package com.example

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.ActivityManager
import android.content.ComponentCallbacks2
import android.content.Context
import android.content.Intent
import android.content.MutableContextWrapper
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Message
import android.print.PrintAttributes
import android.print.PrintManager
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.RenderProcessGoneDetail
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import androidx.webkit.ProfileStore
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import com.example.data.BookmarkEntity
import com.example.data.BrowserDatabase
import com.example.data.BrowserPreferences
import com.example.data.BrowserRepository
import com.example.data.BrowserSettings
import com.example.data.DownloadEntity
import com.example.data.DownloadStatus
import com.example.data.InstalledWebAppEntity
import java.io.ByteArrayInputStream
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class PwaUiState(
    val pwaId: String,
    val appName: String,
    val url: String,
    val pageTitle: String,
    val progress: Int = 0,
    val isLoading: Boolean = true,
    val canGoBack: Boolean = false,
    val canGoForward: Boolean = false,
    val isDesktopMode: Boolean = false,
    val isSslSecure: Boolean = true,
    val isProfileIsolated: Boolean = false,
    val badgeColorHex: Long = 0xFF1A73E8L,
    val favicon: Bitmap? = null
)

data class PwaPoolStats(
    val livePwaIds: Set<String> = emptySet(),
    val liveCount: Int = 0,
    val maxSlotsByRam: Int = 4,
    val totalRamMb: Long = 0L,
    val availRamMb: Long = 0L,
    val isLowMemory: Boolean = false
)

object PwaShortcutHelper {

    const val ACTION_LAUNCH_PWA = "com.example.action.LAUNCH_PWA"
    const val EXTRA_PWA_ID = "extra_pwa_id"
    const val EXTRA_PWA_NAME = "extra_pwa_name"
    const val EXTRA_PWA_URL = "extra_pwa_url"
    const val EXTRA_ISOLATED_PROFILE = "extra_isolated_profile"
    const val EXTRA_PROFILE_NAME = "extra_profile_name"
    const val EXTRA_BADGE_COLOR = "extra_badge_color"
    const val EXTRA_BADGE_TAG = "extra_badge_tag"
    const val EXTRA_OPEN_IN_NEW_TAB = "extra_open_in_new_tab"

    val PRESET_BADGE_COLORS = listOf(
        0xFF1A73E8L, // Google Blue
        0xFF0F9D58L, // Emerald
        0xFF7B61FFL, // Electric Violet
        0xFFEA4335L, // Coral Red
        0xFFF59E0BL, // Warm Amber
        0xFF00ACC1L, // Cyan
        0xFFEC4899L, // Rose
        0xFF334155L  // Slate
    )

    fun generateUniquePwaId(): String {
        val rand = UUID.randomUUID().toString().replace("-", "").take(6)
        return "pwa_${System.currentTimeMillis()}_$rand"
    }

    fun suggestNextAppName(
        rawPageTitle: String?,
        url: String,
        existingApps: List<InstalledWebAppEntity>
    ): String {
        val hostFallback = try {
            Uri.parse(url).host?.removePrefix("www.")?.substringBefore(".")?.replaceFirstChar { it.uppercase() }
                ?: "Web App"
        } catch (_: Exception) {
            "Web App"
        }
        val base = rawPageTitle
            ?.replace(Regex("^Studio \\d+\\s*•\\s*"), "")
            ?.trim()
            ?.takeIf { it.isNotBlank() && it != "New Tab" && it != "Incognito Tab" }
            ?: hostFallback

        val cleanBase = base.take(20).trim()
        val existingNames = existingApps.map { it.name.lowercase() }.toSet()
        if (!existingNames.contains(cleanBase.lowercase())) {
            return cleanBase
        }
        var index = 2
        while (existingNames.contains("$cleanBase $index".lowercase()) && index < 99) {
            index++
        }
        return "$cleanBase $index"
    }

    fun suggestNextBadgeTag(existingApps: List<InstalledWebAppEntity>, url: String): String {
        val sameHostCount = existingApps.count { app ->
            try {
                Uri.parse(app.url).host == Uri.parse(url).host
            } catch (_: Exception) {
                false
            }
        }
        return (sameHostCount + 1).toString()
    }

    fun buildLauncherIconBitmap(
        name: String,
        favicon: Bitmap?,
        badgeColorHex: Long,
        badgeTag: String,
        isStandalonePwa: Boolean
    ): Bitmap {
        val size = 192
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val accentInt = badgeColorHex.toInt()

        // Outer squircle background
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.FILL
        }
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentInt
            style = Paint.Style.STROKE
            strokeWidth = 10f
        }
        val rect = RectF(10f, 10f, size - 10f, size - 10f)
        canvas.drawRoundRect(rect, 44f, 44f, bgPaint)
        canvas.drawRoundRect(rect, 44f, 44f, borderPaint)

        // Center favicon or monogram
        if (favicon != null && !favicon.isRecycled) {
            val iconMargin = 42f
            val dst = RectF(iconMargin, iconMargin, size - iconMargin, size - iconMargin)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
            canvas.drawBitmap(favicon, null, dst, paint)
        } else {
            val circlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = accentInt
                style = Paint.Style.FILL
            }
            canvas.drawCircle(size / 2f, size / 2f, 52f, circlePaint)

            val letter = name.trim().firstOrNull()?.uppercase() ?: "W"
            val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = 58f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
            }
            val yPos = size / 2f - (textPaint.descent() + textPaint.ascent()) / 2f
            canvas.drawText(letter, size / 2f, yPos, textPaint)
        }

        // Distinct badge pill (so 5-10 PWAs of the same website are visually distinguishable)
        val tagText = badgeTag.trim().take(3).ifBlank { if (isStandalonePwa) "PWA" else "" }
        if (tagText.isNotEmpty()) {
            val badgeRadius = if (tagText.length > 2) 30f else 26f
            val cx = size - 36f
            val cy = size - 36f

            val haloPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                style = Paint.Style.FILL
            }
            canvas.drawCircle(cx, cy, badgeRadius + 5f, haloPaint)

            val badgeBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = accentInt
                style = Paint.Style.FILL
            }
            canvas.drawCircle(cx, cy, badgeRadius, badgeBgPaint)

            val tagPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = if (tagText.length > 2) 21f else 27f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
            }
            val tagY = cy - (tagPaint.descent() + tagPaint.ascent()) / 2f
            canvas.drawText(tagText, cx, tagY, tagPaint)
        }

        return bitmap
    }

    fun buildLaunchIntent(
        context: Context,
        app: InstalledWebAppEntity,
        forShortcutPinning: Boolean = false
    ): Intent {
        return if (app.isStandalonePwa) {
            Intent(context, PwaActivity::class.java).apply {
                action = ACTION_LAUNCH_PWA
                data = Uri.parse("studiopwa://app/${app.pwaId}")
                flags = if (forShortcutPinning) {
                    Intent.FLAG_ACTIVITY_NEW_DOCUMENT or Intent.FLAG_ACTIVITY_MULTIPLE_TASK
                } else {
                    Intent.FLAG_ACTIVITY_NEW_DOCUMENT or
                        Intent.FLAG_ACTIVITY_MULTIPLE_TASK or
                        Intent.FLAG_ACTIVITY_NEW_TASK
                }
                putExtra(EXTRA_PWA_ID, app.pwaId)
                putExtra(EXTRA_PWA_NAME, app.name)
                putExtra(EXTRA_PWA_URL, app.url)
                putExtra(EXTRA_ISOLATED_PROFILE, app.isolatedProfile)
                putExtra(EXTRA_PROFILE_NAME, app.profileName)
                putExtra(EXTRA_BADGE_COLOR, app.badgeColorHex)
                putExtra(EXTRA_BADGE_TAG, app.badgeTag)
            }
        } else {
            Intent(context, MainActivity::class.java).apply {
                action = Intent.ACTION_VIEW
                data = Uri.parse(app.url)
                if (!forShortcutPinning) {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                }
                putExtra(EXTRA_OPEN_IN_NEW_TAB, true)
            }
        }
    }

    fun pinToHomeScreen(
        context: Context,
        app: InstalledWebAppEntity,
        favicon: Bitmap?
    ): Boolean {
        val iconBitmap = buildLauncherIconBitmap(
            name = app.name,
            favicon = favicon,
            badgeColorHex = app.badgeColorHex,
            badgeTag = app.badgeTag,
            isStandalonePwa = app.isStandalonePwa
        )
        val launchIntent = buildLaunchIntent(context, app, forShortcutPinning = true)
        val shortcutId = if (app.isStandalonePwa) "pwa_${app.pwaId}" else "sc_${app.pwaId}"

        val shortcutInfo = ShortcutInfoCompat.Builder(context, shortcutId)
            .setShortLabel(app.name.take(24).ifBlank { "Web App" })
            .setLongLabel(app.name.take(48).ifBlank { app.url })
            .setIcon(IconCompat.createWithBitmap(iconBitmap))
            .setIntent(launchIntent)
            .build()

        // Also register as a dynamic app shortcut for quick access on launcher long-press
        try {
            ShortcutManagerCompat.pushDynamicShortcut(context, shortcutInfo)
        } catch (_: Exception) {
        }

        return try {
            if (ShortcutManagerCompat.isRequestPinShortcutSupported(context)) {
                ShortcutManagerCompat.requestPinShortcut(context, shortcutInfo, null)
            } else {
                false
            }
        } catch (_: Exception) {
            false
        }
    }

    fun launchWebApp(context: Context, app: InstalledWebAppEntity) {
        try {
            val intent = buildLaunchIntent(context, app, forShortcutPinning = false)
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Unable to open ${app.name}: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun isMultiProfileSupported(): Boolean {
        return try {
            WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)
        } catch (_: Exception) {
            false
        }
    }

    fun deleteIsolatedProfile(profileName: String) {
        if (profileName.isBlank() || profileName == "Default") return
        try {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
                ProfileStore.getInstance().deleteProfile(profileName)
            }
        } catch (_: Exception) {
        }
    }
}

class PwaSessionController(
    private val appContext: Context,
    val app: InstalledWebAppEntity
) {
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mainScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val repository = BrowserRepository(BrowserDatabase.getInstance(appContext))
    val preferences = BrowserPreferences(appContext)
    private val contextWrapper = MutableContextWrapper(appContext)
    private val userMediaUnlocked = MutableStateFlow(false)

    @Volatile
    private var currentDestination = DownloadDestination()

    @Volatile
    var askBeforeDownload: Boolean = true
        private set

    private val _uiState = MutableStateFlow(
        PwaUiState(
            pwaId = app.pwaId,
            appName = app.name,
            url = app.url,
            pageTitle = app.name,
            isSslSecure = app.url.startsWith("https://"),
            badgeColorHex = app.badgeColorHex
        )
    )
    val uiState: StateFlow<PwaUiState> = _uiState.asStateFlow()

    private val _oauthPopupState = MutableStateFlow<OAuthPopupSession?>(null)
    val oauthPopupState: StateFlow<OAuthPopupSession?> = _oauthPopupState.asStateFlow()

    private val _pendingDownload = MutableStateFlow<PendingDownloadRequest?>(null)
    val pendingDownload: StateFlow<PendingDownloadRequest?> = _pendingDownload.asStateFlow()

    private val _findInPageState = MutableStateFlow(FindInPageState())
    val findInPageState: StateFlow<FindInPageState> = _findInPageState.asStateFlow()

    private var currentActivity: Activity? = null
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var activeFileChooserSession: ChromeFileChooserSession? = null
    var onLaunchFileChooser: ((Intent) -> Boolean)? = null
    var onRequestRuntimePermissions: ((Array<String>, (Boolean) -> Unit) -> Unit)? = null

    private var cookieManager: CookieManager = CookieManager.getInstance()
    private var isolatedProfileActive: Boolean = false

    private val downloadBridge = StudioDownloadBridge(appContext) { fileName, url, mimeType, uriStr, sizeBytes, folderLabel ->
        ioScope.launch {
            repository.insertDownload(
                DownloadEntity(
                    systemDownloadId = -1L,
                    fileName = fileName,
                    url = url,
                    mimeType = mimeType,
                    localUri = uriStr,
                    status = DownloadStatus.SUCCESSFUL,
                    totalBytes = sizeBytes,
                    downloadedBytes = sizeBytes,
                    saveFolderLabel = folderLabel
                )
            )
        }
    }

    var webView: UnthrottledWebView = createPwaWebView()
        private set

    private val _webViewGeneration = MutableStateFlow(0)
    val webViewGeneration: StateFlow<Int> = _webViewGeneration.asStateFlow()

    @Volatile
    private var currentSettings = BrowserSettings()

    init {
        ioScope.launch {
            try {
                preferences.settingsFlow.collectLatest { latest ->
                    currentSettings = latest
                    askBeforeDownload = latest.askBeforeDownload
                    currentDestination = DownloadDestination(
                        preset = DownloadFolderPreset.fromId(latest.downloadFolderPreset),
                        customTreeUri = latest.customDownloadTreeUri,
                        customFolderLabel = latest.customDownloadFolderLabel
                    )
                    mainScope.launch {
                        if (webView.settings.textZoom != latest.textZoomPercent) {
                            webView.settings.textZoom = latest.textZoomPercent
                        }
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            webView.settings.isAlgorithmicDarkeningAllowed = latest.darkWebPages
                        }
                    }
                }
            } catch (_: Exception) {
            }
        }
        webView.loadUrl(app.url)
    }

    fun attachActivity(activity: Activity) {
        currentActivity = activity
        contextWrapper.baseContext = activity
        if (webView.visibility != View.VISIBLE) {
            webView.visibility = View.VISIBLE
        }
        webView.onResume()
        webView.resumeTimers()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                webView.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false)
            } catch (_: Exception) {
            }
        }
        PwaWebViewPool.markForeground(app.pwaId, isForeground = true)
        injectAntiThrottleJavaScript(isActive = true)
    }

    fun detachActivity(activity: Activity) {
        if (currentActivity === activity) {
            currentActivity = null
            contextWrapper.baseContext = appContext
        }
        PwaWebViewPool.markForeground(app.pwaId, isForeground = false)
        flushCookies()
    }

    fun pulseKeepAlive(isForeground: Boolean) {
        try {
            if (webView.visibility != View.VISIBLE) {
                webView.visibility = View.VISIBLE
            }
            webView.resumeTimers()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                webView.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false)
            }
            if (!isForeground) {
                webView.evaluateJavascript("window.__studioTabIsActive=false;", null)
            }
        } catch (_: Exception) {
        }
    }

    private fun injectAntiThrottleJavaScript(isActive: Boolean) {
        try {
            val stateJs = "window.__studioTabIsActive = $isActive;"
            webView.evaluateJavascript("$stateJs\n${WebViewManager.PAGE_VISIBILITY_OVERRIDE_JS}", null)
        } catch (_: Exception) {
        }
    }

    fun reloadOrStop() {
        if (_uiState.value.isLoading) {
            webView.stopLoading()
            _uiState.update { it.copy(isLoading = false, progress = 100) }
        } else {
            webView.reload()
        }
    }

    fun goBack(): Boolean {
        return if (webView.canGoBack()) {
            webView.goBack()
            true
        } else {
            false
        }
    }

    fun goForward(): Boolean {
        return if (webView.canGoForward()) {
            webView.goForward()
            true
        } else {
            false
        }
    }

    fun goHome() {
        webView.loadUrl(app.url)
    }

    fun toggleDesktopMode() {
        val next = !_uiState.value.isDesktopMode
        webView.settings.userAgentString = if (next) {
            WebViewManager.DESKTOP_CHROME_USER_AGENT
        } else {
            WebViewManager.MOBILE_CHROME_USER_AGENT
        }
        _uiState.update { it.copy(isDesktopMode = next) }
        webView.reload()
    }

    fun bookmarkCurrentPage() {
        val state = _uiState.value
        ioScope.launch {
            repository.addOrUpdateBookmark(
                BookmarkEntity(
                    title = state.pageTitle.ifBlank { state.appName },
                    url = state.url,
                    isSpeedDial = false
                )
            )
            mainScope.launch {
                Toast.makeText(currentActivity ?: appContext, "Bookmarked offline in Room DB", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun showFindInPage() {
        _findInPageState.update { it.copy(isVisible = true) }
    }

    fun updateFindQuery(query: String) {
        _findInPageState.update { it.copy(query = query) }
        if (query.isBlank()) {
            webView.clearMatches()
            _findInPageState.update { it.copy(activeMatchIndex = 0, totalMatches = 0) }
        } else {
            webView.findAllAsync(query)
        }
    }

    fun findNextMatch(forward: Boolean) {
        webView.findNext(forward)
    }

    fun clearFindInPage() {
        webView.clearMatches()
        _findInPageState.value = FindInPageState()
    }

    fun updateAskBeforeDownload(ask: Boolean) {
        askBeforeDownload = ask
        ioScope.launch {
            preferences.setAskBeforeDownload(ask)
        }
    }

    fun savePreferredDestination(destination: DownloadDestination) {
        currentDestination = destination
        ioScope.launch {
            preferences.setDownloadDestination(
                preset = destination.preset.name,
                customTreeUri = destination.customTreeUri,
                customFolderLabel = destination.customFolderLabel
            )
        }
    }

    fun confirmPendingDownload(
        customName: String,
        destination: DownloadDestination = currentDestination
    ) {
        val req = _pendingDownload.value ?: return
        _pendingDownload.value = null
        savePreferredDestination(destination)
        executeDownload(req, customName.ifBlank { req.suggestedFileName }, destination)
    }

    fun dismissPendingDownload() {
        _pendingDownload.value = null
    }

    private fun executeDownload(
        req: PendingDownloadRequest,
        finalName: String,
        destination: DownloadDestination
    ) {
        val url = req.url
        if (url.startsWith("blob:") || url.startsWith("data:")) {
            val script = DownloadHelper.buildBlobOrDataExtractionScript(
                blobOrDataUrl = url,
                suggestedName = finalName,
                mimeType = req.mimeType,
                destination = destination
            )
            webView.evaluateJavascript(script, null)
            Toast.makeText(
                currentActivity ?: appContext,
                "Saving $finalName to ${destination.displayLabel()}...",
                Toast.LENGTH_SHORT
            ).show()
            return
        }
        ioScope.launch {
            try {
                DownloadHelper.enqueueDownloadWithDestination(
                    context = appContext,
                    repository = repository,
                    url = url,
                    fileName = finalName,
                    mimeType = req.mimeType,
                    userAgent = req.userAgent,
                    destination = destination
                )
                mainScope.launch {
                    Toast.makeText(
                        currentActivity ?: appContext,
                        "Downloading $finalName to ${destination.displayLabel()}...",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            } catch (_: Exception) {
            }
        }
    }

    fun printPage() {
        val activity = currentActivity ?: return
        try {
            val printManager = activity.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return
            val jobName = "${_uiState.value.appName.take(40)} - PWA"
            val adapter = webView.createPrintDocumentAdapter(jobName)
            printManager.print(jobName, adapter, PrintAttributes.Builder().build())
        } catch (_: Exception) {
        }
    }

    fun clearThisPwaSession() {
        try {
            cookieManager.removeAllCookies {
                ioScope.launch {
                    try {
                        cookieManager.flush()
                    } catch (_: Exception) {
                    }
                }
            }
            if (!isolatedProfileActive) {
                WebStorage.getInstance().deleteAllData()
            }
            webView.clearCache(true)
            webView.clearHistory()
            webView.clearFormData()
            webView.loadUrl(app.url)
            Toast.makeText(currentActivity ?: appContext, "Cleared session for ${app.name}", Toast.LENGTH_SHORT).show()
        } catch (_: Exception) {
        }
    }

    fun closeOAuthPopup() {
        val session = _oauthPopupState.value ?: return
        _oauthPopupState.value = null
        try {
            val popupView = session.popupWebView
            (popupView.parent as? ViewGroup)?.removeView(popupView)
            if (popupView is UnthrottledWebView) popupView.allowExplicitDestroy = true
            popupView.stopLoading()
            popupView.destroy()
        } catch (_: Exception) {
        }
        flushCookies()
    }

    fun flushCookies() {
        ioScope.launch {
            try {
                cookieManager.flush()
            } catch (_: Exception) {
            }
        }
    }

    fun onFileChooserResult(resultCode: Int, data: Intent?) {
        val callback = filePathCallback ?: return
        val session = activeFileChooserSession
        filePathCallback = null
        activeFileChooserSession = null
        val uris = DeviceAccessHelper.resolveFileChooserResult(
            context = currentActivity ?: appContext,
            resultCode = resultCode,
            data = data,
            session = session
        )
        callback.onReceiveValue(uris)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createPwaWebView(): UnthrottledWebView {
        val wv = UnthrottledWebView(contextWrapper).apply {
            setLayerType(View.LAYER_TYPE_NONE, null)
            isFocusable = true
            isFocusableInTouchMode = true
            keepScreenOn = true
            isNestedScrollingEnabled = true
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
            scrollBarStyle = View.SCROLLBARS_INSIDE_OVERLAY
            isVerticalScrollBarEnabled = true
            onUserTap = {
                userMediaUnlocked.value = true
                try {
                    evaluateJavascript("window.__studioUserMediaUnlocked = true;", null)
                } catch (_: Exception) {
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false)
                importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_YES
            }
        }

        // Apply isolated Chromium WebView Profile per PWA when supported
        if (app.isolatedProfile && WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            try {
                val profile = ProfileStore.getInstance().getOrCreateProfile(app.profileName)
                WebViewCompat.setProfile(wv, app.profileName)
                cookieManager = profile.cookieManager
                isolatedProfileActive = true
            } catch (_: Exception) {
                cookieManager = CookieManager.getInstance()
                isolatedProfileActive = false
            }
        }
        _uiState.update { it.copy(isProfileIsolated = isolatedProfileActive) }

        configurePwaWebSettings(wv, isDesktop = false)
        wv.addJavascriptInterface(downloadBridge, "StudioDownloadBridge")

        wv.setFindListener { activeOrdinal, total, _ ->
            _findInPageState.update {
                it.copy(
                    activeMatchIndex = if (total > 0) activeOrdinal + 1 else 0,
                    totalMatches = total
                )
            }
        }

        wv.setDownloadListener(
            DownloadListener { url, userAgent, contentDisposition, mimeType, contentLength ->
                if (url.isNullOrBlank()) return@DownloadListener
                val safeMime = mimeType ?: "application/octet-stream"
                val suggestedName = DownloadHelper.guessName(url, contentDisposition, safeMime)
                val req = PendingDownloadRequest(
                    url = url,
                    userAgent = userAgent ?: WebViewManager.MOBILE_CHROME_USER_AGENT,
                    contentDisposition = contentDisposition ?: "",
                    mimeType = safeMime,
                    contentLength = contentLength,
                    suggestedFileName = suggestedName,
                    defaultDestination = currentDestination
                )
                if (askBeforeDownload) {
                    _pendingDownload.value = req
                } else {
                    executeDownload(req, suggestedName, currentDestination)
                }
            }
        )

        wv.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val headers = request.requestHeaders
                val fetchDest = headers?.get("Sec-Fetch-Dest") ?: headers?.get("sec-fetch-dest")
                val accept = headers?.get("Accept") ?: headers?.get("accept") ?: ""
                val path = request.url?.path?.lowercase() ?: ""
                val isVideo = fetchDest.equals("video", ignoreCase = true) ||
                    accept.startsWith("video/", ignoreCase = true) ||
                    listOf(".mp4", ".webm", ".m4v", ".mov", ".ogv", ".m3u8", ".mpd").any { path.endsWith(it) }
                if (isVideo && !userMediaUnlocked.value) {
                    val host = request.url?.host?.lowercase() ?: ""
                    val isVideoHost = host.contains("youtube.com") || host.contains("googlevideo.com") || host.contains("vimeo.com")
                    if (!isVideoHost) {
                        return WebResourceResponse("text/plain", "UTF-8", 204, "Deferred Video", emptyMap(), ByteArrayInputStream(ByteArray(0)))
                    }
                }
                return super.shouldInterceptRequest(view, request)
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url ?: return false
                val scheme = uri.scheme?.lowercase() ?: return false
                if (scheme == "http" || scheme == "https") return false
                return try {
                    (currentActivity ?: appContext).startActivity(
                        Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                    true
                } catch (_: Exception) {
                    true
                }
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                val safeUrl = url ?: app.url
                val host = try { Uri.parse(safeUrl).host?.lowercase().orEmpty() } catch (_: Exception) { "" }
                userMediaUnlocked.value = host.contains("youtube.com") || host.contains("vimeo.com")
                _uiState.update {
                    it.copy(
                        url = safeUrl,
                        progress = 15,
                        isLoading = true,
                        isSslSecure = safeUrl.startsWith("https://"),
                        canGoBack = view.canGoBack(),
                        canGoForward = view.canGoForward()
                    )
                }
                injectAntiThrottleJavaScript(isActive = currentActivity != null)
            }

            override fun onPageFinished(view: WebView, url: String?) {
                super.onPageFinished(view, url)
                val safeUrl = url ?: view.url ?: app.url
                val resolvedTitle = view.title?.takeIf { t -> t.isNotBlank() }
                _uiState.update {
                    it.copy(
                        url = safeUrl,
                        pageTitle = resolvedTitle ?: it.pageTitle,
                        progress = 100,
                        isLoading = false,
                        isSslSecure = safeUrl.startsWith("https://"),
                        canGoBack = view.canGoBack(),
                        canGoForward = view.canGoForward()
                    )
                }
                if (safeUrl.startsWith("http")) {
                    ioScope.launch {
                        repository.recordHistory(
                            title = "${app.name} • ${resolvedTitle ?: safeUrl}",
                            url = safeUrl
                        )
                    }
                }
                injectAntiThrottleJavaScript(isActive = true)
                flushCookies()
            }

            override fun onRenderProcessGone(
                view: WebView?,
                detail: RenderProcessGoneDetail?
            ): Boolean {
                recoverFromRendererCrash(view)
                return true
            }
        }

        wv.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                super.onProgressChanged(view, newProgress)
                _uiState.update {
                    it.copy(
                        progress = newProgress,
                        isLoading = newProgress < 100
                    )
                }
            }

            override fun onReceivedTitle(view: WebView, title: String?) {
                super.onReceivedTitle(view, title)
                if (!title.isNullOrBlank()) {
                    _uiState.update { it.copy(pageTitle = title) }
                }
            }

            override fun onReceivedIcon(view: WebView, icon: Bitmap?) {
                super.onReceivedIcon(view, icon)
                if (icon != null) {
                    _uiState.update { it.copy(favicon = icon) }
                }
            }

            override fun onCreateWindow(
                view: WebView,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: Message?
            ): Boolean {
                val transport = resultMsg?.obj as? WebView.WebViewTransport ?: return false
                val popupWebView = UnthrottledWebView(MutableContextWrapper(currentActivity ?: appContext)).apply {
                    setLayerType(View.LAYER_TYPE_NONE, null)
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
                if (isolatedProfileActive && WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
                    try {
                        WebViewCompat.setProfile(popupWebView, app.profileName)
                    } catch (_: Exception) {
                    }
                }
                configurePwaWebSettings(popupWebView, isDesktop = _uiState.value.isDesktopMode)
                popupWebView.webViewClient = object : WebViewClient() {
                    override fun onPageStarted(popupView: WebView, url: String?, favicon: Bitmap?) {
                        _oauthPopupState.update { it?.copy(url = url ?: it.url, isLoading = true) }
                    }

                    override fun onPageFinished(popupView: WebView, url: String?) {
                        flushCookies()
                        _oauthPopupState.update {
                            it?.copy(
                                url = url ?: popupView.url ?: it.url,
                                title = popupView.title?.takeIf { t -> t.isNotBlank() } ?: it.title,
                                isLoading = false,
                                progress = 100
                            )
                        }
                    }

                    override fun onRenderProcessGone(
                        view: WebView?,
                        detail: RenderProcessGoneDetail?
                    ): Boolean {
                        closeOAuthPopup()
                        return true
                    }
                }
                popupWebView.webChromeClient = object : WebChromeClient() {
                    override fun onProgressChanged(popupView: WebView, newProgress: Int) {
                        _oauthPopupState.update { it?.copy(progress = newProgress, isLoading = newProgress < 100) }
                    }

                    override fun onCloseWindow(window: WebView?) {
                        flushCookies()
                        closeOAuthPopup()
                    }

                    override fun onShowFileChooser(
                        webView: WebView,
                        filePathCallback: ValueCallback<Array<Uri>>,
                        fileChooserParams: FileChooserParams
                    ): Boolean {
                        return handleFileChooser(filePathCallback, fileChooserParams)
                    }

                    override fun onPermissionRequest(request: PermissionRequest?) {
                        if (request != null) handleWebPermissions(request)
                    }

                    override fun onGeolocationPermissionsShowPrompt(
                        origin: String?,
                        callback: GeolocationPermissions.Callback?
                    ) {
                        DeviceAccessHelper.handleGeolocationPermissionRequest(
                            context = appContext,
                            origin = origin,
                            callback = callback,
                            onRequestRuntimePermissions = onRequestRuntimePermissions
                        )
                    }
                }
                _oauthPopupState.value = OAuthPopupSession(
                    parentTabId = 0,
                    popupWebView = popupWebView
                )
                transport.webView = popupWebView
                resultMsg.sendToTarget()
                return true
            }

            override fun onShowFileChooser(
                webView: WebView,
                filePathCallback: ValueCallback<Array<Uri>>,
                fileChooserParams: FileChooserParams
            ): Boolean {
                return handleFileChooser(filePathCallback, fileChooserParams)
            }

            override fun onPermissionRequest(request: PermissionRequest?) {
                if (request != null) handleWebPermissions(request)
            }

            override fun onGeolocationPermissionsShowPrompt(
                origin: String?,
                callback: GeolocationPermissions.Callback?
            ) {
                DeviceAccessHelper.handleGeolocationPermissionRequest(
                    context = appContext,
                    origin = origin,
                    callback = callback,
                    onRequestRuntimePermissions = onRequestRuntimePermissions
                )
            }
        }

        return wv
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configurePwaWebSettings(wv: WebView, isDesktop: Boolean) {
        cookieManager.setAcceptCookie(true)
        cookieManager.setAcceptThirdPartyCookies(wv, true)
        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            javaScriptCanOpenWindowsAutomatically = true
            setSupportMultipleWindows(true)
            allowFileAccess = true
            allowContentAccess = true
            setGeolocationEnabled(true)
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            mediaPlaybackRequiresUserGesture = true
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                safeBrowsingEnabled = false
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                isAlgorithmicDarkeningAllowed = currentSettings.darkWebPages
            }
            textZoom = currentSettings.textZoomPercent
            try {
                if (WebViewFeature.isFeatureSupported(WebViewFeature.OFF_SCREEN_PRERASTER)) {
                    WebSettingsCompat.setOffscreenPreRaster(this, true)
                }
            } catch (_: Exception) {
            }
            userAgentString = if (isDesktop) {
                WebViewManager.DESKTOP_CHROME_USER_AGENT
            } else {
                WebViewManager.MOBILE_CHROME_USER_AGENT
            }
        }
    }

    private fun handleFileChooser(
        callback: ValueCallback<Array<Uri>>,
        params: WebChromeClient.FileChooserParams
    ): Boolean {
        filePathCallback?.onReceiveValue(null)
        filePathCallback = callback
        val launcher = onLaunchFileChooser
        if (launcher == null) {
            filePathCallback?.onReceiveValue(null)
            filePathCallback = null
            return false
        }

        val launchNow = {
            val session = DeviceAccessHelper.createChromeFileChooserSession(
                context = currentActivity ?: appContext,
                fileChooserParams = params
            )
            activeFileChooserSession = session
            val launched = launcher.invoke(session.chooserIntent)
            if (!launched) {
                activeFileChooserSession = null
                filePathCallback?.onReceiveValue(null)
                filePathCallback = null
            }
        }

        val missingCapturePerms = DeviceAccessHelper.getMissingCapturePermissions(appContext)
        val permRequester = onRequestRuntimePermissions
        if (missingCapturePerms.isNotEmpty() && permRequester != null) {
            permRequester(missingCapturePerms) { _ ->
                launchNow()
            }
        } else {
            launchNow()
        }
        return true
    }

    private fun handleWebPermissions(request: PermissionRequest) {
        DeviceAccessHelper.handleWebPermissionRequest(
            context = appContext,
            request = request,
            onRequestRuntimePermissions = onRequestRuntimePermissions
        )
    }

    private fun recoverFromRendererCrash(crashedView: WebView?) {
        val currentUrl = _uiState.value.url.ifBlank { app.url }
        try {
            (crashedView as? UnthrottledWebView)?.allowExplicitDestroy = true
            (crashedView?.parent as? ViewGroup)?.removeView(crashedView)
            crashedView?.destroy()
        } catch (_: Exception) {
        }
        val replacement = createPwaWebView()
        webView = replacement
        _webViewGeneration.value += 1
        replacement.loadUrl(currentUrl)
    }

    fun destroy() {
        flushCookies()
        closeOAuthPopup()
        try {
            webView.allowExplicitDestroy = true
            (webView.parent as? ViewGroup)?.removeView(webView)
            webView.stopLoading()
            webView.destroy()
        } catch (_: Exception) {
        }
    }
}

object PwaWebViewPool {
    private data class PooledEntry(
        val controller: PwaSessionController,
        @Volatile var lastUsedAtMs: Long = System.currentTimeMillis(),
        @Volatile var isForeground: Boolean = false
    )

    private val sessions = ConcurrentHashMap<String, PooledEntry>()
    private val memoryCallbackRegistered = AtomicBoolean(false)

    @Volatile
    private var keepAliveEnabled: Boolean = true

    private val _poolStats = MutableStateFlow(PwaPoolStats())
    val poolStats: StateFlow<PwaPoolStats> = _poolStats.asStateFlow()

    fun setKeepAliveEnabled(enabled: Boolean, context: Context? = null) {
        if (keepAliveEnabled == enabled) return
        keepAliveEnabled = enabled
        if (context != null) {
            enforceRamBudget(context.applicationContext)
        }
    }

    /**
     * Pure RAM capacity heuristic: maximizes live background PWAs according to device total & available RAM
     * so repeated taps reopen instantly without reloading, while protecting against OS OOM process kills.
     */
    fun calculateMaxSlotsForRam(totalRamMb: Long, availRamMb: Long, isLowMemory: Boolean): Int {
        val hardwareBase = when {
            totalRamMb >= 11_000L -> 12
            totalRamMb >= 7_500L -> 8
            totalRamMb >= 5_500L -> 6
            totalRamMb >= 3_500L -> 4
            else -> 2
        }
        if (isLowMemory || availRamMb in 1L..449L) {
            return 1
        }
        if (availRamMb in 450L..899L) {
            return (hardwareBase / 2).coerceAtLeast(2)
        }
        return hardwareBase
    }

    private fun readDeviceMemorySnapshot(context: Context): Triple<Long, Long, Boolean> {
        return try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            if (am != null) {
                val info = ActivityManager.MemoryInfo()
                am.getMemoryInfo(info)
                val totalMb = (info.totalMem / (1024L * 1024L)).coerceAtLeast(1024L)
                val availMb = (info.availMem / (1024L * 1024L)).coerceAtLeast(0L)
                Triple(totalMb, availMb, info.lowMemory)
            } else {
                Triple(4096L, 2048L, false)
            }
        } catch (_: Exception) {
            Triple(4096L, 2048L, false)
        }
    }

    private fun ensureMemoryCallbacksRegistered(appContext: Context) {
        if (memoryCallbackRegistered.compareAndSet(false, true)) {
            try {
                appContext.registerComponentCallbacks(
                    object : ComponentCallbacks2 {
                        override fun onTrimMemory(level: Int) {
                            handleTrimMemory(appContext, level)
                        }

                        override fun onConfigurationChanged(newConfig: Configuration) {}

                        @Deprecated("Deprecated in Java")
                        override fun onLowMemory() {
                            handleTrimMemory(appContext, ComponentCallbacks2.TRIM_MEMORY_COMPLETE)
                        }
                    }
                )
            } catch (_: Exception) {
            }
        }
    }

    fun getOrCreateSession(context: Context, app: InstalledWebAppEntity): PwaSessionController {
        val appCtx = context.applicationContext
        ensureMemoryCallbacksRegistered(appCtx)

        val existing = sessions[app.pwaId]
        if (existing != null) {
            existing.lastUsedAtMs = System.currentTimeMillis()
            refreshStats(appCtx)
            return existing.controller
        }

        val controller = PwaSessionController(appCtx, app)
        sessions[app.pwaId] = PooledEntry(
            controller = controller,
            lastUsedAtMs = System.currentTimeMillis(),
            isForeground = true
        )
        enforceRamBudget(appCtx, protectedPwaId = app.pwaId)
        refreshStats(appCtx)
        return controller
    }

    fun markForeground(pwaId: String, isForeground: Boolean) {
        sessions[pwaId]?.let {
            it.isForeground = isForeground
            it.lastUsedAtMs = System.currentTimeMillis()
        }
    }

    fun isLiveInRam(pwaId: String): Boolean = sessions.containsKey(pwaId)

    fun liveCount(): Int = sessions.size

    fun pulseAllLiveSessions(context: Context) {
        sessions.values.forEach { entry ->
            if (keepAliveEnabled || entry.isForeground) {
                entry.controller.pulseKeepAlive(entry.isForeground)
            }
        }
        refreshStats(context)
    }

    fun flushAllCookies() {
        sessions.values.forEach { entry ->
            entry.controller.flushCookies()
        }
    }

    fun enforceRamBudget(context: Context, protectedPwaId: String? = null) {
        val (totalMb, availMb, lowMem) = readDeviceMemorySnapshot(context)
        val maxSlots = if (keepAliveEnabled) {
            calculateMaxSlotsForRam(totalMb, availMb, lowMem)
        } else {
            1
        }
        trimPoolToTarget(targetMaxCount = maxSlots, protectedPwaId = protectedPwaId)
        refreshStats(context)
    }

    @Suppress("DEPRECATION")
    private fun handleTrimMemory(context: Context, level: Int) {
        val (totalMb, availMb, lowMem) = readDeviceMemorySnapshot(context)
        val baseMax = if (keepAliveEnabled) {
            calculateMaxSlotsForRam(totalMb, availMb, lowMem)
        } else {
            1
        }
        val target = when {
            !keepAliveEnabled -> 1
            level >= ComponentCallbacks2.TRIM_MEMORY_COMPLETE -> 1
            level >= ComponentCallbacks2.TRIM_MEMORY_MODERATE -> (baseMax / 2).coerceAtLeast(2)
            level == ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL -> 1
            level == ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW -> (baseMax - 1).coerceAtLeast(2)
            else -> baseMax
        }
        if (sessions.size > target) {
            trimPoolToTarget(targetMaxCount = target, protectedPwaId = null)
        }
        flushAllCookies()
        refreshStats(context)
    }

    private fun trimPoolToTarget(targetMaxCount: Int, protectedPwaId: String?) {
        if (sessions.size <= targetMaxCount) return
        val candidates = sessions.entries
            .filter { (id, entry) -> id != protectedPwaId && !entry.isForeground }
            .sortedBy { it.value.lastUsedAtMs }

        for (candidate in candidates) {
            if (sessions.size <= targetMaxCount) break
            sessions.remove(candidate.key)?.controller?.destroy()
        }
    }

    fun refreshStats(context: Context) {
        val (totalMb, availMb, lowMem) = readDeviceMemorySnapshot(context)
        val maxSlots = if (keepAliveEnabled) {
            calculateMaxSlotsForRam(totalMb, availMb, lowMem)
        } else {
            1
        }
        val keys = sessions.keys.toSet()
        _poolStats.value = PwaPoolStats(
            livePwaIds = keys,
            liveCount = keys.size,
            maxSlotsByRam = maxSlots,
            totalRamMb = totalMb,
            availRamMb = availMb,
            isLowMemory = lowMem
        )
    }

    fun removeAndDestroySession(pwaId: String, context: Context? = null) {
        sessions.remove(pwaId)?.controller?.destroy()
        if (context != null) {
            refreshStats(context)
        } else {
            _poolStats.update { current ->
                val updatedIds = current.livePwaIds - pwaId
                current.copy(livePwaIds = updatedIds, liveCount = updatedIds.size)
            }
        }
    }
}
