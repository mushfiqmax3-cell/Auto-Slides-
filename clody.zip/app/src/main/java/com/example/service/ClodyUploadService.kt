package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.example.ClodyApplication
import com.example.MainActivity
import com.example.R
import com.example.data.local.FileEntity
import com.example.data.local.UploadStatus
import com.example.data.local.UploadTaskEntity
import com.example.media.ThumbnailGenerator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest

class ClodyUploadService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var workerJob: Job? = null
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PAUSE_CURRENT -> {
                val taskId = intent.getLongExtra(EXTRA_TASK_ID, -1L)
                serviceScope.launch {
                    val dao = (application as ClodyApplication).container.dao
                    if (taskId > 0L) {
                        dao.updateUploadStatus(taskId, UploadStatus.PAUSED.name, "Paused by user")
                    }
                    workerJob?.cancel()
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                }
                return START_NOT_STICKY
            }
            ACTION_CANCEL_CURRENT -> {
                val taskId = intent.getLongExtra(EXTRA_TASK_ID, -1L)
                serviceScope.launch {
                    val dao = (application as ClodyApplication).container.dao
                    if (taskId > 0L) {
                        dao.updateUploadStatus(taskId, UploadStatus.CANCELLED.name, "Cancelled")
                    }
                    workerJob?.cancel()
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                }
                return START_NOT_STICKY
            }
        }

        val initialNotif = buildProgressNotification(
            taskId = -1L,
            fileName = "Preparing Clody upload queue...",
            progressPct = 0,
            subtitle = "Starting background transfer"
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                initialNotif,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            startForeground(NOTIFICATION_ID, initialNotif)
        }

        if (workerJob?.isActive != true) {
            acquireWakeLock()
            workerJob = serviceScope.launch {
                try {
                    processUploadQueue()
                } finally {
                    releaseWakeLock()
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                }
            }
        }

        return START_STICKY
    }

    private suspend fun processUploadQueue() {
        val container = (application as ClodyApplication).container
        val dao = container.dao
        val telegram = container.telegramClient
        val settingsRepo = container.settingsRepository
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        while (true) {
            val task = dao.getNextPendingUpload() ?: break
            val settings = settingsRepo.settingsFlow.first()

            if (settings.uploadWifiOnly && !isOnWifi()) {
                dao.updateUploadStatus(task.id, UploadStatus.PAUSED.name, "Waiting for Wi-Fi")
                nm.notify(
                    NOTIFICATION_ID,
                    buildProgressNotification(
                        taskId = task.id,
                        fileName = task.fileName,
                        progressPct = 0,
                        subtitle = "Paused — Waiting for Wi-Fi"
                    )
                )
                break
            }

            dao.updateUploadStatus(task.id, UploadStatus.UPLOADING.name, null)

            val stagedFile = stageUriToPrivateFile(task)
            if (stagedFile == null || !stagedFile.exists()) {
                dao.updateUploadStatus(task.id, UploadStatus.FAILED.name, "Source file unavailable")
                continue
            }

            val thumbPath = task.customThumbnailPath?.takeIf { File(it).exists() }
                ?: task.extractedThumbnailPath?.takeIf { File(it).exists() }
            val thumbFile = thumbPath?.let { File(it) }
            val isVideo = task.mimeType.startsWith("video/")
            val sha256 = computeSha256(stagedFile)

            var lastNotifTime = 0L
            val result = telegram.uploadFile(
                file = stagedFile,
                fileName = task.fileName,
                mimeType = task.mimeType,
                thumbnailFile = thumbFile,
                isVideo = isVideo,
                durationSec = task.durationMs / 1000.0,
                onProgress = { sent, speed ->
                    dao.updateUploadProgress(task.id, sent, speed)
                    val now = System.currentTimeMillis()
                    if (now - lastNotifTime > 450L || sent >= task.sizeBytes) {
                        lastNotifTime = now
                        val pct = if (task.sizeBytes > 0L) ((sent * 100L) / task.sizeBytes).toInt().coerceIn(0, 100) else 0
                        val speedLabel = formatSpeed(speed)
                        nm.notify(
                            NOTIFICATION_ID,
                            buildProgressNotification(
                                taskId = task.id,
                                fileName = task.fileName,
                                progressPct = pct,
                                subtitle = "$pct% • $speedLabel"
                            )
                        )
                    }
                }
            )

            stagedFile.delete()

            result.onSuccess { doc ->
                val ext = task.fileName.substringAfterLast('.', "")
                val entity = FileEntity(
                    name = task.fileName,
                    extension = ext,
                    sizeBytes = doc.sizeBytes,
                    mimeType = task.mimeType,
                    folderId = task.folderId,
                    folderPath = task.folderPath,
                    telegramMessageId = doc.messageId,
                    telegramDocumentId = doc.documentId,
                    telegramAccessHash = doc.accessHash,
                    telegramFileReferenceHex = doc.fileReference.joinToString("") { "%02x".format(it) },
                    telegramDcId = doc.dcId,
                    durationMs = task.durationMs,
                    thumbnailPath = task.extractedThumbnailPath,
                    customThumbnailPath = task.customThumbnailPath,
                    localSourceUri = task.localUriString,
                    createdAt = System.currentTimeMillis(),
                    sha256 = sha256
                )
                dao.insertFile(entity)
                dao.updateUploadStatus(task.id, UploadStatus.COMPLETED.name, null)
                telegram.pushCloudIndexSnapshot()
            }.onFailure { err ->
                // Check if task was paused/cancelled while uploading
                val latest = dao.getUploadTaskById(task.id)
                if (latest?.status == UploadStatus.UPLOADING.name) {
                    dao.updateUploadStatus(
                        task.id,
                        UploadStatus.FAILED.name,
                        err.message ?: "Upload failed"
                    )
                }
            }
        }
    }

    private fun stageUriToPrivateFile(task: UploadTaskEntity): File? {
        return runCatching {
            val uri = Uri.parse(task.localUriString)
            if (uri.scheme == "file") {
                val direct = File(uri.path ?: return null)
                if (direct.exists()) {
                    val copy = File(cacheDir, "upload_stage_${task.id}_${task.fileName}")
                    direct.copyTo(copy, overwrite = true)
                    return copy
                }
            }
            val stageDir = File(cacheDir, "upload_stage").apply { mkdirs() }
            val outFile = File(stageDir, "stage_${task.id}_${System.currentTimeMillis()}")
            contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(outFile).use { output ->
                    input.copyTo(output, bufferSize = 64 * 1024)
                }
            } ?: return null
            outFile
        }.getOrNull()
    }

    private fun computeSha256(file: File): String {
        return runCatching {
            val digest = MessageDigest.getInstance("SHA-256")
            file.inputStream().use { fis ->
                val buf = ByteArray(32 * 1024)
                while (true) {
                    val r = fis.read(buf)
                    if (r == -1) break
                    digest.update(buf, 0, r)
                }
            }
            digest.digest().joinToString("") { "%02x".format(it) }
        }.getOrDefault("")
    }

    private fun isOnWifi(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(net) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
    }

    private fun buildProgressNotification(
        taskId: Long,
        fileName: String,
        progressPct: Int,
        subtitle: String
    ): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val pauseIntent = PendingIntent.getService(
            this,
            101,
            Intent(this, ClodyUploadService::class.java).apply {
                action = ACTION_PAUSE_CURRENT
                putExtra(EXTRA_TASK_ID, taskId)
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val cancelIntent = PendingIntent.getService(
            this,
            102,
            Intent(this, ClodyUploadService::class.java).apply {
                action = ACTION_CANCEL_CURRENT
                putExtra(EXTRA_TASK_ID, taskId)
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val builder = NotificationCompat.Builder(this, getString(R.string.upload_notification_channel_id))
            .setContentTitle("Uploading $fileName")
            .setContentText(subtitle)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openIntent)
            .setProgress(100, progressPct, progressPct == 0)

        if (taskId > 0L) {
            builder.addAction(0, "Pause", pauseIntent)
            builder.addAction(0, "Cancel", cancelIntent)
        }
        return builder.build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                getString(R.string.upload_notification_channel_id),
                getString(R.string.upload_notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    private fun acquireWakeLock() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Clody::UploadWakeLock").apply {
            acquire(60 * 60 * 1000L)
        }
    }

    private fun releaseWakeLock() {
        runCatching {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        }
        wakeLock = null
    }

    override fun onDestroy() {
        releaseWakeLock()
        serviceScope.cancel()
        super.onDestroy()
    }

    companion object {
        const val NOTIFICATION_ID = 4401
        const val ACTION_START_QUEUE = "com.example.action.START_UPLOAD_QUEUE"
        const val ACTION_PAUSE_CURRENT = "com.example.action.PAUSE_UPLOAD"
        const val ACTION_CANCEL_CURRENT = "com.example.action.CANCEL_UPLOAD"
        const val EXTRA_TASK_ID = "extra_task_id"

        fun startQueue(context: Context) {
            val intent = Intent(context, ClodyUploadService::class.java).apply {
                action = ACTION_START_QUEUE
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }
}

fun formatSpeed(bytesPerSec: Long): String {
    return when {
        bytesPerSec >= 1024L * 1024L -> String.format("%.1f MB/s", bytesPerSec / (1024.0 * 1024.0))
        bytesPerSec >= 1024L -> String.format("%.0f KB/s", bytesPerSec / 1024.0)
        else -> "$bytesPerSec B/s"
    }
}
