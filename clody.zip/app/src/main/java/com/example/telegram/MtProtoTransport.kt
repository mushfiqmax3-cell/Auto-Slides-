package com.example.telegram

import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import okio.ByteString.Companion.toByteString
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.EOFException
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

data class TelegramDcEndpoint(
    val dcId: Int,
    val ip: String,
    val port: Int = 443,
    val wsUrl: String
)

object TelegramDatacenters {
    val endpoints = mapOf(
        1 to TelegramDcEndpoint(1, "149.154.175.53", 443, "wss://pluto.web.telegram.org/apiws"),
        2 to TelegramDcEndpoint(2, "149.154.167.51", 443, "wss://venus.web.telegram.org/apiws"),
        3 to TelegramDcEndpoint(3, "149.154.175.100", 443, "wss://aurora.web.telegram.org/apiws"),
        4 to TelegramDcEndpoint(4, "149.154.167.91", 443, "wss://vesta.web.telegram.org/apiws"),
        5 to TelegramDcEndpoint(5, "91.108.56.130", 443, "wss://flora.web.telegram.org/apiws")
    )

    fun forDc(dcId: Int): TelegramDcEndpoint = endpoints[dcId] ?: endpoints.getValue(2)
}

interface MtProtoTransport {
    val isConnected: Boolean
    suspend fun connect()
    suspend fun sendFrame(payload: ByteArray)
    suspend fun receiveFrame(): ByteArray
    fun close()
}

/**
 * Direct TCP MTProto Intermediate Transport (0xeeeeeeee header + 4-byte LE length framing).
 */
class TcpIntermediateTransport(
    private val endpoint: TelegramDcEndpoint
) : MtProtoTransport {

    private var socket: Socket? = null
    private var input: BufferedInputStream? = null
    private var output: BufferedOutputStream? = null

    @Volatile
    override var isConnected: Boolean = false
        private set

    override suspend fun connect() = withContext(Dispatchers.IO) {
        close()
        val s = Socket()
        s.tcpNoDelay = true
        s.soTimeout = 45_000
        s.connect(InetSocketAddress(endpoint.ip, endpoint.port), 12_000)
        val out = BufferedOutputStream(s.getOutputStream())
        val inp = BufferedInputStream(s.getInputStream())
        // Intermediate transport tag: 0xeeeeeeee
        out.write(byteArrayOf(0xEE.toByte(), 0xEE.toByte(), 0xEE.toByte(), 0xEE.toByte()))
        out.flush()
        socket = s
        output = out
        input = inp
        isConnected = true
    }

    override suspend fun sendFrame(payload: ByteArray) = withContext(Dispatchers.IO) {
        val out = output ?: throw IOException("TCP transport is not connected")
        synchronized(out) {
            val lenBytes = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(payload.size).array()
            out.write(lenBytes)
            out.write(payload)
            out.flush()
        }
    }

    override suspend fun receiveFrame(): ByteArray = withContext(Dispatchers.IO) {
        val inp = input ?: throw IOException("TCP transport is not connected")
        val lenBuf = readExact(inp, 4)
        val len = ByteBuffer.wrap(lenBuf).order(ByteOrder.LITTLE_ENDIAN).int
        if (len < 0 || len > 32 * 1024 * 1024) {
            throw IOException("Invalid MTProto frame length: $len")
        }
        readExact(inp, len)
    }

    private fun readExact(inp: BufferedInputStream, count: Int): ByteArray {
        val buf = ByteArray(count)
        var offset = 0
        while (offset < count) {
            val read = inp.read(buf, offset, count - offset)
            if (read == -1) throw EOFException("Telegram server closed TCP connection")
            offset += read
        }
        return buf
    }

    override fun close() {
        isConnected = false
        runCatching { socket?.close() }
        socket = null
        input = null
        output = null
    }
}

/**
 * WebSocket MTProto Obfuscated2 Intermediate Transport (wss://dc.web.telegram.org/apiws).
 */
class WebSocketObfuscatedTransport(
    private val endpoint: TelegramDcEndpoint,
    private val okHttpClient: OkHttpClient
) : MtProtoTransport {

    private var webSocket: WebSocket? = null
    private var encryptCipher: Cipher? = null
    private var decryptCipher: Cipher? = null
    private val incomingQueue = LinkedBlockingQueue<Result<ByteArray>>()
    private var recvBuffer = ByteArray(0)

    @Volatile
    override var isConnected: Boolean = false
        private set

    override suspend fun connect() = withContext(Dispatchers.IO) {
        close()
        val openDeferred = CompletableDeferred<Unit>()
        val initPacket = buildObfuscated2InitPacket()

        val req = Request.Builder()
            .url(endpoint.wsUrl)
            .header("Sec-WebSocket-Protocol", "binary")
            .build()

        val ws = okHttpClient.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                webSocket.send(initPacket.toByteString())
                isConnected = true
                openDeferred.complete(Unit)
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                val dec = decryptCipher ?: return
                val decrypted = synchronized(dec) { dec.update(bytes.toByteArray()) }
                if (decrypted != null && decrypted.isNotEmpty()) {
                    incomingQueue.offer(Result.success(decrypted))
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                isConnected = false
                if (!openDeferred.isCompleted) {
                    openDeferred.completeExceptionally(t)
                }
                incomingQueue.offer(Result.failure(t))
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                isConnected = false
                incomingQueue.offer(Result.failure(EOFException("WebSocket closed ($code): $reason")))
            }
        })
        webSocket = ws
        openDeferred.await()
    }

    private fun buildObfuscated2InitPacket(): ByteArray {
        val random = MtProtoCrypto.randomBytes(64)
        while (true) {
            val firstByte = random[0].toInt() and 0xFF
            val firstInt = ByteBuffer.wrap(random, 0, 4).order(ByteOrder.LITTLE_ENDIAN).int
            val secondInt = ByteBuffer.wrap(random, 4, 4).order(ByteOrder.LITTLE_ENDIAN).int
            val forbidden = firstByte == 0xEF ||
                firstInt == 0x44414548 ||
                firstInt == 0x54534F50 ||
                firstInt == 0x20544547 ||
                firstInt == 0x4954504F ||
                firstInt == 0x02010316 ||
                firstInt == 0xEEEEEEEE.toInt() ||
                secondInt == 0x00000000
            if (!forbidden) break
            MtProtoCrypto.randomBytes(8).copyInto(random, 0)
        }
        // Set Intermediate transport protocol tag 0xeeeeeeee at offset 56..59
        random[56] = 0xEE.toByte()
        random[57] = 0xEE.toByte()
        random[58] = 0xEE.toByte()
        random[59] = 0xEE.toByte()
        // Set DC ID at offset 60..61
        random[60] = (endpoint.dcId and 0xFF).toByte()
        random[61] = ((endpoint.dcId shr 8) and 0xFF).toByte()

        val encKey = random.copyOfRange(8, 40)
        val encIv = random.copyOfRange(40, 56)
        val reversed = random.reversedArray()
        val decKey = reversed.copyOfRange(8, 40)
        val decIv = reversed.copyOfRange(40, 56)

        val enc = Cipher.getInstance("AES/CTR/NoPadding").apply {
            init(Cipher.ENCRYPT_MODE, SecretKeySpec(encKey, "AES"), IvParameterSpec(encIv))
        }
        val dec = Cipher.getInstance("AES/CTR/NoPadding").apply {
            init(Cipher.DECRYPT_MODE, SecretKeySpec(decKey, "AES"), IvParameterSpec(decIv))
        }
        encryptCipher = enc
        decryptCipher = dec

        val encryptedInit = enc.update(random) ?: ByteArray(64)
        val out = random.copyOf()
        System.arraycopy(encryptedInit, 56, out, 56, 8)
        return out
    }

    override suspend fun sendFrame(payload: ByteArray) = withContext(Dispatchers.IO) {
        val ws = webSocket ?: throw IOException("WebSocket is not connected")
        val enc = encryptCipher ?: throw IOException("Cipher not initialized")
        val lenBytes = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(payload.size).array()
        val packet = lenBytes + payload
        val encrypted = synchronized(enc) { enc.update(packet) ?: ByteArray(0) }
        if (!ws.send(encrypted.toByteString())) {
            throw IOException("Failed to enqueue WebSocket binary frame")
        }
    }

    override suspend fun receiveFrame(): ByteArray = withContext(Dispatchers.IO) {
        while (true) {
            if (recvBuffer.size >= 4) {
                val frameLen = ByteBuffer.wrap(recvBuffer, 0, 4).order(ByteOrder.LITTLE_ENDIAN).int
                if (frameLen < 0 || frameLen > 32 * 1024 * 1024) {
                    throw IOException("Invalid WebSocket MTProto frame length: $frameLen")
                }
                if (recvBuffer.size >= 4 + frameLen) {
                    val frame = recvBuffer.copyOfRange(4, 4 + frameLen)
                    recvBuffer = recvBuffer.copyOfRange(4 + frameLen, recvBuffer.size)
                    return@withContext frame
                }
            }
            val next = incomingQueue.poll(45, TimeUnit.SECONDS)
                ?: throw IOException("Timed out waiting for Telegram WebSocket packet")
            val chunk = next.getOrThrow()
            recvBuffer += chunk
        }
        @Suppress("UNREACHABLE_CODE")
        ByteArray(0)
    }

    override fun close() {
        isConnected = false
        runCatching { webSocket?.close(1000, "Client closed") }
        webSocket = null
        incomingQueue.clear()
        recvBuffer = ByteArray(0)
    }
}
