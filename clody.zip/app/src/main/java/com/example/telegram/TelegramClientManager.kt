package com.example.telegram

import android.content.Context
import com.example.data.local.ClodyDao
import com.example.data.local.FileEntity
import com.example.data.local.FolderEntity
import com.example.data.local.SecureStorage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.SecureRandom
import kotlin.math.ceil

sealed interface TelegramConnectionState {
    data class Disconnected(val reason: String? = null) : TelegramConnectionState
    data class Connecting(val dcId: Int) : TelegramConnectionState
    data class Connected(val dcId: Int, val userDisplayName: String?) : TelegramConnectionState
}

sealed interface TelegramAuthStep {
    data object NeedsCredentialsAndPhone : TelegramAuthStep
    data class AwaitingOtp(val phoneNumber: String, val phoneCodeHash: String) : TelegramAuthStep
    data class AwaitingPassword(val hint: String) : TelegramAuthStep
    data class Authorized(val displayName: String, val phoneNumber: String) : TelegramAuthStep
}

data class TelegramUserProfile(
    val userId: Long,
    val firstName: String,
    val lastName: String,
    val username: String?,
    val phoneNumber: String?,
    val avatarPath: String? = null
) {
    val fullName: String
        get() = listOf(firstName, lastName).filter { it.isNotBlank() }.joinToString(" ")
            .ifBlank { phoneNumber?.takeIf { it.isNotBlank() } ?: "Telegram User" }

    val handleOrPhone: String
        get() = when {
            !username.isNullOrBlank() -> "@$username"
            !phoneNumber.isNullOrBlank() -> phoneNumber
            else -> "Telegram Cloud"
        }

    val initials: String
        get() {
            val f = firstName.firstOrNull()?.uppercaseChar()
            val l = lastName.firstOrNull()?.uppercaseChar()
            return when {
                f != null && l != null -> "$f$l"
                f != null -> "$f"
                else -> "TG"
            }
        }
}

data class TelegramUploadedDocument(
    val messageId: Int,
    val documentId: Long,
    val accessHash: Long,
    val fileReference: ByteArray,
    val dcId: Int,
    val mimeType: String,
    val sizeBytes: Long
)

@Serializable
data class CloudIndexSnapshot(
    val version: Int = 1,
    val updatedAt: Long = System.currentTimeMillis(),
    val folders: List<FolderEntity> = emptyList(),
    val files: List<FileEntity> = emptyList()
)

class TelegramClientManager(
    private val context: Context,
    private val secureStorage: SecureStorage,
    private val dao: ClodyDao
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val sessionMutex = Mutex()
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val random = SecureRandom()

    private val sessions = mutableMapOf<Int, MtProtoSession>()
    private var activeDcId: Int = secureStorage.getActiveDc()
    private var initWrappedDc = mutableSetOf<Int>()

    private val _connectionState = MutableStateFlow<TelegramConnectionState>(
        TelegramConnectionState.Disconnected(null)
    )
    val connectionState: StateFlow<TelegramConnectionState> = _connectionState.asStateFlow()

    private val _authStep = MutableStateFlow<TelegramAuthStep>(
        if (secureStorage.isLoggedIn()) {
            TelegramAuthStep.Authorized(
                displayName = secureStorage.getUserDisplayName() ?: "Telegram User",
                phoneNumber = secureStorage.getPhoneNumber() ?: ""
            )
        } else {
            TelegramAuthStep.NeedsCredentialsAndPhone
        }
    )
    val authStep: StateFlow<TelegramAuthStep> = _authStep.asStateFlow()

    private val _userProfile = MutableStateFlow<TelegramUserProfile?>(
        if (secureStorage.isLoggedIn()) {
            TelegramUserProfile(
                userId = secureStorage.getUserId(),
                firstName = secureStorage.getFirstName().ifBlank { secureStorage.getUserDisplayName().orEmpty() },
                lastName = secureStorage.getLastName(),
                username = secureStorage.getUsername(),
                phoneNumber = secureStorage.getPhoneNumber(),
                avatarPath = secureStorage.getAvatarPath()
            )
        } else null
    )
    val userProfile: StateFlow<TelegramUserProfile?> = _userProfile.asStateFlow()

    private var pendingPhone: String = ""
    private var pendingPhoneCodeHash: String = ""

    init {
        if (secureStorage.isLoggedIn() && secureStorage.getApiId() != null) {
            scope.launch { reconnectIfAuthorized() }
        }
    }

    private fun getOrCreateSession(dcId: Int): MtProtoSession = synchronized(sessions) {
        sessions.getOrPut(dcId) { MtProtoSession(dcId, secureStorage) }
    }

    private suspend fun invokeOnActiveDc(query: ByteArray): ByteArray {
        val apiId = secureStorage.getApiId()
            ?: throw IllegalStateException("Telegram API ID is not configured")
        var currentDc = activeDcId
        repeat(3) {
            val session = getOrCreateSession(currentDc)
            val needsInit = !initWrappedDc.contains(currentDc)
            try {
                _connectionState.value = TelegramConnectionState.Connecting(currentDc)
                val res = session.invokeRpc(
                    query = query,
                    wrapWithLayerInit = needsInit,
                    apiId = apiId
                )
                initWrappedDc.add(currentDc)
                _connectionState.value = TelegramConnectionState.Connected(
                    dcId = currentDc,
                    userDisplayName = secureStorage.getUserDisplayName()
                )
                return res
            } catch (rpc: TelegramRpcException) {
                val targetDc = rpc.migrationDc()
                if (targetDc != null && targetDc != currentDc) {
                    currentDc = targetDc
                    activeDcId = targetDc
                    secureStorage.saveActiveDc(targetDc)
                    return@repeat
                }
                _connectionState.value = TelegramConnectionState.Connected(
                    dcId = currentDc,
                    userDisplayName = secureStorage.getUserDisplayName()
                )
                throw rpc
            } catch (e: Exception) {
                _connectionState.value = TelegramConnectionState.Disconnected(
                    e.message ?: "Network error"
                )
                throw e
            }
        }
        throw IllegalStateException("Exceeded Telegram DC migration attempts")
    }

    suspend fun reconnectIfAuthorized(): Result<Unit> = sessionMutex.withLock {
        val apiId = secureStorage.getApiId() ?: return Result.failure(IllegalStateException("Missing API ID"))
        if (!secureStorage.isLoggedIn()) return Result.failure(IllegalStateException("Not logged in"))
        return runCatching {
            withContext(Dispatchers.IO) {
                _connectionState.value = TelegramConnectionState.Connecting(activeDcId)
                // Lightweight getState#edd4882a or help.getNearestDc#1fb33026 to verify live connection
                val pingQuery = TlWriter(8).apply {
                    writeInt(0x1fb33026) // help.getNearestDc
                }.toByteArray()
                invokeOnActiveDc(pingQuery)
                ensureStorageChannelInternal()
                runCatching { fetchCurrentUserProfileInternal() }
                Unit
            }
        }.onFailure { err ->
            _connectionState.value = TelegramConnectionState.Disconnected(err.message ?: "Connection failed")
        }
    }

    /**
     * Step 1: Real Telegram auth.sendCode with zero mock fallbacks.
     */
    suspend fun connectAndSendCode(
        apiId: Int,
        apiHash: String,
        phoneNumber: String
    ): Result<String> = sessionMutex.withLock {
        val cleanHash = apiHash.trim()
        val cleanPhone = phoneNumber.trim()
        if (apiId <= 0) return Result.failure(IllegalArgumentException("API ID must be a positive number"))
        if (cleanHash.length < 16) return Result.failure(IllegalArgumentException("API Hash looks invalid"))
        if (!cleanPhone.startsWith("+") || cleanPhone.length < 8) {
            return Result.failure(IllegalArgumentException("Enter full phone number with country code (e.g. +8801...)"))
        }

        secureStorage.saveApiCredentials(apiId, cleanHash)
        secureStorage.savePhoneNumber(cleanPhone)

        return runCatching {
            withContext(Dispatchers.IO) {
                val query = TlWriter(128).apply {
                    writeInt(0xa677244f.toInt()) // auth.sendCode
                    writeString(cleanPhone)
                    writeInt(apiId)
                    writeString(cleanHash)
                    writeInt(0xad253d78.toInt()) // codeSettings
                    writeInt(0) // flags = 0
                }.toByteArray()

                val response = invokeOnActiveDc(query)
                val phoneCodeHash = parseSentCodeHash(response)
                pendingPhone = cleanPhone
                pendingPhoneCodeHash = phoneCodeHash
                _authStep.value = TelegramAuthStep.AwaitingOtp(cleanPhone, phoneCodeHash)
                phoneCodeHash
            }
        }.onFailure { err ->
            if (err !is TelegramRpcException) {
                _connectionState.value = TelegramConnectionState.Disconnected(err.message ?: "Network error")
            }
        }
    }

    /**
     * Step 2a: Real Telegram auth.signIn using 5-digit OTP code.
     */
    suspend fun verifyOtpCode(code: String): Result<Unit> = sessionMutex.withLock {
        val cleanCode = code.trim()
        if (cleanCode.isEmpty()) return Result.failure(IllegalArgumentException("Enter the verification code"))
        if (pendingPhoneCodeHash.isEmpty()) return Result.failure(IllegalStateException("Request a verification code first"))

        return runCatching {
            withContext(Dispatchers.IO) {
                val query = TlWriter(96).apply {
                    writeInt(0x8d52a951.toInt()) // auth.signIn
                    writeInt(1) // flags bit 0 = phone_code present
                    writeString(pendingPhone)
                    writeString(pendingPhoneCodeHash)
                    writeString(cleanCode)
                }.toByteArray()

                try {
                    val response = invokeOnActiveDc(query)
                    completeAuthorization(response, pendingPhone)
                } catch (rpc: TelegramRpcException) {
                    if (rpc.errorMessage == "SESSION_PASSWORD_NEEDED") {
                        val hint = fetchPasswordHint()
                        _authStep.value = TelegramAuthStep.AwaitingPassword(hint)
                        throw rpc
                    }
                    throw rpc
                }
            }
        }
    }

    private suspend fun fetchPasswordHint(): String {
        return runCatching {
            val query = TlWriter(4).apply { writeInt(0x548a30f5) }.toByteArray() // account.getPassword
            val res = invokeOnActiveDc(query)
            val parsed = parseAccountPassword(res)
            parsed.hint
        }.getOrDefault("")
    }

    /**
     * Step 2b: Real Telegram 2FA password verification via SRP.
     */
    suspend fun verifyTwoFactorPassword(password: String): Result<Unit> = sessionMutex.withLock {
        if (password.isEmpty()) return Result.failure(IllegalArgumentException("Enter your 2FA password"))

        return runCatching {
            withContext(Dispatchers.IO) {
                val getPwd = TlWriter(4).apply { writeInt(0x548a30f5) }.toByteArray()
                val pwdBytes = invokeOnActiveDc(getPwd)
                val info = parseAccountPassword(pwdBytes)

                val (bigA, m1) = MtProtoCrypto.computeSrpCheck(
                    password = password,
                    salt1 = info.salt1,
                    salt2 = info.salt2,
                    g = info.g,
                    pBytes = info.p,
                    srpBBytes = info.srpB
                )

                val checkQuery = TlWriter(380).apply {
                    writeInt(0xd18b4d16.toInt()) // auth.checkPassword
                    writeInt(0xd27ff082.toInt()) // inputCheckPasswordSRP
                    writeLong(info.srpId)
                    writeBytes(bigA)
                    writeBytes(m1)
                }.toByteArray()

                val authRes = invokeOnActiveDc(checkQuery)
                completeAuthorization(authRes, pendingPhone)
            }
        }
    }

    private suspend fun completeAuthorization(authBytes: ByteArray, phone: String) {
        val parsed = extractUserProfileFromBytes(authBytes, phone)
        val displayName = parsed?.fullName ?: extractDisplayNameFromAuthorization(authBytes).ifBlank { phone }
        if (parsed != null) {
            secureStorage.saveUserProfileDetails(
                userId = parsed.userId,
                firstName = parsed.firstName,
                lastName = parsed.lastName,
                username = parsed.username,
                phone = parsed.phoneNumber ?: phone
            )
            _userProfile.value = parsed
        } else {
            secureStorage.saveUserDisplayName(displayName)
            secureStorage.savePhoneNumber(phone)
            _userProfile.value = TelegramUserProfile(
                userId = secureStorage.getUserId(),
                firstName = displayName,
                lastName = "",
                username = null,
                phoneNumber = phone
            )
        }
        secureStorage.setLoggedIn(true)
        _connectionState.value = TelegramConnectionState.Connected(activeDcId, displayName)
        _authStep.value = TelegramAuthStep.Authorized(displayName, phone)
        ensureStorageChannelInternal()
        runCatching { fetchCurrentUserProfileInternal() }
    }

    /**
     * Fetches the authenticated user's profile via real Telegram MTProto users.getUsers([inputUserSelf]).
     */
    suspend fun fetchCurrentUserProfile(): Result<TelegramUserProfile?> = runCatching {
        withContext(Dispatchers.IO) { fetchCurrentUserProfileInternal() }
    }

    private suspend fun fetchCurrentUserProfileInternal(): TelegramUserProfile? {
        if (!secureStorage.isLoggedIn()) return null
        val query = TlWriter(24).apply {
            writeInt(0x0d91a548) // users.getUsers
            writeInt(TlHelpers.VECTOR_CTOR)
            writeInt(1)
            writeInt(0xf7c1b13f.toInt()) // inputUserSelf
        }.toByteArray()
        val res = invokeOnActiveDc(query)
        val fallbackPhone = secureStorage.getPhoneNumber()
        val parsed = extractUserProfileFromBytes(res, fallbackPhone) ?: return _userProfile.value
        secureStorage.saveUserProfileDetails(
            userId = parsed.userId,
            firstName = parsed.firstName,
            lastName = parsed.lastName,
            username = parsed.username,
            phone = parsed.phoneNumber ?: fallbackPhone
        )
        _userProfile.value = parsed
        _authStep.value = TelegramAuthStep.Authorized(parsed.fullName, parsed.phoneNumber ?: fallbackPhone.orEmpty())
        _connectionState.value = TelegramConnectionState.Connected(activeDcId, parsed.fullName)
        return parsed
    }

    /**
     * Finds or creates private "Clody Cloud Storage" channel; falls back to Saved Messages if restricted.
     */
    suspend fun ensureStorageChannel(): Result<Pair<Long, Long>> = sessionMutex.withLock {
        runCatching { ensureStorageChannelInternal() }
    }

    private suspend fun ensureStorageChannelInternal(): Pair<Long, Long> {
        val existingId = secureStorage.getStorageChannelId()
        val existingHash = secureStorage.getStorageChannelAccessHash()
        if (existingId != 0L) {
            return existingId to existingHash
        }

        // 1. Check dialogs for existing "Clody Cloud Storage"
        val found = runCatching { findClodyChannelInDialogs() }.getOrNull()
        if (found != null) {
            secureStorage.saveStorageChannel(found.first, found.second, isSelfChat = false)
            return found
        }

        // 2. Create private channel "Clody Cloud Storage"
        val created = runCatching {
            val query = TlWriter(128).apply {
                writeInt(0x91006707.toInt()) // channels.createChannel
                writeInt(1) // flags: broadcast = true (bit 0)
                writeString("Clody Cloud Storage")
                writeString("Private cloud storage managed by Clody")
            }.toByteArray()
            val res = invokeOnActiveDc(query)
            extractChannelFromUpdates(res)
        }.getOrNull()

        if (created != null) {
            secureStorage.saveStorageChannel(created.first, created.second, isSelfChat = false)
            return created
        }

        // 3. Fallback to Saved Messages (InputPeerSelf)
        secureStorage.saveStorageChannel(-1L, 0L, isSelfChat = true)
        return -1L to 0L
    }

    private suspend fun findClodyChannelInDialogs(): Pair<Long, Long>? {
        val query = TlWriter(64).apply {
            writeInt(0xa0f4cb4f.toInt()) // messages.getDialogs
            writeInt(0) // flags
            writeInt(0) // offset_date
            writeInt(0) // offset_id
            writeInt(0x7f3b18ea) // inputPeerEmpty
            writeInt(40) // limit
            writeLong(0L) // hash
        }.toByteArray()
        val res = invokeOnActiveDc(query)
        return scanBytesForChannelTitled(res, "Clody Cloud Storage")
    }

    private fun writeStorageInputPeer(writer: TlWriter) {
        if (secureStorage.isStorageSelfChat() || secureStorage.getStorageChannelId() <= 0L) {
            writer.writeInt(0x7da07ec9) // inputPeerSelf
        } else {
            writer.writeInt(0x27bcbbfc) // inputPeerChannel
            writer.writeLong(secureStorage.getStorageChannelId())
            writer.writeLong(secureStorage.getStorageChannelAccessHash())
        }
    }

    /**
     * Uploads a real local file to the private Telegram storage channel in 512KB parts,
     * with optional compressed preview thumbnail and live progress callback.
     */
    suspend fun uploadFile(
        file: File,
        fileName: String,
        mimeType: String,
        thumbnailFile: File?,
        isVideo: Boolean,
        durationSec: Double,
        onProgress: suspend (bytesSent: Long, speedBytesPerSec: Long) -> Unit
    ): Result<TelegramUploadedDocument> = runCatching {
        withContext(Dispatchers.IO) {
            ensureStorageChannelInternal()

            val totalBytes = file.length()
            val partSize = 512 * 1024 // 512 KB (divisible by 1024 per MTProto spec)
            val isBig = totalBytes > 10L * 1024L * 1024L
            val totalParts = maxOf(1, ceil(totalBytes.toDouble() / partSize).toInt())
            val tgFileId = random.nextLong()

            var uploaded = 0L
            val startTime = System.currentTimeMillis()
            FileInputStream(file).use { fis ->
                val buffer = ByteArray(partSize)
                for (partIndex in 0 until totalParts) {
                    val read = readFullChunk(fis, buffer)
                    if (read <= 0) break
                    val chunk = if (read == buffer.size) buffer else buffer.copyOf(read)

                    val partQuery = if (isBig) {
                        TlWriter(32 + chunk.size).apply {
                            writeInt(0xde7b673d.toInt()) // upload.saveBigFilePart
                            writeLong(tgFileId)
                            writeInt(partIndex)
                            writeInt(totalParts)
                            writeBytes(chunk)
                        }.toByteArray()
                    } else {
                        TlWriter(24 + chunk.size).apply {
                            writeInt(0xb304a621.toInt()) // upload.saveFilePart
                            writeLong(tgFileId)
                            writeInt(partIndex)
                            writeBytes(chunk)
                        }.toByteArray()
                    }
                    invokeOnActiveDc(partQuery)
                    uploaded += chunk.size
                    val elapsedSec = maxOf(0.1, (System.currentTimeMillis() - startTime) / 1000.0)
                    val speed = (uploaded / elapsedSec).toLong()
                    onProgress(uploaded, speed)
                }
            }

            // Optional thumbnail upload (< 200 KB)
            var thumbInputFileId: Long? = null
            var thumbParts = 0
            if (thumbnailFile != null && thumbnailFile.exists() && thumbnailFile.length() > 0L) {
                val thumbBytes = thumbnailFile.readBytes()
                val tId = random.nextLong()
                val tQuery = TlWriter(24 + thumbBytes.size).apply {
                    writeInt(0xb304a621.toInt()) // upload.saveFilePart
                    writeLong(tId)
                    writeInt(0)
                    writeBytes(thumbBytes)
                }.toByteArray()
                invokeOnActiveDc(tQuery)
                thumbInputFileId = tId
                thumbParts = 1
            }

            val sendQuery = TlWriter(512).apply {
                writeInt(0x0330e77f) // messages.sendMedia
                writeInt(0) // flags
                writeStorageInputPeer(this)
                // media: inputMediaUploadedDocument#037c9330
                writeInt(0x037c9330)
                var mediaFlags = 0
                if (thumbInputFileId != null) mediaFlags = mediaFlags or (1 shl 2) // thumb present
                if (!isVideo) mediaFlags = mediaFlags or (1 shl 4) // force_file for non-video docs
                writeInt(mediaFlags)
                // file: InputFile
                if (isBig) {
                    writeInt(0xfa4f0bb5.toInt()) // inputFileBig
                    writeLong(tgFileId)
                    writeInt(totalParts)
                    writeString(fileName)
                } else {
                    writeInt(0xf52ff27f.toInt()) // inputFile
                    writeLong(tgFileId)
                    writeInt(totalParts)
                    writeString(fileName)
                    writeString("") // md5_checksum optional empty
                }
                // thumb: InputFile?
                if (thumbInputFileId != null) {
                    writeInt(0xf52ff27f.toInt())
                    writeLong(thumbInputFileId)
                    writeInt(thumbParts)
                    writeString("thumb.jpg")
                    writeString("")
                }
                writeString(mimeType)
                // attributes Vector<DocumentAttribute>
                writeInt(TlHelpers.VECTOR_CTOR)
                if (isVideo) {
                    writeInt(2)
                    writeInt(0x43c57c48) // documentAttributeVideo
                    writeInt(1 shl 1) // supports_streaming = true
                    writeLong(java.lang.Double.doubleToRawLongBits(durationSec))
                    writeInt(1280)
                    writeInt(720)
                    writeInt(0x15590068) // documentAttributeFilename
                    writeString(fileName)
                } else {
                    writeInt(1)
                    writeInt(0x15590068) // documentAttributeFilename
                    writeString(fileName)
                }
                writeString("Clody Cloud Backup: $fileName")
                writeLong(random.nextLong()) // random_id
            }.toByteArray()

            val updatesBytes = invokeOnActiveDc(sendQuery)
            parseUploadedDocumentFromUpdates(updatesBytes, mimeType, totalBytes)
        }
    }

    /**
     * Progressive byte-range chunk download from Telegram using upload.getFile#be5335be.
     * Supports FILE_MIGRATE_X seamlessly.
     */
    suspend fun downloadChunk(
        dcId: Int,
        documentId: Long,
        accessHash: Long,
        fileReference: ByteArray,
        offset: Long,
        limit: Int
    ): ByteArray = withContext(Dispatchers.IO) {
        // Alignment required by Telegram: offset % 4096 == 0, limit power of 2 <= 1048576
        val alignedOffset = (offset / 4096L) * 4096L
        val alignedLimit = when {
            limit <= 4096 -> 4096
            limit <= 16384 -> 16384
            limit <= 65536 -> 65536
            limit <= 262144 -> 262144
            limit <= 524288 -> 524288
            else -> 1048576
        }

        val apiId = secureStorage.getApiId() ?: 0
        var targetDc = if (dcId in 1..5) dcId else activeDcId
        repeat(3) {
            val session = getOrCreateSession(targetDc)
            val needsInit = !initWrappedDc.contains(targetDc)
            val query = TlWriter(128).apply {
                writeInt(0xbe5335be.toInt()) // upload.getFile
                writeInt(1) // precise = true
                writeInt(0xbad07584.toInt()) // inputDocumentFileLocation
                writeLong(documentId)
                writeLong(accessHash)
                writeBytes(fileReference)
                writeString("") // thumb_size
                writeLong(alignedOffset)
                writeInt(alignedLimit)
            }.toByteArray()

            try {
                val res = session.invokeRpc(query, wrapWithLayerInit = needsInit, apiId = apiId)
                initWrappedDc.add(targetDc)
                val reader = TlReader(res)
                val ctor = reader.readInt()
                if (ctor == 0x096a18d5) { // upload.file
                    reader.readInt() // storage.FileType constructor
                    reader.readInt() // mtime
                    val bytes = reader.readBytes()
                    val delta = (offset - alignedOffset).toInt()
                    return@withContext if (delta > 0 && delta < bytes.size) {
                        bytes.copyOfRange(delta, bytes.size)
                    } else {
                        bytes
                    }
                }
                throw IllegalStateException("Unexpected upload.getFile response ctor 0x${ctor.toUInt().toString(16)}")
            } catch (rpc: TelegramRpcException) {
                val migrated = rpc.migrationDc()
                if (migrated != null && migrated != targetDc) {
                    targetDc = migrated
                    return@repeat
                }
                throw rpc
            }
        }
        ByteArray(0)
    }

    /**
     * Pushes clody_index.json to the private Telegram storage channel so folder trees sync across devices.
     */
    suspend fun pushCloudIndexSnapshot(): Result<Unit> = runCatching {
        withContext(Dispatchers.IO) {
            if (!secureStorage.isLoggedIn()) return@withContext
            val folders = dao.getAllFoldersOnce()
            val files = dao.getAllActiveFilesOnce()
            val snapshot = CloudIndexSnapshot(folders = folders, files = files)
            val jsonText = json.encodeToString(snapshot)
            val indexFile = File(context.cacheDir, "clody_index.json").apply {
                writeText(jsonText, Charsets.UTF_8)
            }
            val uploaded = uploadFile(
                file = indexFile,
                fileName = "clody_index.json",
                mimeType = "application/json",
                thumbnailFile = null,
                isVideo = false,
                durationSec = 0.0,
                onProgress = { _, _ -> }
            ).getOrThrow()

            if (uploaded.messageId > 0) {
                secureStorage.saveIndexMessageId(uploaded.messageId)
                runCatching {
                    val pinQuery = TlWriter(48).apply {
                        writeInt(0xd2aaf7ec.toInt()) // messages.updatePinnedMessage
                        writeInt(1) // silent = true
                        writeStorageInputPeer(this)
                        writeInt(uploaded.messageId)
                    }.toByteArray()
                    invokeOnActiveDc(pinQuery)
                }
            }
        }
    }

    /**
     * Fetches recent channel history from Telegram and restores any missing clody_index.json items.
     */
    suspend fun syncFromTelegramChannel(): Result<Int> = runCatching {
        withContext(Dispatchers.IO) {
            ensureStorageChannelInternal()
            val query = TlWriter(64).apply {
                writeInt(0x4423e6c5) // messages.getHistory
                writeStorageInputPeer(this)
                writeInt(0) // offset_id
                writeInt(0) // offset_date
                writeInt(0) // add_offset
                writeInt(50) // limit
                writeInt(0) // max_id
                writeInt(0) // min_id
                writeLong(0L) // hash
            }.toByteArray()

            val res = invokeOnActiveDc(query)
            val docs = scanMessagesForDocuments(res)
            var restored = 0
            // Check if clody_index.json is present
            val indexDoc = docs.firstOrNull { it.first == "clody_index.json" }
            if (indexDoc != null) {
                val doc = indexDoc.second
                val indexBytes = downloadChunk(
                    dcId = doc.dcId,
                    documentId = doc.documentId,
                    accessHash = doc.accessHash,
                    fileReference = doc.fileReference,
                    offset = 0L,
                    limit = 524288
                )
                runCatching {
                    val snapshot = json.decodeFromString<CloudIndexSnapshot>(String(indexBytes, Charsets.UTF_8))
                    if (snapshot.folders.isNotEmpty()) dao.insertFolders(snapshot.folders)
                    for (f in snapshot.files) {
                        if (dao.getFileByMessageId(f.telegramMessageId) == null) {
                            dao.insertFile(f.copy(id = 0, localCachePath = null, thumbnailPath = null))
                            restored++
                        }
                    }
                }
            }
            restored
        }
    }

    suspend fun logout(): Result<Unit> = sessionMutex.withLock {
        runCatching {
            withContext(Dispatchers.IO) {
                runCatching {
                    val query = TlWriter(4).apply { writeInt(0x3e72ba19) }.toByteArray() // auth.logOut
                    invokeOnActiveDc(query)
                }
                synchronized(sessions) {
                    sessions.values.forEach { it.close() }
                    sessions.clear()
                }
                initWrappedDc.clear()
                secureStorage.clearSessionOnly()
                _userProfile.value = null
                _connectionState.value = TelegramConnectionState.Disconnected(null)
                _authStep.value = TelegramAuthStep.NeedsCredentialsAndPhone
            }
        }
    }

    // --- Resilient TL Parsing Helpers ---

    private fun parseSentCodeHash(bytes: ByteArray): String {
        val reader = TlReader(bytes)
        val ctor = reader.readInt()
        if (ctor == 0x5e002502) { // auth.sentCode
            reader.readInt() // flags
            // skip SentCodeType (ctor + int length usually, or email/fragment patterns)
            val typeCtor = reader.readInt()
            when (typeCtor) {
                0x3dbb5986, 0xc000bba2.toInt(), 0x5353e5a7, 0x82006484.toInt() -> reader.readInt()
                else -> {
                    // Fallback scan for ASCII hex phone_code_hash string
                    return findAsciiHashString(bytes)
                }
            }
            return reader.readString()
        }
        return findAsciiHashString(bytes)
    }

    private fun findAsciiHashString(bytes: ByteArray): String {
        val text = String(bytes, Charsets.ISO_8859_1)
        val match = Regex("[0-9a-f]{12,32}").find(text)
        return match?.value ?: throw IllegalStateException("Unable to extract phone_code_hash from Telegram response")
    }

    private data class AccountPasswordInfo(
        val hint: String,
        val salt1: ByteArray,
        val salt2: ByteArray,
        val g: Int,
        val p: ByteArray,
        val srpB: ByteArray,
        val srpId: Long
    )

    private fun parseAccountPassword(bytes: ByteArray): AccountPasswordInfo {
        val reader = TlReader(bytes)
        val ctor = reader.readInt()
        if (ctor != 0x957b50fb.toInt()) {
            throw IllegalStateException("Unexpected account.password ctor: 0x${ctor.toUInt().toString(16)}")
        }
        val flags = reader.readInt()
        // Skip current_algo (PasswordKdfAlgo)
        val algoCtor = reader.readInt()
        var salt1 = ByteArray(0)
        var salt2 = ByteArray(0)
        var g = 0
        var p = ByteArray(0)
        if (algoCtor == 0x3a912d4a) { // passwordKdfAlgoSHA256SHA256PBKDF2HMACSHA512iter100000SHA256ModPow
            salt1 = reader.readBytes()
            salt2 = reader.readBytes()
            g = reader.readInt()
            p = reader.readBytes()
        }
        val srpB = if ((flags and (1 shl 2)) != 0) reader.readBytes() else ByteArray(0)
        val srpId = if ((flags and (1 shl 2)) != 0) reader.readLong() else 0L
        val hint = if ((flags and (1 shl 3)) != 0) reader.readString() else ""
        return AccountPasswordInfo(hint, salt1, salt2, g, p, srpB, srpId)
    }

    private fun extractUserProfileFromBytes(bytes: ByteArray, fallbackPhone: String?): TelegramUserProfile? {
        for (i in 0 until bytes.size - 20) {
            val valInt = ByteBuffer.wrap(bytes, i, 4).order(ByteOrder.LITTLE_ENDIAN).int
            if (valInt == 0x20b1422 || valInt == 0x215c4438 || valInt == 0x83314fca.toInt() || valInt == 0xeb602f25.toInt()) {
                val parsed = runCatching {
                    val r = TlReader(bytes, i + 4)
                    val flags = r.readInt()
                    r.readInt() // flags2
                    val id = r.readLong()
                    if ((flags and (1 shl 0)) != 0) r.readLong() // access_hash
                    val first = if ((flags and (1 shl 1)) != 0) r.readString() else ""
                    val last = if ((flags and (1 shl 2)) != 0) r.readString() else ""
                    val username = if ((flags and (1 shl 3)) != 0) r.readString().takeIf { it.isNotBlank() } else null
                    val phone = if ((flags and (1 shl 4)) != 0) r.readString().takeIf { it.isNotBlank() } else fallbackPhone
                    TelegramUserProfile(
                        userId = id,
                        firstName = first,
                        lastName = last,
                        username = username,
                        phoneNumber = phone?.let { if (it.startsWith("+")) it else "+$it" }
                    )
                }.getOrNull()
                if (parsed != null && parsed.userId > 0L) return parsed
            }
        }
        return null
    }

    private fun extractDisplayNameFromAuthorization(bytes: ByteArray): String {
        return extractUserProfileFromBytes(bytes, null)?.fullName.orEmpty()
    }

    private fun scanBytesForChannelTitled(bytes: ByteArray, title: String): Pair<Long, Long>? {
        val target = title.toByteArray(Charsets.UTF_8)
        for (i in 0 until bytes.size - 32) {
            val ctor = ByteBuffer.wrap(bytes, i, 4).order(ByteOrder.LITTLE_ENDIAN).int
            // Match modern channel constructors (0x1981ea7e, 0x0aadfc8f, 0x83259464)
            if (ctor == 0x1981ea7e || ctor == 0x0aadfc8f || ctor == 0x83259464.toInt()) {
                runCatching {
                    val r = TlReader(bytes, i + 4)
                    val flags = r.readInt()
                    val id = r.readLong()
                    val accessHash = if ((flags and (1 shl 13)) != 0) r.readLong() else 0L
                    val chTitle = r.readString()
                    if (chTitle == title && accessHash != 0L) {
                        return id to accessHash
                    }
                }
            }
        }
        // Secondary byte search if constructor ID evolved
        val idx = bytes.indexOfSequence(target)
        if (idx > 20) {
            // Try reading id/accessHash immediately preceding title
            val id = ByteBuffer.wrap(bytes, idx - 17, 8).order(ByteOrder.LITTLE_ENDIAN).long
            val accessHash = ByteBuffer.wrap(bytes, idx - 9, 8).order(ByteOrder.LITTLE_ENDIAN).long
            if (id > 0 && accessHash != 0L) return id to accessHash
        }
        return null
    }

    private fun extractChannelFromUpdates(bytes: ByteArray): Pair<Long, Long>? {
        for (i in 0 until bytes.size - 24) {
            val ctor = ByteBuffer.wrap(bytes, i, 4).order(ByteOrder.LITTLE_ENDIAN).int
            if (ctor == 0x1981ea7e || ctor == 0x0aadfc8f || ctor == 0x83259464.toInt()) {
                val res = runCatching {
                    val r = TlReader(bytes, i + 4)
                    val flags = r.readInt()
                    val id = r.readLong()
                    val accessHash = if ((flags and (1 shl 13)) != 0) r.readLong() else 0L
                    id to accessHash
                }.getOrNull()
                if (res != null && res.first > 0L && res.second != 0L) return res
            }
        }
        return null
    }

    private fun parseUploadedDocumentFromUpdates(
        bytes: ByteArray,
        mimeType: String,
        sizeBytes: Long
    ): TelegramUploadedDocument {
        var msgId = 0
        for (i in 0 until bytes.size - 16) {
            val ctor = ByteBuffer.wrap(bytes, i, 4).order(ByteOrder.LITTLE_ENDIAN).int
            if (ctor == 0x4e90bfd6) { // updateMessageID
                msgId = ByteBuffer.wrap(bytes, i + 4, 4).order(ByteOrder.LITTLE_ENDIAN).int
                break
            }
        }
        for (i in 0 until bytes.size - 40) {
            val ctor = ByteBuffer.wrap(bytes, i, 4).order(ByteOrder.LITTLE_ENDIAN).int
            if (ctor == 0x8fd4c4d8.toInt()) { // document#8fd4c4d8
                val parsed = runCatching {
                    val r = TlReader(bytes, i + 4)
                    r.readInt() // flags
                    val docId = r.readLong()
                    val accessHash = r.readLong()
                    val fileRef = r.readBytes()
                    r.readInt() // date
                    val mime = r.readString()
                    val size = r.readLong()
                    // Skip thumbs/video_thumbs if any — fallback to activeDcId
                    TelegramUploadedDocument(
                        messageId = msgId,
                        documentId = docId,
                        accessHash = accessHash,
                        fileReference = fileRef,
                        dcId = activeDcId,
                        mimeType = mime,
                        sizeBytes = size
                    )
                }.getOrNull()
                if (parsed != null) return parsed
            }
        }
        return TelegramUploadedDocument(
            messageId = msgId,
            documentId = 0L,
            accessHash = 0L,
            fileReference = ByteArray(0),
            dcId = activeDcId,
            mimeType = mimeType,
            sizeBytes = sizeBytes
        )
    }

    private fun scanMessagesForDocuments(bytes: ByteArray): List<Pair<String, TelegramUploadedDocument>> {
        val list = mutableListOf<Pair<String, TelegramUploadedDocument>>()
        for (i in 0 until bytes.size - 40) {
            val ctor = ByteBuffer.wrap(bytes, i, 4).order(ByteOrder.LITTLE_ENDIAN).int
            if (ctor == 0x8fd4c4d8.toInt()) {
                runCatching {
                    val r = TlReader(bytes, i + 4)
                    r.readInt() // flags
                    val docId = r.readLong()
                    val accessHash = r.readLong()
                    val fileRef = r.readBytes()
                    r.readInt() // date
                    val mime = r.readString()
                    val size = r.readLong()
                    // Look ahead briefly for documentAttributeFilename#15590068
                    var fileName = ""
                    val lookAheadEnd = minOf(bytes.size - 8, r.position + 512)
                    for (j in r.position until lookAheadEnd) {
                        if (ByteBuffer.wrap(bytes, j, 4).order(ByteOrder.LITTLE_ENDIAN).int == 0x15590068) {
                            fileName = TlReader(bytes, j + 4).readString()
                            break
                        }
                    }
                    list += fileName to TelegramUploadedDocument(
                        messageId = 0,
                        documentId = docId,
                        accessHash = accessHash,
                        fileReference = fileRef,
                        dcId = activeDcId,
                        mimeType = mime,
                        sizeBytes = size
                    )
                }
            }
        }
        return list
    }

    private fun readFullChunk(fis: FileInputStream, buffer: ByteArray): Int {
        var total = 0
        while (total < buffer.size) {
            val r = fis.read(buffer, total, buffer.size - total)
            if (r == -1) break
            total += r
        }
        return total
    }

    private fun ByteArray.indexOfSequence(target: ByteArray): Int {
        if (target.isEmpty() || size < target.size) return -1
        outer@ for (i in 0..(size - target.size)) {
            for (j in target.indices) {
                if (this[i + j] != target[j]) continue@outer
            }
            return i
        }
        return -1
    }
}
