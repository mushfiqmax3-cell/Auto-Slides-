package com.example.telegram

import com.example.data.local.SecureStorage
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import okhttp3.OkHttpClient
import java.io.IOException
import java.math.BigInteger
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

class TelegramRpcException(
    val errorCode: Int,
    val errorMessage: String
) : Exception("$errorMessage (code $errorCode)") {

    fun migrationDc(): Int? {
        val prefixes = listOf("PHONE_MIGRATE_", "NETWORK_MIGRATE_", "FILE_MIGRATE_", "USER_MIGRATE_")
        for (prefix in prefixes) {
            if (errorMessage.startsWith(prefix)) {
                return errorMessage.removePrefix(prefix).toIntOrNull()
            }
        }
        return null
    }

    fun floodWaitSeconds(): Int? {
        return if (errorMessage.startsWith("FLOOD_WAIT_")) {
            errorMessage.removePrefix("FLOOD_WAIT_").toIntOrNull()
        } else null
    }
}

class MtProtoSession(
    val dcId: Int,
    private val secureStorage: SecureStorage,
    private val okHttpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .build()
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val connectMutex = Mutex()
    private val sendMutex = Mutex()
    private val pendingRpc = ConcurrentHashMap<Long, CompletableDeferred<ByteArray>>()
    private val seqNoCounter = AtomicInteger(0)

    private var transport: MtProtoTransport? = null
    private var readerJob: Job? = null

    private var authKey: ByteArray? = secureStorage.getDcAuthKey(dcId)
    private var authKeyId: Long = authKey?.let { computeAuthKeyId(it) } ?: 0L
    private var serverSalt: Long = secureStorage.getDcSalt(dcId)
    private var timeOffset: Int = secureStorage.getDcTimeOffset(dcId)
    private var sessionId: Long = ByteBuffer.wrap(MtProtoCrypto.randomBytes(8)).order(ByteOrder.LITTLE_ENDIAN).long
    private var lastMsgId: Long = 0L

    val isConnected: Boolean
        get() = transport?.isConnected == true && authKey != null

    private fun computeAuthKeyId(key: ByteArray): Long {
        val hash = MtProtoCrypto.sha1(key)
        return TlReader(hash, hash.size - 8).readLong()
    }

    @Synchronized
    private fun nextMsgId(): Long {
        val unixSec = (System.currentTimeMillis() / 1000L) + timeOffset
        val millisPart = System.currentTimeMillis() % 1000L
        var msgId = (unixSec shl 32) or ((millisPart shl 22) and 0xFFFFFFFC)
        msgId = msgId and 0xFFFFFFFFFFFFFFFCuL.toLong()
        if (msgId <= lastMsgId) {
            msgId = lastMsgId + 4L
        }
        lastMsgId = msgId
        return msgId
    }

    private fun nextSeqNo(contentRelated: Boolean): Int {
        return if (contentRelated) {
            seqNoCounter.getAndAdd(1) * 2 + 1
        } else {
            seqNoCounter.get() * 2
        }
    }

    suspend fun ensureConnected(): Unit = connectMutex.withLock {
        if (isConnected) return@withLock

        val endpoint = TelegramDatacenters.forDc(dcId)
        val t = try {
            TcpIntermediateTransport(endpoint).also { it.connect() }
        } catch (tcpEx: Exception) {
            try {
                WebSocketObfuscatedTransport(endpoint, okHttpClient).also { it.connect() }
            } catch (wsEx: Exception) {
                throw IOException(
                    "Unable to reach Telegram DC$dcId (${tcpEx.message ?: wsEx.message})",
                    tcpEx
                )
            }
        }
        transport = t

        if (authKey == null) {
            performDhHandshake(t)
        }

        startReaderLoop(t)
    }

    private suspend fun sendUnencrypted(t: MtProtoTransport, body: ByteArray) {
        val msgId = nextMsgId()
        val writer = TlWriter(20 + body.size)
        writer.writeLong(0L) // auth_key_id = 0
        writer.writeLong(msgId)
        writer.writeInt(body.size)
        writer.writeRaw(body)
        t.sendFrame(writer.toByteArray())
    }

    private suspend fun receiveUnencrypted(t: MtProtoTransport): ByteArray {
        val frame = t.receiveFrame()
        if (frame.size < 20) {
            if (frame.size == 4) {
                val err = ByteBuffer.wrap(frame).order(ByteOrder.LITTLE_ENDIAN).int
                throw IOException("Telegram transport error code: $err")
            }
            throw IOException("Malformed unencrypted MTProto response (${frame.size} bytes)")
        }
        val reader = TlReader(frame)
        val keyId = reader.readLong()
        if (keyId != 0L) throw IOException("Expected unencrypted response, got authKeyId=$keyId")
        reader.readLong() // msgId
        val len = reader.readInt()
        return reader.readRaw(len)
    }

    private suspend fun performDhHandshake(t: MtProtoTransport) {
        val nonce = MtProtoCrypto.randomBytes(16)

        // 1. req_pq_multi#be7e8ef1
        val reqPq = TlWriter(20).apply {
            writeInt(0xbe7e8ef1.toInt())
            writeInt128(nonce)
        }.toByteArray()
        sendUnencrypted(t, reqPq)

        val resPqBytes = receiveUnencrypted(t)
        val resPqReader = TlReader(resPqBytes)
        val resPqCtor = resPqReader.readInt()
        if (resPqCtor != 0x05162463) {
            throw IOException("Expected resPQ (0x05162463), got 0x${resPqCtor.toUInt().toString(16)}")
        }
        val respNonce = resPqReader.readInt128()
        if (!respNonce.contentEquals(nonce)) throw IOException("resPQ nonce mismatch")
        val serverNonce = resPqReader.readInt128()
        val pqBytes = resPqReader.readBytes()
        val vecCtor = resPqReader.readInt()
        if (vecCtor != TlHelpers.VECTOR_CTOR) throw IOException("Expected Vector in resPQ")
        val fpCount = resPqReader.readInt()
        val serverFingerprints = List(fpCount) { resPqReader.readLong() }

        val matchedKey = MtProtoCrypto.OFFICIAL_TELEGRAM_KEYS.firstOrNull { key ->
            serverFingerprints.contains(key.fingerprint)
        } ?: MtProtoCrypto.OFFICIAL_TELEGRAM_KEYS.firstOrNull()
            ?: throw IOException("No matching Telegram RSA public key found")

        // 2. Factorize PQ and prepare p_q_inner_data_dc#a9f55f95
        val (pLong, qLong) = MtProtoCrypto.factorizePQ(pqBytes)
        val pBytes = BigInteger.valueOf(pLong).toByteArray().let {
            if (it.size > 1 && it[0] == 0.toByte()) it.copyOfRange(1, it.size) else it
        }
        val qBytes = BigInteger.valueOf(qLong).toByteArray().let {
            if (it.size > 1 && it[0] == 0.toByte()) it.copyOfRange(1, it.size) else it
        }

        val newNonce = MtProtoCrypto.randomBytes(32)
        val pqInner = TlWriter(160).apply {
            writeInt(0xa9f55f95.toInt()) // p_q_inner_data_dc
            writeBytes(pqBytes)
            writeBytes(pBytes)
            writeBytes(qBytes)
            writeInt128(nonce)
            writeInt128(serverNonce)
            writeInt256(newNonce)
            writeInt(dcId)
        }.toByteArray()

        val encryptedData = MtProtoCrypto.rsaPadEncrypt256(pqInner, matchedKey)

        // 3. req_DH_params#d712e4be
        val reqDh = TlWriter(320).apply {
            writeInt(0xd712e4be.toInt())
            writeInt128(nonce)
            writeInt128(serverNonce)
            writeBytes(pBytes)
            writeBytes(qBytes)
            writeLong(matchedKey.fingerprint)
            writeBytes(encryptedData)
        }.toByteArray()
        sendUnencrypted(t, reqDh)

        val serverDhBytes = receiveUnencrypted(t)
        val dhReader = TlReader(serverDhBytes)
        val dhCtor = dhReader.readInt()
        if (dhCtor != 0xd0e8075c.toInt()) {
            throw IOException("DH params rejected by Telegram server (ctor=0x${dhCtor.toUInt().toString(16)})")
        }
        dhReader.readInt128() // nonce
        dhReader.readInt128() // serverNonce
        val encryptedAnswer = dhReader.readBytes()

        val (tmpAesKey, tmpAesIv) = MtProtoCrypto.deriveTmpAesKeyIv(newNonce, serverNonce)
        val answerWithHash = MtProtoCrypto.aesIgeDecrypt(encryptedAnswer, tmpAesKey, tmpAesIv)
        val answerReader = TlReader(answerWithHash, 20) // skip 20-byte SHA1 prefix
        val innerCtor = answerReader.readInt()
        if (innerCtor != 0xb5890dba.toInt()) {
            throw IOException("Expected server_DH_inner_data, got 0x${innerCtor.toUInt().toString(16)}")
        }
        answerReader.readInt128() // nonce
        answerReader.readInt128() // serverNonce
        val g = answerReader.readInt()
        val dhPrimeBytes = answerReader.readBytes()
        val gABytes = answerReader.readBytes()
        val serverTime = answerReader.readInt()
        timeOffset = serverTime - (System.currentTimeMillis() / 1000L).toInt()

        val dhPrime = BigInteger(1, dhPrimeBytes)
        val gA = BigInteger(1, gABytes)
        val gBig = BigInteger.valueOf(g.toLong())
        val b = BigInteger(1, MtProtoCrypto.randomBytes(256))
        val gB = gBig.modPow(b, dhPrime)
        val gBBytes = with(MtProtoCrypto) { gB.to256Bytes() }

        val clientDhInner = TlWriter(320).apply {
            writeInt(0x6643b654) // client_DH_inner_data
            writeInt128(nonce)
            writeInt128(serverNonce)
            writeLong(0L) // retry_id
            writeBytes(gBBytes)
        }.toByteArray()

        val clientDhHash = MtProtoCrypto.sha1(clientDhInner)
        val unpadded = clientDhHash + clientDhInner
        val padNeeded = (16 - (unpadded.size % 16)) % 16
        val paddedClientDh = unpadded + MtProtoCrypto.randomBytes(padNeeded)
        val encryptedClientDh = MtProtoCrypto.aesIgeEncrypt(paddedClientDh, tmpAesKey, tmpAesIv)

        // 4. set_client_DH_params#f5045f1f
        val setClientDh = TlWriter(400).apply {
            writeInt(0xf5045f1f.toInt())
            writeInt128(nonce)
            writeInt128(serverNonce)
            writeBytes(encryptedClientDh)
        }.toByteArray()
        sendUnencrypted(t, setClientDh)

        val dhGenBytes = receiveUnencrypted(t)
        val genReader = TlReader(dhGenBytes)
        val genCtor = genReader.readInt()
        if (genCtor != 0x3bcbf734) {
            throw IOException("DH key generation failed (ctor=0x${genCtor.toUInt().toString(16)})")
        }

        val sharedKey = with(MtProtoCrypto) { gA.modPow(b, dhPrime).to256Bytes() }
        val newNonceHash1 = ByteBuffer.wrap(newNonce, 0, 8).order(ByteOrder.LITTLE_ENDIAN).long
        val serverSaltInit = newNonceHash1 xor ByteBuffer.wrap(serverNonce, 0, 8).order(ByteOrder.LITTLE_ENDIAN).long

        authKey = sharedKey
        authKeyId = computeAuthKeyId(sharedKey)
        serverSalt = serverSaltInit
        secureStorage.saveDcAuthKey(dcId, sharedKey, serverSaltInit, timeOffset)
    }

    private fun startReaderLoop(t: MtProtoTransport) {
        readerJob?.cancel()
        readerJob = scope.launch {
            try {
                while (t.isConnected) {
                    val frame = t.receiveFrame()
                    handleEncryptedFrame(frame)
                }
            } catch (e: Exception) {
                t.close()
                val err = IOException("Connection lost: ${e.message ?: "Network error"}", e)
                pendingRpc.values.forEach { it.completeExceptionally(err) }
                pendingRpc.clear()
            }
        }
    }

    private fun handleEncryptedFrame(frame: ByteArray) {
        if (frame.size == 4) {
            val code = ByteBuffer.wrap(frame).order(ByteOrder.LITTLE_ENDIAN).int
            val ex = IOException("Telegram MTProto transport error: $code")
            pendingRpc.values.forEach { it.completeExceptionally(ex) }
            pendingRpc.clear()
            return
        }
        if (frame.size < 24) return
        val key = authKey ?: return

        val reader = TlReader(frame)
        val incomingAuthKeyId = reader.readLong()
        if (incomingAuthKeyId != authKeyId) return
        val msgKey = reader.readInt128()
        val encrypted = reader.readRaw(reader.remaining)

        val sha256a = MtProtoCrypto.sha256(msgKey, key.copyOfRange(8, 8 + 36))
        val sha256b = MtProtoCrypto.sha256(key.copyOfRange(40 + 8, 40 + 8 + 36), msgKey)
        val decKey = sha256a.copyOfRange(0, 8) + sha256b.copyOfRange(8, 24) + sha256a.copyOfRange(24, 32)
        val decIv = sha256b.copyOfRange(0, 8) + sha256a.copyOfRange(8, 24) + sha256b.copyOfRange(24, 32)

        val plaintext = MtProtoCrypto.aesIgeDecrypt(encrypted, decKey, decIv)
        if (plaintext.size < 32) return
        val expectedMsgKey = MtProtoCrypto.sha256(key.copyOfRange(96, 128), plaintext).copyOfRange(8, 24)
        if (!expectedMsgKey.contentEquals(msgKey)) return

        val pReader = TlReader(plaintext)
        pReader.readLong() // salt
        pReader.readLong() // sessionId
        val msgId = pReader.readLong()
        pReader.readInt() // seqNo
        val msgLen = pReader.readInt()
        if (msgLen < 4 || pReader.remaining < msgLen) return
        val body = pReader.readRaw(msgLen)

        processIncomingMessage(msgId, body)
    }

    private fun processIncomingMessage(msgId: Long, rawBody: ByteArray) {
        val body = TlHelpers.unwrapGzipIfNeeded(rawBody)
        if (body.size < 4) return
        val reader = TlReader(body)
        val ctor = reader.readInt()

        when (ctor) {
            0x73f1f8dc -> { // msg_container
                val count = reader.readInt()
                repeat(count) {
                    val innerMsgId = reader.readLong()
                    reader.readInt() // seqNo
                    val bytesLen = reader.readInt()
                    val innerBody = reader.readRaw(bytesLen)
                    processIncomingMessage(innerMsgId, innerBody)
                }
            }
            0xf35c6d01.toInt() -> { // rpc_result
                val reqMsgId = reader.readLong()
                val resultBytes = TlHelpers.unwrapGzipIfNeeded(reader.readRaw(reader.remaining))
                val deferred = pendingRpc.remove(reqMsgId)
                sendAckAsync(msgId)
                if (deferred != null) {
                    if (resultBytes.size >= 4) {
                        val rReader = TlReader(resultBytes)
                        if (rReader.peekInt() == 0x2144ca19) { // rpc_error
                            rReader.readInt()
                            val code = rReader.readInt()
                            val msg = rReader.readString()
                            deferred.completeExceptionally(TelegramRpcException(code, msg))
                            return
                        }
                    }
                    deferred.complete(resultBytes)
                }
            }
            0xedab447b.toInt() -> { // bad_server_salt
                val badMsgId = reader.readLong()
                reader.readInt() // badMsgSeqno
                reader.readInt() // errorCode
                val newSalt = reader.readLong()
                serverSalt = newSalt
                authKey?.let { secureStorage.saveDcAuthKey(dcId, it, newSalt, timeOffset) }
                pendingRpc.remove(badMsgId)?.completeExceptionally(
                    TelegramRpcException(48, "BAD_SERVER_SALT_RETRY")
                )
            }
            0xa7eff811.toInt() -> { // bad_msg_notification
                val badMsgId = reader.readLong()
                reader.readInt() // badMsgSeqno
                val errorCode = reader.readInt()
                pendingRpc.remove(badMsgId)?.completeExceptionally(
                    TelegramRpcException(errorCode, "BAD_MSG_NOTIFICATION_$errorCode")
                )
            }
            0x9ec20908.toInt() -> { // new_session_created
                reader.readLong() // firstMsgId
                reader.readLong() // uniqueId
                val newSalt = reader.readLong()
                serverSalt = newSalt
                authKey?.let { secureStorage.saveDcAuthKey(dcId, it, newSalt, timeOffset) }
                sendAckAsync(msgId)
            }
            else -> {
                // Updates / pong / msgs_ack — acknowledge server message
                if ((msgId and 1L) == 1L) sendAckAsync(msgId)
            }
        }
    }

    private fun sendAckAsync(msgId: Long) {
        scope.launch {
            runCatching {
                val ack = TlWriter(20).apply {
                    writeInt(0x62d6b459) // msgs_ack
                    writeInt(TlHelpers.VECTOR_CTOR)
                    writeInt(1)
                    writeLong(msgId)
                }.toByteArray()
                sendEncryptedPacket(ack, contentRelated = false)
            }
        }
    }

    private suspend fun sendEncryptedPacket(payload: ByteArray, contentRelated: Boolean): Long {
        val t = transport ?: throw IOException("Not connected to Telegram DC$dcId")
        val key = authKey ?: throw IOException("Auth key missing for DC$dcId")
        return sendMutex.withLock {
            val msgId = nextMsgId()
            val seqNo = nextSeqNo(contentRelated)
            val baseLen = 32 + payload.size
            var padLen = (16 - (baseLen % 16)) % 16
            if (padLen < 12) padLen += 16

            val plainWriter = TlWriter(baseLen + padLen)
            plainWriter.writeLong(serverSalt)
            plainWriter.writeLong(sessionId)
            plainWriter.writeLong(msgId)
            plainWriter.writeInt(seqNo)
            plainWriter.writeInt(payload.size)
            plainWriter.writeRaw(payload)
            plainWriter.writeRaw(MtProtoCrypto.randomBytes(padLen))
            val plaintextPadded = plainWriter.toByteArray()

            val (msgKey, aesKey, aesIv) = MtProtoCrypto.computeMsgKeyAndAesKeys(
                authKey = key,
                plaintextPadded = plaintextPadded,
                isOutgoing = true
            )
            val encrypted = MtProtoCrypto.aesIgeEncrypt(plaintextPadded, aesKey, aesIv)

            val packet = TlWriter(24 + encrypted.size).apply {
                writeLong(authKeyId)
                writeInt128(msgKey)
                writeRaw(encrypted)
            }.toByteArray()

            t.sendFrame(packet)
            msgId
        }
    }

    suspend fun invokeRpc(
        query: ByteArray,
        wrapWithLayerInit: Boolean = false,
        apiId: Int = 0,
        timeoutMs: Long = 35_000L
    ): ByteArray = withContext(Dispatchers.IO) {
        var attempts = 0
        while (true) {
            attempts++
            ensureConnected()
            val finalQuery = if (wrapWithLayerInit && apiId > 0) {
                wrapInitConnection(apiId, query)
            } else {
                query
            }
            val deferred = CompletableDeferred<ByteArray>()
            val msgId = sendEncryptedPacket(finalQuery, contentRelated = true)
            pendingRpc[msgId] = deferred
            try {
                return@withContext withTimeout(timeoutMs) {
                    deferred.await()
                }
            } catch (rpcEx: TelegramRpcException) {
                pendingRpc.remove(msgId)
                if (rpcEx.errorMessage == "BAD_SERVER_SALT_RETRY" && attempts < 3) {
                    continue
                }
                throw rpcEx
            } catch (e: Exception) {
                pendingRpc.remove(msgId)
                if (attempts < 2 && e is IOException) {
                    close()
                    continue
                }
                throw e
            }
        }
        @Suppress("UNREACHABLE_CODE")
        ByteArray(0)
    }

    private fun wrapInitConnection(apiId: Int, query: ByteArray): ByteArray {
        return TlWriter(256 + query.size).apply {
            writeInt(0xda9b0d0d.toInt()) // invokeWithLayer
            writeInt(198) // Layer 198
            writeInt(0xc1cd5ea9.toInt()) // initConnection
            writeInt(0) // flags
            writeInt(apiId)
            writeString("Clody Android")
            writeString("Android ${android.os.Build.VERSION.RELEASE}")
            writeString("1.0.0")
            writeString("en")
            writeString("")
            writeString("en")
            writeRaw(query)
        }.toByteArray()
    }

    fun close() {
        readerJob?.cancel()
        readerJob = null
        transport?.close()
        transport = null
        pendingRpc.values.forEach {
            it.completeExceptionally(IOException("Telegram session closed"))
        }
        pendingRpc.clear()
    }
}
