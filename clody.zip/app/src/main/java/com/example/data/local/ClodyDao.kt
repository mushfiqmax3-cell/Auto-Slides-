package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ClodyDao {

    // Folders
    @Query("SELECT * FROM folders WHERE parentId IS :parentId ORDER BY name ASC")
    fun observeFolders(parentId: Long?): Flow<List<FolderEntity>>

    @Query("SELECT * FROM folders ORDER BY name ASC")
    fun observeAllFolders(): Flow<List<FolderEntity>>

    @Query("SELECT * FROM folders ORDER BY id ASC")
    suspend fun getAllFoldersOnce(): List<FolderEntity>

    @Query("SELECT * FROM folders WHERE id = :id LIMIT 1")
    suspend fun getFolderById(id: Long): FolderEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFolder(folder: FolderEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFolders(folders: List<FolderEntity>)

    @Update
    suspend fun updateFolder(folder: FolderEntity)

    @Query("DELETE FROM folders WHERE id = :folderId")
    suspend fun deleteFolder(folderId: Long)

    // Files
    @Query("SELECT * FROM files WHERE isDeleted = 0 ORDER BY createdAt DESC")
    fun observeActiveFiles(): Flow<List<FileEntity>>

    @Query("SELECT * FROM files WHERE isDeleted = 0 AND (mimeType LIKE 'image/%' OR mimeType LIKE 'video/%') ORDER BY createdAt DESC")
    fun observeGalleryMedia(): Flow<List<FileEntity>>

    @Query("SELECT * FROM files WHERE isDeleted = 0 AND folderId IS :folderId ORDER BY createdAt DESC")
    fun observeFilesInFolder(folderId: Long?): Flow<List<FileEntity>>

    @Query("SELECT * FROM files WHERE isDeleted = 1 ORDER BY deletedAt DESC")
    fun observeDeletedFiles(): Flow<List<FileEntity>>

    @Query("SELECT * FROM files WHERE isDeleted = 0 AND sizeBytes >= :minBytes ORDER BY sizeBytes DESC")
    fun observeLargeFiles(minBytes: Long = 50L * 1024L * 1024L): Flow<List<FileEntity>>

    @Query("SELECT * FROM files WHERE isDeleted = 0 ORDER BY id ASC")
    suspend fun getAllActiveFilesOnce(): List<FileEntity>

    @Query("SELECT * FROM files WHERE id = :id LIMIT 1")
    suspend fun getFileById(id: Long): FileEntity?

    @Query("SELECT * FROM files WHERE telegramMessageId = :messageId LIMIT 1")
    suspend fun getFileByMessageId(messageId: Int): FileEntity?

    @Query(
        """
        SELECT files.* FROM files
        JOIN files_fts ON files.id = files_fts.rowid
        WHERE files.isDeleted = 0 AND files_fts MATCH :ftsQuery
        ORDER BY files.createdAt DESC
        """
    )
    fun searchFilesFts(ftsQuery: String): Flow<List<FileEntity>>

    @Query(
        """
        SELECT * FROM files
        WHERE isDeleted = 0 AND (name LIKE '%' || :query || '%' OR extension LIKE '%' || :query || '%' OR folderPath LIKE '%' || :query || '%')
        ORDER BY createdAt DESC
        """
    )
    fun searchFilesLike(query: String): Flow<List<FileEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFile(file: FileEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFiles(files: List<FileEntity>)

    @Update
    suspend fun updateFile(file: FileEntity)

    @Query("UPDATE files SET isFavorite = :favorite WHERE id = :fileId")
    suspend fun setFileFavorite(fileId: Long, favorite: Boolean)

    @Query("UPDATE files SET customThumbnailPath = :thumbPath WHERE id = :fileId")
    suspend fun updateCustomThumbnail(fileId: Long, thumbPath: String?)

    @Query("UPDATE files SET localCachePath = :cachePath WHERE id = :fileId")
    suspend fun updateLocalCachePath(fileId: Long, cachePath: String?)

    @Query("UPDATE files SET localCachePath = NULL")
    suspend fun clearAllLocalCachePaths()

    @Query("UPDATE files SET isDeleted = 1, deletedAt = :deletedAt WHERE id = :fileId")
    suspend fun softDeleteFile(fileId: Long, deletedAt: Long = System.currentTimeMillis())

    @Query("UPDATE files SET isDeleted = 0, deletedAt = NULL WHERE id = :fileId")
    suspend fun restoreFile(fileId: Long)

    @Query("DELETE FROM files WHERE id = :fileId")
    suspend fun permanentlyDeleteFile(fileId: Long)

    @Query("DELETE FROM files WHERE isDeleted = 1 AND deletedAt < :cutoffMs")
    suspend fun purgeExpiredRecycleBin(cutoffMs: Long)

    @Query("SELECT COALESCE(SUM(sizeBytes), 0) FROM files WHERE isDeleted = 0")
    fun observeTotalCloudBytes(): Flow<Long>

    @Query("DELETE FROM files")
    suspend fun clearAllFiles()

    @Query("DELETE FROM folders")
    suspend fun clearAllFolders()

    @Query("INSERT INTO files_fts(files_fts) VALUES('optimize')")
    suspend fun optimizeFtsIndex()

    @Query("INSERT INTO files_fts(files_fts) VALUES('rebuild')")
    suspend fun rebuildFtsIndex()

    // Upload Queue
    @Query("SELECT * FROM upload_tasks ORDER BY createdAt DESC")
    fun observeUploadTasks(): Flow<List<UploadTaskEntity>>

    @Query("SELECT * FROM upload_tasks WHERE status IN ('QUEUED', 'UPLOADING') ORDER BY createdAt ASC LIMIT 1")
    suspend fun getNextPendingUpload(): UploadTaskEntity?

    @Query("SELECT * FROM upload_tasks WHERE id = :id LIMIT 1")
    suspend fun getUploadTaskById(id: Long): UploadTaskEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUploadTask(task: UploadTaskEntity): Long

    @Update
    suspend fun updateUploadTask(task: UploadTaskEntity)

    @Query("UPDATE upload_tasks SET status = :status, errorMessage = :error WHERE id = :taskId")
    suspend fun updateUploadStatus(taskId: Long, status: String, error: String? = null)

    @Query("UPDATE upload_tasks SET bytesUploaded = :bytes, speedBytesPerSec = :speed WHERE id = :taskId")
    suspend fun updateUploadProgress(taskId: Long, bytes: Long, speed: Long)

    @Query("DELETE FROM upload_tasks WHERE status IN ('COMPLETED', 'CANCELLED')")
    suspend fun clearFinishedUploads()

    // Download Records
    @Query("SELECT * FROM download_records ORDER BY createdAt DESC")
    fun observeDownloadRecords(): Flow<List<DownloadRecordEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDownloadRecord(record: DownloadRecordEntity): Long

    @Update
    suspend fun updateDownloadRecord(record: DownloadRecordEntity)

    @Query("DELETE FROM download_records WHERE status != 'DOWNLOADING'")
    suspend fun clearCompletedDownloads()
}
