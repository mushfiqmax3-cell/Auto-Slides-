package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        FolderEntity::class,
        FileEntity::class,
        FileFtsEntity::class,
        UploadTaskEntity::class,
        DownloadRecordEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class ClodyDatabase : RoomDatabase() {
    abstract fun clodyDao(): ClodyDao

    companion object {
        @Volatile
        private var INSTANCE: ClodyDatabase? = null

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE files ADD COLUMN localSourceUri TEXT")
            }
        }

        fun getInstance(context: Context): ClodyDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    ClodyDatabase::class.java,
                    "clody_database.db"
                )
                    .addMigrations(MIGRATION_1_2)
                    .fallbackToDestructiveMigration(true)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
