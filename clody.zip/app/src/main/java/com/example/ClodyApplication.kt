package com.example

import android.app.Application
import android.content.Context
import com.example.data.local.ClodyDao
import com.example.data.local.ClodyDatabase
import com.example.data.local.SecureStorage
import com.example.data.local.SettingsRepository
import com.example.files.DeviceFileManager
import com.example.service.TransferManager
import com.example.telegram.TelegramClientManager

class AppContainer(context: Context) {
    val database: ClodyDatabase = ClodyDatabase.getInstance(context)
    val dao: ClodyDao = database.clodyDao()
    val secureStorage: SecureStorage = SecureStorage(context)
    val settingsRepository: SettingsRepository = SettingsRepository(context)
    val telegramClient: TelegramClientManager = TelegramClientManager(context, secureStorage, dao)
    val transferManager: TransferManager = TransferManager(context, dao, telegramClient, settingsRepository)
    val deviceFileManager: DeviceFileManager = DeviceFileManager(context)
}

class ClodyApplication : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
