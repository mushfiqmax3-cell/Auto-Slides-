package com.example.media

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.local.FileEntity
import com.example.telegram.TelegramClientManager
import com.example.ui.theme.FavoriteGold
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

@Composable
fun ImageViewerScreen(
    file: FileEntity,
    telegramClient: TelegramClientManager,
    zeroStorageMode: Boolean,
    onDownloadToGallery: (FileEntity) -> Unit,
    onToggleFavorite: (FileEntity) -> Unit,
    onShare: (FileEntity, File?) -> Unit,
    onDelete: (FileEntity) -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val resolvedSource = remember(file.id, file.localSourceUri) {
        LocalFirstResolver.resolve(context, file)
    }
    val origin = resolvedSource.origin

    var hudVisible by remember { mutableStateOf(true) }
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    var fullResFile by remember(file.id) {
        mutableStateOf(
            when (resolvedSource) {
                is ResolvedMediaSource.LocalDevice -> resolvedSource.directFile
                is ResolvedMediaSource.CloudStream -> {
                    file.localCachePath?.let { File(it).takeIf(File::exists) }
                        ?: ClodyStreamCache.getCachedVideoFile(context, file)
                            .takeIf { it.exists() && it.length() == file.sizeBytes }
                }
            }
        )
    }
    var isLoadingFullRes by remember(file.id) {
        mutableStateOf(resolvedSource is ResolvedMediaSource.CloudStream && fullResFile == null && file.telegramDocumentId != 0L)
    }
    var loadError by remember(file.id) { mutableStateOf<String?>(null) }

    BackHandler(onBack = onBack)

    // Stream full-resolution image into private app cache ONLY when missing on device
    LaunchedEffect(file.id, origin) {
        if (resolvedSource is ResolvedMediaSource.CloudStream && fullResFile == null && file.telegramDocumentId != 0L) {
            isLoadingFullRes = true
            runCatching {
                LocalFirstResolver.loadToReadableFile(context, telegramClient, file).first
            }.onSuccess { cached ->
                fullResFile = cached
                isLoadingFullRes = false
            }.onFailure { err ->
                loadError = err.message
                isLoadingFullRes = false
            }
        }
    }

    DisposableEffect(file.id, zeroStorageMode) {
        onDispose {
            if (zeroStorageMode && origin == MediaPlaybackOrigin.CLOUD_STREAM) {
                ClodyStreamCache.deleteFileCache(context, file)
            }
        }
    }

    val modelToDisplay: Any? = when (resolvedSource) {
        is ResolvedMediaSource.LocalDevice -> resolvedSource.uri
        is ResolvedMediaSource.CloudStream -> fullResFile ?: file.activeThumbnailPath?.let { File(it) }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        val nextScale = (scale * zoom).coerceIn(1f, 4.5f)
                        scale = nextScale
                        offset = if (nextScale > 1f) offset + pan else Offset.Zero
                    }
                }
                .pointerInput(Unit) {
                    detectTapGestures(
                        onTap = { hudVisible = !hudVisible },
                        onDoubleTap = {
                            if (scale > 1.1f) {
                                scale = 1f
                                offset = Offset.Zero
                            } else {
                                scale = 2.5f
                            }
                        }
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            if (modelToDisplay != null) {
                AsyncImage(
                    model = modelToDisplay,
                    contentDescription = file.name,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            scaleX = scale
                            scaleY = scale
                            translationX = offset.x
                            translationY = offset.y
                        }
                )
            }
            if (isLoadingFullRes) {
                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(36.dp))
            }
            if (loadError != null && modelToDisplay == null) {
                Text("Unable to stream photo: $loadError", color = Color.White.copy(alpha = 0.8f))
            }
        }

        AnimatedVisibility(
            visible = hudVisible,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.Black.copy(alpha = 0.55f))
                        .statusBarsPadding()
                        .padding(horizontal = 8.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                    Text(
                        text = file.name,
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 15.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    PlaybackOriginPill(origin = origin, darkSurface = true)
                    IconButton(onClick = { onToggleFavorite(file) }) {
                        Icon(
                            imageVector = if (file.isFavorite) Icons.Filled.Star else Icons.Outlined.StarBorder,
                            contentDescription = "Favorite",
                            tint = if (file.isFavorite) FavoriteGold else Color.White
                        )
                    }
                }

                Surface(
                    color = Color(0xFF141414).copy(alpha = 0.92f),
                    shape = RoundedCornerShape(28.dp),
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .navigationBarsPadding()
                        .padding(bottom = 20.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        DownloadOrSavedPill(
                            origin = origin,
                            onDownloadClick = { onDownloadToGallery(file) },
                            darkMode = true
                        )
                        IconButton(onClick = { onShare(file, fullResFile) }) {
                            Icon(Icons.Default.Share, contentDescription = "Share", tint = Color.White)
                        }
                        IconButton(onClick = { onDelete(file) }) {
                            Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = Color.White)
                        }
                    }
                }
            }
        }
    }
}

private fun hexToBytes(hex: String): ByteArray {
    if (hex.isEmpty() || hex.length % 2 != 0) return ByteArray(0)
    return ByteArray(hex.length / 2) { i ->
        hex.substring(i * 2, i * 2 + 2).toInt(16).toByte()
    }
}
