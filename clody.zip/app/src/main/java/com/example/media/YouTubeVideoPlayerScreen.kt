package com.example.media

import android.app.Activity
import android.content.Context
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.media.AudioManager
import android.net.Uri
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.BrightnessHigh
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.example.data.local.FileEntity
import com.example.telegram.TelegramClientManager
import com.example.ui.theme.YouTubeCrimson
import kotlinx.coroutines.delay
import java.io.File
import kotlin.math.abs
import kotlin.math.roundToInt

enum class VideoResizeFit(val label: String, val resizeMode: Int) {
    FIT("Fit", AspectRatioFrameLayout.RESIZE_MODE_FIT),
    ZOOM("Zoom / Fill", AspectRatioFrameLayout.RESIZE_MODE_ZOOM),
    STRETCH("Stretch", AspectRatioFrameLayout.RESIZE_MODE_FILL)
}

@kotlin.OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@OptIn(UnstableApi::class)
@Composable
fun YouTubeVideoPlayerScreen(
    file: FileEntity,
    playlist: List<FileEntity>,
    telegramClient: TelegramClientManager,
    zeroStorageMode: Boolean,
    onSelectVideo: (FileEntity) -> Unit,
    onDownloadToGallery: (FileEntity) -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val configuration = LocalConfiguration.current
    val isLandscape = configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

    var controlsVisible by remember { mutableStateOf(true) }
    var isLocked by remember { mutableStateOf(false) }
    var showUnlockPill by remember { mutableStateOf(false) }
    var showSettingsSheet by remember { mutableStateOf(false) }

    var isPlaying by remember { mutableStateOf(true) }
    var isBuffering by remember { mutableStateOf(true) }
    var isEnded by remember { mutableStateOf(false) }
    var currentPositionMs by remember { mutableLongStateOf(0L) }
    var durationMs by remember { mutableLongStateOf(maxOf(file.durationMs, 1L)) }
    var bufferedPositionMs by remember { mutableLongStateOf(0L) }
    var videoAspectRatio by remember { mutableFloatStateOf(16f / 9f) }

    var playbackSpeed by remember { mutableFloatStateOf(1.0f) }
    var isTempBoost2x by remember { mutableStateOf(false) }
    var resizeFit by remember { mutableStateOf(VideoResizeFit.FIT) }
    var isLooping by remember { mutableStateOf(false) }

    // Double-tap seek feedback state
    var seekOverlaySide by remember { mutableStateOf<Int?>(null) } // -1 = left, 1 = right
    var seekAccumulatedSec by remember { mutableIntStateOf(0) }
    var lastSeekTapTime by remember { mutableLongStateOf(0L) }

    // Vertical swipe Brightness & Volume HUD
    val audioManager = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVolume = remember { maxOf(1, audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)) }
    var volumeLevel by remember {
        mutableFloatStateOf(audioManager.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxVolume)
    }
    var brightnessLevel by remember {
        mutableFloatStateOf(
            activity?.window?.attributes?.screenBrightness?.takeIf { it in 0f..1f } ?: 0.5f
        )
    }
    var activeSwipeHud by remember { mutableStateOf<String?>(null) } // "BRIGHTNESS" or "VOLUME"

    // Pinch-to-zoom status pill
    var pinchPillText by remember { mutableStateOf<String?>(null) }

    // Scrubber drag state
    var isScrubbing by remember { mutableStateOf(false) }
    var scrubPositionMs by remember { mutableLongStateOf(0L) }

    val resolvedSource = remember(file.id, file.localSourceUri) {
        LocalFirstResolver.resolve(context, file)
    }
    val origin = resolvedSource.origin

    val exoPlayer = remember(file.id) {
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(1500, 30_000, 500, 1000)
            .build()

        val hasLocalCached = file.localCachePath?.let { File(it).exists() } == true
        val dataSourceFactory = when {
            resolvedSource is ResolvedMediaSource.LocalDevice -> DefaultDataSource.Factory(context)
            hasLocalCached || file.telegramDocumentId == 0L -> DefaultDataSource.Factory(context)
            else -> TelegramChunkDataSource.Factory(context, telegramClient, file)
        }

        val mediaUri = when {
            resolvedSource is ResolvedMediaSource.LocalDevice -> resolvedSource.uri
            hasLocalCached -> Uri.fromFile(File(file.localCachePath!!))
            else -> Uri.parse("clody://telegram/${file.telegramDocumentId}/${file.name}")
        }

        ExoPlayer.Builder(context)
            .setLoadControl(loadControl)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dataSourceFactory))
            .build().apply {
                setMediaItem(MediaItem.fromUri(mediaUri))
                playWhenReady = true
                prepare()
            }
    }

    // Listen to ExoPlayer events
    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                isBuffering = playbackState == Player.STATE_BUFFERING
                isEnded = playbackState == Player.STATE_ENDED
                if (exoPlayer.duration > 0L) {
                    durationMs = exoPlayer.duration
                }
            }

            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }

            override fun onVideoSizeChanged(videoSize: VideoSize) {
                if (videoSize.width > 0 && videoSize.height > 0) {
                    videoAspectRatio = (videoSize.width.toFloat() / videoSize.height.toFloat())
                        .coerceIn(0.4f, 2.6f)
                }
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            exoPlayer.removeListener(listener)
            exoPlayer.release()
            if (zeroStorageMode && origin == MediaPlaybackOrigin.CLOUD_STREAM) {
                ClodyStreamCache.deleteFileCache(context, file)
            }
        }
    }

    // Apply playback speed & loop changes
    LaunchedEffect(playbackSpeed, isTempBoost2x) {
        val target = if (isTempBoost2x) 2.0f else playbackSpeed
        exoPlayer.playbackParameters = PlaybackParameters(target)
    }

    LaunchedEffect(isLooping) {
        exoPlayer.repeatMode = if (isLooping) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
    }

    // Poll playhead at 10Hz for smooth scrubber updates
    LaunchedEffect(exoPlayer) {
        while (true) {
            if (!isScrubbing) {
                currentPositionMs = exoPlayer.currentPosition.coerceAtLeast(0L)
            }
            bufferedPositionMs = exoPlayer.bufferedPosition.coerceAtLeast(0L)
            if (exoPlayer.duration > 0L) durationMs = exoPlayer.duration
            delay(100L)
        }
    }

    // Auto-hide HUD after 3 seconds while playing
    LaunchedEffect(controlsVisible, isPlaying, isScrubbing, showSettingsSheet) {
        if (controlsVisible && isPlaying && !isScrubbing && !showSettingsSheet) {
            delay(3000L)
            controlsVisible = false
        }
    }

    // Auto-hide transient HUD pills
    LaunchedEffect(seekOverlaySide, seekAccumulatedSec) {
        if (seekOverlaySide != null) {
            delay(750L)
            seekOverlaySide = null
            seekAccumulatedSec = 0
        }
    }

    LaunchedEffect(activeSwipeHud, brightnessLevel, volumeLevel) {
        if (activeSwipeHud != null) {
            delay(900L)
            activeSwipeHud = null
        }
    }

    LaunchedEffect(pinchPillText) {
        if (pinchPillText != null) {
            delay(1100L)
            pinchPillText = null
        }
    }

    LaunchedEffect(showUnlockPill) {
        if (showUnlockPill) {
            delay(2000L)
            showUnlockPill = false
        }
    }

    // Manage system bars in landscape fullscreen
    DisposableEffect(isLandscape) {
        val window = activity?.window
        if (window != null) {
            val controller = WindowCompat.getInsetsController(window, window.decorView)
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            if (isLandscape) {
                controller.hide(WindowInsetsCompat.Type.systemBars())
            } else {
                controller.show(WindowInsetsCompat.Type.systemBars())
            }
        }
        onDispose {
            if (window != null) {
                WindowCompat.getInsetsController(window, window.decorView)
                    .show(WindowInsetsCompat.Type.systemBars())
            }
        }
    }

    // Restore portrait on exit
    DisposableEffect(Unit) {
        onDispose {
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    fun toggleFullscreen() {
        activity?.requestedOrientation = if (isLandscape) {
            ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        } else {
            ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
    }

    BackHandler {
        if (isLandscape) {
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        } else {
            onBack()
        }
    }

    val currentIndex = remember(file.id, playlist) {
        playlist.indexOfFirst { it.id == file.id }
    }
    val hasPrev = currentIndex > 0
    val hasNext = currentIndex in 0 until (playlist.size - 1)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .testTag("youtube_video_player")
    ) {
        // Theater Layout: Centered video in Portrait, Full-Bleed in Landscape
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            BoxWithConstraints(
                modifier = if (isLandscape) {
                    Modifier.fillMaxSize()
                } else {
                    Modifier
                        .fillMaxWidth()
                        .aspectRatio(videoAspectRatio.coerceIn(0.56f, 2.2f))
                },
                contentAlignment = Alignment.Center
            ) {
                val viewportWidthPx = constraints.maxWidth.toFloat()

                // Hardware-accelerated Media3 PlayerView
                AndroidView(
                    factory = { ctx ->
                        PlayerView(ctx).apply {
                            useController = false
                            setShowBuffering(PlayerView.SHOW_BUFFERING_NEVER)
                            setKeepContentOnPlayerReset(true)
                            player = exoPlayer
                        }
                    },
                    update = { view ->
                        if (view.player !== exoPlayer) view.player = exoPlayer
                        view.resizeMode = resizeFit.resizeMode
                    },
                    modifier = Modifier.fillMaxSize()
                )

                // Gesture Layer: Single tap, Double tap -10/+10, Long-press 2x speed, Vertical swipe Brightness/Volume, Pinch-to-Zoom
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(isLocked) {
                            awaitEachGesture {
                                val firstDown = awaitFirstDown(requireUnconsumed = false)
                                var isMultiTouch = false
                                var verticalDragging = false
                                var totalVerticalDrag = 0f
                                val startX = firstDown.position.x
                                var totalZoom = 1f

                                while (true) {
                                    val event = awaitPointerEvent()
                                    val pressedCount = event.changes.count { it.pressed }
                                    if (pressedCount >= 2 && !isLocked) {
                                        isMultiTouch = true
                                        val zoomDelta = event.calculateZoom()
                                        totalZoom *= zoomDelta
                                        if (totalZoom > 1.15f && resizeFit != VideoResizeFit.ZOOM) {
                                            resizeFit = VideoResizeFit.ZOOM
                                            pinchPillText = "Zoomed to Fill"
                                        } else if (totalZoom < 0.88f && resizeFit != VideoResizeFit.FIT) {
                                            resizeFit = VideoResizeFit.FIT
                                            pinchPillText = "Fit to Screen"
                                        }
                                        event.changes.forEach { it.consume() }
                                    } else if (pressedCount == 1 && !isMultiTouch && !isLocked) {
                                        val change = event.changes.first()
                                        val dy = change.position.y - change.previousPosition.y
                                        val dx = change.position.x - change.previousPosition.x
                                        if (!verticalDragging && abs(dy) > 12f && abs(dy) > abs(dx) * 1.3f) {
                                            verticalDragging = true
                                        }
                                        if (verticalDragging && change.pressed) {
                                            totalVerticalDrag += dy
                                            val deltaFrac = -dy / (size.height.toFloat() * 0.75f)
                                            if (startX < viewportWidthPx * 0.5f) {
                                                // Left half -> Screen Brightness
                                                brightnessLevel = (brightnessLevel + deltaFrac).coerceIn(0.05f, 1.0f)
                                                activity?.window?.let { win ->
                                                    val lp = win.attributes
                                                    lp.screenBrightness = brightnessLevel
                                                    win.attributes = lp
                                                }
                                                activeSwipeHud = "BRIGHTNESS"
                                            } else {
                                                // Right half -> Media Volume
                                                volumeLevel = (volumeLevel + deltaFrac).coerceIn(0f, 1f)
                                                val targetVol = (volumeLevel * maxVolume).roundToInt().coerceIn(0, maxVolume)
                                                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, targetVol, 0)
                                                activeSwipeHud = "VOLUME"
                                            }
                                            change.consume()
                                        }
                                    }
                                    if (event.changes.none { it.pressed }) break
                                }
                            }
                        }
                        .pointerInput(isLocked) {
                            detectTapGestures(
                                onTap = {
                                    if (isLocked) {
                                        showUnlockPill = !showUnlockPill
                                    } else {
                                        controlsVisible = !controlsVisible
                                    }
                                },
                                onDoubleTap = { offset ->
                                    if (isLocked) return@detectTapGestures
                                    val now = System.currentTimeMillis()
                                    val side = if (offset.x < size.width / 2f) -1 else 1
                                    val withinStreak = (now - lastSeekTapTime) < 1100L && seekOverlaySide == side
                                    lastSeekTapTime = now
                                    seekOverlaySide = side
                                    seekAccumulatedSec = if (withinStreak) seekAccumulatedSec + 10 else 10
                                    val targetPos = (exoPlayer.currentPosition + side * 10_000L)
                                        .coerceIn(0L, durationMs)
                                    exoPlayer.seekTo(targetPos)
                                    currentPositionMs = targetPos
                                },
                                onLongPress = {
                                    if (isLocked) return@detectTapGestures
                                    isTempBoost2x = true
                                },
                                onPress = {
                                    tryAwaitRelease()
                                    if (isTempBoost2x) {
                                        isTempBoost2x = false
                                    }
                                }
                            )
                        }
                )

                // Double-tap semi-circular ripple & -10s / +10s chevron overlay
                androidx.compose.animation.AnimatedVisibility(
                    visible = seekOverlaySide != null,
                    enter = fadeIn(tween(120)),
                    exit = fadeOut(tween(220)),
                    modifier = Modifier.fillMaxSize()
                ) {
                    val side = seekOverlaySide ?: 1
                    Box(modifier = Modifier.fillMaxSize()) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val r = size.height * 0.9f
                            val center = if (side < 0) Offset(-r * 0.2f, size.height / 2f) else Offset(size.width + r * 0.2f, size.height / 2f)
                            drawCircle(
                                color = Color.White.copy(alpha = 0.20f),
                                radius = r,
                                center = center
                            )
                        }
                        Column(
                            modifier = Modifier
                                .align(if (side < 0) Alignment.CenterStart else Alignment.CenterEnd)
                                .padding(horizontal = 36.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = if (side < 0) Icons.Default.FastRewind else Icons.Default.FastForward,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(34.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (side < 0) "-${seekAccumulatedSec}s" else "+${seekAccumulatedSec}s",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }
                    }
                }

                // 2.0x Long-Press Speed Floating Pill
                androidx.compose.animation.AnimatedVisibility(
                    visible = isTempBoost2x,
                    enter = fadeIn(tween(120)),
                    exit = fadeOut(tween(120)),
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 18.dp)
                ) {
                    Surface(
                        color = Color.Black.copy(alpha = 0.78f),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "2x Speed",
                                color = Color.White,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.Default.FastForward,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }

                // Pinch-to-Zoom Status Pill
                androidx.compose.animation.AnimatedVisibility(
                    visible = pinchPillText != null,
                    enter = fadeIn(tween(120)),
                    exit = fadeOut(tween(200)),
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 18.dp)
                ) {
                    Surface(
                        color = Color.Black.copy(alpha = 0.78f),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Text(
                            text = pinchPillText.orEmpty(),
                            color = Color.White,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                        )
                    }
                }

                // Vertical Swipe Brightness / Volume HUD Slider
                androidx.compose.animation.AnimatedVisibility(
                    visible = activeSwipeHud != null,
                    enter = fadeIn(tween(100)),
                    exit = fadeOut(tween(200)),
                    modifier = Modifier
                        .align(if (activeSwipeHud == "BRIGHTNESS") Alignment.CenterStart else Alignment.CenterEnd)
                        .padding(horizontal = 24.dp)
                ) {
                    val level = if (activeSwipeHud == "BRIGHTNESS") brightnessLevel else volumeLevel
                    val icon = if (activeSwipeHud == "BRIGHTNESS") Icons.Default.BrightnessHigh else Icons.AutoMirrored.Filled.VolumeUp
                    Surface(
                        color = Color.Black.copy(alpha = 0.72f),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Box(
                                modifier = Modifier
                                    .width(5.dp)
                                    .height(92.dp)
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(Color.White.copy(alpha = 0.25f)),
                                contentAlignment = Alignment.BottomCenter
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .fillMaxHeight(level.coerceIn(0f, 1f))
                                        .background(Color.White)
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "${(level * 100).roundToInt()}%",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                // Screen Locked Unlock Pill
                androidx.compose.animation.AnimatedVisibility(
                    visible = isLocked && showUnlockPill,
                    enter = fadeIn(),
                    exit = fadeOut(),
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 24.dp)
                ) {
                    Surface(
                        color = Color.White,
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier.clickable {
                            isLocked = false
                            showUnlockPill = false
                            controlsVisible = true
                        }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 18.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.LockOpen, contentDescription = "Unlock", tint = Color.Black, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Tap to Unlock", color = Color.Black, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        }
                    }
                }

                // Buffering Spinner ONLY during active chunk buffering (when HUD hidden or visible)
                if (isBuffering && !controlsVisible) {
                    CircularProgressIndicator(
                        color = Color.White,
                        strokeWidth = 3.dp,
                        modifier = Modifier.size(44.dp)
                    )
                }

                // YouTube-Style HUD Overlay (Inside viewport for Portrait / Full-screen in Landscape)
                androidx.compose.animation.AnimatedVisibility(
                    visible = controlsVisible && !isLocked,
                    enter = fadeIn(tween(180)),
                    exit = fadeOut(tween(220)),
                    modifier = Modifier.fillMaxSize()
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    listOf(
                                        Color.Black.copy(alpha = 0.65f),
                                        Color.Black.copy(alpha = 0.25f),
                                        Color.Black.copy(alpha = 0.72f)
                                    )
                                )
                            )
                    ) {
                        // Top Bar (Show Back + Title inside HUD in Landscape; Portrait uses theater top bar)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .align(Alignment.TopCenter)
                                .then(if (isLandscape) Modifier.statusBarsPadding() else Modifier)
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (isLandscape) {
                                IconButton(
                                    onClick = {
                                        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                                    },
                                    modifier = Modifier.testTag("player_back_button")
                                ) {
                                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                                }
                                Text(
                                    text = file.name,
                                    color = Color.White,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 15.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                            } else {
                                Spacer(modifier = Modifier.weight(1f))
                            }
                            PlaybackOriginPill(origin = origin, darkSurface = true)
                            IconButton(
                                onClick = {
                                    isLocked = true
                                    controlsVisible = false
                                    showUnlockPill = true
                                },
                                modifier = Modifier.testTag("player_lock_button")
                            ) {
                                Icon(Icons.Default.Lock, contentDescription = "Lock screen", tint = Color.White)
                            }
                            IconButton(
                                onClick = { showSettingsSheet = true },
                                modifier = Modifier.testTag("player_settings_button")
                            ) {
                                Icon(Icons.Default.Settings, contentDescription = "Player settings", tint = Color.White)
                            }
                        }

                        // Center Transport Controls
                        Row(
                            modifier = Modifier.align(Alignment.Center),
                            horizontalArrangement = Arrangement.spacedBy(28.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = { if (hasPrev) onSelectVideo(playlist[currentIndex - 1]) },
                                enabled = hasPrev
                            ) {
                                Icon(
                                    imageVector = Icons.Default.SkipPrevious,
                                    contentDescription = "Previous video",
                                    tint = if (hasPrev) Color.White else Color.White.copy(alpha = 0.35f),
                                    modifier = Modifier.size(34.dp)
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .size(60.dp)
                                    .clip(CircleShape)
                                    .background(Color.Black.copy(alpha = 0.45f))
                                    .clickable {
                                        when {
                                            isEnded -> {
                                                exoPlayer.seekTo(0L)
                                                exoPlayer.playWhenReady = true
                                            }
                                            isPlaying -> exoPlayer.pause()
                                            else -> exoPlayer.play()
                                        }
                                    }
                                    .testTag("player_play_pause_button"),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isBuffering) {
                                    CircularProgressIndicator(
                                        color = Color.White,
                                        strokeWidth = 3.dp,
                                        modifier = Modifier.size(34.dp)
                                    )
                                } else {
                                    Icon(
                                        imageVector = when {
                                            isEnded -> Icons.Default.Replay
                                            isPlaying -> Icons.Default.Pause
                                            else -> Icons.Default.PlayArrow
                                        },
                                        contentDescription = if (isPlaying) "Pause" else "Play",
                                        tint = Color.White,
                                        modifier = Modifier.size(36.dp)
                                    )
                                }
                            }

                            IconButton(
                                onClick = { if (hasNext) onSelectVideo(playlist[currentIndex + 1]) },
                                enabled = hasNext
                            ) {
                                Icon(
                                    imageVector = Icons.Default.SkipNext,
                                    contentDescription = "Next video",
                                    tint = if (hasNext) Color.White else Color.White.copy(alpha = 0.35f),
                                    modifier = Modifier.size(34.dp)
                                )
                            }
                        }

                        // Bottom Timeline & Scrubber
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .align(Alignment.BottomCenter)
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                val displayedPos = if (isScrubbing) scrubPositionMs else currentPositionMs
                                Text(
                                    text = "${formatDuration(displayedPos)} / ${formatDuration(durationMs)}",
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium
                                )
                                IconButton(
                                    onClick = { toggleFullscreen() },
                                    modifier = Modifier.size(36.dp).testTag("player_fullscreen_button")
                                ) {
                                    Icon(
                                        imageVector = if (isLandscape) Icons.Default.FullscreenExit else Icons.Default.Fullscreen,
                                        contentDescription = "Toggle fullscreen",
                                        tint = Color.White
                                    )
                                }
                            }

                            YouTubeTactileScrubber(
                                currentPositionMs = if (isScrubbing) scrubPositionMs else currentPositionMs,
                                bufferedPositionMs = bufferedPositionMs,
                                durationMs = durationMs,
                                isScrubbing = isScrubbing,
                                onScrubStart = { pos ->
                                    isScrubbing = true
                                    scrubPositionMs = pos
                                },
                                onScrubMove = { pos ->
                                    scrubPositionMs = pos
                                },
                                onScrubEnd = { pos ->
                                    isScrubbing = false
                                    currentPositionMs = pos
                                    exoPlayer.seekTo(pos)
                                }
                            )
                        }
                    }
                }
            }
        }

        // Portrait Mode: Top Back Bar & Bottom Quick-Action Bar outside centered video viewport
        if (!isLandscape) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .align(Alignment.TopCenter)
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Close player", tint = Color.White)
                }
                Text(
                    text = file.name,
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 16.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(8.dp))
                PlaybackOriginPill(origin = origin, darkSurface = true)
            }

            // Minimal quick-action bar below video in Portrait
            Surface(
                color = Color(0xFF141414),
                shape = RoundedCornerShape(28.dp),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(horizontal = 20.dp, vertical = 28.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    DownloadOrSavedPill(
                        origin = origin,
                        onDownloadClick = { onDownloadToGallery(file) },
                        darkMode = true
                    )
                    QuickActionPill(
                        icon = if (isLocked) Icons.Default.LockOpen else Icons.Default.Lock,
                        label = if (isLocked) "Unlock" else "Lock",
                        onClick = {
                            isLocked = !isLocked
                            showUnlockPill = isLocked
                        }
                    )
                    QuickActionPill(
                        icon = if (isLooping) Icons.Default.RepeatOne else Icons.Default.Repeat,
                        label = if (isLooping) "Loop On" else "Loop",
                        tint = if (isLooping) YouTubeCrimson else Color.White,
                        onClick = { isLooping = !isLooping }
                    )
                }
            }
        }
    }

    // YouTube-Style Settings Bottom Sheet
    if (showSettingsSheet) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(
            onDismissRequest = { showSettingsSheet = false },
            sheetState = sheetState,
            containerColor = Color(0xFF1C1C1E),
            contentColor = Color.White
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp)
            ) {
                Text(
                    text = "Playback Settings",
                    style = MaterialTheme.typography.titleLarge,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(16.dp))

                // Playback Speed
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Speed, contentDescription = null, tint = Color.White.copy(alpha = 0.8f))
                    Spacer(modifier = Modifier.width(10.dp))
                    Text("Playback Speed", fontWeight = FontWeight.SemiBold, color = Color.White)
                }
                Spacer(modifier = Modifier.height(8.dp))
                val speeds = listOf(0.25f, 0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    speeds.forEach { spd ->
                        val selected = abs(playbackSpeed - spd) < 0.01f
                        FilterChip(
                            selected = selected,
                            onClick = { playbackSpeed = spd },
                            label = { Text(if (spd == 1.0f) "Normal 1x" else "${spd}x") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color.White,
                                selectedLabelColor = Color.Black,
                                containerColor = Color(0xFF2C2C2E),
                                labelColor = Color.White
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Screen Fit / Aspect Ratio
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AspectRatio, contentDescription = null, tint = Color.White.copy(alpha = 0.8f))
                    Spacer(modifier = Modifier.width(10.dp))
                    Text("Screen Fit", fontWeight = FontWeight.SemiBold, color = Color.White)
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    VideoResizeFit.entries.forEach { fit ->
                        FilterChip(
                            selected = resizeFit == fit,
                            onClick = { resizeFit = fit },
                            label = { Text(fit.label) },
                            leadingIcon = if (resizeFit == fit) {
                                { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                            } else null,
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color.White,
                                selectedLabelColor = Color.Black,
                                containerColor = Color(0xFF2C2C2E),
                                labelColor = Color.White
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Loop Video Switch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Repeat, contentDescription = null, tint = Color.White.copy(alpha = 0.8f))
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("Loop Video", fontWeight = FontWeight.SemiBold, color = Color.White)
                    }
                    Switch(checked = isLooping, onCheckedChange = { isLooping = it })
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        if (origin == MediaPlaybackOrigin.CLOUD_STREAM) {
                            showSettingsSheet = false
                            onDownloadToGallery(file)
                        }
                    },
                    enabled = origin == MediaPlaybackOrigin.CLOUD_STREAM,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.White,
                        contentColor = Color.Black,
                        disabledContainerColor = Color(0xFF2C2C2E),
                        disabledContentColor = com.example.ui.theme.EmeraldConnected
                    ),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                ) {
                    Icon(
                        imageVector = if (origin == MediaPlaybackOrigin.ON_DEVICE) Icons.Default.Check else Icons.Default.Download,
                        contentDescription = null
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (origin == MediaPlaybackOrigin.ON_DEVICE) "Saved on Device ✓" else "Download to Phone Gallery",
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun QuickActionPill(
    icon: ImageVector,
    label: String,
    tint: Color = Color.White,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(label, color = tint, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun YouTubeTactileScrubber(
    currentPositionMs: Long,
    bufferedPositionMs: Long,
    durationMs: Long,
    isScrubbing: Boolean,
    onScrubStart: (Long) -> Unit,
    onScrubMove: (Long) -> Unit,
    onScrubEnd: (Long) -> Unit
) {
    val safeDuration = maxOf(1L, durationMs)
    val activeFraction = (currentPositionMs.toFloat() / safeDuration.toFloat()).coerceIn(0f, 1f)
    val bufferedFraction = (bufferedPositionMs.toFloat() / safeDuration.toFloat()).coerceIn(activeFraction, 1f)
    val thumbRadius by animateDpAsState(
        targetValue = if (isScrubbing) 10.dp else 6.dp,
        label = "scrubber_thumb"
    )
    val density = LocalDensity.current

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxWidth()
            .height(38.dp),
        contentAlignment = Alignment.Center
    ) {
        val widthPx = constraints.maxWidth.toFloat().coerceAtLeast(1f)

        // Floating live timestamp tooltip above finger while scrubbing
        if (isScrubbing) {
            val tooltipX = (activeFraction * widthPx - with(density) { 26.dp.toPx() })
                .coerceIn(0f, (widthPx - with(density) { 56.dp.toPx() }).coerceAtLeast(0f))
            Surface(
                color = Color(0xFF141414),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .offset { IntOffset(tooltipX.roundToInt(), -with(density) { 30.dp.roundToPx() }) }
            ) {
                Text(
                    text = formatDuration(currentPositionMs),
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }

        var dragTargetMs by remember { mutableLongStateOf(currentPositionMs) }
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(safeDuration) {
                    detectTapGestures { offset ->
                        val frac = (offset.x / widthPx).coerceIn(0f, 1f)
                        val target = (frac * safeDuration).toLong()
                        onScrubEnd(target)
                    }
                }
                .pointerInput(safeDuration) {
                    detectHorizontalDragGestures(
                        onDragStart = { offset ->
                            val frac = (offset.x / widthPx).coerceIn(0f, 1f)
                            dragTargetMs = (frac * safeDuration).toLong()
                            onScrubStart(dragTargetMs)
                        },
                        onHorizontalDrag = { change, _ ->
                            change.consume()
                            val frac = (change.position.x / widthPx).coerceIn(0f, 1f)
                            dragTargetMs = (frac * safeDuration).toLong()
                            onScrubMove(dragTargetMs)
                        },
                        onDragEnd = {
                            onScrubEnd(dragTargetMs)
                        },
                        onDragCancel = {
                            onScrubEnd(dragTargetMs)
                        }
                    )
                }
        ) {
            val cy = size.height / 2f
            val trackHeight = if (isScrubbing) 5.dp.toPx() else 3.5.dp.toPx()
            val top = cy - trackHeight / 2f

            // Background dark track
            drawRoundRect(
                color = Color.White.copy(alpha = 0.25f),
                topLeft = Offset(0f, top),
                size = Size(size.width, trackHeight),
                cornerRadius = CornerRadius(trackHeight / 2f)
            )
            // Buffered progress track (light gray)
            drawRoundRect(
                color = Color.White.copy(alpha = 0.55f),
                topLeft = Offset(0f, top),
                size = Size(size.width * bufferedFraction, trackHeight),
                cornerRadius = CornerRadius(trackHeight / 2f)
            )
            // Active fill (YouTube Crimson)
            drawRoundRect(
                color = YouTubeCrimson,
                topLeft = Offset(0f, top),
                size = Size(size.width * activeFraction, trackHeight),
                cornerRadius = CornerRadius(trackHeight / 2f)
            )
            // Tactile scrubber dot
            drawCircle(
                color = YouTubeCrimson,
                radius = thumbRadius.toPx(),
                center = Offset(size.width * activeFraction, cy)
            )
        }
    }
}

fun formatDuration(ms: Long): String {
    val totalSec = (ms / 1000L).coerceAtLeast(0L)
    val hrs = totalSec / 3600L
    val mins = (totalSec % 3600L) / 60L
    val secs = totalSec % 60L
    return if (hrs > 0) {
        String.format("%d:%02d:%02d", hrs, mins, secs)
    } else {
        String.format("%02d:%02d", mins, secs)
    }
}
