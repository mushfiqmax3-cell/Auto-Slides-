package com.example.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.DownloadDone
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.DownloadRecordEntity
import com.example.data.local.UploadStatus
import com.example.data.local.UploadTaskEntity
import com.example.service.formatSpeed
import com.example.telegram.TelegramConnectionState
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.EmeraldConnected

@Composable
fun TransfersScreen(
    connectionState: TelegramConnectionState,
    uploadTasks: List<UploadTaskEntity>,
    downloadRecords: List<DownloadRecordEntity>,
    onOpenConnectionSheet: () -> Unit,
    onOpenUploadPicker: () -> Unit,
    onPauseUpload: (Long) -> Unit,
    onResumeUpload: (Long) -> Unit,
    onCancelUpload: (Long) -> Unit,
    onClearFinishedUploads: () -> Unit,
    onClearCompletedDownloads: () -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 110.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
    ) {
        item(key = "transfers_header") {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Transfers", style = MaterialTheme.typography.displaySmall)
                    Button(
                        onClick = onOpenUploadPicker,
                        shape = RoundedCornerShape(22.dp)
                    ) {
                        Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Upload")
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                TelegramConnectionStatusPill(state = connectionState, onClick = onOpenConnectionSheet)
            }
        }

        item(key = "upload_queue_header") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Upload Queue", style = MaterialTheme.typography.titleLarge)
                if (uploadTasks.any { it.status == UploadStatus.COMPLETED.name || it.status == UploadStatus.CANCELLED.name }) {
                    TextButton(onClick = onClearFinishedUploads) { Text("Clear Finished") }
                }
            }
        }

        if (uploadTasks.isEmpty()) {
            item(key = "uploads_empty") {
                ClodyEmptyStateCard(
                    title = "No active uploads",
                    subtitle = "Background uploads continue even if you exit Clody or lock the screen.",
                    ctaLabel = "Select Files to Upload",
                    onCtaClick = onOpenUploadPicker
                )
            }
        } else {
            items(uploadTasks, key = { "up_${it.id}" }) { task ->
                val pct = if (task.sizeBytes > 0L) (task.bytesUploaded.toFloat() / task.sizeBytes.toFloat()).coerceIn(0f, 1f) else 0f
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    task.fileName,
                                    style = MaterialTheme.typography.titleMedium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                val statusLine = when (task.status) {
                                    UploadStatus.UPLOADING.name ->
                                        "${(pct * 100).toInt()}% • ${formatFileSize(task.bytesUploaded)} / ${formatFileSize(task.sizeBytes)} • ${formatSpeed(task.speedBytesPerSec)}"
                                    UploadStatus.COMPLETED.name -> "Uploaded (${formatFileSize(task.sizeBytes)})"
                                    UploadStatus.FAILED.name -> task.errorMessage ?: "Upload failed"
                                    UploadStatus.PAUSED.name -> task.errorMessage ?: "Paused"
                                    else -> task.status
                                }
                                Text(
                                    statusLine,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = when (task.status) {
                                        UploadStatus.COMPLETED.name -> EmeraldConnected
                                        UploadStatus.FAILED.name -> CrimsonAlert
                                        else -> MaterialTheme.colorScheme.onSurfaceVariant
                                    }
                                )
                            }
                            if (task.status == UploadStatus.UPLOADING.name || task.status == UploadStatus.QUEUED.name) {
                                IconButton(onClick = { onPauseUpload(task.id) }) {
                                    Icon(Icons.Default.Pause, contentDescription = "Pause")
                                }
                            } else if (task.status == UploadStatus.PAUSED.name || task.status == UploadStatus.FAILED.name) {
                                IconButton(onClick = { onResumeUpload(task.id) }) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = "Resume")
                                }
                            }
                            if (task.status != UploadStatus.COMPLETED.name && task.status != UploadStatus.CANCELLED.name) {
                                IconButton(onClick = { onCancelUpload(task.id) }) {
                                    Icon(Icons.Default.Cancel, contentDescription = "Cancel", tint = CrimsonAlert)
                                }
                            }
                        }
                        if (task.status == UploadStatus.UPLOADING.name || task.status == UploadStatus.QUEUED.name || task.status == UploadStatus.PAUSED.name) {
                            Spacer(modifier = Modifier.height(8.dp))
                            LinearProgressIndicator(
                                progress = { pct },
                                modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp))
                            )
                        }
                    }
                }
            }
        }

        item(key = "downloads_header") {
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Public Downloads", style = MaterialTheme.typography.titleLarge)
                if (downloadRecords.isNotEmpty()) {
                    TextButton(onClick = onClearCompletedDownloads) { Text("Clear History") }
                }
            }
        }

        if (downloadRecords.isEmpty()) {
            item(key = "downloads_empty") {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        "Streamed videos & photos stay strictly in private cache until you tap Download.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
        } else {
            items(downloadRecords, key = { "dl_${it.id}" }) { dl ->
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.DownloadDone,
                            contentDescription = null,
                            tint = EmeraldConnected
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(dl.fileName, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                "${dl.publicPath.ifBlank { "Downloads/Clody" }} • ${formatFileSize(dl.sizeBytes)}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}
