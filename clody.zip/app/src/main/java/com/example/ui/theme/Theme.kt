package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

private val ClodyLightColorScheme = lightColorScheme(
    primary = DeepCharcoal,
    onPrimary = PureWhiteSurface,
    primaryContainer = SoftStoneGray,
    onPrimaryContainer = DeepCharcoal,
    secondary = MutedCharcoalText,
    onSecondary = PureWhiteSurface,
    secondaryContainer = SoftStoneGray,
    onSecondaryContainer = DeepCharcoal,
    tertiary = VideoIconIndigo,
    onTertiary = PureWhiteSurface,
    tertiaryContainer = VideoTintSurface,
    onTertiaryContainer = VideoIconIndigo,
    background = AlabasterCanvas,
    onBackground = DeepCharcoal,
    surface = PureWhiteSurface,
    onSurface = DeepCharcoal,
    surfaceVariant = SoftStoneGray,
    onSurfaceVariant = MutedCharcoalText,
    outline = WarmBorderGray,
    error = CrimsonAlert,
    onError = PureWhiteSurface
)

private val ClodyDarkColorScheme = darkColorScheme(
    primary = AlabasterCanvas,
    onPrimary = DeepCharcoal,
    primaryContainer = DarkSecondarySurface,
    onPrimaryContainer = DarkTextPrimary,
    secondary = DarkTextSecondary,
    onSecondary = DarkCanvas,
    secondaryContainer = DarkSecondarySurface,
    onSecondaryContainer = DarkTextPrimary,
    tertiary = Color(0xFF9E8CFF),
    onTertiary = DeepCharcoal,
    tertiaryContainer = Color(0xFF28233C),
    onTertiaryContainer = Color(0xFFDCD6FF),
    background = DarkCanvas,
    onBackground = DarkTextPrimary,
    surface = DarkSurface,
    onSurface = DarkTextPrimary,
    surfaceVariant = DarkSecondarySurface,
    onSurfaceVariant = DarkTextSecondary,
    outline = Color(0xFF343430),
    error = Color(0xFFEF4444),
    onError = PureWhiteSurface
)

val ClodyShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

val LocalAnimationsEnabled = staticCompositionLocalOf { true }

@Composable
fun ClodyTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    animationsEnabled: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> ClodyDarkColorScheme
        else -> ClodyLightColorScheme
    }

    CompositionLocalProvider(LocalAnimationsEnabled provides animationsEnabled) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = ClodyTypography,
            shapes = ClodyShapes,
            content = content
        )
    }
}
