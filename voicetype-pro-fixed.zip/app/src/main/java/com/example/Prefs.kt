package com.example

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

enum class EngineMode(val id: String, val displayLabel: String, val bengaliSubtitle: String) {
    AUTO_HYBRID(
        "AUTO_HYBRID",
        "Auto-Hybrid",
        "অটো-হাইব্রিড (Gemini AI + অফলাইন ফলব্যাক)"
    ),
    GEMINI_ONLY(
        "GEMINI_ONLY",
        "Gemini AI",
        "শুধুমাত্র অনলাইন জেমিনি এআই (বাংলা + English)"
    ),
    OFFLINE_ONLY(
        "OFFLINE_ONLY",
        "Offline On-Device",
        "সম্পূর্ণ ইন্টারনেট ছাড়া অন-ডিভাইস ভয়েস টাইপিং"
    );

    companion object {
        fun fromId(id: String?): EngineMode {
            return entries.firstOrNull { it.id == id } ?: AUTO_HYBRID
        }
    }
}

enum class OfflineLanguageMode(val localeTag: String, val label: String) {
    BENGALI_BD("bn-BD", "বাংলা (bn-BD)"),
    ENGLISH_US("en-US", "English (en-US)"),
    DEVICE_DEFAULT("", "Device Default (ডিফল্ট ভাষা)");

    companion object {
        fun fromTag(tag: String?): OfflineLanguageMode {
            return entries.firstOrNull { it.localeTag == tag } ?: BENGALI_BD
        }
    }
}

data class TranscriptionRecord(
    val id: Long,
    val text: String,
    val timestamp: Long,
    val modelUsed: String
)

/**
 * Manages secure storage for the Gemini API key via EncryptedSharedPreferences,
 * hybrid engine mode, offline language selection, model configuration,
 * last floating bubble position, and the last 20 transcriptions.
 */
object Prefs {
    private const val ENCRYPTED_PREFS_NAME = "voicetype_secure_prefs"
    private const val STANDARD_PREFS_NAME = "voicetype_standard_prefs"

    private const val KEY_API_KEY = "gemini_api_key"
    private const val KEY_SEEDED_INITIAL = "seeded_initial_key"
    private const val KEY_MODEL_NAME = "gemini_model_name"
    private const val KEY_ENGINE_MODE = "speech_engine_mode"
    private const val KEY_OFFLINE_LANGUAGE = "offline_language_tag"
    private const val KEY_BUBBLE_X = "bubble_pos_x"
    private const val KEY_BUBBLE_Y = "bubble_pos_y"
    private const val KEY_HISTORY_JSON = "transcription_history_json"

    const val DEFAULT_MODEL_NAME = "gemini-3.8-flash"
    const val FALLBACK_MODEL_NAME = "gemini-3.5-flash-lite"
    private const val MAX_HISTORY_ITEMS = 20

    private val _historyFlow = MutableStateFlow<List<TranscriptionRecord>>(emptyList())
    val historyFlow: StateFlow<List<TranscriptionRecord>> = _historyFlow.asStateFlow()

    private val _engineModeFlow = MutableStateFlow(EngineMode.AUTO_HYBRID)
    val engineModeFlow: StateFlow<EngineMode> = _engineModeFlow.asStateFlow()

    private val _offlineLanguageFlow = MutableStateFlow(OfflineLanguageMode.BENGALI_BD)
    val offlineLanguageFlow: StateFlow<OfflineLanguageMode> = _offlineLanguageFlow.asStateFlow()

    private fun getSecurePrefs(context: Context): SharedPreferences {
        return try {
            val masterKey = MasterKey.Builder(context.applicationContext)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                context.applicationContext,
                ENCRYPTED_PREFS_NAME,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            context.applicationContext.getSharedPreferences(ENCRYPTED_PREFS_NAME, Context.MODE_PRIVATE)
        }
    }

    private fun getStandardPrefs(context: Context): SharedPreferences {
        return context.applicationContext.getSharedPreferences(STANDARD_PREFS_NAME, Context.MODE_PRIVATE)
    }

    fun init(context: Context) {
        val securePrefs = getSecurePrefs(context)
        val alreadySeeded = securePrefs.getBoolean(KEY_SEEDED_INITIAL, false)
        if (!alreadySeeded) {
            val buildConfigKey = try {
                BuildConfig.GEMINI_API_KEY
            } catch (_: Exception) {
                ""
            }
            if (buildConfigKey.isNotBlank() &&
                buildConfigKey != "MY_GEMINI_API_KEY" &&
                buildConfigKey != "null"
            ) {
                securePrefs.edit()
                    .putString(KEY_API_KEY, buildConfigKey.trim())
                    .putBoolean(KEY_SEEDED_INITIAL, true)
                    .apply()
            } else {
                securePrefs.edit()
                    .putBoolean(KEY_SEEDED_INITIAL, true)
                    .apply()
            }
        }

        // Migrate legacy invalid default model "gemini-3.5-transcribe" to "gemini-2.5-flash"
        val stdPrefs = getStandardPrefs(context)
        val currentModel = stdPrefs.getString(KEY_MODEL_NAME, null)
        if (currentModel == null || currentModel == "gemini-3.5-transcribe" || currentModel.startsWith("gemini-2.")) {
            stdPrefs.edit().putString(KEY_MODEL_NAME, DEFAULT_MODEL_NAME).apply()
        }

        _engineModeFlow.value = getEngineMode(context)
        _offlineLanguageFlow.value = getOfflineLanguage(context)
        _historyFlow.value = loadHistory(context)
    }

    fun getApiKey(context: Context): String {
        val stored = getSecurePrefs(context).getString(KEY_API_KEY, "")?.trim().orEmpty()
        if (stored.isNotEmpty()) return stored

        val buildConfigKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (_: Exception) {
            ""
        }
        return if (buildConfigKey.isNotBlank() &&
            buildConfigKey != "MY_GEMINI_API_KEY" &&
            buildConfigKey != "null"
        ) {
            buildConfigKey.trim()
        } else {
            ""
        }
    }

    fun saveApiKey(context: Context, apiKey: String) {
        getSecurePrefs(context).edit()
            .putString(KEY_API_KEY, apiKey.trim())
            .putBoolean(KEY_SEEDED_INITIAL, true)
            .apply()
    }

    fun getModelName(context: Context): String {
        val stored = getStandardPrefs(context).getString(KEY_MODEL_NAME, DEFAULT_MODEL_NAME)?.trim()
        return if (stored.isNullOrEmpty() || stored == "gemini-3.5-transcribe" || stored.startsWith("gemini-2.")) {
            DEFAULT_MODEL_NAME
        } else {
            stored
        }
    }

    fun saveModelName(context: Context, modelName: String) {
        val clean = modelName.trim().ifEmpty { DEFAULT_MODEL_NAME }
        getStandardPrefs(context).edit().putString(KEY_MODEL_NAME, clean).apply()
    }

    fun getEngineMode(context: Context): EngineMode {
        val raw = getStandardPrefs(context).getString(KEY_ENGINE_MODE, EngineMode.AUTO_HYBRID.id)
        return EngineMode.fromId(raw)
    }

    fun saveEngineMode(context: Context, mode: EngineMode) {
        getStandardPrefs(context).edit().putString(KEY_ENGINE_MODE, mode.id).apply()
        _engineModeFlow.value = mode
    }

    fun getOfflineLanguage(context: Context): OfflineLanguageMode {
        val raw = getStandardPrefs(context).getString(
            KEY_OFFLINE_LANGUAGE,
            OfflineLanguageMode.BENGALI_BD.localeTag
        )
        return OfflineLanguageMode.fromTag(raw)
    }

    fun saveOfflineLanguage(context: Context, languageMode: OfflineLanguageMode) {
        getStandardPrefs(context).edit()
            .putString(KEY_OFFLINE_LANGUAGE, languageMode.localeTag)
            .apply()
        _offlineLanguageFlow.value = languageMode
    }

    fun saveBubblePosition(context: Context, x: Int, y: Int) {
        getStandardPrefs(context).edit()
            .putInt(KEY_BUBBLE_X, x)
            .putInt(KEY_BUBBLE_Y, y)
            .apply()
    }

    fun getBubblePosition(context: Context, defaultX: Int = 0, defaultY: Int = 260): Pair<Int, Int> {
        val prefs = getStandardPrefs(context)
        val x = prefs.getInt(KEY_BUBBLE_X, defaultX)
        val y = prefs.getInt(KEY_BUBBLE_Y, defaultY)
        return x to y
    }

    fun addHistoryItem(context: Context, text: String, modelUsed: String) {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return

        val current = loadHistory(context).toMutableList()
        val now = System.currentTimeMillis()
        current.add(
            0,
            TranscriptionRecord(
                id = now,
                text = trimmed,
                timestamp = now,
                modelUsed = modelUsed
            )
        )
        val capped = current.take(MAX_HISTORY_ITEMS)
        saveHistory(context, capped)
        _historyFlow.value = capped
    }

    fun clearHistory(context: Context) {
        getStandardPrefs(context).edit().remove(KEY_HISTORY_JSON).apply()
        _historyFlow.value = emptyList()
    }

    fun loadHistory(context: Context): List<TranscriptionRecord> {
        val raw = getStandardPrefs(context).getString(KEY_HISTORY_JSON, null) ?: return emptyList()
        return try {
            val array = JSONArray(raw)
            val result = mutableListOf<TranscriptionRecord>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                result.add(
                    TranscriptionRecord(
                        id = obj.optLong("id", System.currentTimeMillis() + i),
                        text = obj.optString("text", ""),
                        timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                        modelUsed = obj.optString("modelUsed", DEFAULT_MODEL_NAME)
                    )
                )
            }
            result.filter { it.text.isNotBlank() }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun saveHistory(context: Context, list: List<TranscriptionRecord>) {
        val array = JSONArray()
        for (item in list) {
            val obj = JSONObject().apply {
                put("id", item.id)
                put("text", item.text)
                put("timestamp", item.timestamp)
                put("modelUsed", item.modelUsed)
            }
            array.put(obj)
        }
        getStandardPrefs(context).edit().putString(KEY_HISTORY_JSON, array.toString()).apply()
    }
}
