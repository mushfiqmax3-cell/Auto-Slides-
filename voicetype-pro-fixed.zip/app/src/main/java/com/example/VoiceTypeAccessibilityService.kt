package com.example

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import android.text.TextUtils
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * AccessibilityService that tracks the currently focused editable text field in any external app
 * and enables VoiceType Pro to insert transcribed Bengali + English text at the active cursor.
 */
class VoiceTypeAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: VoiceTypeAccessibilityService? = null
            private set

        @Volatile
        var lastFocusedEditableNode: AccessibilityNodeInfo? = null
            private set

        /**
         * Inserts transcribed text into the currently focused editable field across any app,
         * or falls back to clipboard paste/copy if no node is accessible.
         */
        fun insertTranscribedText(context: Context, text: String): InsertionOutcome {
            return TextInserter.insertText(
                context = context,
                service = instance,
                cachedFocusedNode = lastFocusedEditableNode,
                transcribedText = text
            )
        }

        /**
         * Undoes the last inserted transcription if performed within 30 seconds.
         */
        fun performUndoIfAvailable(context: Context): Boolean {
            return TextInserter.undoLastInsertion(
                context = context,
                service = instance,
                cachedFocusedNode = lastFocusedEditableNode
            )
        }

        /**
         * Checks whether VoiceTypeAccessibilityService is enabled in system Accessibility settings.
         */
        fun isServiceEnabled(context: Context): Boolean {
            if (instance != null) return true
            val expectedComponent = ComponentName(context, VoiceTypeAccessibilityService::class.java)
            val enabledServices = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false

            val splitter = TextUtils.SimpleStringSplitter(':')
            splitter.setString(enabledServices)
            while (splitter.hasNext()) {
                val componentNameString = splitter.next()
                val enabledComponent = ComponentName.unflattenFromString(componentNameString)
                if (enabledComponent != null && enabledComponent == expectedComponent) {
                    return true
                }
            }
            return false
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString()
        // Ignore events originating from our own overlay window
        if (pkg == packageName) return

        val source = event.source
        if (source != null && source.isEditable) {
            lastFocusedEditableNode = source
            return
        }

        // Also check active window focus if focus changed
        if (event.eventType == AccessibilityEvent.TYPE_VIEW_FOCUSED ||
            event.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_SELECTION_CHANGED ||
            event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
        ) {
            val root = try {
                rootInActiveWindow
            } catch (_: Exception) {
                null
            }
            val focused = root?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            if (focused != null &&
                focused.isEditable &&
                focused.packageName?.toString() != packageName
            ) {
                lastFocusedEditableNode = focused
            }
        }
    }

    override fun onInterrupt() {
        // Required override for AccessibilityService
    }

    override fun onDestroy() {
        if (instance === this) {
            instance = null
        }
        lastFocusedEditableNode = null
        super.onDestroy()
    }
}
