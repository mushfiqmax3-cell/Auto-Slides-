package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.TextButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.StatusRed
import com.example.ui.theme.VoiceTypeProTheme
import kotlinx.coroutines.delay

class SettingsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        enableEdgeToEdge()
        setContent {
            VoiceTypeProTheme {
                SettingsScreen(onBack = { finish() })
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val context = LocalContext.current

    var apiKeys by remember { mutableStateOf(Prefs.getApiKeys()) }
    var showAddDialog by rememberSaveable { mutableStateOf(false) }
    var newKeyInput by rememberSaveable { mutableStateOf("") }
    var selectedModel by rememberSaveable { mutableStateOf(Prefs.getModelName(context)) }
    var models by remember { mutableStateOf<List<String>>(emptyList()) }
    var isLoadingModels by remember { mutableStateOf(false) }
    var modelStatus by remember { mutableStateOf<String?>(null) }
    var modelStatusIsError by remember { mutableStateOf(false) }
    var dropdownExpanded by remember { mutableStateOf(false) }

    val syncWithKeyboard by Prefs.syncKeyboardFlow.collectAsState()

    // Whenever the key list changes, load the model list using the first key.
    LaunchedEffect(apiKeys) {
        val key = apiKeys.firstOrNull().orEmpty()
        if (key.isEmpty()) {
            models = emptyList()
            modelStatus = null
            return@LaunchedEffect
        }
        isLoadingModels = true
        modelStatus = null
        GeminiTranscriber.fetchAvailableModels(key).fold(
            onSuccess = { list ->
                models = list
                modelStatusIsError = false
                modelStatus = if (list.isEmpty()) {
                    "No usable models found for this key"
                } else {
                    "${list.size} models available (মডেল পাওয়া গেছে)"
                }
                if (list.isNotEmpty() && selectedModel !in list) {
                    // The saved model is not offered for this key (e.g. retired): keep it visible,
                    // the user picks a new one from the list.
                    modelStatus += " — pick a model below"
                }
            },
            onFailure = { err ->
                models = emptyList()
                modelStatusIsError = true
                modelStatus = err.localizedMessage ?: "Could not load models."
            }
        )
        isLoadingModels = false
    }

    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Add API Key") },
            text = {
                OutlinedTextField(
                    value = newKeyInput,
                    onValueChange = { newKeyInput = it },
                    label = { Text("Paste Gemini API key") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("api_key_field")
                )
            },
            confirmButton = {
                TextButton(
                    enabled = newKeyInput.isNotBlank(),
                    onClick = {
                        Prefs.addApiKey(newKeyInput)
                        apiKeys = Prefs.getApiKeys()
                        newKeyInput = ""
                        showAddDialog = false
                    }
                ) { Text("Add") }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) { Text("Cancel") }
            }
        )
    }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .widthIn(max = 600.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header with back arrow
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = MaterialTheme.colorScheme.onBackground
                    )
                }
                Text(
                    text = "Settings (সেটিংস)",
                    color = MaterialTheme.colorScheme.onBackground,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            // API keys (rotation list)
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Gemini API Keys (এপিআই কী)",
                    color = MaterialTheme.colorScheme.onBackground,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium
                )
                Button(
                    onClick = {
                        newKeyInput = ""
                        showAddDialog = true
                    },
                    modifier = Modifier.testTag("add_key_button")
                ) {
                    Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("+ Add Key")
                }
            }

            if (apiKeys.isEmpty()) {
                Text(
                    text = "No API key yet. Tap + Add Key to paste one (কোনো কী নেই)",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 13.sp
                )
            }
            apiKeys.forEach { key ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("api_key_row"),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = maskApiKey(key),
                        color = MaterialTheme.colorScheme.onBackground,
                        fontSize = 15.sp,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = {
                        Prefs.removeApiKey(key)
                        apiKeys = Prefs.getApiKeys()
                    }) {
                        Icon(
                            imageVector = Icons.Filled.Delete,
                            contentDescription = "Delete key",
                            tint = StatusRed
                        )
                    }
                }
            }
            Text(
                text = "Add multiple keys to rotate requests automatically. This prevents quota throttling and speeds up responses (একাধিক কী দিলে রিকুয়েস্ট ঘুরে ঘুরে যাবে)",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 12.sp
            )

            // Model dropdown (filled from the API)
            ExposedDropdownMenuBox(
                expanded = dropdownExpanded,
                onExpandedChange = { if (models.isNotEmpty()) dropdownExpanded = !dropdownExpanded }
            ) {
                OutlinedTextField(
                    value = selectedModel,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Model (মডেল)") },
                    trailingIcon = {
                        if (isLoadingModels) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                        } else {
                            ExposedDropdownMenuDefaults.TrailingIcon(expanded = dropdownExpanded)
                        }
                    },
                    modifier = Modifier
                        .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                        .fillMaxWidth()
                        .testTag("model_dropdown")
                )
                ExposedDropdownMenu(
                    expanded = dropdownExpanded,
                    onDismissRequest = { dropdownExpanded = false }
                ) {
                    models.forEach { model ->
                        DropdownMenuItem(
                            text = { Text(model) },
                            onClick = {
                                selectedModel = model
                                Prefs.saveModelName(context, model)
                                dropdownExpanded = false
                            }
                        )
                    }
                }
            }
            modelStatus?.let {
                Text(
                    text = it,
                    color = if (modelStatusIsError) StatusRed else StatusGreen,
                    fontSize = 13.sp
                )
            }
            if (apiKeys.isEmpty()) {
                Text(
                    text = "Enter your API key to load the available models (এপিআই কী দিলে মডেল তালিকা আসবে)",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 13.sp
                )
            }

            Spacer(modifier = Modifier.height(4.dp))
            HorizontalDivider()
            Spacer(modifier = Modifier.height(4.dp))

            // Sync with Keyboard
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Sync with Keyboard (কীবোর্ডের সাথে সিঙ্ক)",
                        color = MaterialTheme.colorScheme.onBackground,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "Show the floating mic only while a text field is focused. Requires the Accessibility service.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 13.sp
                    )
                }
                Switch(
                    checked = syncWithKeyboard,
                    onCheckedChange = { Prefs.saveSyncWithKeyboard(context, it) },
                    modifier = Modifier.testTag("sync_keyboard_switch")
                )
            }
        }
    }
}

/** `AIzaSy...4xK9` style mask: first 6 and last 4 characters only. */
internal fun maskApiKey(key: String): String =
    if (key.length <= 12) "••••••" else key.take(6) + "..." + key.takeLast(4)
