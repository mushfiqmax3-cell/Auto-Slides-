package com.example.telegram

import android.content.Context
import android.os.Build
import com.example.data.local.ClodyDao
import com.example.data.local.FileEntity
import com.example.data.local.FolderEntity
import com.example.data.local.GalleryAlbumEntity
import com.example.data.local.SecureStorage
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import org.drinkless.tdlib.Client
import org.drinkless.tdlib.TdApi
import java.io.File
import java.io.RandomAccessFile
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

sealed interface TelegramConnectionState {
    data class Disconnected(val reason: String? = null) : TelegramConnectionState
    data class Connecting(val dcId: Int) : TelegramConnectionState
    data class Connected(val dcId: Int, val userDisplayName: String?) : TelegramConnectionState
}

sealed interface TelegramAuthStep {
    data object VerifyApiCredentials : TelegramAuthStep
    data class EnterPhoneNumber(val apiId: Int, val apiHash: String) : TelegramAuthStep
    data class AwaitingOtp(val phoneNumber: String, val phoneCodeHash: String) : TelegramAuthStep
    data class AwaitingPassword(val hint: String) : TelegramAuthStep
    data class Authorized(val displayName: String, val phoneNumber: String) : TelegramAuthStep
}

enum class VerifyOtpOutcome {
    AUTHORIZED,
    NEEDS_TWO_FACTOR
}

data class TelegramUserProfile(
    val userId: Long,
    val firstName: String,
    val lastName: String,
    val username: String?,
    val phoneNumber: String?,
    val avatarPath: String? = null
) {
    val fullName: String
        get() = listOf(firstName, lastName).filter { it.isNotBlank() }.joinToString(" ")
            .ifBlank { phoneNumber?.takeIf { it.isNotBlank() } ?: "Telegram User" }

    val handleOrPhone: String
        get() = when {
            !username.isNullOrBlank() -> "@$username"
            !phoneNumber.isNullOrBlank() -> phoneNumber
            else -> "Telegram Cloud"
        }

    val initials: String
        get() {
            val f = firstName.firstOrNull()?.uppercaseChar()
            val l = lastName.firstOrNull()?.uppercaseChar()
            return when {
                f != null && l != null -> "$f$l"
                f != null -> "$f"
                else -> "TG"
            }
        }
}

data class TelegramUploadedDocument(
    val messageId: Int,
    val documentId: Long,
    val accessHash: Long,
    val fileReference: ByteArray,
    val dcId: Int,
    val mimeType: String,
    val sizeBytes: Long
)

@Serializable
data class CloudIndexSnapshot(
    val version: Int = 2,
    val updatedAt: Long = System.currentTimeMillis(),
    val folders: List<FolderEntity> = emptyList(),
    val albums: List<GalleryAlbumEntity> = emptyList(),
    val files: List<FileEntity> = emptyList()
)

class TelegramTdException(
    val code: Int,
    val rawMessage: String,
    val userMessage: String
) : Exception(userMessage)

class TelegramClientManager(
    private val context: Context,
    private val secureStorage: SecureStorage,
    private val dao: ClodyDao
) {
    companion object {
        const val STANDARD_MAX_FILE_BYTES: Long = 2_000L * 1024L * 1024L // 2 GB (4000 parts of 512 KB)
        const val PREMIUM_MAX_FILE_BYTES: Long = 4_000L * 1024L * 1024L // 4 GB (8000 parts of 512 KB)
        const val DEFAULT_CHUNK_SIZE: Int = 512 * 1024 // 512 KB streaming chunk size

        fun formatTdError(error: TdApi.Error): String {
            val raw = error.message?.trim().orEmpty()
            return when {
                raw.equals("API_ID_INVALID", ignoreCase = true) ->
                    "API_ID_INVALID: Your Telegram API ID or API Hash was rejected by Telegram."
                raw.equals("API_HASH_INVALID", ignoreCase = true) ->
                    "API_HASH_INVALID: Your 32-character Telegram API Hash is invalid."
                raw.equals("PHONE_NUMBER_INVALID", ignoreCase = true) ->
                    "PHONE_NUMBER_INVALID: Enter a valid phone number in international format (e.g. +8801...)."
                raw.equals("PHONE_NUMBER_BANNED", ignoreCase = true) ->
                    "PHONE_NUMBER_BANNED: This phone number is restricted by Telegram."
                raw.equals("PHONE_CODE_INVALID", ignoreCase = true) ->
                    "PHONE_CODE_INVALID: The verification code you entered is incorrect."
                raw.equals("PHONE_CODE_EXPIRED", ignoreCase = true) ->
                    "PHONE_CODE_EXPIRED: The verification code has expired. Tap Resend Code."
                raw.equals("PASSWORD_HASH_INVALID", ignoreCase = true) ->
                    "PASSWORD_HASH_INVALID: Incorrect 2FA cloud password."
                raw.startsWith("FLOOD_WAIT_", ignoreCase = true) -> {
                    val secs = raw.substringAfter("FLOOD_WAIT_").filter(Char::isDigit).toIntOrNull()
                    if (secs != null) {
                        "FLOOD_WAIT_$secs: Too many attempts. Please wait $secs seconds before trying again."
                    } else {
                        "$raw: Too many attempts. Please wait before trying again."
                    }
                }
                raw.startsWith("CHANNELS_TOO_MUCH", ignoreCase = true) ->
                    "CHANNELS_TOO_MUCH: Channel limit reached; using Saved Messages as fallback."
                raw.isNotBlank() ->
                    if (error.code > 0 && !raw.contains("code ${error.code}")) "$raw (code ${error.code})" else raw
                else -> "Telegram error (code ${error.code})"
            }
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val sessionMutex = Mutex()
    private val clientLock = Any()
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    @Volatile
    private var tdClient: Client? = null

    @Volatile
    private var isPremiumAccount: Boolean = false

    private val _tdAuthorizationState = MutableStateFlow<TdApi.AuthorizationState?>(null)
    private val fileProgressListeners = ConcurrentHashMap<Int, (TdApi.File) -> Unit>()
    private val pendingMessageSends = ConcurrentHashMap<Long, CompletableDeferred<TdApi.Message>>()
    private val remoteToLocalFileIdCache = ConcurrentHashMap<String, Int>()
    private var pendingParameterInit: CompletableDeferred<Unit>? = null

    private val _connectionState = MutableStateFlow<TelegramConnectionState>(
        TelegramConnectionState.Disconnected(null)
    )
    val connectionState: StateFlow<TelegramConnectionState> = _connectionState.asStateFlow()

    private val _authStep = MutableStateFlow<TelegramAuthStep>(
        if (secureStorage.isLoggedIn()) {
            TelegramAuthStep.Authorized(
                displayName = secureStorage.getUserDisplayName() ?: "Telegram User",
                phoneNumber = secureStorage.getPhoneNumber() ?: ""
            )
        } else {
            TelegramAuthStep.VerifyApiCredentials
        }
    )
    val authStep: StateFlow<TelegramAuthStep> = _authStep.asStateFlow()

    private val _userProfile = MutableStateFlow<TelegramUserProfile?>(
        if (secureStorage.isLoggedIn()) {
            TelegramUserProfile(
                userId = secureStorage.getUserId(),
                firstName = secureStorage.getFirstName().ifBlank { secureStorage.getUserDisplayName().orEmpty() },
                lastName = secureStorage.getLastName(),
                username = secureStorage.getUsername(),
                phoneNumber = secureStorage.getPhoneNumber(),
                avatarPath = secureStorage.getAvatarPath()
            )
        } else null
    )
    val userProfile: StateFlow<TelegramUserProfile?> = _userProfile.asStateFlow()

    private var pendingPhone: String = secureStorage.getPhoneNumber().orEmpty()

    private val updateHandler = Client.ResultHandler { obj ->
        when (obj) {
            is TdApi.UpdateAuthorizationState -> handleAuthorizationState(obj.authorizationState)
            is TdApi.UpdateConnectionState -> handleConnectionState(obj.state)
            is TdApi.UpdateFile -> handleFileUpdate(obj.file)
            is TdApi.UpdateMessageSendSucceeded -> {
                pendingMessageSends.remove(obj.oldMessageId)?.complete(obj.message)
            }
            is TdApi.UpdateMessageSendFailed -> {
                val err = obj.error ?: TdApi.Error(500, "Message send failed")
                pendingMessageSends.remove(obj.oldMessageId)?.completeExceptionally(
                    TelegramTdException(err.code, err.message.orEmpty(), formatTdError(err))
                )
            }
            is TdApi.UpdateNewMessage -> {
                // Keep internal file cache updated if new document arrives in storage channel
                val msg = obj.message
                val docFile = extractTdFileFromMessage(msg)
                if (docFile != null && !docFile.remote?.id.isNullOrBlank() && docFile.id != 0) {
                    remoteToLocalFileIdCache[docFile.remote.id] = docFile.id
                }
            }
        }
    }

    init {
        if (secureStorage.isLoggedIn() && secureStorage.getApiId() != null) {
            scope.launch { runCatching { reconnectIfAuthorized() } }
        }
    }

    private fun getOrCreateTdClient(): Client {
        synchronized(clientLock) {
            val existing = tdClient
            if (existing != null) return existing
            Client.setLogMessageHandler(1, null)
            val created = Client.create(
                updateHandler,
                { _ -> },
                { _ -> }
            )
            created.send(TdApi.SetLogVerbosityLevel(1), null)
            tdClient = created
            return created
        }
    }

    private fun buildTdlibParameters(apiId: Int, apiHash: String): TdApi.SetTdlibParameters {
        val dbDir = File(context.filesDir, "tdlib_db").apply { mkdirs() }.absolutePath
        val filesDir = File(context.filesDir, "tdlib_files").apply { mkdirs() }.absolutePath
        val lang = Locale.getDefault().language.ifBlank { "en" }
        val model = "${Build.MANUFACTURER} ${Build.MODEL}".trim().ifBlank { "Android Device" }
        val sysVer = "Android ${Build.VERSION.RELEASE ?: "14"}"

        return TdApi.SetTdlibParameters(
            /* useTestDc = */ false,
            /* databaseDirectory = */ dbDir,
            /* filesDirectory = */ filesDir,
            /* databaseEncryptionKey = */ ByteArray(0),
            /* useFileDatabase = */ true,
            /* useChatInfoDatabase = */ true,
            /* useMessageDatabase = */ true,
            /* useSecretChats = */ false,
            /* apiId = */ apiId,
            /* apiHash = */ apiHash,
            /* systemLanguageCode = */ lang,
            /* deviceModel = */ model,
            /* systemVersion = */ sysVer,
            /* applicationVersion = */ "1.0.0"
        )
    }

    private fun handleAuthorizationState(state: TdApi.AuthorizationState?) {
        if (state == null) return
        _tdAuthorizationState.value = state

        when (state) {
            is TdApi.AuthorizationStateWaitTdlibParameters -> {
                val apiId = secureStorage.getApiId()
                val apiHash = secureStorage.getApiHash()
                if (apiId != null && apiId > 0 && !apiHash.isNullOrBlank()) {
                    val params = buildTdlibParameters(apiId, apiHash)
                    tdClient?.send(params) { result ->
                        if (result is TdApi.Error) {
                            val ex = TelegramTdException(result.code, result.message.orEmpty(), formatTdError(result))
                            pendingParameterInit?.completeExceptionally(ex)
                            _connectionState.value = TelegramConnectionState.Disconnected(ex.userMessage)
                        } else {
                            pendingParameterInit?.complete(Unit)
                        }
                    }
                }
            }

            is TdApi.AuthorizationStateWaitPhoneNumber -> {
                pendingParameterInit?.complete(Unit)
                val apiId = secureStorage.getApiId() ?: 0
                val apiHash = secureStorage.getApiHash().orEmpty()
                _connectionState.value = TelegramConnectionState.Connected(
                    dcId = secureStorage.getActiveDc(),
                    userDisplayName = null
                )
                if (apiId > 0 && apiHash.isNotBlank()) {
                    _authStep.value = TelegramAuthStep.EnterPhoneNumber(apiId, apiHash)
                } else {
                    _authStep.value = TelegramAuthStep.VerifyApiCredentials
                }
            }

            is TdApi.AuthorizationStateWaitCode -> {
                pendingParameterInit?.complete(Unit)
                val phone = state.codeInfo?.phoneNumber?.takeIf { it.isNotBlank() }
                    ?.let { if (it.startsWith("+")) it else "+$it" }
                    ?: pendingPhone.ifBlank { secureStorage.getPhoneNumber().orEmpty() }
                pendingPhone = phone
                _authStep.value = TelegramAuthStep.AwaitingOtp(phone, "tdlib_code_session")
            }

            is TdApi.AuthorizationStateWaitPassword -> {
                pendingParameterInit?.complete(Unit)
                _authStep.value = TelegramAuthStep.AwaitingPassword(state.passwordHint.orEmpty())
            }

            is TdApi.AuthorizationStateReady -> {
                pendingParameterInit?.complete(Unit)
                secureStorage.setLoggedIn(true)
                val displayName = secureStorage.getUserDisplayName() ?: "Telegram User"
                val phone = secureStorage.getPhoneNumber().orEmpty()
                _connectionState.value = TelegramConnectionState.Connected(
                    dcId = secureStorage.getActiveDc(),
                    userDisplayName = displayName
                )
                _authStep.value = TelegramAuthStep.Authorized(displayName, phone)
                scope.launch {
                    runCatching { fetchCurrentUserProfileInternal() }
                    runCatching { ensureStorageChannelInternal() }
                }
            }

            is TdApi.AuthorizationStateLoggingOut,
            is TdApi.AuthorizationStateClosing -> {
                _connectionState.value = TelegramConnectionState.Disconnected(null)
            }

            is TdApi.AuthorizationStateClosed -> {
                synchronized(clientLock) {
                    tdClient = null
                }
                if (!secureStorage.isLoggedIn()) {
                    _connectionState.value = TelegramConnectionState.Disconnected(null)
                    _authStep.value = TelegramAuthStep.VerifyApiCredentials
                }
            }
        }
    }

    private fun handleConnectionState(state: TdApi.ConnectionState?) {
        val dc = secureStorage.getActiveDc()
        when (state) {
            is TdApi.ConnectionStateWaitingForNetwork,
            is TdApi.ConnectionStateConnectingToProxy,
            is TdApi.ConnectionStateConnecting,
            is TdApi.ConnectionStateUpdating -> {
                _connectionState.value = TelegramConnectionState.Connecting(dc)
            }
            is TdApi.ConnectionStateReady -> {
                _connectionState.value = TelegramConnectionState.Connected(
                    dcId = dc,
                    userDisplayName = secureStorage.getUserDisplayName()
                )
            }
        }
    }

    private fun handleFileUpdate(file: TdApi.File?) {
        if (file == null) return
        if (!file.remote?.id.isNullOrBlank() && file.id != 0) {
            remoteToLocalFileIdCache[file.remote.id] = file.id
        }
        fileProgressListeners[file.id]?.invoke(file)
    }

    private suspend fun <T : TdApi.Object> sendTdQuery(query: TdApi.Function<T>): T =
        suspendCancellableCoroutine { cont ->
            val client = getOrCreateTdClient()
            client.send(query) { result ->
                if (!cont.isActive) return@send
                when (result) {
                    is TdApi.Error -> {
                        cont.resumeWithException(
                            TelegramTdException(
                                code = result.code,
                                rawMessage = result.message.orEmpty(),
                                userMessage = formatTdError(result)
                            )
                        )
                    }
                    else -> {
                        @Suppress("UNCHECKED_CAST")
                        val typed = result as? T
                        if (typed != null) {
                            cont.resume(typed)
                        } else {
                            cont.resumeWithException(
                                IllegalStateException(
                                    "Unexpected TDLib response type: ${result?.javaClass?.simpleName}"
                                )
                            )
                        }
                    }
                }
            }
        }

    suspend fun reconnectIfAuthorized(): Result<Unit> = sessionMutex.withLock {
        val apiId = secureStorage.getApiId()
            ?: return Result.failure(IllegalStateException("Missing API ID"))
        val apiHash = secureStorage.getApiHash()
            ?: return Result.failure(IllegalStateException("Missing API Hash"))
        if (!secureStorage.isLoggedIn()) {
            return Result.failure(IllegalStateException("Not logged in"))
        }

        return runCatching {
            withContext(Dispatchers.IO) {
                _connectionState.value = TelegramConnectionState.Connecting(secureStorage.getActiveDc())
                val state = sendTdQuery(TdApi.GetAuthorizationState())
                handleAuthorizationState(state)
                if (state is TdApi.AuthorizationStateWaitTdlibParameters) {
                    sendTdQuery(buildTdlibParameters(apiId, apiHash))
                }
                ensureStorageChannelInternal()
                runCatching { fetchCurrentUserProfileInternal() }
                Unit
            }
        }.onFailure { err ->
            _connectionState.value = TelegramConnectionState.Disconnected(err.message ?: "Connection failed")
        }
    }

    /**
     * Step 1: Validate API ID (positive integer) and API Hash (32 hex chars),
     * save them in SecureStorage, and initialize TDLib via SetTdlibParameters.
     */
    suspend fun verifyApiCredentials(
        apiId: Int,
        apiHash: String,
        onProgressLabel: (String) -> Unit = {}
    ): Result<Unit> = sessionMutex.withLock {
        val cleanHash = apiHash.trim()
        if (apiId <= 0) {
            return Result.failure(IllegalArgumentException("API ID must be a positive integer"))
        }
        if (!cleanHash.matches(Regex("^[0-9a-fA-F]{32}$"))) {
            return Result.failure(IllegalArgumentException("API Hash must be a 32-character hexadecimal string"))
        }

        pendingPhone = ""
        secureStorage.clearAll()
        secureStorage.saveApiCredentials(apiId, cleanHash)
        secureStorage.saveActiveDc(2)

        return runCatching {
            withContext(Dispatchers.IO) {
                _connectionState.value = TelegramConnectionState.Connecting(2)
                onProgressLabel("Connecting to Telegram...")

                val initDeferred = CompletableDeferred<Unit>()
                pendingParameterInit = initDeferred

                val client = getOrCreateTdClient()
                onProgressLabel("Verifying API...")

                val currentState = sendTdQuery(TdApi.GetAuthorizationState())
                if (currentState is TdApi.AuthorizationStateWaitTdlibParameters) {
                    sendTdQuery(buildTdlibParameters(apiId, cleanHash))
                }

                withTimeout(25_000L) {
                    initDeferred.await()
                }

                _connectionState.value = TelegramConnectionState.Connected(2, null)
                if (_authStep.value !is TelegramAuthStep.Authorized) {
                    _authStep.value = TelegramAuthStep.EnterPhoneNumber(apiId, cleanHash)
                }
            }
        }.onFailure { err ->
            pendingParameterInit = null
            _connectionState.value = TelegramConnectionState.Disconnected(err.message ?: "Connection failed")
        }
    }

    fun editApiCredentials() {
        pendingPhone = ""
        _authStep.value = TelegramAuthStep.VerifyApiCredentials
    }

    /**
     * Step 2: Send phone number via TDLib SetAuthenticationPhoneNumber.
     * TDLib natively handles DC migrations, TCP obfuscation, and rate limits.
     */
    suspend fun sendPhoneCode(phoneNumber: String): Result<String> = sessionMutex.withLock {
        val currentStep = _authStep.value as? TelegramAuthStep.EnterPhoneNumber
        val apiId = currentStep?.apiId ?: secureStorage.getApiId()
            ?: return Result.failure(IllegalStateException("Verify your API credentials first"))
        val apiHash = currentStep?.apiHash ?: secureStorage.getApiHash()
            ?: return Result.failure(IllegalStateException("Verify your API credentials first"))

        val raw = phoneNumber.trim()
        val normalizedPhone = "+" + raw.removePrefix("+").filter(Char::isDigit)
        if (!raw.startsWith("+") || normalizedPhone.length < 8) {
            return Result.failure(
                IllegalArgumentException("Enter full phone number with country code (e.g. +880...)")
            )
        }

        pendingPhone = normalizedPhone
        secureStorage.saveApiCredentials(apiId, apiHash)
        secureStorage.savePhoneNumber(normalizedPhone)

        return runCatching {
            withContext(Dispatchers.IO) {
                val authState = sendTdQuery(TdApi.GetAuthorizationState())
                if (authState is TdApi.AuthorizationStateWaitTdlibParameters) {
                    sendTdQuery(buildTdlibParameters(apiId, apiHash))
                }

                val settings = TdApi.PhoneNumberAuthenticationSettings(
                    /* allowFlashCall = */ false,
                    /* allowMissedCall = */ false,
                    /* isCurrentPhoneNumber = */ false,
                    /* hasUnknownPhoneNumber = */ false,
                    /* allowSmsRetrieverApi = */ false,
                    /* firebaseAuthenticationSettings = */ null,
                    /* authenticationTokens = */ emptyArray()
                )
                sendTdQuery(TdApi.SetAuthenticationPhoneNumber(normalizedPhone, settings))
                _authStep.value = TelegramAuthStep.AwaitingOtp(normalizedPhone, "tdlib_code_session")
                "tdlib_code_session"
            }
        }
    }

    /**
     * Step 3a: Resend authentication code via TDLib ResendAuthenticationCode.
     */
    suspend fun resendOtpCode(): Result<String> = sessionMutex.withLock {
        if (pendingPhone.isBlank()) {
            return Result.failure(IllegalStateException("No pending verification request"))
        }
        return runCatching {
            withContext(Dispatchers.IO) {
                sendTdQuery(TdApi.ResendAuthenticationCode(TdApi.ResendCodeReasonUserRequest()))
                _authStep.value = TelegramAuthStep.AwaitingOtp(pendingPhone, "tdlib_code_session")
                "tdlib_code_session"
            }
        }
    }

    /**
     * Step 3b: Verify OTP code via TDLib CheckAuthenticationCode.
     * Smoothly transitions to AwaitingPassword if 2FA Cloud Password is enabled on the account.
     */
    suspend fun verifyOtpCode(code: String): Result<VerifyOtpOutcome> = sessionMutex.withLock {
        val cleanCode = code.trim()
        if (cleanCode.isEmpty()) {
            return Result.failure(IllegalArgumentException("Enter the verification code"))
        }

        return runCatching {
            withContext(Dispatchers.IO) {
                sendTdQuery(TdApi.CheckAuthenticationCode(cleanCode))
                val updatedState = sendTdQuery(TdApi.GetAuthorizationState())
                handleAuthorizationState(updatedState)

                when (updatedState) {
                    is TdApi.AuthorizationStateWaitPassword -> {
                        _authStep.value = TelegramAuthStep.AwaitingPassword(updatedState.passwordHint.orEmpty())
                        VerifyOtpOutcome.NEEDS_TWO_FACTOR
                    }
                    else -> {
                        completeTdAuthorization()
                        VerifyOtpOutcome.AUTHORIZED
                    }
                }
            }
        }
    }

    /**
     * Step 3c: Verify 2FA Cloud Password via TDLib CheckAuthenticationPassword.
     */
    suspend fun verifyTwoFactorPassword(password: String): Result<Unit> = sessionMutex.withLock {
        if (password.isEmpty()) {
            return Result.failure(IllegalArgumentException("Enter your 2FA password"))
        }

        return runCatching {
            withContext(Dispatchers.IO) {
                sendTdQuery(TdApi.CheckAuthenticationPassword(password))
                completeTdAuthorization()
            }
        }
    }

    private suspend fun completeTdAuthorization() {
        secureStorage.setLoggedIn(true)
        val profile = runCatching { fetchCurrentUserProfileInternal() }.getOrNull()
        val displayName = profile?.fullName
            ?: secureStorage.getUserDisplayName()?.takeIf { it.isNotBlank() }
            ?: pendingPhone.ifBlank { "Telegram User" }
        val phone = profile?.phoneNumber ?: pendingPhone.ifBlank { secureStorage.getPhoneNumber().orEmpty() }

        _connectionState.value = TelegramConnectionState.Connected(
            dcId = secureStorage.getActiveDc(),
            userDisplayName = displayName
        )
        _authStep.value = TelegramAuthStep.Authorized(displayName, phone)
        runCatching { ensureStorageChannelInternal() }
    }

    /**
     * Fetches the authenticated user's profile via TDLib GetMe.
     */
    suspend fun fetchCurrentUserProfile(): Result<TelegramUserProfile?> = runCatching {
        withContext(Dispatchers.IO) { fetchCurrentUserProfileInternal() }
    }

    private suspend fun fetchCurrentUserProfileInternal(): TelegramUserProfile? {
        if (!secureStorage.isLoggedIn()) return null
        val user = sendTdQuery(TdApi.GetMe())
        isPremiumAccount = user.isPremium

        val activeUsername = user.usernames?.activeUsernames?.firstOrNull()?.takeIf { it.isNotBlank() }
            ?: user.usernames?.editableUsername?.takeIf { it.isNotBlank() }
        val formattedPhone = user.phoneNumber?.takeIf { it.isNotBlank() }?.let {
            if (it.startsWith("+")) it else "+$it"
        } ?: secureStorage.getPhoneNumber()

        var avatarLocalPath: String? = secureStorage.getAvatarPath()
        val smallPhotoFile = user.profilePhoto?.small
        if (smallPhotoFile != null && smallPhotoFile.id != 0) {
            runCatching {
                val downloaded = sendTdQuery(
                    TdApi.DownloadFile(smallPhotoFile.id, 16, 0L, 0L, true)
                )
                val path = downloaded.local?.path
                if (!path.isNullOrBlank() && File(path).exists()) {
                    avatarLocalPath = path
                }
            }
        }

        val profile = TelegramUserProfile(
            userId = user.id,
            firstName = user.firstName.orEmpty(),
            lastName = user.lastName.orEmpty(),
            username = activeUsername,
            phoneNumber = formattedPhone,
            avatarPath = avatarLocalPath
        )

        secureStorage.saveUserProfileDetails(
            userId = profile.userId,
            firstName = profile.firstName,
            lastName = profile.lastName,
            username = profile.username,
            phone = profile.phoneNumber,
            avatarPath = profile.avatarPath
        )
        _userProfile.value = profile
        _authStep.value = TelegramAuthStep.Authorized(
            displayName = profile.fullName,
            phoneNumber = profile.phoneNumber.orEmpty()
        )
        _connectionState.value = TelegramConnectionState.Connected(
            dcId = secureStorage.getActiveDc(),
            userDisplayName = profile.fullName
        )
        return profile
    }

    /**
     * Finds or creates private "Clody Cloud Storage" channel using TDLib;
     * falls back to Saved Messages (CreatePrivateChat with self) if channel creation is restricted.
     */
    suspend fun ensureStorageChannel(): Result<Pair<Long, Long>> = sessionMutex.withLock {
        runCatching { ensureStorageChannelInternal() }
    }

    private suspend fun ensureStorageChannelInternal(): Pair<Long, Long> {
        val existingChatId = secureStorage.getStorageChannelId()
        val existingHash = secureStorage.getStorageChannelAccessHash()
        if (existingChatId != 0L) {
            val verified = runCatching { sendTdQuery(TdApi.GetChat(existingChatId)) }.getOrNull()
            if (verified != null) {
                return existingChatId to existingHash
            }
        }

        // 1. Search existing chats for "Clody Cloud Storage"
        val foundChatId = runCatching { findClodyChannelInChats() }.getOrNull()
        if (foundChatId != null && foundChatId != 0L) {
            secureStorage.saveStorageChannel(foundChatId, 1L, isSelfChat = false)
            return foundChatId to 1L
        }

        // 2. Create private channel "Clody Cloud Storage" via CreateNewSupergroupChat(isChannel = true)
        val createdChat = runCatching {
            sendTdQuery(
                TdApi.CreateNewSupergroupChat(
                    /* title = */ "Clody Cloud Storage",
                    /* isForum = */ false,
                    /* isChannel = */ true,
                    /* description = */ "Private cloud storage managed by Clody",
                    /* location = */ null,
                    /* messageAutoDeleteTime = */ 0,
                    /* forImport = */ false
                )
            )
        }.getOrNull()

        if (createdChat != null && createdChat.id != 0L) {
            secureStorage.saveStorageChannel(createdChat.id, 1L, isSelfChat = false)
            return createdChat.id to 1L
        }

        // 3. Fallback to Saved Messages (private chat with self)
        val selfChatId = runCatching {
            val me = sendTdQuery(TdApi.GetMe())
            val selfChat = sendTdQuery(TdApi.CreatePrivateChat(me.id, false))
            selfChat.id
        }.getOrDefault(-1L)

        secureStorage.saveStorageChannel(selfChatId, 0L, isSelfChat = true)
        return selfChatId to 0L
    }

    private suspend fun findClodyChannelInChats(): Long? {
        runCatching { sendTdQuery(TdApi.LoadChats(TdApi.ChatListMain(), 50)) }
        val chats = sendTdQuery(TdApi.GetChats(TdApi.ChatListMain(), 50))
        for (chatId in chats.chatIds ?: LongArray(0)) {
            val chat = runCatching { sendTdQuery(TdApi.GetChat(chatId)) }.getOrNull() ?: continue
            if (chat.title == "Clody Cloud Storage") {
                return chat.id
            }
        }
        return null
    }

    /**
     * Uploads a local file to the private Telegram storage channel using TDLib's SendMessage
     * with InputMessageDocument / InputMessageVideo + InputFileLocal, reporting live progress
     * via UpdateFile and completing on UpdateMessageSendSucceeded.
     */
    suspend fun uploadFile(
        file: File,
        fileName: String,
        mimeType: String,
        thumbnailFile: File?,
        isVideo: Boolean,
        durationSec: Double,
        onProgress: suspend (bytesSent: Long, speedBytesPerSec: Long) -> Unit
    ): Result<TelegramUploadedDocument> = runCatching {
        withContext(Dispatchers.IO) {
            val totalBytes = file.length()
            val maxAllowed = if (isPremiumAccount) PREMIUM_MAX_FILE_BYTES else STANDARD_MAX_FILE_BYTES
            if (totalBytes > maxAllowed) {
                val limitGb = if (isPremiumAccount) "4 GB" else "2 GB"
                throw IllegalArgumentException(
                    "File size exceeds Telegram's $limitGb limit for your account."
                )
            }

            val (chatId, _) = ensureStorageChannelInternal()
            val startTime = System.currentTimeMillis()

            val inputThumb = if (thumbnailFile != null && thumbnailFile.exists() && thumbnailFile.length() > 0L) {
                TdApi.InputThumbnail(TdApi.InputFileLocal(thumbnailFile.absolutePath), 320, 320)
            } else null

            val caption = TdApi.FormattedText("Clody Cloud Backup: $fileName", emptyArray())
            val content: TdApi.InputMessageContent = if (isVideo) {
                TdApi.InputMessageVideo(
                    /* video = */ TdApi.InputFileLocal(file.absolutePath),
                    /* thumbnail = */ inputThumb,
                    /* cover = */ null,
                    /* startTimestamp = */ 0,
                    /* addedStickerFileIds = */ IntArray(0),
                    /* duration = */ durationSec.toInt(),
                    /* width = */ 1280,
                    /* height = */ 720,
                    /* supportsStreaming = */ true,
                    /* caption = */ caption,
                    /* showCaptionAboveMedia = */ false,
                    /* selfDestructType = */ null,
                    /* hasSpoiler = */ false
                )
            } else {
                TdApi.InputMessageDocument(
                    /* document = */ TdApi.InputFileLocal(file.absolutePath),
                    /* thumbnail = */ inputThumb,
                    /* disableContentTypeDetection = */ false,
                    /* caption = */ caption
                )
            }

            val sendDeferred = CompletableDeferred<TdApi.Message>()
            val provisionalMsg = sendTdQuery(
                TdApi.SendMessage(
                    /* chatId = */ chatId,
                    /* topicId = */ null,
                    /* replyTo = */ null,
                    /* options = */ TdApi.MessageSendOptions(),
                    /* replyMarkup = */ null,
                    /* inputMessageContent = */ content
                )
            )

            val provisionalFile = extractTdFileFromMessage(provisionalMsg)
            val trackedFileId = provisionalFile?.id ?: 0

            if (provisionalMsg.sendingState is TdApi.MessageSendingStatePending) {
                pendingMessageSends[provisionalMsg.id] = sendDeferred
            } else {
                sendDeferred.complete(provisionalMsg)
            }

            if (trackedFileId != 0) {
                fileProgressListeners[trackedFileId] = { updatedFile ->
                    val uploaded = updatedFile.remote?.uploadedSize ?: 0L
                    val elapsedSec = maxOf(0.1, (System.currentTimeMillis() - startTime) / 1000.0)
                    val speed = (uploaded / elapsedSec).toLong()
                    scope.launch {
                        runCatching { onProgress(minOf(uploaded, totalBytes), speed) }
                    }
                }
            }

            val finalMessage = try {
                sendDeferred.await()
            } finally {
                pendingMessageSends.remove(provisionalMsg.id)
                if (trackedFileId != 0) {
                    fileProgressListeners.remove(trackedFileId)
                }
            }

            val elapsedSec = maxOf(0.1, (System.currentTimeMillis() - startTime) / 1000.0)
            val finalSpeed = (totalBytes / elapsedSec).toLong()
            onProgress(totalBytes, finalSpeed)

            val finalTdFile = extractTdFileFromMessage(finalMessage) ?: provisionalFile
            val tdFileId = finalTdFile?.id ?: trackedFileId
            val remoteIdStr = finalTdFile?.remote?.id.orEmpty()
            if (remoteIdStr.isNotBlank() && tdFileId != 0) {
                remoteToLocalFileIdCache[remoteIdStr] = tdFileId
            }

            val normalizedMsgId = ((finalMessage.id ushr 20).toInt()).let {
                if (it > 0) it else (finalMessage.id and 0x7FFFFFFFL).toInt().coerceAtLeast(1)
            }
            val nonZeroDocId = when {
                tdFileId != 0 -> tdFileId.toLong()
                remoteIdStr.isNotBlank() -> remoteIdStr.hashCode().toLong().let { if (it == 0L) 1L else it }
                else -> normalizedMsgId.toLong()
            }

            TelegramUploadedDocument(
                messageId = normalizedMsgId,
                documentId = nonZeroDocId,
                accessHash = finalMessage.id,
                fileReference = remoteIdStr.toByteArray(Charsets.UTF_8),
                dcId = secureStorage.getActiveDc(),
                mimeType = mimeType,
                sizeBytes = if ((finalTdFile?.size ?: 0L) > 0L) finalTdFile!!.size else totalBytes
            )
        }
    }

    /**
     * Progressive byte-range chunk download using TDLib DownloadFile + ReadFilePart.
     * Preserves 512 KB chunk streaming for Media3 video/audio players and LocalFirstResolver.
     */
    suspend fun downloadChunk(
        dcId: Int,
        documentId: Long,
        accessHash: Long,
        fileReference: ByteArray,
        offset: Long,
        limit: Int
    ): ByteArray = withContext(Dispatchers.IO) {
        if (limit <= 0) return@withContext ByteArray(0)

        val remoteId = if (fileReference.isNotEmpty()) {
            runCatching { String(fileReference, Charsets.UTF_8).trim() }.getOrDefault("")
        } else ""

        var tdFileId = if (remoteId.isNotBlank()) {
            remoteToLocalFileIdCache[remoteId] ?: 0
        } else 0

        if (tdFileId == 0 && remoteId.isNotBlank()) {
            val remoteFile = runCatching {
                sendTdQuery(TdApi.GetRemoteFile(remoteId, null))
            }.getOrNull()
            if (remoteFile != null && remoteFile.id != 0) {
                tdFileId = remoteFile.id
                remoteToLocalFileIdCache[remoteId] = tdFileId
            }
        }

        if (tdFileId == 0 && accessHash != 0L) {
            val chatId = secureStorage.getStorageChannelId()
            if (chatId != 0L) {
                val msg = runCatching {
                    sendTdQuery(TdApi.GetMessage(chatId, accessHash))
                }.getOrNull()
                val msgFile = extractTdFileFromMessage(msg)
                if (msgFile != null && msgFile.id != 0) {
                    tdFileId = msgFile.id
                }
            }
        }

        if (tdFileId == 0 && documentId > 0L && documentId <= Int.MAX_VALUE) {
            tdFileId = documentId.toInt()
        }

        if (tdFileId == 0) {
            throw IllegalStateException("Unable to resolve TDLib file ID for cloud stream")
        }

        val downloadedFile = sendTdQuery(
            TdApi.DownloadFile(
                /* fileId = */ tdFileId,
                /* priority = */ 32,
                /* offset = */ offset,
                /* limit = */ limit.toLong(),
                /* synchronous = */ true
            )
        )

        val part = runCatching {
            sendTdQuery(TdApi.ReadFilePart(tdFileId, offset, limit.toLong()))
        }.getOrNull()

        if (part?.data != null && part.data.isNotEmpty()) {
            return@withContext part.data
        }

        // Fallback: read directly from TDLib's local file path if downloaded on disk
        val localPath = downloadedFile.local?.path
        if (!localPath.isNullOrBlank()) {
            val localFile = File(localPath)
            if (localFile.exists() && localFile.length() > offset) {
                RandomAccessFile(localFile, "r").use { raf ->
                    val available = minOf(limit.toLong(), raf.length() - offset).toInt()
                    if (available > 0) {
                        val buffer = ByteArray(available)
                        raf.seek(offset)
                        val read = raf.read(buffer)
                        if (read > 0) {
                            return@withContext if (read == buffer.size) buffer else buffer.copyOf(read)
                        }
                    }
                }
            }
        }

        ByteArray(0)
    }

    /**
     * Pushes clody_index.json to the private Telegram storage channel so folder and album trees sync across devices.
     */
    suspend fun pushCloudIndexSnapshot(): Result<Unit> = runCatching {
        withContext(Dispatchers.IO) {
            if (!secureStorage.isLoggedIn()) return@withContext
            val folders = dao.getAllFoldersOnce()
            val albums = dao.getAllAlbumsOnce()
            val files = dao.getAllActiveFilesOnce()
            val snapshot = CloudIndexSnapshot(folders = folders, albums = albums, files = files)
            val jsonText = json.encodeToString(snapshot)
            val indexFile = File(context.cacheDir, "clody_index.json").apply {
                writeText(jsonText, Charsets.UTF_8)
            }
            val uploaded = uploadFile(
                file = indexFile,
                fileName = "clody_index.json",
                mimeType = "application/json",
                thumbnailFile = null,
                isVideo = false,
                durationSec = 0.0,
                onProgress = { _, _ -> }
            ).getOrThrow()

            if (uploaded.messageId > 0) {
                secureStorage.saveIndexMessageId(uploaded.messageId)
                val chatId = secureStorage.getStorageChannelId()
                if (chatId != 0L && uploaded.accessHash != 0L) {
                    runCatching {
                        sendTdQuery(
                            TdApi.PinChatMessage(
                                /* chatId = */ chatId,
                                /* messageId = */ uploaded.accessHash,
                                /* disableNotification = */ true,
                                /* onlyForSelf = */ false
                            )
                        )
                    }
                }
            }
        }
    }

    /**
     * Fetches recent channel history from TDLib GetChatHistory and restores any missing clody_index.json items.
     */
    suspend fun syncFromTelegramChannel(): Result<Int> = runCatching {
        withContext(Dispatchers.IO) {
            val (chatId, _) = ensureStorageChannelInternal()
            val history = sendTdQuery(
                TdApi.GetChatHistory(
                    /* chatId = */ chatId,
                    /* fromMessageId = */ 0L,
                    /* offset = */ 0,
                    /* limit = */ 50,
                    /* onlyLocal = */ false
                )
            )

            val docs = mutableListOf<Pair<String, TelegramUploadedDocument>>()
            for (msg in history.messages ?: emptyArray()) {
                val pair = extractNamedDocumentFromMessage(msg) ?: continue
                docs += pair
            }

            var restored = 0
            val indexDoc = docs.firstOrNull { it.first == "clody_index.json" }
            if (indexDoc != null) {
                val doc = indexDoc.second
                val indexBytes = downloadChunk(
                    dcId = doc.dcId,
                    documentId = doc.documentId,
                    accessHash = doc.accessHash,
                    fileReference = doc.fileReference,
                    offset = 0L,
                    limit = maxOf(DEFAULT_CHUNK_SIZE, doc.sizeBytes.toInt())
                )
                runCatching {
                    val snapshot = json.decodeFromString<CloudIndexSnapshot>(
                        String(indexBytes, Charsets.UTF_8)
                    )
                    if (snapshot.folders.isNotEmpty()) dao.insertFolders(snapshot.folders)
                    if (snapshot.albums.isNotEmpty()) dao.insertAlbums(snapshot.albums)
                    for (f in snapshot.files) {
                        if (dao.getFileByMessageId(f.telegramMessageId) == null) {
                            dao.insertFile(f.copy(id = 0, localCachePath = null, thumbnailPath = null))
                            restored++
                        }
                    }
                }
            }
            restored
        }
    }

    suspend fun logout(): Result<Unit> = sessionMutex.withLock {
        runCatching {
            withContext(Dispatchers.IO) {
                runCatching {
                    if (tdClient != null) {
                        sendTdQuery(TdApi.LogOut())
                    }
                }
                synchronized(clientLock) {
                    tdClient = null
                }
                fileProgressListeners.clear()
                pendingMessageSends.clear()
                remoteToLocalFileIdCache.clear()
                secureStorage.clearSessionOnly()
                _userProfile.value = null
                _connectionState.value = TelegramConnectionState.Disconnected(null)
                _authStep.value = TelegramAuthStep.VerifyApiCredentials
            }
        }
    }

    private fun extractTdFileFromMessage(msg: TdApi.Message?): TdApi.File? {
        if (msg == null) return null
        return when (val content = msg.content) {
            is TdApi.MessageDocument -> content.document?.document
            is TdApi.MessageVideo -> content.video?.video
            else -> null
        }
    }

    private fun extractNamedDocumentFromMessage(msg: TdApi.Message): Pair<String, TelegramUploadedDocument>? {
        val content = msg.content
        val fileName: String
        val mimeType: String
        val tdFile: TdApi.File?

        when (content) {
            is TdApi.MessageDocument -> {
                val doc = content.document ?: return null
                fileName = doc.fileName.orEmpty()
                mimeType = doc.mimeType.orEmpty()
                tdFile = doc.document
            }
            is TdApi.MessageVideo -> {
                val vid = content.video ?: return null
                fileName = vid.fileName.orEmpty()
                mimeType = vid.mimeType.orEmpty()
                tdFile = vid.video
            }
            else -> return null
        }

        if (tdFile == null) return null
        val remoteId = tdFile.remote?.id.orEmpty()
        if (remoteId.isNotBlank() && tdFile.id != 0) {
            remoteToLocalFileIdCache[remoteId] = tdFile.id
        }

        val normalizedMsgId = ((msg.id ushr 20).toInt()).let {
            if (it > 0) it else (msg.id and 0x7FFFFFFFL).toInt().coerceAtLeast(1)
        }
        val docId = if (tdFile.id != 0) tdFile.id.toLong() else normalizedMsgId.toLong()

        return fileName to TelegramUploadedDocument(
            messageId = normalizedMsgId,
            documentId = docId,
            accessHash = msg.id,
            fileReference = remoteId.toByteArray(Charsets.UTF_8),
            dcId = secureStorage.getActiveDc(),
            mimeType = mimeType,
            sizeBytes = tdFile.size
        )
    }
}
