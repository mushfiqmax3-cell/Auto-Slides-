package com.example.media

import android.content.Context
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.FileEntity
import com.example.telegram.TelegramClientManager
import com.example.ui.theme.EmeraldConnected
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

enum class MediaPlaybackOrigin(val label: String) {
    ON_DEVICE("On Device"),
    CLOUD_STREAM("Streaming from Cloud")
}

sealed interface ResolvedMediaSource {
    val origin: MediaPlaybackOrigin

    data class LocalDevice(
        val uri: Uri,
        val directFile: File? = null
    ) : ResolvedMediaSource {
        override val origin: MediaPlaybackOrigin = MediaPlaybackOrigin.ON_DEVICE
    }

    data class CloudStream(
        val fileEntity: FileEntity
    ) : ResolvedMediaSource {
        override val origin: MediaPlaybackOrigin = MediaPlaybackOrigin.CLOUD_STREAM
    }
}

object LocalFirstResolver {

    /**
     * Checks whether the original file still exists & is readable on the device.
     * Never throws if deleted from device; cleanly falls back to CloudStream.
     */
    fun resolve(context: Context, file: FileEntity): ResolvedMediaSource {
        val raw = file.localSourceUri?.takeIf { it.isNotBlank() }
        if (raw != null) {
            val uri = Uri.parse(raw)
            if (uri.scheme == "file") {
                val f = uri.path?.let { File(it) }
                if (f != null && f.exists() && f.isFile && f.canRead() && f.length() > 0L) {
                    return ResolvedMediaSource.LocalDevice(uri = uri, directFile = f)
                }
            } else {
                val readable = runCatching {
                    context.contentResolver.openAssetFileDescriptor(uri, "r")?.use { afd ->
                        afd.length != 0L
                    } ?: false
                }.getOrDefault(false)
                if (readable) {
                    return ResolvedMediaSource.LocalDevice(uri = uri, directFile = null)
                }
            }
        }
        return ResolvedMediaSource.CloudStream(file)
    }

    /**
     * Opens a local file directly OR streams chunks from Telegram into private cache (`tdlib_files`).
     * Never saves to public phone storage automatically.
     */
    suspend fun loadToReadableFile(
        context: Context,
        telegramClient: TelegramClientManager,
        file: FileEntity,
        onProgress: (Float) -> Unit = {}
    ): Pair<File, MediaPlaybackOrigin> = withContext(Dispatchers.IO) {
        when (val resolved = resolve(context, file)) {
            is ResolvedMediaSource.LocalDevice -> {
                if (resolved.directFile != null) {
                    return@withContext resolved.directFile to MediaPlaybackOrigin.ON_DEVICE
                }
                // Stage small readable copy in private reader temp dir from local ContentResolver (zero cloud data!)
                val readerDir = File(context.cacheDir, "local_reader_temp").apply { mkdirs() }
                val tmp = File(readerDir, "local_${file.id}_${file.name.replace(Regex("[^a-zA-Z0-9._-]"), "_")}")
                context.contentResolver.openInputStream(resolved.uri)?.use { input ->
                    FileOutputStream(tmp).use { output ->
                        input.copyTo(output, bufferSize = 64 * 1024)
                    }
                } ?: throw IllegalStateException("Local URI unreadable")
                onProgress(1f)
                tmp to MediaPlaybackOrigin.ON_DEVICE
            }

            is ResolvedMediaSource.CloudStream -> {
                val cached = ClodyStreamCache.getCachedVideoFile(context, file)
                val existingFromPath = file.localCachePath?.let { File(it).takeIf { f -> f.exists() && f.length() > 0L } }
                if (existingFromPath != null) {
                    onProgress(1f)
                    return@withContext existingFromPath to MediaPlaybackOrigin.CLOUD_STREAM
                }
                if (cached.exists() && file.sizeBytes > 0L && cached.length() == file.sizeBytes) {
                    onProgress(1f)
                    return@withContext cached to MediaPlaybackOrigin.CLOUD_STREAM
                }
                if (file.telegramDocumentId == 0L) {
                    throw IllegalStateException("File unavailable locally and missing Telegram document reference")
                }
                val ref = hexToBytes(file.telegramFileReferenceHex)
                val chunkSize = 512 * 1024
                var pos = 0L
                val total = maxOf(1L, file.sizeBytes)
                FileOutputStream(cached).use { fos ->
                    while (pos < file.sizeBytes) {
                        val chunk = telegramClient.downloadChunk(
                            dcId = file.telegramDcId,
                            documentId = file.telegramDocumentId,
                            accessHash = file.telegramAccessHash,
                            fileReference = ref,
                            offset = pos,
                            limit = chunkSize
                        )
                        if (chunk.isEmpty()) break
                        val toWrite = minOf(chunk.size.toLong(), file.sizeBytes - pos).toInt()
                        fos.write(chunk, 0, toWrite)
                        pos += toWrite
                        onProgress((pos.toFloat() / total.toFloat()).coerceIn(0f, 1f))
                    }
                }
                onProgress(1f)
                cached to MediaPlaybackOrigin.CLOUD_STREAM
            }
        }
    }

    fun cleanupTempLocalCopies(context: Context, fileId: Long) {
        val readerDir = File(context.cacheDir, "local_reader_temp")
        readerDir.listFiles()?.filter { it.name.startsWith("local_${fileId}_") }?.forEach { it.delete() }
    }

    private fun hexToBytes(hex: String): ByteArray {
        if (hex.isEmpty() || hex.length % 2 != 0) return ByteArray(0)
        return ByteArray(hex.length / 2) { i ->
            hex.substring(i * 2, i * 2 + 2).toInt(16).toByte()
        }
    }
}

@Composable
fun PlaybackOriginPill(
    origin: MediaPlaybackOrigin,
    darkSurface: Boolean = true,
    modifier: Modifier = Modifier
) {
    val bg = if (darkSurface) Color.White.copy(alpha = 0.14f) else Color(0xFF141414).copy(alpha = 0.08f)
    val fg = if (darkSurface) Color.White else Color(0xFF141414)
    val dotColor = if (origin == MediaPlaybackOrigin.ON_DEVICE) EmeraldConnected else Color(0xFF8E8E93)
    val icon = if (origin == MediaPlaybackOrigin.ON_DEVICE) Icons.Default.PhoneAndroid else Icons.Default.Cloud

    Surface(
        color = bg,
        shape = RoundedCornerShape(16.dp),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(7.dp)
                    .clip(CircleShape)
                    .background(dotColor)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Icon(icon, contentDescription = null, tint = fg, modifier = Modifier.size(13.dp))
            Spacer(modifier = Modifier.width(5.dp))
            Text(
                text = origin.label,
                color = fg,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1
            )
        }
    }
}

@Composable
fun DownloadOrSavedPill(
    origin: MediaPlaybackOrigin,
    onDownloadClick: () -> Unit,
    darkMode: Boolean = true,
    modifier: Modifier = Modifier
) {
    val isSaved = origin == MediaPlaybackOrigin.ON_DEVICE
    val bg = when {
        isSaved && darkMode -> Color.White.copy(alpha = 0.14f)
        isSaved && !darkMode -> Color(0xFF141414).copy(alpha = 0.08f)
        darkMode -> Color.White
        else -> Color(0xFF141414)
    }
    val fg = when {
        isSaved && darkMode -> EmeraldConnected
        isSaved && !darkMode -> EmeraldConnected
        darkMode -> Color(0xFF141414)
        else -> Color.White
    }

    Surface(
        color = bg,
        shape = RoundedCornerShape(20.dp),
        onClick = { if (!isSaved) onDownloadClick() },
        enabled = !isSaved,
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (isSaved) Icons.Default.CheckCircle else Icons.Default.Download,
                contentDescription = null,
                tint = fg,
                modifier = Modifier.size(15.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = if (isSaved) "Saved on Device ✓" else "Download",
                color = fg,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}
