package com.example.media

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.BufferedInputStream
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.util.zip.ZipInputStream

sealed interface WordBlock {
    data class Heading(val level: Int, val text: String) : WordBlock
    data class Paragraph(val text: String, val isBold: Boolean = false, val isItalic: Boolean = false) : WordBlock
    data class BulletItem(val text: String, val index: Int? = null) : WordBlock
    data class TableBlock(val rows: List<List<String>>) : WordBlock
}

data class SpreadsheetSheet(
    val name: String,
    val rows: List<List<String>>
)

object DocumentParser {

    fun parseDocx(file: File): List<WordBlock> {
        var documentXml: ByteArray? = null
        ZipInputStream(BufferedInputStream(FileInputStream(file))).use { zis ->
            while (true) {
                val entry = zis.nextEntry ?: break
                if (entry.name == "word/document.xml") {
                    documentXml = zis.readBytes()
                    break
                }
            }
        }
        val xmlBytes = documentXml ?: return listOf(
            WordBlock.Paragraph("Unable to locate word/document.xml inside this .docx archive.")
        )

        val blocks = mutableListOf<WordBlock>()
        val parser = Xml.newPullParser()
        parser.setInput(ByteArrayInputStream(xmlBytes), "UTF-8")

        var inParagraph = false
        var inTable = false
        var inTableRow = false
        var inTableCell = false
        var isHeadingLevel = 0
        var isBullet = false
        var hasBold = false
        var hasItalic = false

        val paraBuilder = StringBuilder()
        val cellBuilder = StringBuilder()
        val currentTableRows = mutableListOf<List<String>>()
        val currentRowCells = mutableListOf<String>()
        var bulletCounter = 0

        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            val tag = parser.name?.substringAfter(':')
            when (event) {
                XmlPullParser.START_TAG -> {
                    when (tag) {
                        "tbl" -> {
                            inTable = true
                            currentTableRows.clear()
                        }
                        "tr" -> if (inTable) {
                            inTableRow = true
                            currentRowCells.clear()
                        }
                        "tc" -> if (inTableRow) {
                            inTableCell = true
                            cellBuilder.clear()
                        }
                        "p" -> {
                            inParagraph = true
                            if (!inTableCell) {
                                paraBuilder.clear()
                                isHeadingLevel = 0
                                isBullet = false
                                hasBold = false
                                hasItalic = false
                            } else if (cellBuilder.isNotEmpty()) {
                                cellBuilder.append("\n")
                            }
                        }
                        "pStyle" -> if (inParagraph && !inTableCell) {
                            val valAttr = getAttr(parser, "val").orEmpty()
                            if (valAttr.startsWith("Heading", ignoreCase = true) || valAttr.equals("Title", ignoreCase = true)) {
                                isHeadingLevel = valAttr.filter(Char::isDigit).toIntOrNull()?.coerceIn(1, 6) ?: 1
                            }
                        }
                        "numPr" -> if (inParagraph && !inTableCell) {
                            isBullet = true
                        }
                        "b" -> if (inParagraph && !inTableCell) hasBold = true
                        "i" -> if (inParagraph && !inTableCell) hasItalic = true
                        "br" -> if (inTableCell) cellBuilder.append("\n") else paraBuilder.append("\n")
                        "tab" -> if (inTableCell) cellBuilder.append(" ") else paraBuilder.append("    ")
                        "t" -> {
                            val text = parser.nextText()
                            if (inTableCell) cellBuilder.append(text) else if (inParagraph) paraBuilder.append(text)
                        }
                    }
                }
                XmlPullParser.END_TAG -> {
                    when (tag) {
                        "p" -> {
                            if (!inTableCell && inParagraph) {
                                val text = paraBuilder.toString().trim()
                                if (text.isNotEmpty()) {
                                    when {
                                        isHeadingLevel > 0 -> {
                                            bulletCounter = 0
                                            blocks += WordBlock.Heading(isHeadingLevel, text)
                                        }
                                        isBullet -> {
                                            bulletCounter++
                                            blocks += WordBlock.BulletItem(text, null)
                                        }
                                        else -> {
                                            bulletCounter = 0
                                            blocks += WordBlock.Paragraph(text, hasBold, hasItalic)
                                        }
                                    }
                                }
                            }
                            inParagraph = false
                        }
                        "tc" -> {
                            if (inTableCell) {
                                currentRowCells += cellBuilder.toString().trim()
                                inTableCell = false
                            }
                        }
                        "tr" -> {
                            if (inTableRow) {
                                if (currentRowCells.isNotEmpty()) {
                                    currentTableRows += currentRowCells.toList()
                                }
                                inTableRow = false
                            }
                        }
                        "tbl" -> {
                            if (inTable) {
                                if (currentTableRows.isNotEmpty()) {
                                    blocks += WordBlock.TableBlock(currentTableRows.toList())
                                }
                                inTable = false
                            }
                        }
                    }
                }
            }
            event = parser.next()
        }
        return blocks.ifEmpty { listOf(WordBlock.Paragraph("(Empty Word document)")) }
    }

    fun parseRtf(file: File): List<WordBlock> {
        val raw = file.readText(Charsets.ISO_8859_1)
        val out = StringBuilder()
        var depth = 0
        var skipGroupDepth = Int.MAX_VALUE
        var i = 0
        val skippedDestinations = setOf("fonttbl", "colortbl", "stylesheet", "info", "pict", "object", "header", "footer")

        while (i < raw.length) {
            val ch = raw[i]
            when (ch) {
                '{' -> {
                    depth++
                    // Check if opening a metadata destination like {\fonttbl ...}
                    if (i + 2 < raw.length && raw[i + 1] == '\\') {
                        val lookahead = raw.substring(i + 2, minOf(raw.length, i + 20))
                            .takeWhile { it.isLetter() || it == '*' }
                            .removePrefix("*")
                        if (lookahead in skippedDestinations && skipGroupDepth == Int.MAX_VALUE) {
                            skipGroupDepth = depth
                        }
                    }
                    i++
                }
                '}' -> {
                    if (depth == skipGroupDepth) skipGroupDepth = Int.MAX_VALUE
                    depth = maxOf(0, depth - 1)
                    i++
                }
                '\\' -> {
                    i++
                    if (i >= raw.length) break
                    val next = raw[i]
                    if (depth >= skipGroupDepth) {
                        i++
                        continue
                    }
                    when (next) {
                        '\'', -> {
                            if (i + 2 < raw.length) {
                                val byteVal = raw.substring(i + 1, i + 3).toIntOrNull(16)
                                if (byteVal != null) out.append(byteVal.toChar())
                                i += 3
                            } else i++
                        }
                        '\\', '{', '}' -> {
                            out.append(next)
                            i++
                        }
                        '~' -> {
                            out.append(' ')
                            i++
                        }
                        '\n', '\r' -> {
                            out.append('\n')
                            i++
                        }
                        else -> {
                            val wordStart = i
                            while (i < raw.length && raw[i].isLetter()) i++
                            val word = raw.substring(wordStart, i)
                            val numStart = i
                            if (i < raw.length && (raw[i] == '-' || raw[i].isDigit())) {
                                i++
                                while (i < raw.length && raw[i].isDigit()) i++
                            }
                            val numParam = raw.substring(numStart, i).toIntOrNull()
                            if (i < raw.length && raw[i] == ' ') i++
                            when (word) {
                                "par", "line" -> out.append('\n')
                                "tab" -> out.append("    ")
                                "u" -> if (numParam != null) {
                                    val code = if (numParam < 0) numParam + 65536 else numParam
                                    out.append(code.toChar())
                                }
                            }
                        }
                    }
                }
                '\r', '\n' -> i++
                else -> {
                    if (depth < skipGroupDepth) out.append(ch)
                    i++
                }
            }
        }

        val paragraphs = out.toString()
            .split('\n')
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .map { WordBlock.Paragraph(it) }
        return paragraphs.ifEmpty { listOf(WordBlock.Paragraph("(Empty RTF document)")) }
    }

    fun parseXlsx(file: File): List<SpreadsheetSheet> {
        val entries = mutableMapOf<String, ByteArray>()
        ZipInputStream(BufferedInputStream(FileInputStream(file))).use { zis ->
            while (true) {
                val entry = zis.nextEntry ?: break
                if (!entry.isDirectory && (
                        entry.name == "xl/sharedStrings.xml" ||
                            entry.name == "xl/workbook.xml" ||
                            entry.name == "xl/_rels/workbook.xml.rels" ||
                            entry.name.startsWith("xl/worksheets/sheet")
                        )
                ) {
                    entries[entry.name] = zis.readBytes()
                }
            }
        }

        val sharedStrings = entries["xl/sharedStrings.xml"]?.let { parseSharedStrings(it) }.orEmpty()
        val sheetInfos = parseWorkbookSheets(
            workbookBytes = entries["xl/workbook.xml"],
            relsBytes = entries["xl/_rels/workbook.xml.rels"],
            availableSheets = entries.keys.filter { it.startsWith("xl/worksheets/sheet") }.sorted()
        )

        val result = mutableListOf<SpreadsheetSheet>()
        for ((title, path) in sheetInfos) {
            val bytes = entries[path] ?: continue
            val rows = parseWorksheetXml(bytes, sharedStrings)
            result += SpreadsheetSheet(name = title, rows = rows)
        }
        return result.ifEmpty {
            listOf(SpreadsheetSheet("Sheet 1", listOf(listOf("Empty or unsupported XLSX workbook"))))
        }
    }

    private fun parseSharedStrings(bytes: ByteArray): List<String> {
        val list = mutableListOf<String>()
        val parser = Xml.newPullParser()
        parser.setInput(ByteArrayInputStream(bytes), "UTF-8")
        var inSi = false
        val sb = StringBuilder()
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            val tag = parser.name?.substringAfter(':')
            when (event) {
                XmlPullParser.START_TAG -> when (tag) {
                    "si" -> {
                        inSi = true
                        sb.clear()
                    }
                    "t" -> if (inSi) sb.append(parser.nextText())
                }
                XmlPullParser.END_TAG -> if (tag == "si") {
                    list += sb.toString()
                    inSi = false
                }
            }
            event = parser.next()
        }
        return list
    }

    private fun parseWorkbookSheets(
        workbookBytes: ByteArray?,
        relsBytes: ByteArray?,
        availableSheets: List<String>
    ): List<Pair<String, String>> {
        val relMap = mutableMapOf<String, String>()
        if (relsBytes != null) {
            val p = Xml.newPullParser()
            p.setInput(ByteArrayInputStream(relsBytes), "UTF-8")
            var event = p.eventType
            while (event != XmlPullParser.END_DOCUMENT) {
                if (event == XmlPullParser.START_TAG && p.name?.substringAfter(':') == "Relationship") {
                    val id = getAttr(p, "Id")
                    val target = getAttr(p, "Target")
                    if (!id.isNullOrBlank() && !target.isNullOrBlank()) {
                        val normalized = if (target.startsWith("/")) target.drop(1)
                        else if (target.startsWith("xl/")) target
                        else "xl/$target"
                        relMap[id] = normalized
                    }
                }
                event = p.next()
            }
        }

        val ordered = mutableListOf<Pair<String, String>>()
        if (workbookBytes != null) {
            val p = Xml.newPullParser()
            p.setInput(ByteArrayInputStream(workbookBytes), "UTF-8")
            var event = p.eventType
            while (event != XmlPullParser.END_DOCUMENT) {
                if (event == XmlPullParser.START_TAG && p.name?.substringAfter(':') == "sheet") {
                    val name = getAttr(p, "name") ?: "Sheet ${ordered.size + 1}"
                    val rId = getAttr(p, "id")
                    val path = if (rId != null) relMap[rId] else null
                    if (path != null) ordered += name to path
                }
                event = p.next()
            }
        }

        if (ordered.isEmpty()) {
            availableSheets.forEachIndexed { idx, p ->
                ordered += "Sheet ${idx + 1}" to p
            }
        }
        return ordered
    }

    private fun parseWorksheetXml(bytes: ByteArray, sharedStrings: List<String>): List<List<String>> {
        val parser = Xml.newPullParser()
        parser.setInput(ByteArrayInputStream(bytes), "UTF-8")

        val rowsMap = mutableListOf<MutableList<String>>()
        var currentRow = mutableListOf<String>()
        var currentColIdx = 0
        var currentType = ""
        var currentValue = ""
        var inCell = false
        var maxCols = 1

        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            val tag = parser.name?.substringAfter(':')
            when (event) {
                XmlPullParser.START_TAG -> when (tag) {
                    "row" -> currentRow = mutableListOf()
                    "c" -> {
                        inCell = true
                        currentType = getAttr(parser, "t").orEmpty()
                        currentValue = ""
                        val ref = getAttr(parser, "r").orEmpty()
                        currentColIdx = columnLettersToIndex(ref.takeWhile { it.isLetter() })
                            .takeIf { it >= 0 } ?: currentRow.size
                    }
                    "v" -> if (inCell) {
                        val raw = parser.nextText()
                        currentValue = if (currentType == "s") {
                            raw.toIntOrNull()?.let { idx -> sharedStrings.getOrNull(idx) } ?: raw
                        } else if (currentType == "b") {
                            if (raw == "1") "TRUE" else "FALSE"
                        } else {
                            raw
                        }
                    }
                    "t" -> if (inCell && currentType == "inlineStr") {
                        currentValue += parser.nextText()
                    }
                }
                XmlPullParser.END_TAG -> when (tag) {
                    "c" -> {
                        while (currentRow.size < currentColIdx) currentRow.add("")
                        if (currentColIdx < currentRow.size) {
                            currentRow[currentColIdx] = currentValue
                        } else {
                            currentRow.add(currentValue)
                        }
                        maxCols = maxOf(maxCols, currentRow.size)
                        inCell = false
                    }
                    "row" -> {
                        if (currentRow.any { it.isNotEmpty() }) {
                            rowsMap += currentRow
                        }
                    }
                }
            }
            event = parser.next()
        }

        // Normalize rectangular grid width
        return rowsMap.map { r ->
            if (r.size < maxCols) r + List(maxCols - r.size) { "" } else r
        }
    }

    private fun columnLettersToIndex(letters: String): Int {
        if (letters.isEmpty()) return -1
        var col = 0
        for (c in letters.uppercase()) {
            col = col * 26 + (c - 'A' + 1)
        }
        return col - 1
    }

    fun parseCsv(file: File): List<SpreadsheetSheet> {
        val text = readSafeText(file, maxBytes = 2 * 1024 * 1024)
        if (text.isBlank()) return listOf(SpreadsheetSheet(file.name, emptyList()))

        val firstLine = text.lineSequence().firstOrNull().orEmpty()
        val delimiter = when {
            firstLine.count { it == ';' } > firstLine.count { it == ',' } -> ';'
            firstLine.count { it == '\t' } > firstLine.count { it == ',' } -> '\t'
            else -> ','
        }

        val rows = mutableListOf<List<String>>()
        val currentRow = mutableListOf<String>()
        val cell = StringBuilder()
        var inQuotes = false
        var i = 0
        while (i < text.length) {
            val ch = text[i]
            when {
                inQuotes -> {
                    if (ch == '"') {
                        if (i + 1 < text.length && text[i + 1] == '"') {
                            cell.append('"')
                            i++
                        } else {
                            inQuotes = false
                        }
                    } else {
                        cell.append(ch)
                    }
                }
                ch == '"' -> inQuotes = true
                ch == delimiter -> {
                    currentRow += cell.toString().trim()
                    cell.clear()
                }
                ch == '\r' -> Unit
                ch == '\n' -> {
                    currentRow += cell.toString().trim()
                    cell.clear()
                    if (currentRow.any { it.isNotEmpty() }) rows += currentRow.toList()
                    currentRow.clear()
                }
                else -> cell.append(ch)
            }
            i++
        }
        if (cell.isNotEmpty() || currentRow.isNotEmpty()) {
            currentRow += cell.toString().trim()
            if (currentRow.any { it.isNotEmpty() }) rows += currentRow.toList()
        }

        val maxCols = rows.maxOfOrNull { it.size } ?: 1
        val normalized = rows.map { r -> if (r.size < maxCols) r + List(maxCols - r.size) { "" } else r }
        return listOf(SpreadsheetSheet(file.nameWithoutExtension.ifBlank { "CSV" }, normalized))
    }

    fun parseXlsFallback(file: File): List<SpreadsheetSheet> {
        val bytes = FileInputStream(file).use { fis ->
            val buf = ByteArray(minOf(file.length(), 1024L * 1024L).toInt())
            val r = fis.read(buf)
            if (r > 0) buf.copyOf(r) else ByteArray(0)
        }
        val strings = mutableListOf<String>()
        val sb = StringBuilder()
        for (b in bytes) {
            val c = b.toInt() and 0xFF
            if (c in 32..126) {
                sb.append(c.toChar())
            } else {
                if (sb.length >= 3) strings += sb.toString().trim()
                sb.clear()
            }
        }
        if (sb.length >= 3) strings += sb.toString().trim()
        val rows = strings.distinct().chunked(4).map { chunk ->
            if (chunk.size < 4) chunk + List(4 - chunk.size) { "" } else chunk
        }
        return listOf(SpreadsheetSheet("Legacy XLS Preview", rows))
    }

    fun readSafeText(file: File, maxBytes: Int = 2 * 1024 * 1024): String {
        return FileInputStream(file).use { input ->
            readStreamCapped(input, maxBytes)
        }
    }

    private fun readStreamCapped(input: InputStream, maxBytes: Int): String {
        val buf = ByteArray(minOf(maxBytes, 64 * 1024))
        val out = java.io.ByteArrayOutputStream()
        var total = 0
        while (total < maxBytes) {
            val r = input.read(buf, 0, minOf(buf.size, maxBytes - total))
            if (r <= 0) break
            out.write(buf, 0, r)
            total += r
        }
        return String(out.toByteArray(), Charsets.UTF_8)
    }

    private fun getAttr(parser: XmlPullParser, localName: String): String? {
        for (i in 0 until parser.attributeCount) {
            if (parser.getAttributeName(i).substringAfter(':') == localName) {
                return parser.getAttributeValue(i)
            }
        }
        return null
    }
}
