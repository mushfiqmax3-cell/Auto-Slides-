package com.example.media

import android.content.Context
import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.BaseDataSource
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import com.example.data.local.FileEntity
import com.example.telegram.TelegramClientManager
import kotlinx.coroutines.runBlocking
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.util.BitSet

object ClodyStreamCache {
    fun getStreamCacheDir(context: Context): File {
        return File(context.cacheDir, "tdlib_files").apply { mkdirs() }
    }

    fun getCachedVideoFile(context: Context, fileEntity: FileEntity): File {
        return File(getStreamCacheDir(context), "stream_${fileEntity.id}_${fileEntity.telegramDocumentId}.bin")
    }

    fun getChunkMapFile(context: Context, fileEntity: FileEntity): File {
        return File(getStreamCacheDir(context), "stream_${fileEntity.id}_${fileEntity.telegramDocumentId}.chunks")
    }

    fun getStreamCacheSizeBytes(context: Context): Long {
        val dir = getStreamCacheDir(context)
        return dir.walkTopDown().filter { it.isFile }.sumOf { it.length() }
    }

    fun clearStreamCache(context: Context): Long {
        val dir = getStreamCacheDir(context)
        val freed = getStreamCacheSizeBytes(context)
        dir.listFiles()?.forEach { it.deleteRecursively() }
        return freed
    }

    fun deleteFileCache(context: Context, fileEntity: FileEntity) {
        getCachedVideoFile(context, fileEntity).delete()
        getChunkMapFile(context, fileEntity).delete()
    }
}

/**
 * Progressive byte-range Media3 DataSource streaming 512 KB chunks on-demand
 * from Telegram MTProto servers into private app cache (cacheDir/tdlib_files).
 * Supports instant playback start and timeline seeking without pre-downloading the full file.
 */
@OptIn(UnstableApi::class)
class TelegramChunkDataSource(
    private val context: Context,
    private val telegramClient: TelegramClientManager,
    private val fileEntity: FileEntity
) : BaseDataSource(/* isNetwork = */ true) {

    companion object {
        private const val CHUNK_SIZE = 512 * 1024 // 512 KB aligned with Telegram upload.getFile
    }

    private var dataSpec: DataSpec? = null
    private var opened = false
    private var currentPosition = 0L
    private var bytesRemaining = 0L
    private var randomAccessFile: RandomAccessFile? = null
    private var chunkBitSet = BitSet()
    private val fileReferenceBytes: ByteArray by lazy {
        hexToBytes(fileEntity.telegramFileReferenceHex)
    }

    override fun open(dataSpec: DataSpec): Long {
        this.dataSpec = dataSpec
        transferInitializing(dataSpec)

        val totalSize = fileEntity.sizeBytes
        if (totalSize <= 0L) {
            throw IOException("Invalid cloud file size for ${fileEntity.name}")
        }
        if (dataSpec.position > totalSize) {
            throw IOException("Requested position ${dataSpec.position} beyond EOF $totalSize")
        }

        val cacheFile = ClodyStreamCache.getCachedVideoFile(context, fileEntity)
        val mapFile = ClodyStreamCache.getChunkMapFile(context, fileEntity)
        if (mapFile.exists()) {
            runCatching {
                val raw = mapFile.readBytes()
                chunkBitSet = BitSet.valueOf(raw)
            }
        }

        val raf = RandomAccessFile(cacheFile, "rw")
        if (raf.length() != totalSize) {
            raf.setLength(totalSize)
        }
        randomAccessFile = raf

        currentPosition = dataSpec.position
        bytesRemaining = if (dataSpec.length != C.LENGTH_UNSET.toLong()) {
            minOf(dataSpec.length, totalSize - currentPosition)
        } else {
            totalSize - currentPosition
        }

        opened = true
        transferStarted(dataSpec)
        return bytesRemaining
    }

    override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
        if (length == 0) return 0
        if (bytesRemaining <= 0L) return C.RESULT_END_OF_INPUT

        val raf = randomAccessFile ?: throw IOException("DataSource not opened")
        val toRead = minOf(length.toLong(), bytesRemaining).toInt()
        val chunkIndex = (currentPosition / CHUNK_SIZE).toInt()

        ensureChunkCached(raf, chunkIndex)

        val chunkEnd = minOf(fileEntity.sizeBytes, (chunkIndex + 1L) * CHUNK_SIZE)
        val availableInChunk = (chunkEnd - currentPosition).toInt()
        val readCount = minOf(toRead, availableInChunk)

        raf.seek(currentPosition)
        val actual = raf.read(buffer, offset, readCount)
        if (actual <= 0) return C.RESULT_END_OF_INPUT

        currentPosition += actual
        bytesRemaining -= actual
        bytesTransferred(actual)
        return actual
    }

    private fun ensureChunkCached(raf: RandomAccessFile, chunkIndex: Int) {
        if (chunkBitSet.get(chunkIndex)) return

        val chunkOffset = chunkIndex.toLong() * CHUNK_SIZE
        val expectedLen = minOf(CHUNK_SIZE.toLong(), fileEntity.sizeBytes - chunkOffset).toInt()
        if (expectedLen <= 0) return

        val bytes = runBlocking {
            telegramClient.downloadChunk(
                dcId = fileEntity.telegramDcId,
                documentId = fileEntity.telegramDocumentId,
                accessHash = fileEntity.telegramAccessHash,
                fileReference = fileReferenceBytes,
                offset = chunkOffset,
                limit = CHUNK_SIZE
            )
        }
        if (bytes.isEmpty()) {
            throw IOException("Empty chunk returned from Telegram at offset $chunkOffset")
        }

        raf.seek(chunkOffset)
        raf.write(bytes, 0, minOf(bytes.size, expectedLen))
        chunkBitSet.set(chunkIndex)
        runCatching {
            ClodyStreamCache.getChunkMapFile(context, fileEntity).writeBytes(chunkBitSet.toByteArray())
        }
    }

    override fun getUri(): Uri? = dataSpec?.uri

    override fun close() {
        runCatching { randomAccessFile?.close() }
        randomAccessFile = null
        if (opened) {
            opened = false
            transferEnded()
        }
    }

    private fun hexToBytes(hex: String): ByteArray {
        if (hex.isEmpty() || hex.length % 2 != 0) return ByteArray(0)
        return ByteArray(hex.length / 2) { i ->
            hex.substring(i * 2, i * 2 + 2).toInt(16).toByte()
        }
    }

    class Factory(
        private val context: Context,
        private val telegramClient: TelegramClientManager,
        private val fileEntity: FileEntity
    ) : DataSource.Factory {
        override fun createDataSource(): DataSource {
            return TelegramChunkDataSource(context, telegramClient, fileEntity)
        }
    }
}
