package com.example.media

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import kotlin.math.roundToInt

data class ExtractedMediaMetadata(
    val thumbnailPath: String?,
    val durationMs: Long
)

object ThumbnailGenerator {

    private const val MAX_WIDTH_PX = 320
    private const val TARGET_MAX_BYTES = 25 * 1024 // ~15-25 KB lightweight preview

    fun getThumbnailsDir(context: Context): File {
        return File(context.cacheDir, "thumbnails").apply { mkdirs() }
    }

    suspend fun generateForUri(
        context: Context,
        uri: Uri,
        mimeType: String,
        uniqueKey: String
    ): ExtractedMediaMetadata = withContext(Dispatchers.IO) {
        val outFile = File(getThumbnailsDir(context), "thumb_${uniqueKey.hashCode()}.jpg")
        if (mimeType.startsWith("video/")) {
            extractVideoFrameAndDuration(context, uri, outFile)
        } else if (mimeType.startsWith("image/")) {
            val path = compressImageUri(context, uri, outFile)
            ExtractedMediaMetadata(path, 0L)
        } else {
            ExtractedMediaMetadata(null, 0L)
        }
    }

    suspend fun saveCustomThumbnail(
        context: Context,
        imageUri: Uri,
        uniqueKey: String
    ): String? = withContext(Dispatchers.IO) {
        val outFile = File(getThumbnailsDir(context), "custom_${uniqueKey.hashCode()}_${System.currentTimeMillis()}.jpg")
        compressImageUri(context, imageUri, outFile)
    }

    private fun extractVideoFrameAndDuration(
        context: Context,
        uri: Uri,
        outFile: File
    ): ExtractedMediaMetadata {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, uri)
            val durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            val durationMs = durationStr?.toLongOrNull() ?: 0L
            val targetTimeUs = if (durationMs > 1200L) 1_000_000L else 0L
            val frame = retriever.getFrameAtTime(targetTimeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: retriever.getFrameAtTime(0L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
            val thumbPath = frame?.let { bmp ->
                val saved = writeScaledCompressedJpeg(bmp, outFile)
                bmp.recycle()
                saved
            }
            ExtractedMediaMetadata(thumbPath, durationMs)
        } catch (_: Exception) {
            ExtractedMediaMetadata(null, 0L)
        } finally {
            runCatching { retriever.release() }
        }
    }

    private fun compressImageUri(
        context: Context,
        uri: Uri,
        outFile: File
    ): String? {
        return try {
            val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, boundsOpts)
            }
            val srcW = boundsOpts.outWidth
            val srcH = boundsOpts.outHeight
            if (srcW <= 0 || srcH <= 0) return null

            var sampleSize = 1
            while ((srcW / sampleSize) > MAX_WIDTH_PX * 2) {
                sampleSize *= 2
            }

            val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sampleSize }
            val decoded = context.contentResolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, decodeOpts)
            } ?: return null

            val path = writeScaledCompressedJpeg(decoded, outFile)
            decoded.recycle()
            path
        } catch (_: Exception) {
            null
        }
    }

    private fun writeScaledCompressedJpeg(bitmap: Bitmap, outFile: File): String? {
        val scale = if (bitmap.width > MAX_WIDTH_PX) {
            MAX_WIDTH_PX.toFloat() / bitmap.width.toFloat()
        } else 1f
        val targetW = maxOf(1, (bitmap.width * scale).roundToInt())
        val targetH = maxOf(1, (bitmap.height * scale).roundToInt())
        val scaled = if (scale < 1f) {
            Bitmap.createScaledBitmap(bitmap, targetW, targetH, true)
        } else {
            bitmap
        }

        val baos = ByteArrayOutputStream()
        var quality = 82
        while (quality >= 35) {
            baos.reset()
            scaled.compress(Bitmap.CompressFormat.JPEG, quality, baos)
            if (baos.size() <= TARGET_MAX_BYTES) break
            quality -= 12
        }

        FileOutputStream(outFile).use { fos ->
            fos.write(baos.toByteArray())
            fos.flush()
        }
        if (scaled !== bitmap) scaled.recycle()
        return outFile.absolutePath
    }
}
