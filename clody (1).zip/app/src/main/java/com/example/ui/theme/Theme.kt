package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Immutable
data class ClodyMetrics(
    val scale: Float = 1f,
    val horizontalPadding: Dp = 16.dp,
    val cardCornerRadius: Dp = 22.dp,
    val primaryButtonHeight: Dp = 50.dp,
    val navBarHeight: Dp = 68.dp,
    val navIconSize: Dp = 24.dp,
    val galleryMinCellSize: Dp = 112.dp,
    val isWideScreen: Boolean = false
)

val LocalClodyMetrics = staticCompositionLocalOf { ClodyMetrics() }

private val ClodyLightColorScheme = lightColorScheme(
    primary = DeepCharcoal,
    onPrimary = PureWhiteSurface,
    primaryContainer = SoftStoneGray,
    onPrimaryContainer = DeepCharcoal,
    secondary = MutedCharcoalText,
    onSecondary = PureWhiteSurface,
    secondaryContainer = SoftStoneGray,
    onSecondaryContainer = DeepCharcoal,
    tertiary = VideoIconIndigo,
    onTertiary = PureWhiteSurface,
    tertiaryContainer = VideoTintSurface,
    onTertiaryContainer = VideoIconIndigo,
    background = AlabasterCanvas,
    onBackground = DeepCharcoal,
    surface = PureWhiteSurface,
    onSurface = DeepCharcoal,
    surfaceVariant = SoftStoneGray,
    onSurfaceVariant = MutedCharcoalText,
    outline = WarmBorderGray,
    error = CrimsonAlert,
    onError = PureWhiteSurface
)

private val ClodyDarkColorScheme = darkColorScheme(
    primary = AlabasterCanvas,
    onPrimary = DeepCharcoal,
    primaryContainer = DarkSecondarySurface,
    onPrimaryContainer = DarkTextPrimary,
    secondary = DarkTextSecondary,
    onSecondary = DarkCanvas,
    secondaryContainer = DarkSecondarySurface,
    onSecondaryContainer = DarkTextPrimary,
    tertiary = Color(0xFF9E8CFF),
    onTertiary = DeepCharcoal,
    tertiaryContainer = Color(0xFF28233C),
    onTertiaryContainer = Color(0xFFDCD6FF),
    background = DarkCanvas,
    onBackground = DarkTextPrimary,
    surface = DarkSurface,
    onSurface = DarkTextPrimary,
    surfaceVariant = DarkSecondarySurface,
    onSurfaceVariant = DarkTextSecondary,
    outline = Color(0xFF343430),
    error = Color(0xFFEF4444),
    onError = PureWhiteSurface
)

val ClodyShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

val LocalAnimationsEnabled = staticCompositionLocalOf { true }

private fun scaledTypography(scale: Float): Typography {
    val s = scale.coerceIn(0.94f, 1.15f)
    return Typography(
        displaySmall = ClodyTypography.displaySmall.copy(
            fontSize = (30f * s).sp,
            lineHeight = (36f * s).sp
        ),
        headlineMedium = ClodyTypography.headlineMedium.copy(
            fontSize = (24f * s).sp,
            lineHeight = (30f * s).sp
        ),
        titleLarge = ClodyTypography.titleLarge.copy(
            fontSize = (20f * s).sp,
            lineHeight = (26f * s).sp
        ),
        titleMedium = ClodyTypography.titleMedium.copy(
            fontSize = (16f * s).sp,
            lineHeight = (22f * s).sp
        ),
        bodyLarge = ClodyTypography.bodyLarge.copy(
            fontSize = (15f * s).sp,
            lineHeight = (22f * s).sp
        ),
        bodyMedium = ClodyTypography.bodyMedium.copy(
            fontSize = (13.5f * s).sp,
            lineHeight = (19f * s).sp
        ),
        labelLarge = ClodyTypography.labelLarge.copy(
            fontSize = (14f * s).sp,
            lineHeight = (20f * s).sp
        ),
        labelMedium = ClodyTypography.labelMedium.copy(
            fontSize = (12.5f * s).sp,
            lineHeight = (17f * s).sp
        ),
        labelSmall = ClodyTypography.labelSmall.copy(
            fontSize = (11.5f * s).sp,
            lineHeight = (15f * s).sp
        )
    )
}

@Composable
fun ClodyTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    animationsEnabled: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> ClodyDarkColorScheme
        else -> ClodyLightColorScheme
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val widthDp = maxWidth.value
        val scale = remember(widthDp) { (widthDp / 390f).coerceIn(0.94f, 1.16f) }
        val metrics = remember(widthDp, scale) {
            ClodyMetrics(
                scale = scale,
                horizontalPadding = (16f * scale).coerceIn(14f, 24f).dp,
                cardCornerRadius = (22f * scale).coerceIn(18f, 26f).dp,
                primaryButtonHeight = (50f * scale).coerceIn(48f, 56f).dp,
                navBarHeight = 68.dp,
                navIconSize = 24.dp,
                galleryMinCellSize = (110f * scale).coerceIn(104f, 140f).dp,
                isWideScreen = widthDp >= 600f
            )
        }
        val typography = remember(scale) { scaledTypography(scale) }

        CompositionLocalProvider(
            LocalAnimationsEnabled provides animationsEnabled,
            LocalClodyMetrics provides metrics
        ) {
            MaterialTheme(
                colorScheme = colorScheme,
                typography = typography,
                shapes = ClodyShapes,
                content = content
            )
        }
    }
}
