package com.example.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CollectionsBookmark
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PermMedia
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.local.FileEntity
import com.example.files.LocalMediaCandidate
import com.example.media.formatDuration
import com.example.service.TransferBatchSummary
import com.example.telegram.TelegramConnectionState
import com.example.ui.theme.LocalClodyMetrics
import com.example.ui.theme.VideoIconIndigo
import com.example.ui.theme.VideoTintSurface
import com.example.ui.theme.bounceClick
import kotlinx.coroutines.flow.StateFlow
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun GalleryScreen(
    mediaFiles: List<FileEntity>,
    detectedLocalMedia: List<LocalMediaCandidate>,
    hasMediaPermission: Boolean,
    connectionState: TelegramConnectionState,
    batchSummaryFlow: StateFlow<TransferBatchSummary>,
    onRequestMediaPermission: () -> Unit,
    onOpenUploadPicker: () -> Unit,
    onOpenOrganizationHub: () -> Unit,
    onOpenTransfers: () -> Unit,
    onUploadDetectedLocal: () -> Unit,
    onDismissDetectedLocal: () -> Unit,
    onOpenPhoto: (FileEntity) -> Unit,
    onOpenVideo: (FileEntity) -> Unit,
    onOpenFileMenu: (FileEntity) -> Unit,
    onOpenConnectionSheet: () -> Unit
) {
    val metrics = LocalClodyMetrics.current
    val dateFormatter = remember { SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()) }
    val groupedByDate = remember(mediaFiles) {
        mediaFiles.groupBy { dateFormatter.format(Date(it.createdAt)) }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = metrics.galleryMinCellSize),
            contentPadding = PaddingValues(
                start = metrics.horizontalPadding,
                end = metrics.horizontalPadding,
                top = 12.dp,
                bottom = 160.dp
            ),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
        ) {
            // Header + Connection Pill + Gallery Search Trigger + Live Transfer Progress Ring
            item(span = { GridItemSpan(maxLineSpan) }, key = "gallery_header", contentType = "header") {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Gallery", style = MaterialTheme.typography.displaySmall)
                        TelegramConnectionStatusPill(state = connectionState, onClick = onOpenConnectionSheet)
                    }
                    Spacer(modifier = Modifier.height(12.dp))

                    // Search Bar Pill (opens Gallery Organization Hub: Favorites, Trash, Albums) + Render-Isolated Transfer Ring
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            color = MaterialTheme.colorScheme.surface,
                            shape = RoundedCornerShape(28.dp),
                            tonalElevation = 1.dp,
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 50.dp)
                                .clip(RoundedCornerShape(28.dp))
                                .bounceClick(onClick = onOpenOrganizationHub)
                                .testTag("gallery_search_input")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 13.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Default.Search,
                                    contentDescription = "Search & Albums",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "Search, Albums, Favorites",
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Icon(
                                    Icons.Default.CollectionsBookmark,
                                    contentDescription = "Albums",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        LiveTransferRingButton(
                            batchSummaryFlow = batchSummaryFlow,
                            onClick = onOpenTransfers
                        )
                    }
                }
            }

            // Contextual Media Permission Banner (only if not yet granted)
            if (!hasMediaPermission) {
                item(span = { GridItemSpan(maxLineSpan) }, key = "media_perm_banner", contentType = "banner") {
                    Surface(
                        color = MaterialTheme.colorScheme.surface,
                        shape = RoundedCornerShape(22.dp),
                        modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.surfaceVariant),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.PermMedia, contentDescription = null)
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Auto-Detect New Media", style = MaterialTheme.typography.titleMedium)
                                Text(
                                    "Allow media access to scan new device photos & videos for backup.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = onRequestMediaPermission,
                                shape = RoundedCornerShape(18.dp),
                                modifier = Modifier.height(42.dp)
                            ) {
                                Text("Allow", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            // Smart Auto-Backup Prompt Card (STRICTLY ONLY when real new local files are detected)
            if (detectedLocalMedia.isNotEmpty()) {
                item(span = { GridItemSpan(maxLineSpan) }, key = "smart_backup_card", contentType = "backup_card") {
                    Surface(
                        color = MaterialTheme.colorScheme.surface,
                        shape = RoundedCornerShape(22.dp),
                        tonalElevation = 1.dp,
                        modifier = Modifier.fillMaxWidth().padding(top = 6.dp).testTag("detected_media_card")
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "Found ${detectedLocalMedia.size} items. Do you want to upload them?",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(detectedLocalMedia, key = { it.id }) { item ->
                                    Box(
                                        modifier = Modifier
                                            .size(66.dp)
                                            .clip(RoundedCornerShape(14.dp))
                                            .background(MaterialTheme.colorScheme.surfaceVariant)
                                    ) {
                                        if (item.thumbnailPath != null && File(item.thumbnailPath).exists()) {
                                            AsyncImage(
                                                model = File(item.thumbnailPath),
                                                contentDescription = item.displayName,
                                                contentScale = ContentScale.Crop,
                                                modifier = Modifier.fillMaxSize()
                                            )
                                        } else {
                                            Icon(
                                                Icons.Default.VideoFile,
                                                contentDescription = null,
                                                modifier = Modifier.align(Alignment.Center)
                                            )
                                        }
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                OutlinedButton(
                                    onClick = onDismissDetectedLocal,
                                    shape = RoundedCornerShape(22.dp),
                                    modifier = Modifier.weight(1f).height(46.dp)
                                ) {
                                    Text("Cancel")
                                }
                                Button(
                                    onClick = onUploadDetectedLocal,
                                    shape = RoundedCornerShape(22.dp),
                                    modifier = Modifier.weight(1f).height(46.dp)
                                ) {
                                    Text("Upload")
                                }
                            }
                        }
                    }
                }
            }

            // Clean 100% Empty State when no media has been uploaded
            if (groupedByDate.isEmpty()) {
                item(span = { GridItemSpan(maxLineSpan) }, key = "gallery_empty", contentType = "empty") {
                    ClodyEmptyStateCard(
                        title = "No files yet",
                        subtitle = "Tap + Upload to add your photos, videos, or files",
                        ctaLabel = "Upload",
                        onCtaClick = onOpenUploadPicker,
                        modifier = Modifier.padding(top = 18.dp)
                    )
                }
            } else {
                groupedByDate.forEach { (dateLabel, itemsInGroup) ->
                    item(
                        span = { GridItemSpan(maxLineSpan) },
                        key = "date_$dateLabel",
                        contentType = "date_header"
                    ) {
                        Text(
                            text = dateLabel,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)
                        )
                    }

                    items(
                        items = itemsInGroup,
                        key = { it.id },
                        contentType = { if (it.isVideo) "video_thumb" else "image_thumb" }
                    ) { file ->
                        val thumbPath = file.activeThumbnailPath
                        Box(
                            modifier = Modifier
                                .aspectRatio(1f)
                                .clip(RoundedCornerShape(16.dp))
                                .background(if (file.isVideo) VideoTintSurface else MaterialTheme.colorScheme.surfaceVariant)
                                .bounceClick(
                                    onLongClick = { onOpenFileMenu(file) }
                                ) {
                                    if (file.isVideo) onOpenVideo(file) else onOpenPhoto(file)
                                }
                                .testTag("gallery_item_${file.id}")
                        ) {
                            if (thumbPath != null && File(thumbPath).exists()) {
                                AsyncImage(
                                    model = File(thumbPath),
                                    contentDescription = file.name,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.VideoFile,
                                    contentDescription = file.name,
                                    tint = VideoIconIndigo,
                                    modifier = Modifier.size(34.dp).align(Alignment.Center)
                                )
                            }

                            if (file.isVideo) {
                                Surface(
                                    color = Color.Black.copy(alpha = 0.68f),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .padding(6.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            Icons.Default.PlayArrow,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(12.dp)
                                        )
                                        Spacer(modifier = Modifier.width(2.dp))
                                        Text(
                                            text = if (file.durationMs > 0L) formatDuration(file.durationMs) else "Video",
                                            color = Color.White,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }
                            }

                            IconButton(
                                onClick = { onOpenFileMenu(file) },
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .padding(4.dp)
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(Color.Black.copy(alpha = 0.45f))
                            ) {
                                Icon(
                                    Icons.Default.MoreVert,
                                    contentDescription = "More options for ${file.name}",
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Gallery Bottom-Right Elevated Floating "+ Upload" Black Pill CTA (positioned cleanly above floating nav bar)
        Surface(
            color = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
            shape = RoundedCornerShape(28.dp),
            shadowElevation = 10.dp,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .navigationBarsPadding()
                .padding(end = metrics.horizontalPadding, bottom = 92.dp)
                .heightIn(min = 52.dp)
                .clip(RoundedCornerShape(28.dp))
                .bounceClick(onClick = onOpenUploadPicker)
                .testTag("gallery_upload_button")
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Upload",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
