package com.example.ui

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.provider.DocumentsContract
import android.provider.Settings
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ClodyApplication
import com.example.data.local.AppSettings
import com.example.data.local.DownloadRecordEntity
import com.example.data.local.FileEntity
import com.example.data.local.FolderEntity
import com.example.data.local.GalleryAlbumEntity
import com.example.data.local.SortOption
import com.example.data.local.ThemeMode
import com.example.data.local.UploadTaskEntity
import com.example.files.DeviceStorageStats
import com.example.files.DuplicateGroup
import com.example.files.InstalledAppItem
import com.example.files.LocalFileItem
import com.example.files.LocalMediaCandidate
import com.example.media.ClodyStreamCache
import com.example.media.LocalFirstResolver
import com.example.media.ResolvedMediaSource
import com.example.media.ThumbnailGenerator
import com.example.service.TransferBatchSummary
import com.example.service.UploadCandidate
import com.example.telegram.TelegramAuthStep
import com.example.telegram.TelegramConnectionState
import com.example.telegram.TelegramUserProfile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

enum class SearchCategory(val label: String) {
    ALL("All"),
    IMAGES("Images"),
    VIDEOS("Videos"),
    AUDIO("Audio"),
    DOCS("Docs"),
    APPS("Apps"),
    ARCHIVES("Archives")
}

enum class PendingUploadIntent {
    NONE,
    GALLERY_MEDIA,
    FOLDERS_CHOOSER,
    DETECTED_AUTO_BACKUP,
    LOCAL_URIS
}

@OptIn(ExperimentalCoroutinesApi::class)
class ClodyViewModel(application: Application) : AndroidViewModel(application) {

    private val container = (application as ClodyApplication).container
    private val dao = container.dao
    val secureStorage = container.secureStorage
    private val settingsRepo = container.settingsRepository
    val telegramClient = container.telegramClient
    private val transferManager = container.transferManager
    val deviceFileManager = container.deviceFileManager

    val settings: StateFlow<AppSettings> = settingsRepo.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettings())

    val connectionState: StateFlow<TelegramConnectionState> = telegramClient.connectionState
    val authStep: StateFlow<TelegramAuthStep> = telegramClient.authStep
    val userProfile: StateFlow<TelegramUserProfile?> = telegramClient.userProfile

    val galleryMedia: StateFlow<List<FileEntity>> = dao.observeGalleryMedia()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val galleryAlbums: StateFlow<List<GalleryAlbumEntity>> = dao.observeGalleryAlbums()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favoriteGalleryMedia: StateFlow<List<FileEntity>> = dao.observeFavoriteGalleryMedia()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val deletedGalleryMedia: StateFlow<List<FileEntity>> = dao.observeDeletedGalleryMedia()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allActiveFiles: StateFlow<List<FileEntity>> = dao.observeActiveFiles()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val deletedFiles: StateFlow<List<FileEntity>> = dao.observeDeletedFiles()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val largeCloudFiles: StateFlow<List<FileEntity>> = dao.observeLargeFiles()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val uploadTasks: StateFlow<List<UploadTaskEntity>> = dao.observeActiveUploadTasks()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val downloadRecords: StateFlow<List<DownloadRecordEntity>> = dao.observeActiveDownloadRecords()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val transferBatchSummary: StateFlow<TransferBatchSummary> = container.transferBatchTracker.batchSummary
    val downloadSpeeds: StateFlow<Map<Long, Long>> = container.transferBatchTracker.downloadSpeeds

    val totalCloudBytes: StateFlow<Long> = dao.observeTotalCloudBytes()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    // Folders navigation
    private val _currentFolderId = MutableStateFlow<Long?>(null)
    val currentFolderId: StateFlow<Long?> = _currentFolderId.asStateFlow()

    private val _breadcrumbs = MutableStateFlow<List<FolderEntity>>(emptyList())
    val breadcrumbs: StateFlow<List<FolderEntity>> = _breadcrumbs.asStateFlow()

    val currentSubfolders: StateFlow<List<FolderEntity>> = _currentFolderId
        .flatMapLatest { parentId -> dao.observeFolders(parentId) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val currentFolderFiles: StateFlow<List<FileEntity>> = combine(
        _currentFolderId.flatMapLatest { fid -> dao.observeFilesInFolder(fid) },
        settings
    ) { files, appSettings ->
        val filtered = if (appSettings.showHiddenFiles) files else files.filter { !it.name.startsWith(".") }
        when (appSettings.sortOption) {
            SortOption.DATE_DESC -> filtered.sortedByDescending { it.createdAt }
            SortOption.NAME_ASC -> filtered.sortedBy { it.name.lowercase() }
            SortOption.SIZE_DESC -> filtered.sortedByDescending { it.sizeBytes }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Search
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _searchCategory = MutableStateFlow(SearchCategory.ALL)
    val searchCategory: StateFlow<SearchCategory> = _searchCategory.asStateFlow()

    val searchResults: StateFlow<List<FileEntity>> = combine(
        _searchQuery,
        _searchCategory,
        settings
    ) { q, cat, appSettings -> Triple(q.trim(), cat, appSettings) }
        .flatMapLatest { (q, cat, appSettings) ->
            val baseFlow = if (q.isBlank()) {
                dao.observeActiveFiles()
            } else {
                val safeFts = q.replace("\"", "").split(Regex("\\s+"))
                    .filter { it.isNotBlank() }
                    .joinToString(" ") { "$it*" }
                if (safeFts.isNotBlank()) dao.searchFilesFts(safeFts) else dao.searchFilesLike(q)
            }
            baseFlow.combine(MutableStateFlow(cat to appSettings.showHiddenFiles)) { list, (category, showHidden) ->
                list.filter { file ->
                    val hiddenOk = showHidden || !file.name.startsWith(".")
                    val catOk = when (category) {
                        SearchCategory.ALL -> true
                        SearchCategory.IMAGES -> file.isImage
                        SearchCategory.VIDEOS -> file.isVideo
                        SearchCategory.AUDIO -> file.isAudio
                        SearchCategory.DOCS -> file.isDocument
                        SearchCategory.APPS -> file.isApp
                        SearchCategory.ARCHIVES -> file.isArchive
                    }
                    hiddenOk && catOk
                }
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Real detected device media (strictly empty unless real new local files are scanned)
    private val _detectedLocalMedia = MutableStateFlow<List<LocalMediaCandidate>>(emptyList())
    val detectedLocalMedia: StateFlow<List<LocalMediaCandidate>> = _detectedLocalMedia.asStateFlow()

    // Upload Preview Modal candidates
    private val _uploadPreviewCandidates = MutableStateFlow<List<UploadCandidate>>(emptyList())
    val uploadPreviewCandidates: StateFlow<List<UploadCandidate>> = _uploadPreviewCandidates.asStateFlow()

    // Auth / Connect Bottom Sheet
    private val _showConnectSheet = MutableStateFlow(false)
    val showConnectSheet: StateFlow<Boolean> = _showConnectSheet.asStateFlow()

    private val _authBusy = MutableStateFlow(false)
    val authBusy: StateFlow<Boolean> = _authBusy.asStateFlow()

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    // Storage & Tools state
    private val _deviceStorage = MutableStateFlow(deviceFileManager.getDeviceStorageStats())
    val deviceStorage: StateFlow<DeviceStorageStats> = _deviceStorage.asStateFlow()

    private val _streamCacheBytes = MutableStateFlow(ClodyStreamCache.getStreamCacheSizeBytes(application))
    val streamCacheBytes: StateFlow<Long> = _streamCacheBytes.asStateFlow()

    private val _localDirectoryItems = MutableStateFlow<List<LocalFileItem>>(emptyList())
    val localDirectoryItems: StateFlow<List<LocalFileItem>> = _localDirectoryItems.asStateFlow()

    private val _currentLocalDir = MutableStateFlow(deviceFileManager.getRootDirectory())
    val currentLocalDir: StateFlow<File> = _currentLocalDir.asStateFlow()

    private val _largeLocalFiles = MutableStateFlow<List<LocalFileItem>>(emptyList())
    val largeLocalFiles: StateFlow<List<LocalFileItem>> = _largeLocalFiles.asStateFlow()

    private val _installedApps = MutableStateFlow<List<InstalledAppItem>>(emptyList())
    val installedApps: StateFlow<List<InstalledAppItem>> = _installedApps.asStateFlow()

    private val _duplicateGroups = MutableStateFlow<List<DuplicateGroup>>(emptyList())
    val duplicateGroups: StateFlow<List<DuplicateGroup>> = _duplicateGroups.asStateFlow()

    // Media viewer active targets
    private val _activeVideoFile = MutableStateFlow<FileEntity?>(null)
    val activeVideoFile: StateFlow<FileEntity?> = _activeVideoFile.asStateFlow()

    private val _activeImageFile = MutableStateFlow<FileEntity?>(null)
    val activeImageFile: StateFlow<FileEntity?> = _activeImageFile.asStateFlow()

    private val _activeAudioFile = MutableStateFlow<FileEntity?>(null)
    val activeAudioFile: StateFlow<FileEntity?> = _activeAudioFile.asStateFlow()

    private val _activeDocumentFile = MutableStateFlow<FileEntity?>(null)
    val activeDocumentFile: StateFlow<FileEntity?> = _activeDocumentFile.asStateFlow()

    private val _binaryDownloadBanner = MutableStateFlow<BinaryBannerState?>(null)
    val binaryDownloadBanner: StateFlow<BinaryBannerState?> = _binaryDownloadBanner.asStateFlow()

    private val _completedAuthUploadIntent = MutableStateFlow(PendingUploadIntent.NONE)
    val completedAuthUploadIntent: StateFlow<PendingUploadIntent> = _completedAuthUploadIntent.asStateFlow()

    private var queuedPendingIntent = PendingUploadIntent.NONE
    private var queuedLocalUris: List<Uri> = emptyList()

    init {
        viewModelScope.launch {
            // Purge recycle bin items older than 30 days & clean any leftover finished transfer records
            val cutoff = System.currentTimeMillis() - 30L * 24L * 60L * 60L * 1000L
            dao.purgeExpiredRecycleBin(cutoff)
            dao.clearFinishedUploads()
            dao.clearCompletedDownloads()
            refreshStorageMetrics()
        }
    }

    fun showMessage(msg: String) {
        _snackbarMessage.value = msg
    }

    fun clearMessage() {
        _snackbarMessage.value = null
    }

    fun openConnectSheet() {
        _authError.value = null
        _showConnectSheet.value = true
    }

    fun dismissConnectSheet() {
        _showConnectSheet.value = false
    }

    fun sendAuthCode(apiIdStr: String, apiHash: String, phone: String) {
        val apiId = apiIdStr.trim().toIntOrNull()
        if (apiId == null || apiId <= 0) {
            _authError.value = "Enter a valid numeric Telegram API ID"
            return
        }
        viewModelScope.launch {
            _authBusy.value = true
            _authError.value = null
            val res = telegramClient.connectAndSendCode(apiId, apiHash, phone)
            _authBusy.value = false
            res.onFailure { err ->
                _authError.value = err.message ?: "Failed to connect to Telegram servers"
            }
        }
    }

    fun requireAuthForUpload(intent: PendingUploadIntent, onAuthorized: () -> Unit) {
        if (secureStorage.isLoggedIn() && authStep.value is TelegramAuthStep.Authorized) {
            onAuthorized()
        } else {
            queuedPendingIntent = intent
            openConnectSheet()
        }
    }

    fun consumeCompletedAuthUploadIntent() {
        _completedAuthUploadIntent.value = PendingUploadIntent.NONE
    }

    private fun handlePostAuthSuccess() {
        _showConnectSheet.value = false
        showMessage("Connected to Telegram Live Server")
        syncFromTelegram()
        when (val pending = queuedPendingIntent) {
            PendingUploadIntent.NONE -> Unit
            PendingUploadIntent.DETECTED_AUTO_BACKUP -> {
                queuedPendingIntent = PendingUploadIntent.NONE
                uploadDetectedLocalMedia()
            }
            PendingUploadIntent.LOCAL_URIS -> {
                queuedPendingIntent = PendingUploadIntent.NONE
                val uris = queuedLocalUris
                queuedLocalUris = emptyList()
                if (uris.isNotEmpty()) prepareUploadFromUris(uris)
            }
            PendingUploadIntent.GALLERY_MEDIA, PendingUploadIntent.FOLDERS_CHOOSER -> {
                queuedPendingIntent = PendingUploadIntent.NONE
                _completedAuthUploadIntent.value = pending
            }
        }
    }

    fun verifyOtpCode(code: String) {
        viewModelScope.launch {
            _authBusy.value = true
            _authError.value = null
            val res = telegramClient.verifyOtpCode(code)
            _authBusy.value = false
            res.onSuccess {
                handlePostAuthSuccess()
            }.onFailure { err ->
                _authError.value = err.message ?: "Verification failed"
            }
        }
    }

    fun verifyTwoFactorPassword(password: String) {
        viewModelScope.launch {
            _authBusy.value = true
            _authError.value = null
            val res = telegramClient.verifyTwoFactorPassword(password)
            _authBusy.value = false
            res.onSuccess {
                handlePostAuthSuccess()
            }.onFailure { err ->
                _authError.value = err.message ?: "Invalid 2FA password"
            }
        }
    }

    fun logout() {
        viewModelScope.launch {
            telegramClient.logout()
            showMessage("Signed out of Telegram")
        }
    }

    fun syncFromTelegram() {
        if (!secureStorage.isLoggedIn()) {
            openConnectSheet()
            return
        }
        viewModelScope.launch {
            val res = telegramClient.syncFromTelegramChannel()
            res.onSuccess { count ->
                showMessage(if (count > 0) "Synced $count cloud items" else "Cloud index is up to date")
            }.onFailure { err ->
                showMessage("Sync error: ${err.message}")
            }
        }
    }

    fun forceCloudIndexSync() {
        if (!secureStorage.isLoggedIn()) {
            openConnectSheet()
            return
        }
        viewModelScope.launch {
            telegramClient.pushCloudIndexSnapshot()
                .onSuccess { showMessage("Cloud index backed up to Telegram") }
                .onFailure { showMessage("Index backup failed: ${it.message}") }
        }
    }

    // --- Real Local Media Scan (NO dummy data) ---
    fun refreshLocalMediaScan() {
        viewModelScope.launch {
            val existing = dao.getAllActiveFilesOnce().map { it.name to it.sizeBytes }.toSet()
            val dismissed = settings.value.dismissedBackupIds
            val found = deviceFileManager.scanUnbackedUpLocalMedia(existing, dismissed)
            _detectedLocalMedia.value = found
        }
    }

    fun dismissLocalBackupCard() {
        viewModelScope.launch {
            val ids = _detectedLocalMedia.value.map { it.id }.toSet()
            settingsRepo.addDismissedBackupIds(ids)
            _detectedLocalMedia.value = emptyList()
        }
    }

    fun uploadDetectedLocalMedia() {
        if (!secureStorage.isLoggedIn()) {
            queuedPendingIntent = PendingUploadIntent.DETECTED_AUTO_BACKUP
            openConnectSheet()
            return
        }
        val items = _detectedLocalMedia.value
        if (items.isEmpty()) return
        viewModelScope.launch {
            val candidates = items.map {
                UploadCandidate(
                    uri = it.uri,
                    fileName = it.displayName,
                    mimeType = it.mimeType,
                    sizeBytes = it.sizeBytes,
                    durationMs = it.durationMs,
                    extractedThumbnailPath = it.thumbnailPath
                )
            }
            transferManager.enqueueUploads(candidates, currentFolderId.value, currentFolderPathString())
            settingsRepo.addDismissedBackupIds(items.map { it.id }.toSet())
            _detectedLocalMedia.value = emptyList()
            showMessage("Added ${candidates.size} items to background upload queue")
        }
    }

    // --- Upload Staging + Custom Video Thumbnail ---
    fun prepareUploadFromUris(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            val prepared = transferManager.prepareUploadCandidates(uris)
            _uploadPreviewCandidates.value = prepared
        }
    }

    fun setCustomThumbnailForCandidate(candidateUri: Uri, imageUri: Uri) {
        viewModelScope.launch {
            val savedPath = ThumbnailGenerator.saveCustomThumbnail(
                context = getApplication(),
                imageUri = imageUri,
                uniqueKey = candidateUri.toString()
            )
            if (savedPath != null) {
                _uploadPreviewCandidates.value = _uploadPreviewCandidates.value.map { c ->
                    if (c.uri == candidateUri) c.copy(customThumbnailPath = savedPath) else c
                }
            }
        }
    }

    fun dismissUploadPreview() {
        _uploadPreviewCandidates.value = emptyList()
    }

    fun confirmEnqueueUploads() {
        val candidates = _uploadPreviewCandidates.value
        if (candidates.isEmpty()) return
        if (!secureStorage.isLoggedIn()) {
            openConnectSheet()
            return
        }
        viewModelScope.launch {
            transferManager.enqueueUploads(candidates, currentFolderId.value, currentFolderPathString())
            _uploadPreviewCandidates.value = emptyList()
            showMessage("Uploading ${candidates.size} item(s) in background")
        }
    }

    fun changeThumbnailForUploadedVideo(fileId: Long, imageUri: Uri) {
        viewModelScope.launch {
            val path = ThumbnailGenerator.saveCustomThumbnail(
                context = getApplication(),
                imageUri = imageUri,
                uniqueKey = "uploaded_$fileId"
            )
            if (path != null) {
                dao.updateCustomThumbnail(fileId, path)
                showMessage("Video thumbnail updated")
            }
        }
    }

    // --- Folder Navigation & File Operations ---
    fun createFolder(name: String) {
        val clean = name.trim()
        if (clean.isEmpty()) return
        viewModelScope.launch {
            dao.insertFolder(FolderEntity(name = clean, parentId = _currentFolderId.value))
            if (secureStorage.isLoggedIn()) {
                telegramClient.pushCloudIndexSnapshot()
            }
        }
    }

    fun openFolder(folder: FolderEntity) {
        _currentFolderId.value = folder.id
        _breadcrumbs.value = _breadcrumbs.value + folder
    }

    fun navigateToRootFolder() {
        _currentFolderId.value = null
        _breadcrumbs.value = emptyList()
    }

    fun navigateToBreadcrumb(folderId: Long) {
        val idx = _breadcrumbs.value.indexOfFirst { it.id == folderId }
        if (idx >= 0) {
            _currentFolderId.value = folderId
            _breadcrumbs.value = _breadcrumbs.value.take(idx + 1)
        }
    }

    fun navigateUpFolder(): Boolean {
        val crumbs = _breadcrumbs.value
        if (crumbs.isEmpty()) return false
        val updated = crumbs.dropLast(1)
        _breadcrumbs.value = updated
        _currentFolderId.value = updated.lastOrNull()?.id
        return true
    }

    private fun currentFolderPathString(): String {
        val crumbs = _breadcrumbs.value
        return if (crumbs.isEmpty()) "Cloud" else "Cloud / " + crumbs.joinToString(" / ") { it.name }
    }

    fun toggleFavorite(file: FileEntity) {
        val nextFav = !file.isFavorite
        if (_activeImageFile.value?.id == file.id) {
            _activeImageFile.value = _activeImageFile.value?.copy(isFavorite = nextFav)
        }
        if (_activeVideoFile.value?.id == file.id) {
            _activeVideoFile.value = _activeVideoFile.value?.copy(isFavorite = nextFav)
        }
        viewModelScope.launch {
            dao.setFileFavorite(file.id, nextFav)
        }
    }

    // --- Gallery Albums (strictly separate from File Folders) ---
    fun createGalleryAlbum(name: String, initialFile: FileEntity? = null) {
        val clean = name.trim()
        if (clean.isEmpty()) return
        viewModelScope.launch {
            val newId = dao.insertAlbum(
                GalleryAlbumEntity(
                    name = clean,
                    coverThumbnailPath = initialFile?.activeThumbnailPath
                )
            )
            if (initialFile != null) {
                dao.setFileAlbum(initialFile.id, newId)
                if (_activeImageFile.value?.id == initialFile.id) {
                    _activeImageFile.value = _activeImageFile.value?.copy(albumId = newId)
                }
                if (_activeVideoFile.value?.id == initialFile.id) {
                    _activeVideoFile.value = _activeVideoFile.value?.copy(albumId = newId)
                }
                showMessage("Created album \"$clean\" & added ${initialFile.name}")
            } else {
                showMessage("Created album \"$clean\"")
            }
            if (secureStorage.isLoggedIn()) {
                telegramClient.pushCloudIndexSnapshot()
            }
        }
    }

    fun assignFileToAlbum(file: FileEntity, album: GalleryAlbumEntity) {
        viewModelScope.launch {
            dao.setFileAlbum(file.id, album.id)
            if (album.coverThumbnailPath.isNullOrBlank() && !file.activeThumbnailPath.isNullOrBlank()) {
                dao.insertAlbum(album.copy(coverThumbnailPath = file.activeThumbnailPath))
            }
            if (_activeImageFile.value?.id == file.id) {
                _activeImageFile.value = _activeImageFile.value?.copy(albumId = album.id)
            }
            if (_activeVideoFile.value?.id == file.id) {
                _activeVideoFile.value = _activeVideoFile.value?.copy(albumId = album.id)
            }
            showMessage("Added to ${album.name}")
            if (secureStorage.isLoggedIn()) {
                telegramClient.pushCloudIndexSnapshot()
            }
        }
    }

    fun removeFileFromAlbum(file: FileEntity) {
        viewModelScope.launch {
            dao.setFileAlbum(file.id, null)
            if (_activeImageFile.value?.id == file.id) {
                _activeImageFile.value = _activeImageFile.value?.copy(albumId = null)
            }
            if (_activeVideoFile.value?.id == file.id) {
                _activeVideoFile.value = _activeVideoFile.value?.copy(albumId = null)
            }
            showMessage("Removed from album")
        }
    }

    fun deleteGalleryAlbum(album: GalleryAlbumEntity) {
        viewModelScope.launch {
            dao.clearAlbumFromFiles(album.id)
            dao.deleteAlbum(album.id)
            showMessage("Deleted album \"${album.name}\"")
            if (secureStorage.isLoggedIn()) {
                telegramClient.pushCloudIndexSnapshot()
            }
        }
    }

    fun emptyGalleryTrash() {
        viewModelScope.launch {
            val items = deletedGalleryMedia.value
            dao.emptyGalleryTrash()
            items.forEach { ClodyStreamCache.deleteFileCache(getApplication(), it) }
            showMessage("Gallery trash emptied")
        }
    }

    fun renameFile(file: FileEntity, newName: String) {
        val clean = newName.trim()
        if (clean.isEmpty()) return
        viewModelScope.launch {
            val ext = clean.substringAfterLast('.', file.extension)
            dao.updateFile(file.copy(name = clean, extension = ext))
        }
    }

    fun deleteFile(file: FileEntity) {
        viewModelScope.launch {
            if (settings.value.useRecycleBin && !file.isDeleted) {
                dao.softDeleteFile(file.id)
                showMessage("Moved to Recycle Bin")
            } else {
                dao.permanentlyDeleteFile(file.id)
                ClodyStreamCache.deleteFileCache(getApplication(), file)
                showMessage("Permanently deleted")
            }
        }
    }

    fun restoreFile(file: FileEntity) {
        viewModelScope.launch {
            dao.restoreFile(file.id)
            showMessage("Restored ${file.name}")
        }
    }

    fun permanentlyDeleteFile(file: FileEntity) {
        viewModelScope.launch {
            dao.permanentlyDeleteFile(file.id)
            ClodyStreamCache.deleteFileCache(getApplication(), file)
        }
    }

    fun downloadToPublicGallery(file: FileEntity) {
        showMessage("Saving ${file.name} to phone storage...")
        transferManager.exportToPublicStorage(file) { res ->
            res.onSuccess { path ->
                showMessage("Saved to $path")
            }.onFailure { err ->
                showMessage("Download failed: ${err.message}")
            }
        }
    }

    fun shareFile(file: FileEntity, cachedFile: File?) {
        val ctx = getApplication<Application>()
        val target = cachedFile?.takeIf { it.exists() }
            ?: file.activeThumbnailPath?.let { File(it).takeIf(File::exists) }
        if (target == null) {
            showMessage("Download or open media first to share")
            return
        }
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", target)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = file.mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        ctx.startActivity(Intent.createChooser(intent, "Share ${file.name}").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        })
    }

    fun openCloudFile(file: FileEntity) {
        when {
            file.isVideo -> openVideoPlayer(file)
            file.isImage -> openImageViewer(file)
            file.isAudio -> openAudioPlayer(file)
            file.isInAppDocument -> openDocumentReader(file)
            else -> triggerDirectBinaryDownload(file)
        }
    }

    fun openVideoPlayer(file: FileEntity) {
        _activeVideoFile.value = file
    }

    fun closeVideoPlayer() {
        _activeVideoFile.value = null
        refreshStorageMetrics()
    }

    fun openImageViewer(file: FileEntity) {
        _activeImageFile.value = file
    }

    fun closeImageViewer() {
        _activeImageFile.value = null
        refreshStorageMetrics()
    }

    fun openAudioPlayer(file: FileEntity) {
        _activeAudioFile.value = file
    }

    fun closeAudioPlayer() {
        _activeAudioFile.value = null
        refreshStorageMetrics()
    }

    fun openDocumentReader(file: FileEntity) {
        _activeDocumentFile.value = file
    }

    fun closeDocumentReader() {
        _activeDocumentFile.value = null
        refreshStorageMetrics()
    }

    fun triggerDirectBinaryDownload(file: FileEntity) {
        viewModelScope.launch {
            val localCheck = withContext(Dispatchers.IO) {
                LocalFirstResolver.resolve(getApplication(), file)
            }
            if (localCheck is ResolvedMediaSource.LocalDevice) {
                _binaryDownloadBanner.value = BinaryBannerState.Completed(
                    fileName = file.name,
                    message = "${file.name} is Saved on Device ✓ — Open from your device File Manager"
                )
                return@launch
            }
            _binaryDownloadBanner.value = BinaryBannerState.Downloading(file.name)
            transferManager.exportToPublicStorage(file) { res ->
                res.onSuccess {
                    _binaryDownloadBanner.value = BinaryBannerState.Completed(
                        fileName = file.name,
                        message = "Downloaded ${file.name} — Open from your device File Manager"
                    )
                }.onFailure { err ->
                    _binaryDownloadBanner.value = BinaryBannerState.Error(
                        fileName = file.name,
                        message = err.message ?: "Unable to download file"
                    )
                }
            }
        }
    }

    fun dismissBinaryBanner() {
        _binaryDownloadBanner.value = null
    }

    fun pauseUpload(taskId: Long) = transferManager.pauseUpload(taskId)
    fun resumeUpload(taskId: Long) = transferManager.resumeUpload(taskId)
    fun cancelUpload(taskId: Long) = transferManager.cancelUpload(taskId)
    fun cancelDownload(recordId: Long) = transferManager.cancelDownload(recordId)
    fun clearFinishedUploads() { viewModelScope.launch { dao.clearFinishedUploads() } }
    fun clearCompletedDownloads() { viewModelScope.launch { dao.clearCompletedDownloads() } }

    fun updateSearchQuery(q: String) { _searchQuery.value = q }
    fun updateSearchCategory(cat: SearchCategory) { _searchCategory.value = cat }

    // --- Settings & Tools ---
    fun setThemeMode(mode: ThemeMode) { viewModelScope.launch { settingsRepo.setThemeMode(mode) } }
    fun setDynamicColors(enabled: Boolean) { viewModelScope.launch { settingsRepo.setDynamicColors(enabled) } }
    fun setAnimationsEnabled(enabled: Boolean) { viewModelScope.launch { settingsRepo.setAnimationsEnabled(enabled) } }
    fun setShowHiddenFiles(enabled: Boolean) { viewModelScope.launch { settingsRepo.setShowHiddenFiles(enabled) } }
    fun setShowFileExtensions(enabled: Boolean) { viewModelScope.launch { settingsRepo.setShowFileExtensions(enabled) } }
    fun setUseRecycleBin(enabled: Boolean) { viewModelScope.launch { settingsRepo.setUseRecycleBin(enabled) } }
    fun setConfirmBeforeDeleting(enabled: Boolean) { viewModelScope.launch { settingsRepo.setConfirmBeforeDeleting(enabled) } }
    fun setUploadWifiOnly(enabled: Boolean) { viewModelScope.launch { settingsRepo.setUploadWifiOnly(enabled) } }
    fun setZeroStorageMode(enabled: Boolean) { viewModelScope.launch { settingsRepo.setZeroStorageMode(enabled) } }
    fun setGridViewFolders(grid: Boolean) { viewModelScope.launch { settingsRepo.setGridViewFolders(grid) } }
    fun setSortOption(option: SortOption) { viewModelScope.launch { settingsRepo.setSortOption(option) } }

    fun clearStreamCache() {
        viewModelScope.launch(Dispatchers.IO) {
            val freed = ClodyStreamCache.clearStreamCache(getApplication())
            dao.clearAllLocalCachePaths()
            refreshStorageMetrics()
            withContext(Dispatchers.Main) {
                showMessage("Freed ${formatFileSize(freed)} stream cache")
            }
        }
    }

    fun refreshStorageMetrics() {
        _deviceStorage.value = deviceFileManager.getDeviceStorageStats()
        _streamCacheBytes.value = ClodyStreamCache.getStreamCacheSizeBytes(getApplication())
    }

    fun isBatteryOptimizationIgnored(): Boolean {
        val pm = getApplication<Application>().getSystemService(PowerManager::class.java)
        return pm.isIgnoringBatteryOptimizations(getApplication<Application>().packageName)
    }

    fun requestIgnoreBatteryOptimization() {
        val ctx = getApplication<Application>()
        val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
            data = Uri.parse("package:${ctx.packageName}")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        runCatching { ctx.startActivity(intent) }
    }

    fun loadLocalDirectory(dir: File = _currentLocalDir.value) {
        viewModelScope.launch {
            _currentLocalDir.value = dir
            _localDirectoryItems.value = deviceFileManager.listDirectory(dir, settings.value.showHiddenFiles)
        }
    }

    fun uploadLocalFile(item: LocalFileItem) {
        if (item.isDirectory) return
        val uris = listOf(Uri.fromFile(item.file))
        if (!secureStorage.isLoggedIn()) {
            queuedLocalUris = uris
            queuedPendingIntent = PendingUploadIntent.LOCAL_URIS
            openConnectSheet()
            return
        }
        prepareUploadFromUris(uris)
    }

    fun scanLargeLocalFiles() {
        viewModelScope.launch {
            _largeLocalFiles.value = deviceFileManager.scanLargeLocalFiles()
        }
    }

    fun scanDuplicates() {
        viewModelScope.launch {
            _duplicateGroups.value = deviceFileManager.findDuplicateCloudFiles(allActiveFiles.value)
        }
    }

    fun loadInstalledApps() {
        viewModelScope.launch {
            _installedApps.value = deviceFileManager.getInstalledUserApps()
        }
    }

    fun backupApkToCloud(app: InstalledAppItem) {
        val uris = listOf(Uri.fromFile(File(app.apkPath)))
        if (!secureStorage.isLoggedIn()) {
            queuedLocalUris = uris
            queuedPendingIntent = PendingUploadIntent.LOCAL_URIS
            openConnectSheet()
            return
        }
        prepareUploadFromUris(uris)
    }

    fun compressFiles(uris: List<Uri>, archiveName: String) {
        viewModelScope.launch {
            deviceFileManager.compressToZip(uris, archiveName)
                .onSuccess { file -> showMessage("Created ${file.name} (${formatFileSize(file.length())})") }
                .onFailure { err -> showMessage("Compression failed: ${err.message}") }
        }
    }

    fun extractArchive(uri: Uri) {
        viewModelScope.launch {
            deviceFileManager.extractArchive(uri)
                .onSuccess { dir -> showMessage("Extracted to ${dir.name}/") }
                .onFailure { err -> showMessage("Extraction failed: ${err.message}") }
        }
    }

    fun addSyncedFolder(treeUri: Uri) {
        val ctx = getApplication<Application>()
        runCatching {
            ctx.contentResolver.takePersistableUriPermission(
                treeUri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        }
        viewModelScope.launch {
            settingsRepo.addSyncedFolderUri(treeUri.toString())
            val files = withContext(Dispatchers.IO) {
                val list = mutableListOf<Uri>()
                val docId = DocumentsContract.getTreeDocumentId(treeUri)
                val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, docId)
                ctx.contentResolver.query(
                    childrenUri,
                    arrayOf(
                        DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                        DocumentsContract.Document.COLUMN_MIME_TYPE
                    ),
                    null,
                    null,
                    null
                )?.use { cursor ->
                    while (cursor.moveToNext() && list.size < 25) {
                        val childId = cursor.getString(0)
                        val mime = cursor.getString(1) ?: ""
                        if (mime != DocumentsContract.Document.MIME_TYPE_DIR) {
                            list += DocumentsContract.buildDocumentUriUsingTree(treeUri, childId)
                        }
                    }
                }
                list
            }
            val folderLabel = treeUri.lastPathSegment?.substringAfterLast(':') ?: "Synced"
            if (files.isNotEmpty() && secureStorage.isLoggedIn()) {
                val prepared = transferManager.prepareUploadCandidates(files)
                transferManager.enqueueUploads(prepared, null, folderLabel)
                showMessage("Syncing ${prepared.size} files from $folderLabel")
            } else {
                showMessage("Folder assigned for sync")
            }
        }
    }

    fun removeSyncedFolder(uriString: String) {
        viewModelScope.launch { settingsRepo.removeSyncedFolderUri(uriString) }
    }

    fun rebuildFileIndex() {
        viewModelScope.launch(Dispatchers.IO) {
            dao.rebuildFtsIndex()
            refreshLocalMediaScan()
            withContext(Dispatchers.Main) { showMessage("File index rebuilt") }
        }
    }

    fun optimizeSearchIndex() {
        viewModelScope.launch(Dispatchers.IO) {
            dao.optimizeFtsIndex()
            withContext(Dispatchers.Main) { showMessage("FTS4 search index optimized") }
        }
    }
}

fun formatFileSize(bytes: Long): String {
    if (bytes <= 0L) return "0 B"
    val kb = 1024.0
    val mb = kb * 1024.0
    val gb = mb * 1024.0
    return when {
        bytes >= gb -> String.format("%.1f GB", bytes / gb)
        bytes >= mb -> String.format("%.1f MB", bytes / mb)
        bytes >= kb -> String.format("%.0f KB", bytes / kb)
        else -> "$bytes B"
    }
}
