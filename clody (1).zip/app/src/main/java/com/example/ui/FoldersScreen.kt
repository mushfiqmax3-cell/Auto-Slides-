package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.InsertDriveFile
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.automirrored.filled.ViewList
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.local.FileEntity
import com.example.data.local.FolderEntity
import com.example.data.local.SortOption
import com.example.telegram.TelegramConnectionState
import com.example.ui.theme.AmberConnecting
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.EmeraldConnected
import com.example.ui.theme.FavoriteGold
import com.example.ui.theme.VideoIconIndigo
import com.example.ui.theme.VideoTintSurface
import com.example.ui.theme.bounceClick
import java.io.File

@Composable
fun FoldersScreen(
    connectionState: TelegramConnectionState,
    breadcrumbs: List<FolderEntity>,
    subfolders: List<FolderEntity>,
    files: List<FileEntity>,
    isGridView: Boolean,
    showFileExtensions: Boolean,
    sortOption: SortOption,
    onToggleGridView: (Boolean) -> Unit,
    onChangeSort: (SortOption) -> Unit,
    onJumpToSearch: () -> Unit,
    onSyncCloud: () -> Unit,
    onOpenConnectionSheet: () -> Unit,
    onOpenUploadPicker: () -> Unit,
    onCreateFolder: (String) -> Unit,
    onOpenFolder: (FolderEntity) -> Unit,
    onNavigateRoot: () -> Unit,
    onNavigateBreadcrumb: (Long) -> Unit,
    onNavigateUp: () -> Boolean,
    onOpenFile: (FileEntity) -> Unit,
    onToggleFavorite: (FileEntity) -> Unit,
    onOpenFileMenu: (FileEntity) -> Unit
) {
    var showNewFolderDialog by remember { mutableStateOf(false) }
    var showSortMenu by remember { mutableStateOf(false) }

    BackHandler(enabled = breadcrumbs.isNotEmpty()) {
        onNavigateUp()
    }

    val dotColor = when (connectionState) {
        is TelegramConnectionState.Connected -> EmeraldConnected
        is TelegramConnectionState.Connecting -> AmberConnecting
        is TelegramConnectionState.Disconnected -> CrimsonAlert
    }
    val statusSubtext = when (connectionState) {
        is TelegramConnectionState.Connected -> connectionState.userDisplayName ?: "Connected"
        is TelegramConnectionState.Connecting -> "Connecting..."
        is TelegramConnectionState.Disconnected -> "Tap to Connect"
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(10.dp))

        // Header Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.clickable(onClick = onOpenConnectionSheet)) {
                Text("Cloud", style = MaterialTheme.typography.displaySmall)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(dotColor)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = statusSubtext,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                CircularHeaderIcon(Icons.Default.Search, "Search", onJumpToSearch)
                Box {
                    CircularHeaderIcon(Icons.AutoMirrored.Filled.Sort, "Sort") { showSortMenu = true }
                    DropdownMenu(expanded = showSortMenu, onDismissRequest = { showSortMenu = false }) {
                        DropdownMenuItem(
                            text = { Text("Newest First${if (sortOption == SortOption.DATE_DESC) " ✓" else ""}") },
                            onClick = { onChangeSort(SortOption.DATE_DESC); showSortMenu = false }
                        )
                        DropdownMenuItem(
                            text = { Text("Name A–Z${if (sortOption == SortOption.NAME_ASC) " ✓" else ""}") },
                            onClick = { onChangeSort(SortOption.NAME_ASC); showSortMenu = false }
                        )
                        DropdownMenuItem(
                            text = { Text("Largest First${if (sortOption == SortOption.SIZE_DESC) " ✓" else ""}") },
                            onClick = { onChangeSort(SortOption.SIZE_DESC); showSortMenu = false }
                        )
                    }
                }
                CircularHeaderIcon(
                    icon = if (isGridView) Icons.AutoMirrored.Filled.ViewList else Icons.Default.GridView,
                    desc = "Switch view",
                    onClick = { onToggleGridView(!isGridView) }
                )
                CircularHeaderIcon(Icons.Default.CloudSync, "Sync Cloud", onSyncCloud)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Side-by-side Primary Action Pills: Upload + New Folder
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = onOpenUploadPicker,
                shape = RoundedCornerShape(24.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ),
                modifier = Modifier.weight(1f).height(48.dp).testTag("folders_upload_button")
            ) {
                Icon(Icons.Default.Cloud, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Upload", fontWeight = FontWeight.SemiBold)
            }
            OutlinedButton(
                onClick = { showNewFolderDialog = true },
                shape = RoundedCornerShape(24.dp),
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = MaterialTheme.colorScheme.onSurface
                ),
                modifier = Modifier.weight(1f).height(48.dp).testTag("folders_new_folder_button")
            ) {
                Icon(Icons.Default.CreateNewFolder, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("New folder", fontWeight = FontWeight.SemiBold)
            }
        }

        // Breadcrumb bar when inside nested folders
        if (breadcrumbs.isNotEmpty()) {
            Spacer(modifier = Modifier.height(12.dp))
            LazyRow(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                item(key = "root_crumb") {
                    Surface(
                        color = MaterialTheme.colorScheme.surface,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.clickable(onClick = onNavigateRoot)
                    ) {
                        Text(
                            "Cloud",
                            style = MaterialTheme.typography.labelMedium,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
                items(breadcrumbs, key = { it.id }) { crumb ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.ChevronRight,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(16.dp)
                        )
                        Surface(
                            color = MaterialTheme.colorScheme.surface,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.clickable { onNavigateBreadcrumb(crumb.id) }
                        ) {
                            Text(
                                crumb.name,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (subfolders.isEmpty() && files.isEmpty()) {
            ClodyEmptyStateCard(
                title = if (breadcrumbs.isEmpty()) "No files yet" else "This folder is empty",
                subtitle = "Tap Upload to add your photos, videos, or files",
                ctaLabel = "Upload",
                onCtaClick = onOpenUploadPicker
            )
        } else if (isGridView) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                contentPadding = PaddingValues(bottom = 110.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(subfolders, key = { "folder_${it.id}" }, contentType = { "folder_grid" }) { folder ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .bounceClick { onOpenFolder(folder) }
                            .testTag("folder_item_${folder.id}"),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Surface(
                            color = MaterialTheme.colorScheme.surface,
                            shape = RoundedCornerShape(18.dp),
                            tonalElevation = 1.dp,
                            modifier = Modifier.fillMaxWidth().aspectRatio(1f)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Default.Folder,
                                    contentDescription = folder.name,
                                    tint = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.size(44.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = folder.name,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                items(files, key = { "file_${it.id}" }, contentType = { "file_grid" }) { file ->
                    val displayName = if (showFileExtensions) file.name else file.name.substringBeforeLast('.')
                    val thumb = file.activeThumbnailPath
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .bounceClick { onOpenFile(file) }
                            .testTag("file_grid_item_${file.id}")
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(1f)
                                .clip(RoundedCornerShape(16.dp))
                                .background(if (file.isVideo) VideoTintSurface else MaterialTheme.colorScheme.surface)
                        ) {
                            if (thumb != null && File(thumb).exists()) {
                                AsyncImage(
                                    model = File(thumb),
                                    contentDescription = file.name,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else {
                                Icon(
                                    imageVector = fileCategoryIcon(file),
                                    contentDescription = file.name,
                                    tint = if (file.isVideo) VideoIconIndigo else MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.size(34.dp).align(Alignment.Center)
                                )
                            }

                            // Top-right Favorite Star button
                            IconButton(
                                onClick = { onToggleFavorite(file) },
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(4.dp)
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(Color.Black.copy(alpha = 0.45f))
                            ) {
                                Icon(
                                    imageVector = if (file.isFavorite) Icons.Filled.Star else Icons.Outlined.StarBorder,
                                    contentDescription = "Favorite",
                                    tint = if (file.isFavorite) FavoriteGold else Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                            }

                            if (file.isVideo) {
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.BottomStart)
                                        .padding(6.dp)
                                        .clip(CircleShape)
                                        .background(Color.Black.copy(alpha = 0.58f))
                                        .padding(4.dp)
                                ) {
                                    Icon(
                                        Icons.Default.PlayArrow,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(12.dp)
                                    )
                                }
                            }

                            IconButton(
                                onClick = { onOpenFileMenu(file) },
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .padding(4.dp)
                                    .size(26.dp)
                                    .clip(CircleShape)
                                    .background(Color.Black.copy(alpha = 0.45f))
                                    .testTag("file_menu_btn_${file.id}")
                            ) {
                                Icon(
                                    Icons.Default.MoreVert,
                                    contentDescription = "More actions",
                                    tint = Color.White,
                                    modifier = Modifier.size(15.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = displayName,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = formatFileSize(file.sizeBytes),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(bottom = 110.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(subfolders, key = { "folder_l_${it.id}" }, contentType = { "folder_list" }) { folder ->
                    Surface(
                        color = MaterialTheme.colorScheme.surface,
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier.fillMaxWidth().bounceClick { onOpenFolder(folder) }
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Folder, contentDescription = null, modifier = Modifier.size(32.dp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(folder.name, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                        }
                    }
                }

                items(files, key = { "file_l_${it.id}" }, contentType = { "file_list" }) { file ->
                    val displayName = if (showFileExtensions) file.name else file.name.substringBeforeLast('.')
                    val thumb = file.activeThumbnailPath
                    Surface(
                        color = MaterialTheme.colorScheme.surface,
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier.fillMaxWidth().bounceClick { onOpenFile(file) }
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (file.isVideo) VideoTintSurface else MaterialTheme.colorScheme.surfaceVariant),
                                contentAlignment = Alignment.Center
                            ) {
                                if (thumb != null && File(thumb).exists()) {
                                    AsyncImage(
                                        model = File(thumb),
                                        contentDescription = file.name,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                } else {
                                    Icon(
                                        fileCategoryIcon(file),
                                        contentDescription = null,
                                        tint = if (file.isVideo) VideoIconIndigo else MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(displayName, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(formatFileSize(file.sizeBytes), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            IconButton(onClick = { onToggleFavorite(file) }) {
                                Icon(
                                    if (file.isFavorite) Icons.Filled.Star else Icons.Outlined.StarBorder,
                                    contentDescription = "Favorite",
                                    tint = if (file.isFavorite) FavoriteGold else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(onClick = { onOpenFileMenu(file) }) {
                                Icon(Icons.Default.MoreVert, contentDescription = "More actions")
                            }
                        }
                    }
                }
            }
        }
    }

    if (showNewFolderDialog) {
        var folderName by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showNewFolderDialog = false },
            title = { Text("Create New Folder") },
            text = {
                OutlinedTextField(
                    value = folderName,
                    onValueChange = { folderName = it },
                    label = { Text("Folder name") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp)
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    onCreateFolder(folderName)
                    showNewFolderDialog = false
                }) { Text("Create") }
            },
            dismissButton = {
                TextButton(onClick = { showNewFolderDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun CircularHeaderIcon(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    desc: String,
    onClick: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        shape = CircleShape,
        tonalElevation = 1.dp,
        modifier = Modifier.size(42.dp).clip(CircleShape).clickable(onClick = onClick)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = desc, modifier = Modifier.size(20.dp))
        }
    }
}

internal fun fileCategoryIcon(file: FileEntity): androidx.compose.ui.graphics.vector.ImageVector {
    return when {
        file.isVideo -> Icons.Default.VideoFile
        file.isAudio -> Icons.Default.MusicNote
        file.isPdf -> Icons.Default.PictureAsPdf
        file.isSpreadsheet -> Icons.Default.TableChart
        file.isWordDoc || file.isTextOrCode -> Icons.Default.Description
        file.isArchive -> Icons.Default.FolderZip
        file.isApp -> Icons.Default.Apps
        else -> Icons.AutoMirrored.Filled.InsertDriveFile
    }
}
