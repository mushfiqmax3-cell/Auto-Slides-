package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Clody Warm Minimalist Monochrome Palette
val AlabasterCanvas = Color(0xFFF5F4F0)
val PureWhiteSurface = Color(0xFFFFFFFF)
val SoftStoneGray = Color(0xFFEAE8E1)
val WarmBorderGray = Color(0xFFDFDDD5)
val DeepCharcoal = Color(0xFF141414)
val MutedCharcoalText = Color(0xFF5E5D58)
val SubtleHintText = Color(0xFF8C8A82)

// Dark Mode Warm Monochrome
val DarkCanvas = Color(0xFF121212)
val DarkSurface = Color(0xFF1E1E1E)
val DarkSecondarySurface = Color(0xFF2A2A27)
val DarkTextPrimary = Color(0xFFF5F4F0)
val DarkTextSecondary = Color(0xFFA8A69E)

// Semantic Accents
val VideoTintSurface = Color(0xFFECEAF4)
val VideoIconIndigo = Color(0xFF6342E8)
val EmeraldConnected = Color(0xFF22C55E)
val AmberConnecting = Color(0xFFF59E0B)
val CrimsonAlert = Color(0xFFB91C1C)
val YouTubeCrimson = Color(0xFFFF0033)
val FavoriteGold = Color(0xFFEAB308)
