package com.example.ui.theme

import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FiniteAnimationSpec
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer

object ClodyMotion {
    /** Crisp out-quartic curve equivalent to cubic-bezier(0.22, 1, 0.36, 1) */
    val CrispOutEasing = CubicBezierEasing(0.22f, 1f, 0.36f, 1f)

    fun <T> defaultSpring(animationsEnabled: Boolean = true): FiniteAnimationSpec<T> {
        return if (animationsEnabled) {
            spring(
                dampingRatio = 0.84f,
                stiffness = Spring.StiffnessMediumLow
            )
        } else {
            snap()
        }
    }

    fun <T> snappySpring(animationsEnabled: Boolean = true): FiniteAnimationSpec<T> {
        return if (animationsEnabled) {
            spring(
                dampingRatio = 0.88f,
                stiffness = Spring.StiffnessMedium
            )
        } else {
            snap()
        }
    }

    fun <T> crispTween(
        durationMs: Int = 240,
        animationsEnabled: Boolean = true
    ): FiniteAnimationSpec<T> {
        return if (animationsEnabled) {
            tween(durationMillis = durationMs.coerceIn(180, 280), easing = CrispOutEasing)
        } else {
            snap()
        }
    }
}

/**
 * Pure GPU-composited tactile scale press feedback (scale3d(0.97, 0.97, 1) equivalent)
 * with zero layout invalidation during animation.
 */
@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
fun Modifier.bounceClick(
    enabled: Boolean = true,
    scaleDown: Float = 0.97f,
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit
): Modifier = composed {
    val animationsEnabled = LocalAnimationsEnabled.current
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed && enabled && animationsEnabled) scaleDown else 1f,
        animationSpec = ClodyMotion.crispTween(durationMs = 200, animationsEnabled = animationsEnabled),
        label = "gpu_bounce_scale"
    )

    val clickModifier = if (onLongClick != null) {
        Modifier.combinedClickable(
            interactionSource = interactionSource,
            indication = null,
            enabled = enabled,
            onLongClick = onLongClick,
            onClick = onClick
        )
    } else {
        Modifier.clickable(
            interactionSource = interactionSource,
            indication = null,
            enabled = enabled,
            onClick = onClick
        )
    }

    this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .then(clickModifier)
}
