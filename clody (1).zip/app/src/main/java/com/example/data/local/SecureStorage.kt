package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Hardware-backed Android Keystore AES-256-GCM encrypted preferences wrapper
 * for Telegram API credentials and MTProto session keys.
 */
class SecureStorage(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("clody_secure_vault", Context.MODE_PRIVATE)

    private fun getOrCreateMasterKey(): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = keyStore.getEntry(KEY_ALIAS, null) as? KeyStore.SecretKeyEntry
        if (existing != null) return existing.secretKey

        val keyGenerator = KeyGenerator.getInstance(
            KeyProperties.KEY_ALGORITHM_AES,
            "AndroidKeyStore"
        )
        val spec = KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build()
        keyGenerator.init(spec)
        return keyGenerator.generateKey()
    }

    private fun encrypt(plainText: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateMasterKey())
        val iv = cipher.iv
        val encrypted = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))
        val combined = ByteArray(1 + iv.size + encrypted.size)
        combined[0] = iv.size.toByte()
        System.arraycopy(iv, 0, combined, 1, iv.size)
        System.arraycopy(encrypted, 0, combined, 1 + iv.size, encrypted.size)
        return Base64.encodeToString(combined, Base64.NO_WRAP)
    }

    private fun decrypt(cipherText: String?): String? {
        if (cipherText.isNullOrBlank()) return null
        return runCatching {
            val combined = Base64.decode(cipherText, Base64.NO_WRAP)
            val ivSize = combined[0].toInt() and 0xFF
            val iv = combined.copyOfRange(1, 1 + ivSize)
            val encrypted = combined.copyOfRange(1 + ivSize, combined.size)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateMasterKey(), GCMParameterSpec(128, iv))
            String(cipher.doFinal(encrypted), Charsets.UTF_8)
        }.getOrNull()
    }

    fun saveApiCredentials(apiId: Int, apiHash: String) {
        prefs.edit()
            .putString(KEY_API_ID, encrypt(apiId.toString()))
            .putString(KEY_API_HASH, encrypt(apiHash.trim()))
            .apply()
    }

    fun getApiId(): Int? = decrypt(prefs.getString(KEY_API_ID, null))?.toIntOrNull()

    fun getApiHash(): String? = decrypt(prefs.getString(KEY_API_HASH, null))

    fun savePhoneNumber(phone: String) {
        prefs.edit().putString(KEY_PHONE, encrypt(phone)).apply()
    }

    fun getPhoneNumber(): String? = decrypt(prefs.getString(KEY_PHONE, null))

    fun saveUserDisplayName(name: String) {
        prefs.edit().putString(KEY_USER_NAME, encrypt(name)).apply()
    }

    fun getUserDisplayName(): String? = decrypt(prefs.getString(KEY_USER_NAME, null))

    fun saveUserProfileDetails(
        userId: Long,
        firstName: String,
        lastName: String,
        username: String?,
        phone: String?,
        avatarPath: String? = null
    ) {
        val fullName = listOf(firstName, lastName).filter { it.isNotBlank() }.joinToString(" ")
            .ifBlank { phone ?: "Telegram User" }
        val ed = prefs.edit()
            .putLong(KEY_USER_ID, userId)
            .putString(KEY_FIRST_NAME, encrypt(firstName))
            .putString(KEY_LAST_NAME, encrypt(lastName))
            .putString(KEY_USER_NAME, encrypt(fullName))
        if (!username.isNullOrBlank()) {
            ed.putString(KEY_USERNAME, encrypt(username))
        } else {
            ed.remove(KEY_USERNAME)
        }
        if (!phone.isNullOrBlank()) {
            ed.putString(KEY_PHONE, encrypt(phone))
        }
        if (!avatarPath.isNullOrBlank()) {
            ed.putString(KEY_AVATAR_PATH, avatarPath)
        }
        ed.apply()
    }

    fun getFirstName(): String = decrypt(prefs.getString(KEY_FIRST_NAME, null)).orEmpty()
    fun getLastName(): String = decrypt(prefs.getString(KEY_LAST_NAME, null)).orEmpty()
    fun getUsername(): String? = decrypt(prefs.getString(KEY_USERNAME, null))
    fun getAvatarPath(): String? = prefs.getString(KEY_AVATAR_PATH, null)

    fun saveUserId(userId: Long) {
        prefs.edit().putLong(KEY_USER_ID, userId).apply()
    }

    fun getUserId(): Long = prefs.getLong(KEY_USER_ID, 0L)

    fun saveStorageChannel(channelId: Long, accessHash: Long, isSelfChat: Boolean) {
        prefs.edit()
            .putLong(KEY_CHANNEL_ID, channelId)
            .putLong(KEY_CHANNEL_HASH, accessHash)
            .putBoolean(KEY_IS_SELF_CHAT, isSelfChat)
            .apply()
    }

    fun getStorageChannelId(): Long = prefs.getLong(KEY_CHANNEL_ID, 0L)
    fun getStorageChannelAccessHash(): Long = prefs.getLong(KEY_CHANNEL_HASH, 0L)
    fun isStorageSelfChat(): Boolean = prefs.getBoolean(KEY_IS_SELF_CHAT, false)

    fun saveActiveDc(dcId: Int) {
        val normalized = if (dcId in 1..5) dcId else 2
        prefs.edit().putInt(KEY_ACTIVE_DC, normalized).apply()
    }

    fun getActiveDc(): Int = prefs.getInt(KEY_ACTIVE_DC, 2).let { if (it in 1..5) it else 2 }

    fun saveDcAuthKey(dcId: Int, authKey: ByteArray, serverSalt: Long, timeOffset: Int) {
        val b64 = Base64.encodeToString(authKey, Base64.NO_WRAP)
        prefs.edit()
            .putString("dc_auth_$dcId", encrypt(b64))
            .putLong("dc_salt_$dcId", serverSalt)
            .putInt("dc_offset_$dcId", timeOffset)
            .apply()
    }

    fun getDcAuthKey(dcId: Int): ByteArray? {
        val b64 = decrypt(prefs.getString("dc_auth_$dcId", null)) ?: return null
        return runCatching { Base64.decode(b64, Base64.NO_WRAP) }.getOrNull()
    }

    fun clearDcAuthKey(dcId: Int) {
        prefs.edit()
            .remove("dc_auth_$dcId")
            .remove("dc_salt_$dcId")
            .remove("dc_offset_$dcId")
            .apply()
    }

    fun getDcSalt(dcId: Int): Long = prefs.getLong("dc_salt_$dcId", 0L)

    fun getDcTimeOffset(dcId: Int): Int = prefs.getInt("dc_offset_$dcId", 0)

    fun setLoggedIn(loggedIn: Boolean) {
        prefs.edit().putBoolean(KEY_LOGGED_IN, loggedIn).apply()
    }

    fun isLoggedIn(): Boolean = prefs.getBoolean(KEY_LOGGED_IN, false)

    fun saveIndexMessageId(msgId: Int) {
        prefs.edit().putInt(KEY_INDEX_MSG_ID, msgId).apply()
    }

    fun getIndexMessageId(): Int = prefs.getInt(KEY_INDEX_MSG_ID, 0)

    fun clearSessionOnly() {
        val apiId = prefs.getString(KEY_API_ID, null)
        val apiHash = prefs.getString(KEY_API_HASH, null)
        prefs.edit().clear().apply()
        prefs.edit()
            .putString(KEY_API_ID, apiId)
            .putString(KEY_API_HASH, apiHash)
            .apply()
    }

    fun clearAll() {
        prefs.edit().clear().apply()
    }

    companion object {
        private const val KEY_ALIAS = "clody_vault_master_key_v1"
        private const val KEY_API_ID = "api_id"
        private const val KEY_API_HASH = "api_hash"
        private const val KEY_PHONE = "phone"
        private const val KEY_USER_NAME = "user_name"
        private const val KEY_FIRST_NAME = "first_name"
        private const val KEY_LAST_NAME = "last_name"
        private const val KEY_USERNAME = "username"
        private const val KEY_AVATAR_PATH = "avatar_path"
        private const val KEY_USER_ID = "user_id"
        private const val KEY_CHANNEL_ID = "channel_id"
        private const val KEY_CHANNEL_HASH = "channel_hash"
        private const val KEY_IS_SELF_CHAT = "is_self_chat"
        private const val KEY_ACTIVE_DC = "active_dc"
        private const val KEY_LOGGED_IN = "logged_in"
        private const val KEY_INDEX_MSG_ID = "index_msg_id"
    }
}
