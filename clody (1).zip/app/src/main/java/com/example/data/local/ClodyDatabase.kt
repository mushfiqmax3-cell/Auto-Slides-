package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        FolderEntity::class,
        GalleryAlbumEntity::class,
        FileEntity::class,
        FileFtsEntity::class,
        UploadTaskEntity::class,
        DownloadRecordEntity::class
    ],
    version = 3,
    exportSchema = false
)
abstract class ClodyDatabase : RoomDatabase() {
    abstract fun clodyDao(): ClodyDao

    companion object {
        @Volatile
        private var INSTANCE: ClodyDatabase? = null

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE files ADD COLUMN localSourceUri TEXT")
            }
        }

        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE files ADD COLUMN albumId INTEGER")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_files_albumId ON files(albumId)")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS gallery_albums (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        name TEXT NOT NULL,
                        coverThumbnailPath TEXT,
                        createdAt INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
            }
        }

        fun getInstance(context: Context): ClodyDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    ClodyDatabase::class.java,
                    "clody_database.db"
                )
                    .addMigrations(MIGRATION_1_2, MIGRATION_2_3)
                    .fallbackToDestructiveMigration(true)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
