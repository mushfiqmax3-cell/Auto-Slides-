package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "clody_settings")

enum class ThemeMode {
    SYSTEM, LIGHT, DARK
}

enum class SortOption {
    DATE_DESC, NAME_ASC, SIZE_DESC
}

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.LIGHT,
    val dynamicColors: Boolean = false,
    val animationsEnabled: Boolean = true,
    val showHiddenFiles: Boolean = false,
    val showFileExtensions: Boolean = true,
    val useRecycleBin: Boolean = true,
    val confirmBeforeDeleting: Boolean = true,
    val uploadWifiOnly: Boolean = false,
    val zeroStorageMode: Boolean = false,
    val gridViewFolders: Boolean = true,
    val sortOption: SortOption = SortOption.DATE_DESC,
    val syncedFolderUris: Set<String> = emptySet(),
    val dismissedBackupIds: Set<String> = emptySet()
)

class SettingsRepository(private val context: Context) {

    private object Keys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val DYNAMIC_COLORS = booleanPreferencesKey("dynamic_colors")
        val ANIMATIONS_ENABLED = booleanPreferencesKey("animations_enabled")
        val SHOW_HIDDEN_FILES = booleanPreferencesKey("show_hidden_files")
        val SHOW_FILE_EXTENSIONS = booleanPreferencesKey("show_file_extensions")
        val USE_RECYCLE_BIN = booleanPreferencesKey("use_recycle_bin")
        val CONFIRM_DELETE = booleanPreferencesKey("confirm_delete")
        val UPLOAD_WIFI_ONLY = booleanPreferencesKey("upload_wifi_only")
        val ZERO_STORAGE_MODE = booleanPreferencesKey("zero_storage_mode")
        val GRID_VIEW_FOLDERS = booleanPreferencesKey("grid_view_folders")
        val SORT_OPTION = stringPreferencesKey("sort_option")
        val SYNCED_FOLDER_URIS = stringSetPreferencesKey("synced_folder_uris")
        val DISMISSED_BACKUP_IDS = stringSetPreferencesKey("dismissed_backup_ids")
    }

    val settingsFlow: Flow<AppSettings> = context.dataStore.data.map { prefs ->
        AppSettings(
            themeMode = prefs[Keys.THEME_MODE]?.let { runCatching { ThemeMode.valueOf(it) }.getOrNull() } ?: ThemeMode.LIGHT,
            dynamicColors = prefs[Keys.DYNAMIC_COLORS] ?: false,
            animationsEnabled = prefs[Keys.ANIMATIONS_ENABLED] ?: true,
            showHiddenFiles = prefs[Keys.SHOW_HIDDEN_FILES] ?: false,
            showFileExtensions = prefs[Keys.SHOW_FILE_EXTENSIONS] ?: true,
            useRecycleBin = prefs[Keys.USE_RECYCLE_BIN] ?: true,
            confirmBeforeDeleting = prefs[Keys.CONFIRM_DELETE] ?: true,
            uploadWifiOnly = prefs[Keys.UPLOAD_WIFI_ONLY] ?: false,
            zeroStorageMode = prefs[Keys.ZERO_STORAGE_MODE] ?: false,
            gridViewFolders = prefs[Keys.GRID_VIEW_FOLDERS] ?: true,
            sortOption = prefs[Keys.SORT_OPTION]?.let { runCatching { SortOption.valueOf(it) }.getOrNull() } ?: SortOption.DATE_DESC,
            syncedFolderUris = prefs[Keys.SYNCED_FOLDER_URIS] ?: emptySet(),
            dismissedBackupIds = prefs[Keys.DISMISSED_BACKUP_IDS] ?: emptySet()
        )
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.dataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    suspend fun setDynamicColors(enabled: Boolean) {
        context.dataStore.edit { it[Keys.DYNAMIC_COLORS] = enabled }
    }

    suspend fun setAnimationsEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.ANIMATIONS_ENABLED] = enabled }
    }

    suspend fun setShowHiddenFiles(enabled: Boolean) {
        context.dataStore.edit { it[Keys.SHOW_HIDDEN_FILES] = enabled }
    }

    suspend fun setShowFileExtensions(enabled: Boolean) {
        context.dataStore.edit { it[Keys.SHOW_FILE_EXTENSIONS] = enabled }
    }

    suspend fun setUseRecycleBin(enabled: Boolean) {
        context.dataStore.edit { it[Keys.USE_RECYCLE_BIN] = enabled }
    }

    suspend fun setConfirmBeforeDeleting(enabled: Boolean) {
        context.dataStore.edit { it[Keys.CONFIRM_DELETE] = enabled }
    }

    suspend fun setUploadWifiOnly(enabled: Boolean) {
        context.dataStore.edit { it[Keys.UPLOAD_WIFI_ONLY] = enabled }
    }

    suspend fun setZeroStorageMode(enabled: Boolean) {
        context.dataStore.edit { it[Keys.ZERO_STORAGE_MODE] = enabled }
    }

    suspend fun setGridViewFolders(grid: Boolean) {
        context.dataStore.edit { it[Keys.GRID_VIEW_FOLDERS] = grid }
    }

    suspend fun setSortOption(option: SortOption) {
        context.dataStore.edit { it[Keys.SORT_OPTION] = option.name }
    }

    suspend fun addSyncedFolderUri(uri: String) {
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.SYNCED_FOLDER_URIS] ?: emptySet()
            prefs[Keys.SYNCED_FOLDER_URIS] = current + uri
        }
    }

    suspend fun removeSyncedFolderUri(uri: String) {
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.SYNCED_FOLDER_URIS] ?: emptySet()
            prefs[Keys.SYNCED_FOLDER_URIS] = current - uri
        }
    }

    suspend fun addDismissedBackupIds(ids: Set<String>) {
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.DISMISSED_BACKUP_IDS] ?: emptySet()
            prefs[Keys.DISMISSED_BACKUP_IDS] = current + ids
        }
    }
}
