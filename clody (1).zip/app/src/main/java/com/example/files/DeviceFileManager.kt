package com.example.files

import android.content.ContentUris
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.MediaStore
import com.example.data.local.FileEntity
import com.example.media.ThumbnailGenerator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.apache.commons.compress.archivers.sevenz.SevenZFile
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.archivers.zip.ZipArchiveInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

data class LocalMediaCandidate(
    val id: String,
    val uri: Uri,
    val displayName: String,
    val mimeType: String,
    val sizeBytes: Long,
    val durationMs: Long,
    val dateAddedSec: Long,
    val thumbnailPath: String?
)

data class DeviceStorageStats(
    val usedBytes: Long,
    val totalBytes: Long
) {
    val usedPercent: Int
        get() = if (totalBytes > 0L) ((usedBytes * 100L) / totalBytes).toInt().coerceIn(0, 100) else 0
}

data class LocalFileItem(
    val file: File,
    val name: String,
    val isDirectory: Boolean,
    val sizeBytes: Long,
    val lastModified: Long,
    val isHidden: Boolean
)

data class InstalledAppItem(
    val appName: String,
    val packageName: String,
    val versionName: String,
    val apkPath: String,
    val sizeBytes: Long
)

data class DuplicateGroup(
    val hash: String,
    val sizeBytes: Long,
    val files: List<FileEntity>
)

class DeviceFileManager(private val context: Context) {

    fun getDeviceStorageStats(): DeviceStorageStats {
        return runCatching {
            val stat = StatFs(Environment.getDataDirectory().path)
            val total = stat.totalBytes
            val free = stat.availableBytes
            DeviceStorageStats(usedBytes = (total - free).coerceAtLeast(0L), totalBytes = total)
        }.getOrDefault(DeviceStorageStats(0L, 1L))
    }

    /**
     * Scans real device MediaStore for photos & videos not yet backed up or dismissed.
     * Strictly returns emptyList() when permission is absent or no real files are found.
     */
    suspend fun scanUnbackedUpLocalMedia(
        existingNamesAndSizes: Set<Pair<String, Long>>,
        dismissedIds: Set<String>,
        limit: Int = 20
    ): List<LocalMediaCandidate> = withContext(Dispatchers.IO) {
        val results = mutableListOf<LocalMediaCandidate>()
        val projection = arrayOf(
            MediaStore.Files.FileColumns._ID,
            MediaStore.Files.FileColumns.DISPLAY_NAME,
            MediaStore.Files.FileColumns.MIME_TYPE,
            MediaStore.Files.FileColumns.SIZE,
            MediaStore.Files.FileColumns.DATE_ADDED,
            MediaStore.Files.FileColumns.MEDIA_TYPE,
            MediaStore.Video.VideoColumns.DURATION
        )
        val selection = "${MediaStore.Files.FileColumns.MEDIA_TYPE}=? OR ${MediaStore.Files.FileColumns.MEDIA_TYPE}=?"
        val args = arrayOf(
            MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE.toString(),
            MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO.toString()
        )
        val sort = "${MediaStore.Files.FileColumns.DATE_ADDED} DESC"
        val collection = MediaStore.Files.getContentUri("external")

        runCatching {
            context.contentResolver.query(collection, projection, selection, args, sort)?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MIME_TYPE)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.SIZE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATE_ADDED)
                val typeCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MEDIA_TYPE)
                val durCol = cursor.getColumnIndex(MediaStore.Video.VideoColumns.DURATION)

                while (cursor.moveToNext() && results.size < limit) {
                    val mediaId = cursor.getLong(idCol)
                    val name = cursor.getString(nameCol) ?: continue
                    val mime = cursor.getString(mimeCol) ?: "application/octet-stream"
                    val size = cursor.getLong(sizeCol)
                    val dateAdded = cursor.getLong(dateCol)
                    val mediaType = cursor.getInt(typeCol)
                    val durationMs = if (durCol >= 0) cursor.getLong(durCol) else 0L
                    val key = "${mediaId}_$size"
                    if (size <= 0L) continue
                    if (dismissedIds.contains(key)) continue
                    if (existingNamesAndSizes.contains(name to size)) continue

                    val baseUri = if (mediaType == MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO) {
                        MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                    } else {
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                    }
                    val contentUri = ContentUris.withAppendedId(baseUri, mediaId)
                    val thumb = ThumbnailGenerator.generateForUri(
                        context = context,
                        uri = contentUri,
                        mimeType = mime,
                        uniqueKey = key
                    )
                    results += LocalMediaCandidate(
                        id = key,
                        uri = contentUri,
                        displayName = name,
                        mimeType = mime,
                        sizeBytes = size,
                        durationMs = maxOf(durationMs, thumb.durationMs),
                        dateAddedSec = dateAdded,
                        thumbnailPath = thumb.thumbnailPath
                    )
                }
            }
        }
        results
    }

    fun hasAllFilesAccess(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            true
        }
    }

    fun getRootDirectory(): File = Environment.getExternalStorageDirectory()

    fun getClodyDownloadsDir(): File {
        val publicDownloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        val dir = File(publicDownloads, "Clody")
        if (!dir.exists()) dir.mkdirs()
        return if (dir.exists() && dir.canRead()) dir else File(context.filesDir, "Downloads").apply { mkdirs() }
    }

    suspend fun listDirectory(dir: File, showHidden: Boolean): List<LocalFileItem> = withContext(Dispatchers.IO) {
        val children = dir.listFiles() ?: return@withContext emptyList()
        children
            .filter { showHidden || !it.name.startsWith(".") }
            .sortedWith(compareBy<File> { !it.isDirectory }.thenBy { it.name.lowercase() })
            .map {
                LocalFileItem(
                    file = it,
                    name = it.name,
                    isDirectory = it.isDirectory,
                    sizeBytes = if (it.isDirectory) 0L else it.length(),
                    lastModified = it.lastModified(),
                    isHidden = it.name.startsWith(".")
                )
            }
    }

    suspend fun scanLargeLocalFiles(minBytes: Long = 50L * 1024L * 1024L): List<LocalFileItem> =
        withContext(Dispatchers.IO) {
            val root = getRootDirectory()
            val out = mutableListOf<LocalFileItem>()
            if (!root.canRead()) return@withContext emptyList()
            root.walkTopDown()
                .maxDepth(5)
                .filter { it.isFile && it.length() >= minBytes }
                .take(80)
                .forEach { f ->
                    out += LocalFileItem(
                        file = f,
                        name = f.name,
                        isDirectory = false,
                        sizeBytes = f.length(),
                        lastModified = f.lastModified(),
                        isHidden = f.name.startsWith(".")
                    )
                }
            out.sortedByDescending { it.sizeBytes }
        }

    fun findDuplicateCloudFiles(files: List<FileEntity>): List<DuplicateGroup> {
        return files
            .filter { it.sha256.isNotBlank() && it.sizeBytes > 0L }
            .groupBy { "${it.sizeBytes}_${it.sha256}" }
            .values
            .filter { it.size > 1 }
            .map { group ->
                DuplicateGroup(
                    hash = group.first().sha256,
                    sizeBytes = group.first().sizeBytes,
                    files = group
                )
            }
    }

    suspend fun compressToZip(
        uris: List<Uri>,
        archiveName: String
    ): Result<File> = withContext(Dispatchers.IO) {
        runCatching {
            val cleanName = if (archiveName.endsWith(".zip", ignoreCase = true)) archiveName else "$archiveName.zip"
            val outDir = File(context.filesDir, "archives").apply { mkdirs() }
            val outFile = File(outDir, cleanName)
            ZipOutputStream(FileOutputStream(outFile)).use { zos ->
                val buf = ByteArray(16 * 1024)
                uris.forEachIndexed { idx, uri ->
                    val name = resolveFileName(uri) ?: "item_$idx"
                    zos.putNextEntry(ZipEntry(name))
                    context.contentResolver.openInputStream(uri)?.use { input ->
                        while (true) {
                            val r = input.read(buf)
                            if (r == -1) break
                            zos.write(buf, 0, r)
                        }
                    }
                    zos.closeEntry()
                }
            }
            outFile
        }
    }

    suspend fun extractArchive(archiveUri: Uri): Result<File> = withContext(Dispatchers.IO) {
        runCatching {
            val fileName = resolveFileName(archiveUri) ?: "archive.zip"
            val tempFile = File(context.cacheDir, "extract_${System.currentTimeMillis()}_$fileName")
            context.contentResolver.openInputStream(archiveUri)?.use { input ->
                FileOutputStream(tempFile).use { output -> input.copyTo(output) }
            } ?: throw IllegalStateException("Cannot read archive URI")

            val destDir = File(context.filesDir, "extracted/${fileName.substringBeforeLast('.')}").apply {
                mkdirs()
            }

            when (fileName.substringAfterLast('.', "").lowercase()) {
                "7z" -> {
                    SevenZFile.builder().setFile(tempFile).get().use { sevenZ ->
                        var entry = sevenZ.nextEntry
                        val buf = ByteArray(16 * 1024)
                        while (entry != null) {
                            val target = safeResolve(destDir, entry.name)
                            if (entry.isDirectory) {
                                target.mkdirs()
                            } else {
                                target.parentFile?.mkdirs()
                                FileOutputStream(target).use { fos ->
                                    while (true) {
                                        val r = sevenZ.read(buf)
                                        if (r <= 0) break
                                        fos.write(buf, 0, r)
                                    }
                                }
                            }
                            entry = sevenZ.nextEntry
                        }
                    }
                }
                "tar" -> {
                    TarArchiveInputStream(BufferedInputStream(FileInputStream(tempFile))).use { tais ->
                        var entry = tais.nextEntry
                        while (entry != null) {
                            val target = safeResolve(destDir, entry.name)
                            if (entry.isDirectory) {
                                target.mkdirs()
                            } else {
                                target.parentFile?.mkdirs()
                                FileOutputStream(target).use { fos -> tais.copyTo(fos) }
                            }
                            entry = tais.nextEntry
                        }
                    }
                }
                else -> {
                    ZipArchiveInputStream(BufferedInputStream(FileInputStream(tempFile))).use { zais ->
                        var entry = zais.nextEntry
                        while (entry != null) {
                            val target = safeResolve(destDir, entry.name)
                            if (entry.isDirectory) {
                                target.mkdirs()
                            } else {
                                target.parentFile?.mkdirs()
                                FileOutputStream(target).use { fos -> zais.copyTo(fos) }
                            }
                            entry = zais.nextEntry
                        }
                    }
                }
            }
            tempFile.delete()
            destDir
        }
    }

    private fun safeResolve(destDir: File, entryName: String): File {
        val target = File(destDir, entryName)
        if (!target.canonicalPath.startsWith(destDir.canonicalPath)) {
            throw SecurityException("Blocked Zip Path Traversal entry: $entryName")
        }
        return target
    }

    suspend fun getInstalledUserApps(): List<InstalledAppItem> = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        apps.filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 }
            .mapNotNull { info ->
                val apk = File(info.publicSourceDir ?: return@mapNotNull null)
                val pkgInfo = runCatching { pm.getPackageInfo(info.packageName, 0) }.getOrNull()
                InstalledAppItem(
                    appName = pm.getApplicationLabel(info).toString(),
                    packageName = info.packageName,
                    versionName = pkgInfo?.versionName ?: "1.0",
                    apkPath = apk.absolutePath,
                    sizeBytes = apk.length()
                )
            }
            .sortedBy { it.appName.lowercase() }
    }

    private fun resolveFileName(uri: Uri): String? {
        if (uri.scheme == "file") return File(uri.path ?: return null).name
        return context.contentResolver.query(
            uri,
            arrayOf(android.provider.OpenableColumns.DISPLAY_NAME),
            null,
            null,
            null
        )?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    }

    fun computeQuickSha256(file: File): String {
        return runCatching {
            val md = MessageDigest.getInstance("SHA-256")
            file.inputStream().use { fis ->
                val buf = ByteArray(16 * 1024)
                while (true) {
                    val r = fis.read(buf)
                    if (r == -1) break
                    md.update(buf, 0, r)
                }
            }
            md.digest().joinToString("") { "%02x".format(it) }
        }.getOrDefault("")
    }
}
