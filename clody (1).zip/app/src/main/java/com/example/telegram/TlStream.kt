package com.example.telegram

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.GZIPInputStream

class TlWriter(initialCapacity: Int = 256) {
    private val out = ByteArrayOutputStream(initialCapacity)

    fun writeInt(value: Int) {
        out.write(value and 0xFF)
        out.write((value ushr 8) and 0xFF)
        out.write((value ushr 16) and 0xFF)
        out.write((value ushr 24) and 0xFF)
    }

    fun writeLong(value: Long) {
        for (i in 0 until 8) {
            out.write(((value ushr (i * 8)) and 0xFFL).toInt())
        }
    }

    fun writeRaw(bytes: ByteArray) {
        out.write(bytes)
    }

    fun writeInt128(bytes: ByteArray) {
        require(bytes.size == 16) { "Int128 must be 16 bytes" }
        out.write(bytes)
    }

    fun writeInt256(bytes: ByteArray) {
        require(bytes.size == 32) { "Int256 must be 32 bytes" }
        out.write(bytes)
    }

    fun writeBytes(bytes: ByteArray) {
        val len = bytes.size
        val headerSize: Int
        if (len < 254) {
            out.write(len)
            headerSize = 1
        } else {
            out.write(0xFE)
            out.write(len and 0xFF)
            out.write((len ushr 8) and 0xFF)
            out.write((len ushr 16) and 0xFF)
            headerSize = 4
        }
        out.write(bytes)
        val total = headerSize + len
        val padding = (4 - (total % 4)) % 4
        repeat(padding) { out.write(0) }
    }

    fun writeString(value: String) {
        writeBytes(value.toByteArray(Charsets.UTF_8))
    }

    fun writeBool(value: Boolean) {
        writeInt(if (value) TL_BOOL_TRUE else TL_BOOL_FALSE)
    }

    fun toByteArray(): ByteArray = out.toByteArray()

    companion object {
        const val TL_BOOL_TRUE = 0x997275b5.toInt()
        const val TL_BOOL_FALSE = 0xbc799737.toInt()
    }
}

class TlReader(private val data: ByteArray, initialOffset: Int = 0) {
    var position: Int = initialOffset
        private set

    val remaining: Int get() = data.size - position

    fun readInt(): Int {
        if (remaining < 4) throw IllegalStateException("Unexpected EOF reading Int at $position")
        val v = (data[position].toInt() and 0xFF) or
            ((data[position + 1].toInt() and 0xFF) shl 8) or
            ((data[position + 2].toInt() and 0xFF) shl 16) or
            ((data[position + 3].toInt() and 0xFF) shl 24)
        position += 4
        return v
    }

    fun peekInt(): Int {
        if (remaining < 4) throw IllegalStateException("Unexpected EOF peeking Int at $position")
        return (data[position].toInt() and 0xFF) or
            ((data[position + 1].toInt() and 0xFF) shl 8) or
            ((data[position + 2].toInt() and 0xFF) shl 16) or
            ((data[position + 3].toInt() and 0xFF) shl 24)
    }

    fun readLong(): Long {
        if (remaining < 8) throw IllegalStateException("Unexpected EOF reading Long at $position")
        var v = 0L
        for (i in 0 until 8) {
            v = v or ((data[position + i].toLong() and 0xFFL) shl (i * 8))
        }
        position += 8
        return v
    }

    fun readDouble(): Double {
        return java.lang.Double.longBitsToDouble(readLong())
    }

    fun readRaw(count: Int): ByteArray {
        if (remaining < count) throw IllegalStateException("Unexpected EOF reading $count raw bytes")
        val out = data.copyOfRange(position, position + count)
        position += count
        return out
    }

    fun readInt128(): ByteArray = readRaw(16)

    fun readInt256(): ByteArray = readRaw(32)

    fun readBytes(): ByteArray {
        if (remaining < 1) throw IllegalStateException("Unexpected EOF reading Bytes length")
        val first = data[position].toInt() and 0xFF
        val len: Int
        val headerSize: Int
        if (first < 254) {
            len = first
            headerSize = 1
            position += 1
        } else {
            if (remaining < 4) throw IllegalStateException("Unexpected EOF reading extended Bytes length")
            len = (data[position + 1].toInt() and 0xFF) or
                ((data[position + 2].toInt() and 0xFF) shl 8) or
                ((data[position + 3].toInt() and 0xFF) shl 16)
            headerSize = 4
            position += 4
        }
        if (remaining < len) throw IllegalStateException("Unexpected EOF reading $len bytes payload")
        val bytes = data.copyOfRange(position, position + len)
        position += len
        val padding = (4 - ((headerSize + len) % 4)) % 4
        position = minOf(data.size, position + padding)
        return bytes
    }

    fun readString(): String = String(readBytes(), Charsets.UTF_8)

    fun readBool(): Boolean {
        return when (val ctor = readInt()) {
            TlWriter.TL_BOOL_TRUE -> true
            TlWriter.TL_BOOL_FALSE -> false
            else -> throw IllegalStateException("Invalid TL Bool constructor: 0x${ctor.toUInt().toString(16)}")
        }
    }

    fun skip(count: Int) {
        position = minOf(data.size, position + count)
    }
}

object TlHelpers {
    const val VECTOR_CTOR = 0x1cb5c415
    const val GZIP_PACKED_CTOR = 0x3072cfa1

    fun gunzip(compressed: ByteArray): ByteArray {
        GZIPInputStream(ByteArrayInputStream(compressed)).use { gis ->
            return gis.readBytes()
        }
    }

    fun unwrapGzipIfNeeded(bytes: ByteArray): ByteArray {
        if (bytes.size >= 4) {
            val ctor = ByteBuffer.wrap(bytes, 0, 4).order(ByteOrder.LITTLE_ENDIAN).int
            if (ctor == GZIP_PACKED_CTOR) {
                val reader = TlReader(bytes, 4)
                return gunzip(reader.readBytes())
            }
        }
        return bytes
    }
}
