package com.example.telegram

import android.util.Base64
import java.math.BigInteger
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

data class TelegramRsaKey(
    val modulus: BigInteger,
    val exponent: BigInteger,
    val fingerprint: Long
)

object MtProtoCrypto {
    private val random = SecureRandom()

    fun randomBytes(count: Int): ByteArray = ByteArray(count).also { random.nextBytes(it) }

    fun sha1(data: ByteArray): ByteArray = MessageDigest.getInstance("SHA-1").digest(data)

    fun sha256(data: ByteArray): ByteArray = MessageDigest.getInstance("SHA-256").digest(data)

    fun sha256(vararg parts: ByteArray): ByteArray {
        val md = MessageDigest.getInstance("SHA-256")
        parts.forEach { md.update(it) }
        return md.digest()
    }

    fun aesIgeEncrypt(data: ByteArray, key: ByteArray, iv: ByteArray): ByteArray {
        require(data.size % 16 == 0) { "AES-IGE plaintext must be multiple of 16 bytes" }
        require(key.size == 32 && iv.size == 32) { "AES-256-IGE requires 32-byte key and 32-byte IV" }

        val cipher = Cipher.getInstance("AES/ECB/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"))

        val out = ByteArray(data.size)
        var iv1 = iv.copyOfRange(0, 16)
        var iv2 = iv.copyOfRange(16, 32)
        val block = ByteArray(16)

        var offset = 0
        while (offset < data.size) {
            for (i in 0 until 16) {
                block[i] = (data[offset + i].toInt() xor iv1[i].toInt()).toByte()
            }
            val encrypted = cipher.doFinal(block)
            for (i in 0 until 16) {
                encrypted[i] = (encrypted[i].toInt() xor iv2[i].toInt()).toByte()
                out[offset + i] = encrypted[i]
            }
            iv1 = out.copyOfRange(offset, offset + 16)
            iv2 = data.copyOfRange(offset, offset + 16)
            offset += 16
        }
        return out
    }

    fun aesIgeDecrypt(data: ByteArray, key: ByteArray, iv: ByteArray): ByteArray {
        require(data.size % 16 == 0) { "AES-IGE ciphertext must be multiple of 16 bytes" }
        require(key.size == 32 && iv.size == 32) { "AES-256-IGE requires 32-byte key and 32-byte IV" }

        val cipher = Cipher.getInstance("AES/ECB/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"))

        val out = ByteArray(data.size)
        var iv1 = iv.copyOfRange(0, 16)
        var iv2 = iv.copyOfRange(16, 32)
        val block = ByteArray(16)

        var offset = 0
        while (offset < data.size) {
            for (i in 0 until 16) {
                block[i] = (data[offset + i].toInt() xor iv2[i].toInt()).toByte()
            }
            val decrypted = cipher.doFinal(block)
            for (i in 0 until 16) {
                decrypted[i] = (decrypted[i].toInt() xor iv1[i].toInt()).toByte()
                out[offset + i] = decrypted[i]
            }
            iv1 = data.copyOfRange(offset, offset + 16)
            iv2 = out.copyOfRange(offset, offset + 16)
            offset += 16
        }
        return out
    }

    fun aesCtrTransform(data: ByteArray, key: ByteArray, iv: ByteArray): ByteArray {
        val cipher = Cipher.getInstance("AES/CTR/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), IvParameterSpec(iv))
        return cipher.doFinal(data)
    }

    fun computeMsgKeyAndAesKeys(
        authKey: ByteArray,
        plaintextPadded: ByteArray,
        isOutgoing: Boolean
    ): Triple<ByteArray, ByteArray, ByteArray> {
        val x = if (isOutgoing) 0 else 8
        val msgKeyLarge = sha256(authKey.copyOfRange(88 + x, 88 + x + 32), plaintextPadded)
        val msgKey = msgKeyLarge.copyOfRange(8, 24)

        val sha256a = sha256(msgKey, authKey.copyOfRange(x, x + 36))
        val sha256b = sha256(authKey.copyOfRange(40 + x, 40 + x + 36), msgKey)

        val aesKey = sha256a.copyOfRange(0, 8) +
            sha256b.copyOfRange(8, 24) +
            sha256a.copyOfRange(24, 32)
        val aesIv = sha256b.copyOfRange(0, 8) +
            sha256a.copyOfRange(8, 24) +
            sha256b.copyOfRange(24, 32)

        return Triple(msgKey, aesKey, aesIv)
    }

    fun deriveTmpAesKeyIv(newNonce: ByteArray, serverNonce: ByteArray): Pair<ByteArray, ByteArray> {
        val h1 = sha1(newNonce + serverNonce)
        val h2 = sha1(serverNonce + newNonce)
        val h3 = sha1(newNonce + newNonce)
        val tmpAesKey = h1 + h2.copyOfRange(0, 12)
        val tmpAesIv = h2.copyOfRange(12, 20) + h3 + newNonce.copyOfRange(0, 4)
        return tmpAesKey to tmpAesIv
    }

    /**
     * Factorizes 64-bit semi-prime PQ into (p, q) with p <= q using Brent's Pollard Rho.
     */
    fun factorizePQ(pqBytes: ByteArray): Pair<Long, Long> {
        val n = BigInteger(1, pqBytes).toLong()
        if (n <= 1L) return 1L to n
        if (n % 2L == 0L) return 2L to (n / 2L)

        var y = 1L
        var c = 1L
        val m = 128L
        var g = 1L
        var r = 1L
        var q = 1L
        var x = 0L
        var ys = 0L

        val bigN = BigInteger.valueOf(n)

        fun mulMod(a: Long, b: Long): Long {
            return BigInteger.valueOf(a).multiply(BigInteger.valueOf(b)).mod(bigN).toLong()
        }

        fun gcd(a: Long, b: Long): Long {
            var u = kotlin.math.abs(a)
            var v = kotlin.math.abs(b)
            while (v != 0L) {
                val t = u % v
                u = v
                v = t
            }
            return u
        }

        var attempt = 0
        while (g == 1L) {
            x = y
            for (i in 0 until r) {
                y = (mulMod(y, y) + c) % n
            }
            var k = 0L
            while (k < r && g == 1L) {
                ys = y
                val lim = minOf(m, r - k)
                for (i in 0 until lim) {
                    y = (mulMod(y, y) + c) % n
                    val diff = if (x > y) x - y else y - x
                    q = mulMod(q, diff)
                }
                g = gcd(q, n)
                k += m
            }
            r = r shl 1
            if (g == n) {
                do {
                    ys = (mulMod(ys, ys) + c) % n
                    val diff = if (x > ys) x - ys else ys - x
                    g = gcd(diff, n)
                } while (g == 1L)
                if (g == n) {
                    attempt++
                    y = (attempt + 1).toLong()
                    c = (attempt + 2).toLong()
                    g = 1L
                    r = 1L
                    q = 1L
                }
            }
        }

        val p = g
        val other = n / p
        return if (p <= other) p to other else other to p
    }

    /**
     * Parses PKCS#1 RSA public key from PEM and computes Telegram's 64-bit fingerprint.
     */
    fun parsePkcs1RsaKey(pemBase64: String): TelegramRsaKey {
        val der = Base64.decode(pemBase64.replace("\\s".toRegex(), ""), Base64.DEFAULT)
        // Minimal ASN.1 DER parser for SEQUENCE { INTEGER modulus, INTEGER exponent }
        var idx = 0
        require(der[idx++] == 0x30.toByte())
        idx = skipDerLength(der, idx)
        require(der[idx++] == 0x02.toByte())
        val (modLen, afterModLen) = readDerLength(der, idx)
        val modBytes = der.copyOfRange(afterModLen, afterModLen + modLen)
        idx = afterModLen + modLen
        require(der[idx++] == 0x02.toByte())
        val (expLen, afterExpLen) = readDerLength(der, idx)
        val expBytes = der.copyOfRange(afterExpLen, afterExpLen + expLen)

        val modulus = BigInteger(1, modBytes)
        val exponent = BigInteger(1, expBytes)

        val nUnsigned = modulus.toUnsignedByteArray()
        val eUnsigned = exponent.toUnsignedByteArray()
        val writer = TlWriter(320)
        writer.writeBytes(nUnsigned)
        writer.writeBytes(eUnsigned)
        val hash = sha1(writer.toByteArray())
        val fp = TlReader(hash, hash.size - 8).readLong()

        return TelegramRsaKey(modulus = modulus, exponent = exponent, fingerprint = fp)
    }

    private fun readDerLength(data: ByteArray, start: Int): Pair<Int, Int> {
        val first = data[start].toInt() and 0xFF
        return if ((first and 0x80) == 0) {
            first to (start + 1)
        } else {
            val numBytes = first and 0x7F
            var len = 0
            for (i in 1..numBytes) {
                len = (len shl 8) or (data[start + i].toInt() and 0xFF)
            }
            len to (start + 1 + numBytes)
        }
    }

    private fun skipDerLength(data: ByteArray, start: Int): Int {
        val first = data[start].toInt() and 0xFF
        return if ((first and 0x80) == 0) start + 1 else start + 1 + (first and 0x7F)
    }

    fun BigInteger.toUnsignedByteArray(): ByteArray {
        val raw = toByteArray()
        return if (raw.size > 1 && raw[0] == 0.toByte()) raw.copyOfRange(1, raw.size) else raw
    }

    fun BigInteger.to256Bytes(): ByteArray {
        val raw = toUnsignedByteArray()
        if (raw.size == 256) return raw
        if (raw.size > 256) return raw.copyOfRange(raw.size - 256, raw.size)
        val out = ByteArray(256)
        System.arraycopy(raw, 0, out, 256 - raw.size, raw.size)
        return out
    }

    fun rsaEncrypt256(dataWithPadding255: ByteArray, key: TelegramRsaKey): ByteArray {
        val m = BigInteger(1, dataWithPadding255)
        val c = m.modPow(key.exponent, key.modulus)
        return c.to256Bytes()
    }

    /**
     * MTProto 2.0 rsa_pad encryption for req_DH_params encrypted_data.
     */
    fun rsaPadEncrypt256(innerData: ByteArray, key: TelegramRsaKey): ByteArray {
        require(innerData.size <= 144) { "p_q_inner_data exceeds 144 bytes (${innerData.size})" }
        val dataWithPadding = ByteArray(192)
        System.arraycopy(innerData, 0, dataWithPadding, 0, innerData.size)
        if (innerData.size < 192) {
            val pad = randomBytes(192 - innerData.size)
            System.arraycopy(pad, 0, dataWithPadding, innerData.size, pad.size)
        }
        val dataPadReversed = dataWithPadding.reversedArray()
        val zeroIv = ByteArray(32)

        while (true) {
            val tempKey = randomBytes(32)
            val dataWithHash = dataPadReversed + sha256(tempKey, dataWithPadding)
            val aesEncrypted = aesIgeEncrypt(dataWithHash, tempKey, zeroIv)
            val encryptedHash = sha256(aesEncrypted)
            val tempKeyXor = ByteArray(32) { i -> (tempKey[i].toInt() xor encryptedHash[i].toInt()).toByte() }
            val keyAesEncrypted = tempKeyXor + aesEncrypted
            val candidate = BigInteger(1, keyAesEncrypted)
            if (candidate < key.modulus) {
                return candidate.modPow(key.exponent, key.modulus).to256Bytes()
            }
        }
    }

    /**
     * Official Telegram RSA-2048 public keys (PKCS#1).
     * Production key is listed first; test-backend key is retained as fallback.
     */
    val OFFICIAL_TELEGRAM_KEYS: List<TelegramRsaKey> by lazy {
        listOf(
            // Official Telegram production RSA-2048 key (fingerprint 0xc3b42b026ce86b21)
            """
            MIIBCgKCAQEAwVACPi9w23mF3tBkdZz+zwrzKOaaQdr01vAbU4E1pvkfj4sqDsm6
            lyDONS789sVoD/xCS9Y0hkkC3gtL1tSfTlgCMOOul9lcixlEKzwKENj1Yz/s7daS
            an9tqw3bfUV/nqgbhGX81v/+7RFAEd+RwFnK7a+XYl9sluzHRyVVaTTveB2GazTw
            Efzk2DWgkBluml8OREmvfraX3bkHZJTKX4EQSjBbbdJ2ZXIsRrYOXfaA+xayEGB+
            8hdlLmAjbCVfaigxX0CDqWeR1yFL9kwd9P0NsZRPsmoqVwMbMu7mStFai6aIhc3n
            Slv8kg9qv1m6XHVQY3PnEw+QQtqSIXklHwIDAQAB
            """.trimIndent(),
            // Official Telegram test-backend RSA-2048 key (fingerprint 0xb25898df208d2603)
            """
            MIIBCgKCAQEAyMEdY1aR+sCR3ZSJrtztKTKqigvO/vBfqACJLZtS7QMgCGXJ6XIR
            yy7mx66W0/sOFa7/1mAZtEoIokDP3ShoqF4fVNb6XeqgQfaUHd8wJpDWHcR2OFwv
            plUUI1PLTktZ9uW2WE23b+ixNwJjJGwBDJPQEQFBE+vfmH0JP503wr5INS1poWg/
            j25sIWeYPHYeOrFp/eXaqhISP6G+q2IeTaWTXpwZj4LzXq5YOpk4bYEQ6mvRq7D1
            aHWfYmlEGepfaYR8Q0YqvvhYtMte3ITnuSJs171+GDqpdKcSwHnd6FudwGO4pcCO
            j4WcDuXc2CTHgH8gFTNhp/Y8/SpDOhvn9QIDAQAB
            """.trimIndent()
        ).mapNotNull { pem ->
            runCatching { parsePkcs1RsaKey(pem) }.getOrNull()
        }
    }

    /**
     * Computes SRP 2FA parameters (A, M1) for PasswordKdfAlgoSHA256SHA256PBKDF2HMACSHA512iter100000SHA256ModPow.
     */
    fun computeSrpCheck(
        password: String,
        salt1: ByteArray,
        salt2: ByteArray,
        g: Int,
        pBytes: ByteArray,
        srpBBytes: ByteArray
    ): Pair<ByteArray, ByteArray> {
        val p = BigInteger(1, pBytes)
        val gBig = BigInteger.valueOf(g.toLong())
        val p256 = p.to256Bytes()
        val g256 = gBig.to256Bytes()

        fun h(x: ByteArray) = sha256(x)
        fun sh(data: ByteArray, salt: ByteArray) = sha256(salt, data, salt)
        fun ph1(pwd: ByteArray, s1: ByteArray, s2: ByteArray) = sh(sh(pwd, s1), s2)
        fun pbkdf2(passwordBytes: ByteArray, salt: ByteArray): ByteArray {
            val factory = javax.crypto.SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512")
            // Use raw UTF-8 bytes via PBEKeySpec or manual HMAC-SHA512 PBKDF2 for exact byte fidelity
            val mac = javax.crypto.Mac.getInstance("HmacSHA512")
            mac.init(javax.crypto.spec.SecretKeySpec(passwordBytes, "HmacSHA512"))
            val blockIndex = byteArrayOf(0, 0, 0, 1)
            var u = mac.doFinal(salt + blockIndex)
            val result = u.copyOf()
            for (iter in 2..100_000) {
                u = mac.doFinal(u)
                for (i in result.indices) {
                    result[i] = (result[i].toInt() xor u[i].toInt()).toByte()
                }
            }
            return result
        }

        val pwdBytes = password.toByteArray(Charsets.UTF_8)
        val xBytes = sh(pbkdf2(ph1(pwdBytes, salt1, salt2), salt1), salt2)
        val x = BigInteger(1, xBytes)

        val k = BigInteger(1, h(p256 + g256))
        val bBig = BigInteger(1, srpBBytes)

        val aBytes = randomBytes(256)
        val a = BigInteger(1, aBytes)
        val bigA = gBig.modPow(a, p)
        val a256 = bigA.to256Bytes()

        val u = BigInteger(1, h(a256 + srpBBytes))
        val gx = gBig.modPow(x, p)
        val kgx = k.multiply(gx).mod(p)
        var diff = bBig.subtract(kgx).mod(p)
        if (diff.signum() < 0) diff = diff.add(p)

        val exp = a.add(u.multiply(x))
        val s = diff.modPow(exp, p)
        val kAuth = h(s.to256Bytes())

        val hP = h(p256)
        val hG = h(g256)
        val hpXorHg = ByteArray(32) { i -> (hP[i].toInt() xor hG[i].toInt()).toByte() }
        val m1 = h(hpXorHg + h(salt1) + h(salt2) + a256 + srpBBytes + kAuth)

        return a256 to m1
    }
}
