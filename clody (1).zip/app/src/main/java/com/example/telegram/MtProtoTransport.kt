package com.example.telegram

import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import okio.ByteString.Companion.toByteString
import java.io.EOFException
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

data class TelegramDcEndpoint(
    val dcId: Int,
    val host: String,
    val port: Int = 443,
    val wsUrl: String,
    val useWSS: Boolean = true,
    val testServers: Boolean = false
)

object TelegramDatacenters {
    const val DEFAULT_DC_ID = 2
    const val DEFAULT_PORT = 443

    /**
     * Maps Telegram production Data Center IDs (1..5) to official WebSocket SNI hostnames.
     * Raw IP addresses are rejected by Telegram WebSocket edge servers with -404.
     */
    fun getWebDcHost(dcId: Int): String = when (dcId) {
        1 -> "pluto.web.telegram.org"
        2 -> "venus.web.telegram.org"
        3 -> "aurora.web.telegram.org"
        4 -> "vesta.web.telegram.org"
        5 -> "flora.web.telegram.org"
        else -> "venus.web.telegram.org"
    }

    fun normalizeDcId(dcId: Int): Int = if (dcId in 1..5) dcId else DEFAULT_DC_ID

    val endpoints: Map<Int, TelegramDcEndpoint> = (1..5).associateWith { id ->
        val host = getWebDcHost(id)
        TelegramDcEndpoint(
            dcId = id,
            host = host,
            port = DEFAULT_PORT,
            wsUrl = "wss://$host/apiws",
            useWSS = true,
            testServers = false
        )
    }

    fun forDc(dcId: Int): TelegramDcEndpoint {
        val normalized = normalizeDcId(dcId)
        val host = getWebDcHost(normalized)
        return TelegramDcEndpoint(
            dcId = normalized,
            host = host,
            port = DEFAULT_PORT,
            wsUrl = "wss://$host/apiws",
            useWSS = true,
            testServers = false
        )
    }
}

interface MtProtoTransport {
    val isConnected: Boolean
    suspend fun connect()
    suspend fun sendFrame(payload: ByteArray)
    suspend fun receiveFrame(): ByteArray
    fun close()
}

/**
 * WebSocket MTProto Obfuscated2 Intermediate Transport (wss://<dc>.web.telegram.org/apiws, port 443).
 */
class WebSocketObfuscatedTransport(
    private val endpoint: TelegramDcEndpoint,
    private val okHttpClient: OkHttpClient
) : MtProtoTransport {

    private var webSocket: WebSocket? = null
    private var encryptCipher: Cipher? = null
    private var decryptCipher: Cipher? = null
    private val incomingQueue = LinkedBlockingQueue<Result<ByteArray>>()
    private var recvBuffer = ByteArray(0)

    @Volatile
    override var isConnected: Boolean = false
        private set

    override suspend fun connect() = withContext(Dispatchers.IO) {
        close()
        require(endpoint.useWSS && !endpoint.testServers) {
            "Production WSS transport is required for Telegram WebSocket endpoints"
        }
        val expectedHost = TelegramDatacenters.getWebDcHost(endpoint.dcId)
        val targetWsUrl = "wss://$expectedHost/apiws"
        val openDeferred = CompletableDeferred<Unit>()
        val initPacket = buildObfuscated2InitPacket()

        val req = Request.Builder()
            .url(targetWsUrl)
            .header("Sec-WebSocket-Protocol", "binary")
            .build()

        val ws = okHttpClient.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                val sent = webSocket.send(initPacket.toByteString())
                if (!sent) {
                    isConnected = false
                    openDeferred.completeExceptionally(
                        IOException("Failed to send Obfuscated2 init packet to $expectedHost")
                    )
                    return
                }
                isConnected = true
                openDeferred.complete(Unit)
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                val dec = decryptCipher ?: return
                val decrypted = synchronized(dec) { dec.update(bytes.toByteArray()) }
                if (decrypted != null && decrypted.isNotEmpty()) {
                    incomingQueue.offer(Result.success(decrypted))
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                isConnected = false
                val err = if (response != null) {
                    IOException("WebSocket failure (${response.code} ${response.message}) on $expectedHost: ${t.message}", t)
                } else {
                    IOException("WebSocket failure on $expectedHost: ${t.message}", t)
                }
                if (!openDeferred.isCompleted) {
                    openDeferred.completeExceptionally(err)
                }
                incomingQueue.offer(Result.failure(err))
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                isConnected = false
                val err = EOFException("WebSocket closed ($code): $reason")
                if (!openDeferred.isCompleted) {
                    openDeferred.completeExceptionally(err)
                }
                incomingQueue.offer(Result.failure(err))
            }
        })
        webSocket = ws
        openDeferred.await()
    }

    internal fun buildObfuscated2InitPacket(): ByteArray {
        val random = MtProtoCrypto.randomBytes(64)
        while (true) {
            val firstByte = random[0].toInt() and 0xFF
            val firstInt = ByteBuffer.wrap(random, 0, 4).order(ByteOrder.LITTLE_ENDIAN).int
            val secondInt = ByteBuffer.wrap(random, 4, 4).order(ByteOrder.LITTLE_ENDIAN).int
            val forbidden = firstByte == 0xEF ||
                firstInt == 0x44414548 ||
                firstInt == 0x54534F50 ||
                firstInt == 0x20544547 ||
                firstInt == 0x4954504F ||
                firstInt == 0x02010316 ||
                firstInt == 0xEEEEEEEE.toInt() ||
                firstInt == 0xDDDDDDDD.toInt() ||
                secondInt == 0x00000000
            if (!forbidden) break
            MtProtoCrypto.randomBytes(8).copyInto(random, 0)
        }
        // Set Intermediate transport protocol tag 0xeeeeeeee at offset 56..59
        random[56] = 0xEE.toByte()
        random[57] = 0xEE.toByte()
        random[58] = 0xEE.toByte()
        random[59] = 0xEE.toByte()
        // Set production DC ID (positive 1..5, LE signed 16-bit) at offset 60..61
        val prodDcId = TelegramDatacenters.normalizeDcId(endpoint.dcId)
        random[60] = (prodDcId and 0xFF).toByte()
        random[61] = ((prodDcId shr 8) and 0xFF).toByte()

        val encKey = random.copyOfRange(8, 40)
        val encIv = random.copyOfRange(40, 56)
        val reversed = random.reversedArray()
        val decKey = reversed.copyOfRange(8, 40)
        val decIv = reversed.copyOfRange(40, 56)

        val enc = Cipher.getInstance("AES/CTR/NoPadding").apply {
            init(Cipher.ENCRYPT_MODE, SecretKeySpec(encKey, "AES"), IvParameterSpec(encIv))
        }
        val dec = Cipher.getInstance("AES/CTR/NoPadding").apply {
            init(Cipher.DECRYPT_MODE, SecretKeySpec(decKey, "AES"), IvParameterSpec(decIv))
        }
        encryptCipher = enc
        decryptCipher = dec

        val encryptedInit = enc.update(random) ?: ByteArray(64)
        val out = random.copyOf()
        System.arraycopy(encryptedInit, 56, out, 56, 8)
        return out
    }

    override suspend fun sendFrame(payload: ByteArray) = withContext(Dispatchers.IO) {
        val ws = webSocket ?: throw IOException("WebSocket is not connected")
        val enc = encryptCipher ?: throw IOException("Cipher not initialized")
        val lenBytes = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(payload.size).array()
        val packet = lenBytes + payload
        val encrypted = synchronized(enc) { enc.update(packet) ?: ByteArray(0) }
        if (!ws.send(encrypted.toByteString())) {
            throw IOException("Failed to enqueue WebSocket binary frame")
        }
    }

    override suspend fun receiveFrame(): ByteArray = withContext(Dispatchers.IO) {
        while (true) {
            if (recvBuffer.size >= 4) {
                val frameLen = ByteBuffer.wrap(recvBuffer, 0, 4).order(ByteOrder.LITTLE_ENDIAN).int
                if (frameLen < 0 || frameLen > 32 * 1024 * 1024) {
                    throw IOException("Invalid WebSocket MTProto frame length: $frameLen")
                }
                if (recvBuffer.size >= 4 + frameLen) {
                    val frame = recvBuffer.copyOfRange(4, 4 + frameLen)
                    recvBuffer = recvBuffer.copyOfRange(4 + frameLen, recvBuffer.size)
                    return@withContext frame
                }
            }
            val next = incomingQueue.poll(45, TimeUnit.SECONDS)
                ?: throw IOException("Timed out waiting for Telegram WebSocket packet")
            val chunk = next.getOrThrow()
            recvBuffer += chunk
        }
        @Suppress("UNREACHABLE_CODE")
        ByteArray(0)
    }

    override fun close() {
        isConnected = false
        runCatching { webSocket?.close(1000, "Client closed") }
        webSocket = null
        incomingQueue.clear()
        incomingQueue.offer(Result.failure(EOFException("WebSocket transport closed")))
        recvBuffer = ByteArray(0)
    }
}
