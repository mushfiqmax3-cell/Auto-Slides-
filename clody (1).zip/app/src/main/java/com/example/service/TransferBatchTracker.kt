package com.example.service

import androidx.compose.runtime.Immutable
import com.example.data.local.ClodyDao
import com.example.data.local.DownloadRecordEntity
import com.example.data.local.UploadStatus
import com.example.data.local.UploadTaskEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import java.util.concurrent.atomic.AtomicLong

@Immutable
data class TransferBatchSummary(
    val activeCount: Int = 0,
    val galleryActiveCount: Int = 0,
    val filesActiveCount: Int = 0,
    val totalBatchBytes: Long = 0L,
    val transferredBatchBytes: Long = 0L,
    val combinedSpeedBytesPerSec: Long = 0L,
    val overallFraction: Float = 0f,
    val overallPercent: Int = 0,
    val isActive: Boolean = false
)

fun isGalleryMimeType(mimeType: String): Boolean {
    return mimeType.startsWith("image/") || mimeType.startsWith("video/")
}

fun computeTransferBatchSummary(
    activeUploads: List<UploadTaskEntity>,
    activeDownloads: List<DownloadRecordEntity>,
    downloadSpeeds: Map<Long, Long>,
    completedBatchBytes: Long
): TransferBatchSummary {
    val activeUp = activeUploads.filter { it.status != UploadStatus.CANCELLED.name }
    val activeDown = activeDownloads

    val activeCount = activeUp.size + activeDown.size
    if (activeCount == 0) {
        return TransferBatchSummary()
    }

    val galleryCount = activeUp.count { isGalleryMimeType(it.mimeType) } +
        activeDown.count { isGalleryMimeType(it.mimeType) }
    val filesCount = activeCount - galleryCount

    val activeUpTotal = activeUp.sumOf { maxOf(0L, it.sizeBytes) }
    val activeUpDone = activeUp.sumOf {
        val maxB = maxOf(0L, it.sizeBytes)
        if (it.status == UploadStatus.COMPLETED.name) maxB else it.bytesUploaded.coerceIn(0L, maxB)
    }

    val activeDownTotal = activeDown.sumOf { maxOf(0L, it.sizeBytes) }
    val activeDownDone = activeDown.sumOf {
        val maxB = maxOf(0L, it.sizeBytes)
        if (it.status == "COMPLETED") maxB else it.progressBytes.coerceIn(0L, maxB)
    }

    val safeCompleted = completedBatchBytes.coerceAtLeast(0L)
    val totalBatchBytes = safeCompleted + activeUpTotal + activeDownTotal
    val transferredBatchBytes = (safeCompleted + activeUpDone + activeDownDone)
        .coerceIn(0L, maxOf(1L, totalBatchBytes))

    val overallFraction = if (totalBatchBytes > 0L) {
        (transferredBatchBytes.toFloat() / totalBatchBytes.toFloat()).coerceIn(0f, 1f)
    } else {
        0f
    }
    val overallPercent = (overallFraction * 100f).toInt().coerceIn(0, 100)

    val uploadSpeed = activeUp
        .filter { it.status == UploadStatus.UPLOADING.name }
        .sumOf { maxOf(0L, it.speedBytesPerSec) }
    val downloadSpeed = activeDown
        .filter { it.status == "DOWNLOADING" }
        .sumOf { maxOf(0L, downloadSpeeds[it.id] ?: 0L) }

    return TransferBatchSummary(
        activeCount = activeCount,
        galleryActiveCount = galleryCount,
        filesActiveCount = filesCount,
        totalBatchBytes = totalBatchBytes,
        transferredBatchBytes = transferredBatchBytes,
        combinedSpeedBytesPerSec = uploadSpeed + downloadSpeed,
        overallFraction = overallFraction,
        overallPercent = overallPercent,
        isActive = true
    )
}

class TransferBatchTracker(
    dao: ClodyDao
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val completedBatchBytes = MutableStateFlow(0L)
    private val _downloadSpeeds = MutableStateFlow<Map<Long, Long>>(emptyMap())
    val downloadSpeeds: StateFlow<Map<Long, Long>> = _downloadSpeeds.asStateFlow()

    private val completedAccum = AtomicLong(0L)

    val batchSummary: StateFlow<TransferBatchSummary> = combine(
        dao.observeActiveUploadTasks(),
        dao.observeActiveDownloadRecords(),
        _downloadSpeeds,
        completedBatchBytes
    ) { uploads, downloads, speeds, completedBytes ->
        val hasAnyActive = uploads.any { it.status != UploadStatus.CANCELLED.name } || downloads.isNotEmpty()
        if (!hasAnyActive && completedBytes != 0L) {
            completedAccum.set(0L)
            completedBatchBytes.value = 0L
            TransferBatchSummary()
        } else {
            computeTransferBatchSummary(
                activeUploads = uploads,
                activeDownloads = downloads,
                downloadSpeeds = speeds,
                completedBatchBytes = completedBytes
            )
        }
    }.stateIn(scope, SharingStarted.Eagerly, TransferBatchSummary())

    fun updateDownloadSpeed(recordId: Long, speedBytesPerSec: Long) {
        _downloadSpeeds.update { current ->
            current + (recordId to speedBytesPerSec.coerceAtLeast(0L))
        }
    }

    fun clearDownloadSpeed(recordId: Long) {
        _downloadSpeeds.update { current ->
            if (current.containsKey(recordId)) current - recordId else current
        }
    }

    fun onItemCompleted(sizeBytes: Long) {
        if (sizeBytes > 0L) {
            val next = completedAccum.addAndGet(sizeBytes)
            completedBatchBytes.value = next
        }
    }

    fun resetBatchIfIdle(activeCount: Int) {
        if (activeCount <= 0) {
            completedAccum.set(0L)
            completedBatchBytes.value = 0L
        }
    }

    fun latestSummary(): TransferBatchSummary = batchSummary.value
}
