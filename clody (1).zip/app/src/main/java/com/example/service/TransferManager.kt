package com.example.service

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import com.example.data.local.ClodyDao
import com.example.data.local.DownloadRecordEntity
import com.example.data.local.FileEntity
import com.example.data.local.SettingsRepository
import com.example.data.local.UploadStatus
import com.example.data.local.UploadTaskEntity
import com.example.media.ClodyStreamCache
import com.example.media.ThumbnailGenerator
import com.example.telegram.TelegramClientManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.util.concurrent.ConcurrentHashMap

data class UploadCandidate(
    val uri: Uri,
    val fileName: String,
    val mimeType: String,
    val sizeBytes: Long,
    val durationMs: Long,
    val extractedThumbnailPath: String?,
    val customThumbnailPath: String? = null
)

class TransferManager(
    private val context: Context,
    private val dao: ClodyDao,
    private val telegramClient: TelegramClientManager,
    private val settingsRepository: SettingsRepository,
    private val transferBatchTracker: TransferBatchTracker
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val downloadJobs = ConcurrentHashMap<Long, Job>()

    suspend fun prepareUploadCandidates(uris: List<Uri>): List<UploadCandidate> = withContext(Dispatchers.IO) {
        uris.mapNotNull { uri ->
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            val meta = queryUriMetadata(uri) ?: return@mapNotNull null
            val thumbMeta = ThumbnailGenerator.generateForUri(
                context = context,
                uri = uri,
                mimeType = meta.second,
                uniqueKey = "${uri}_${meta.first}"
            )
            UploadCandidate(
                uri = uri,
                fileName = meta.first,
                mimeType = meta.second,
                sizeBytes = meta.third,
                durationMs = thumbMeta.durationMs,
                extractedThumbnailPath = thumbMeta.thumbnailPath
            )
        }
    }

    private fun queryUriMetadata(uri: Uri): Triple<String, String, Long>? {
        if (uri.scheme == "file") {
            val f = File(uri.path ?: return null)
            if (!f.exists()) return null
            val mime = guessMimeFromName(f.name)
            return Triple(f.name, mime, f.length())
        }
        val cr = context.contentResolver
        var name = "file_${System.currentTimeMillis()}"
        var size = 0L
        cr.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (nameIdx >= 0 && !cursor.isNull(nameIdx)) name = cursor.getString(nameIdx)
                if (sizeIdx >= 0 && !cursor.isNull(sizeIdx)) size = cursor.getLong(sizeIdx)
            }
        }
        val rawMime = cr.getType(uri)
        val mime = if (rawMime.isNullOrBlank() || rawMime == "application/octet-stream") {
            guessMimeFromName(name)
        } else rawMime
        return Triple(name, mime, size)
    }

    suspend fun enqueueUploads(
        candidates: List<UploadCandidate>,
        folderId: Long?,
        folderPath: String
    ) {
        withContext(Dispatchers.IO) {
            for (c in candidates) {
                dao.insertUploadTask(
                    UploadTaskEntity(
                        fileName = c.fileName,
                        localUriString = c.uri.toString(),
                        mimeType = c.mimeType,
                        sizeBytes = c.sizeBytes,
                        durationMs = c.durationMs,
                        folderId = folderId,
                        folderPath = folderPath,
                        extractedThumbnailPath = c.extractedThumbnailPath,
                        customThumbnailPath = c.customThumbnailPath,
                        status = UploadStatus.QUEUED.name
                    )
                )
            }
            val wifiOnly = settingsRepository.settingsFlow.first().uploadWifiOnly
            ClodyUploadService.startQueue(context)
            ClodyUploadWorker.schedule(context, wifiOnly)
        }
    }

    fun pauseUpload(taskId: Long) {
        scope.launch {
            dao.updateUploadStatus(taskId, UploadStatus.PAUSED.name, "Paused")
            context.startService(
                Intent(context, ClodyUploadService::class.java).apply {
                    action = ClodyUploadService.ACTION_PAUSE_CURRENT
                    putExtra(ClodyUploadService.EXTRA_TASK_ID, taskId)
                }
            )
        }
    }

    fun resumeUpload(taskId: Long) {
        scope.launch {
            dao.updateUploadStatus(taskId, UploadStatus.QUEUED.name, null)
            val wifiOnly = settingsRepository.settingsFlow.first().uploadWifiOnly
            ClodyUploadService.startQueue(context)
            ClodyUploadWorker.schedule(context, wifiOnly)
        }
    }

    fun cancelUpload(taskId: Long) {
        scope.launch {
            val task = dao.getUploadTaskById(taskId)
            val wasUploading = task?.status == UploadStatus.UPLOADING.name
            dao.deleteUploadTaskById(taskId)
            if (wasUploading) {
                context.startService(
                    Intent(context, ClodyUploadService::class.java).apply {
                        action = ClodyUploadService.ACTION_CANCEL_CURRENT
                        putExtra(ClodyUploadService.EXTRA_TASK_ID, taskId)
                    }
                )
            }
        }
    }

    fun cancelDownload(recordId: Long) {
        downloadJobs.remove(recordId)?.cancel()
        transferBatchTracker.clearDownloadSpeed(recordId)
        scope.launch {
            dao.deleteDownloadRecordById(recordId)
        }
    }

    /**
     * Explicit user-initiated export to public phone storage (MediaStore Downloads/Clody or Pictures/Clody).
     * Never called automatically during streaming/previewing.
     */
    fun exportToPublicStorage(file: FileEntity, onDone: (Result<String>) -> Unit = {}) {
        scope.launch {
            var createdRecordId = -1L
            var createdUri: Uri? = null
            val res = runCatching {
                val recordId = dao.insertDownloadRecord(
                    DownloadRecordEntity(
                        fileId = file.id,
                        fileName = file.name,
                        sizeBytes = file.sizeBytes,
                        mimeType = file.mimeType,
                        status = "DOWNLOADING"
                    )
                )
                createdRecordId = recordId
                coroutineContext[Job]?.let { downloadJobs[recordId] = it }

                val cached = ClodyStreamCache.getCachedVideoFile(context, file)
                val hexRef = hexToBytes(file.telegramFileReferenceHex)
                val (uri, displayPath) = createPublicMediaStoreTarget(file)
                createdUri = uri

                val startTime = System.currentTimeMillis()
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    if (cached.exists() && file.sizeBytes > 0L && cached.length() == file.sizeBytes) {
                        FileInputStream(cached).use { it.copyTo(out) }
                    } else if (file.telegramDocumentId != 0L) {
                        var offset = 0L
                        val chunkSize = 512 * 1024
                        while (offset < file.sizeBytes) {
                            val chunk = telegramClient.downloadChunk(
                                dcId = file.telegramDcId,
                                documentId = file.telegramDocumentId,
                                accessHash = file.telegramAccessHash,
                                fileReference = hexRef,
                                offset = offset,
                                limit = chunkSize
                            )
                            if (chunk.isEmpty()) break
                            val writeLen = minOf(chunk.size.toLong(), file.sizeBytes - offset).toInt()
                            out.write(chunk, 0, writeLen)
                            offset += writeLen
                            val elapsedSec = maxOf(0.1, (System.currentTimeMillis() - startTime) / 1000.0)
                            val speed = (offset / elapsedSec).toLong()
                            transferBatchTracker.updateDownloadSpeed(recordId, speed)
                            dao.updateDownloadRecord(
                                DownloadRecordEntity(
                                    id = recordId,
                                    fileId = file.id,
                                    fileName = file.name,
                                    sizeBytes = file.sizeBytes,
                                    mimeType = file.mimeType,
                                    publicUriString = uri.toString(),
                                    publicPath = displayPath,
                                    status = "DOWNLOADING",
                                    progressBytes = offset
                                )
                            )
                        }
                    }
                } ?: throw IllegalStateException("Unable to open public destination stream")

                markMediaStorePendingComplete(uri)
                transferBatchTracker.updateDownloadSpeed(recordId, 0L)

                dao.updateDownloadRecord(
                    DownloadRecordEntity(
                        id = recordId,
                        fileId = file.id,
                        fileName = file.name,
                        sizeBytes = file.sizeBytes,
                        mimeType = file.mimeType,
                        publicUriString = uri.toString(),
                        publicPath = displayPath,
                        status = "COMPLETED",
                        progressBytes = file.sizeBytes
                    )
                )
                // Brief pause so UI renders 100% smoothly before auto-vanishing from active queue
                delay(420L)
                transferBatchTracker.onItemCompleted(file.sizeBytes)
                transferBatchTracker.clearDownloadSpeed(recordId)
                dao.deleteDownloadRecordById(recordId)
                displayPath
            }
            if (createdRecordId > 0L) {
                downloadJobs.remove(createdRecordId)
                res.onFailure {
                    transferBatchTracker.clearDownloadSpeed(createdRecordId)
                    dao.deleteDownloadRecordById(createdRecordId)
                    createdUri?.let { u -> runCatching { context.contentResolver.delete(u, null, null) } }
                }
            }
            withContext(Dispatchers.Main) { onDone(res) }
        }
    }

    private fun createPublicMediaStoreTarget(file: FileEntity): Pair<Uri, String> {
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
            put(MediaStore.MediaColumns.MIME_TYPE, file.mimeType)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val relPath = when {
                    file.isImage -> "${Environment.DIRECTORY_PICTURES}/Clody"
                    file.isVideo -> "${Environment.DIRECTORY_MOVIES}/Clody"
                    else -> "${Environment.DIRECTORY_DOWNLOADS}/Clody"
                }
                put(MediaStore.MediaColumns.RELATIVE_PATH, relPath)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
        }
        val collection = when {
            file.isImage -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            file.isVideo -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q -> MediaStore.Downloads.EXTERNAL_CONTENT_URI
            else -> MediaStore.Files.getContentUri("external")
        }
        val uri = context.contentResolver.insert(collection, values)
            ?: throw IllegalStateException("Failed to create MediaStore entry")
        val path = when {
            file.isImage -> "Pictures/Clody/${file.name}"
            file.isVideo -> "Movies/Clody/${file.name}"
            else -> "Downloads/Clody/${file.name}"
        }
        return uri to path
    }

    private fun markMediaStorePendingComplete(uri: Uri) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
            context.contentResolver.update(uri, done, null, null)
        }
    }

    private fun hexToBytes(hex: String): ByteArray {
        if (hex.isEmpty() || hex.length % 2 != 0) return ByteArray(0)
        return ByteArray(hex.length / 2) { i ->
            hex.substring(i * 2, i * 2 + 2).toInt(16).toByte()
        }
    }

    private fun guessMimeFromName(name: String): String {
        return when (name.substringAfterLast('.', "").lowercase()) {
            "jpg", "jpeg" -> "image/jpeg"
            "png" -> "image/png"
            "webp" -> "image/webp"
            "gif" -> "image/gif"
            "heic", "heif" -> "image/heic"
            "mp4" -> "video/mp4"
            "mkv" -> "video/x-matroska"
            "mov" -> "video/quicktime"
            "webm" -> "video/webm"
            "mp3" -> "audio/mpeg"
            "m4a", "aac" -> "audio/mp4"
            "wav" -> "audio/wav"
            "ogg", "opus" -> "audio/ogg"
            "flac" -> "audio/flac"
            "pdf" -> "application/pdf"
            "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            "rtf" -> "application/rtf"
            "xlsx" -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            "xls" -> "application/vnd.ms-excel"
            "csv" -> "text/csv"
            "txt", "log", "md", "markdown" -> "text/plain"
            "json" -> "application/json"
            "xml" -> "text/xml"
            "html", "htm" -> "text/html"
            "css" -> "text/css"
            "js" -> "text/javascript"
            "py", "kt", "java" -> "text/plain"
            "zip" -> "application/zip"
            "7z" -> "application/x-7z-compressed"
            "tar" -> "application/x-tar"
            "rar" -> "application/vnd.rar"
            "apk" -> "application/vnd.android.package-archive"
            else -> "application/octet-stream"
        }
    }
}
