package com.example

import android.content.Context
import android.net.Uri
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.ClodyDatabase
import com.example.data.local.DownloadRecordEntity
import com.example.data.local.FileEntity
import com.example.data.local.FolderEntity
import com.example.data.local.GalleryAlbumEntity
import com.example.data.local.UploadStatus
import com.example.data.local.UploadTaskEntity
import com.example.media.DocumentParser
import com.example.media.LocalFirstResolver
import com.example.media.MediaPlaybackOrigin
import com.example.media.ResolvedMediaSource
import com.example.media.WordBlock
import com.example.data.local.SecureStorage
import com.example.service.computeTransferBatchSummary
import com.example.service.isGalleryMimeType
import com.example.telegram.MtProtoCrypto
import com.example.telegram.TelegramDatacenters
import com.example.telegram.TelegramRpcException
import com.example.telegram.TlReader
import com.example.telegram.TlWriter
import com.example.telegram.WebSocketObfuscatedTransport
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.test.runTest
import okhttp3.OkHttpClient
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File
import java.io.FileOutputStream
import java.math.BigInteger
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Before
    fun resetDatabase() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = ClodyDatabase.getInstance(context)
        val dao = db.clodyDao()
        dao.clearAllFiles()
        dao.clearAllFolders()
        dao.clearAllAlbums()
        db.openHelper.writableDatabase.execSQL("DELETE FROM upload_tasks")
        db.openHelper.writableDatabase.execSQL("DELETE FROM download_records")
    }

    @Test
    fun `app name is Clody`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Clody", appName)
    }

    @Test
    fun `database starts completely empty with zero mock files`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = ClodyDatabase.getInstance(context)
        val files = db.clodyDao().observeActiveFiles().first()
        val folders = db.clodyDao().observeAllFolders().first()
        assertTrue(files.isEmpty())
        assertTrue(folders.isEmpty())
    }

    @Test
    fun `gallery strictly isolates images and videos from audio docs and binaries`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = ClodyDatabase.getInstance(context)
        val dao = db.clodyDao()

        dao.insertFile(FileEntity(name = "photo.jpg", extension = "jpg", sizeBytes = 100, mimeType = "image/jpeg"))
        dao.insertFile(FileEntity(name = "clip.mp4", extension = "mp4", sizeBytes = 200, mimeType = "video/mp4"))
        dao.insertFile(FileEntity(name = "song.mp3", extension = "mp3", sizeBytes = 300, mimeType = "audio/mpeg"))
        dao.insertFile(FileEntity(name = "report.pdf", extension = "pdf", sizeBytes = 400, mimeType = "application/pdf"))
        dao.insertFile(FileEntity(name = "budget.xlsx", extension = "xlsx", sizeBytes = 500, mimeType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
        dao.insertFile(FileEntity(name = "app.apk", extension = "apk", sizeBytes = 600, mimeType = "application/vnd.android.package-archive"))

        val gallery = dao.observeGalleryMedia().first()
        assertEquals(2, gallery.size)
        assertTrue(gallery.all { it.isImage || it.isVideo })
    }

    @Test
    fun `file entity detects audio pdf word spreadsheet text and binary types`() {
        val audio = FileEntity(name = "track.flac", extension = "flac", sizeBytes = 10, mimeType = "audio/flac")
        val pdf = FileEntity(name = "spec.pdf", extension = "pdf", sizeBytes = 10, mimeType = "application/pdf")
        val docx = FileEntity(name = "memo.docx", extension = "docx", sizeBytes = 10, mimeType = "application/vnd.openxmlformats-officedocument.wordprocessingml.document")
        val xlsx = FileEntity(name = "sheet.xlsx", extension = "xlsx", sizeBytes = 10, mimeType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
        val md = FileEntity(name = "README.md", extension = "md", sizeBytes = 10, mimeType = "text/plain")
        val apk = FileEntity(name = "build.apk", extension = "apk", sizeBytes = 10, mimeType = "application/vnd.android.package-archive")

        assertTrue(audio.isAudio)
        assertFalse(audio.isInAppDocument)
        assertTrue(pdf.isPdf && pdf.isInAppDocument)
        assertTrue(docx.isWordDoc && docx.isInAppDocument)
        assertTrue(xlsx.isSpreadsheet && xlsx.isInAppDocument)
        assertTrue(md.isTextOrCode && md.isInAppDocument)
        assertTrue(apk.isApp && !apk.isInAppDocument && !apk.isAudio)
    }

    @Test
    fun `local first resolver returns on device when file exists and cloud fallback when deleted`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val tempFile = File(context.cacheDir, "local_first_test.txt").apply {
            writeText("Hello Clody Local-First")
        }
        val entity = FileEntity(
            name = "local_first_test.txt",
            extension = "txt",
            sizeBytes = tempFile.length(),
            mimeType = "text/plain",
            localSourceUri = Uri.fromFile(tempFile).toString(),
            telegramDocumentId = 123456L
        )

        val firstResolve = LocalFirstResolver.resolve(context, entity)
        assertTrue(firstResolve is ResolvedMediaSource.LocalDevice)
        assertEquals(MediaPlaybackOrigin.ON_DEVICE, firstResolve.origin)

        assertTrue(tempFile.delete())

        val secondResolve = LocalFirstResolver.resolve(context, entity)
        assertTrue(secondResolve is ResolvedMediaSource.CloudStream)
        assertEquals(MediaPlaybackOrigin.CLOUD_STREAM, secondResolve.origin)
    }

    @Test
    fun `document parser handles csv docx and xlsx accurately`() {
        val context = ApplicationProvider.getApplicationContext<Context>()

        // 1. CSV
        val csvFile = File(context.cacheDir, "test_data.csv").apply {
            writeText("Name,Role,City\n\"Rahman, A.\",Engineer,Dhaka\nSara,Designer,Chattogram\n")
        }
        val csvSheets = DocumentParser.parseCsv(csvFile)
        assertEquals(1, csvSheets.size)
        assertEquals(3, csvSheets[0].rows.size)
        assertEquals("Rahman, A.", csvSheets[0].rows[1][0])
        assertEquals("Dhaka", csvSheets[0].rows[1][2])
        csvFile.delete()

        // 2. DOCX
        val docxFile = File(context.cacheDir, "test_doc.docx")
        ZipOutputStream(FileOutputStream(docxFile)).use { zos ->
            zos.putNextEntry(ZipEntry("word/document.xml"))
            zos.write(
                """
                <w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
                  <w:body>
                    <w:p><w:pPr><w:pStyle w:val="Heading1"/></w:pPr><w:r><w:t>Project Summary</w:t></w:r></w:p>
                    <w:p><w:r><w:t>Clody stores files cleanly.</w:t></w:r></w:p>
                  </w:body>
                </w:document>
                """.trimIndent().toByteArray(Charsets.UTF_8)
            )
            zos.closeEntry()
        }
        val blocks = DocumentParser.parseDocx(docxFile)
        assertTrue(blocks.any { it is WordBlock.Heading && it.text == "Project Summary" })
        assertTrue(blocks.any { it is WordBlock.Paragraph && it.text == "Clody stores files cleanly." })
        docxFile.delete()

        // 3. XLSX
        val xlsxFile = File(context.cacheDir, "test_sheet.xlsx")
        ZipOutputStream(FileOutputStream(xlsxFile)).use { zos ->
            zos.putNextEntry(ZipEntry("xl/sharedStrings.xml"))
            zos.write("""<sst><si><t>Item</t></si><si><t>Count</t></si></sst>""".toByteArray())
            zos.closeEntry()
            zos.putNextEntry(ZipEntry("xl/worksheets/sheet1.xml"))
            zos.write(
                """
                <worksheet>
                  <sheetData>
                    <row r="1"><c r="A1" t="s"><v>0</v></c><c r="B1" t="s"><v>1</v></c></row>
                    <row r="2"><c r="A2" t="inlineStr"><is><t>Photos</t></is></c><c r="B2"><v>42</v></c></row>
                  </sheetData>
                </worksheet>
                """.trimIndent().toByteArray()
            )
            zos.closeEntry()
        }
        val xlsxSheets = DocumentParser.parseXlsx(xlsxFile)
        assertEquals(1, xlsxSheets.size)
        assertEquals(listOf("Item", "Count"), xlsxSheets[0].rows[0])
        assertEquals(listOf("Photos", "42"), xlsxSheets[0].rows[1])
        xlsxFile.delete()
    }

    @Test
    fun `official Telegram RSA public key computes exact fingerprint`() {
        val keys = MtProtoCrypto.OFFICIAL_TELEGRAM_KEYS
        assertEquals(2, keys.size)
        assertEquals(0xc3b42b026ce86b21uL.toLong(), keys[0].fingerprint)
        assertEquals(0xb25898df208d2603uL.toLong(), keys[1].fingerprint)
        val encrypted = MtProtoCrypto.rsaPadEncrypt256(ByteArray(96) { 0x42 }, keys[0])
        assertEquals(256, encrypted.size)
    }

    @Test
    fun `aes ige roundtrip and pq factorization work accurately`() {
        val key = MtProtoCrypto.randomBytes(32)
        val iv = MtProtoCrypto.randomBytes(32)
        val plain = MtProtoCrypto.randomBytes(64)
        val encrypted = MtProtoCrypto.aesIgeEncrypt(plain, key, iv)
        val decrypted = MtProtoCrypto.aesIgeDecrypt(encrypted, key, iv)
        assertArrayEquals(plain, decrypted)

        val p = 179424673L
        val q = 179424691L
        val pq = BigInteger.valueOf(p).multiply(BigInteger.valueOf(q)).toByteArray()
        val (fp, fq) = MtProtoCrypto.factorizePQ(pq)
        assertEquals(p, fp)
        assertEquals(q, fq)
    }

    @Test
    fun `tl writer and reader roundtrip bytes and strings`() {
        val payload = TlWriter().apply {
            writeInt(0x12345678)
            writeLong(9876543210123L)
            writeString("Clody Cloud Storage")
            writeBytes(byteArrayOf(1, 2, 3, 4, 5))
        }.toByteArray()

        val reader = TlReader(payload)
        assertEquals(0x12345678, reader.readInt())
        assertEquals(9876543210123L, reader.readLong())
        assertEquals("Clody Cloud Storage", reader.readString())
        assertArrayEquals(byteArrayOf(1, 2, 3, 4, 5), reader.readBytes())
    }

    @Test
    fun `telegram datacenters enforce production wss domain mapping dc1 to dc5 on port 443`() {
        assertEquals("pluto.web.telegram.org", TelegramDatacenters.getWebDcHost(1))
        assertEquals("venus.web.telegram.org", TelegramDatacenters.getWebDcHost(2))
        assertEquals("aurora.web.telegram.org", TelegramDatacenters.getWebDcHost(3))
        assertEquals("vesta.web.telegram.org", TelegramDatacenters.getWebDcHost(4))
        assertEquals("flora.web.telegram.org", TelegramDatacenters.getWebDcHost(5))
        assertEquals("venus.web.telegram.org", TelegramDatacenters.getWebDcHost(99))

        for (dc in 1..5) {
            val endpoint = TelegramDatacenters.forDc(dc)
            assertEquals(dc, endpoint.dcId)
            assertEquals(443, endpoint.port)
            assertTrue(endpoint.useWSS)
            assertFalse(endpoint.testServers)
            assertEquals("wss://${TelegramDatacenters.getWebDcHost(dc)}/apiws", endpoint.wsUrl)
            assertFalse(endpoint.host.matches(Regex("\\d+\\.\\d+\\.\\d+\\.\\d+")))
        }
    }

    @Test
    fun `default dc is dc2 venus and invalid dc normalizes safely`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val storage = SecureStorage(context)
        storage.clearAll()
        assertEquals(2, storage.getActiveDc())
        assertEquals("venus.web.telegram.org", TelegramDatacenters.forDc(storage.getActiveDc()).host)

        storage.saveActiveDc(-2)
        assertEquals(2, storage.getActiveDc())
        storage.saveActiveDc(5)
        assertEquals(5, storage.getActiveDc())
        assertEquals("flora.web.telegram.org", TelegramDatacenters.forDc(storage.getActiveDc()).host)
        storage.clearAll()
    }

    @Test
    fun `obfuscated2 init packet encodes intermediate tag and positive dcId`() {
        val endpoint = TelegramDatacenters.forDc(5)
        val transport = WebSocketObfuscatedTransport(endpoint, OkHttpClient())
        val initPacket = transport.buildObfuscated2InitPacket()
        assertEquals(64, initPacket.size)

        val encKey = initPacket.copyOfRange(8, 40)
        val encIv = initPacket.copyOfRange(40, 56)
        val serverDec = Cipher.getInstance("AES/CTR/NoPadding").apply {
            init(Cipher.DECRYPT_MODE, SecretKeySpec(encKey, "AES"), IvParameterSpec(encIv))
        }
        val decrypted = serverDec.update(initPacket)!!
        val tag = ByteBuffer.wrap(decrypted, 56, 4).order(ByteOrder.LITTLE_ENDIAN).int
        val dcId = ByteBuffer.wrap(decrypted, 60, 2).order(ByteOrder.LITTLE_ENDIAN).short.toInt()
        assertEquals(0xEEEEEEEE.toInt(), tag)
        assertEquals(5, dcId)
    }

    @Test
    fun `migration rpc exceptions extract target dc accurately`() {
        assertEquals(5, TelegramRpcException(303, "PHONE_MIGRATE_5").migrationDc())
        assertEquals(2, TelegramRpcException(303, "NETWORK_MIGRATE_2").migrationDc())
        assertEquals(4, TelegramRpcException(303, "FILE_MIGRATE_4").migrationDc())
        assertEquals(1, TelegramRpcException(303, "USER_MIGRATE_1").migrationDc())
    }

    @Test
    fun `gallery albums stay isolated from file folders and track favorites and trash`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = ClodyDatabase.getInstance(context)
        val dao = db.clodyDao()

        val folderId = dao.insertFolder(FolderEntity(name = "WorkDocs"))
        val albumId = dao.insertAlbum(GalleryAlbumEntity(name = "Summer Trips"))

        val photoId = dao.insertFile(
            FileEntity(
                name = "beach.jpg",
                extension = "jpg",
                sizeBytes = 1000,
                mimeType = "image/jpeg",
                folderId = null,
                albumId = null,
                isFavorite = true
            )
        )
        val videoId = dao.insertFile(
            FileEntity(
                name = "sunset.mp4",
                extension = "mp4",
                sizeBytes = 2000,
                mimeType = "video/mp4",
                folderId = folderId
            )
        )
        dao.insertFile(
            FileEntity(
                name = "notes.pdf",
                extension = "pdf",
                sizeBytes = 500,
                mimeType = "application/pdf",
                folderId = folderId,
                isFavorite = true
            )
        )

        dao.setFileAlbum(photoId, albumId)
        val albumItems = dao.observeFilesInAlbum(albumId).first()
        assertEquals(1, albumItems.size)
        assertEquals("beach.jpg", albumItems[0].name)

        // Gallery favorites only includes visual media, not PDF
        val favMedia = dao.observeFavoriteGalleryMedia().first()
        assertEquals(1, favMedia.size)
        assertEquals("beach.jpg", favMedia[0].name)

        // Folders remain strictly untouched by albums
        assertEquals(1, dao.observeAllFolders().first().size)
        assertEquals(1, dao.observeGalleryAlbums().first().size)

        // Soft-delete moves video to Gallery Trash
        dao.softDeleteFile(videoId)
        val trashMedia = dao.observeDeletedGalleryMedia().first()
        assertEquals(1, trashMedia.size)
        assertEquals("sunset.mp4", trashMedia[0].name)
    }

    @Test
    fun `unified batch progress stays monotonic as earlier items finish and auto vanish`() = runTest {
        val up1 = UploadTaskEntity(
            id = 1,
            fileName = "photo1.jpg",
            localUriString = "file:///tmp/1.jpg",
            mimeType = "image/jpeg",
            sizeBytes = 100L,
            bytesUploaded = 100L,
            speedBytesPerSec = 0L,
            status = UploadStatus.COMPLETED.name
        )
        val up2 = UploadTaskEntity(
            id = 2,
            fileName = "clip.mp4",
            localUriString = "file:///tmp/2.mp4",
            mimeType = "video/mp4",
            sizeBytes = 100L,
            bytesUploaded = 0L,
            speedBytesPerSec = 50L,
            status = UploadStatus.UPLOADING.name
        )
        val dl1 = DownloadRecordEntity(
            id = 10,
            fileId = 5,
            fileName = "report.pdf",
            sizeBytes = 200L,
            mimeType = "application/pdf",
            status = "DOWNLOADING",
            progressBytes = 100L
        )

        // Step 1: up1 at 100%, up2 at 0%, dl1 at 50% -> 200 / 400 = 50%
        val mid = computeTransferBatchSummary(
            activeUploads = listOf(up1, up2),
            activeDownloads = listOf(dl1),
            downloadSpeeds = mapOf(10L to 25L),
            completedBatchBytes = 0L
        )
        assertEquals(3, mid.activeCount)
        assertEquals(2, mid.galleryActiveCount)
        assertEquals(1, mid.filesActiveCount)
        assertEquals(400L, mid.totalBatchBytes)
        assertEquals(200L, mid.transferredBatchBytes)
        assertEquals(50, mid.overallPercent)
        assertEquals(75L, mid.combinedSpeedBytesPerSec)

        // Step 2: up1 auto-vanishes (deleted from DB), its 100L moves to completedBatchBytes -> still 50%!
        val afterVanish = computeTransferBatchSummary(
            activeUploads = listOf(up2),
            activeDownloads = listOf(dl1),
            downloadSpeeds = mapOf(10L to 25L),
            completedBatchBytes = 100L
        )
        assertEquals(2, afterVanish.activeCount)
        assertEquals(400L, afterVanish.totalBatchBytes)
        assertEquals(200L, afterVanish.transferredBatchBytes)
        assertEquals(50, afterVanish.overallPercent)

        // Step 3: DAO auto-vanish delete clears active queue cleanly
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = ClodyDatabase.getInstance(context)
        val dao = db.clodyDao()
        val insertedId = dao.insertUploadTask(up2.copy(id = 0))
        assertEquals(1, dao.observeActiveUploadTasks().first().size)
        dao.deleteUploadTaskById(insertedId)
        assertTrue(dao.observeActiveUploadTasks().first().isEmpty())
        assertTrue(isGalleryMimeType("video/mp4"))
        assertFalse(isGalleryMimeType("application/pdf"))
    }
}
