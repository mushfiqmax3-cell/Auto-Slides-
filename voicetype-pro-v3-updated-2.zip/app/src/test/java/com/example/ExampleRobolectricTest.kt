package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("VoiceType Pro", appName)
    }

    @Test
    fun `default model is gemini-3_8-flash and camelCase inlineData is generated`() {
        assertEquals("gemini-3.8-flash", Prefs.DEFAULT_MODEL_NAME)

        val payload = GeminiTranscriber.buildTranscriptionJson("UklGRiQAAABXQVZFZm10IBAAAAABAAEA", "audio/mp4")
        val root = JSONObject(payload)
        val contents = root.getJSONArray("contents")
        val parts = contents.getJSONObject(0).getJSONArray("parts")
        val firstPart = parts.getJSONObject(0)

        assertTrue(firstPart.has("inlineData"))
        assertFalse(firstPart.has("inline_data"))

        val inlineData = firstPart.getJSONObject("inlineData")
        assertEquals("audio/mp4", inlineData.getString("mimeType"))
        assertFalse(inlineData.has("mime_type"))
        assertNotNull(inlineData.getString("data"))
    }

    @Test
    fun `sync with keyboard setting persists and defaults to off`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        Prefs.init(context)
        assertFalse(Prefs.getSyncWithKeyboard(context))

        Prefs.saveSyncWithKeyboard(context, true)
        assertTrue(Prefs.getSyncWithKeyboard(context))

        Prefs.saveSyncWithKeyboard(context, false)
        assertFalse(Prefs.getSyncWithKeyboard(context))
    }

    @Test
    fun `models json keeps only generateContent gemini models`() {
        val json = """
            {"models":[
              {"name":"models/gemini-3.8-flash","supportedGenerationMethods":["generateContent","countTokens"]},
              {"name":"models/gemini-3.5-flash-lite","supportedGenerationMethods":["generateContent"]},
              {"name":"models/gemini-3.8-flash-tts","supportedGenerationMethods":["generateContent"]},
              {"name":"models/text-embedding-004","supportedGenerationMethods":["embedContent"]},
              {"name":"models/gemini-embedding-001","supportedGenerationMethods":["embedContent"]},
              {"name":"models/gemini-x-only-count","supportedGenerationMethods":["countTokens"]}
            ]}
        """.trimIndent()
        val result = GeminiTranscriber.parseModelsJson(json)
        assertEquals(listOf("gemini-3.8-flash", "gemini-3.5-flash-lite"), result)
    }

    @Test
    fun `prompt tone adapts to the target app`() {
        assertEquals(GeminiTranscriber.TRANSCRIPTION_PROMPT, GeminiTranscriber.buildPrompt(null))
        assertEquals(GeminiTranscriber.TRANSCRIPTION_PROMPT, GeminiTranscriber.buildPrompt("com.unknown.app"))
        assertTrue(GeminiTranscriber.buildPrompt("com.google.android.gm").contains("EMAIL"))
        assertTrue(GeminiTranscriber.buildPrompt("com.whatsapp").contains("casual CHAT"))
    }

    @Test
    fun `state machine transitions follow exact specification`() {
        val machine = BubbleStateMachine()
        assertEquals(BubbleState.IDLE, machine.currentState)
        assertTrue(machine.isMicEnabled())

        // IDLE --(tap mic)--> RECORDING
        assertEquals(BubbleState.RECORDING, machine.onMicTapped())
        assertTrue(machine.isMicEnabled())

        // RECORDING --(tap ✕)--> IDLE
        assertEquals(BubbleState.IDLE, machine.onCancelToIdle())

        // IDLE --(tap mic)--> RECORDING --(tap mic)--> PROCESSING
        assertEquals(BubbleState.RECORDING, machine.onMicTapped())
        assertEquals(BubbleState.PROCESSING, machine.onMicTapped())
        assertFalse(machine.isMicEnabled())
        assertNull(machine.onMicTapped())

        // PROCESSING --(success)--> INSERTED --> IDLE
        assertTrue(machine.onTranscriptionSuccess())
        assertEquals(BubbleState.INSERTED, machine.currentState)
        machine.resetToIdle()
        assertEquals(BubbleState.IDLE, machine.currentState)
    }

    @Test
    fun `text inserter splices at cursor with smart leading space`() {
        val (emptyResult, emptyCursor) = TextInserter.buildInsertedText(
            existingText = "",
            selectionStart = 0,
            selectionEnd = 0,
            newText = "আমি ভালো আছি।"
        )
        assertEquals("আমি ভালো আছি।", emptyResult)
        assertEquals("আমি ভালো আছি।".length, emptyCursor)

        val (appendResult, appendCursor) = TextInserter.buildInsertedText(
            existingText = "Hello",
            selectionStart = 5,
            selectionEnd = 5,
            newText = "world!"
        )
        assertEquals("Hello world!", appendResult)
        assertEquals(12, appendCursor)
    }

    @Test
    fun `audio recorder normalization amplifies quiet speech`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val recorder = AudioRecorderManager(context) {}

        // 10 samples of quiet 16-bit PCM (amplitude 400)
        val quietPcm = ByteArray(20)
        for (i in 0 until 10) {
            val sample = 400
            quietPcm[i * 2] = (sample and 0xFF).toByte()
            quietPcm[i * 2 + 1] = ((sample shr 8) and 0xFF).toByte()
        }

        val boosted = recorder.normalizePcm16Le(quietPcm)
        val boostedSample = ((boosted[1].toInt() shl 8) or (boosted[0].toInt() and 0xFF)).toShort().toInt()

        // Should be boosted well above 400 (up to 30x gain, so ~12000)
        assertTrue("Boosted sample ($boostedSample) should be > 3000", boostedSample >= 3000)
    }
}
