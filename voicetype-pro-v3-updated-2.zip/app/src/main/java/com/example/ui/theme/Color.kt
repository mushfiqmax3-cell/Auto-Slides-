package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light & Dark Theme Palette for VoiceType Pro
val IndigoPrimaryLight = Color(0xFF4F46E5)
val OnIndigoPrimaryLight = Color(0xFFFFFFFF)
val IndigoContainerLight = Color(0xFFE0E7FF)
val OnIndigoContainerLight = Color(0xFF1E1B4B)

val CyanSecondaryLight = Color(0xFF0891B2)
val OnCyanSecondaryLight = Color(0xFFFFFFFF)
val CyanContainerLight = Color(0xFFCFFAFE)
val OnCyanContainerLight = Color(0xFF083344)

val EmeraldTertiaryLight = Color(0xFF059669)
val EmeraldContainerLight = Color(0xFFD1FAE5)

val SurfaceLight = Color(0xFFF8FAFC)
val OnSurfaceLight = Color(0xFF0F172A)
val SurfaceVariantLight = Color(0xFFEEF2FF)
val OnSurfaceVariantLight = Color(0xFF475569)

// Dark Theme Tokens
val IndigoPrimaryDark = Color(0xFF818CF8)
val OnIndigoPrimaryDark = Color(0xFF1E1B4B)
val IndigoContainerDark = Color(0xFF312E81)
val OnIndigoContainerDark = Color(0xFFE0E7FF)

val CyanSecondaryDark = Color(0xFF38BDF8)
val OnCyanSecondaryDark = Color(0xFF082F49)
val CyanContainerDark = Color(0xFF0C4A6E)
val OnCyanContainerDark = Color(0xFFE0F2FE)

val EmeraldTertiaryDark = Color(0xFF34D399)
val EmeraldContainerDark = Color(0xFF064E3B)

val SurfaceDark = Color(0xFF0B0F19)
val OnSurfaceDark = Color(0xFFF1F5F9)
val SurfaceVariantDark = Color(0xFF161E2E)
val OnSurfaceVariantDark = Color(0xFF94A3B8)

val StatusGreen = Color(0xFF10B981)
val StatusRed = Color(0xFFF43F5E)
val StatusAmber = Color(0xFFF59E0B)
