package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddToHomeScreen
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DesktopWindows
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FindInPage
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Checkbox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.BrowserTabModel
import com.example.FindInPageState
import com.example.R
import com.example.WebViewManager
import com.example.data.BookmarkEntity
import com.example.data.HistoryEntity
import com.example.ui.theme.ChromeAmberWarn
import com.example.ui.theme.ChromeEmeraldShield
import com.example.ui.theme.ChromeIncognitoBg
import com.example.ui.theme.ChromeIncognitoOmnibox
import com.example.ui.theme.JetBrainsMonoFont
import com.example.ui.theme.PlusJakartaSansFont

@Composable
fun ChromeTopToolbar(
    activeTab: BrowserTabModel?,
    tabCount: Int,
    isBookmarked: Boolean,
    isOverflowMenuOpen: Boolean,
    webViewManager: WebViewManager,
    bookmarks: List<BookmarkEntity>,
    history: List<HistoryEntity>,
    onHomeClick: () -> Unit,
    onSubmitUrl: (String) -> Unit,
    onToggleBookmark: () -> Unit,
    onOpenTabSwitcher: () -> Unit,
    onOpenSiteInfo: () -> Unit,
    onToggleOverflowMenu: () -> Unit,
    onDismissOverflowMenu: () -> Unit
) {
    val focusManager = LocalFocusManager.current
    val isIncognito = activeTab?.isIncognito == true
    val isNewTabPage = activeTab?.url == WebViewManager.NEW_TAB_URL
    val rawUrl = if (isNewTabPage) "" else (activeTab?.url ?: WebViewManager.DEFAULT_HOME_URL)

    var textFieldValue by remember(activeTab?.id, rawUrl) {
        mutableStateOf(TextFieldValue(text = rawUrl, selection = TextRange(rawUrl.length)))
    }
    var isFocused by remember { mutableStateOf(false) }
    var dragAccumulated by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(rawUrl, isFocused) {
        if (!isFocused) {
            textFieldValue = TextFieldValue(text = rawUrl, selection = TextRange(rawUrl.length))
        }
    }

    val barContainerColor = if (isIncognito) ChromeIncognitoBg else MaterialTheme.colorScheme.surface
    val omniboxBgColor = if (isIncognito) ChromeIncognitoOmnibox else MaterialTheme.colorScheme.surfaceVariant
    val barContentColor = if (isIncognito) Color(0xFFE8EAED) else MaterialTheme.colorScheme.onSurface

    Column(modifier = Modifier.fillMaxWidth()) {
        Surface(
            color = barContainerColor,
            tonalElevation = if (isIncognito) 0.dp else 3.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 6.dp, vertical = 6.dp)
            ) {
                // Home / Incognito Indicator Button
                IconButton(
                    onClick = onHomeClick,
                    modifier = Modifier
                        .size(44.dp)
                        .minimumInteractiveComponentSize()
                        .testTag("nav_home_button")
                ) {
                    Icon(
                        imageVector = if (isIncognito) Icons.Default.VisibilityOff else Icons.Default.Home,
                        contentDescription = stringResource(R.string.cd_nav_home),
                        tint = barContentColor,
                        modifier = Modifier.size(22.dp)
                    )
                }

                // Authentic Chrome Pill Omnibox (swipeable left/right to switch tabs)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .clip(RoundedCornerShape(22.dp))
                        .background(omniboxBgColor)
                        .border(
                            width = if (isFocused) 1.5.dp else 0.dp,
                            color = if (isFocused) MaterialTheme.colorScheme.primary else Color.Transparent,
                            shape = RoundedCornerShape(22.dp)
                        )
                        .pointerInput(activeTab?.id) {
                            detectHorizontalDragGestures(
                                onDragStart = { dragAccumulated = 0f },
                                onHorizontalDrag = { _, dragAmount -> dragAccumulated += dragAmount },
                                onDragEnd = {
                                    if (dragAccumulated > 90f) {
                                        webViewManager.switchTabByDelta(-1)
                                    } else if (dragAccumulated < -90f) {
                                        webViewManager.switchTabByDelta(1)
                                    }
                                    dragAccumulated = 0f
                                }
                            )
                        }
                        .padding(horizontal = 10.dp)
                ) {
                    // SSL / Search Icon (clickable to show Site Security Info)
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .clickable(enabled = !isNewTabPage, onClick = onOpenSiteInfo)
                    ) {
                        Icon(
                            imageVector = when {
                                isNewTabPage || isFocused -> Icons.Default.Search
                                activeTab?.isSslSecure != false -> Icons.Default.Lock
                                else -> Icons.Default.Warning
                            },
                            contentDescription = stringResource(R.string.cd_ssl_security),
                            tint = when {
                                isNewTabPage || isFocused -> barContentColor.copy(alpha = 0.7f)
                                activeTab?.isSslSecure != false -> ChromeEmeraldShield
                                else -> ChromeAmberWarn
                            },
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    Box(
                        contentAlignment = Alignment.CenterStart,
                        modifier = Modifier.weight(1f)
                    ) {
                        if (textFieldValue.text.isEmpty() && !isFocused) {
                            Text(
                                text = "Search or type web address",
                                style = MaterialTheme.typography.bodyMedium,
                                color = barContentColor.copy(alpha = 0.6f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        } else if (!isFocused && !isNewTabPage) {
                            // Show clean Chrome-style host + path display when not focused
                            val displayHost = remember(rawUrl) {
                                formatCompactDisplayUrl(rawUrl)
                            }
                            Text(
                                text = displayHost,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontFamily = PlusJakartaSansFont,
                                    fontWeight = FontWeight.Medium
                                ),
                                color = barContentColor,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        isFocused = true
                                    }
                            )
                        }

                        // Always render BasicTextField so focus works smoothly on tap
                        BasicTextField(
                            value = textFieldValue,
                            onValueChange = { textFieldValue = it },
                            singleLine = true,
                            textStyle = TextStyle(
                                color = if (isFocused || isNewTabPage) barContentColor else Color.Transparent,
                                fontSize = 14.sp,
                                fontFamily = JetBrainsMonoFont
                            ),
                            cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Uri,
                                imeAction = ImeAction.Go
                            ),
                            keyboardActions = KeyboardActions(
                                onGo = {
                                    focusManager.clearFocus()
                                    isFocused = false
                                    onSubmitUrl(textFieldValue.text)
                                }
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .onFocusChanged { state ->
                                    isFocused = state.isFocused
                                    if (state.isFocused) {
                                        onDismissOverflowMenu()
                                        textFieldValue = textFieldValue.copy(
                                            selection = TextRange(0, textFieldValue.text.length)
                                        )
                                    }
                                }
                                .testTag("omnibox_input")
                        )
                    }

                    if (isFocused && textFieldValue.text.isNotEmpty()) {
                        IconButton(
                            onClick = { textFieldValue = TextFieldValue("") },
                            modifier = Modifier.size(30.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Clear URL",
                                tint = barContentColor.copy(alpha = 0.7f),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    } else if (!isNewTabPage) {
                        IconButton(
                            onClick = onToggleBookmark,
                            modifier = Modifier
                                .size(30.dp)
                                .testTag("bookmark_star_button")
                        ) {
                            Icon(
                                imageVector = if (isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                                contentDescription = "Bookmark page",
                                tint = if (isBookmarked) MaterialTheme.colorScheme.primary else barContentColor.copy(alpha = 0.75f),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.width(4.dp))

                // Chrome Square Tab Switcher Badge [5]
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(44.dp)
                        .minimumInteractiveComponentSize()
                        .clip(CircleShape)
                        .clickable(onClick = onOpenTabSwitcher)
                        .testTag("tab_switcher_button")
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(22.dp)
                            .border(
                                width = 1.8.dp,
                                color = barContentColor,
                                shape = RoundedCornerShape(6.dp)
                            )
                    ) {
                        Text(
                            text = if (tabCount > 99) ":D" else tabCount.toString(),
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            ),
                            color = barContentColor,
                            textAlign = TextAlign.Center
                        )
                    }
                }

                // 3-Dot Chrome Overflow Toggle Button (tap to open, tap again to close)
                IconButton(
                    onClick = onToggleOverflowMenu,
                    modifier = Modifier
                        .size(44.dp)
                        .minimumInteractiveComponentSize()
                        .clip(CircleShape)
                        .background(
                            if (isOverflowMenuOpen) {
                                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.8f)
                            } else {
                                Color.Transparent
                            }
                        )
                        .testTag("chrome_menu_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.MoreVert,
                        contentDescription = "Browser menu",
                        tint = if (isOverflowMenuOpen) {
                            MaterialTheme.colorScheme.onPrimaryContainer
                        } else {
                            barContentColor
                        },
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }

        // Autocomplete suggestions when typing in Omnibox
        if (isFocused && textFieldValue.text.isNotBlank()) {
            OmniboxAutocompleteDropdown(
                query = textFieldValue.text,
                bookmarks = bookmarks,
                history = history,
                onSelectSuggestion = { chosen ->
                    focusManager.clearFocus()
                    isFocused = false
                    onSubmitUrl(chosen)
                }
            )
        }
    }
}

@Composable
private fun OmniboxAutocompleteDropdown(
    query: String,
    bookmarks: List<BookmarkEntity>,
    history: List<HistoryEntity>,
    onSelectSuggestion: (String) -> Unit
) {
    val q = query.trim().lowercase()
    val matches = remember(q, bookmarks, history) {
        val bookmarkHits = bookmarks
            .filter { it.title.lowercase().contains(q) || it.url.lowercase().contains(q) }
            .take(3)
            .map { Triple(it.title, it.url, true) }
        val historyHits = history
            .filter { it.title.lowercase().contains(q) || it.url.lowercase().contains(q) }
            .distinctBy { it.url }
            .filter { h -> bookmarkHits.none { it.second == h.url } }
            .take(4)
            .map { Triple(it.title, it.url, false) }
        bookmarkHits + historyHits
    }

    if (matches.isNotEmpty()) {
        Surface(
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp,
            shadowElevation = 6.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                matches.forEach { (title, url, isBookmark) ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectSuggestion(url) }
                            .padding(horizontal = 16.dp, vertical = 10.dp)
                    ) {
                        Icon(
                            imageVector = if (isBookmark) Icons.Default.Bookmark else Icons.Default.History,
                            contentDescription = null,
                            tint = if (isBookmark) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = title,
                                style = MaterialTheme.typography.bodyMedium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = url,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                }
            }
        }
    }
}

@Composable
fun ChromeOverflowMenuOverlay(
    expanded: Boolean,
    activeTab: BrowserTabModel?,
    isBookmarked: Boolean,
    isGoogleSignedIn: Boolean,
    isBatteryUnrestricted: Boolean,
    activeDownloadCount: Int,
    onDismiss: () -> Unit,
    onBack: () -> Unit,
    onForward: () -> Unit,
    onToggleBookmark: () -> Unit,
    onDownloadCurrentPage: () -> Unit,
    onSiteInfo: () -> Unit,
    onReload: () -> Unit,
    onGoogleSignIn: () -> Unit,
    onNewTab: () -> Unit,
    onNewIncognitoTab: () -> Unit,
    onOpenBookmarks: () -> Unit,
    onOpenHistory: () -> Unit,
    onOpenDownloads: () -> Unit,
    onFindInPage: () -> Unit,
    onShare: () -> Unit,
    onCopyUrl: () -> Unit,
    onPrintPdf: () -> Unit,
    onToggleDesktop: () -> Unit,
    onAddToHomeOrPwa: () -> Unit,
    onOpenInstalledPwas: () -> Unit,
    onOpenShield: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.fillMaxSize()) {
        // Subtle scrim behind the menu card so tapping outside on the page dismisses the menu
        AnimatedVisibility(
            visible = expanded,
            enter = fadeIn(animationSpec = tween(150)),
            exit = fadeOut(animationSpec = tween(120))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.24f))
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = onDismiss
                    )
                    .testTag("overflow_menu_scrim")
            )
        }

        Box(
            contentAlignment = Alignment.TopEnd,
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 6.dp, end = 8.dp, bottom = 12.dp)
        ) {
            AnimatedVisibility(
                visible = expanded,
                enter = fadeIn(animationSpec = tween(160)) +
                    expandVertically(
                        expandFrom = Alignment.Top,
                        animationSpec = spring(stiffness = Spring.StiffnessMediumLow)
                    ) +
                    scaleIn(
                        initialScale = 0.94f,
                        transformOrigin = TransformOrigin(1f, 0f),
                        animationSpec = spring(stiffness = Spring.StiffnessMediumLow)
                    ),
                exit = fadeOut(animationSpec = tween(120)) +
                    shrinkVertically(
                        shrinkTowards = Alignment.Top,
                        animationSpec = tween(130)
                    )
            ) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 6.dp,
                    shadowElevation = 10.dp,
                    border = BorderStroke(
                        width = 1.dp,
                        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f)
                    ),
                    modifier = Modifier
                        .widthIn(min = 278.dp, max = 318.dp)
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            onClick = {}
                        )
                        .testTag("chrome_overflow_menu_panel")
                ) {
                    Column(
                        modifier = Modifier
                            .verticalScroll(rememberScrollState())
                            .padding(vertical = 6.dp)
                    ) {
                        // Chrome-Style Top Quick-Action Strip (Back, Forward, Bookmark, Download Page, Site Info, Reload)
                        Row(
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 6.dp, vertical = 4.dp)
                        ) {
                            val canGoBack = activeTab?.canGoBack == true
                            IconButton(
                                onClick = {
                                    onDismiss()
                                    onBack()
                                },
                                enabled = canGoBack,
                                modifier = Modifier
                                    .size(44.dp)
                                    .minimumInteractiveComponentSize()
                                    .testTag("nav_back_button")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = stringResource(R.string.cd_nav_back),
                                    tint = if (canGoBack) {
                                        MaterialTheme.colorScheme.onSurface
                                    } else {
                                        MaterialTheme.colorScheme.onSurface.copy(alpha = 0.35f)
                                    }
                                )
                            }

                            val canGoForward = activeTab?.canGoForward == true
                            IconButton(
                                onClick = {
                                    onDismiss()
                                    onForward()
                                },
                                enabled = canGoForward,
                                modifier = Modifier
                                    .size(44.dp)
                                    .minimumInteractiveComponentSize()
                                    .testTag("nav_forward_button")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                    contentDescription = stringResource(R.string.cd_nav_forward),
                                    tint = if (canGoForward) {
                                        MaterialTheme.colorScheme.onSurface
                                    } else {
                                        MaterialTheme.colorScheme.onSurface.copy(alpha = 0.35f)
                                    }
                                )
                            }

                            IconButton(
                                onClick = {
                                    onDismiss()
                                    onToggleBookmark()
                                },
                                modifier = Modifier
                                    .size(44.dp)
                                    .minimumInteractiveComponentSize()
                                    .testTag("menu_bookmark_button")
                            ) {
                                Icon(
                                    imageVector = if (isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                                    contentDescription = "Bookmark",
                                    tint = if (isBookmarked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                )
                            }

                            IconButton(
                                onClick = {
                                    onDismiss()
                                    onDownloadCurrentPage()
                                },
                                modifier = Modifier
                                    .size(44.dp)
                                    .minimumInteractiveComponentSize()
                                    .testTag("menu_download_page_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Download,
                                    contentDescription = "Download page"
                                )
                            }

                            IconButton(
                                onClick = {
                                    onDismiss()
                                    onSiteInfo()
                                },
                                modifier = Modifier
                                    .size(44.dp)
                                    .minimumInteractiveComponentSize()
                                    .testTag("menu_site_info_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Info,
                                    contentDescription = "Site info"
                                )
                            }

                            IconButton(
                                onClick = {
                                    onDismiss()
                                    onReload()
                                },
                                modifier = Modifier
                                    .size(44.dp)
                                    .minimumInteractiveComponentSize()
                                    .testTag("menu_reload_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Reload"
                                )
                            }
                        }

                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                        // Google Account Sign-In Status Tile
                        OverflowMenuRow(
                            icon = {
                                Icon(
                                    imageVector = Icons.Default.AccountCircle,
                                    contentDescription = null,
                                    tint = if (isGoogleSignedIn) ChromeEmeraldShield else MaterialTheme.colorScheme.primary
                                )
                            },
                            title = if (isGoogleSignedIn) "Google Account Active" else "Sign in to Google",
                            subtitle = if (isGoogleSignedIn) "Tap to manage or switch account" else "Sync cookies & access AI Studio",
                            onClick = {
                                onDismiss()
                                onGoogleSignIn()
                            },
                            modifier = Modifier.testTag("menu_google_account_item")
                        )

                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                        OverflowMenuRow(
                            icon = { Icon(Icons.Default.Add, contentDescription = null) },
                            title = "New tab",
                            onClick = {
                                onDismiss()
                                onNewTab()
                            },
                            modifier = Modifier.testTag("menu_new_tab_button")
                        )
                        OverflowMenuRow(
                            icon = { Icon(Icons.Default.VisibilityOff, contentDescription = null) },
                            title = "New Incognito tab",
                            onClick = {
                                onDismiss()
                                onNewIncognitoTab()
                            },
                            modifier = Modifier.testTag("menu_incognito_tab_button")
                        )
                        OverflowMenuRow(
                            icon = { Icon(Icons.Default.History, contentDescription = null) },
                            title = "History",
                            onClick = {
                                onDismiss()
                                onOpenHistory()
                            },
                            modifier = Modifier.testTag("menu_history_button")
                        )
                        OverflowMenuRow(
                            icon = { Icon(Icons.Default.Download, contentDescription = null) },
                            title = "Downloads",
                            trailing = {
                                if (activeDownloadCount > 0) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(MaterialTheme.colorScheme.primaryContainer)
                                            .padding(horizontal = 7.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = activeDownloadCount.toString(),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer
                                        )
                                    }
                                }
                            },
                            onClick = {
                                onDismiss()
                                onOpenDownloads()
                            },
                            modifier = Modifier.testTag("menu_downloads_button")
                        )
                        OverflowMenuRow(
                            icon = { Icon(Icons.Default.Bookmark, contentDescription = null) },
                            title = "Bookmarks",
                            onClick = {
                                onDismiss()
                                onOpenBookmarks()
                            },
                            modifier = Modifier.testTag("menu_bookmarks_button")
                        )

                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                        OverflowMenuRow(
                            icon = { Icon(Icons.Default.FindInPage, contentDescription = null) },
                            title = "Find in page",
                            onClick = {
                                onDismiss()
                                onFindInPage()
                            },
                            modifier = Modifier.testTag("menu_find_in_page_button")
                        )
                        OverflowMenuRow(
                            icon = { Icon(Icons.Default.Share, contentDescription = null) },
                            title = "Share...",
                            onClick = {
                                onDismiss()
                                onShare()
                            },
                            modifier = Modifier.testTag("menu_share_button")
                        )
                        OverflowMenuRow(
                            icon = { Icon(Icons.Default.ContentCopy, contentDescription = null) },
                            title = "Copy link",
                            onClick = {
                                onDismiss()
                                onCopyUrl()
                            },
                            modifier = Modifier.testTag("menu_copy_link_button")
                        )
                        OverflowMenuRow(
                            icon = { Icon(Icons.Default.Print, contentDescription = null) },
                            title = "Print / Save as PDF",
                            onClick = {
                                onDismiss()
                                onPrintPdf()
                            },
                            modifier = Modifier.testTag("menu_print_pdf_button")
                        )
                        OverflowMenuRow(
                            icon = { Icon(Icons.Default.DesktopWindows, contentDescription = null) },
                            title = "Desktop site",
                            trailing = {
                                Checkbox(
                                    checked = activeTab?.isDesktopMode == true,
                                    onCheckedChange = null
                                )
                            },
                            onClick = {
                                onDismiss()
                                onToggleDesktop()
                            },
                            modifier = Modifier.testTag("menu_desktop_site_button")
                        )

                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                        OverflowMenuRow(
                            icon = {
                                Icon(
                                    imageVector = Icons.Default.AddToHomeScreen,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            },
                            title = "Add to Home screen / PWA",
                            subtitle = "Create shortcut or separate PWA app",
                            onClick = {
                                onDismiss()
                                onAddToHomeOrPwa()
                            },
                            modifier = Modifier.testTag("menu_add_pwa_button")
                        )
                        OverflowMenuRow(
                            icon = { Icon(Icons.Default.Apps, contentDescription = null) },
                            title = "Installed PWAs & Apps",
                            onClick = {
                                onDismiss()
                                onOpenInstalledPwas()
                            },
                            modifier = Modifier.testTag("menu_installed_pwas_button")
                        )

                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                        OverflowMenuRow(
                            icon = {
                                Icon(
                                    imageVector = Icons.Default.Shield,
                                    contentDescription = null,
                                    tint = if (isBatteryUnrestricted) ChromeEmeraldShield else ChromeAmberWarn
                                )
                            },
                            title = if (isBatteryUnrestricted) "Background Shield (Max)" else "Anti-Kill Battery Shield",
                            onClick = {
                                onDismiss()
                                onOpenShield()
                            },
                            modifier = Modifier.testTag("menu_shield_button")
                        )
                        OverflowMenuRow(
                            icon = { Icon(Icons.Default.Settings, contentDescription = null) },
                            title = "Settings",
                            onClick = {
                                onDismiss()
                                onOpenSettings()
                            },
                            modifier = Modifier.testTag("menu_settings_button")
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun OverflowMenuRow(
    icon: @Composable () -> Unit,
    title: String,
    subtitle: String? = null,
    trailing: (@Composable () -> Unit)? = null,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = if (subtitle != null) 10.dp else 11.dp)
    ) {
        icon()
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge.copy(
                    fontWeight = if (subtitle != null) FontWeight.Medium else FontWeight.Normal,
                    fontSize = 15.sp
                ),
                color = MaterialTheme.colorScheme.onSurface
            )
            if (subtitle != null) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        if (trailing != null) {
            Spacer(modifier = Modifier.width(8.dp))
            trailing()
        }
    }
}

@Composable
fun CompactTabStripBar(
    tabs: List<BrowserTabModel>,
    activeTabId: Int,
    onSelectTab: (Int) -> Unit,
    onCloseTab: (Int) -> Unit,
    onAddTab: () -> Unit
) {
    val scrollState = rememberScrollState()
    Surface(
        color = MaterialTheme.colorScheme.background,
        tonalElevation = 1.dp,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("compact_tab_strip_bar")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 6.dp, vertical = 4.dp)
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                modifier = Modifier
                    .weight(1f)
                    .horizontalScroll(scrollState)
            ) {
                tabs.forEach { tab ->
                    val selected = tab.id == activeTabId
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .height(34.dp)
                            .widthIn(min = 110.dp, max = 165.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                if (selected) MaterialTheme.colorScheme.surfaceVariant
                                else Color.Transparent
                            )
                            .clickable { onSelectTab(tab.id) }
                            .padding(start = 8.dp, end = 4.dp)
                    ) {
                        val bmp = tab.favicon
                        if (bmp != null) {
                            Image(
                                bitmap = bmp.asImageBitmap(),
                                contentDescription = null,
                                modifier = Modifier
                                    .size(14.dp)
                                    .clip(RoundedCornerShape(3.dp))
                            )
                        } else {
                            Icon(
                                imageVector = if (tab.isIncognito) Icons.Default.VisibilityOff else Icons.Default.Public,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = tab.pageTitle,
                            style = MaterialTheme.typography.labelMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = { onCloseTab(tab.id) },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close tab",
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
            }
            IconButton(
                onClick = onAddTab,
                modifier = Modifier.size(34.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "New tab",
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
fun IsolatedSlimProgressBar(webViewManager: WebViewManager) {
    val progress by webViewManager.activeTabProgress.collectAsStateWithLifecycle()
    val isLoading by webViewManager.activeTabIsLoading.collectAsStateWithLifecycle()

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(2.5.dp)
            .background(MaterialTheme.colorScheme.surface)
    ) {
        AnimatedVisibility(
            visible = isLoading && progress in 1..99,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            LinearProgressIndicator(
                progress = { (progress / 100f).coerceIn(0.02f, 1f) },
                color = MaterialTheme.colorScheme.primary,
                trackColor = Color.Transparent,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(2.5.dp)
                    .testTag("slim_progress_bar")
            )
        }
    }
}

@Composable
fun FindInPageBar(
    state: FindInPageState,
    onQueryChange: (String) -> Unit,
    onFindPrev: () -> Unit,
    onFindNext: () -> Unit,
    onClose: () -> Unit
) {
    if (!state.isVisible) return

    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        tonalElevation = 6.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Search,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            BasicTextField(
                value = state.query,
                onValueChange = onQueryChange,
                singleLine = true,
                textStyle = TextStyle(
                    color = MaterialTheme.colorScheme.onSurface,
                    fontSize = 14.sp
                ),
                cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                modifier = Modifier
                    .weight(1f)
                    .testTag("find_in_page_input")
            )
            if (state.query.isNotEmpty()) {
                Text(
                    text = "${state.activeMatchIndex}/${state.totalMatches}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 8.dp)
                )
            }
            IconButton(onClick = onFindPrev, modifier = Modifier.size(40.dp)) {
                Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Previous match")
            }
            IconButton(onClick = onFindNext, modifier = Modifier.size(40.dp)) {
                Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Next match")
            }
            IconButton(
                onClick = onClose,
                modifier = Modifier
                    .size(40.dp)
                    .testTag("find_in_page_close")
            ) {
                Icon(Icons.Default.Close, contentDescription = "Close find bar")
            }
        }
    }
}



private fun formatCompactDisplayUrl(url: String): String {
    return try {
        val stripped = url.removePrefix("https://").removePrefix("http://").removePrefix("www.")
        if (stripped.length > 36) stripped.take(36) + "…" else stripped.trimEnd('/')
    } catch (_: Exception) {
        url
    }
}
