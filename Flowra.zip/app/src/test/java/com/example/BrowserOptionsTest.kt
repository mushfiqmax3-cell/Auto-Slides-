package com.example

import android.content.Context
import android.view.View
import android.view.WindowManager
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.test.core.app.ApplicationProvider
import com.example.data.BrowserDatabase
import com.example.data.BrowserPreferences
import com.example.data.BrowserRepository
import com.example.data.FrameRateMode
import com.example.data.HomepageMode
import com.example.data.SearchEngine
import com.example.data.ThemeMode
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class BrowserOptionsTest {

    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun `verify 60 fps frame rate mode and all BrowserPreferences options persist`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val prefs = BrowserPreferences(context)

        // Default frame rate mode should be SMOOTH_60
        val initial = prefs.settingsFlow.first()
        assertEquals(FrameRateMode.SMOOTH_60, initial.frameRateMode)
        assertEquals(60f, initial.frameRateMode.targetFps, 0.01f)

        // Test toggling all preference options
        prefs.setFrameRateMode(FrameRateMode.ADAPTIVE_MAX)
        prefs.setSearchEngine(SearchEngine.DUCKDUCKGO)
        prefs.setThemeMode(ThemeMode.DARK)
        prefs.setHomepageMode(HomepageMode.GOOGLE_AI_STUDIO)
        prefs.setShowTabStrip(true)
        prefs.setAskBeforeDownload(false)
        prefs.setAdBlockEnabled(false)
        prefs.setJavaScriptEnabled(false)
        prefs.setDarkWebPages(true)
        prefs.setKeepPwasAliveInRam(false)
        prefs.setTextZoomPercent(135)
        prefs.setDownloadDestination(DownloadFolderPreset.STUDIO_DOWNLOADS.name)

        val updated = prefs.settingsFlow.first()
        assertEquals(FrameRateMode.ADAPTIVE_MAX, updated.frameRateMode)
        assertEquals(SearchEngine.DUCKDUCKGO, updated.searchEngine)
        assertEquals(ThemeMode.DARK, updated.themeMode)
        assertEquals(HomepageMode.GOOGLE_AI_STUDIO, updated.homepageMode)
        assertTrue(updated.showTabStrip)
        assertFalse(updated.askBeforeDownload)
        assertFalse(updated.adBlockEnabled)
        assertFalse(updated.javaScriptEnabled)
        assertTrue(updated.darkWebPages)
        assertFalse(updated.keepPwasAliveInRam)
        assertEquals(135, updated.textZoomPercent)
        assertEquals(DownloadFolderPreset.STUDIO_DOWNLOADS.name, updated.downloadFolderPreset)

        // Verify zoom clamping bounds (75..160)
        prefs.setTextZoomPercent(300)
        assertEquals(160, prefs.settingsFlow.first().textZoomPercent)

        // Restore defaults cleanly
        prefs.setFrameRateMode(FrameRateMode.SMOOTH_60)
        prefs.setSearchEngine(SearchEngine.GOOGLE)
        prefs.setThemeMode(ThemeMode.SYSTEM)
        prefs.setHomepageMode(HomepageMode.CHROME_START_PAGE)
        prefs.setShowTabStrip(false)
        prefs.setAskBeforeDownload(true)
        prefs.setAdBlockEnabled(true)
        prefs.setJavaScriptEnabled(true)
        prefs.setDarkWebPages(false)
        prefs.setKeepPwasAliveInRam(true)
        prefs.setTextZoomPercent(100)
        prefs.setDownloadDestination(DownloadFolderPreset.DOWNLOADS.name)

        // Verify all SearchEngine URL templates
        SearchEngine.entries.forEach { engine ->
            val built = engine.buildSearchUrl("compose 60fps")
            assertTrue(built.startsWith(engine.searchUrlTemplate))
            assertTrue(built.contains("compose"))
        }
    }

    @Test
    fun `verify WebViewManager tab switching, desktop mode, find in page, download prompt, and 60fps pipeline`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val manager = WebViewManager.getInstance(context)
        manager.resetToDefaultFiveTabs()

        // Verify Window frame pacing keeps screen awake cleanly on MainActivity
        FramePacingHelper.applyWindowFramePacing(composeRule.activity, FrameRateMode.SMOOTH_60)
        val flags = composeRule.activity.window.attributes.flags
        assertTrue((flags and WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) != 0)

        val tabs = manager.tabsState.value
        assertEquals(5, tabs.size)
        val firstTabId = tabs[0].id
        val secondTabId = tabs[1].id

        // Verify lightweight 60fps anti-throttle JS has no heavy MutationObserver
        assertFalse(WebViewManager.PAGE_VISIBILITY_OVERRIDE_JS.contains("MutationObserver"))
        assertTrue(WebViewManager.PAGE_VISIBILITY_OVERRIDE_JS.contains("loadstart"))

        // Tab delta navigation
        assertEquals(firstTabId, manager.activeTabId.value)
        manager.switchTabByDelta(1)
        assertEquals(secondTabId, manager.activeTabId.value)
        manager.switchTabByDelta(-1)
        assertEquals(firstTabId, manager.activeTabId.value)

        // Desktop mode toggle
        assertFalse(manager.tabsState.value.first { it.id == firstTabId }.isDesktopMode)
        manager.toggleDesktopModeForActiveTab()
        assertTrue(manager.tabsState.value.first { it.id == firstTabId }.isDesktopMode)
        manager.toggleDesktopModeForActiveTab()
        assertFalse(manager.tabsState.value.first { it.id == firstTabId }.isDesktopMode)

        // Find in page state lifecycle
        manager.showFindInPage()
        assertTrue(manager.findInPageState.value.isVisible)
        manager.updateFindQuery("Gemini")
        assertEquals("Gemini", manager.findInPageState.value.query)
        manager.clearFindInPage()
        assertFalse(manager.findInPageState.value.isVisible)
        assertEquals("", manager.findInPageState.value.query)

        // Download prompt & dismiss
        manager.preferences.setAskBeforeDownload(true)
        manager.triggerDirectDownload("https://example.com/model.bin", "application/octet-stream")
        assertNotNull(manager.pendingDownload.value)
        assertEquals("model.bin", manager.pendingDownload.value?.suggestedFileName)
        manager.dismissPendingDownload()
        assertNull(manager.pendingDownload.value)

        // about:blank & about:newtab normalization
        assertEquals("about:blank", manager.normalizeUrlOrSearchQuery("about:blank"))
        assertEquals(WebViewManager.NEW_TAB_URL, manager.normalizeUrlOrSearchQuery(WebViewManager.NEW_TAB_URL))

        // Verify all 5 WebViews remain View.VISIBLE and LAYER_TYPE_NONE for smooth HWUI rendering
        for (i in 0 until manager.persistentContainer.childCount) {
            val child = manager.persistentContainer.getChildAt(i)
            assertEquals(View.VISIBLE, child.visibility)
            assertEquals(View.LAYER_TYPE_NONE, child.layerType)
        }
    }

    @Test
    fun `verify Overflow Menu, Settings 60fps picker, and all Settings toggles`() {
        composeRule.waitForIdle()

        // 1. Verify Top Toolbar essentials
        composeRule.onNodeWithTag("nav_home_button").assertIsDisplayed()
        composeRule.onNodeWithTag("omnibox_input").assertIsDisplayed()
        composeRule.onNodeWithTag("tab_switcher_button").assertIsDisplayed()
        composeRule.onNodeWithTag("chrome_menu_button").assertIsDisplayed()

        // 2. Open Overflow Menu & verify all menu options exist
        composeRule.onNodeWithTag("chrome_menu_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("chrome_overflow_menu_panel").assertIsDisplayed()
        composeRule.onNodeWithTag("menu_new_tab_button").assertIsDisplayed()
        composeRule.onNodeWithTag("menu_incognito_tab_button").assertIsDisplayed()
        composeRule.onNodeWithTag("menu_history_button").assertIsDisplayed()
        composeRule.onNodeWithTag("menu_downloads_button").assertIsDisplayed()
        composeRule.onNodeWithTag("menu_bookmarks_button").assertIsDisplayed()

        // Scrollable lower menu items
        composeRule.onNodeWithTag("menu_find_in_page_button").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("menu_share_button").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("menu_copy_link_button").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("menu_print_pdf_button").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("menu_desktop_site_button").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("menu_add_pwa_button").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("menu_installed_pwas_button").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("menu_shield_button").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("menu_settings_button").performScrollTo().assertIsDisplayed()

        // 3. Open Settings & test Frame Rate 60 FPS picker
        composeRule.onNodeWithTag("menu_settings_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Settings").assertIsDisplayed()
        composeRule.onNodeWithTag("settings_frame_rate_row").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("settings_frame_rate_row").performClick()
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("frame_rate_option_ADAPTIVE_MAX").assertIsDisplayed()
        composeRule.onNodeWithTag("frame_rate_option_SMOOTH_60").assertIsDisplayed()
        // Switch to Adaptive Max then back to Smooth 60 FPS
        composeRule.onNodeWithTag("frame_rate_option_ADAPTIVE_MAX").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Adaptive Max Hz (90-120 FPS)").assertIsDisplayed()

        composeRule.onNodeWithTag("settings_frame_rate_row").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("frame_rate_option_SMOOTH_60").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Smooth 60 FPS (Consistent)").assertIsDisplayed()

        // 4. Verify remaining Settings switches and toggle Top Tab Strip ON -> check outside dialog -> restore OFF
        composeRule.onNodeWithTag("settings_ask_download_row").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("settings_ad_block_row").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("settings_javascript_row").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("settings_dark_web_row").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("settings_keep_pwas_alive_row").performScrollTo().assertIsDisplayed()

        composeRule.onNodeWithTag("settings_show_tab_strip_row").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithContentDescription("Close settings").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("compact_tab_strip_bar").assertIsDisplayed()

        // Restore Top Tab Strip OFF cleanly
        composeRule.onNodeWithTag("chrome_menu_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("menu_settings_button").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("settings_show_tab_strip_row").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithContentDescription("Close settings").performClick()
        composeRule.waitForIdle()
    }

    @Test
    fun `verify Start Page, Shield, PWA Creator, Installed PWAs, Site Info, Incognito, History, Downloads, and Bookmarks`() {
        composeRule.waitForIdle()

        // 1. Open Tab Switcher & switch to a New Tab (Start Page)
        composeRule.onNodeWithTag("tab_switcher_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("New tab").assertIsDisplayed().performClick()
        composeRule.waitForIdle()

        // Start Page (ChromeNewTabPage) visible with smooth 60fps Speed Dial
        composeRule.onNodeWithTag("ntp_google_chip").assertIsDisplayed()
        composeRule.onNodeWithTag("ntp_shield_chip").assertIsDisplayed()
        composeRule.onNodeWithTag("ntp_search_input").assertIsDisplayed()
        composeRule.onNodeWithText("AI Studio").assertIsDisplayed()

        // 2. Open Battery Shield from Start Page chip & verify 60 FPS telemetry
        composeRule.onNodeWithTag("ntp_shield_chip").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("60 FPS Pre-Raster & Frame Pacing").assertIsDisplayed()
        composeRule.onNodeWithText("SMOOTH ACTIVE").assertIsDisplayed()
        composeRule.onNodeWithText("Done").performScrollTo().performClick()
        composeRule.waitForIdle()

        // 3. Open PWA / Shortcut Creator from Start Page
        composeRule.onNodeWithTag("ntp_add_pwa_button").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("mode_pwa_card").assertIsDisplayed()
        composeRule.onNodeWithTag("mode_shortcut_card").assertIsDisplayed()
        composeRule.onNodeWithTag("pwa_name_input").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("pin_to_home_button").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("create_and_open_pwa_button").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithText("Cancel").performScrollTo().performClick()
        composeRule.waitForIdle()

        // 4. Open Find in Page from Overflow Menu and close it
        composeRule.onNodeWithTag("chrome_menu_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("menu_find_in_page_button").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("find_in_page_input").assertIsDisplayed()
        composeRule.onNodeWithTag("find_in_page_close").performClick()
        composeRule.waitForIdle()

        // 5. Open Site Info Dialog from Overflow Menu & test Desktop site mode toggle
        composeRule.onNodeWithTag("chrome_menu_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("menu_site_info_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Desktop site mode").assertIsDisplayed()
        composeRule.onNodeWithText("Clear cookies & site storage").assertIsDisplayed()
        composeRule.onNodeWithText("Desktop site mode").performClick()
        composeRule.waitForIdle()

        // 6. Open Installed PWAs & Apps Sheet
        composeRule.onNodeWithTag("chrome_menu_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("menu_installed_pwas_button").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Installed PWAs & Shortcuts").assertIsDisplayed()
        composeRule.onNodeWithContentDescription("Close PWAs list").performClick()
        composeRule.waitForIdle()

        // 7. Open Downloads Sheet & verify filter chips
        composeRule.onNodeWithTag("chrome_menu_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("menu_downloads_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Downloads").assertIsDisplayed()
        composeRule.onNodeWithText("Active").performClick()
        composeRule.onNodeWithText("Completed").performClick()
        composeRule.onNodeWithText("All").performClick()
        composeRule.onNodeWithContentDescription("Close downloads").performClick()
        composeRule.waitForIdle()

        // 8. Open History Sheet & Clear Browsing Data Dialog
        composeRule.onNodeWithTag("chrome_menu_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("menu_history_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("History").assertIsDisplayed()
        composeRule.onNodeWithText("Clear data...").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Clear browsing data").assertIsDisplayed()
        composeRule.onNodeWithText("Cancel").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithContentDescription("Close history").performClick()
        composeRule.waitForIdle()

        // 9. Open Bookmarks Sheet & verify starter offline bookmarks
        composeRule.onNodeWithTag("chrome_menu_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("menu_bookmarks_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Bookmarks").assertIsDisplayed()
        composeRule.onAllNodesWithText("AI Studio")[0].assertIsDisplayed()
        composeRule.onNodeWithContentDescription("Close bookmarks").performClick()
        composeRule.waitForIdle()

        // 10. Open Incognito Tab & verify Incognito Landing Page
        composeRule.onNodeWithTag("chrome_menu_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("menu_incognito_tab_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("You've gone Incognito").assertIsDisplayed()

        // Reset tabs back to default 5 tabs so repository state stays clean
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = BrowserRepository(BrowserDatabase.getInstance(context))
        runBlocking {
            assertTrue(repo.allBookmarks.first().isNotEmpty())
            WebViewManager.getInstance(context).resetToDefaultFiveTabs()
        }
    }
}
