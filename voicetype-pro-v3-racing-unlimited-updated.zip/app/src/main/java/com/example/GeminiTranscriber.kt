package com.example

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

data class TranscriptionResponse(
    val text: String,
    val modelUsed: String,
    val usedFallbackModel: Boolean
)

sealed class TranscriptionException(message: String) : Exception(message) {
    class NoInternet : TranscriptionException("No internet connection. Please check your network.")
    class InvalidApiKey : TranscriptionException("Invalid Gemini API key. Check your key in VoiceType Pro.")
    class QuotaExceeded : TranscriptionException("Quota exceeded (429). Please wait a moment and try again.")
    class ServiceUnavailable : TranscriptionException("Gemini is temporarily unavailable (503). Please try again.")
    class EmptyResult : TranscriptionException("No speech detected (কোনো কথা শনাক্ত হয়নি).")
    class ModelNotFound(model: String) : TranscriptionException("Model '$model' not available (404). Change the model in VoiceType Pro settings.")
    class ApiError(msg: String) : TranscriptionException(msg)
}

/**
 * Handles inline base64 audio transcription with the Gemini API over OkHttp + Coroutines.
 * Uses official Google Generative Language REST API camelCase keys ("inlineData", "mimeType")
 * and defaults to "gemini-1.5-flash" (low latency), rotating across all stored API keys on 429 / 503.
 */
object GeminiTranscriber {
    /** Persona + hard transcription rules, sent as the Gemini system instruction and at the top of the prompt. */
    const val VERBATIM_SYSTEM_INSTRUCTION =
        "You are an expert Bangladeshi Bengali Voice Typing Engine.\n" +
        "The speaker is from Bangladesh, speaking natural Bengali. The speech may contain regional dialects " +
        "from across Bangladesh, with a primary focus on the Northern/Naogaon/Rajshahi (বরেন্দ্রী) dialect, " +
        "as well as code-mixed English words.\n\n" +
        "MANDATORY TRANSCRIPTION RULES:\n" +
        "1. PRIMARY SCRIPT: Always output text in Bengali script (বাংলা লিপি).\n" +
        "2. DIALECT HANDLING: Fully comprehend and accurately transcribe Bangladeshi regional colloquialisms " +
        "and vocabulary (especially Naogaon/Rajshahi and other districts such as Chattogram, Sylhet, Noakhali, " +
        "Barishal, Rangpur and Dhaka) directly into standard Bengali script.\n" +
        "3. CODE-MIXING (ENGLISH WORDS): When English terms are spoken, either transliterate them phonetically " +
        "into Bengali script (e.g., 'অ্যাপ', 'মোবাইল', 'টাইম') or write standard English words. " +
        "Do not let English words turn the entire sentence into Roman script.\n" +
        "4. STRICT NEGATIVE RESTRICTIONS:\n" +
        "   - NEVER use Hindi or Devanagari script under any circumstances.\n" +
        "   - NEVER output Banglish / Romanized Bengali (e.g., 'ami bhalo achi').\n" +
        "5. OUTPUT ONLY: Return only the exact transcribed speech. No markdown fences, no quotes, " +
        "no conversational filler, no explanations, no preambles " +
        "(e.g., do NOT output 'Here is the transcription:', 'Sure:', 'You said:')."

    const val TRANSCRIPTION_PROMPT =
        VERBATIM_SYSTEM_INSTRUCTION + "\n\n" +
        "Transcribe everything spoken in the attached audio verbatim, following the rules above. " +
        "Capture every audible word even if the voice is soft, quiet or fast. " +
        "Add natural sentence punctuation (।, ?, !, .). " +
        "Return ONLY the transcribed text."

    /** Deterministic decoding: no sampling randomness, so no creative script hallucination. */
    const val GENERATION_TEMPERATURE = 0.0
    const val GENERATION_TOP_P = 0.1
    const val GENERATION_TOP_K = 1

    private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()

    internal val okHttpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()
    }

    @Volatile
    private var activeCall: Call? = null

    /**
     * Cancels any in-flight OkHttp network request immediately.
     */
    fun cancelActiveRequest() {
        try {
            activeCall?.cancel()
        } catch (_: Exception) {
        } finally {
            activeCall = null
        }
    }

    /**
     * Reads the closed and flushed audio file safely into a byte array.
     */
    private fun readClosedAudioBytes(audioFile: File): ByteArray {
        FileInputStream(audioFile).use { fis ->
            return fis.readBytes()
        }
    }

    /**
     * Detects the MIME type from the audio file header or extension ("audio/wav" or "audio/mp4").
     */
    fun detectAudioMimeType(audioFile: File, bytes: ByteArray): String {
        if (bytes.size >= 12 &&
            bytes[0] == 'R'.code.toByte() &&
            bytes[1] == 'I'.code.toByte() &&
            bytes[2] == 'F'.code.toByte() &&
            bytes[3] == 'F'.code.toByte()
        ) {
            return "audio/wav"
        }
        return if (audioFile.extension.equals("wav", ignoreCase = true)) {
            "audio/wav"
        } else {
            "audio/mp4"
        }
    }

    /**
     * Sends the recorded audio file inline (Base64) to Gemini and returns the trimmed transcription.
     * Always deletes [audioFile] in the finally block (success, failure, or cancellation).
     */
    suspend fun transcribeAudio(
        audioFile: File,
        apiKey: String,
        configuredModel: String = Prefs.DEFAULT_MODEL_NAME,
        appPackage: String? = null
    ): Result<TranscriptionResponse> = withContext(Dispatchers.IO) {
        try {
            val keysToTry = keysForAttempt(apiKey)
            if (keysToTry.isEmpty()) {
                return@withContext Result.failure(TranscriptionException.InvalidApiKey())
            }
            if (!audioFile.exists() || audioFile.length() <= 44L) {
                return@withContext Result.failure(TranscriptionException.EmptyResult())
            }

            val audioBytes = readClosedAudioBytes(audioFile)
            if (audioBytes.size <= 44) {
                return@withContext Result.failure(TranscriptionException.EmptyResult())
            }

            val mimeType = detectAudioMimeType(audioFile, audioBytes)
            val base64Audio = Base64.encodeToString(audioBytes, Base64.NO_WRAP)
            val requestBodyJson = buildTranscriptionJson(
                base64Audio,
                mimeType,
                buildPrompt(appPackage)
            )

            val primaryModel = configuredModel.trim().ifEmpty { Prefs.DEFAULT_MODEL_NAME }

            // Round-robin failover: the first key is the next one in rotation; on 429 / 503 /
            // rate-limit (or a rejected key) we immediately retry with the NEXT key, at most
            // once per stored key, before reporting failure.
            var lastFailure: TranscriptionException? = null
            for (key in keysToTry) {
                val outcome = executeWithModelFallback(primaryModel, key, requestBodyJson)
                val attempt = outcome.attempt

                if (attempt.isModelNotFound) {
                    // Model problem, not a key problem: another key would fail the same way.
                    return@withContext Result.failure(TranscriptionException.ModelNotFound(outcome.modelUsed))
                }
                val failure = attempt.exception
                if (failure != null) {
                    if (attempt.retryWithNextKey) {
                        lastFailure = failure
                        continue
                    }
                    return@withContext Result.failure(failure)
                }

                val text = cleanExtractedTranscript(attempt.extractedText.orEmpty())
                if (text.isEmpty()) {
                    return@withContext Result.failure(TranscriptionException.EmptyResult())
                }
                return@withContext Result.success(
                    TranscriptionResponse(
                        text = text,
                        modelUsed = outcome.modelUsed,
                        usedFallbackModel = outcome.modelUsed != primaryModel
                    )
                )
            }
            Result.failure(lastFailure ?: TranscriptionException.QuotaExceeded())
        } catch (e: kotlinx.coroutines.CancellationException) {
            cancelActiveRequest()
            throw e
        } catch (e: UnknownHostException) {
            Result.failure(TranscriptionException.NoInternet())
        } catch (e: SocketTimeoutException) {
            Result.failure(TranscriptionException.ApiError("Connection timed out. Please try again."))
        } catch (e: IOException) {
            Result.failure(TranscriptionException.NoInternet())
        } catch (e: Exception) {
            Result.failure(TranscriptionException.ApiError(e.localizedMessage ?: "Transcription failed."))
        } finally {
            activeCall = null
            try {
                if (audioFile.exists()) {
                    audioFile.delete()
                }
            } catch (_: Exception) {
            }
        }
    }

    /**
     * Keys for one transcription, in attempt order: starts at the next key in the round-robin
     * rotation and wraps around the whole list so each key is tried at most once.
     * Falls back to [provided] only when no keys are stored.
     */
    private fun keysForAttempt(provided: String): List<String> {
        val all = Prefs.getApiKeys()
        if (all.isEmpty()) {
            return listOfNotNull(provided.trim().takeIf { it.isNotEmpty() })
        }
        val first = Prefs.getNextApiKey() ?: return all
        val start = all.indexOf(first).coerceAtLeast(0)
        return all.drop(start) + all.take(start)
    }

    private data class ModelOutcome(val attempt: RawApiAttempt, val modelUsed: String)

    /** Models that returned 404 and the fallback that replaced them, so we don't pay a 404 round-trip every time. */
    private val modelRedirects = ConcurrentHashMap<String, String>()

    private suspend fun executeWithModelFallback(
        primaryModel: String,
        apiKey: String,
        bodyJson: String
    ): ModelOutcome {
        val effective = modelRedirects[primaryModel] ?: primaryModel
        val first = executeGenerateContent(effective, apiKey, bodyJson)
        if (!first.isModelNotFound || effective == Prefs.FALLBACK_MODEL_NAME) {
            return ModelOutcome(first, effective)
        }
        val second = executeGenerateContent(Prefs.FALLBACK_MODEL_NAME, apiKey, bodyJson)
        if (!second.isModelNotFound && second.exception?.let { !isRetryable(it) } != false) {
            // Fallback model exists: remember it for this process.
            modelRedirects[primaryModel] = Prefs.FALLBACK_MODEL_NAME
        }
        return ModelOutcome(second, Prefs.FALLBACK_MODEL_NAME)
    }

    private fun isRetryable(e: TranscriptionException): Boolean =
        e is TranscriptionException.QuotaExceeded ||
            e is TranscriptionException.ServiceUnavailable ||
            e is TranscriptionException.InvalidApiKey

    /**
     * Makes a tiny test request to validate the user's API key and model configuration.
     */
    suspend fun testApiKey(
        apiKey: String,
        configuredModel: String = Prefs.DEFAULT_MODEL_NAME
    ): Result<TranscriptionResponse> = withContext(Dispatchers.IO) {
        try {
            val cleanKey = apiKey.trim()
            if (cleanKey.isEmpty()) {
                return@withContext Result.failure(TranscriptionException.InvalidApiKey())
            }

            val testJson = JSONObject().apply {
                val part = JSONObject().put("text", "Reply with OK")
                val parts = JSONArray().put(part)
                val content = JSONObject().put("parts", parts)
                put("contents", JSONArray().put(content))
                put("generationConfig", JSONObject().put("temperature", 0))
            }.toString()

            val primaryModel = configuredModel.trim().ifEmpty { Prefs.DEFAULT_MODEL_NAME }
            val primaryAttempt = executeGenerateContent(
                model = primaryModel,
                apiKey = cleanKey,
                bodyJson = testJson
            )

            if (primaryAttempt.isModelNotFound && primaryModel != Prefs.FALLBACK_MODEL_NAME) {
                val fallbackAttempt = executeGenerateContent(
                    model = Prefs.FALLBACK_MODEL_NAME,
                    apiKey = cleanKey,
                    bodyJson = testJson
                )
                if (fallbackAttempt.exception != null) {
                    return@withContext Result.failure(fallbackAttempt.exception)
                }
                return@withContext Result.success(
                    TranscriptionResponse(
                        text = fallbackAttempt.extractedText.orEmpty().trim().ifEmpty { "OK" },
                        modelUsed = Prefs.FALLBACK_MODEL_NAME,
                        usedFallbackModel = true
                    )
                )
            }

            if (primaryAttempt.exception != null) {
                return@withContext Result.failure(primaryAttempt.exception)
            }

            Result.success(
                TranscriptionResponse(
                    text = primaryAttempt.extractedText.orEmpty().trim().ifEmpty { "OK" },
                    modelUsed = primaryModel,
                    usedFallbackModel = false
                )
            )
        } catch (e: UnknownHostException) {
            Result.failure(TranscriptionException.NoInternet())
        } catch (e: SocketTimeoutException) {
            Result.failure(TranscriptionException.ApiError("Request timed out."))
        } catch (e: IOException) {
            Result.failure(TranscriptionException.NoInternet())
        } catch (e: Exception) {
            Result.failure(TranscriptionException.ApiError(e.localizedMessage ?: "Validation failed."))
        }
    }

    /**
     * Builds the official Google Generative Language REST API JSON payload using camelCase keys:
     * parts: [ { "inlineData": { "mimeType": mimeType, "data": base64Audio } }, { "text": TRANSCRIPTION_PROMPT } ]
     */
    fun buildTranscriptionJson(
        base64Audio: String,
        mimeType: String = "audio/wav",
        prompt: String = TRANSCRIPTION_PROMPT
    ): String {
        val inlineData = JSONObject().apply {
            put("mimeType", mimeType)
            put("data", base64Audio)
        }
        val audioPart = JSONObject().apply {
            put("inlineData", inlineData)
        }
        val textPart = JSONObject().apply {
            put("text", prompt)
        }
        val partsArray = JSONArray().apply {
            put(audioPart)
            put(textPart)
        }
        val contentObj = JSONObject().apply {
            put("role", "user")
            put("parts", partsArray)
        }
        val contentsArray = JSONArray().apply {
            put(contentObj)
        }
        val generationConfig = JSONObject().apply {
            put("temperature", GENERATION_TEMPERATURE)
            put("topP", GENERATION_TOP_P)
            put("topK", GENERATION_TOP_K)
        }
        val systemInstruction = JSONObject().apply {
            put("parts", JSONArray().put(JSONObject().put("text", VERBATIM_SYSTEM_INSTRUCTION)))
        }
        return JSONObject().apply {
            put("systemInstruction", systemInstruction)
            put("contents", contentsArray)
            put("generationConfig", generationConfig)
        }.toString()
    }

    // ---------------------------------------------------------------------------------------
    // App-aware tone
    // ---------------------------------------------------------------------------------------

    private val FORMAL_EMAIL_APPS = setOf(
        "com.google.android.gm",
        "com.microsoft.office.outlook",
        "com.yahoo.mobile.client.android.mail",
        "ch.protonmail.android",
        "com.samsung.android.email.provider"
    )
    private val CASUAL_CHAT_APPS = setOf(
        "com.whatsapp",
        "com.whatsapp.w4b",
        "org.telegram.messenger",
        "org.thoughtcrime.securesms",
        "com.facebook.orca",
        "com.facebook.katana",
        "com.instagram.android",
        "com.discord",
        "com.snapchat.android",
        "com.google.android.apps.messaging",
        "com.samsung.android.messaging",
        "com.viber.voip",
        "jp.naver.line.android"
    )
    private val WORK_CHAT_APPS = setOf(
        "com.slack",
        "com.microsoft.teams",
        "com.google.android.apps.dynamite"
    )
    private val DOCUMENT_APPS = setOf(
        "com.google.android.keep",
        "com.google.android.apps.docs.editors.docs",
        "com.microsoft.office.word",
        "com.microsoft.office.onenote",
        "notion.id",
        "md.obsidian"
    )

    /**
     * Returns a one-line tone instruction for the app the user is typing into,
     * or null when no special tone applies.
     */
    fun toneInstructionFor(appPackage: String?): String? {
        val pkg = appPackage?.trim().orEmpty()
        return when {
            pkg.isEmpty() -> null
            pkg in FORMAL_EMAIL_APPS ->
                "The text is for an EMAIL. Use a polite, formal, professional tone with complete sentences and proper punctuation."
            pkg in WORK_CHAT_APPS ->
                "The text is for a WORK CHAT message. Use a clear, professional but conversational tone."
            pkg in CASUAL_CHAT_APPS ->
                "The text is for a casual CHAT message. Use a relaxed, natural, conversational tone; short sentences are fine."
            pkg in DOCUMENT_APPS ->
                "The text is for a NOTE or DOCUMENT. Use clear, well-structured written language."
            else -> null
        }
    }

    /**
     * Base transcription prompt plus an optional tone line derived from [appPackage].
     */
    fun buildPrompt(appPackage: String?): String {
        val tone = toneInstructionFor(appPackage) ?: return TRANSCRIPTION_PROMPT
        return TRANSCRIPTION_PROMPT +
            "\nContext: $tone Adjust only punctuation, capitalization and formality of wording to suit it. " +
            "Keep the original meaning and the original language of each word; never add, remove, or translate content."
    }

    // ---------------------------------------------------------------------------------------
    // Model list (Settings dropdown)
    // ---------------------------------------------------------------------------------------

    /**
     * Parses a `models.list` response and returns the model IDs (without the `models/` prefix)
     * whose `supportedGenerationMethods` contains `generateContent`.
     */
    fun parseModelsJson(json: String): List<String> {
        val root = JSONObject(json)
        val models = root.optJSONArray("models") ?: return emptyList()
        val result = LinkedHashSet<String>()
        for (i in 0 until models.length()) {
            val m = models.optJSONObject(i) ?: continue
            val id = m.optString("name", "").removePrefix("models/")
            if (id.isEmpty()) continue
            val methods = m.optJSONArray("supportedGenerationMethods") ?: continue
            var supportsGenerate = false
            for (j in 0 until methods.length()) {
                if (methods.optString(j) == "generateContent") supportsGenerate = true
            }
            if (supportsGenerate) result.add(id)
        }
        return result.toList().sortedDescending()
    }

    /**
     * GET https://generativelanguage.googleapis.com/v1beta/models?key={API_KEY} and returns the
     * model IDs available to that key that support `generateContent`.
     */
    suspend fun fetchAvailableModels(apiKey: String): Result<List<String>> = withContext(Dispatchers.IO) {
        try {
            val cleanKey = apiKey.trim()
            if (cleanKey.isEmpty()) {
                return@withContext Result.failure(TranscriptionException.InvalidApiKey())
            }
            val all = LinkedHashSet<String>()
            var pageToken: String? = null
            var pages = 0
            do {
                val urlBuilder = "https://generativelanguage.googleapis.com/v1beta/models" +
                    "?key=$cleanKey&pageSize=1000" +
                    (pageToken?.let { "&pageToken=$it" } ?: "")
                val request = Request.Builder()
                    .url(urlBuilder)
                    .get()
                    .build()
                val call = okHttpClient.newCall(request)
                val (code, body) = suspendCancellableCoroutine<Pair<Int, String>> { cont ->
                    cont.invokeOnCancellation { call.cancel() }
                    call.enqueue(object : Callback {
                        override fun onFailure(call: Call, e: IOException) {
                            if (!cont.isCancelled) cont.resumeWithException(e)
                        }

                        override fun onResponse(call: Call, response: Response) {
                            response.use { r ->
                                val s = r.body?.string().orEmpty()
                                if (!cont.isCancelled) cont.resume(r.code to s)
                            }
                        }
                    })
                }
                if (code == 400 || code == 401 || code == 403) {
                    return@withContext Result.failure(TranscriptionException.InvalidApiKey())
                }
                if (code == 429) {
                    return@withContext Result.failure(TranscriptionException.QuotaExceeded())
                }
                if (code !in 200..299) {
                    return@withContext Result.failure(
                        TranscriptionException.ApiError(parseErrorMessage(body) ?: "Server error ($code).")
                    )
                }
                all.addAll(parseModelsJson(body))
                pageToken = JSONObject(body).optString("nextPageToken", "").ifEmpty { null }
                pages++
            } while (pageToken != null && pages < 5)

            Result.success(all.toList().sortedDescending())
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: UnknownHostException) {
            Result.failure(TranscriptionException.NoInternet())
        } catch (e: IOException) {
            Result.failure(TranscriptionException.NoInternet())
        } catch (e: Exception) {
            Result.failure(TranscriptionException.ApiError(e.localizedMessage ?: "Could not load models."))
        }
    }

    /** Devanagari block minus the danda (U+0964) and double danda (U+0965), which Bengali text also uses. */
    private val DEVANAGARI_REGEX = Regex("[\\u0900-\\u0963\\u0966-\\u097F]")

    /**
     * Safeguard against Hindi/Devanagari leakage. Returns "" when the output is mostly Devanagari
     * (rejected, so nothing wrong is typed), otherwise strips any stray Devanagari characters.
     * The Bengali danda "।" is preserved.
     */
    internal fun stripDevanagari(text: String): String {
        val devanagari = DEVANAGARI_REGEX.findAll(text).count()
        if (devanagari == 0) return text
        val letters = text.count { it.isLetter() }
        if (letters == 0 || devanagari * 2 > letters) return ""
        return DEVANAGARI_REGEX.replace(text, "")
            .replace(Regex("[ \\t]{2,}"), " ")
            .trim()
    }

    internal fun cleanExtractedTranscript(raw: String): String {
        var text = raw.trim()
        if (text.startsWith("```") && text.endsWith("```")) {
            text = text.removeSurrounding("```").trim()
            if (text.startsWith("text\n") || text.startsWith("json\n")) {
                text = text.substringAfter('\n').trim()
            }
        }
        // Strip any conversational prefix / wrapping quotes the model may still add.
        text = text.replace(
            Regex(
                "^(Here is the transcription|Here's what you said|Transcription|The audio says):?\\s*",
                RegexOption.IGNORE_CASE
            ),
            ""
        )
        // Fillers like "Sure:" / "You said:" are only stripped when followed by a colon, so real
        // speech that merely starts with those words is never altered.
        text = text.replace(
            Regex("^(Sure|Certainly|Okay|You said|Here you go):\\s*", RegexOption.IGNORE_CASE),
            ""
        )
        text = text.removeSurrounding("\"").removeSurrounding("'").trim()
        val lower = text.lowercase()
        if (lower == "no speech" ||
            lower == "no speech detected" ||
            lower == "no speech detected." ||
            lower == "[silence]" ||
            lower == "(silence)" ||
            lower == "silence" ||
            lower == "nothing" ||
            lower == "none"
        ) {
            return ""
        }
        return stripDevanagari(text)
    }

    private data class RawApiAttempt(
        val extractedText: String? = null,
        val isModelNotFound: Boolean = false,
        val exception: TranscriptionException? = null,
        val retryWithNextKey: Boolean = false
    )

    private suspend fun executeGenerateContent(
        model: String,
        apiKey: String,
        bodyJson: String
    ): RawApiAttempt {
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent"
        val request = Request.Builder()
            .url(url)
            .addHeader("x-goog-api-key", apiKey)
            .addHeader("Content-Type", "application/json")
            .post(bodyJson.toRequestBody(JSON_MEDIA_TYPE))
            .build()

        val call = okHttpClient.newCall(request)
        activeCall = call

        val (code, responseBody) = suspendCancellableCoroutine<Pair<Int, String>> { cont ->
            cont.invokeOnCancellation {
                try {
                    call.cancel()
                } catch (_: Exception) {
                }
            }
            call.enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    if (!cont.isCancelled) {
                        cont.resumeWithException(e)
                    }
                }

                override fun onResponse(call: Call, response: Response) {
                    response.use { resp ->
                        val bodyStr = resp.body?.string().orEmpty()
                        if (!cont.isCancelled) {
                            cont.resume(resp.code to bodyStr)
                        }
                    }
                }
            })
        }

        if (code == 404) {
            return RawApiAttempt(isModelNotFound = true)
        }

        if (code == 400 || code == 401 || code == 403) {
            val lower = responseBody.lowercase()
            if (lower.contains("api_key_invalid") ||
                lower.contains("api key not valid") ||
                lower.contains("invalid api key") ||
                code == 401 || code == 403
            ) {
                // A rejected key may be one of several: let the caller try the next one.
                return RawApiAttempt(exception = TranscriptionException.InvalidApiKey(), retryWithNextKey = true)
            }
            if (lower.contains("not found") || lower.contains("is not found for api version")) {
                return RawApiAttempt(isModelNotFound = true)
            }
            return RawApiAttempt(
                exception = TranscriptionException.ApiError(
                    parseErrorMessage(responseBody) ?: "Request error ($code)."
                )
            )
        }

        if (code == 429) {
            return RawApiAttempt(exception = TranscriptionException.QuotaExceeded(), retryWithNextKey = true)
        }

        if (code == 503) {
            return RawApiAttempt(exception = TranscriptionException.ServiceUnavailable(), retryWithNextKey = true)
        }

        if (code !in 200..299) {
            val lowerBody = responseBody.lowercase()
            if (lowerBody.contains("resource_exhausted") || lowerBody.contains("rate limit") || lowerBody.contains("quota")) {
                return RawApiAttempt(exception = TranscriptionException.QuotaExceeded(), retryWithNextKey = true)
            }
            return RawApiAttempt(
                exception = TranscriptionException.ApiError(
                    parseErrorMessage(responseBody) ?: "Server error ($code)."
                )
            )
        }

        val extracted = extractCandidatesText(responseBody)
        return RawApiAttempt(extractedText = extracted)
    }

    fun extractCandidatesText(jsonString: String): String {
        return try {
            val root = JSONObject(jsonString)
            val candidates = root.optJSONArray("candidates") ?: return ""
            if (candidates.length() == 0) return ""
            val firstCandidate = candidates.optJSONObject(0) ?: return ""
            val content = firstCandidate.optJSONObject("content") ?: return ""
            val parts = content.optJSONArray("parts") ?: return ""
            val builder = StringBuilder()
            for (i in 0 until parts.length()) {
                val part = parts.optJSONObject(i) ?: continue
                if (part.optBoolean("thought", false)) continue
                val text = part.optString("text", "")
                if (text.isNotEmpty()) {
                    builder.append(text)
                }
            }
            builder.toString().trim()
        } catch (_: Exception) {
            ""
        }
    }

    internal fun parseErrorMessage(jsonString: String): String? {
        return try {
            val root = JSONObject(jsonString)
            val err = root.optJSONObject("error") ?: return null
            err.optString("message", "").takeIf { it.isNotBlank() }
        } catch (_: Exception) {
            null
        }
    }
}
