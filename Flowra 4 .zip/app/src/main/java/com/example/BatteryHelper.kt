package com.example

import android.annotation.SuppressLint
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings

data class OemGuideInfo(
    val id: String,
    val brandTitle: String,
    val osSubtitle: String,
    val instructions: String,
    val isCurrentDeviceMatch: Boolean
)

object BatteryHelper {

    fun isIgnoringBatteryOptimizations(context: Context): Boolean {
        val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        return powerManager?.isIgnoringBatteryOptimizations(context.packageName) == true
    }

    @SuppressLint("BatteryLife")
    fun requestIgnoreBatteryOptimizations(context: Context): Boolean {
        return try {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                data = Uri.parse("package:${context.packageName}")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (_: Exception) {
            openIgnoreBatteryOptimizationSettingsList(context)
        }
    }

    fun openIgnoreBatteryOptimizationSettingsList(context: Context): Boolean {
        return try {
            val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (_: Exception) {
            openAppDetailsSettings(context)
        }
    }

    fun openAppDetailsSettings(context: Context): Boolean {
        return try {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.fromParts("package", context.packageName, null)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (_: Exception) {
            false
        }
    }

    fun getDetectedManufacturerLabel(): String {
        val manufacturer = Build.MANUFACTURER.orEmpty().trim()
        val brand = Build.BRAND.orEmpty().trim()
        return if (manufacturer.equals(brand, ignoreCase = true) || brand.isEmpty()) {
            manufacturer.replaceFirstChar { it.uppercase() }
        } else {
            "${manufacturer.replaceFirstChar { it.uppercase() }} ($brand)"
        }
    }

    fun getOemConfigurations(): List<OemGuideInfo> {
        val mfg = "${Build.MANUFACTURER} ${Build.BRAND}".lowercase()
        return listOf(
            OemGuideInfo(
                id = "xiaomi",
                brandTitle = "Xiaomi / Redmi / POCO",
                osSubtitle = "MIUI & HyperOS Autostart + No Restrictions",
                instructions = "Enable 'Autostart' and set Battery Saver to 'No restrictions' so HyperOS never suspends the 5 WebViews.",
                isCurrentDeviceMatch = mfg.contains("xiaomi") || mfg.contains("redmi") || mfg.contains("poco")
            ),
            OemGuideInfo(
                id = "samsung",
                brandTitle = "Samsung Galaxy",
                osSubtitle = "OneUI Unrestricted Battery & Never Sleeping Apps",
                instructions = "In App Info -> Battery, select 'Unrestricted'. Also add Flowra to 'Never auto sleeping apps'.",
                isCurrentDeviceMatch = mfg.contains("samsung")
            ),
            OemGuideInfo(
                id = "oppo_oneplus_realme",
                brandTitle = "OnePlus / OPPO / Realme",
                osSubtitle = "ColorOS & OxygenOS Startup Manager",
                instructions = "In Battery Usage, enable 'Allow background activity' and 'Allow auto-launch' to prevent deep-sleep killing.",
                isCurrentDeviceMatch = mfg.contains("oppo") || mfg.contains("oneplus") || mfg.contains("realme")
            ),
            OemGuideInfo(
                id = "vivo",
                brandTitle = "Vivo / iQOO",
                osSubtitle = "OriginOS & FuntouchOS High Background Power",
                instructions = "Enable 'High background power consumption' and 'Autostart' in iManager permissions.",
                isCurrentDeviceMatch = mfg.contains("vivo") || mfg.contains("iqoo")
            )
        )
    }

    fun openOemSpecificSettings(context: Context, oemId: String): Boolean {
        val candidateIntents = when (oemId) {
            "xiaomi" -> listOf(
                Intent().apply {
                    component = ComponentName(
                        "com.miui.securitycenter",
                        "com.miui.permcenter.autostart.AutoStartManagementActivity"
                    )
                },
                Intent("miui.intent.action.OP_AUTO_START").apply {
                    addCategory(Intent.CATEGORY_DEFAULT)
                },
                Intent().apply {
                    component = ComponentName(
                        "com.miui.powerkeeper",
                        "com.miui.powerkeeper.ui.HiddenAppsConfigActivity"
                    )
                    putExtra("package_name", context.packageName)
                    putExtra("package_label", context.getString(R.string.app_name))
                }
            )

            "samsung" -> listOf(
                Intent().apply {
                    component = ComponentName(
                        "com.samsung.android.lool",
                        "com.samsung.android.sm.battery.ui.BatteryActivity"
                    )
                },
                Intent().apply {
                    component = ComponentName(
                        "com.samsung.android.sm",
                        "com.samsung.android.sm.ui.battery.BatteryActivity"
                    )
                },
                Intent().apply {
                    component = ComponentName(
                        "com.samsung.android.lool",
                        "com.samsung.android.sm.ui.battery.AppSleepListActivity"
                    )
                }
            )

            "oppo_oneplus_realme" -> listOf(
                Intent().apply {
                    component = ComponentName(
                        "com.coloros.safecenter",
                        "com.coloros.safecenter.permission.startup.StartupAppListActivity"
                    )
                },
                Intent().apply {
                    component = ComponentName(
                        "com.coloros.safecenter",
                        "com.coloros.safecenter.startupapp.StartupAppListActivity"
                    )
                },
                Intent().apply {
                    component = ComponentName(
                        "com.oplus.battery",
                        "com.oplus.powermanager.fuelgaue.PowerControlActivity"
                    )
                },
                Intent().apply {
                    component = ComponentName(
                        "com.oneplus.security",
                        "com.oneplus.security.chainlaunch.view.ChainLaunchAppListActivity"
                    )
                },
                Intent().apply {
                    component = ComponentName(
                        "com.oppo.safe",
                        "com.oppo.safe.permission.startup.StartupAppListActivity"
                    )
                }
            )

            "vivo" -> listOf(
                Intent().apply {
                    component = ComponentName(
                        "com.vivo.abe",
                        "com.vivo.applicationbehaviorengine.ui.ExcessivePowerManagerActivity"
                    )
                },
                Intent().apply {
                    component = ComponentName(
                        "com.iqoo.secure",
                        "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity"
                    )
                },
                Intent().apply {
                    component = ComponentName(
                        "com.vivo.permissionmanager",
                        "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"
                    )
                },
                Intent().apply {
                    component = ComponentName(
                        "com.iqoo.secure",
                        "com.iqoo.secure.ui.phoneoptimize.BgStartUpManager"
                    )
                }
            )

            else -> emptyList()
        }

        for (intent in candidateIntents) {
            try {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                return true
            } catch (_: Exception) {
                // Continue to next candidate intent
            }
        }

        // Guaranteed fallback to App Details screen where Battery -> Unrestricted is always accessible
        return openAppDetailsSettings(context)
    }
}
