package com.example

import android.app.Activity
import android.os.Build
import android.view.Display
import android.view.Window
import android.view.WindowManager
import com.example.data.FrameRateMode
import kotlin.math.abs

object FramePacingHelper {

    /**
     * Configures the Activity window for consistent, judder-free 60 FPS (or Adaptive Max Hz)
     * frame pacing while preserving the current native display resolution.
     */
    fun applyWindowFramePacing(activity: Activity, mode: FrameRateMode) {
        applyWindowFramePacing(activity.window, mode)
    }

    fun applyWindowFramePacing(window: Window?, mode: FrameRateMode) {
        if (window == null) return
        try {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val display = window.decorView.display ?: return
                val currentMode = display.mode
                val targetMode = selectDisplayMode(
                    currentMode = currentMode,
                    supportedModes = display.supportedModes.toList(),
                    frameRateMode = mode
                )
                if (targetMode != null && targetMode.modeId != currentMode.modeId) {
                    val params = window.attributes
                    if (params.preferredDisplayModeId != targetMode.modeId) {
                        params.preferredDisplayModeId = targetMode.modeId
                        window.attributes = params
                    }
                }
            }
        } catch (_: Exception) {
        }
    }

    internal fun selectDisplayMode(
        currentMode: Display.Mode,
        supportedModes: List<Display.Mode>,
        frameRateMode: FrameRateMode
    ): Display.Mode? {
        if (supportedModes.isEmpty()) return null
        val sameResolutionModes = supportedModes.filter {
            it.physicalWidth == currentMode.physicalWidth &&
                it.physicalHeight == currentMode.physicalHeight
        }.ifEmpty { supportedModes }

        return when (frameRateMode) {
            FrameRateMode.SMOOTH_60 -> {
                sameResolutionModes.minByOrNull { abs(it.refreshRate - 60f) }
            }
            FrameRateMode.ADAPTIVE_MAX -> {
                sameResolutionModes.maxByOrNull { it.refreshRate }
            }
        }
    }
}
