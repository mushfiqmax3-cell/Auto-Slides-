package com.example.data

import android.content.Context
import android.net.Uri
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.browserDataStore: DataStore<Preferences> by preferencesDataStore(name = "studio_browser_prefs")

enum class SearchEngine(val displayName: String, val searchUrlTemplate: String) {
    GOOGLE("Google", "https://www.google.com/search?q="),
    DUCKDUCKGO("DuckDuckGo", "https://duckduckgo.com/?q="),
    BING("Bing", "https://www.bing.com/search?q="),
    BRAVE("Brave Search", "https://search.brave.com/search?q="),
    YAHOO("Yahoo", "https://search.yahoo.com/search?p=");

    fun buildSearchUrl(query: String): String = "$searchUrlTemplate${Uri.encode(query)}"
}

enum class ThemeMode(val displayName: String) {
    SYSTEM("System Default"),
    DARK("Dark"),
    LIGHT("Light")
}

enum class HomepageMode(val displayName: String, val homeUrl: String) {
    CHROME_START_PAGE("Chrome Start Page", "about:newtab"),
    GOOGLE_AI_STUDIO("Google AI Studio", "https://aistudio.google.com/")
}

enum class FrameRateMode(val displayName: String, val targetFps: Float) {
    SMOOTH_60("Smooth 60 FPS (Consistent)", 60f),
    ADAPTIVE_MAX("Adaptive Max Hz (90-120 FPS)", 120f)
}

data class BrowserSettings(
    val searchEngine: SearchEngine = SearchEngine.GOOGLE,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val homepageMode: HomepageMode = HomepageMode.CHROME_START_PAGE,
    val frameRateMode: FrameRateMode = FrameRateMode.SMOOTH_60,
    val askBeforeDownload: Boolean = true,
    val downloadFolderPreset: String = "DOWNLOADS",
    val customDownloadTreeUri: String = "",
    val customDownloadFolderLabel: String = "",
    val keepPwasAliveInRam: Boolean = true,
    val showTabStrip: Boolean = false,
    val adBlockEnabled: Boolean = true,
    val javaScriptEnabled: Boolean = true,
    val darkWebPages: Boolean = false,
    val textZoomPercent: Int = 100
)

class BrowserPreferences(private val context: Context) {

    private object Keys {
        val SEARCH_ENGINE = stringPreferencesKey("search_engine")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val HOMEPAGE_MODE = stringPreferencesKey("homepage_mode")
        val FRAME_RATE_MODE = stringPreferencesKey("frame_rate_mode")
        val ASK_BEFORE_DOWNLOAD = booleanPreferencesKey("ask_before_download")
        val DOWNLOAD_FOLDER_PRESET = stringPreferencesKey("download_folder_preset")
        val CUSTOM_DOWNLOAD_TREE_URI = stringPreferencesKey("custom_download_tree_uri")
        val CUSTOM_DOWNLOAD_FOLDER_LABEL = stringPreferencesKey("custom_download_folder_label")
        val KEEP_PWAS_ALIVE_IN_RAM = booleanPreferencesKey("keep_pwas_alive_in_ram")
        val SHOW_TAB_STRIP = booleanPreferencesKey("show_tab_strip")
        val AD_BLOCK_ENABLED = booleanPreferencesKey("ad_block_enabled")
        val JAVASCRIPT_ENABLED = booleanPreferencesKey("javascript_enabled")
        val DARK_WEB_PAGES = booleanPreferencesKey("dark_web_pages")
        val TEXT_ZOOM_PERCENT = intPreferencesKey("text_zoom_percent")
    }

    val settingsFlow: Flow<BrowserSettings> = context.browserDataStore.data.map { prefs ->
        BrowserSettings(
            searchEngine = prefs[Keys.SEARCH_ENGINE]?.let { name ->
                SearchEngine.entries.find { it.name == name }
            } ?: SearchEngine.GOOGLE,
            themeMode = prefs[Keys.THEME_MODE]?.let { name ->
                ThemeMode.entries.find { it.name == name }
            } ?: ThemeMode.SYSTEM,
            homepageMode = prefs[Keys.HOMEPAGE_MODE]?.let { name ->
                HomepageMode.entries.find { it.name == name }
            } ?: HomepageMode.CHROME_START_PAGE,
            frameRateMode = prefs[Keys.FRAME_RATE_MODE]?.let { name ->
                FrameRateMode.entries.find { it.name == name }
            } ?: FrameRateMode.SMOOTH_60,
            askBeforeDownload = prefs[Keys.ASK_BEFORE_DOWNLOAD] ?: true,
            downloadFolderPreset = prefs[Keys.DOWNLOAD_FOLDER_PRESET] ?: "DOWNLOADS",
            customDownloadTreeUri = prefs[Keys.CUSTOM_DOWNLOAD_TREE_URI] ?: "",
            customDownloadFolderLabel = prefs[Keys.CUSTOM_DOWNLOAD_FOLDER_LABEL] ?: "",
            keepPwasAliveInRam = prefs[Keys.KEEP_PWAS_ALIVE_IN_RAM] ?: true,
            showTabStrip = prefs[Keys.SHOW_TAB_STRIP] ?: false,
            adBlockEnabled = prefs[Keys.AD_BLOCK_ENABLED] ?: true,
            javaScriptEnabled = prefs[Keys.JAVASCRIPT_ENABLED] ?: true,
            darkWebPages = prefs[Keys.DARK_WEB_PAGES] ?: false,
            textZoomPercent = prefs[Keys.TEXT_ZOOM_PERCENT] ?: 100
        )
    }

    suspend fun setSearchEngine(engine: SearchEngine) {
        context.browserDataStore.edit { it[Keys.SEARCH_ENGINE] = engine.name }
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.browserDataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    suspend fun setHomepageMode(mode: HomepageMode) {
        context.browserDataStore.edit { it[Keys.HOMEPAGE_MODE] = mode.name }
    }

    suspend fun setFrameRateMode(mode: FrameRateMode) {
        context.browserDataStore.edit { it[Keys.FRAME_RATE_MODE] = mode.name }
    }

    suspend fun setAskBeforeDownload(ask: Boolean) {
        context.browserDataStore.edit { it[Keys.ASK_BEFORE_DOWNLOAD] = ask }
    }

    suspend fun setDownloadDestination(
        preset: String,
        customTreeUri: String? = null,
        customFolderLabel: String? = null
    ) {
        context.browserDataStore.edit { prefs ->
            prefs[Keys.DOWNLOAD_FOLDER_PRESET] = preset
            if (customTreeUri != null) {
                prefs[Keys.CUSTOM_DOWNLOAD_TREE_URI] = customTreeUri
            }
            if (customFolderLabel != null) {
                prefs[Keys.CUSTOM_DOWNLOAD_FOLDER_LABEL] = customFolderLabel
            }
        }
    }

    suspend fun setKeepPwasAliveInRam(enabled: Boolean) {
        context.browserDataStore.edit { it[Keys.KEEP_PWAS_ALIVE_IN_RAM] = enabled }
    }

    suspend fun setShowTabStrip(show: Boolean) {
        context.browserDataStore.edit { it[Keys.SHOW_TAB_STRIP] = show }
    }

    suspend fun setAdBlockEnabled(enabled: Boolean) {
        context.browserDataStore.edit { it[Keys.AD_BLOCK_ENABLED] = enabled }
    }

    suspend fun setJavaScriptEnabled(enabled: Boolean) {
        context.browserDataStore.edit { it[Keys.JAVASCRIPT_ENABLED] = enabled }
    }

    suspend fun setDarkWebPages(enabled: Boolean) {
        context.browserDataStore.edit { it[Keys.DARK_WEB_PAGES] = enabled }
    }

    suspend fun setTextZoomPercent(zoom: Int) {
        context.browserDataStore.edit { it[Keys.TEXT_ZOOM_PERCENT] = zoom.coerceIn(75, 160) }
    }
}
