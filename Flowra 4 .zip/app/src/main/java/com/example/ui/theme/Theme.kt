package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val StudioDarkColorScheme = darkColorScheme(
    primary = ChromeElectricBlue,
    onPrimary = Color(0xFF062E6F),
    primaryContainer = Color(0xFF0842A0),
    onPrimaryContainer = Color(0xFFD3E3FD),
    secondary = ChromeCyanAccent,
    onSecondary = Color(0xFF00363D),
    secondaryContainer = Color(0xFF2E3136),
    onSecondaryContainer = Color(0xFFE3E3E3),
    tertiary = ChromeEmeraldShield,
    onTertiary = Color(0xFF003915),
    tertiaryContainer = Color(0xFF0F5223),
    onTertiaryContainer = Color(0xFFC4EED0),
    background = ChromeDarkBg,
    onBackground = Color(0xFFE3E3E3),
    surface = ChromeDarkSurface,
    onSurface = Color(0xFFE3E3E3),
    surfaceVariant = ChromeDarkSurfaceContainer,
    onSurfaceVariant = Color(0xFFC4C7C5),
    outline = Color(0xFF444746),
    outlineVariant = Color(0xFF333538),
    error = ChromeErrorRed,
    onError = Color(0xFF601410)
)

private val StudioLightColorScheme = lightColorScheme(
    primary = ChromePrimaryLight,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD3E3FD),
    onPrimaryContainer = Color(0xFF041E49),
    secondary = ChromeSecondaryLight,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFC2E7FF),
    onSecondaryContainer = Color(0xFF001D35),
    tertiary = ChromeTertiaryLight,
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFC4EED0),
    onTertiaryContainer = Color(0xFF072711),
    background = ChromeLightBg,
    onBackground = Color(0xFF1F1F1F),
    surface = ChromeLightSurface,
    onSurface = Color(0xFF1F1F1F),
    surfaceVariant = ChromeLightSurfaceContainer,
    onSurfaceVariant = Color(0xFF444746),
    outline = Color(0xFF747775),
    outlineVariant = Color(0xFFE0E3E1),
    error = Color(0xFFB3261E),
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> StudioDarkColorScheme
        else -> StudioLightColorScheme
    }
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
