package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Authentic Google Chrome Material You Palette (Dark)
val ChromeDarkBg = Color(0xFF1F2023)
val ChromeDarkSurface = Color(0xFF28292D)
val ChromeDarkSurfaceContainer = Color(0xFF33353A)
val ChromeDarkTabActive = Color(0xFF3C4043)
val ChromeDarkTabInactive = Color(0xFF232428)
val ChromeElectricBlue = Color(0xFF8AB4F8)
val ChromeCyanAccent = Color(0xFF78D9EC)
val ChromeEmeraldShield = Color(0xFF34A853)
val ChromeAmberWarn = Color(0xFFFBBC04)
val ChromeErrorRed = Color(0xFFF28B82)

// Authentic Google Chrome Material You Palette (Light)
val ChromeLightBg = Color(0xFFFFFFFF)
val ChromeLightSurface = Color(0xFFF8F9FA)
val ChromeLightSurfaceContainer = Color(0xFFEDF2FA)
val ChromePrimaryLight = Color(0xFF1A73E8)
val ChromeSecondaryLight = Color(0xFF0B57D0)
val ChromeTertiaryLight = Color(0xFF188038)

// Incognito Chrome Palette
val ChromeIncognitoBg = Color(0xFF1A1A1D)
val ChromeIncognitoSurface = Color(0xFF292A2E)
val ChromeIncognitoOmnibox = Color(0xFF35363A)
val ChromeIncognitoAccent = Color(0xFFA8C7FA)
