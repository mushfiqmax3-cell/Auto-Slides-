package com.example.ui

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.AddToHomeScreen
import androidx.compose.material.icons.automirrored.filled.Launch
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.InstallMobile
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.PwaPoolStats
import com.example.PwaShortcutHelper
import com.example.WebViewManager
import com.example.data.InstalledWebAppEntity
import com.example.ui.theme.ChromeCyanAccent
import com.example.ui.theme.ChromeEmeraldShield
import java.util.Locale

@Composable
fun CreateShortcutOrPwaDialog(
    initialUrl: String,
    initialTitle: String,
    favicon: Bitmap?,
    existingApps: List<InstalledWebAppEntity>,
    onConfirmCreate: (
        name: String,
        url: String,
        isStandalonePwa: Boolean,
        isolatedProfile: Boolean,
        badgeColorHex: Long,
        badgeTag: String,
        launchImmediately: Boolean
    ) -> Unit,
    onDismiss: () -> Unit
) {
    val cleanInitialUrl = if (initialUrl.isBlank() || initialUrl == WebViewManager.NEW_TAB_URL) {
        WebViewManager.DEFAULT_HOME_URL
    } else {
        initialUrl
    }

    val suggestedName = remember(initialTitle, cleanInitialUrl, existingApps) {
        PwaShortcutHelper.suggestNextAppName(initialTitle, cleanInitialUrl, existingApps)
    }
    val suggestedTag = remember(existingApps, cleanInitialUrl) {
        PwaShortcutHelper.suggestNextBadgeTag(existingApps, cleanInitialUrl)
    }
    val defaultColor = remember(existingApps) {
        val list = PwaShortcutHelper.PRESET_BADGE_COLORS
        list[existingApps.size % list.size]
    }

    var appName by remember { mutableStateOf(suggestedName) }
    var targetUrl by remember { mutableStateOf(cleanInitialUrl) }
    var isStandalonePwa by remember { mutableStateOf(true) }
    var isolatedProfile by remember { mutableStateOf(true) }
    var badgeColorHex by remember { mutableLongStateOf(defaultColor) }
    var badgeTag by remember { mutableStateOf(suggestedTag) }

    val previewBitmap = remember(appName, favicon, badgeColorHex, badgeTag, isStandalonePwa) {
        PwaShortcutHelper.buildLauncherIconBitmap(
            name = appName.ifBlank { "Web App" },
            favicon = favicon,
            badgeColorHex = badgeColorHex,
            badgeTag = badgeTag,
            isStandalonePwa = isStandalonePwa
        )
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            color = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(22.dp),
            tonalElevation = 6.dp,
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .widthIn(max = 540.dp)
        ) {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.AddToHomeScreen,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Add to Home Screen / PWA",
                            style = MaterialTheme.typography.titleLarge
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close dialog")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Live Home Screen Icon Preview Card
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
                    ),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(14.dp)
                    ) {
                        Image(
                            bitmap = previewBitmap.asImageBitmap(),
                            contentDescription = "Launcher icon preview",
                            modifier = Modifier
                                .size(62.dp)
                                .clip(RoundedCornerShape(16.dp))
                        )
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = appName.ifBlank { "Studio Web App" },
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = if (isStandalonePwa) {
                                    "Independent PWA Window"
                                } else {
                                    "Browser Website Shortcut"
                                },
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = targetUrl,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Mode Selection Cards: PWA vs Shortcut
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    ModeOptionCard(
                        selected = isStandalonePwa,
                        title = "Standalone PWA",
                        subtitle = "Separate app & window",
                        icon = Icons.Default.InstallMobile,
                        onClick = { isStandalonePwa = true },
                        modifier = Modifier.weight(1f).testTag("mode_pwa_card")
                    )
                    ModeOptionCard(
                        selected = !isStandalonePwa,
                        title = "Web Shortcut",
                        subtitle = "Opens in browser tab",
                        icon = Icons.Default.Link,
                        onClick = { isStandalonePwa = false },
                        modifier = Modifier.weight(1f).testTag("mode_shortcut_card")
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = appName,
                    onValueChange = { appName = it },
                    label = { Text("App / Shortcut Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("pwa_name_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = targetUrl,
                    onValueChange = { targetUrl = it },
                    label = { Text("Website URL") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("pwa_url_input")
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Badge Tag + Color Customizer (makes 5-10 PWAs of the same site easy to tell apart)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = badgeTag,
                        onValueChange = { badgeTag = it.take(3) },
                        label = { Text("Badge #") },
                        singleLine = true,
                        modifier = Modifier.width(105.dp)
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Badge Color",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.horizontalScroll(rememberScrollState())
                        ) {
                            PwaShortcutHelper.PRESET_BADGE_COLORS.forEach { hex ->
                                val selected = badgeColorHex == hex
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier
                                        .size(30.dp)
                                        .clip(CircleShape)
                                        .background(Color(hex))
                                        .border(
                                            width = if (selected) 2.5.dp else 0.dp,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            shape = CircleShape
                                        )
                                        .clickable { badgeColorHex = hex }
                                ) {
                                    if (selected) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                if (isStandalonePwa) {
                    Spacer(modifier = Modifier.height(14.dp))
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { isolatedProfile = !isolatedProfile }
                                .padding(horizontal = 12.dp, vertical = 10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = null,
                                tint = ChromeEmeraldShield,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Isolated Session & Account",
                                    style = MaterialTheme.typography.titleSmall
                                )
                                Text(
                                    text = "Each PWA has its own cookies, login & storage — multiple PWAs of the same site stay completely separate.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Switch(
                                checked = isolatedProfile,
                                onCheckedChange = { isolatedProfile = it }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                val context = androidx.compose.ui.platform.LocalContext.current
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable {
                            PwaShortcutHelper.openOemShortcutPermissionSettings(context)
                        }
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Home Screen Shortcut Permission",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "If your phone blocks shortcuts (Xiaomi/Vivo/Oppo), tap here to enable 'Home screen shortcuts'",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        TextButton(
                            onClick = { PwaShortcutHelper.openOemShortcutPermissionSettings(context) }
                        ) {
                            Text("Allow")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    horizontalArrangement = Arrangement.End,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    OutlinedButton(
                        onClick = {
                            val finalName = appName.ifBlank { suggestedName }
                            val finalUrl = targetUrl.ifBlank { cleanInitialUrl }
                            onDismiss()
                            onConfirmCreate(
                                finalName,
                                finalUrl,
                                isStandalonePwa,
                                isolatedProfile,
                                badgeColorHex,
                                badgeTag,
                                false
                            )
                        },
                        modifier = Modifier.testTag("pin_to_home_button")
                    ) {
                        Text("Pin to Home")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val finalName = appName.ifBlank { suggestedName }
                            val finalUrl = targetUrl.ifBlank { cleanInitialUrl }
                            onDismiss()
                            onConfirmCreate(
                                finalName,
                                finalUrl,
                                isStandalonePwa,
                                isolatedProfile,
                                badgeColorHex,
                                badgeTag,
                                true
                            )
                        },
                        modifier = Modifier.testTag("create_and_open_pwa_button")
                    ) {
                        Text("Add & Open")
                    }
                }
            }
        }
    }
}

@Composable
private fun ModeOptionCard(
    selected: Boolean,
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = if (selected) {
            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)
        } else {
            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
        },
        modifier = modifier
            .border(
                width = if (selected) 2.dp else 1.dp,
                color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.35f),
                shape = RoundedCornerShape(14.dp)
            )
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                maxLines = 1
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun InstalledWebAppsSheetDialog(
    webApps: List<InstalledWebAppEntity>,
    poolStats: PwaPoolStats = PwaPoolStats(),
    onLaunchApp: (InstalledWebAppEntity) -> Unit,
    onRepinApp: (InstalledWebAppEntity) -> Unit,
    onHibernateApp: (InstalledWebAppEntity) -> Unit = {},
    onDeleteApp: (InstalledWebAppEntity) -> Unit,
    onCreateNew: () -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            color = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.86f)
                .widthIn(max = 600.dp)
        ) {
            Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Apps, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Installed PWAs & Shortcuts", style = MaterialTheme.typography.titleLarge)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = {
                            onDismiss()
                            onCreateNew()
                        }) {
                            Icon(Icons.Default.Add, contentDescription = "Create new PWA")
                        }
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Close, contentDescription = "Close PWAs list")
                        }
                    }
                }

                Text(
                    text = "Each PWA runs in its own independent window and isolated session. Background PWAs stay cached in RAM according to your phone's memory so re-opening needs zero reload.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(10.dp))

                // RAM Keep-Alive Capacity Card
                val totalRamStr = if (poolStats.totalRamMb > 0L) {
                    String.format(Locale.US, "%.1f GB RAM", poolStats.totalRamMb / 1024.0)
                } else {
                    "Auto RAM"
                }
                val availRamStr = if (poolStats.availRamMb > 0L) {
                    String.format(Locale.US, "%.1f GB free", poolStats.availRamMb / 1024.0)
                } else {
                    "Ready"
                }
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = ChromeEmeraldShield.copy(alpha = 0.12f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Memory,
                            contentDescription = null,
                            tint = ChromeEmeraldShield,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "RAM Keep-Alive Pool: ${poolStats.liveCount} / ${poolStats.maxSlotsByRam} live apps",
                                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
                                color = ChromeEmeraldShield
                            )
                            Text(
                                text = "$totalRamStr ($availRamStr) • Oldest idle PWA reloads only when RAM runs low",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider()
                Spacer(modifier = Modifier.height(10.dp))

                if (webApps.isEmpty()) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.weight(1f).fillMaxWidth()
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.InstallMobile,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.45f),
                                modifier = Modifier.size(56.dp)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "No PWAs or shortcuts created yet",
                                style = MaterialTheme.typography.titleMedium
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Button(
                                onClick = {
                                    onDismiss()
                                    onCreateNew()
                                }
                            ) {
                                Icon(Icons.AutoMirrored.Filled.AddToHomeScreen, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Create First PWA")
                            }
                        }
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.weight(1f).fillMaxWidth()
                    ) {
                        items(webApps, key = { it.pwaId }) { app ->
                            val badgeColor = Color(app.badgeColorHex)
                            val isLive = poolStats.livePwaIds.contains(app.pwaId)
                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
                                ),
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        onLaunchApp(app)
                                        onDismiss()
                                    }
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(12.dp)
                                ) {
                                    Box(
                                        contentAlignment = Alignment.Center,
                                        modifier = Modifier
                                            .size(44.dp)
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(badgeColor)
                                    ) {
                                        Text(
                                            text = app.badgeTag.ifBlank {
                                                app.name.firstOrNull()?.uppercase() ?: "W"
                                            },
                                            style = MaterialTheme.typography.titleMedium.copy(
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 15.sp
                                            ),
                                            color = Color.White
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = app.name,
                                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = app.url,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Row(
                                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                                            modifier = Modifier.horizontalScroll(rememberScrollState())
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(6.dp))
                                                    .background(MaterialTheme.colorScheme.primaryContainer)
                                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                                            ) {
                                                Text(
                                                    text = if (app.isStandalonePwa) "PWA" else "Shortcut",
                                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                                )
                                            }
                                            if (app.isStandalonePwa) {
                                                Box(
                                                    modifier = Modifier
                                                        .clip(RoundedCornerShape(6.dp))
                                                        .background(
                                                            if (isLive) ChromeEmeraldShield.copy(alpha = 0.18f)
                                                            else ChromeCyanAccent.copy(alpha = 0.14f)
                                                        )
                                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                                ) {
                                                    Text(
                                                        text = if (isLive) "Live in RAM • Instant" else "Standby",
                                                        style = MaterialTheme.typography.labelSmall.copy(
                                                            fontSize = 10.sp,
                                                            fontWeight = FontWeight.SemiBold
                                                        ),
                                                        color = if (isLive) ChromeEmeraldShield else ChromeCyanAccent
                                                    )
                                                }
                                            }
                                            if (app.isStandalonePwa && app.isolatedProfile) {
                                                Box(
                                                    modifier = Modifier
                                                        .clip(RoundedCornerShape(6.dp))
                                                        .background(ChromeEmeraldShield.copy(alpha = 0.16f))
                                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                                ) {
                                                    Text(
                                                        text = "Isolated",
                                                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                                        color = ChromeEmeraldShield
                                                    )
                                                }
                                            }
                                        }
                                    }
                                    if (isLive) {
                                        IconButton(onClick = { onHibernateApp(app) }) {
                                            Icon(
                                                imageVector = Icons.Default.Bedtime,
                                                contentDescription = "Free RAM for this PWA"
                                            )
                                        }
                                    }
                                    IconButton(onClick = { onRepinApp(app) }) {
                                        Icon(
                                            imageVector = Icons.AutoMirrored.Filled.AddToHomeScreen,
                                            contentDescription = "Pin to Home Screen"
                                        )
                                    }
                                    IconButton(onClick = {
                                        onLaunchApp(app)
                                        onDismiss()
                                    }) {
                                        Icon(
                                            imageVector = Icons.AutoMirrored.Filled.Launch,
                                            contentDescription = "Open PWA",
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                    IconButton(onClick = { onDeleteApp(app) }) {
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = "Delete PWA",
                                            tint = MaterialTheme.colorScheme.error
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
