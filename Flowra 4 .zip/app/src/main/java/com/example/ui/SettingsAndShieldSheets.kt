package com.example.ui

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Tab
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.BatteryHelper
import com.example.DevicePermissionsStatus
import com.example.DownloadFolderPreset
import com.example.OemGuideInfo
import com.example.PwaPoolStats
import com.example.R
import com.example.ShieldServiceState
import com.example.data.BrowserSettings
import com.example.data.FrameRateMode
import com.example.data.HomepageMode
import com.example.data.SearchEngine
import com.example.data.ThemeMode
import com.example.ui.theme.ChromeAmberWarn
import com.example.ui.theme.ChromeCyanAccent
import com.example.ui.theme.ChromeElectricBlue
import com.example.ui.theme.ChromeEmeraldShield
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun SettingsSheetDialog(
    settings: BrowserSettings,
    isGoogleSignedIn: Boolean,
    isBatteryUnrestricted: Boolean,
    permissionsStatus: DevicePermissionsStatus = DevicePermissionsStatus(),
    onRequestAllPermissions: () -> Unit = {},
    onSelectSearchEngine: (SearchEngine) -> Unit,
    onSelectThemeMode: (ThemeMode) -> Unit,
    onSelectHomepageMode: (HomepageMode) -> Unit,
    onSelectFrameRateMode: (FrameRateMode) -> Unit = {},
    onToggleAskBeforeDownload: (Boolean) -> Unit,
    onSelectDownloadPreset: (DownloadFolderPreset) -> Unit = {},
    onPickCustomDownloadFolder: (((String, String) -> Unit) -> Unit)? = null,
    onToggleKeepPwasAlive: (Boolean) -> Unit = {},
    onToggleShowTabStrip: (Boolean) -> Unit,
    onToggleAdBlock: (Boolean) -> Unit,
    onToggleJavaScript: (Boolean) -> Unit,
    onToggleDarkWebPages: (Boolean) -> Unit,
    onUpdateTextZoom: (Int) -> Unit,
    onGoogleSignIn: () -> Unit,
    onGoogleManage: () -> Unit,
    onGoogleSignOut: () -> Unit,
    onOpenShieldDialog: () -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var showSearchPicker by remember { mutableStateOf(false) }
    var showThemePicker by remember { mutableStateOf(false) }
    var showHomepagePicker by remember { mutableStateOf(false) }
    var showFrameRatePicker by remember { mutableStateOf(false) }
    var showDownloadFolderPicker by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            color = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.90f)
                .widthIn(max = 600.dp)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Header
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Settings, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("Settings", style = MaterialTheme.typography.titleLarge)
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close settings")
                    }
                }
                HorizontalDivider()

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp)
                ) {
                    // Account Section
                    SectionLabel("YOU AND GOOGLE")
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.AccountCircle,
                                    contentDescription = null,
                                    tint = if (isGoogleSignedIn) ChromeEmeraldShield else MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(34.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = if (isGoogleSignedIn) "Google Account Connected" else "Sign in to Google",
                                        style = MaterialTheme.typography.titleSmall
                                    )
                                    Text(
                                        text = if (isGoogleSignedIn) "Cookies active across AI Studio & Google services" else "Sign in to save & use AI Studio, Drive, YouTube",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = {
                                        onDismiss()
                                        if (isGoogleSignedIn) onGoogleManage() else onGoogleSignIn()
                                    }
                                ) {
                                    Text(if (isGoogleSignedIn) "Manage Account" else "Sign In")
                                }
                                if (isGoogleSignedIn) {
                                    OutlinedButton(
                                        onClick = {
                                            onDismiss()
                                            onGoogleSignOut()
                                        }
                                    ) {
                                        Text("Sign Out")
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = ChromeEmeraldShield.copy(alpha = 0.12f)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Storage,
                                contentDescription = null,
                                tint = ChromeEmeraldShield,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Persistent Logins & Offline SQLite Storage",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                                    color = ChromeEmeraldShield
                                )
                                Text(
                                    text = "Cookies & site logins persist on device across restarts; Bookmarks & History are saved in offline Room SQLite.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    SectionLabel("DEVICE PERMISSIONS & FILE MANAGER ACCESS")
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(14.dp)
                        ) {
                            TelemetryStatusRow(
                                icon = Icons.Default.Folder,
                                label = "File Manager, ZArchiver, Photos & Capture",
                                value = "CHROME CHOOSER ACTIVE",
                                isHealthy = permissionsStatus.fileManagerAndSafReady
                            )
                            TelemetryStatusRow(
                                icon = Icons.Default.CameraAlt,
                                label = "Camera (Photo & Video Capture)",
                                value = if (permissionsStatus.cameraGranted) "GRANTED" else "TAP GRANT",
                                isHealthy = permissionsStatus.cameraGranted
                            )
                            TelemetryStatusRow(
                                icon = Icons.Default.Mic,
                                label = "Microphone (Voice & Audio)",
                                value = if (permissionsStatus.microphoneGranted) "GRANTED" else "TAP GRANT",
                                isHealthy = permissionsStatus.microphoneGranted
                            )
                            TelemetryStatusRow(
                                icon = Icons.Default.LocationOn,
                                label = "Location (GPS & Maps)",
                                value = if (permissionsStatus.locationGranted) "GRANTED" else "TAP GRANT",
                                isHealthy = permissionsStatus.locationGranted
                            )
                            TelemetryStatusRow(
                                icon = Icons.Default.Notifications,
                                label = "Notifications",
                                value = if (permissionsStatus.notificationsGranted) "GRANTED" else "TAP GRANT",
                                isHealthy = permissionsStatus.notificationsGranted
                            )

                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Button(
                                    onClick = onRequestAllPermissions,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (permissionsStatus.allGranted) ChromeEmeraldShield else ChromeElectricBlue
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp)
                                        .testTag("grant_all_permissions_button")
                                ) {
                                    Text(
                                        text = if (permissionsStatus.allGranted) "All Permissions Active" else "Grant All Permissions",
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                OutlinedButton(
                                    onClick = { BatteryHelper.openAppDetailsSettings(context) },
                                    modifier = Modifier.height(48.dp)
                                ) {
                                    Text("App Settings")
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))
                    SectionLabel("BASICS")

                    SettingsRowItem(
                        icon = Icons.Default.Search,
                        title = "Search engine",
                        subtitle = settings.searchEngine.displayName,
                        onClick = { showSearchPicker = true }
                    )
                    SettingsRowItem(
                        icon = Icons.Default.Home,
                        title = "Homepage",
                        subtitle = settings.homepageMode.displayName,
                        onClick = { showHomepagePicker = true }
                    )
                    SettingsRowItem(
                        icon = Icons.Default.DarkMode,
                        title = "Theme",
                        subtitle = settings.themeMode.displayName,
                        onClick = { showThemePicker = true }
                    )

                    Spacer(modifier = Modifier.height(14.dp))
                    SectionLabel("INTERFACE & ACCESSIBILITY")

                    SettingsRowItem(
                        icon = Icons.Default.Speed,
                        title = "Frame rate & smoothness",
                        subtitle = settings.frameRateMode.displayName,
                        onClick = { showFrameRatePicker = true },
                        modifier = Modifier.testTag("settings_frame_rate_row")
                    )

                    SettingsSwitchRow(
                        icon = Icons.Default.Tab,
                        title = "Show top tab strip",
                        subtitle = "Keep tab bar visible under the address bar",
                        checked = settings.showTabStrip,
                        onCheckedChange = onToggleShowTabStrip,
                        modifier = Modifier.testTag("settings_show_tab_strip_row")
                    )

                    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Page text zoom", style = MaterialTheme.typography.titleSmall)
                            Text("${settings.textZoomPercent}%", color = MaterialTheme.colorScheme.primary)
                        }
                        Slider(
                            value = settings.textZoomPercent.toFloat(),
                            onValueChange = { onUpdateTextZoom(it.roundToInt()) },
                            valueRange = 75f..150f,
                            steps = 14
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    SectionLabel("DOWNLOADS, PRIVACY & PERFORMANCE")

                    SettingsSwitchRow(
                        icon = Icons.Default.Download,
                        title = "Ask where to save files",
                        subtitle = "Brave-style file name & folder picker before download",
                        checked = settings.askBeforeDownload,
                        onCheckedChange = onToggleAskBeforeDownload,
                        modifier = Modifier.testTag("settings_ask_download_row")
                    )
                    val activeFolderLabel = if (
                        settings.downloadFolderPreset == DownloadFolderPreset.CUSTOM_SAF.name &&
                        settings.customDownloadFolderLabel.isNotBlank()
                    ) {
                        settings.customDownloadFolderLabel
                    } else {
                        DownloadFolderPreset.fromId(settings.downloadFolderPreset).relativeDisplayPath
                    }
                    SettingsRowItem(
                        icon = Icons.Default.Folder,
                        title = "Default download folder",
                        subtitle = activeFolderLabel,
                        onClick = { showDownloadFolderPicker = true }
                    )
                    SettingsSwitchRow(
                        icon = Icons.Default.Security,
                        title = "Ad & tracker shield",
                        subtitle = "Block known ad/tracking network domains",
                        checked = settings.adBlockEnabled,
                        onCheckedChange = onToggleAdBlock,
                        modifier = Modifier.testTag("settings_ad_block_row")
                    )
                    SettingsSwitchRow(
                        icon = Icons.Default.Public,
                        title = "JavaScript",
                        subtitle = "Allow sites to run JavaScript (recommended)",
                        checked = settings.javaScriptEnabled,
                        onCheckedChange = onToggleJavaScript,
                        modifier = Modifier.testTag("settings_javascript_row")
                    )
                    SettingsSwitchRow(
                        icon = Icons.Default.DarkMode,
                        title = "Dark theme for websites",
                        subtitle = "Apply algorithmic darkening to web pages (Android 13+)",
                        checked = settings.darkWebPages,
                        onCheckedChange = onToggleDarkWebPages,
                        modifier = Modifier.testTag("settings_dark_web_row")
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    SectionLabel("BACKGROUND ENGINE")

                    SettingsSwitchRow(
                        icon = Icons.Default.Save,
                        title = "RAM-adaptive PWA & shortcut keep-alive",
                        subtitle = "Keep background PWAs live in RAM up to device memory limit",
                        checked = settings.keepPwasAliveInRam,
                        onCheckedChange = onToggleKeepPwasAlive,
                        modifier = Modifier.testTag("settings_keep_pwas_alive_row")
                    )
                    SettingsRowItem(
                        icon = Icons.Default.Shield,
                        title = "Anti-Kill & OEM Battery Shield",
                        subtitle = if (isBatteryUnrestricted) "Unrestricted • Tabs & PWAs kept alive" else "Tap to whitelist battery optimization",
                        onClick = {
                            onDismiss()
                            onOpenShieldDialog()
                        }
                    )
                }
            }
        }
    }

    if (showDownloadFolderPicker) {
        val selectablePresets = listOf(
            DownloadFolderPreset.DOWNLOADS,
            DownloadFolderPreset.STUDIO_DOWNLOADS,
            DownloadFolderPreset.DOCUMENTS,
            DownloadFolderPreset.PICTURES,
            DownloadFolderPreset.MUSIC,
            DownloadFolderPreset.MOVIES
        )
        Dialog(onDismissRequest = { showDownloadFolderPicker = false }) {
            Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surface) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text("Default download folder", style = MaterialTheme.typography.titleLarge)
                    Spacer(modifier = Modifier.height(10.dp))
                    selectablePresets.forEach { preset ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onSelectDownloadPreset(preset)
                                    showDownloadFolderPicker = false
                                }
                                .padding(vertical = 8.dp)
                        ) {
                            RadioButton(
                                selected = settings.downloadFolderPreset == preset.name,
                                onClick = {
                                    onSelectDownloadPreset(preset)
                                    showDownloadFolderPicker = false
                                }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(preset.displayName, style = MaterialTheme.typography.bodyLarge)
                                Text(
                                    preset.relativeDisplayPath,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                    if (onPickCustomDownloadFolder != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = {
                                onPickCustomDownloadFolder { _, _ ->
                                    showDownloadFolderPicker = false
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Folder, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Choose any phone folder (SAF)...")
                        }
                    }
                }
            }
        }
    }

    if (showSearchPicker) {
        OptionPickerDialog(
            title = "Search engine",
            options = SearchEngine.entries,
            selected = settings.searchEngine,
            labelProvider = { it.displayName },
            onSelect = {
                onSelectSearchEngine(it)
                showSearchPicker = false
            },
            onDismiss = { showSearchPicker = false }
        )
    }

    if (showThemePicker) {
        OptionPickerDialog(
            title = "Theme",
            options = ThemeMode.entries,
            selected = settings.themeMode,
            labelProvider = { it.displayName },
            onSelect = {
                onSelectThemeMode(it)
                showThemePicker = false
            },
            onDismiss = { showThemePicker = false }
        )
    }

    if (showHomepagePicker) {
        OptionPickerDialog(
            title = "Homepage",
            options = HomepageMode.entries,
            selected = settings.homepageMode,
            labelProvider = { it.displayName },
            onSelect = {
                onSelectHomepageMode(it)
                showHomepagePicker = false
            },
            onDismiss = { showHomepagePicker = false }
        )
    }

    if (showFrameRatePicker) {
        OptionPickerDialog(
            title = "Frame rate & smoothness",
            options = FrameRateMode.entries,
            selected = settings.frameRateMode,
            labelProvider = { it.displayName },
            tagProvider = { "frame_rate_option_${it.name}" },
            onSelect = {
                onSelectFrameRateMode(it)
                showFrameRatePicker = false
            },
            onDismiss = { showFrameRatePicker = false }
        )
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(bottom = 8.dp)
    )
}

@Composable
private fun SettingsRowItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp)
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(22.dp))
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun SettingsSwitchRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(vertical = 8.dp)
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(22.dp))
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(modifier = Modifier.width(8.dp))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun <T> OptionPickerDialog(
    title: String,
    options: List<T>,
    selected: T,
    labelProvider: (T) -> String,
    tagProvider: ((T) -> String)? = null,
    onSelect: (T) -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surface) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(title, style = MaterialTheme.typography.titleLarge)
                Spacer(modifier = Modifier.height(10.dp))
                options.forEach { option ->
                    val itemModifier = Modifier
                        .fillMaxWidth()
                        .let { base ->
                            val tag = tagProvider?.invoke(option)
                            if (tag != null) base.testTag(tag) else base
                        }
                        .clickable { onSelect(option) }
                        .padding(vertical = 8.dp)
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = itemModifier
                    ) {
                        RadioButton(selected = option == selected, onClick = { onSelect(option) })
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(labelProvider(option), style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }
        }
    }
}

@Composable
fun BatteryShieldDialog(
    isBatteryUnrestricted: Boolean,
    shieldState: ShieldServiceState,
    poolStats: PwaPoolStats = PwaPoolStats(),
    onRefreshBatteryStatus: () -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val oemConfigs = remember { BatteryHelper.getOemConfigurations() }
    val detectedBrand = remember { BatteryHelper.getDetectedManufacturerLabel() }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp,
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .widthIn(max = 560.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = null,
                            tint = ChromeEmeraldShield,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = stringResource(R.string.shield_dialog_title),
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "Device: $detectedBrand • 5 Parallel Renderers",
                                style = MaterialTheme.typography.labelMedium,
                                color = ChromeCyanAccent
                            )
                        }
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(48.dp)) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close shield dialog")
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = stringResource(R.string.shield_dialog_subtitle),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(14.dp))

                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(14.dp)
                    ) {
                        Text(
                            text = "LIVE HARDWARE & CHROMIUM KEEP-ALIVE TELEMETRY",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.ExtraBold),
                            color = ChromeElectricBlue
                        )
                        TelemetryStatusRow(
                            icon = Icons.Default.Memory,
                            label = "CPU Partial WakeLock + Sticky Service",
                            value = if (shieldState.wakeLockHeld) "HELD (Pulse #${shieldState.heartbeatCount})" else "STARTING",
                            isHealthy = shieldState.wakeLockHeld
                        )
                        TelemetryStatusRow(
                            icon = Icons.Default.Wifi,
                            label = "Low-Latency Wi-Fi + Multicast Lock",
                            value = if (shieldState.wifiLockHeld) "LOCKED (No Drop)" else "ACTIVE",
                            isHealthy = true
                        )
                        TelemetryStatusRow(
                            icon = Icons.Default.Security,
                            label = "Sub-Audible PCM Audio Keep-Alive",
                            value = if (shieldState.audioKeepAliveActive) "STREAMING" else "STANDBY",
                            isHealthy = shieldState.audioKeepAliveActive
                        )
                        TelemetryStatusRow(
                            icon = Icons.Default.Public,
                            label = "Chromium 5-Tab Visibility & Priority",
                            value = "IMPORTANT + VISIBLE",
                            isHealthy = true
                        )
                        TelemetryStatusRow(
                            icon = Icons.Default.Speed,
                            label = "60 FPS Pre-Raster & Frame Pacing",
                            value = "SMOOTH ACTIVE",
                            isHealthy = true
                        )
                        val totalRamGb = if (poolStats.totalRamMb > 0L) {
                            String.format(Locale.US, "%.1f GB RAM", poolStats.totalRamMb / 1024.0)
                        } else {
                            "Auto RAM"
                        }
                        TelemetryStatusRow(
                            icon = Icons.Default.Storage,
                            label = "RAM Keep-Alive PWA Pool",
                            value = "${poolStats.liveCount} / ${poolStats.maxSlotsByRam} live ($totalRamGb)",
                            isHealthy = !poolStats.isLowMemory
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isBatteryUnrestricted) {
                            ChromeEmeraldShield.copy(alpha = 0.14f)
                        } else {
                            ChromeAmberWarn.copy(alpha = 0.16f)
                        }
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (isBatteryUnrestricted) Icons.Default.CheckCircle else Icons.Default.BatteryChargingFull,
                                contentDescription = null,
                                tint = if (isBatteryUnrestricted) ChromeEmeraldShield else ChromeAmberWarn,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isBatteryUnrestricted) "1. Android Doze Whitelist: UNRESTRICTED" else "1. Bypass Android Doze & Battery Saver",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (isBatteryUnrestricted) {
                                "Flowra is exempted from standard Android Doze battery optimizations."
                            } else {
                                "Grant 'Ignore Battery Optimizations' so Android never suspends background network or CPU threads."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            Button(
                                onClick = {
                                    BatteryHelper.requestIgnoreBatteryOptimizations(context)
                                    onRefreshBatteryStatus()
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isBatteryUnrestricted) ChromeEmeraldShield else ChromeElectricBlue
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("whitelist_battery_button")
                            ) {
                                Text(
                                    text = if (isBatteryUnrestricted) "Re-Verify Whitelist" else "Grant Unrestricted",
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            OutlinedButton(
                                onClick = { BatteryHelper.openAppDetailsSettings(context) },
                                modifier = Modifier.height(48.dp)
                            ) {
                                Text("App Info")
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "2. OEM BACKGROUND & AUTOSTART BYPASS",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.ExtraBold),
                    color = ChromeCyanAccent
                )
                Spacer(modifier = Modifier.height(8.dp))

                oemConfigs.forEach { oem ->
                    OemBypassCard(
                        oem = oem,
                        onOpenOemSettings = { BatteryHelper.openOemSpecificSettings(context, oem.id) }
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }

                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = onDismiss,
                    contentPadding = PaddingValues(vertical = 12.dp),
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) {
                    Text("Done", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun TelemetryStatusRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String,
    isHealthy: Boolean
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isHealthy) ChromeEmeraldShield else ChromeAmberWarn,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
        }
        Text(
            text = value,
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = if (isHealthy) ChromeEmeraldShield else ChromeAmberWarn
        )
    }
}

@Composable
private fun OemBypassCard(
    oem: OemGuideInfo,
    onOpenOemSettings: () -> Unit
) {
    val borderColor = if (oem.isCurrentDeviceMatch) ChromeCyanAccent else MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = if (oem.isCurrentDeviceMatch) 1.5.dp else 1.dp,
                color = borderColor,
                shape = RoundedCornerShape(12.dp)
            )
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth().padding(12.dp)
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = oem.brandTitle, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                    if (oem.isCurrentDeviceMatch) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "DETECTED",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.ExtraBold, fontSize = 10.sp),
                            color = ChromeCyanAccent
                        )
                    }
                }
                Text(text = oem.osSubtitle, style = MaterialTheme.typography.labelSmall, color = ChromeElectricBlue)
                Spacer(modifier = Modifier.height(3.dp))
                Text(text = oem.instructions, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(modifier = Modifier.width(8.dp))
            OutlinedButton(
                onClick = onOpenOemSettings,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                modifier = Modifier.height(48.dp).testTag("oem_button_${oem.id}")
            ) {
                Icon(imageVector = Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Open", style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}
