package com.example

import android.content.Context
import android.net.Uri
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.CRC32
import java.util.zip.Inflater
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

data class ExtractedZipEntryResult(
    val fileName: String,
    val mimeType: String,
    val savedUri: Uri,
    val sizeBytes: Long,
    val isValidApk: Boolean = true
)

data class ZipExtractionSummary(
    val extractedFiles: List<ExtractedZipEntryResult>,
    val repairedCount: Int = 0,
    val containsSimulatedApk: Boolean = false
)

/**
 * Fault-tolerant ZIP normalizer and extractor engineered to fix "Unable to decompress"
 * errors on OEM File Managers (such as Vivo/iQOO, Xiaomi, Samsung, Oppo) caused by:
 * 1. Streaming Data Descriptors (General Purpose Bit Flag bit 3 = 0x0008) from JSZip / Node / Web exports.
 * 2. Mismatched CRC-32 checksums, uncompressed payloads marked with method=8 (Deflate), or
 *    mismatched header sizes in web-generated ZIP buffers.
 * 3. Direct extraction of inner .apk and project files into /Downloads without requiring an external unzip tool.
 */
object ZipArchiveHelper {

    private const val LOCAL_FILE_HEADER_SIG = 0x04034b50
    private const val CENTRAL_DIR_HEADER_SIG = 0x02014b50
    private const val END_OF_CENTRAL_DIR_SIG = 0x06054b50
    private const val DATA_DESCRIPTOR_SIG = 0x08074b50

    data class RawParsedEntry(
        val name: String,
        val data: ByteArray
    )

    /**
     * Parses a ZIP byte array using standard ZipInputStream first, and falls back to a
     * tolerant binary PK\x03\x04 / PK\x01\x02 scanner if standard ZipInputStream fails
     * due to bad CRC32, streaming flags, or truncated/mismatched web-generated buffers.
     */
    fun parseEntriesTolerant(zipBytes: ByteArray): List<RawParsedEntry> {
        if (zipBytes.size < 4) return emptyList()

        // 1. Try standard ZipInputStream first
        val standardEntries = LinkedHashMap<String, ByteArray>()
        var standardSucceeded = true
        try {
            ZipInputStream(ByteArrayInputStream(zipBytes)).use { zis ->
                val buffer = ByteArray(16 * 1024)
                while (true) {
                    val entry = try {
                        zis.nextEntry
                    } catch (_: Exception) {
                        standardSucceeded = false
                        break
                    } ?: break

                    if (!entry.isDirectory) {
                        val out = ByteArrayOutputStream()
                        try {
                            while (true) {
                                val read = zis.read(buffer)
                                if (read <= 0) break
                                out.write(buffer, 0, read)
                            }
                            val cleanName = sanitizeEntryPath(entry.name)
                            if (cleanName.isNotBlank()) {
                                standardEntries[cleanName] = out.toByteArray()
                            }
                        } catch (_: Exception) {
                            standardSucceeded = false
                            if (out.size() > 0) {
                                val cleanName = sanitizeEntryPath(entry.name)
                                if (cleanName.isNotBlank()) {
                                    standardEntries[cleanName] = out.toByteArray()
                                }
                            }
                        }
                    }
                    try {
                        zis.closeEntry()
                    } catch (_: Exception) {
                        // Ignore CRC32 or Data Descriptor mismatch on closeEntry()
                    }
                }
            }
        } catch (_: Exception) {
            standardSucceeded = false
        }

        if (standardSucceeded && standardEntries.isNotEmpty()) {
            return standardEntries.map { (name, bytes) -> RawParsedEntry(name, bytes) }
        }

        // 2. Tolerant Raw PK\x03\x04 Local File Header + Central Directory Scanner
        val rawEntries = parseRawZipHeaders(zipBytes)
        if (rawEntries.isNotEmpty()) {
            // Merge any valid standard entries with raw entries
            val merged = LinkedHashMap<String, ByteArray>()
            standardEntries.forEach { (k, v) -> merged[k] = v }
            rawEntries.forEach { entry ->
                val existing = merged[entry.name]
                if (existing == null || entry.data.size > existing.size) {
                    merged[entry.name] = entry.data
                }
            }
            return merged.map { (name, bytes) -> RawParsedEntry(name, bytes) }
        }

        return standardEntries.map { (name, bytes) -> RawParsedEntry(name, bytes) }
    }

    /**
     * Re-packages a ZIP byte array into a 100% standard, pre-computed CRC-32 ZIP archive
     * (bit 3 Data Descriptor cleared, accurate sizes in Local File Header) so OEM File Managers
     * like Vivo File Manager never fail with "Unable to decompress".
     */
    fun normalizeZipBytes(zipBytes: ByteArray): ByteArray {
        val entries = parseEntriesTolerant(zipBytes)
        if (entries.isEmpty()) return zipBytes

        return try {
            val bos = ByteArrayOutputStream(zipBytes.size.coerceAtLeast(1024))
            ZipOutputStream(bos).use { zos ->
                val seenNames = HashSet<String>()
                for (item in entries) {
                    val safeName = item.name.ifBlank { "extracted_file" }
                    if (!seenNames.add(safeName)) continue

                    val payload = item.data
                    val crc = CRC32().apply { update(payload) }.value
                    // Use STORED for already-compressed .apk / .zip / media or small files so
                    // Local File Header always has exact pre-computed CRC-32 and sizes (no bit 3 flag!)
                    val useStored = safeName.endsWith(".apk", ignoreCase = true) ||
                        safeName.endsWith(".zip", ignoreCase = true) ||
                        safeName.endsWith(".png", ignoreCase = true) ||
                        safeName.endsWith(".jpg", ignoreCase = true)

                    val entry = ZipEntry(safeName).apply {
                        size = payload.size.toLong()
                        crc32 = crc
                        if (useStored) {
                            method = ZipEntry.STORED
                            compressedSize = payload.size.toLong()
                        } else {
                            method = ZipEntry.DEFLATED
                        }
                    }
                    zos.putNextEntry(entry)
                    zos.write(payload)
                    zos.closeEntry()
                }
            }
            bos.toByteArray()
        } catch (_: Exception) {
            zipBytes
        }
    }

    private var ZipEntry.crc32: Long
        get() = crc
        set(value) {
            crc = value
        }

    /**
     * Extracts all files inside a downloaded .zip URI directly into the user's download folder
     * so inner .apk or project files can be opened/installed directly without external decompression.
     */
    fun extractZipFromUri(
        context: Context,
        zipUri: Uri,
        destination: DownloadDestination = DownloadDestination()
    ): ZipExtractionSummary {
        val rawBytes = try {
            context.contentResolver.openInputStream(zipUri)?.use(InputStream::readBytes)
        } catch (_: Exception) {
            null
        } ?: return ZipExtractionSummary(emptyList())

        return extractZipBytesToDestination(context, rawBytes, destination)
    }

    fun extractZipBytesToDestination(
        context: Context,
        zipBytes: ByteArray,
        destination: DownloadDestination = DownloadDestination()
    ): ZipExtractionSummary {
        val entries = parseEntriesTolerant(zipBytes)
        if (entries.isEmpty()) return ZipExtractionSummary(emptyList())

        val extractedList = mutableListOf<ExtractedZipEntryResult>()
        var simulatedApkDetected = false

        for (entry in entries) {
            val baseFileName = File(entry.name).name.ifBlank { "extracted_file" }
            val isApk = baseFileName.endsWith(".apk", ignoreCase = true)
            val mime = guessMimeForFileName(baseFileName)
            val validApk = if (isApk) isLikelyValidApkBytes(entry.data) else true
            if (isApk && !validApk) {
                simulatedApkDetected = true
            }

            val savedUri = writeBytesToDestination(
                context = context,
                fileName = baseFileName,
                mimeType = mime,
                bytes = entry.data,
                destination = destination
            )
            if (savedUri != null) {
                extractedList.add(
                    ExtractedZipEntryResult(
                        fileName = baseFileName,
                        mimeType = mime,
                        savedUri = savedUri,
                        sizeBytes = entry.data.size.toLong(),
                        isValidApk = validApk
                    )
                )
            }
        }

        return ZipExtractionSummary(
            extractedFiles = extractedList,
            repairedCount = extractedList.size,
            containsSimulatedApk = simulatedApkDetected
        )
    }

    /**
     * Checks whether a byte array representing an .apk file is a real Android Package (ZIP container
     * starting with PK\x03\x04 and containing AndroidManifest.xml or classes.dex).
     */
    fun isLikelyValidApkBytes(bytes: ByteArray): Boolean {
        if (bytes.size < 64) return false
        val magic = ByteBuffer.wrap(bytes, 0, 4).order(ByteOrder.LITTLE_ENDIAN).int
        if (magic != LOCAL_FILE_HEADER_SIG) return false
        val asciiWindow = String(bytes, 0, bytes.size.coerceAtMost(256 * 1024), Charsets.ISO_8859_1)
        return asciiWindow.contains("AndroidManifest.xml") || asciiWindow.contains("classes.dex") || asciiWindow.contains("resources.arsc")
    }

    private fun parseRawZipHeaders(bytes: ByteArray): List<RawParsedEntry> {
        val results = mutableListOf<RawParsedEntry>()
        val centralSizes = parseCentralDirectoryCompressedSizes(bytes)

        val headerOffsets = mutableListOf<Int>()
        var idx = 0
        while (idx <= bytes.size - 30) {
            if (bytes[idx] == 0x50.toByte() &&
                bytes[idx + 1] == 0x4b.toByte() &&
                bytes[idx + 2] == 0x03.toByte() &&
                bytes[idx + 3] == 0x04.toByte()
            ) {
                headerOffsets.add(idx)
                idx += 30
            } else {
                idx++
            }
        }

        val firstCentralDirOffset = findFirstSignatureOffset(bytes, CENTRAL_DIR_HEADER_SIG)
            ?: findFirstSignatureOffset(bytes, END_OF_CENTRAL_DIR_SIG)
            ?: bytes.size

        for (i in headerOffsets.indices) {
            val offset = headerOffsets[i]
            if (offset + 30 > bytes.size) continue

            val buf = ByteBuffer.wrap(bytes, offset, 30).order(ByteOrder.LITTLE_ENDIAN)
            buf.int // signature
            buf.short // version needed
            val flags = buf.short.toInt() and 0xFFFF
            val method = buf.short.toInt() and 0xFFFF
            buf.short // mod time
            buf.short // mod date
            buf.int // crc32
            val compSizeHeader = buf.int.toLong() and 0xFFFFFFFFL
            val uncompSizeHeader = buf.int.toLong() and 0xFFFFFFFFL
            val nameLen = buf.short.toInt() and 0xFFFF
            val extraLen = buf.short.toInt() and 0xFFFF

            val nameStart = offset + 30
            val dataStart = nameStart + nameLen + extraLen
            if (nameStart + nameLen > bytes.size || dataStart > bytes.size) continue

            val rawName = String(bytes, nameStart, nameLen, Charsets.UTF_8)
            val cleanName = sanitizeEntryPath(rawName)
            if (cleanName.isBlank() || rawName.endsWith("/")) continue

            val nextBoundary = if (i + 1 < headerOffsets.size) {
                headerOffsets[i + 1]
            } else {
                firstCentralDirOffset.coerceAtLeast(dataStart)
            }
            val maxAvailable = (nextBoundary - dataStart).coerceAtLeast(0)
            if (maxAvailable <= 0) continue

            val centralHint = centralSizes[rawName] ?: centralSizes[cleanName]
            val candidateCompSize = when {
                compSizeHeader in 1..maxAvailable.toLong() -> compSizeHeader.toInt()
                centralHint != null && centralHint in 1..maxAvailable.toLong() -> centralHint.toInt()
                else -> trimTrailingDataDescriptor(bytes, dataStart, maxAvailable, flags)
            }

            val slice = bytes.copyOfRange(dataStart, dataStart + candidateCompSize)
            val extractedData = if (method == 8) {
                inflateTolerantOrFallbackRaw(slice, uncompSizeHeader)
            } else {
                slice
            }

            results.add(RawParsedEntry(cleanName, extractedData))
        }

        return results
    }

    private fun parseCentralDirectoryCompressedSizes(bytes: ByteArray): Map<String, Long> {
        val map = HashMap<String, Long>()
        var i = 0
        while (i <= bytes.size - 46) {
            if (bytes[i] == 0x50.toByte() &&
                bytes[i + 1] == 0x4b.toByte() &&
                bytes[i + 2] == 0x01.toByte() &&
                bytes[i + 3] == 0x02.toByte()
            ) {
                try {
                    val buf = ByteBuffer.wrap(bytes, i, 46).order(ByteOrder.LITTLE_ENDIAN)
                    buf.position(20)
                    val compSize = buf.int.toLong() and 0xFFFFFFFFL
                    buf.int // uncompSize
                    val nameLen = buf.short.toInt() and 0xFFFF
                    val extraLen = buf.short.toInt() and 0xFFFF
                    val commentLen = buf.short.toInt() and 0xFFFF
                    val namePos = i + 46
                    if (namePos + nameLen <= bytes.size) {
                        val name = String(bytes, namePos, nameLen, Charsets.UTF_8)
                        if (compSize > 0L) {
                            map[name] = compSize
                            map[sanitizeEntryPath(name)] = compSize
                        }
                    }
                    i = (namePos + nameLen + extraLen + commentLen).coerceAtLeast(i + 46)
                } catch (_: Exception) {
                    i++
                }
            } else {
                i++
            }
        }
        return map
    }

    private fun findFirstSignatureOffset(bytes: ByteArray, signatureLe: Int): Int? {
        val b0 = (signatureLe and 0xFF).toByte()
        val b1 = ((signatureLe ushr 8) and 0xFF).toByte()
        val b2 = ((signatureLe ushr 16) and 0xFF).toByte()
        val b3 = ((signatureLe ushr 24) and 0xFF).toByte()
        for (i in 0..bytes.size - 4) {
            if (bytes[i] == b0 && bytes[i + 1] == b1 && bytes[i + 2] == b2 && bytes[i + 3] == b3) {
                return i
            }
        }
        return null
    }

    private fun trimTrailingDataDescriptor(
        bytes: ByteArray,
        dataStart: Int,
        maxAvailable: Int,
        flags: Int
    ): Int {
        val hasDataDescriptor = (flags and 0x0008) != 0
        if (!hasDataDescriptor || maxAvailable <= 16) return maxAvailable
        val end = dataStart + maxAvailable
        val sigOffset = end - 16
        val sig = ByteBuffer.wrap(bytes, sigOffset, 4).order(ByteOrder.LITTLE_ENDIAN).int
        return if (sig == DATA_DESCRIPTOR_SIG) {
            maxAvailable - 16
        } else {
            maxAvailable
        }
    }

    private fun inflateTolerantOrFallbackRaw(compressed: ByteArray, expectedUncompressed: Long): ByteArray {
        val inflater = Inflater(true)
        return try {
            inflater.setInput(compressed)
            val out = ByteArrayOutputStream(
                expectedUncompressed.coerceIn(1024L, 32L * 1024L * 1024L).toInt()
            )
            val buffer = ByteArray(16 * 1024)
            while (!inflater.finished() && !inflater.needsInput()) {
                val count = inflater.inflate(buffer)
                if (count <= 0) break
                out.write(buffer, 0, count)
            }
            val result = out.toByteArray()
            if (result.isNotEmpty()) result else compressed
        } catch (_: Exception) {
            // If a web script marked uncompressed bytes as method=8 (Deflate), return raw bytes
            compressed
        } finally {
            inflater.end()
        }
    }

    private fun sanitizeEntryPath(rawPath: String): String {
        return rawPath
            .replace('\\', '/')
            .split('/')
            .filter { it.isNotBlank() && it != "." && it != ".." }
            .joinToString("/")
    }

    fun guessMimeForFileName(fileName: String): String {
        val lower = fileName.lowercase()
        return when {
            lower.endsWith(".apk") -> "application/vnd.android.package-archive"
            lower.endsWith(".zip") -> "application/zip"
            lower.endsWith(".pdf") -> "application/pdf"
            lower.endsWith(".json") -> "application/json"
            lower.endsWith(".png") -> "image/png"
            lower.endsWith(".jpg") || lower.endsWith(".jpeg") -> "image/jpeg"
            lower.endsWith(".mp4") -> "video/mp4"
            lower.endsWith(".mp3") -> "audio/mpeg"
            lower.endsWith(".txt") || lower.endsWith(".md") || lower.endsWith(".kt") -> "text/plain"
            else -> "application/octet-stream"
        }
    }
}
