package com.example

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.ActivityManager
import android.content.ComponentCallbacks2
import android.content.Context
import android.content.Intent
import android.content.MutableContextWrapper
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Message
import android.print.PrintAttributes
import android.print.PrintManager
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.RenderProcessGoneDetail
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import androidx.webkit.ProfileStore
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import com.example.data.BookmarkEntity
import com.example.data.BrowserDatabase
import com.example.data.BrowserPreferences
import com.example.data.BrowserRepository
import com.example.data.BrowserSettings
import com.example.data.DownloadEntity
import com.example.data.DownloadStatus
import com.example.data.InstalledWebAppEntity
import java.io.ByteArrayInputStream
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class PwaUiState(
    val pwaId: String,
    val appName: String,
    val url: String,
    val pageTitle: String,
    val progress: Int = 0,
    val isLoading: Boolean = true,
    val canGoBack: Boolean = false,
    val canGoForward: Boolean = false,
    val isDesktopMode: Boolean = false,
    val isSslSecure: Boolean = true,
    val isProfileIsolated: Boolean = false,
    val badgeColorHex: Long = 0xFF1A73E8L,
    val favicon: Bitmap? = null
)

data class PwaPoolStats(
    val livePwaIds: Set<String> = emptySet(),
    val liveCount: Int = 0,
    val maxSlotsByRam: Int = 4,
    val totalRamMb: Long = 0L,
    val availRamMb: Long = 0L,
    val isLowMemory: Boolean = false
)

object PwaShortcutHelper {

    const val ACTION_LAUNCH_PWA = "com.example.action.LAUNCH_PWA"
    const val EXTRA_PWA_ID = "extra_pwa_id"
    const val EXTRA_PWA_NAME = "extra_pwa_name"
    const val EXTRA_PWA_URL = "extra_pwa_url"
    const val EXTRA_IS_STANDALONE_PWA = "extra_is_standalone_pwa"
    const val EXTRA_IS_STANDALONE_PWA_STR = "extra_is_standalone_pwa_str"
    const val EXTRA_ISOLATED_PROFILE = "extra_isolated_profile"
    const val EXTRA_ISOLATED_PROFILE_STR = "extra_isolated_profile_str"
    const val EXTRA_PROFILE_NAME = "extra_profile_name"
    const val EXTRA_BADGE_COLOR = "extra_badge_color"
    const val EXTRA_BADGE_COLOR_STR = "extra_badge_color_str"
    const val EXTRA_BADGE_TAG = "extra_badge_tag"
    const val EXTRA_OPEN_IN_NEW_TAB = "extra_open_in_new_tab"
    const val EXTRA_REQUEST_PIN_ON_START = "extra_request_pin_on_start"

    val PRESET_BADGE_COLORS = listOf(
        0xFF1A73E8L, // Google Blue
        0xFF0F9D58L, // Emerald
        0xFF7B61FFL, // Electric Violet
        0xFFEA4335L, // Coral Red
        0xFFF59E0BL, // Warm Amber
        0xFF00ACC1L, // Cyan
        0xFFEC4899L, // Rose
        0xFF334155L  // Slate
    )

    fun generateUniquePwaId(): String {
        val rand = UUID.randomUUID().toString().replace("-", "").take(6)
        return "pwa_${System.currentTimeMillis()}_$rand"
    }

    fun suggestNextAppName(
        rawPageTitle: String?,
        url: String,
        existingApps: List<InstalledWebAppEntity>
    ): String {
        val hostFallback = try {
            Uri.parse(url).host?.removePrefix("www.")?.substringBefore(".")?.replaceFirstChar { it.uppercase() }
                ?: "Web App"
        } catch (_: Exception) {
            "Web App"
        }
        val base = rawPageTitle
            ?.replace(Regex("^Studio \\d+\\s*•\\s*"), "")
            ?.replace(Regex("^Tab \\d+\\s*•\\s*"), "")
            ?.trim()
            ?.takeIf { it.isNotBlank() && it != "New Tab" && it != "Incognito Tab" }
            ?: hostFallback

        val cleanBase = base.take(20).trim()
        val existingNames = existingApps.map { it.name.lowercase() }.toSet()
        if (!existingNames.contains(cleanBase.lowercase())) {
            return cleanBase
        }
        var index = 2
        while (existingNames.contains("$cleanBase $index".lowercase()) && index < 99) {
            index++
        }
        return "$cleanBase $index"
    }

    fun suggestNextBadgeTag(existingApps: List<InstalledWebAppEntity>, url: String): String {
        val sameHostCount = existingApps.count { app ->
            try {
                Uri.parse(app.url).host == Uri.parse(url).host
            } catch (_: Exception) {
                false
            }
        }
        return (sameHostCount + 1).toString()
    }

    fun buildLauncherIconBitmap(
        name: String,
        favicon: Bitmap?,
        badgeColorHex: Long,
        badgeTag: String,
        isStandalonePwa: Boolean
    ): Bitmap {
        val size = 192
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val accentInt = badgeColorHex.toInt()

        // Outer squircle background
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.FILL
        }
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentInt
            style = Paint.Style.STROKE
            strokeWidth = 10f
        }
        val rect = RectF(10f, 10f, size - 10f, size - 10f)
        canvas.drawRoundRect(rect, 44f, 44f, bgPaint)
        canvas.drawRoundRect(rect, 44f, 44f, borderPaint)

        // Center favicon or monogram
        if (favicon != null && !favicon.isRecycled) {
            try {
                val safeFavicon = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && favicon.config == Bitmap.Config.HARDWARE) {
                    favicon.copy(Bitmap.Config.ARGB_8888, false)
                } else {
                    favicon
                }
                val iconMargin = 42f
                val dst = RectF(iconMargin, iconMargin, size - iconMargin, size - iconMargin)
                val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
                canvas.drawBitmap(safeFavicon, null, dst, paint)
            } catch (_: Exception) {
                drawMonogramCenter(canvas, size, accentInt, name)
            }
        } else {
            drawMonogramCenter(canvas, size, accentInt, name)
        }

        // Distinct badge pill (so 5-10 PWAs of the same website are visually distinguishable)
        val tagText = badgeTag.trim().take(3).ifBlank { if (isStandalonePwa) "PWA" else "" }
        if (tagText.isNotEmpty()) {
            val badgeRadius = if (tagText.length > 2) 30f else 26f
            val cx = size - 36f
            val cy = size - 36f

            val haloPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                style = Paint.Style.FILL
            }
            canvas.drawCircle(cx, cy, badgeRadius + 5f, haloPaint)

            val badgeBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = accentInt
                style = Paint.Style.FILL
            }
            canvas.drawCircle(cx, cy, badgeRadius, badgeBgPaint)

            val tagPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = if (tagText.length > 2) 21f else 27f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
            }
            val tagY = cy - (tagPaint.descent() + tagPaint.ascent()) / 2f
            canvas.drawText(tagText, cx, tagY, tagPaint)
        }

        return bitmap
    }

    private fun drawMonogramCenter(canvas: Canvas, size: Int, accentInt: Int, name: String) {
        val circlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentInt
            style = Paint.Style.FILL
        }
        canvas.drawCircle(size / 2f, size / 2f, 52f, circlePaint)

        val letter = name.trim().firstOrNull()?.uppercase() ?: "W"
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 58f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        val yPos = size / 2f - (textPaint.descent() + textPaint.ascent()) / 2f
        canvas.drawText(letter, size / 2f, yPos, textPaint)
    }

    fun buildPwaDataUri(app: InstalledWebAppEntity): Uri {
        return Uri.Builder()
            .scheme("studiopwa")
            .authority("app")
            .appendPath(app.pwaId)
            .appendQueryParameter("name", app.name)
            .appendQueryParameter("url", app.url)
            .appendQueryParameter("standalone", app.isStandalonePwa.toString())
            .appendQueryParameter("isolated", app.isolatedProfile.toString())
            .appendQueryParameter("profile", app.profileName)
            .appendQueryParameter("color", app.badgeColorHex.toString())
            .appendQueryParameter("tag", app.badgeTag)
            .build()
    }

    fun extractEntityFromShortcutIntent(intent: Intent?): InstalledWebAppEntity? {
        if (intent == null) return null
        val dataUri = intent.data
        val isStudioPwaScheme = dataUri?.scheme.equals("studiopwa", ignoreCase = true)
        val hasPwaIdExtra = intent.hasExtra(EXTRA_PWA_ID)
        if (!isStudioPwaScheme && !hasPwaIdExtra) return null

        val pwaId = intent.getStringExtra(EXTRA_PWA_ID)
            ?: dataUri?.lastPathSegment
            ?: "pwa_default"
        val name = intent.getStringExtra(EXTRA_PWA_NAME)
            ?: dataUri?.getQueryParameter("name")
            ?: "Web App"
        val url = intent.getStringExtra(EXTRA_PWA_URL)
            ?: dataUri?.getQueryParameter("url")
            ?: WebViewManager.DEFAULT_HOME_URL
        val standalone = when {
            intent.hasExtra(EXTRA_IS_STANDALONE_PWA) ->
                intent.getBooleanExtra(EXTRA_IS_STANDALONE_PWA, true)
            intent.hasExtra(EXTRA_IS_STANDALONE_PWA_STR) ->
                intent.getStringExtra(EXTRA_IS_STANDALONE_PWA_STR)?.toBooleanStrictOrNull() ?: true
            else ->
                dataUri?.getQueryParameter("standalone")?.toBooleanStrictOrNull() ?: true
        }
        val isolated = when {
            intent.hasExtra(EXTRA_ISOLATED_PROFILE) ->
                intent.getBooleanExtra(EXTRA_ISOLATED_PROFILE, true)
            intent.hasExtra(EXTRA_ISOLATED_PROFILE_STR) ->
                intent.getStringExtra(EXTRA_ISOLATED_PROFILE_STR)?.toBooleanStrictOrNull() ?: true
            else ->
                dataUri?.getQueryParameter("isolated")?.toBooleanStrictOrNull() ?: true
        }
        val profileName = intent.getStringExtra(EXTRA_PROFILE_NAME)
            ?: dataUri?.getQueryParameter("profile")
            ?: if (isolated) "pwa_profile_$pwaId" else "Default"
        val colorFromStr = intent.getStringExtra(EXTRA_BADGE_COLOR_STR)?.toLongOrNull()
            ?: dataUri?.getQueryParameter("color")?.toLongOrNull()
        val badgeColor = if (intent.hasExtra(EXTRA_BADGE_COLOR)) {
            intent.getLongExtra(EXTRA_BADGE_COLOR, colorFromStr ?: 0xFF1A73E8L)
        } else {
            colorFromStr ?: 0xFF1A73E8L
        }
        val badgeTag = intent.getStringExtra(EXTRA_BADGE_TAG)
            ?: dataUri?.getQueryParameter("tag")
            ?: ""

        return InstalledWebAppEntity(
            pwaId = pwaId,
            name = name,
            url = url,
            isStandalonePwa = standalone,
            isolatedProfile = isolated,
            profileName = profileName,
            badgeColorHex = badgeColor,
            badgeTag = badgeTag
        )
    }

    fun buildLaunchIntent(
        context: Context,
        app: InstalledWebAppEntity,
        forShortcutPinning: Boolean = false
    ): Intent {
        if (forShortcutPinning) {
            // Always target MainActivity (the official MAIN + LAUNCHER activity) when pinning to the Home Screen
            // so 100% of Android & OEM launchers (Pixel, Samsung, Xiaomi HyperOS/MIUI, Vivo, Oppo/Realme) accept the shortcut.
            // MainActivity immediately routes standalone PWAs to PwaActivity or opens Web Shortcuts in a browser tab.
            return Intent(context.applicationContext, MainActivity::class.java).apply {
                action = Intent.ACTION_VIEW
                data = buildPwaDataUri(app)
                addCategory(Intent.CATEGORY_DEFAULT)
                addCategory(Intent.CATEGORY_BROWSABLE)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra(EXTRA_PWA_ID, app.pwaId)
                putExtra(EXTRA_PWA_NAME, app.name)
                putExtra(EXTRA_PWA_URL, app.url)
                putExtra(EXTRA_IS_STANDALONE_PWA, app.isStandalonePwa)
                putExtra(EXTRA_IS_STANDALONE_PWA_STR, app.isStandalonePwa.toString())
                putExtra(EXTRA_ISOLATED_PROFILE, app.isolatedProfile)
                putExtra(EXTRA_ISOLATED_PROFILE_STR, app.isolatedProfile.toString())
                putExtra(EXTRA_PROFILE_NAME, app.profileName)
                putExtra(EXTRA_BADGE_COLOR, app.badgeColorHex)
                putExtra(EXTRA_BADGE_COLOR_STR, app.badgeColorHex.toString())
                putExtra(EXTRA_BADGE_TAG, app.badgeTag)
                putExtra(EXTRA_OPEN_IN_NEW_TAB, true)
            }
        }

        return if (app.isStandalonePwa) {
            Intent(context, PwaActivity::class.java).apply {
                action = ACTION_LAUNCH_PWA
                data = buildPwaDataUri(app)
                addCategory(Intent.CATEGORY_DEFAULT)
                flags = Intent.FLAG_ACTIVITY_NEW_DOCUMENT or
                    Intent.FLAG_ACTIVITY_MULTIPLE_TASK or
                    Intent.FLAG_ACTIVITY_NEW_TASK
                putExtra(EXTRA_PWA_ID, app.pwaId)
                putExtra(EXTRA_PWA_NAME, app.name)
                putExtra(EXTRA_PWA_URL, app.url)
                putExtra(EXTRA_IS_STANDALONE_PWA, true)
                putExtra(EXTRA_IS_STANDALONE_PWA_STR, "true")
                putExtra(EXTRA_ISOLATED_PROFILE, app.isolatedProfile)
                putExtra(EXTRA_ISOLATED_PROFILE_STR, app.isolatedProfile.toString())
                putExtra(EXTRA_PROFILE_NAME, app.profileName)
                putExtra(EXTRA_BADGE_COLOR, app.badgeColorHex)
                putExtra(EXTRA_BADGE_COLOR_STR, app.badgeColorHex.toString())
                putExtra(EXTRA_BADGE_TAG, app.badgeTag)
            }
        } else {
            Intent(context, MainActivity::class.java).apply {
                action = Intent.ACTION_VIEW
                data = Uri.parse(app.url)
                addCategory(Intent.CATEGORY_DEFAULT)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                putExtra(EXTRA_OPEN_IN_NEW_TAB, true)
            }
        }
    }

    private fun unwrapActivityContext(context: Context): Activity? {
        var cur: Context? = context
        while (cur is android.content.ContextWrapper) {
            if (cur is Activity) return cur
            cur = cur.baseContext
        }
        return null
    }

    /**
     * Checks if Xiaomi MIUI/HyperOS or Vivo/Oppo AppOps explicitly blocks Home Screen shortcut creation (op 10017).
     */
    fun isOemShortcutPermissionDenied(context: Context): Boolean {
        val manufacturer = Build.MANUFACTURER?.lowercase() ?: ""
        if (!manufacturer.contains("xiaomi") &&
            !manufacturer.contains("redmi") &&
            !manufacturer.contains("poco")
        ) {
            return false
        }
        return try {
            val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as? android.app.AppOpsManager
                ?: return false
            val checkMethod = appOps.javaClass.getMethod(
                "checkOpNoThrow",
                Int::class.javaPrimitiveType,
                Int::class.javaPrimitiveType,
                String::class.java
            )
            val mode = checkMethod.invoke(
                appOps,
                10017, // OP_INSTALL_SHORTCUT on MIUI / HyperOS
                android.os.Process.myUid(),
                context.packageName
            ) as? Int
            mode == android.app.AppOpsManager.MODE_IGNORED || mode == android.app.AppOpsManager.MODE_ERRORED
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Opens the OEM "Home screen shortcuts" permission screen (Xiaomi MIUI/HyperOS, Vivo, Oppo/Realme, or App Info).
     */
    fun openOemShortcutPermissionSettings(context: Context) {
        val starter = unwrapActivityContext(context)
            ?: WebViewManager.getInstanceIfCreated()?.currentActivity
            ?: context
        val pkg = context.packageName
        val candidateIntents = listOf(
            Intent("miui.intent.action.APP_PERM_EDITOR").apply {
                setClassName("com.miui.securitycenter", "com.miui.permcenter.permissions.PermissionsEditorActivity")
                putExtra("extra_pkgname", pkg)
            },
            Intent("miui.intent.action.APP_PERM_EDITOR").apply {
                setClassName("com.miui.securitycenter", "com.miui.permcenter.permissions.AppPermissionsEditorActivity")
                putExtra("extra_pkgname", pkg)
            },
            Intent("com.oppo.safe.permission.PermissionSettingsActivity").apply {
                putExtra("package", pkg)
            },
            Intent("permission.intent.action.softPermissionDetail").apply {
                putExtra("packagename", pkg)
            },
            Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.fromParts("package", pkg, null)
            }
        )
        for (intent in candidateIntents) {
            try {
                if (starter !is Activity) {
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                starter.startActivity(intent)
                return
            } catch (_: Exception) {
            }
        }
    }

    fun pinToHomeScreen(
        context: Context,
        app: InstalledWebAppEntity,
        favicon: Bitmap?
    ): Boolean {
        val targetContext: Context = unwrapActivityContext(context)
            ?: WebViewManager.getInstanceIfCreated()?.currentActivity
            ?: context
        val appContext = targetContext.applicationContext
        val mainActivityComponent = android.content.ComponentName(appContext, MainActivity::class.java)

        val iconBitmap = buildLauncherIconBitmap(
            name = app.name,
            favicon = favicon,
            badgeColorHex = app.badgeColorHex,
            badgeTag = app.badgeTag,
            isStandalonePwa = app.isStandalonePwa
        )
        val launchIntent = buildLaunchIntent(targetContext, app, forShortcutPinning = true)
        val baseShortcutId = if (app.isStandalonePwa) "pwa_${app.pwaId}" else "sc_${app.pwaId}"
        val shortLabel = app.name.trim().take(24).ifBlank { "Web App" }
        val longLabel = app.name.trim().take(48).ifBlank { shortLabel }

        // Check if baseShortcutId is already pinned; if so, update it AND use a fresh unique ID for the new pin request
        // so Android ShortcutService never rejects re-pinning an existing shortcut ID.
        var pinShortcutId = baseShortcutId
        try {
            val existingPinned = ShortcutManagerCompat.getShortcuts(
                targetContext,
                ShortcutManagerCompat.FLAG_MATCH_PINNED or ShortcutManagerCompat.FLAG_MATCH_CACHED
            )
            if (existingPinned.any { it.id == baseShortcutId }) {
                val updatedBase = ShortcutInfoCompat.Builder(targetContext, baseShortcutId)
                    .setActivity(mainActivityComponent)
                    .setShortLabel(shortLabel)
                    .setLongLabel(longLabel)
                    .setIcon(IconCompat.createWithBitmap(iconBitmap))
                    .setIntent(launchIntent)
                    .build()
                ShortcutManagerCompat.updateShortcuts(targetContext, listOf(updatedBase))
                pinShortcutId = "${baseShortcutId}_${System.currentTimeMillis() % 100000}"
            }
        } catch (_: Exception) {
        }

        val pinShortcutInfo = ShortcutInfoCompat.Builder(targetContext, pinShortcutId)
            .setActivity(mainActivityComponent)
            .setShortLabel(shortLabel)
            .setLongLabel(longLabel)
            .setIcon(IconCompat.createWithBitmap(iconBitmap))
            .setIntent(launchIntent)
            .build()

        // 1. Primary modern pin path via ShortcutManagerCompat & native ShortcutManager
        var pinned = false
        try {
            if (ShortcutManagerCompat.isRequestPinShortcutSupported(targetContext)) {
                pinned = ShortcutManagerCompat.requestPinShortcut(targetContext, pinShortcutInfo, null)
            }
        } catch (_: Exception) {
        }

        if (!pinned && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                val sm = targetContext.getSystemService(android.content.pm.ShortcutManager::class.java)
                if (sm != null && sm.isRequestPinShortcutSupported) {
                    pinned = sm.requestPinShortcut(pinShortcutInfo.toShortcutInfo(), null)
                }
            } catch (_: Exception) {
            }
        }

        // 2. Also send legacy INSTALL_SHORTCUT broadcast for OEM/custom launchers that listen to broadcast intents
        var broadcastSent = false
        if (!pinned) {
            try {
                @Suppress("DEPRECATION")
                val legacyInstallIntent = Intent("com.android.launcher.action.INSTALL_SHORTCUT").apply {
                    putExtra(Intent.EXTRA_SHORTCUT_INTENT, launchIntent)
                    putExtra(Intent.EXTRA_SHORTCUT_NAME, shortLabel)
                    putExtra(Intent.EXTRA_SHORTCUT_ICON, iconBitmap)
                    putExtra("duplicate", false)
                }
                targetContext.sendBroadcast(legacyInstallIntent)
                broadcastSent = true
            } catch (_: Exception) {
            }
        }

        // 3. Register in dynamic app shortcuts (long-press on Flowra icon) using a separate dynamic ID
        // so it never collides with requestPinShortcut.
        var dynamicPushed = false
        try {
            val dynamicId = "dyn_${app.pwaId}"
            val maxAllowed = ShortcutManagerCompat.getMaxShortcutCountPerActivity(targetContext).coerceAtLeast(4)
            val existingDynamic = ShortcutManagerCompat.getDynamicShortcuts(targetContext)
            if (existingDynamic.size >= (maxAllowed - 1).coerceAtLeast(2)) {
                val toRemove = existingDynamic
                    .filter { it.id != dynamicId }
                    .take((existingDynamic.size - maxAllowed + 2).coerceAtLeast(1))
                    .map { it.id }
                if (toRemove.isNotEmpty()) {
                    ShortcutManagerCompat.removeDynamicShortcuts(targetContext, toRemove)
                }
            }
            val dynamicShortcutInfo = ShortcutInfoCompat.Builder(targetContext, dynamicId)
                .setActivity(mainActivityComponent)
                .setShortLabel(shortLabel)
                .setLongLabel(longLabel)
                .setIcon(IconCompat.createWithBitmap(iconBitmap))
                .setIntent(launchIntent)
                .build()
            dynamicPushed = ShortcutManagerCompat.pushDynamicShortcut(targetContext, dynamicShortcutInfo)
        } catch (_: Exception) {
        }

        // 4. If Xiaomi/MIUI/HyperOS explicitly blocked OP_INSTALL_SHORTCUT (10017), prompt and open permission settings
        if (isOemShortcutPermissionDenied(targetContext)) {
            Toast.makeText(
                targetContext,
                "হোম স্ক্রিনে শর্টকাট যোগ করতে 'Home screen shortcuts' পারমিশনটি Allow করে দিন",
                Toast.LENGTH_LONG
            ).show()
            openOemShortcutPermissionSettings(targetContext)
        }

        return pinned || broadcastSent || dynamicPushed
    }

    fun launchWebApp(
        context: Context,
        app: InstalledWebAppEntity,
        requestPinOnStart: Boolean = false
    ) {
        try {
            val intent = buildLaunchIntent(context, app, forShortcutPinning = false).apply {
                if (requestPinOnStart) {
                    putExtra(EXTRA_REQUEST_PIN_ON_START, true)
                }
            }
            val starter = unwrapActivityContext(context)
                ?: WebViewManager.getInstanceIfCreated()?.currentActivity
                ?: context
            starter.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Unable to open ${app.name}: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun isMultiProfileSupported(): Boolean {
        return try {
            WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)
        } catch (_: Exception) {
            false
        }
    }

    fun deleteIsolatedProfile(profileName: String) {
        if (profileName.isBlank() || profileName == "Default") return
        try {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
                ProfileStore.getInstance().deleteProfile(profileName)
            }
        } catch (_: Exception) {
        }
    }
}

class PwaSessionController(
    private val appContext: Context,
    val app: InstalledWebAppEntity
) {
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mainScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val repository = BrowserRepository(BrowserDatabase.getInstance(appContext))
    val preferences = BrowserPreferences(appContext)
    private val contextWrapper = MutableContextWrapper(appContext)
    private val userMediaUnlocked = MutableStateFlow(false)

    @Volatile
    private var currentDestination = DownloadDestination()

    @Volatile
    var askBeforeDownload: Boolean = true
        private set

    private val _uiState = MutableStateFlow(
        PwaUiState(
            pwaId = app.pwaId,
            appName = app.name,
            url = app.url,
            pageTitle = app.name,
            isSslSecure = app.url.startsWith("https://"),
            badgeColorHex = app.badgeColorHex
        )
    )
    val uiState: StateFlow<PwaUiState> = _uiState.asStateFlow()

    private val _oauthPopupState = MutableStateFlow<OAuthPopupSession?>(null)
    val oauthPopupState: StateFlow<OAuthPopupSession?> = _oauthPopupState.asStateFlow()

    private val _pendingDownload = MutableStateFlow<PendingDownloadRequest?>(null)
    val pendingDownload: StateFlow<PendingDownloadRequest?> = _pendingDownload.asStateFlow()

    private val _findInPageState = MutableStateFlow(FindInPageState())
    val findInPageState: StateFlow<FindInPageState> = _findInPageState.asStateFlow()

    private var currentActivity: Activity? = null
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var activeFileChooserSession: ChromeFileChooserSession? = null
    var onLaunchFileChooser: ((Intent) -> Boolean)? = null
    var onRequestRuntimePermissions: ((Array<String>, (Boolean) -> Unit) -> Unit)? = null

    private var cookieManager: CookieManager = CookieManager.getInstance()
    private var isolatedProfileActive: Boolean = false

    private val downloadBridge: StudioDownloadBridge = StudioDownloadBridge(
        context = appContext,
        repository = repository,
        onPendingDownloadFromJs = { url, suggestedName, mimeType, contentLength, pageUrl ->
            mainScope.launch {
                val req = PendingDownloadRequest(
                    url = url,
                    userAgent = WebViewManager.MOBILE_CHROME_USER_AGENT,
                    contentDisposition = "",
                    mimeType = mimeType,
                    contentLength = contentLength,
                    suggestedFileName = suggestedName,
                    defaultDestination = currentDestination,
                    refererUrl = pageUrl.ifBlank { _uiState.value.url }
                )
                if (askBeforeDownload) {
                    _pendingDownload.value = req
                } else {
                    executeDownload(req, suggestedName, currentDestination)
                }
            }
        },
        onUpgradePendingDownload = { url, upgradedFileName, upgradedMimeType, contentLength ->
            mainScope.launch {
                _pendingDownload.update { current ->
                    if (current != null && current.url == url) {
                        current.copy(
                            suggestedFileName = upgradedFileName.ifBlank { current.suggestedFileName },
                            mimeType = upgradedMimeType.ifBlank { current.mimeType },
                            contentLength = if (contentLength > 0L) contentLength else current.contentLength
                        )
                    } else {
                        current
                    }
                }
            }
        },
        onBase64Saved = { fileName, url, mimeType, uriStr, sizeBytes, folderLabel ->
            ioScope.launch {
                repository.insertDownload(
                    DownloadEntity(
                        systemDownloadId = -1L,
                        fileName = fileName,
                        url = url,
                        mimeType = mimeType,
                        localUri = uriStr,
                        status = DownloadStatus.SUCCESSFUL,
                        totalBytes = sizeBytes,
                        downloadedBytes = sizeBytes,
                        saveFolderLabel = folderLabel
                    )
                )
            }
        }
    )

    var webView: UnthrottledWebView = createPwaWebView()
        private set

    private val _webViewGeneration = MutableStateFlow(0)
    val webViewGeneration: StateFlow<Int> = _webViewGeneration.asStateFlow()

    @Volatile
    private var currentSettings = BrowserSettings()

    init {
        ioScope.launch {
            try {
                preferences.settingsFlow.collectLatest { latest ->
                    currentSettings = latest
                    askBeforeDownload = latest.askBeforeDownload
                    currentDestination = DownloadDestination(
                        preset = DownloadFolderPreset.fromId(latest.downloadFolderPreset),
                        customTreeUri = latest.customDownloadTreeUri,
                        customFolderLabel = latest.customDownloadFolderLabel
                    )
                    mainScope.launch {
                        if (webView.settings.textZoom != latest.textZoomPercent) {
                            webView.settings.textZoom = latest.textZoomPercent
                        }
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            webView.settings.isAlgorithmicDarkeningAllowed = latest.darkWebPages
                        }
                    }
                }
            } catch (_: Exception) {
            }
        }
        webView.loadUrl(app.url)
    }

    fun attachActivity(activity: Activity) {
        currentActivity = activity
        contextWrapper.baseContext = activity
        if (webView.visibility != View.VISIBLE) {
            webView.visibility = View.VISIBLE
        }
        webView.onResume()
        webView.resumeTimers()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                webView.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false)
            } catch (_: Exception) {
            }
        }
        PwaWebViewPool.markForeground(app.pwaId, isForeground = true)
        injectAntiThrottleJavaScript(isActive = true)
    }

    fun detachActivity(activity: Activity) {
        if (currentActivity === activity) {
            currentActivity = null
            contextWrapper.baseContext = appContext
        }
        PwaWebViewPool.markForeground(app.pwaId, isForeground = false)
        flushCookies()
    }

    fun pulseKeepAlive(isForeground: Boolean) {
        try {
            if (webView.visibility != View.VISIBLE) {
                webView.visibility = View.VISIBLE
            }
            webView.resumeTimers()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                webView.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false)
            }
            if (!isForeground) {
                webView.evaluateJavascript("window.__studioTabIsActive=false;", null)
            }
        } catch (_: Exception) {
        }
    }

    private fun injectAntiThrottleJavaScript(isActive: Boolean) {
        try {
            val stateJs = "window.__studioTabIsActive = $isActive;"
            webView.evaluateJavascript("$stateJs\n${WebViewManager.PAGE_VISIBILITY_OVERRIDE_JS}", null)
        } catch (_: Exception) {
        }
    }

    fun reloadOrStop() {
        if (_uiState.value.isLoading) {
            webView.stopLoading()
            _uiState.update { it.copy(isLoading = false, progress = 100) }
        } else {
            webView.reload()
        }
    }

    fun goBack(): Boolean {
        return if (webView.canGoBack()) {
            webView.goBack()
            true
        } else {
            false
        }
    }

    fun goForward(): Boolean {
        return if (webView.canGoForward()) {
            webView.goForward()
            true
        } else {
            false
        }
    }

    fun goHome() {
        webView.loadUrl(app.url)
    }

    fun toggleDesktopMode() {
        val next = !_uiState.value.isDesktopMode
        webView.settings.userAgentString = if (next) {
            WebViewManager.DESKTOP_CHROME_USER_AGENT
        } else {
            WebViewManager.MOBILE_CHROME_USER_AGENT
        }
        _uiState.update { it.copy(isDesktopMode = next) }
        webView.reload()
    }

    fun bookmarkCurrentPage() {
        val state = _uiState.value
        ioScope.launch {
            repository.addOrUpdateBookmark(
                BookmarkEntity(
                    title = state.pageTitle.ifBlank { state.appName },
                    url = state.url,
                    isSpeedDial = false
                )
            )
            mainScope.launch {
                Toast.makeText(currentActivity ?: appContext, "Bookmarked offline in Room DB", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun showFindInPage() {
        _findInPageState.update { it.copy(isVisible = true) }
    }

    fun updateFindQuery(query: String) {
        _findInPageState.update { it.copy(query = query) }
        if (query.isBlank()) {
            webView.clearMatches()
            _findInPageState.update { it.copy(activeMatchIndex = 0, totalMatches = 0) }
        } else {
            webView.findAllAsync(query)
        }
    }

    fun findNextMatch(forward: Boolean) {
        webView.findNext(forward)
    }

    fun clearFindInPage() {
        webView.clearMatches()
        _findInPageState.value = FindInPageState()
    }

    fun updateAskBeforeDownload(ask: Boolean) {
        askBeforeDownload = ask
        ioScope.launch {
            preferences.setAskBeforeDownload(ask)
        }
    }

    fun savePreferredDestination(destination: DownloadDestination) {
        currentDestination = destination
        ioScope.launch {
            preferences.setDownloadDestination(
                preset = destination.preset.name,
                customTreeUri = destination.customTreeUri,
                customFolderLabel = destination.customFolderLabel
            )
        }
    }

    fun confirmPendingDownload(
        customName: String,
        destination: DownloadDestination = currentDestination
    ) {
        val req = _pendingDownload.value ?: return
        _pendingDownload.value = null
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            !DeviceAccessHelper.isNotificationsGranted(appContext)
        ) {
            onRequestRuntimePermissions?.invoke(arrayOf(Manifest.permission.POST_NOTIFICATIONS)) {}
        }
        savePreferredDestination(destination)
        executeDownload(req, customName.ifBlank { req.suggestedFileName }, destination)
    }

    fun dismissPendingDownload() {
        val req = _pendingDownload.value
        _pendingDownload.value = null
        if (req != null && (req.url.startsWith("blob:") || req.url.startsWith("data:"))) {
            downloadBridge.discardPreStagedBlob(req.url)
        }
    }

    private fun executeDownload(
        req: PendingDownloadRequest,
        finalName: String,
        destination: DownloadDestination
    ) {
        val url = req.url
        if (url.startsWith("blob:") || url.startsWith("data:")) {
            downloadBridge.confirmStagedOrExecuteBlobDownload(
                blobOrDataUrl = url,
                customFileName = finalName,
                mimeType = req.mimeType,
                destination = destination,
                fallbackWebView = webView
            )
            Toast.makeText(
                currentActivity ?: appContext,
                "Downloading $finalName to ${destination.displayLabel()}...",
                Toast.LENGTH_SHORT
            ).show()
            return
        }
        DownloadHelper.launchBackgroundHttpDownload(
            context = appContext,
            repository = repository,
            url = url,
            fileName = finalName,
            mimeType = req.mimeType,
            userAgent = req.userAgent,
            destination = destination,
            refererUrl = req.refererUrl
        )
        mainScope.launch {
            Toast.makeText(
                currentActivity ?: appContext,
                "Downloading $finalName in background (${destination.displayLabel()})...",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    fun printPage() {
        val activity = currentActivity ?: return
        try {
            val printManager = activity.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return
            val jobName = "${_uiState.value.appName.take(40)} - PWA"
            val adapter = webView.createPrintDocumentAdapter(jobName)
            printManager.print(jobName, adapter, PrintAttributes.Builder().build())
        } catch (_: Exception) {
        }
    }

    fun clearThisPwaSession() {
        try {
            cookieManager.removeAllCookies {
                ioScope.launch {
                    try {
                        cookieManager.flush()
                    } catch (_: Exception) {
                    }
                }
            }
            if (!isolatedProfileActive) {
                WebStorage.getInstance().deleteAllData()
            }
            webView.clearCache(true)
            webView.clearHistory()
            webView.clearFormData()
            webView.loadUrl(app.url)
            Toast.makeText(currentActivity ?: appContext, "Cleared session for ${app.name}", Toast.LENGTH_SHORT).show()
        } catch (_: Exception) {
        }
    }

    fun closeOAuthPopup() {
        val session = _oauthPopupState.value ?: return
        _oauthPopupState.value = null
        try {
            val popupView = session.popupWebView
            (popupView.parent as? ViewGroup)?.removeView(popupView)
            if (popupView is UnthrottledWebView) popupView.allowExplicitDestroy = true
            popupView.stopLoading()
            popupView.destroy()
        } catch (_: Exception) {
        }
        flushCookies()
    }

    fun flushCookies() {
        ioScope.launch {
            try {
                cookieManager.flush()
            } catch (_: Exception) {
            }
        }
    }

    fun onFileChooserResult(resultCode: Int, data: Intent?) {
        val callback = filePathCallback ?: return
        val session = activeFileChooserSession
        filePathCallback = null
        activeFileChooserSession = null
        val uris = DeviceAccessHelper.resolveFileChooserResult(
            context = currentActivity ?: appContext,
            resultCode = resultCode,
            data = data,
            session = session
        )
        callback.onReceiveValue(uris)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createPwaWebView(): UnthrottledWebView {
        val wv = UnthrottledWebView(contextWrapper).apply {
            setLayerType(View.LAYER_TYPE_NONE, null)
            isFocusable = true
            isFocusableInTouchMode = true
            keepScreenOn = true
            isNestedScrollingEnabled = true
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
            scrollBarStyle = View.SCROLLBARS_INSIDE_OVERLAY
            isVerticalScrollBarEnabled = true
            onUserTap = {
                userMediaUnlocked.value = true
                try {
                    evaluateJavascript("window.__studioUserMediaUnlocked = true;", null)
                } catch (_: Exception) {
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false)
                importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_YES
            }
        }

        // Apply isolated Chromium WebView Profile per PWA when supported
        if (app.isolatedProfile && WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            try {
                val profile = ProfileStore.getInstance().getOrCreateProfile(app.profileName)
                WebViewCompat.setProfile(wv, app.profileName)
                cookieManager = profile.cookieManager
                isolatedProfileActive = true
            } catch (_: Exception) {
                cookieManager = CookieManager.getInstance()
                isolatedProfileActive = false
            }
        }
        _uiState.update { it.copy(isProfileIsolated = isolatedProfileActive) }

        configurePwaWebSettings(wv, isDesktop = false)
        wv.addJavascriptInterface(downloadBridge, "StudioDownloadBridge")
        try {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
                WebViewCompat.addDocumentStartJavaScript(
                    wv,
                    WebViewManager.PAGE_VISIBILITY_OVERRIDE_JS,
                    setOf("*")
                )
            }
        } catch (_: Exception) {
        }

        wv.setFindListener { activeOrdinal, total, _ ->
            _findInPageState.update {
                it.copy(
                    activeMatchIndex = if (total > 0) activeOrdinal + 1 else 0,
                    totalMatches = total
                )
            }
        }

        wv.setDownloadListener(
            DownloadListener { url, userAgent, contentDisposition, mimeType, contentLength ->
                if (url.isNullOrBlank()) return@DownloadListener
                downloadBridge.markDownloadListenerClaimed(url)
                val referer = wv.url?.takeIf { it.isNotBlank() } ?: _uiState.value.url
                val blobMeta = downloadBridge.getRegisteredBlobMetadata(url)
                val rawMime = when {
                    !blobMeta?.mimeType.isNullOrBlank() &&
                        !blobMeta!!.mimeType.equals("text/plain", ignoreCase = true) &&
                        !blobMeta.mimeType.equals("application/octet-stream", ignoreCase = true) ->
                        blobMeta.mimeType
                    else -> mimeType ?: "application/octet-stream"
                }
                val suggestedName = DownloadHelper.guessName(
                    url = url,
                    contentDisposition = contentDisposition,
                    mimeType = rawMime,
                    registeredBlobName = downloadBridge.getRegisteredBlobName(url),
                    registeredBlobMeta = blobMeta,
                    refererUrl = referer
                )
                val resolvedMime = resolveAccurateMimeType(
                    fileName = suggestedName,
                    rawMimeType = rawMime,
                    magicHex = blobMeta?.magicHex
                )
                val effectiveLength = if (contentLength > 0L) contentLength else (blobMeta?.sizeBytes ?: -1L)
                val req = PendingDownloadRequest(
                    url = url,
                    userAgent = userAgent ?: WebViewManager.MOBILE_CHROME_USER_AGENT,
                    contentDisposition = contentDisposition ?: "",
                    mimeType = resolvedMime,
                    contentLength = effectiveLength,
                    suggestedFileName = suggestedName,
                    defaultDestination = currentDestination,
                    refererUrl = referer
                )
                if ((url.startsWith("blob:") || url.startsWith("data:")) &&
                    !downloadBridge.hasStagedOrActiveBlob(url)
                ) {
                    val preStageScript = DownloadHelper.buildBlobOrDataExtractionScript(
                        blobOrDataUrl = url,
                        suggestedName = suggestedName,
                        mimeType = resolvedMime,
                        destination = currentDestination,
                        preStageOnly = true
                    )
                    wv.evaluateJavascript(preStageScript, null)
                }
                if (askBeforeDownload) {
                    _pendingDownload.value = req
                } else {
                    executeDownload(req, suggestedName, currentDestination)
                }
            }
        )

        wv.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val headers = request.requestHeaders
                val fetchDest = headers?.get("Sec-Fetch-Dest") ?: headers?.get("sec-fetch-dest")
                val accept = headers?.get("Accept") ?: headers?.get("accept") ?: ""
                val path = request.url?.path?.lowercase() ?: ""
                val isVideo = fetchDest.equals("video", ignoreCase = true) ||
                    accept.startsWith("video/", ignoreCase = true) ||
                    listOf(".mp4", ".webm", ".m4v", ".mov", ".ogv", ".m3u8", ".mpd").any { path.endsWith(it) }
                if (isVideo && !userMediaUnlocked.value) {
                    val host = request.url?.host?.lowercase() ?: ""
                    val isVideoHost = host.contains("youtube.com") || host.contains("googlevideo.com") || host.contains("vimeo.com")
                    if (!isVideoHost) {
                        return WebResourceResponse("text/plain", "UTF-8", 204, "Deferred Video", emptyMap(), ByteArrayInputStream(ByteArray(0)))
                    }
                }
                return super.shouldInterceptRequest(view, request)
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url ?: return false
                val scheme = uri.scheme?.lowercase() ?: return false
                if (scheme == "http" || scheme == "https") return false
                return try {
                    (currentActivity ?: appContext).startActivity(
                        Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                    true
                } catch (_: Exception) {
                    true
                }
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                val safeUrl = url ?: app.url
                val host = try { Uri.parse(safeUrl).host?.lowercase().orEmpty() } catch (_: Exception) { "" }
                userMediaUnlocked.value = host.contains("youtube.com") || host.contains("vimeo.com")
                _uiState.update {
                    it.copy(
                        url = safeUrl,
                        progress = 15,
                        isLoading = true,
                        isSslSecure = safeUrl.startsWith("https://"),
                        canGoBack = view.canGoBack(),
                        canGoForward = view.canGoForward()
                    )
                }
                if (safeUrl.startsWith("http")) {
                    ioScope.launch {
                        repository.recordHistory(
                            title = "${app.name} • ${_uiState.value.pageTitle.ifBlank { safeUrl }}",
                            url = safeUrl
                        )
                    }
                }
                injectAntiThrottleJavaScript(isActive = currentActivity != null)
            }

            override fun doUpdateVisitedHistory(view: WebView, url: String?, isReload: Boolean) {
                super.doUpdateVisitedHistory(view, url, isReload)
                val safeUrl = url ?: view.url ?: return
                val resolvedTitle = view.title?.takeIf { t -> t.isNotBlank() }
                _uiState.update {
                    it.copy(
                        url = safeUrl,
                        pageTitle = resolvedTitle ?: it.pageTitle,
                        isSslSecure = safeUrl.startsWith("https://"),
                        canGoBack = view.canGoBack(),
                        canGoForward = view.canGoForward()
                    )
                }
                if (safeUrl.startsWith("http")) {
                    ioScope.launch {
                        repository.recordHistory(
                            title = "${app.name} • ${resolvedTitle ?: _uiState.value.pageTitle.ifBlank { safeUrl }}",
                            url = safeUrl
                        )
                    }
                }
            }

            override fun onPageFinished(view: WebView, url: String?) {
                super.onPageFinished(view, url)
                val safeUrl = url ?: view.url ?: app.url
                val resolvedTitle = view.title?.takeIf { t -> t.isNotBlank() }
                _uiState.update {
                    it.copy(
                        url = safeUrl,
                        pageTitle = resolvedTitle ?: it.pageTitle,
                        progress = 100,
                        isLoading = false,
                        isSslSecure = safeUrl.startsWith("https://"),
                        canGoBack = view.canGoBack(),
                        canGoForward = view.canGoForward()
                    )
                }
                if (safeUrl.startsWith("http")) {
                    ioScope.launch {
                        repository.recordHistory(
                            title = "${app.name} • ${resolvedTitle ?: safeUrl}",
                            url = safeUrl
                        )
                    }
                }
                injectAntiThrottleJavaScript(isActive = true)
                flushCookies()
            }

            override fun onRenderProcessGone(
                view: WebView?,
                detail: RenderProcessGoneDetail?
            ): Boolean {
                recoverFromRendererCrash(view)
                return true
            }
        }

        wv.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                super.onProgressChanged(view, newProgress)
                _uiState.update {
                    it.copy(
                        progress = newProgress,
                        isLoading = newProgress < 100
                    )
                }
            }

            override fun onReceivedTitle(view: WebView, title: String?) {
                super.onReceivedTitle(view, title)
                if (!title.isNullOrBlank()) {
                    _uiState.update { it.copy(pageTitle = title) }
                    val currentUrl = view.url ?: _uiState.value.url
                    if (currentUrl.startsWith("http")) {
                        ioScope.launch {
                            repository.recordHistory(
                                title = "${app.name} • $title",
                                url = currentUrl
                            )
                        }
                    }
                }
            }

            override fun onReceivedIcon(view: WebView, icon: Bitmap?) {
                super.onReceivedIcon(view, icon)
                if (icon != null) {
                    _uiState.update { it.copy(favicon = icon) }
                }
            }

            override fun onCreateWindow(
                view: WebView,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: Message?
            ): Boolean {
                val transport = resultMsg?.obj as? WebView.WebViewTransport ?: return false
                val popupWebView = UnthrottledWebView(MutableContextWrapper(currentActivity ?: appContext)).apply {
                    setLayerType(View.LAYER_TYPE_NONE, null)
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
                if (isolatedProfileActive && WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
                    try {
                        WebViewCompat.setProfile(popupWebView, app.profileName)
                    } catch (_: Exception) {
                    }
                }
                configurePwaWebSettings(popupWebView, isDesktop = _uiState.value.isDesktopMode)
                popupWebView.webViewClient = object : WebViewClient() {
                    override fun onPageStarted(popupView: WebView, url: String?, favicon: Bitmap?) {
                        _oauthPopupState.update { it?.copy(url = url ?: it.url, isLoading = true) }
                    }

                    override fun onPageFinished(popupView: WebView, url: String?) {
                        flushCookies()
                        _oauthPopupState.update {
                            it?.copy(
                                url = url ?: popupView.url ?: it.url,
                                title = popupView.title?.takeIf { t -> t.isNotBlank() } ?: it.title,
                                isLoading = false,
                                progress = 100
                            )
                        }
                    }

                    override fun onRenderProcessGone(
                        view: WebView?,
                        detail: RenderProcessGoneDetail?
                    ): Boolean {
                        closeOAuthPopup()
                        return true
                    }
                }
                popupWebView.webChromeClient = object : WebChromeClient() {
                    override fun onProgressChanged(popupView: WebView, newProgress: Int) {
                        _oauthPopupState.update { it?.copy(progress = newProgress, isLoading = newProgress < 100) }
                    }

                    override fun onCloseWindow(window: WebView?) {
                        flushCookies()
                        closeOAuthPopup()
                    }

                    override fun onShowFileChooser(
                        webView: WebView,
                        filePathCallback: ValueCallback<Array<Uri>>,
                        fileChooserParams: FileChooserParams
                    ): Boolean {
                        return handleFileChooser(filePathCallback, fileChooserParams)
                    }

                    override fun onPermissionRequest(request: PermissionRequest?) {
                        if (request != null) handleWebPermissions(request)
                    }

                    override fun onGeolocationPermissionsShowPrompt(
                        origin: String?,
                        callback: GeolocationPermissions.Callback?
                    ) {
                        DeviceAccessHelper.handleGeolocationPermissionRequest(
                            context = appContext,
                            origin = origin,
                            callback = callback,
                            onRequestRuntimePermissions = onRequestRuntimePermissions
                        )
                    }
                }
                _oauthPopupState.value = OAuthPopupSession(
                    parentTabId = 0,
                    popupWebView = popupWebView
                )
                transport.webView = popupWebView
                resultMsg.sendToTarget()
                return true
            }

            override fun onShowFileChooser(
                webView: WebView,
                filePathCallback: ValueCallback<Array<Uri>>,
                fileChooserParams: FileChooserParams
            ): Boolean {
                return handleFileChooser(filePathCallback, fileChooserParams)
            }

            override fun onPermissionRequest(request: PermissionRequest?) {
                if (request != null) handleWebPermissions(request)
            }

            override fun onGeolocationPermissionsShowPrompt(
                origin: String?,
                callback: GeolocationPermissions.Callback?
            ) {
                DeviceAccessHelper.handleGeolocationPermissionRequest(
                    context = appContext,
                    origin = origin,
                    callback = callback,
                    onRequestRuntimePermissions = onRequestRuntimePermissions
                )
            }
        }

        return wv
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configurePwaWebSettings(wv: WebView, isDesktop: Boolean) {
        cookieManager.setAcceptCookie(true)
        cookieManager.setAcceptThirdPartyCookies(wv, true)
        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            javaScriptCanOpenWindowsAutomatically = true
            setSupportMultipleWindows(true)
            allowFileAccess = true
            allowContentAccess = true
            setGeolocationEnabled(true)
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            mediaPlaybackRequiresUserGesture = true
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                safeBrowsingEnabled = false
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                isAlgorithmicDarkeningAllowed = currentSettings.darkWebPages
            }
            textZoom = currentSettings.textZoomPercent
            try {
                if (WebViewFeature.isFeatureSupported(WebViewFeature.OFF_SCREEN_PRERASTER)) {
                    WebSettingsCompat.setOffscreenPreRaster(this, true)
                }
            } catch (_: Exception) {
            }
            userAgentString = if (isDesktop) {
                WebViewManager.DESKTOP_CHROME_USER_AGENT
            } else {
                WebViewManager.MOBILE_CHROME_USER_AGENT
            }
        }
    }

    private fun handleFileChooser(
        callback: ValueCallback<Array<Uri>>,
        params: WebChromeClient.FileChooserParams
    ): Boolean {
        filePathCallback?.onReceiveValue(null)
        filePathCallback = callback
        val launcher = onLaunchFileChooser
        if (launcher == null) {
            filePathCallback?.onReceiveValue(null)
            filePathCallback = null
            return false
        }

        val launchNow = {
            val session = DeviceAccessHelper.createChromeFileChooserSession(
                context = currentActivity ?: appContext,
                fileChooserParams = params
            )
            activeFileChooserSession = session
            val launched = launcher.invoke(session.chooserIntent)
            if (!launched) {
                activeFileChooserSession = null
                filePathCallback?.onReceiveValue(null)
                filePathCallback = null
            }
        }

        val missingCapturePerms = DeviceAccessHelper.getOnDemandCapturePermissionsForFileChooser(
            context = appContext,
            fileChooserParams = params
        )
        val permRequester = onRequestRuntimePermissions
        if (missingCapturePerms.isNotEmpty() && permRequester != null) {
            permRequester(missingCapturePerms) { _ ->
                launchNow()
            }
        } else {
            launchNow()
        }
        return true
    }

    private fun handleWebPermissions(request: PermissionRequest) {
        DeviceAccessHelper.handleWebPermissionRequest(
            context = appContext,
            request = request,
            onRequestRuntimePermissions = onRequestRuntimePermissions
        )
    }

    private fun recoverFromRendererCrash(crashedView: WebView?) {
        val currentUrl = _uiState.value.url.ifBlank { app.url }
        try {
            (crashedView as? UnthrottledWebView)?.allowExplicitDestroy = true
            (crashedView?.parent as? ViewGroup)?.removeView(crashedView)
            crashedView?.destroy()
        } catch (_: Exception) {
        }
        val replacement = createPwaWebView()
        webView = replacement
        _webViewGeneration.value += 1
        replacement.loadUrl(currentUrl)
    }

    fun destroy() {
        flushCookies()
        closeOAuthPopup()
        try {
            webView.allowExplicitDestroy = true
            (webView.parent as? ViewGroup)?.removeView(webView)
            webView.stopLoading()
            webView.destroy()
        } catch (_: Exception) {
        }
    }
}

object PwaWebViewPool {
    private data class PooledEntry(
        val controller: PwaSessionController,
        @Volatile var lastUsedAtMs: Long = System.currentTimeMillis(),
        @Volatile var isForeground: Boolean = false
    )

    private val sessions = ConcurrentHashMap<String, PooledEntry>()
    private val memoryCallbackRegistered = AtomicBoolean(false)

    @Volatile
    private var keepAliveEnabled: Boolean = true

    private val _poolStats = MutableStateFlow(PwaPoolStats())
    val poolStats: StateFlow<PwaPoolStats> = _poolStats.asStateFlow()

    fun setKeepAliveEnabled(enabled: Boolean, context: Context? = null) {
        if (keepAliveEnabled == enabled) return
        keepAliveEnabled = enabled
        if (context != null) {
            enforceRamBudget(context.applicationContext)
        }
    }

    /**
     * Pure RAM capacity heuristic: maximizes live background PWAs according to device total & available RAM
     * so repeated taps reopen instantly without reloading, while protecting against OS OOM process kills.
     */
    fun calculateMaxSlotsForRam(totalRamMb: Long, availRamMb: Long, isLowMemory: Boolean): Int {
        val hardwareBase = when {
            totalRamMb >= 11_000L -> 12
            totalRamMb >= 7_500L -> 8
            totalRamMb >= 5_500L -> 6
            totalRamMb >= 3_500L -> 4
            else -> 2
        }
        if (isLowMemory || availRamMb in 1L..449L) {
            return 1
        }
        if (availRamMb in 450L..899L) {
            return (hardwareBase / 2).coerceAtLeast(2)
        }
        return hardwareBase
    }

    private fun readDeviceMemorySnapshot(context: Context): Triple<Long, Long, Boolean> {
        return try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            if (am != null) {
                val info = ActivityManager.MemoryInfo()
                am.getMemoryInfo(info)
                val totalMb = (info.totalMem / (1024L * 1024L)).coerceAtLeast(1024L)
                val availMb = (info.availMem / (1024L * 1024L)).coerceAtLeast(0L)
                Triple(totalMb, availMb, info.lowMemory)
            } else {
                Triple(4096L, 2048L, false)
            }
        } catch (_: Exception) {
            Triple(4096L, 2048L, false)
        }
    }

    private fun ensureMemoryCallbacksRegistered(appContext: Context) {
        if (memoryCallbackRegistered.compareAndSet(false, true)) {
            try {
                appContext.registerComponentCallbacks(
                    object : ComponentCallbacks2 {
                        override fun onTrimMemory(level: Int) {
                            handleTrimMemory(appContext, level)
                        }

                        override fun onConfigurationChanged(newConfig: Configuration) {}

                        @Deprecated("Deprecated in Java")
                        override fun onLowMemory() {
                            handleTrimMemory(appContext, ComponentCallbacks2.TRIM_MEMORY_COMPLETE)
                        }
                    }
                )
            } catch (_: Exception) {
            }
        }
    }

    fun getOrCreateSession(context: Context, app: InstalledWebAppEntity): PwaSessionController {
        val appCtx = context.applicationContext
        ensureMemoryCallbacksRegistered(appCtx)

        val existing = sessions[app.pwaId]
        if (existing != null) {
            existing.lastUsedAtMs = System.currentTimeMillis()
            refreshStats(appCtx)
            return existing.controller
        }

        val controller = PwaSessionController(appCtx, app)
        sessions[app.pwaId] = PooledEntry(
            controller = controller,
            lastUsedAtMs = System.currentTimeMillis(),
            isForeground = true
        )
        enforceRamBudget(appCtx, protectedPwaId = app.pwaId)
        refreshStats(appCtx)
        return controller
    }

    fun markForeground(pwaId: String, isForeground: Boolean) {
        sessions[pwaId]?.let {
            it.isForeground = isForeground
            it.lastUsedAtMs = System.currentTimeMillis()
        }
    }

    fun isLiveInRam(pwaId: String): Boolean = sessions.containsKey(pwaId)

    fun liveCount(): Int = sessions.size

    fun pulseAllLiveSessions(context: Context) {
        sessions.values.forEach { entry ->
            if (keepAliveEnabled || entry.isForeground) {
                entry.controller.pulseKeepAlive(entry.isForeground)
            }
        }
        refreshStats(context)
    }

    fun flushAllCookies() {
        sessions.values.forEach { entry ->
            entry.controller.flushCookies()
        }
    }

    fun enforceRamBudget(context: Context, protectedPwaId: String? = null) {
        val (totalMb, availMb, lowMem) = readDeviceMemorySnapshot(context)
        val maxSlots = if (keepAliveEnabled) {
            calculateMaxSlotsForRam(totalMb, availMb, lowMem)
        } else {
            1
        }
        trimPoolToTarget(targetMaxCount = maxSlots, protectedPwaId = protectedPwaId)
        refreshStats(context)
    }

    @Suppress("DEPRECATION")
    private fun handleTrimMemory(context: Context, level: Int) {
        val (totalMb, availMb, lowMem) = readDeviceMemorySnapshot(context)
        val baseMax = if (keepAliveEnabled) {
            calculateMaxSlotsForRam(totalMb, availMb, lowMem)
        } else {
            1
        }
        val target = when {
            !keepAliveEnabled -> 1
            level >= ComponentCallbacks2.TRIM_MEMORY_COMPLETE -> 1
            level >= ComponentCallbacks2.TRIM_MEMORY_MODERATE -> (baseMax / 2).coerceAtLeast(2)
            level == ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL -> 1
            level == ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW -> (baseMax - 1).coerceAtLeast(2)
            else -> baseMax
        }
        if (sessions.size > target) {
            trimPoolToTarget(targetMaxCount = target, protectedPwaId = null)
        }
        flushAllCookies()
        refreshStats(context)
    }

    private fun trimPoolToTarget(targetMaxCount: Int, protectedPwaId: String?) {
        if (sessions.size <= targetMaxCount) return
        val candidates = sessions.entries
            .filter { (id, entry) -> id != protectedPwaId && !entry.isForeground }
            .sortedBy { it.value.lastUsedAtMs }

        for (candidate in candidates) {
            if (sessions.size <= targetMaxCount) break
            sessions.remove(candidate.key)?.controller?.destroy()
        }
    }

    fun refreshStats(context: Context) {
        val (totalMb, availMb, lowMem) = readDeviceMemorySnapshot(context)
        val maxSlots = if (keepAliveEnabled) {
            calculateMaxSlotsForRam(totalMb, availMb, lowMem)
        } else {
            1
        }
        val keys = sessions.keys.toSet()
        _poolStats.value = PwaPoolStats(
            livePwaIds = keys,
            liveCount = keys.size,
            maxSlotsByRam = maxSlots,
            totalRamMb = totalMb,
            availRamMb = availMb,
            isLowMemory = lowMem
        )
    }

    fun removeAndDestroySession(pwaId: String, context: Context? = null) {
        sessions.remove(pwaId)?.controller?.destroy()
        if (context != null) {
            refreshStats(context)
        } else {
            _poolStats.update { current ->
                val updatedIds = current.livePwaIds - pwaId
                current.copy(livePwaIds = updatedIds, liveCount = updatedIds.size)
            }
        }
    }
}
