package com.example

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Parcelable
import android.provider.MediaStore
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class DevicePermissionsStatus(
    val cameraGranted: Boolean = false,
    val microphoneGranted: Boolean = false,
    val locationGranted: Boolean = false,
    val notificationsGranted: Boolean = true,
    val fileManagerAndSafReady: Boolean = true
) {
    val allGranted: Boolean
        get() = cameraGranted && microphoneGranted && locationGranted && notificationsGranted
}

data class ChromeFileChooserSession(
    val chooserIntent: Intent,
    val photoFile: File? = null,
    val photoUri: Uri? = null,
    val videoFile: File? = null,
    val videoUri: Uri? = null
)

object DeviceAccessHelper {

    fun isCameraGranted(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun isMicrophoneGranted(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun isLocationGranted(context: Context): Boolean {
        val fine = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        return fine || coarse
    }

    fun isNotificationsGranted(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    fun getPermissionsStatus(context: Context): DevicePermissionsStatus {
        return DevicePermissionsStatus(
            cameraGranted = isCameraGranted(context),
            microphoneGranted = isMicrophoneGranted(context),
            locationGranted = isLocationGranted(context),
            notificationsGranted = isNotificationsGranted(context),
            fileManagerAndSafReady = true
        )
    }

    fun getAllBrowserRuntimePermissions(): Array<String> {
        val list = mutableListOf(
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            list.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        return list.toTypedArray()
    }

    fun getMissingBrowserRuntimePermissions(context: Context): Array<String> {
        val missing = mutableListOf<String>()
        if (!isCameraGranted(context)) {
            missing.add(Manifest.permission.CAMERA)
        }
        if (!isMicrophoneGranted(context)) {
            missing.add(Manifest.permission.RECORD_AUDIO)
        }
        if (!isLocationGranted(context)) {
            missing.add(Manifest.permission.ACCESS_FINE_LOCATION)
            missing.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        }
        if (!isNotificationsGranted(context) && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            missing.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        return missing.toTypedArray()
    }

    fun getMissingCapturePermissions(context: Context): Array<String> {
        val missing = mutableListOf<String>()
        if (!isCameraGranted(context)) {
            missing.add(Manifest.permission.CAMERA)
        }
        if (!isMicrophoneGranted(context)) {
            missing.add(Manifest.permission.RECORD_AUDIO)
        }
        return missing.toTypedArray()
    }

    /**
     * Builds a Chrome-grade file chooser Intent that:
     * 1. Uses Intent.ACTION_GET_CONTENT with CATEGORY_OPENABLE and wildcard MIME type so Android's
     *    DocumentsUI "Open from" drawer includes the phone's native File Manager, ZArchiver,
     *    MEGA, Photos, Recorder, and all Google Drive accounts (matching Chrome's behavior).
     * 2. Includes Camera (ACTION_IMAGE_CAPTURE), Camcorder (ACTION_VIDEO_CAPTURE), and
     *    Sound Recorder (RECORD_SOUND_ACTION) in EXTRA_INITIAL_INTENTS so the bottom sheet
     *    "Complete action using" offers direct Camera, Camcorder, and File Manager / Photos options.
     */
    fun createChromeFileChooserSession(
        context: Context,
        fileChooserParams: WebChromeClient.FileChooserParams?
    ): ChromeFileChooserSession {
        val allowMultiple = fileChooserParams?.let {
            it.mode == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE
        } ?: true

        val getContentIntent = Intent(Intent.ACTION_GET_CONTENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, allowMultiple)
            putExtra(Intent.EXTRA_LOCAL_ONLY, false)
        }

        val initialIntents = mutableListOf<Intent>()
        var photoFile: File? = null
        var photoUri: Uri? = null
        var videoFile: File? = null
        var videoUri: Uri? = null

        val authority = "${context.applicationContext.packageName}.fileprovider"
        val capturesDir = File(context.cacheDir, "browser_captures").apply { mkdirs() }
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

        // Attach Camera & Camcorder capture intents when CAMERA permission is granted
        // (avoids SecurityException on devices where CAMERA is declared in AndroidManifest)
        if (isCameraGranted(context)) {
            try {
                val imgFile = File(capturesDir, "IMG_${timestamp}.jpg")
                val imgUri = FileProvider.getUriForFile(context, authority, imgFile)
                photoFile = imgFile
                photoUri = imgUri
                val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                    putExtra(MediaStore.EXTRA_OUTPUT, imgUri)
                    addFlags(
                        Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                            Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                }
                initialIntents.add(cameraIntent)
            } catch (_: Exception) {
            }

            try {
                val vidFile = File(capturesDir, "VID_${timestamp}.mp4")
                val vidUri = FileProvider.getUriForFile(context, authority, vidFile)
                videoFile = vidFile
                videoUri = vidUri
                val camcorderIntent = Intent(MediaStore.ACTION_VIDEO_CAPTURE).apply {
                    putExtra(MediaStore.EXTRA_OUTPUT, vidUri)
                    putExtra(MediaStore.EXTRA_VIDEO_QUALITY, 1)
                    addFlags(
                        Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                            Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                }
                initialIntents.add(camcorderIntent)
            } catch (_: Exception) {
            }
        }

        // Attach Sound Recorder intent so audio capture is available in the chooser
        try {
            val soundRecorderIntent = Intent(MediaStore.Audio.Media.RECORD_SOUND_ACTION)
            initialIntents.add(soundRecorderIntent)
        } catch (_: Exception) {
        }

        val chooserTitle = fileChooserParams?.title?.takeIf { it.isNotBlank() }?.toString()
            ?: "Complete action using"

        val chooserIntent = Intent.createChooser(getContentIntent, chooserTitle).apply {
            if (initialIntents.isNotEmpty()) {
                putExtra(
                    Intent.EXTRA_INITIAL_INTENTS,
                    initialIntents.toTypedArray<Parcelable>()
                )
            }
        }

        return ChromeFileChooserSession(
            chooserIntent = chooserIntent,
            photoFile = photoFile,
            photoUri = photoUri,
            videoFile = videoFile,
            videoUri = videoUri
        )
    }

    fun resolveFileChooserResult(
        context: Context,
        resultCode: Int,
        data: Intent?,
        session: ChromeFileChooserSession?
    ): Array<Uri>? {
        if (resultCode != Activity.RESULT_OK) {
            cleanupEmptyCaptureFiles(session)
            return null
        }

        val results = mutableListOf<Uri>()
        val clipData = data?.clipData
        if (clipData != null) {
            for (i in 0 until clipData.itemCount) {
                clipData.getItemAt(i)?.uri?.let { uri ->
                    takeReadPermissionIfPossible(context, data, uri)
                    results.add(uri)
                }
            }
        } else {
            data?.data?.let { uri ->
                takeReadPermissionIfPossible(context, data, uri)
                results.add(uri)
            }
        }

        if (results.isEmpty() && session != null) {
            val capturedPhoto = session.photoFile
            val capturedPhotoUri = session.photoUri
            val capturedVideo = session.videoFile
            val capturedVideoUri = session.videoUri

            if (capturedPhoto != null && capturedPhotoUri != null && capturedPhoto.exists() && capturedPhoto.length() > 0L) {
                results.add(capturedPhotoUri)
            } else if (capturedVideo != null && capturedVideoUri != null && capturedVideo.exists() && capturedVideo.length() > 0L) {
                results.add(capturedVideoUri)
            }
        }

        cleanupEmptyCaptureFiles(session)

        if (results.isNotEmpty()) {
            return results.toTypedArray()
        }

        return try {
            WebChromeClient.FileChooserParams.parseResult(resultCode, data)
        } catch (_: Exception) {
            null
        }
    }

    private fun takeReadPermissionIfPossible(context: Context, data: Intent, uri: Uri) {
        try {
            val flags = data.flags and Intent.FLAG_GRANT_READ_URI_PERMISSION
            if (flags != 0) {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
        } catch (_: Exception) {
        }
    }

    private fun cleanupEmptyCaptureFiles(session: ChromeFileChooserSession?) {
        if (session == null) return
        try {
            session.photoFile?.let { if (it.exists() && it.length() == 0L) it.delete() }
            session.videoFile?.let { if (it.exists() && it.length() == 0L) it.delete() }
        } catch (_: Exception) {
        }
    }

    private const val PREFS_SITE_PERMISSIONS = "flowra_site_permissions"

    @Volatile
    private var capturePermPromptedThisSession: Boolean = false

    private fun normalizeOriginKey(originOrUrl: String?): String {
        if (originOrUrl.isNullOrBlank()) return "global"
        return try {
            val uri = Uri.parse(originOrUrl)
            val scheme = uri.scheme?.lowercase() ?: "https"
            val host = uri.host?.lowercase() ?: originOrUrl.lowercase()
            val port = if (uri.port > 0) ":${uri.port}" else ""
            "$scheme://$host$port"
        } catch (_: Exception) {
            originOrUrl.lowercase()
        }
    }

    fun isSitePermissionRemembered(context: Context, origin: String?, permType: String): Boolean {
        return try {
            val prefs = context.applicationContext.getSharedPreferences(PREFS_SITE_PERMISSIONS, Context.MODE_PRIVATE)
            val key = "${normalizeOriginKey(origin)}_$permType"
            val globalKey = "always_allow_$permType"
            prefs.getBoolean(key, false) || prefs.getBoolean(globalKey, true)
        } catch (_: Exception) {
            true
        }
    }

    fun rememberSitePermissionGranted(context: Context, origin: String?, permType: String, allowAlways: Boolean = true) {
        try {
            val prefs = context.applicationContext.getSharedPreferences(PREFS_SITE_PERMISSIONS, Context.MODE_PRIVATE)
            val key = "${normalizeOriginKey(origin)}_$permType"
            prefs.edit()
                .putBoolean(key, allowAlways)
                .putBoolean("always_allow_$permType", allowAlways)
                .apply()
        } catch (_: Exception) {
        }
    }

    /**
     * Only request Camera/Mic runtime permissions before opening the File Chooser if the webpage
     * explicitly set the HTML5 `capture` attribute (`<input type="file" capture>`) AND we haven't
     * already prompted during this session. Standard File Manager picking (`<input type="file">`)
     * opens immediately with zero permission prompts, matching Google Chrome and Brave.
     */
    fun getOnDemandCapturePermissionsForFileChooser(
        context: Context,
        fileChooserParams: WebChromeClient.FileChooserParams?
    ): Array<String> {
        val isDirectCaptureRequested = try {
            fileChooserParams?.isCaptureEnabled == true
        } catch (_: Exception) {
            false
        }
        if (!isDirectCaptureRequested || capturePermPromptedThisSession) {
            return emptyArray()
        }
        capturePermPromptedThisSession = true
        val acceptTypes = try {
            fileChooserParams?.acceptTypes?.joinToString(",")?.lowercase().orEmpty()
        } catch (_: Exception) {
            ""
        }
        val needed = mutableListOf<String>()
        val wantsAudioOnly = acceptTypes.contains("audio/") && !acceptTypes.contains("video/") && !acceptTypes.contains("image/")
        if (wantsAudioOnly) {
            if (!isMicrophoneGranted(context)) {
                needed.add(Manifest.permission.RECORD_AUDIO)
            }
        } else {
            if (!isCameraGranted(context)) {
                needed.add(Manifest.permission.CAMERA)
            }
            if (acceptTypes.contains("video/") && !isMicrophoneGranted(context)) {
                needed.add(Manifest.permission.RECORD_AUDIO)
            }
        }
        return needed.toTypedArray()
    }

    /**
     * Handles WebView PermissionRequest (Camera, Microphone, Protected Media DRM, MIDI) on-demand
     * just like Chrome/Brave: only prompts when a website actively requests Camera/Mic, and once
     * granted, remembers the decision and auto-grants forever without asking again.
     */
    fun handleWebPermissionRequest(
        context: Context,
        request: PermissionRequest,
        onRequestRuntimePermissions: ((Array<String>, (Boolean) -> Unit) -> Unit)?
    ) {
        val resources = request.resources ?: return
        val originStr = try {
            request.origin?.toString()
        } catch (_: Exception) {
            null
        }
        val neededAndroidPermissions = mutableListOf<String>()

        if (resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) {
            if (!isMicrophoneGranted(context)) {
                neededAndroidPermissions.add(Manifest.permission.RECORD_AUDIO)
            } else {
                rememberSitePermissionGranted(context, originStr, "microphone", true)
            }
        }
        if (resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)) {
            if (!isCameraGranted(context)) {
                neededAndroidPermissions.add(Manifest.permission.CAMERA)
            } else {
                rememberSitePermissionGranted(context, originStr, "camera", true)
            }
        }

        if (neededAndroidPermissions.isEmpty()) {
            try {
                request.grant(resources)
            } catch (_: Exception) {
            }
            return
        }

        if (onRequestRuntimePermissions != null) {
            onRequestRuntimePermissions(neededAndroidPermissions.toTypedArray()) { _ ->
                if (isMicrophoneGranted(context)) {
                    rememberSitePermissionGranted(context, originStr, "microphone", true)
                }
                if (isCameraGranted(context)) {
                    rememberSitePermissionGranted(context, originStr, "camera", true)
                }
                val grantableResources = resources.filter { res ->
                    when (res) {
                        PermissionRequest.RESOURCE_AUDIO_CAPTURE -> isMicrophoneGranted(context)
                        PermissionRequest.RESOURCE_VIDEO_CAPTURE -> isCameraGranted(context)
                        else -> true
                    }
                }.toTypedArray()

                try {
                    if (grantableResources.isNotEmpty()) {
                        request.grant(grantableResources)
                    } else {
                        request.deny()
                    }
                } catch (_: Exception) {
                }
            }
        } else {
            try {
                request.grant(resources)
            } catch (_: Exception) {
            }
        }
    }

    /**
     * Handles HTML5 Geolocation API requests (navigator.geolocation) on-demand like Chrome/Brave:
     * only prompts when a website actively calls geolocation, and passes `retain = true` plus
     * persistent site memory so once allowed, it never asks again.
     */
    fun handleGeolocationPermissionRequest(
        context: Context,
        origin: String?,
        callback: GeolocationPermissions.Callback?,
        onRequestRuntimePermissions: ((Array<String>, (Boolean) -> Unit) -> Unit)?
    ) {
        if (origin == null || callback == null) return
        if (isLocationGranted(context)) {
            rememberSitePermissionGranted(context, origin, "location", true)
            callback.invoke(origin, true, true)
            return
        }

        if (onRequestRuntimePermissions != null) {
            onRequestRuntimePermissions(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            ) { _ ->
                val granted = isLocationGranted(context)
                if (granted) {
                    rememberSitePermissionGranted(context, origin, "location", true)
                }
                callback.invoke(origin, granted, granted)
            }
        } else {
            callback.invoke(origin, false, false)
        }
    }
}
