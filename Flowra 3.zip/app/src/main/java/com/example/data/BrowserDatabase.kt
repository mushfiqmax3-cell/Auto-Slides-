package com.example.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Entity(
    tableName = "bookmarks",
    indices = [Index(value = ["url"])]
)
data class BookmarkEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val url: String,
    val isSpeedDial: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "history",
    indices = [Index(value = ["visitedAt"]), Index(value = ["url"])]
)
data class HistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val url: String,
    val visitedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "downloads",
    indices = [Index(value = ["createdAt"])]
)
data class DownloadEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val systemDownloadId: Long = -1L,
    val fileName: String,
    val url: String,
    val mimeType: String = "application/octet-stream",
    val localUri: String = "",
    val status: String = DownloadStatus.RUNNING,
    val totalBytes: Long = -1L,
    val downloadedBytes: Long = 0L,
    val saveFolderLabel: String = "Downloads",
    val createdAt: Long = System.currentTimeMillis()
)

object DownloadStatus {
    const val PENDING = "PENDING"
    const val RUNNING = "RUNNING"
    const val PAUSED = "PAUSED"
    const val SUCCESSFUL = "SUCCESSFUL"
    const val FAILED = "FAILED"
}

@Entity(
    tableName = "installed_web_apps",
    indices = [Index(value = ["pwaId"], unique = true)]
)
data class InstalledWebAppEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val pwaId: String,
    val name: String,
    val url: String,
    val isStandalonePwa: Boolean = true,
    val isolatedProfile: Boolean = true,
    val profileName: String,
    val badgeColorHex: Long = 0xFF1A73E8L,
    val badgeTag: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface BookmarkDao {
    @Query("SELECT * FROM bookmarks ORDER BY createdAt DESC")
    fun getAllBookmarks(): Flow<List<BookmarkEntity>>

    @Query("SELECT * FROM bookmarks WHERE isSpeedDial = 1 ORDER BY createdAt ASC")
    fun getSpeedDialBookmarks(): Flow<List<BookmarkEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM bookmarks WHERE url = :url)")
    fun isBookmarked(url: String): Flow<Boolean>

    @Query("SELECT * FROM bookmarks WHERE url = :url LIMIT 1")
    suspend fun getBookmarkByUrl(url: String): BookmarkEntity?

    @Query("SELECT COUNT(*) FROM bookmarks")
    suspend fun getBookmarkCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBookmark(bookmark: BookmarkEntity): Long

    @Update
    suspend fun updateBookmark(bookmark: BookmarkEntity)

    @Query("UPDATE bookmarks SET isSpeedDial = :isSpeedDial WHERE id = :id")
    suspend fun setSpeedDial(id: Long, isSpeedDial: Boolean)

    @Query("UPDATE bookmarks SET title = :title, url = :url, isSpeedDial = :isSpeedDial WHERE id = :id")
    suspend fun updateBookmarkFields(id: Long, title: String, url: String, isSpeedDial: Boolean)

    @Query("DELETE FROM bookmarks WHERE id = :id")
    suspend fun deleteBookmarkById(id: Long)

    @Query("DELETE FROM bookmarks WHERE url = :url")
    suspend fun deleteBookmarkByUrl(url: String)
}

@Dao
interface HistoryDao {
    @Query("SELECT * FROM history ORDER BY visitedAt DESC LIMIT 500")
    fun getAllHistory(): Flow<List<HistoryEntity>>

    @Query("SELECT * FROM history WHERE title LIKE '%' || :query || '%' OR url LIKE '%' || :query || '%' ORDER BY visitedAt DESC LIMIT 25")
    suspend fun searchHistory(query: String): List<HistoryEntity>

    @Query("SELECT * FROM history WHERE url = :url ORDER BY visitedAt DESC LIMIT 1")
    suspend fun getLatestVisitForUrl(url: String): HistoryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(entry: HistoryEntity)

    @Query("UPDATE history SET title = :title, visitedAt = :visitedAt WHERE id = :id")
    suspend fun updateVisitTimestamp(id: Long, title: String, visitedAt: Long)

    @Query("DELETE FROM history WHERE id = :id")
    suspend fun deleteHistoryById(id: Long)

    @Query("DELETE FROM history")
    suspend fun clearAllHistory()
}

@Dao
interface DownloadDao {
    @Query("SELECT * FROM downloads ORDER BY createdAt DESC")
    fun getAllDownloads(): Flow<List<DownloadEntity>>

    @Query("SELECT * FROM downloads WHERE status IN ('PENDING', 'RUNNING', 'PAUSED')")
    suspend fun getActiveDownloads(): List<DownloadEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDownload(download: DownloadEntity): Long

    @Update
    suspend fun updateDownload(download: DownloadEntity)

    @Query("UPDATE downloads SET downloadedBytes = :bytes WHERE id = :id")
    suspend fun updateDownloadProgress(id: Long, bytes: Long)

    @Query("DELETE FROM downloads WHERE id = :id")
    suspend fun deleteDownloadById(id: Long)

    @Query("DELETE FROM downloads WHERE status IN ('SUCCESSFUL', 'FAILED')")
    suspend fun clearFinishedDownloads()

    @Query("DELETE FROM downloads")
    suspend fun clearAllDownloads()
}

@Dao
interface InstalledWebAppDao {
    @Query("SELECT * FROM installed_web_apps ORDER BY createdAt DESC")
    fun getAllWebApps(): Flow<List<InstalledWebAppEntity>>

    @Query("SELECT * FROM installed_web_apps WHERE pwaId = :pwaId LIMIT 1")
    suspend fun getWebAppByPwaId(pwaId: String): InstalledWebAppEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWebApp(app: InstalledWebAppEntity): Long

    @Update
    suspend fun updateWebApp(app: InstalledWebAppEntity)

    @Query("DELETE FROM installed_web_apps WHERE pwaId = :pwaId")
    suspend fun deleteWebAppByPwaId(pwaId: String)
}

@Database(
    entities = [
        BookmarkEntity::class,
        HistoryEntity::class,
        DownloadEntity::class,
        InstalledWebAppEntity::class
    ],
    version = 3,
    exportSchema = false
)
abstract class BrowserDatabase : RoomDatabase() {
    abstract fun bookmarkDao(): BookmarkDao
    abstract fun historyDao(): HistoryDao
    abstract fun downloadDao(): DownloadDao
    abstract fun installedWebAppDao(): InstalledWebAppDao

    companion object {
        @Volatile
        private var INSTANCE: BrowserDatabase? = null

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `installed_web_apps` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `pwaId` TEXT NOT NULL,
                        `name` TEXT NOT NULL,
                        `url` TEXT NOT NULL,
                        `isStandalonePwa` INTEGER NOT NULL,
                        `isolatedProfile` INTEGER NOT NULL,
                        `profileName` TEXT NOT NULL,
                        `badgeColorHex` INTEGER NOT NULL,
                        `badgeTag` TEXT NOT NULL,
                        `createdAt` INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
            }
        }

        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `downloads` ADD COLUMN `saveFolderLabel` TEXT NOT NULL DEFAULT 'Downloads'")
                db.execSQL("DELETE FROM `installed_web_apps` WHERE `id` NOT IN (SELECT MIN(`id`) FROM `installed_web_apps` GROUP BY `pwaId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_bookmarks_url` ON `bookmarks` (`url`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_history_visitedAt` ON `history` (`visitedAt`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_history_url` ON `history` (`url`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_downloads_createdAt` ON `downloads` (`createdAt`)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_installed_web_apps_pwaId` ON `installed_web_apps` (`pwaId`)")
            }
        }

        fun getInstance(context: Context): BrowserDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    BrowserDatabase::class.java,
                    "studio_browser.db"
                ).addMigrations(MIGRATION_1_2, MIGRATION_2_3).build().also { INSTANCE = it }
            }
        }
    }
}

class BrowserRepository(private val database: BrowserDatabase) {
    private val bookmarkDao = database.bookmarkDao()
    private val historyDao = database.historyDao()
    private val downloadDao = database.downloadDao()
    private val webAppDao = database.installedWebAppDao()

    val allBookmarks: Flow<List<BookmarkEntity>> = bookmarkDao.getAllBookmarks()
    val speedDialBookmarks: Flow<List<BookmarkEntity>> = bookmarkDao.getSpeedDialBookmarks()
    val allHistory: Flow<List<HistoryEntity>> = historyDao.getAllHistory()
    val allDownloads: Flow<List<DownloadEntity>> = downloadDao.getAllDownloads()
    val allWebApps: Flow<List<InstalledWebAppEntity>> = webAppDao.getAllWebApps()

    suspend fun ensureStarterBookmarks() {
        if (bookmarkDao.getBookmarkCount() == 0) {
            val now = System.currentTimeMillis()
            val starters = listOf(
                BookmarkEntity(title = "AI Studio", url = "https://aistudio.google.com/", isSpeedDial = true, createdAt = now),
                BookmarkEntity(title = "Google", url = "https://www.google.com/", isSpeedDial = true, createdAt = now + 1),
                BookmarkEntity(title = "Sign In", url = "https://accounts.google.com/", isSpeedDial = true, createdAt = now + 2),
                BookmarkEntity(title = "Gemini", url = "https://gemini.google.com/", isSpeedDial = true, createdAt = now + 3),
                BookmarkEntity(title = "YouTube", url = "https://m.youtube.com/", isSpeedDial = true, createdAt = now + 4),
                BookmarkEntity(title = "GitHub", url = "https://github.com/", isSpeedDial = true, createdAt = now + 5),
                BookmarkEntity(title = "Wikipedia", url = "https://www.wikipedia.org/", isSpeedDial = true, createdAt = now + 6),
                BookmarkEntity(title = "Translate", url = "https://translate.google.com/", isSpeedDial = true, createdAt = now + 7)
            )
            starters.forEach { bookmarkDao.insertBookmark(it) }
        }
    }

    fun isBookmarked(url: String): Flow<Boolean> = bookmarkDao.isBookmarked(url)

    suspend fun toggleBookmark(title: String, url: String): Boolean {
        val existing = bookmarkDao.getBookmarkByUrl(url)
        return if (existing != null) {
            bookmarkDao.deleteBookmarkById(existing.id)
            false
        } else {
            bookmarkDao.insertBookmark(
                BookmarkEntity(
                    title = title.ifBlank { url },
                    url = url,
                    isSpeedDial = false
                )
            )
            true
        }
    }

    suspend fun addOrUpdateBookmark(bookmark: BookmarkEntity) {
        val existing = bookmarkDao.getBookmarkByUrl(bookmark.url)
        if (existing != null) {
            bookmarkDao.updateBookmarkFields(
                id = existing.id,
                title = bookmark.title.ifBlank { bookmark.url },
                url = bookmark.url,
                isSpeedDial = bookmark.isSpeedDial || existing.isSpeedDial
            )
        } else {
            bookmarkDao.insertBookmark(bookmark)
        }
    }

    suspend fun updateBookmarkFields(id: Long, title: String, url: String, isSpeedDial: Boolean) {
        bookmarkDao.updateBookmarkFields(id, title.ifBlank { url }, url, isSpeedDial)
    }

    suspend fun setBookmarkSpeedDial(id: Long, isSpeedDial: Boolean) {
        bookmarkDao.setSpeedDial(id, isSpeedDial)
    }

    suspend fun deleteBookmark(id: Long) {
        bookmarkDao.deleteBookmarkById(id)
    }

    suspend fun recordHistory(title: String, url: String) {
        if (url.isBlank() || url == "about:newtab" || url == "about:blank") return
        val now = System.currentTimeMillis()
        val recent = historyDao.getLatestVisitForUrl(url)
        val cleanTitle = title.ifBlank { url }
        if (recent != null && (now - recent.visitedAt) < 15 * 60 * 1000L) {
            historyDao.updateVisitTimestamp(recent.id, cleanTitle, now)
        } else {
            historyDao.insertHistory(
                HistoryEntity(
                    title = cleanTitle,
                    url = url,
                    visitedAt = now
                )
            )
        }
    }

    suspend fun searchHistory(query: String): List<HistoryEntity> {
        if (query.isBlank()) return emptyList()
        return historyDao.searchHistory(query)
    }

    suspend fun deleteHistoryItem(id: Long) = historyDao.deleteHistoryById(id)

    suspend fun clearHistory() = historyDao.clearAllHistory()

    suspend fun insertDownload(download: DownloadEntity): Long = downloadDao.insertDownload(download)

    suspend fun updateDownload(download: DownloadEntity) = downloadDao.updateDownload(download)

    suspend fun updateDownloadProgress(id: Long, bytes: Long) = downloadDao.updateDownloadProgress(id, bytes)

    suspend fun getActiveDownloads(): List<DownloadEntity> = downloadDao.getActiveDownloads()

    suspend fun deleteDownload(id: Long) = downloadDao.deleteDownloadById(id)

    suspend fun clearFinishedDownloads() = downloadDao.clearFinishedDownloads()

    suspend fun clearAllDownloads() = downloadDao.clearAllDownloads()

    suspend fun insertWebApp(app: InstalledWebAppEntity): Long = webAppDao.insertWebApp(app)

    suspend fun updateWebApp(app: InstalledWebAppEntity) = webAppDao.updateWebApp(app)

    suspend fun getWebAppByPwaId(pwaId: String): InstalledWebAppEntity? = webAppDao.getWebAppByPwaId(pwaId)

    suspend fun deleteWebApp(pwaId: String) = webAppDao.deleteWebAppByPwaId(pwaId)
}
