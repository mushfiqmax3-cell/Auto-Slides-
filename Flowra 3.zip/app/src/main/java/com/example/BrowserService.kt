package com.example

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class ShieldServiceState(
    val isRunning: Boolean = false,
    val wakeLockHeld: Boolean = false,
    val wifiLockHeld: Boolean = false,
    val audioKeepAliveActive: Boolean = false,
    val heartbeatCount: Long = 0L,
    val activeTabsCount: Int = 5,
    val livePwasCount: Int = 0
)

class BrowserService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var multicastLock: WifiManager.MulticastLock? = null
    private var silentAudioTrack: AudioTrack? = null
    private var heartbeatJob: Job? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        acquireHardwareLocks()
        startSilentAudioKeepAlive()
        startHeartbeatLoop()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_SERVICE -> {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_CANCEL_DOWNLOAD -> {
                val rowId = intent.getLongExtra(EXTRA_DOWNLOAD_ROW_ID, -1L)
                if (rowId > 0L) {
                    val repo = WebViewManager.getInstanceIfCreated()?.repository
                        ?: com.example.data.BrowserRepository(
                            com.example.data.BrowserDatabase.getInstance(applicationContext)
                        )
                    DownloadHelper.cancelActiveDownload(applicationContext, repo, rowId)
                }
            }
            ACTION_UPDATE_NOTIFICATION -> {
                val tabCount = intent.getIntExtra(EXTRA_TAB_COUNT, 5)
                val pwaCount = intent.getIntExtra(EXTRA_PWA_COUNT, PwaWebViewPool.liveCount())
                _serviceState.update { it.copy(activeTabsCount = tabCount, livePwasCount = pwaCount) }
            }
        }

        ensureLocksHeld()
        val notification = buildOngoingNotification(
            activeTabCount = _serviceState.value.activeTabsCount,
            livePwaCount = _serviceState.value.livePwasCount
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE or
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
            _serviceState.update {
                it.copy(
                    isRunning = true,
                    wakeLockHeld = wakeLock?.isHeld == true,
                    wifiLockHeld = wifiLock?.isHeld == true
                )
            }
        } catch (_: Exception) {
            // Fallback if foreground promotion is restricted in a background edge-case
        }

        return START_STICKY
    }

    private fun acquireHardwareLocks() {
        try {
            val powerManager = getSystemService(Context.POWER_SERVICE) as? PowerManager
            if (wakeLock == null && powerManager != null) {
                wakeLock = powerManager.newWakeLock(
                    PowerManager.PARTIAL_WAKE_LOCK,
                    "StudioBrowser::CpuKeepAliveLock"
                ).apply {
                    setReferenceCounted(false)
                    acquire()
                }
            }
        } catch (_: Exception) {
        }

        try {
            val wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            if (wifiLock == null && wifiManager != null) {
                @Suppress("DEPRECATION")
                val lockMode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    WifiManager.WIFI_MODE_FULL_LOW_LATENCY
                } else {
                    WifiManager.WIFI_MODE_FULL_HIGH_PERF
                }
                wifiLock = wifiManager.createWifiLock(
                    lockMode,
                    "StudioBrowser::LowLatencyWifiLock"
                ).apply {
                    setReferenceCounted(false)
                    acquire()
                }
            }

            if (multicastLock == null && wifiManager != null) {
                multicastLock = wifiManager.createMulticastLock("StudioBrowser::MulticastKeepAlive").apply {
                    setReferenceCounted(false)
                    acquire()
                }
            }
        } catch (_: Exception) {
        }

        _serviceState.update {
            it.copy(
                wakeLockHeld = wakeLock?.isHeld == true,
                wifiLockHeld = wifiLock?.isHeld == true
            )
        }
    }

    private fun ensureLocksHeld() {
        try {
            if (wakeLock?.isHeld != true) {
                wakeLock?.acquire()
            }
            if (wifiLock?.isHeld != true) {
                wifiLock?.acquire()
            }
            if (multicastLock?.isHeld != true) {
                multicastLock?.acquire()
            }
        } catch (_: Exception) {
        }
        _serviceState.update {
            it.copy(
                wakeLockHeld = wakeLock?.isHeld == true,
                wifiLockHeld = wifiLock?.isHeld == true
            )
        }
    }

    /**
     * Plays a continuous inaudible sub-zero PCM buffer in loop mode so aggressive OEM
     * task killers (Xiaomi HyperOS, Samsung OneUI, Oppo ColorOS, Vivo OriginOS) classify
     * the process as an active multimedia/streaming session and never freeze its cgroup.
     */
    private fun startSilentAudioKeepAlive() {
        if (silentAudioTrack != null) return
        try {
            val sampleRate = 8000
            val minBufferSize = AudioTrack.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            ).coerceAtLeast(sampleRate * 2)

            val audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build()

            val audioFormat = AudioFormat.Builder()
                .setSampleRate(sampleRate)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build()

            val track = AudioTrack.Builder()
                .setAudioAttributes(audioAttributes)
                .setAudioFormat(audioFormat)
                .setBufferSizeInBytes(minBufferSize)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            val silentSamples = ShortArray(sampleRate) { 0 }
            track.write(silentSamples, 0, silentSamples.size)
            track.setLoopPoints(0, silentSamples.size / 2, -1)
            track.setVolume(0.0f)
            track.play()

            silentAudioTrack = track
            _serviceState.update { it.copy(audioKeepAliveActive = true) }
        } catch (_: Exception) {
            _serviceState.update { it.copy(audioKeepAliveActive = false) }
        }
    }

    private fun startHeartbeatLoop() {
        heartbeatJob?.cancel()
        heartbeatJob = serviceScope.launch {
            delay(12_000L)
            while (isActive) {
                ensureLocksHeld()
                withContext(Dispatchers.Main) {
                    WebViewManager.getInstanceIfCreated()?.pulseBackgroundKeepAlive()
                    PwaWebViewPool.pulseAllLiveSessions(applicationContext)
                }
                val pwaCount = PwaWebViewPool.liveCount()
                _serviceState.update { current ->
                    current.copy(
                        isRunning = true,
                        wakeLockHeld = wakeLock?.isHeld == true,
                        wifiLockHeld = wifiLock?.isHeld == true,
                        heartbeatCount = current.heartbeatCount + 1,
                        livePwasCount = pwaCount
                    )
                }
                delay(12_000L)
            }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_channel_desc)
                setShowBadge(false)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
            manager?.createNotificationChannel(channel)
        }
    }

    private fun buildOngoingNotification(activeTabCount: Int, livePwaCount: Int): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingOpenIntent = PendingIntent.getActivity(
            this,
            100,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val activeDownloads = DownloadHelper.activeDownloadCount()
        val titleText = when {
            activeDownloads > 0 -> "$activeDownloads Download(s) Running in Background • $activeTabCount Tabs Live"
            livePwaCount > 0 -> "$activeTabCount Studio Tabs + $livePwaCount PWAs Live in RAM"
            else -> "$activeTabCount AI Studio Tabs Active in Background"
        }
        val contentText = getString(R.string.notification_content)

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(
                if (activeDownloads > 0) android.R.drawable.stat_sys_download
                else android.R.drawable.ic_menu_compass
            )
            .setContentTitle(titleText)
            .setContentText(contentText)
            .setSubText(if (activeDownloads > 0) "Background Download Active" else "Anti-Throttle Shield ON")
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setContentIntent(pendingOpenIntent)
            .addAction(
                android.R.drawable.ic_menu_view,
                getString(R.string.action_return_to_app),
                pendingOpenIntent
            )
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        // Persist all cookies/logins to disk and keep hardware locks alive even if swiped from recents
        WebViewManager.getInstanceIfCreated()?.flushCookiesNow()
        PwaWebViewPool.flushAllCookies()
        ensureLocksHeld()
    }

    override fun onDestroy() {
        heartbeatJob?.cancel()
        serviceScope.cancel()
        try {
            silentAudioTrack?.stop()
            silentAudioTrack?.release()
        } catch (_: Exception) {
        }
        silentAudioTrack = null

        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: Exception) {
        }
        try {
            if (wifiLock?.isHeld == true) wifiLock?.release()
        } catch (_: Exception) {
        }
        try {
            if (multicastLock?.isHeld == true) multicastLock?.release()
        } catch (_: Exception) {
        }

        _serviceState.update {
            it.copy(
                isRunning = false,
                wakeLockHeld = false,
                wifiLockHeld = false,
                audioKeepAliveActive = false
            )
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val CHANNEL_ID = "studio_browser_keepalive_channel"
        private const val NOTIFICATION_ID = 5005
        const val ACTION_START_SERVICE = "com.example.action.START_BROWSER_SHIELD"
        const val ACTION_STOP_SERVICE = "com.example.action.STOP_BROWSER_SHIELD"
        const val ACTION_UPDATE_NOTIFICATION = "com.example.action.UPDATE_BROWSER_SHIELD"
        const val ACTION_CANCEL_DOWNLOAD = "com.example.action.CANCEL_DOWNLOAD"
        const val EXTRA_TAB_COUNT = "extra_tab_count"
        const val EXTRA_PWA_COUNT = "extra_pwa_count"
        const val EXTRA_DOWNLOAD_ROW_ID = "extra_download_row_id"

        private val _serviceState = MutableStateFlow(ShieldServiceState())
        val serviceState: StateFlow<ShieldServiceState> = _serviceState.asStateFlow()

        fun startKeepAliveService(
            context: Context,
            tabCount: Int = 5,
            pwaCount: Int = PwaWebViewPool.liveCount()
        ) {
            val intent = Intent(context.applicationContext, BrowserService::class.java).apply {
                action = ACTION_UPDATE_NOTIFICATION
                putExtra(EXTRA_TAB_COUNT, tabCount)
                putExtra(EXTRA_PWA_COUNT, pwaCount)
            }
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.applicationContext.startForegroundService(intent)
                } else {
                    context.applicationContext.startService(intent)
                }
            } catch (_: Exception) {
                try {
                    context.applicationContext.startService(intent)
                } catch (_: Exception) {
                }
            }
        }

        fun stopKeepAliveService(context: Context) {
            val intent = Intent(context.applicationContext, BrowserService::class.java).apply {
                action = ACTION_STOP_SERVICE
            }
            try {
                context.applicationContext.startService(intent)
            } catch (_: Exception) {
            }
        }
    }
}
