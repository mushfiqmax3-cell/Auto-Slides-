package com.example

import android.Manifest
import android.app.DownloadManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.util.Base64
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.MimeTypeMap
import android.webkit.URLUtil
import android.webkit.WebView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.example.data.BrowserRepository
import com.example.data.DownloadEntity
import com.example.data.DownloadStatus
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class DownloadFolderPreset(
    val displayName: String,
    val relativeDisplayPath: String,
    val publicDirType: String,
    val subFolder: String? = null
) {
    DOWNLOADS("Downloads", "/Downloads", Environment.DIRECTORY_DOWNLOADS, null),
    STUDIO_DOWNLOADS("Downloads / Flowra", "/Downloads/Flowra", Environment.DIRECTORY_DOWNLOADS, "Flowra"),
    MUSIC("Music", "/Music", Environment.DIRECTORY_MUSIC, null),
    PICTURES("Pictures", "/Pictures", Environment.DIRECTORY_PICTURES, null),
    MOVIES("Movies", "/Movies", Environment.DIRECTORY_MOVIES, null),
    DOCUMENTS("Documents", "/Documents", Environment.DIRECTORY_DOCUMENTS, null),
    CUSTOM_SAF("Custom Folder", "Custom folder", Environment.DIRECTORY_DOWNLOADS, null);

    companion object {
        fun fromId(id: String?): DownloadFolderPreset {
            return entries.find { it.name == id } ?: DOWNLOADS
        }
    }
}

data class DownloadDestination(
    val preset: DownloadFolderPreset = DownloadFolderPreset.DOWNLOADS,
    val customTreeUri: String = "",
    val customFolderLabel: String = ""
) {
    fun displayLabel(): String {
        return if (preset == DownloadFolderPreset.CUSTOM_SAF && customFolderLabel.isNotBlank()) {
            customFolderLabel
        } else {
            preset.relativeDisplayPath
        }
    }
}

data class PendingDownloadRequest(
    val url: String,
    val userAgent: String,
    val contentDisposition: String,
    val mimeType: String,
    val contentLength: Long,
    val suggestedFileName: String,
    val defaultDestination: DownloadDestination = DownloadDestination(),
    val refererUrl: String = "",
    val sourceTabId: Int = -1
)

data class RegisteredBlobMetadata(
    val blobUrl: String,
    val mimeType: String,
    val sizeBytes: Long,
    val magicHex: String,
    val suggestedName: String,
    val timestampMs: Long = System.currentTimeMillis()
)

private class ActiveBlobTransfer(
    val transferId: String,
    val blobUrl: String,
    val tempFile: File,
    @Volatile var fileName: String,
    @Volatile var mimeType: String,
    @Volatile var totalBytes: Long,
    @Volatile var destination: DownloadDestination,
    @Volatile var isPreStagedOnly: Boolean,
    @Volatile var userConfirmedSave: Boolean,
    @Volatile var stagingFinished: Boolean = false,
    @Volatile var stagingFailed: Boolean = false,
    @Volatile var magicSniffed: Boolean = false,
    @Volatile var dbRowId: Long = -1L,
    @Volatile var bytesReceived: Long = 0L,
    val commitLock: Any = Any(),
    var committed: Boolean = false
)

class StudioDownloadBridge(
    private val context: Context,
    private val repository: BrowserRepository? = null,
    private val onPendingDownloadFromJs: ((
        url: String,
        suggestedName: String,
        mimeType: String,
        contentLength: Long,
        pageUrl: String
    ) -> Unit)? = null,
    private val onUpgradePendingDownload: ((
        url: String,
        upgradedFileName: String,
        upgradedMimeType: String,
        contentLength: Long
    ) -> Unit)? = null,
    private val onAiStudioPermissionError: ((Boolean) -> Unit)? = null,
    private val onBase64Saved: (
        fileName: String,
        url: String,
        mimeType: String,
        uriString: String,
        sizeBytes: Long,
        saveFolderLabel: String
    ) -> Unit
) {
    private val bridgeScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val activeTransfers = ConcurrentHashMap<String, ActiveBlobTransfer>()
    private val stagedTransfersByUrl = ConcurrentHashMap<String, ActiveBlobTransfer>()
    private val cachedBlobNames = ConcurrentHashMap<String, String>()
    private val cachedBlobMetadata = ConcurrentHashMap<String, RegisteredBlobMetadata>()
    private val downloadListenerClaimedUrls = ConcurrentHashMap<String, Long>()

    @JavascriptInterface
    fun reportAiStudioPermissionError(hasError: Boolean) {
        onAiStudioPermissionError?.invoke(hasError)
    }

    @JavascriptInterface
    fun registerBlobSuggestedName(blobUrl: String, downloadAttrName: String) {
        if (blobUrl.isNotBlank() && downloadAttrName.isNotBlank()) {
            val clean = downloadAttrName.trim()
            cachedBlobNames[blobUrl] = clean
            val existingMeta = cachedBlobMetadata[blobUrl]
            if (existingMeta != null && existingMeta.suggestedName.isBlank()) {
                cachedBlobMetadata[blobUrl] = existingMeta.copy(suggestedName = clean)
            }
        }
    }

    @JavascriptInterface
    fun registerBlobMetadata(
        blobUrl: String,
        mimeType: String,
        sizeBytes: Long,
        magicHex: String,
        fileName: String
    ) {
        if (blobUrl.isBlank()) return
        val cleanName = fileName.trim()
        if (cleanName.isNotBlank()) {
            cachedBlobNames[blobUrl] = cleanName
        }
        val magicDetected = detectMimeAndExtFromMagicHex(magicHex)
        val effectiveMime = when {
            magicDetected != null -> magicDetected.first
            mimeType.isNotBlank() &&
                !mimeType.equals("text/plain", ignoreCase = true) &&
                !mimeType.equals("application/octet-stream", ignoreCase = true) -> mimeType.trim()
            else -> mimeType.trim()
        }
        val meta = RegisteredBlobMetadata(
            blobUrl = blobUrl,
            mimeType = effectiveMime,
            sizeBytes = sizeBytes,
            magicHex = magicHex.trim(),
            suggestedName = cleanName.ifBlank { cachedBlobNames[blobUrl].orEmpty() }
        )
        cachedBlobMetadata[blobUrl] = meta

        // If a PendingDownloadRequest is already showing for this blobUrl, upgrade its filename & MIME immediately!
        if (magicDetected != null || effectiveMime.isNotBlank() || cleanName.isNotBlank()) {
            val bestName = buildSmartBlobFileName(
                rawSuggestedName = meta.suggestedName,
                rawMime = effectiveMime,
                magicHex = magicHex,
                pageUrl = blobUrl
            )
            val resolvedMime = resolveAccurateMimeType(bestName, effectiveMime, magicHex)
            onUpgradePendingDownload?.invoke(blobUrl, bestName, resolvedMime, sizeBytes)
        }
    }

    fun getRegisteredBlobName(blobUrl: String): String? = cachedBlobNames[blobUrl]

    fun getRegisteredBlobMetadata(blobUrl: String): RegisteredBlobMetadata? = cachedBlobMetadata[blobUrl]

    fun markDownloadListenerClaimed(url: String) {
        if (url.isNotBlank()) {
            downloadListenerClaimedUrls[url] = System.currentTimeMillis()
        }
    }

    fun hasStagedOrActiveBlob(url: String): Boolean {
        val session = stagedTransfersByUrl[url] ?: return false
        return !session.stagingFailed
    }

    /**
     * Called directly from our DOCUMENT_START JS interceptor the exact millisecond `<a href="blob:...">`
     * or `<a href="data:...">` is clicked (BEFORE `URL.revokeObjectURL` can execute on the next JS line!).
     * Pre-stages the Blob bytes to a native temp file on disk while the user views the Brave Download Dialog.
     */
    @JavascriptInterface
    fun beginPreStagedBlobTransfer(
        transferId: String,
        blobUrl: String,
        suggestedName: String,
        mimeType: String,
        totalBytes: Long,
        magicHex: String,
        pageUrl: String
    ) {
        try {
            if (suggestedName.isNotBlank() && blobUrl.isNotBlank()) {
                cachedBlobNames[blobUrl] = suggestedName.trim()
            }
            if (blobUrl.isNotBlank()) {
                registerBlobMetadata(blobUrl, mimeType, totalBytes, magicHex, suggestedName)
            }
            val smartName = buildSmartBlobFileName(
                rawSuggestedName = suggestedName.ifBlank { cachedBlobNames[blobUrl].orEmpty() },
                rawMime = mimeType,
                magicHex = magicHex,
                pageUrl = pageUrl.ifBlank { blobUrl }
            )
            val resolvedMime = resolveAccurateMimeType(smartName, mimeType, magicHex)

            val dir = File(context.cacheDir, "blob_transfers").apply { mkdirs() }
            val tempFile = File(dir, "stage_${transferId.replace(Regex("[^a-zA-Z0-9_-]"), "")}.tmp")
            if (tempFile.exists()) tempFile.delete()

            val session = ActiveBlobTransfer(
                transferId = transferId,
                blobUrl = blobUrl,
                tempFile = tempFile,
                fileName = smartName,
                mimeType = resolvedMime,
                totalBytes = totalBytes,
                destination = DownloadDestination(),
                isPreStagedOnly = true,
                userConfirmedSave = false,
                magicSniffed = magicHex.length >= 8
            )
            activeTransfers[transferId] = session
            if (blobUrl.isNotBlank()) {
                stagedTransfersByUrl[blobUrl] = session
            }

            // Upgrade any already-visible dialog for this URL
            if (blobUrl.isNotBlank()) {
                onUpgradePendingDownload?.invoke(blobUrl, smartName, resolvedMime, totalBytes)
            }

            // If Android's native DownloadListener didn't fire for this blob/data link (e.g. inside an iframe
            // or data: URL or detached anchor), trigger the Brave Download Dialog automatically after 180ms!
            if (onPendingDownloadFromJs != null && blobUrl.isNotBlank()) {
                bridgeScope.launch {
                    delay(180L)
                    val claimedAt = downloadListenerClaimedUrls[blobUrl] ?: 0L
                    if (System.currentTimeMillis() - claimedAt > 3000L) {
                        downloadListenerClaimedUrls[blobUrl] = System.currentTimeMillis()
                        onPendingDownloadFromJs.invoke(
                            blobUrl,
                            session.fileName,
                            session.mimeType,
                            session.totalBytes,
                            pageUrl
                        )
                    }
                }
            }
        } catch (_: Exception) {
        }
    }

    @JavascriptInterface
    fun startBlobTransfer(
        transferId: String,
        fileName: String,
        mimeType: String,
        presetName: String,
        customTreeUri: String,
        customFolderLabel: String
    ) {
        try {
            val rawMime = mimeType.ifBlank { "application/octet-stream" }
            val safeName = sanitizeFileName(
                fileName.ifBlank { "download_${System.currentTimeMillis()}" },
                rawMime
            )
            val safeMime = resolveAccurateMimeType(safeName, rawMime)
            val dir = File(context.cacheDir, "blob_transfers").apply { mkdirs() }
            val tempFile = File(dir, "blob_${transferId.replace(Regex("[^a-zA-Z0-9_-]"), "")}.tmp")
            if (tempFile.exists()) tempFile.delete()
            val destination = DownloadDestination(
                preset = DownloadFolderPreset.fromId(presetName),
                customTreeUri = customTreeUri,
                customFolderLabel = customFolderLabel
            )
            val session = ActiveBlobTransfer(
                transferId = transferId,
                blobUrl = "blob:transfer/$transferId",
                tempFile = tempFile,
                fileName = safeName,
                mimeType = safeMime,
                totalBytes = -1L,
                destination = destination,
                isPreStagedOnly = false,
                userConfirmedSave = true
            )
            activeTransfers[transferId] = session
            val repo = repository
            if (repo != null) {
                bridgeScope.launch {
                    try {
                        val rowId = repo.insertDownload(
                            DownloadEntity(
                                systemDownloadId = -1L,
                                fileName = safeName,
                                url = session.blobUrl,
                                mimeType = safeMime,
                                status = DownloadStatus.RUNNING,
                                totalBytes = -1L,
                                downloadedBytes = 0L,
                                saveFolderLabel = destination.displayLabel()
                            )
                        )
                        session.dbRowId = rowId
                        DownloadHelper.notifyForegroundServiceDownloadActive(context)
                        DownloadHelper.postDownloadProgressNotification(
                            context = context,
                            rowId = rowId,
                            fileName = safeName,
                            downloadedBytes = 0L,
                            totalBytes = -1L,
                            folderLabel = destination.displayLabel()
                        )
                    } catch (_: Exception) {
                    }
                }
            }
        } catch (_: Exception) {
        }
    }

    @JavascriptInterface
    fun appendBlobChunk(transferId: String, base64Chunk: String) {
        val session = activeTransfers[transferId] ?: return
        try {
            val cleanBase64 = if (base64Chunk.contains("base64,")) {
                base64Chunk.substringAfter("base64,")
            } else {
                base64Chunk
            }
            if (cleanBase64.isEmpty()) return
            val bytes = Base64.decode(cleanBase64, Base64.DEFAULT)
            if (bytes.isEmpty()) return

            // Sniff magic bytes on the very first chunk so WAV / MP3 / OGG / ZIP / PDF / Images
            // are NEVER mislabeled as text/plain (.txt) or .bin!
            if (session.bytesReceived == 0L && bytes.size >= 4) {
                val detected = detectMimeAndExtFromBytes(bytes)
                if (detected != null) {
                    val (trueMime, trueExt) = detected
                    val correctedName = applyDetectedExtensionIfNeeded(session.fileName, trueExt)
                    session.fileName = correctedName
                    session.mimeType = trueMime
                    session.magicSniffed = true
                    if (session.blobUrl.isNotBlank()) {
                        onUpgradePendingDownload?.invoke(
                            session.blobUrl,
                            correctedName,
                            trueMime,
                            session.totalBytes
                        )
                    }
                }
            }

            FileOutputStream(session.tempFile, true).use { out ->
                out.write(bytes)
            }
            session.bytesReceived += bytes.size
            val rowId = session.dbRowId
            val repo = repository
            if (rowId > 0L && repo != null) {
                val currentTotal = session.bytesReceived
                val expectedTotal = session.totalBytes
                val fName = session.fileName
                val fLabel = session.destination.displayLabel()
                bridgeScope.launch {
                    try {
                        repo.updateDownloadProgress(rowId, currentTotal)
                        DownloadHelper.postDownloadProgressNotification(
                            context = context,
                            rowId = rowId,
                            fileName = fName,
                            downloadedBytes = currentTotal,
                            totalBytes = expectedTotal,
                            folderLabel = fLabel
                        )
                    } catch (_: Exception) {
                    }
                }
            }
        } catch (_: Exception) {
        }
    }

    @JavascriptInterface
    fun finishBlobTransfer(transferId: String, sourceUrl: String) {
        val session = activeTransfers[transferId] ?: return
        session.stagingFinished = true
        if (session.totalBytes <= 0L && session.tempFile.exists()) {
            session.totalBytes = session.tempFile.length()
        }
        // Double-check magic bytes on the completed temp file
        if (session.tempFile.exists() && session.tempFile.length() >= 4L) {
            val header = readHeaderBytes(session.tempFile, 32)
            val detected = detectMimeAndExtFromBytes(header)
            if (detected != null) {
                val (trueMime, trueExt) = detected
                session.fileName = applyDetectedExtensionIfNeeded(session.fileName, trueExt)
                session.mimeType = trueMime
                if (session.blobUrl.isNotBlank()) {
                    onUpgradePendingDownload?.invoke(
                        session.blobUrl,
                        session.fileName,
                        session.mimeType,
                        session.totalBytes
                    )
                }
            }
        }

        // If this was a pre-staged blob and the user hasn't clicked "Download" in the dialog yet,
        // keep the staged temp file ready on disk until confirmStagedOrExecuteBlobDownload is called!
        var shouldCommitNow = false
        synchronized(session.commitLock) {
            if (session.userConfirmedSave && !session.committed) {
                session.committed = true
                shouldCommitNow = true
            }
        }
        if (shouldCommitNow) {
            activeTransfers.remove(transferId)
            if (session.blobUrl.isNotBlank()) {
                stagedTransfersByUrl.remove(session.blobUrl)
            }
            commitSessionFileToDestination(session, sourceUrl.ifBlank { session.blobUrl })
        }
    }

    @JavascriptInterface
    fun reportBlobTransferError(transferId: String, blobUrl: String, errorMsg: String) {
        val session = activeTransfers.remove(transferId) ?: stagedTransfersByUrl.remove(blobUrl)
        if (session != null) {
            session.stagingFailed = true
            session.tempFile.delete()
            val rowId = session.dbRowId
            if (rowId > 0L && repository != null) {
                bridgeScope.launch {
                    repository.updateDownload(
                        DownloadEntity(
                            id = rowId,
                            systemDownloadId = -1L,
                            fileName = session.fileName,
                            url = blobUrl,
                            mimeType = session.mimeType,
                            status = DownloadStatus.FAILED,
                            saveFolderLabel = session.destination.displayLabel()
                        )
                    )
                    DownloadHelper.postDownloadFailedNotification(context, rowId, session.fileName)
                }
            }
        }
    }

    /**
     * Called when the user confirms (or auto-confirms) a `blob:` or `data:` download in Flowra.
     * If the blob was already pre-staged (or is currently streaming into `stagedTransfersByUrl`),
     * commits the staged temp file directly to the chosen destination folder without failing on
     * revoked Blob URLs!
     */
    fun confirmStagedOrExecuteBlobDownload(
        blobOrDataUrl: String,
        customFileName: String,
        mimeType: String,
        destination: DownloadDestination,
        fallbackWebView: WebView?
    ) {
        val staged = stagedTransfersByUrl[blobOrDataUrl]
        if (staged != null && !staged.stagingFailed) {
            // Inspect magic bytes if already available on disk so even if the user kept a generic
            // .txt/.bin name, we preserve the real audio/zip extension unless the user explicitly changed it.
            val header = if (staged.tempFile.exists() && staged.tempFile.length() >= 4L) {
                readHeaderBytes(staged.tempFile, 32)
            } else {
                ByteArray(0)
            }
            val detected = detectMimeAndExtFromBytes(header)
            val effectiveMime = detected?.first ?: resolveAccurateMimeType(customFileName, staged.mimeType)
            val finalName = if (detected != null) {
                applyDetectedExtensionIfNeeded(
                    sanitizeFileName(customFileName.ifBlank { staged.fileName }, effectiveMime),
                    detected.second
                )
            } else {
                sanitizeFileName(customFileName.ifBlank { staged.fileName }, effectiveMime)
            }

            staged.fileName = finalName
            staged.mimeType = effectiveMime
            staged.destination = destination

            var shouldCommitNow = false
            synchronized(staged.commitLock) {
                staged.userConfirmedSave = true
                if (staged.stagingFinished && !staged.committed) {
                    staged.committed = true
                    shouldCommitNow = true
                }
            }

            if (shouldCommitNow) {
                activeTransfers.remove(staged.transferId)
                stagedTransfersByUrl.remove(blobOrDataUrl)
                commitSessionFileToDestination(staged, blobOrDataUrl)
            } else {
                // Still receiving chunks in background: insert DB row & show progress notification now!
                val repo = repository
                if (repo != null && staged.dbRowId <= 0L) {
                    bridgeScope.launch {
                        try {
                            val rowId = repo.insertDownload(
                                DownloadEntity(
                                    systemDownloadId = -1L,
                                    fileName = finalName,
                                    url = blobOrDataUrl,
                                    mimeType = effectiveMime,
                                    status = DownloadStatus.RUNNING,
                                    totalBytes = staged.totalBytes,
                                    downloadedBytes = staged.bytesReceived,
                                    saveFolderLabel = destination.displayLabel()
                                )
                            )
                            staged.dbRowId = rowId
                            DownloadHelper.notifyForegroundServiceDownloadActive(context)
                            DownloadHelper.postDownloadProgressNotification(
                                context = context,
                                rowId = rowId,
                                fileName = finalName,
                                downloadedBytes = staged.bytesReceived,
                                totalBytes = staged.totalBytes,
                                folderLabel = destination.displayLabel()
                            )
                        } catch (_: Exception) {
                        }
                    }
                }
            }
            return
        }

        // Fallback if not pre-staged yet: execute direct extraction script in WebView
        if (fallbackWebView != null) {
            val script = DownloadHelper.buildBlobOrDataExtractionScript(
                blobOrDataUrl = blobOrDataUrl,
                suggestedName = customFileName,
                mimeType = mimeType,
                destination = destination
            )
            fallbackWebView.evaluateJavascript(script, null)
        }
    }

    fun discardPreStagedBlob(blobOrDataUrl: String) {
        val staged = stagedTransfersByUrl.remove(blobOrDataUrl) ?: return
        activeTransfers.remove(staged.transferId)
        try {
            staged.tempFile.delete()
        } catch (_: Exception) {
        }
    }

    private fun commitSessionFileToDestination(session: ActiveBlobTransfer, sourceUrl: String) {
        bridgeScope.launch {
            try {
                if (!session.tempFile.exists() || session.tempFile.length() == 0L) {
                    val rowId = session.dbRowId
                    if (rowId > 0L && repository != null) {
                        repository.deleteDownload(rowId)
                        DownloadHelper.cancelDownloadNotification(context, rowId)
                    }
                    return@launch
                }

                // Final magic-byte check on the physical temp file before moving to MediaStore/SAF
                val header = readHeaderBytes(session.tempFile, 32)
                val detected = detectMimeAndExtFromBytes(header)
                val finalName = if (detected != null) {
                    applyDetectedExtensionIfNeeded(session.fileName, detected.second)
                } else {
                    sanitizeFileName(session.fileName, session.mimeType)
                }
                val finalMime = detected?.first ?: resolveAccurateMimeType(finalName, session.mimeType)
                val fileSize = session.tempFile.length()
                val folderLabel = session.destination.displayLabel()

                val repo = repository
                var rowId = session.dbRowId
                if (rowId <= 0L && repo != null) {
                    rowId = repo.insertDownload(
                        DownloadEntity(
                            systemDownloadId = -1L,
                            fileName = finalName,
                            url = sourceUrl,
                            mimeType = finalMime,
                            status = DownloadStatus.RUNNING,
                            totalBytes = fileSize,
                            downloadedBytes = fileSize / 2,
                            saveFolderLabel = folderLabel
                        )
                    )
                    session.dbRowId = rowId
                }

                if (rowId > 0L) {
                    DownloadHelper.postDownloadProgressNotification(
                        context = context,
                        rowId = rowId,
                        fileName = finalName,
                        downloadedBytes = fileSize,
                        totalBytes = fileSize,
                        folderLabel = folderLabel
                    )
                }

                val savedUri = saveTempFileToDestination(
                    context = context,
                    sourceFile = session.tempFile,
                    fileName = finalName,
                    mimeType = finalMime,
                    destination = session.destination
                )
                session.tempFile.delete()

                if (savedUri != null) {
                    if (rowId > 0L && repo != null) {
                        repo.updateDownload(
                            DownloadEntity(
                                id = rowId,
                                systemDownloadId = -1L,
                                fileName = finalName,
                                url = sourceUrl,
                                mimeType = finalMime,
                                localUri = savedUri.toString(),
                                status = DownloadStatus.SUCCESSFUL,
                                totalBytes = fileSize,
                                downloadedBytes = fileSize,
                                saveFolderLabel = folderLabel
                            )
                        )
                    } else {
                        onBase64Saved(
                            finalName,
                            sourceUrl,
                            finalMime,
                            savedUri.toString(),
                            fileSize,
                            folderLabel
                        )
                    }

                    if (rowId > 0L) {
                        DownloadHelper.cancelDownloadNotification(context, rowId)
                    }
                    DownloadHelper.postDownloadCompleteNotification(
                        context = context,
                        fileName = finalName,
                        mimeType = finalMime,
                        fileUri = savedUri,
                        folderLabel = folderLabel,
                        sizeBytes = fileSize
                    )

                    withContext(Dispatchers.Main) {
                        Toast.makeText(
                            context,
                            "Download complete: $finalName ($folderLabel)",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                } else {
                    throw IllegalStateException("Could not write file to storage")
                }
            } catch (e: Exception) {
                session.tempFile.delete()
                val rowId = session.dbRowId
                if (rowId > 0L && repository != null) {
                    repository.updateDownload(
                        DownloadEntity(
                            id = rowId,
                            systemDownloadId = -1L,
                            fileName = session.fileName,
                            url = sourceUrl,
                            mimeType = session.mimeType,
                            status = DownloadStatus.FAILED,
                            saveFolderLabel = session.destination.displayLabel()
                        )
                    )
                    DownloadHelper.postDownloadFailedNotification(context, rowId, session.fileName)
                }
                withContext(Dispatchers.Main) {
                    Toast.makeText(context, "Download failed: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            } finally {
                DownloadHelper.notifyForegroundServiceDownloadIdleCheck(context, repository)
            }
        }
    }

    @JavascriptInterface
    fun saveBase64Data(base64DataUrl: String, fileName: String, mimeType: String) {
        saveBase64DataToDestination(
            base64DataUrl = base64DataUrl,
            fileName = fileName,
            mimeType = mimeType,
            presetName = DownloadFolderPreset.DOWNLOADS.name,
            customTreeUri = "",
            customFolderLabel = ""
        )
    }

    @JavascriptInterface
    fun saveBase64DataToDestination(
        base64DataUrl: String,
        fileName: String,
        mimeType: String,
        presetName: String,
        customTreeUri: String,
        customFolderLabel: String
    ) {
        bridgeScope.launch {
            val dir = File(context.cacheDir, "blob_transfers").apply { mkdirs() }
            val tempFile = File(dir, "data_${System.nanoTime()}.tmp")
            try {
                val rawMime = mimeType.ifBlank {
                    extractMimeFromDataUrl(base64DataUrl) ?: "application/octet-stream"
                }
                val payload = if (base64DataUrl.contains("base64,")) {
                    val base64Part = base64DataUrl.substringAfter("base64,", "")
                    if (base64Part.isEmpty()) return@launch
                    Base64.decode(base64Part, Base64.DEFAULT)
                } else if (base64DataUrl.startsWith("data:")) {
                    val rawPart = base64DataUrl.substringAfter(",", "")
                    URLDecoder.decode(rawPart, "UTF-8").toByteArray(Charsets.UTF_8)
                } else {
                    Base64.decode(base64DataUrl, Base64.DEFAULT)
                }
                if (payload.isEmpty()) return@launch
                tempFile.writeBytes(payload)

                val detected = detectMimeAndExtFromBytes(payload)
                val effectiveMime = detected?.first ?: rawMime
                val initialSafeName = sanitizeFileName(
                    fileName.ifBlank { "download_${System.currentTimeMillis()}" },
                    effectiveMime
                )
                val safeName = if (detected != null) {
                    applyDetectedExtensionIfNeeded(initialSafeName, detected.second)
                } else {
                    initialSafeName
                }
                val safeMime = resolveAccurateMimeType(safeName, effectiveMime)

                val destination = DownloadDestination(
                    preset = DownloadFolderPreset.fromId(presetName),
                    customTreeUri = customTreeUri,
                    customFolderLabel = customFolderLabel
                )
                val savedUri = saveTempFileToDestination(
                    context = context,
                    sourceFile = tempFile,
                    fileName = safeName,
                    mimeType = safeMime,
                    destination = destination
                )
                val folderLabel = destination.displayLabel()
                if (savedUri != null) {
                    onBase64Saved(
                        safeName,
                        base64DataUrl.take(96),
                        safeMime,
                        savedUri.toString(),
                        payload.size.toLong(),
                        folderLabel
                    )
                    DownloadHelper.postDownloadCompleteNotification(
                        context = context,
                        fileName = safeName,
                        mimeType = safeMime,
                        fileUri = savedUri,
                        folderLabel = folderLabel,
                        sizeBytes = payload.size.toLong()
                    )
                    withContext(Dispatchers.Main) {
                        Toast.makeText(
                            context,
                            "Download complete: $safeName ($folderLabel)",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(context, "Download failed: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            } finally {
                tempFile.delete()
            }
        }
    }

    private fun extractMimeFromDataUrl(dataUrl: String): String? {
        if (!dataUrl.startsWith("data:")) return null
        val header = dataUrl.substringAfter("data:").substringBefore(";").substringBefore(",")
        return header.takeIf { it.contains("/") }
    }
}

private fun readHeaderBytes(file: File, maxBytes: Int = 32): ByteArray {
    return try {
        if (!file.exists() || file.length() <= 0L) return ByteArray(0)
        val count = file.length().coerceAtMost(maxBytes.toLong()).toInt()
        val buf = ByteArray(count)
        FileInputStream(file).use { it.read(buf) }
        buf
    } catch (_: Exception) {
        ByteArray(0)
    }
}

/**
 * Inspects the binary magic bytes of a file/blob so WAV, MP3, OGG, FLAC, M4A, ZIP, PDF, APK,
 * PNG, JPEG, GIF, WebP, MP4, and WebM files are ALWAYS identified accurately even when
 * Chromium's WebView sniffs a WAV ("RIFF....WAVE") or binary blob as `text/plain`!
 */
fun detectMimeAndExtFromBytes(bytes: ByteArray): Pair<String, String>? {
    if (bytes.size < 4) return null
    val b0 = bytes[0].toInt() and 0xFF
    val b1 = bytes[1].toInt() and 0xFF
    val b2 = bytes[2].toInt() and 0xFF
    val b3 = bytes[3].toInt() and 0xFF

    // 1. RIFF container: WAV ("WAVE"), WebP ("WEBP"), or AVI ("AVI ")
    if (b0 == 0x52 && b1 == 0x49 && b2 == 0x46 && b3 == 0x46 && bytes.size >= 12) {
        val f0 = bytes[8].toInt() and 0xFF
        val f1 = bytes[9].toInt() and 0xFF
        val f2 = bytes[10].toInt() and 0xFF
        val f3 = bytes[11].toInt() and 0xFF
        if (f0 == 0x57 && f1 == 0x41 && f2 == 0x56 && f3 == 0x45) {
            return "audio/wav" to "wav"
        }
        if (f0 == 0x57 && f1 == 0x45 && f2 == 0x42 && f3 == 0x50) {
            return "image/webp" to "webp"
        }
        if (f0 == 0x41 && f1 == 0x56 && f2 == 0x49 && f3 == 0x20) {
            return "video/x-msvideo" to "avi"
        }
    }

    // 2. OGG Audio ("OggS")
    if (b0 == 0x4F && b1 == 0x67 && b2 == 0x67 && b3 == 0x53) {
        return "audio/ogg" to "ogg"
    }

    // 3. FLAC Audio ("fLaC")
    if (b0 == 0x66 && b1 == 0x4C && b2 == 0x61 && b3 == 0x43) {
        return "audio/flac" to "flac"
    }

    // 4. MP3 Audio ("ID3" tag or MPEG sync frame 0xFF 0xFB / 0xFF 0xF3 / 0xFF 0xF2 / 0xFF 0xE3)
    if (b0 == 0x49 && b1 == 0x44 && b2 == 0x33) {
        return "audio/mpeg" to "mp3"
    }
    if (b0 == 0xFF && (b1 == 0xFB || b1 == 0xF3 || b1 == 0xF2 || b1 == 0xE3)) {
        return "audio/mpeg" to "mp3"
    }

    // 5. ADTS AAC Audio (0xFF 0xF1 or 0xFF 0xF9)
    if (b0 == 0xFF && (b1 == 0xF1 || b1 == 0xF9)) {
        return "audio/aac" to "aac"
    }

    // 6. ISO Base Media File Format ("....ftyp"): M4A audio vs MP4/MOV video
    if (bytes.size >= 12 &&
        (bytes[4].toInt() and 0xFF) == 0x66 &&
        (bytes[5].toInt() and 0xFF) == 0x74 &&
        (bytes[6].toInt() and 0xFF) == 0x79 &&
        (bytes[7].toInt() and 0xFF) == 0x70
    ) {
        val brand = String(bytes, 8, 4, Charsets.US_ASCII)
        return if (brand.equals("M4A ", ignoreCase = true) || brand.equals("M4B ", ignoreCase = true)) {
            "audio/mp4" to "m4a"
        } else {
            "video/mp4" to "mp4"
        }
    }

    // 7. WebM / Matroska (0x1A 0x45 0xDF 0xA3)
    if (b0 == 0x1A && b1 == 0x45 && b2 == 0xDF && b3 == 0xA3) {
        return "video/webm" to "webm"
    }

    // 8. ZIP / APK / Office Container ("PK\x03\x04" or "PK\x05\x06")
    if (b0 == 0x50 && b1 == 0x4B && ((b2 == 0x03 && b3 == 0x04) || (b2 == 0x05 && b3 == 0x06))) {
        return "application/zip" to "zip"
    }

    // 9. PDF Document ("%PDF")
    if (b0 == 0x25 && b1 == 0x50 && b2 == 0x44 && b3 == 0x46) {
        return "application/pdf" to "pdf"
    }

    // 10. PNG Image ("\x89PNG")
    if (b0 == 0x89 && b1 == 0x50 && b2 == 0x4E && b3 == 0x47) {
        return "image/png" to "png"
    }

    // 11. JPEG Image (0xFF 0xD8 0xFF)
    if (b0 == 0xFF && b1 == 0xD8 && b2 == 0xFF) {
        return "image/jpeg" to "jpg"
    }

    // 12. GIF Image ("GIF8")
    if (b0 == 0x47 && b1 == 0x49 && b2 == 0x46 && b3 == 0x38) {
        return "image/gif" to "gif"
    }

    // 13. RAR Archive ("Rar!")
    if (b0 == 0x52 && b1 == 0x61 && b2 == 0x72 && b3 == 0x21) {
        return "application/vnd.rar" to "rar"
    }

    // 14. 7z Archive (0x37 0x7A 0xBC 0xAF)
    if (b0 == 0x37 && b1 == 0x7A && b2 == 0xBC && b3 == 0xAF) {
        return "application/x-7z-compressed" to "7z"
    }

    // 15. GZIP Archive (0x1F 0x8B)
    if (b0 == 0x1F && b1 == 0x8B) {
        return "application/gzip" to "gz"
    }

    return null
}

fun detectMimeAndExtFromMagicHex(magicHex: String?): Pair<String, String>? {
    if (magicHex.isNullOrBlank() || magicHex.length < 8) return null
    val clean = magicHex.trim().lowercase(Locale.US)
    val len = (clean.length / 2).coerceAtMost(32)
    val bytes = ByteArray(len)
    for (i in 0 until len) {
        val hi = Character.digit(clean[i * 2], 16)
        val lo = Character.digit(clean[i * 2 + 1], 16)
        if (hi < 0 || lo < 0) return null
        bytes[i] = ((hi shl 4) or lo).toByte()
    }
    return detectMimeAndExtFromBytes(bytes)
}

/**
 * Replaces a wrong/generic extension (like `.txt`, `.bin`, `.dat`, `.download`, or missing extension)
 * when binary magic bytes prove the file is actually a WAV, MP3, OGG, ZIP, PDF, PNG, etc.
 * Preserves specialized ZIP container extensions (`.apk`, `.docx`, `.xlsx`, `.pptx`, `.jar`, `.epub`).
 */
fun applyDetectedExtensionIfNeeded(currentFileName: String, detectedExt: String): String {
    val clean = currentFileName.trim().ifBlank { "download_${System.currentTimeMillis()}.$detectedExt" }
    val dotIdx = clean.lastIndexOf('.')
    if (dotIdx <= 0 || dotIdx == clean.lastIndex) {
        return "${clean.trimEnd('.')}.$detectedExt"
    }
    val currentExt = clean.substring(dotIdx + 1).lowercase(Locale.US)
    if (currentExt == detectedExt.lowercase(Locale.US)) {
        return clean
    }
    // If magic bytes say ZIP, preserve specialized ZIP-based formats if the file already has one
    if (detectedExt.equals("zip", ignoreCase = true) &&
        currentExt in setOf("apk", "aab", "docx", "xlsx", "pptx", "jar", "epub", "odt")
    ) {
        return clean
    }
    // If current extension is a generic/misclassified text or binary fallback, replace it with the true extension!
    val replaceableExtensions = setOf("txt", "bin", "dat", "tmp", "download", "html", "htm", "raw")
    if (currentExt in replaceableExtensions) {
        val baseName = clean.substring(0, dotIdx)
        return "$baseName.$detectedExt"
    }
    return clean
}

fun buildSmartBlobFileName(
    rawSuggestedName: String?,
    rawMime: String?,
    magicHex: String?,
    pageUrl: String?
): String {
    val detected = detectMimeAndExtFromMagicHex(magicHex)
    val effectiveMime = when {
        detected != null -> detected.first
        !rawMime.isNullOrBlank() &&
            !rawMime.equals("text/plain", ignoreCase = true) &&
            !rawMime.equals("application/octet-stream", ignoreCase = true) -> rawMime
        pageUrl?.contains("generate-speech", ignoreCase = true) == true -> "audio/wav"
        else -> rawMime ?: "application/octet-stream"
    }
    val baseCandidate = if (!rawSuggestedName.isNullOrBlank()) {
        rawSuggestedName.trim()
    } else {
        val prefix = when {
            effectiveMime.startsWith("audio/") ||
                pageUrl?.contains("generate-speech", ignoreCase = true) == true -> "ai_studio_audio"
            effectiveMime.contains("zip") -> "ai_studio_project"
            effectiveMime.startsWith("image/") -> "image"
            effectiveMime.startsWith("video/") -> "video"
            else -> "download"
        }
        "${prefix}_${System.currentTimeMillis()}"
    }
    val sanitized = sanitizeFileName(baseCandidate, effectiveMime)
    return if (detected != null) {
        applyDetectedExtensionIfNeeded(sanitized, detected.second)
    } else {
        sanitized
    }
}

fun sanitizeFileName(rawName: String, mimeType: String): String {
    val decoded = try {
        if (rawName.contains("%")) URLDecoder.decode(rawName, "UTF-8") else rawName
    } catch (_: Exception) {
        rawName
    }
    val clean = decoded
        .replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001F]"), "_")
        .trim()
        .trimStart('.')
        .ifBlank { "download_${System.currentTimeMillis()}" }

    val extFromMime = guessExtensionFromMime(mimeType)
        ?: MimeTypeMap.getSingleton().getExtensionFromMimeType(mimeType.substringBefore(";").trim())

    val hasValidExt = clean.contains(".") && !clean.endsWith(".") &&
        clean.substringAfterLast('.').length in 1..8
    if (hasValidExt) {
        val currentExt = clean.substringAfterLast('.').lowercase(Locale.US)
        // If filename was given .txt or .bin but the MIME type is clearly audio/video/zip/image/pdf, fix the extension!
        if ((currentExt == "txt" || currentExt == "bin") &&
            !extFromMime.isNullOrBlank() &&
            extFromMime != "txt" &&
            extFromMime != "bin"
        ) {
            return "${clean.substringBeforeLast('.')}.$extFromMime"
        }
        return clean
    }

    return if (!extFromMime.isNullOrBlank()) "${clean.trimEnd('.')}.$extFromMime" else clean
}

private fun guessExtensionFromMime(mimeType: String): String? {
    val m = mimeType.lowercase(Locale.US).substringBefore(";").trim()
    return when (m) {
        "image/jpeg", "image/jpg" -> "jpg"
        "image/png" -> "png"
        "image/webp" -> "webp"
        "image/gif" -> "gif"
        "image/svg+xml" -> "svg"
        "video/mp4" -> "mp4"
        "video/webm" -> "webm"
        "video/x-matroska" -> "mkv"
        "video/quicktime" -> "mov"
        "audio/mpeg", "audio/mp3" -> "mp3"
        "audio/wav", "audio/x-wav", "audio/wave", "audio/vnd.wave" -> "wav"
        "audio/ogg", "application/ogg" -> "ogg"
        "audio/mp4", "audio/x-m4a", "audio/m4a" -> "m4a"
        "audio/flac", "audio/x-flac" -> "flac"
        "audio/aac" -> "aac"
        "audio/opus" -> "opus"
        "audio/webm" -> "webm"
        "application/pdf" -> "pdf"
        "application/zip", "application/x-zip-compressed", "application/x-zip" -> "zip"
        "application/vnd.rar", "application/x-rar-compressed" -> "rar"
        "application/x-7z-compressed" -> "7z"
        "application/gzip", "application/x-gzip" -> "gz"
        "application/vnd.android.package-archive" -> "apk"
        "application/json" -> "json"
        "text/plain" -> "txt"
        "text/html" -> "html"
        "text/csv" -> "csv"
        "application/x-subrip", "text/srt" -> "srt"
        else -> null
    }
}

fun resolveAccurateMimeType(
    fileName: String,
    rawMimeType: String?,
    magicHex: String? = null
): String {
    val magicDetected = detectMimeAndExtFromMagicHex(magicHex)
    if (magicDetected != null) {
        val lower = fileName.lowercase(Locale.US)
        if (magicDetected.second == "zip" && lower.endsWith(".apk")) {
            return "application/vnd.android.package-archive"
        }
        return magicDetected.first
    }

    val cleanMime = rawMimeType?.substringBefore(";")?.trim().orEmpty()
    val lowerName = fileName.lowercase(Locale.US)
    val ext = lowerName.substringAfterLast('.', "")
    val mimeFromExt = when (ext) {
        "jpg", "jpeg" -> "image/jpeg"
        "png" -> "image/png"
        "webp" -> "image/webp"
        "gif" -> "image/gif"
        "bmp" -> "image/bmp"
        "svg" -> "image/svg+xml"
        "mp4", "m4v" -> "video/mp4"
        "mkv" -> "video/x-matroska"
        "webm" -> "video/webm"
        "mov" -> "video/quicktime"
        "avi" -> "video/x-msvideo"
        "mp3" -> "audio/mpeg"
        "wav" -> "audio/wav"
        "m4a" -> "audio/mp4"
        "ogg", "oga", "opus" -> "audio/ogg"
        "flac" -> "audio/flac"
        "aac" -> "audio/aac"
        "pdf" -> "application/pdf"
        "apk" -> "application/vnd.android.package-archive"
        "zip" -> "application/zip"
        "rar" -> "application/vnd.rar"
        "7z" -> "application/x-7z-compressed"
        "tar" -> "application/x-tar"
        "gz", "tgz" -> "application/gzip"
        "json" -> "application/json"
        "srt" -> "text/plain"
        "txt", "log", "md", "kt", "java", "py", "js", "ts", "css" -> "text/plain"
        "html", "htm" -> "text/html"
        "csv" -> "text/csv"
        "xml" -> "text/xml"
        "doc" -> "application/msword"
        "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        "xls" -> "application/vnd.ms-excel"
        "xlsx" -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        "ppt" -> "application/vnd.ms-powerpoint"
        "pptx" -> "application/vnd.openxmlformats-officedocument.presentationml.presentation"
        else -> if (ext.isNotBlank()) MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) else null
    }
    if (!mimeFromExt.isNullOrBlank()) {
        // If filename has .txt only because Chromium mis-sniffed it, but rawMimeType is a real non-text type, prefer rawMimeType
        if (ext == "txt" && cleanMime.isNotBlank() &&
            !cleanMime.startsWith("text/") &&
            !cleanMime.equals("application/octet-stream", ignoreCase = true)
        ) {
            return cleanMime
        }
        return mimeFromExt
    }
    if (cleanMime.isNotBlank() &&
        !cleanMime.equals("application/octet-stream", ignoreCase = true) &&
        !cleanMime.equals("binary/octet-stream", ignoreCase = true)
    ) {
        return cleanMime
    }
    return "application/octet-stream"
}

fun formatSafTreeLabel(treeUri: Uri): String {
    return try {
        val docId = DocumentsContract.getTreeDocumentId(treeUri)
        val normalized = when {
            docId.startsWith("primary:", ignoreCase = true) -> {
                val rel = docId.substringAfter(":").trim('/')
                if (rel.isEmpty()) "/Internal Storage" else "/$rel"
            }
            docId.contains(":") -> {
                val vol = docId.substringBefore(":")
                val rel = docId.substringAfter(":").trim('/')
                if (rel.isEmpty()) "/$vol" else "/$vol/$rel"
            }
            else -> "/$docId"
        }
        normalized
    } catch (_: Exception) {
        treeUri.lastPathSegment ?: "Selected Folder"
    }
}

fun writeBytesToDownloads(
    context: Context,
    fileName: String,
    mimeType: String,
    bytes: ByteArray
): Uri? = writeBytesToDestination(context, fileName, mimeType, bytes, DownloadDestination())

fun writeBytesToDestination(
    context: Context,
    fileName: String,
    mimeType: String,
    bytes: ByteArray,
    destination: DownloadDestination
): Uri? {
    val tempDir = File(context.cacheDir, "save_staging").apply { mkdirs() }
    val stagingFile = File(tempDir, "bytes_${System.nanoTime()}.tmp")
    return try {
        stagingFile.writeBytes(bytes)
        saveTempFileToDestination(context, stagingFile, fileName, mimeType, destination)
    } catch (_: Exception) {
        null
    } finally {
        stagingFile.delete()
    }
}

/**
 * Saves a staged file from disk to the user's chosen destination (Custom SAF folder, MediaStore
 * public directories, or direct public storage) without loading the entire file into RAM.
 * Supports ALL file types (Audio, Video, Images, ZIP, APK, PDF, Documents, Arbitrary Binaries).
 */
fun saveTempFileToDestination(
    context: Context,
    sourceFile: File,
    fileName: String,
    mimeType: String,
    destination: DownloadDestination
): Uri? {
    if (!sourceFile.exists() || sourceFile.length() <= 0L) return null
    val header = readHeaderBytes(sourceFile, 32)
    val detected = detectMimeAndExtFromBytes(header)
    val finalFileName = if (detected != null) {
        applyDetectedExtensionIfNeeded(fileName, detected.second)
    } else {
        sanitizeFileName(fileName, mimeType)
    }
    val resolvedMime = detected?.first ?: resolveAccurateMimeType(finalFileName, mimeType)

    // 1. Custom SAF Folder selected via ACTION_OPEN_DOCUMENT_TREE
    if (destination.preset == DownloadFolderPreset.CUSTOM_SAF && destination.customTreeUri.isNotBlank()) {
        try {
            val treeUri = Uri.parse(destination.customTreeUri)
            val parentDocUri = DocumentsContract.buildDocumentUriUsingTree(
                treeUri,
                DocumentsContract.getTreeDocumentId(treeUri)
            )
            val createdUri = DocumentsContract.createDocument(
                context.contentResolver,
                parentDocUri,
                resolvedMime,
                finalFileName
            )
            if (createdUri != null) {
                var copiedOk = false
                context.contentResolver.openOutputStream(createdUri)?.use { out ->
                    FileInputStream(sourceFile).use { input ->
                        input.copyTo(out, 64 * 1024)
                    }
                    out.flush()
                    copiedOk = true
                }
                if (copiedOk) {
                    triggerMediaScanForSafUri(context, treeUri, finalFileName, resolvedMime)
                    return createdUri
                }
            }
        } catch (_: Exception) {
            // Fall through to public Downloads if SAF permission was revoked
        }
    }

    val preset = destination.preset
    val primaryDirType = preset.publicDirType

    // 2. Android 10+ (API 29+) MediaStore Scoped Storage
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        val resolver = context.contentResolver
        // Only target media-specific MediaStore tables when the file's actual MIME matches;
        // MediaStore.Downloads accepts ALL file types (Audio, Video, ZIP, APK, PDF, Images, etc.)!
        val primaryCollectionUri = when {
            preset == DownloadFolderPreset.PICTURES && resolvedMime.startsWith("image/") ->
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            preset == DownloadFolderPreset.MUSIC && resolvedMime.startsWith("audio/") ->
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            preset == DownloadFolderPreset.MOVIES && resolvedMime.startsWith("video/") ->
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            preset == DownloadFolderPreset.DOCUMENTS ->
                MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            else ->
                MediaStore.Downloads.EXTERNAL_CONTENT_URI
        }

        val targetRelPath = when {
            preset == DownloadFolderPreset.STUDIO_DOWNLOADS ->
                "${Environment.DIRECTORY_DOWNLOADS}/Flowra"
            preset == DownloadFolderPreset.DOWNLOADS || preset == DownloadFolderPreset.CUSTOM_SAF ->
                Environment.DIRECTORY_DOWNLOADS
            preset == DownloadFolderPreset.PICTURES && !resolvedMime.startsWith("image/") ->
                Environment.DIRECTORY_DOWNLOADS
            preset == DownloadFolderPreset.MUSIC && !resolvedMime.startsWith("audio/") ->
                Environment.DIRECTORY_DOWNLOADS
            preset == DownloadFolderPreset.MOVIES && !resolvedMime.startsWith("video/") ->
                Environment.DIRECTORY_DOWNLOADS
            else -> buildString {
                append(primaryDirType)
                if (!preset.subFolder.isNullOrBlank()) {
                    append("/")
                    append(preset.subFolder)
                }
            }
        }

        val candidateNames = listOf(
            finalFileName,
            buildDeduplicatedName(finalFileName, 1),
            buildDeduplicatedName(finalFileName, (System.currentTimeMillis() % 10000).toInt())
        )

        for (candidateName in candidateNames) {
            try {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, candidateName)
                    put(MediaStore.MediaColumns.MIME_TYPE, resolvedMime)
                    put(MediaStore.MediaColumns.RELATIVE_PATH, targetRelPath)
                }
                val insertedUri = try {
                    resolver.insert(primaryCollectionUri, values)
                } catch (_: Exception) {
                    null
                } ?: try {
                    resolver.insert(
                        MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                        ContentValues().apply {
                            put(MediaStore.MediaColumns.DISPLAY_NAME, candidateName)
                            put(MediaStore.MediaColumns.MIME_TYPE, resolvedMime)
                            put(
                                MediaStore.MediaColumns.RELATIVE_PATH,
                                if (preset == DownloadFolderPreset.STUDIO_DOWNLOADS) {
                                    "${Environment.DIRECTORY_DOWNLOADS}/Flowra"
                                } else {
                                    Environment.DIRECTORY_DOWNLOADS
                                }
                            )
                        }
                    )
                } catch (_: Exception) {
                    null
                } ?: try {
                    resolver.insert(
                        MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                        ContentValues().apply {
                            put(MediaStore.MediaColumns.DISPLAY_NAME, candidateName)
                            put(MediaStore.MediaColumns.MIME_TYPE, "application/octet-stream")
                            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                        }
                    )
                } catch (_: Exception) {
                    null
                }

                if (insertedUri != null) {
                    var writeSucceeded = false
                    resolver.openOutputStream(insertedUri)?.use { out ->
                        FileInputStream(sourceFile).use { stageIn ->
                            stageIn.copyTo(out, 64 * 1024)
                        }
                        out.flush()
                        writeSucceeded = true
                    }
                    if (writeSucceeded) {
                        val realPath = queryMediaStoreFilePath(context, insertedUri)
                        if (!realPath.isNullOrBlank()) {
                            val realFile = File(realPath)
                            if (realFile.exists()) {
                                scanFileForFileManager(context, realFile, resolvedMime)
                            }
                        }
                        return insertedUri
                    }
                }
            } catch (_: Exception) {
            }
        }
    }

    // 3. Direct Public Directory File write fallback (/storage/emulated/0/Download/<fileName>)
    try {
        @Suppress("DEPRECATION")
        val basePubDir = Environment.getExternalStoragePublicDirectory(primaryDirType)
        val targetPubDir = if (!preset.subFolder.isNullOrBlank() && basePubDir != null) {
            File(basePubDir, preset.subFolder)
        } else {
            basePubDir
        }
        if (targetPubDir != null && (targetPubDir.exists() || targetPubDir.mkdirs())) {
            val targetFile = buildUniqueFileInDir(targetPubDir, finalFileName)
            FileInputStream(sourceFile).use { stageIn ->
                FileOutputStream(targetFile).use { fileOut ->
                    stageIn.copyTo(fileOut, 64 * 1024)
                    fileOut.flush()
                    try {
                        fileOut.fd.sync()
                    } catch (_: Exception) {
                    }
                }
            }
            if (targetFile.exists() && targetFile.length() > 0L) {
                scanFileForFileManager(context, targetFile, resolvedMime)
                return FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    targetFile
                )
            }
        }
    } catch (_: Exception) {
    }

    // 4. App-specific external Downloads fallback (guaranteed writable on all sandboxes)
    try {
        val appDownloadsDir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
            ?: File(context.filesDir, "Downloads")
        if (!appDownloadsDir.exists()) appDownloadsDir.mkdirs()
        val fallbackFile = buildUniqueFileInDir(appDownloadsDir, finalFileName)
        sourceFile.copyTo(fallbackFile, overwrite = true)
        if (fallbackFile.exists() && fallbackFile.length() > 0L) {
            scanFileForFileManager(context, fallbackFile, resolvedMime)
            return FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                fallbackFile
            )
        }
    } catch (_: Exception) {
    }

    return null
}

private fun triggerMediaScanForSafUri(
    context: Context,
    treeUri: Uri,
    fileName: String,
    mimeType: String
) {
    try {
        val docId = DocumentsContract.getTreeDocumentId(treeUri)
        if (docId.startsWith("primary:", ignoreCase = true)) {
            val rel = docId.substringAfter(":").trim('/')
            @Suppress("DEPRECATION")
            val root = Environment.getExternalStorageDirectory()
            val targetDir = if (rel.isEmpty()) root else File(root, rel)
            val targetFile = File(targetDir, fileName)
            if (targetFile.exists()) {
                scanFileForFileManager(context, targetFile, mimeType)
            }
        }
    } catch (_: Exception) {
    }
}

private fun scanFileForFileManager(
    context: Context,
    file: File,
    mimeType: String
) {
    try {
        MediaScannerConnection.scanFile(
            context.applicationContext,
            arrayOf(file.absolutePath),
            arrayOf(mimeType),
            null
        )
    } catch (_: Exception) {
    }
    try {
        @Suppress("DEPRECATION")
        val scanIntent = Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(file))
        context.applicationContext.sendBroadcast(scanIntent)
    } catch (_: Exception) {
    }
}

private fun queryMediaStoreFilePath(context: Context, uri: Uri): String? {
    return try {
        val projection = arrayOf(MediaStore.MediaColumns.DATA)
        context.contentResolver.query(uri, projection, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex(MediaStore.MediaColumns.DATA)
                if (idx >= 0) cursor.getString(idx) else null
            } else {
                null
            }
        }
    } catch (_: Exception) {
        null
    }
}

private fun buildUniqueFileInDir(dir: File, desiredName: String): File {
    var candidate = File(dir, desiredName)
    if (!candidate.exists()) return candidate
    val dotIdx = desiredName.lastIndexOf('.')
    val base = if (dotIdx > 0) desiredName.substring(0, dotIdx) else desiredName
    val ext = if (dotIdx > 0) desiredName.substring(dotIdx) else ""
    var counter = 1
    while (candidate.exists() && counter < 999) {
        candidate = File(dir, "$base ($counter)$ext")
        counter++
    }
    return candidate
}

private fun buildDeduplicatedName(fileName: String, index: Int): String {
    val dotIdx = fileName.lastIndexOf('.')
    return if (dotIdx > 0) {
        val base = fileName.substring(0, dotIdx)
        val ext = fileName.substring(dotIdx)
        "$base ($index)$ext"
    } else {
        "$fileName ($index)"
    }
}

private fun copyStreamWithProgress(
    input: InputStream,
    output: java.io.OutputStream,
    cancelFlag: AtomicBoolean? = null,
    onProgress: ((Long) -> Unit)?
) {
    val buffer = ByteArray(32 * 1024)
    var total = 0L
    var lastReportedBytes = 0L
    var lastReportedTime = 0L
    while (true) {
        if (cancelFlag?.get() == true) {
            throw CancellationException("Download cancelled by user")
        }
        val read = input.read(buffer)
        if (read <= 0) break
        output.write(buffer, 0, read)
        total += read
        if (onProgress != null) {
            val now = System.currentTimeMillis()
            if (lastReportedBytes == 0L ||
                (total - lastReportedBytes >= 32 * 1024L && now - lastReportedTime >= 250L)
            ) {
                lastReportedBytes = total
                lastReportedTime = now
                onProgress(total)
            }
        }
    }
    output.flush()
    onProgress?.invoke(total)
}

object DownloadHelper {

    private const val DOWNLOAD_CHANNEL_ID = "flowra_downloads_channel"
    private const val DOWNLOAD_PROGRESS_CHANNEL_ID = "flowra_downloads_progress_channel"
    const val EXTRA_OPEN_DOWNLOADS = "extra_open_downloads_sheet"

    private val backgroundDownloadScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val activeInProcessRowIds = ConcurrentHashMap<Long, Long>()
    private val activeCancelFlags = ConcurrentHashMap<Long, AtomicBoolean>()
    private val activeJobs = ConcurrentHashMap<Long, Job>()

    fun activeDownloadCount(): Int = activeInProcessRowIds.size

    fun detectMimeAndExtFromBytes(header: ByteArray, length: Int = header.size): Pair<String, String>? =
        com.example.detectMimeAndExtFromBytes(
            if (length in 0 until header.size) header.copyOf(length) else header
        )

    fun detectMimeAndExtFromMagicHex(magicHex: String?): Pair<String, String>? =
        com.example.detectMimeAndExtFromMagicHex(magicHex)

    fun applyDetectedExtensionIfNeeded(currentFileName: String, mimeOrExt: String): String {
        val ext = if (mimeOrExt.contains("/")) {
            guessExtensionFromMime(mimeOrExt) ?: mimeOrExt.substringAfterLast('/').lowercase(Locale.US)
        } else {
            mimeOrExt.trimStart('.').lowercase(Locale.US)
        }
        if (ext.isBlank() || ext == "octet-stream" || ext == "plain") {
            return currentFileName
        }
        return com.example.applyDetectedExtensionIfNeeded(currentFileName, ext)
    }

    fun cancelActiveDownload(context: Context, repository: BrowserRepository, rowId: Long) {
        activeCancelFlags[rowId]?.set(true)
        activeJobs.remove(rowId)?.cancel()
        activeInProcessRowIds.remove(rowId)
        cancelDownloadNotification(context, rowId)
        backgroundDownloadScope.launch {
            try {
                repository.deleteDownload(rowId)
            } catch (_: Exception) {
            }
            notifyForegroundServiceDownloadIdleCheck(context, repository)
        }
    }

    fun notifyForegroundServiceDownloadActive(context: Context) {
        try {
            val tabCount = WebViewManager.getInstanceIfCreated()?.tabsState?.value?.size ?: 5
            BrowserService.startKeepAliveService(
                context = context.applicationContext,
                tabCount = tabCount,
                pwaCount = PwaWebViewPool.liveCount()
            )
        } catch (_: Exception) {
        }
    }

    fun notifyForegroundServiceDownloadIdleCheck(context: Context, repository: BrowserRepository?) {
        try {
            val tabCount = WebViewManager.getInstanceIfCreated()?.tabsState?.value?.size ?: 5
            BrowserService.startKeepAliveService(
                context = context.applicationContext,
                tabCount = tabCount,
                pwaCount = PwaWebViewPool.liveCount()
            )
        } catch (_: Exception) {
        }
    }

    /**
     * Streams blob: or data: URLs in 512 KB binary chunks via StudioDownloadBridge so large
     * .zip, .wav, .mp3, and .apk files never hit WebView JNI Base64 string limits,
     * searches both the main window and child iframes for `window.__flowraBlobStore`,
     * and falls back to XMLHttpRequest if Content-Security-Policy blocks fetch().
     */
    fun buildBlobOrDataExtractionScript(
        blobOrDataUrl: String,
        suggestedName: String,
        mimeType: String,
        destination: DownloadDestination = DownloadDestination(),
        preStageOnly: Boolean = false
    ): String {
        val escapedUrl = blobOrDataUrl.replace("\\", "\\\\").replace("'", "\\'")
        val escapedName = suggestedName.replace("\\", "\\\\").replace("'", "\\'")
        val escapedMime = mimeType.replace("\\", "\\\\").replace("'", "\\'")
        val escapedPreset = destination.preset.name.replace("'", "\\'")
        val escapedTree = destination.customTreeUri.replace("\\", "\\\\").replace("'", "\\'")
        val escapedLabel = destination.customFolderLabel.replace("\\", "\\\\").replace("'", "\\'")
        val preStageFlag = if (preStageOnly) "true" else "false"
        return """
            (function() {
                try {
                    var targetUrl = '$escapedUrl';
                    var fallbackName = '$escapedName';
                    var fallbackMime = '$escapedMime';
                    var presetName = '$escapedPreset';
                    var customTree = '$escapedTree';
                    var customLabel = '$escapedLabel';
                    var isPreStage = $preStageFlag;

                    if (targetUrl.indexOf('data:') === 0 && !isPreStage) {
                        if (window.StudioDownloadBridge && window.StudioDownloadBridge.saveBase64DataToDestination) {
                            window.StudioDownloadBridge.saveBase64DataToDestination(
                                targetUrl, fallbackName, fallbackMime, presetName, customTree, customLabel
                            );
                        }
                        return;
                    }

                    function findCachedBlobInFrames(url) {
                        try {
                            if (window.__flowraBlobStore && window.__flowraBlobStore[url]) {
                                return window.__flowraBlobStore[url];
                            }
                            for (var i = 0; i < window.frames.length; i++) {
                                try {
                                    var fw = window.frames[i];
                                    if (fw && fw.__flowraBlobStore && fw.__flowraBlobStore[url]) {
                                        return fw.__flowraBlobStore[url];
                                    }
                                } catch (eFrame) {}
                            }
                        } catch (eLookup) {}
                        return null;
                    }

                    function fetchBlobWithXhrFallback(url) {
                        var cached = findCachedBlobInFrames(url);
                        if (cached) return Promise.resolve(cached);
                        return fetch(url).then(function(res) {
                            if (!res.ok) throw new Error('HTTP ' + res.status);
                            return res.blob();
                        }).catch(function() {
                            return new Promise(function(resolve, reject) {
                                try {
                                    var xhr = new XMLHttpRequest();
                                    xhr.open('GET', url, true);
                                    xhr.responseType = 'blob';
                                    xhr.onload = function() {
                                        if (xhr.status === 200 || xhr.status === 0) {
                                            resolve(xhr.response);
                                        } else {
                                            reject(new Error('XHR status ' + xhr.status));
                                        }
                                    };
                                    xhr.onerror = function() { reject(new Error('XHR error')); };
                                    xhr.send();
                                } catch (eXhr) {
                                    reject(eXhr);
                                }
                            });
                        });
                    }

                    function readMagicHex(blob, cb) {
                        try {
                            var headerSlice = blob.slice(0, Math.min(32, blob.size));
                            var fr = new FileReader();
                            fr.onloadend = function() {
                                try {
                                    var buf = fr.result;
                                    if (!buf) { cb(''); return; }
                                    var arr = new Uint8Array(buf);
                                    var hex = '';
                                    for (var i = 0; i < arr.length; i++) {
                                        var h = arr[i].toString(16);
                                        hex += (h.length === 1 ? '0' + h : h);
                                    }
                                    cb(hex);
                                } catch (eH) { cb(''); }
                            };
                            fr.onerror = function() { cb(''); };
                            fr.readAsArrayBuffer(headerSlice);
                        } catch (eS) {
                            cb('');
                        }
                    }

                    fetchBlobWithXhrFallback(targetUrl).then(function(blob) {
                        if (!blob || !window.StudioDownloadBridge) return;
                        var effectiveMime = blob.type || fallbackMime || 'application/octet-stream';
                        var transferId = 'tr_' + Date.now() + '_' + Math.floor(Math.random() * 100000);

                        readMagicHex(blob, function(magicHex) {
                            if (isPreStage) {
                                window.StudioDownloadBridge.beginPreStagedBlobTransfer(
                                    transferId,
                                    targetUrl,
                                    fallbackName,
                                    effectiveMime,
                                    blob.size || -1,
                                    magicHex || '',
                                    window.location ? window.location.href : ''
                                );
                            } else {
                                window.StudioDownloadBridge.startBlobTransfer(
                                    transferId, fallbackName, effectiveMime, presetName, customTree, customLabel
                                );
                            }

                            var chunkSize = 512 * 1024;
                            var offset = 0;

                            function sendNextChunk() {
                                if (offset >= blob.size) {
                                    window.StudioDownloadBridge.finishBlobTransfer(transferId, targetUrl);
                                    return;
                                }
                                var slice = blob.slice(offset, Math.min(offset + chunkSize, blob.size));
                                offset += chunkSize;
                                var reader = new FileReader();
                                reader.onloadend = function() {
                                    if (reader.result) {
                                        window.StudioDownloadBridge.appendBlobChunk(transferId, reader.result);
                                        sendNextChunk();
                                    } else {
                                        window.StudioDownloadBridge.finishBlobTransfer(transferId, targetUrl);
                                    }
                                };
                                reader.onerror = function() {
                                    window.StudioDownloadBridge.reportBlobTransferError(transferId, targetUrl, 'Chunk read error');
                                };
                                reader.readAsDataURL(slice);
                            }
                            sendNextChunk();
                        });
                    }).catch(function(err) {
                        if (window.StudioDownloadBridge && window.StudioDownloadBridge.reportBlobTransferError && !isPreStage) {
                            window.StudioDownloadBridge.reportBlobTransferError('err', targetUrl, err ? String(err) : 'Blob unavailable');
                        }
                    });
                } catch (e) {}
            })();
        """.trimIndent()
    }

    suspend fun enqueueHttpDownload(
        context: Context,
        repository: BrowserRepository,
        url: String,
        fileName: String,
        mimeType: String,
        userAgent: String
    ): Long = enqueueDownloadWithDestination(
        context = context,
        repository = repository,
        url = url,
        fileName = fileName,
        mimeType = mimeType,
        userAgent = userAgent,
        destination = DownloadDestination()
    )

    /**
     * Launches a background download in `backgroundDownloadScope` tied to `BrowserService` so
     * downloads continue seamlessly in the background even if the user minimizes or exits the app,
     * with real-time progress notifications in the Android status bar!
     */
    fun launchBackgroundHttpDownload(
        context: Context,
        repository: BrowserRepository,
        url: String,
        fileName: String,
        mimeType: String,
        userAgent: String,
        destination: DownloadDestination,
        refererUrl: String = "",
        existingRowId: Long? = null
    ) {
        val appCtx = context.applicationContext
        notifyForegroundServiceDownloadActive(appCtx)
        backgroundDownloadScope.launch {
            enqueueDownloadWithDestination(
                context = appCtx,
                repository = repository,
                url = url,
                fileName = fileName,
                mimeType = mimeType,
                userAgent = userAgent,
                destination = destination,
                refererUrl = refererUrl,
                existingRowId = existingRowId
            )
        }
    }

    suspend fun enqueueDownloadWithDestination(
        context: Context,
        repository: BrowserRepository,
        url: String,
        fileName: String,
        mimeType: String,
        userAgent: String,
        destination: DownloadDestination,
        refererUrl: String = "",
        existingRowId: Long? = null
    ): Long {
        val rawMime = mimeType.ifBlank { "application/octet-stream" }
        val finalName = sanitizeFileName(fileName, rawMime)
        val safeMime = resolveAccurateMimeType(finalName, rawMime)
        val folderLabel = destination.displayLabel()

        return streamHttpDownloadToSafOrMediaStore(
            context = context.applicationContext,
            repository = repository,
            url = url,
            finalName = finalName,
            safeMime = safeMime,
            userAgent = userAgent,
            destination = destination,
            folderLabel = folderLabel,
            refererUrl = refererUrl,
            existingRowId = existingRowId
        )
    }

    private suspend fun streamHttpDownloadToSafOrMediaStore(
        context: Context,
        repository: BrowserRepository,
        url: String,
        finalName: String,
        safeMime: String,
        userAgent: String,
        destination: DownloadDestination,
        folderLabel: String,
        refererUrl: String = "",
        existingRowId: Long? = null
    ): Long {
        val rowId = if (existingRowId != null && existingRowId > 0L) {
            repository.updateDownload(
                DownloadEntity(
                    id = existingRowId,
                    systemDownloadId = -1L,
                    fileName = finalName,
                    url = url,
                    mimeType = safeMime,
                    status = DownloadStatus.RUNNING,
                    totalBytes = -1L,
                    downloadedBytes = 0L,
                    saveFolderLabel = folderLabel
                )
            )
            existingRowId
        } else {
            repository.insertDownload(
                DownloadEntity(
                    systemDownloadId = -1L,
                    fileName = finalName,
                    url = url,
                    mimeType = safeMime,
                    status = DownloadStatus.RUNNING,
                    saveFolderLabel = folderLabel
                )
            )
        }

        val cancelFlag = AtomicBoolean(false)
        activeInProcessRowIds[rowId] = System.currentTimeMillis()
        activeCancelFlags[rowId] = cancelFlag
        notifyForegroundServiceDownloadActive(context)

        postDownloadProgressNotification(
            context = context,
            rowId = rowId,
            fileName = finalName,
            downloadedBytes = 0L,
            totalBytes = -1L,
            folderLabel = folderLabel
        )

        return withContext(Dispatchers.IO) {
            var connection: HttpURLConnection? = null
            val tempDir = File(context.cacheDir, "http_downloads").apply { mkdirs() }
            val tempFile = File(tempDir, "dl_${rowId}_${System.currentTimeMillis()}.tmp")
            var resolvedFileName = finalName
            var effectiveMime = safeMime
            try {
                connection = openFollowedHttpConnection(url, userAgent, refererUrl)
                val responseCode = try {
                    connection.responseCode
                } catch (_: Exception) {
                    200
                }
                if (responseCode >= 400) {
                    throw IllegalStateException("HTTP $responseCode")
                }

                val totalLength = connection.contentLengthLong
                val serverMime = connection.contentType?.substringBefore(";")?.trim().orEmpty()
                val serverDisposition = connection.getHeaderField("Content-Disposition")
                val finalRedirectedUrl = connection.url?.toString() ?: url

                // Upgrade filename & MIME type if the redirected response provided a clearer name
                resolvedFileName = refineFileNameFromResponse(
                    initialFileName = finalName,
                    finalUrl = finalRedirectedUrl,
                    contentDisposition = serverDisposition,
                    serverMime = serverMime.ifBlank { safeMime }
                )
                effectiveMime = resolveAccurateMimeType(
                    resolvedFileName,
                    serverMime.ifBlank { safeMime }
                )

                val runningEntity = DownloadEntity(
                    id = rowId,
                    systemDownloadId = -1L,
                    fileName = resolvedFileName,
                    url = url,
                    mimeType = effectiveMime,
                    status = DownloadStatus.RUNNING,
                    totalBytes = totalLength,
                    downloadedBytes = 0L,
                    saveFolderLabel = folderLabel
                )
                repository.updateDownload(runningEntity)
                postDownloadProgressNotification(
                    context = context,
                    rowId = rowId,
                    fileName = resolvedFileName,
                    downloadedBytes = 0L,
                    totalBytes = totalLength,
                    folderLabel = folderLabel
                )

                var finalBytes = 0L
                connection.inputStream.use { input ->
                    FileOutputStream(tempFile).use { tempOut ->
                        copyStreamWithProgress(input, tempOut, cancelFlag) { written ->
                            finalBytes = written
                            backgroundDownloadScope.launch {
                                try {
                                    repository.updateDownloadProgress(rowId, written)
                                    postDownloadProgressNotification(
                                        context = context,
                                        rowId = rowId,
                                        fileName = resolvedFileName,
                                        downloadedBytes = written,
                                        totalBytes = totalLength,
                                        folderLabel = folderLabel
                                    )
                                } catch (_: Exception) {
                                }
                            }
                        }
                    }
                }

                if (!tempFile.exists() || tempFile.length() == 0L) {
                    throw IllegalStateException("Empty response stream")
                }
                finalBytes = tempFile.length()

                // Inspect binary magic bytes on the downloaded tempFile so mislabeled audio/zip/pdf/images
                // get their true extension and MIME type!
                val header = readHeaderBytes(tempFile, 32)
                val detected = detectMimeAndExtFromBytes(header)
                if (detected != null) {
                    resolvedFileName = applyDetectedExtensionIfNeeded(resolvedFileName, detected.second)
                    effectiveMime = resolveAccurateMimeType(resolvedFileName, detected.first)
                }

                val savedUri = saveTempFileToDestination(
                    context = context,
                    sourceFile = tempFile,
                    fileName = resolvedFileName,
                    mimeType = effectiveMime,
                    destination = destination
                )

                val isSuccess = savedUri != null
                repository.updateDownload(
                    runningEntity.copy(
                        fileName = resolvedFileName,
                        mimeType = effectiveMime,
                        localUri = savedUri?.toString() ?: "",
                        status = if (isSuccess) DownloadStatus.SUCCESSFUL else DownloadStatus.FAILED,
                        totalBytes = if (totalLength > 0) totalLength else finalBytes,
                        downloadedBytes = finalBytes
                    )
                )

                cancelDownloadNotification(context, rowId)

                if (isSuccess && savedUri != null) {
                    postDownloadCompleteNotification(
                        context = context,
                        fileName = resolvedFileName,
                        mimeType = effectiveMime,
                        fileUri = savedUri,
                        folderLabel = folderLabel,
                        sizeBytes = finalBytes
                    )
                    withContext(Dispatchers.Main) {
                        Toast.makeText(
                            context,
                            "Download complete: $resolvedFileName ($folderLabel)",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                } else {
                    postDownloadFailedNotification(context, rowId, resolvedFileName)
                }

                rowId
            } catch (e: CancellationException) {
                cancelDownloadNotification(context, rowId)
                repository.deleteDownload(rowId)
                -1L
            } catch (e: Exception) {
                cancelDownloadNotification(context, rowId)
                repository.updateDownload(
                    DownloadEntity(
                        id = rowId,
                        systemDownloadId = -1L,
                        fileName = resolvedFileName,
                        url = url,
                        mimeType = effectiveMime,
                        status = DownloadStatus.FAILED,
                        saveFolderLabel = folderLabel
                    )
                )
                postDownloadFailedNotification(context, rowId, resolvedFileName)
                withContext(Dispatchers.Main) {
                    Toast.makeText(
                        context,
                        "Download failed for $resolvedFileName. Tap Retry in Downloads.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
                -1L
            } finally {
                activeInProcessRowIds.remove(rowId)
                activeCancelFlags.remove(rowId)
                activeJobs.remove(rowId)
                tempFile.delete()
                connection?.disconnect()
                notifyForegroundServiceDownloadIdleCheck(context, repository)
            }
        }
    }

    private fun refineFileNameFromResponse(
        initialFileName: String,
        finalUrl: String,
        contentDisposition: String?,
        serverMime: String
    ): String {
        val lowerInitial = initialFileName.lowercase(Locale.US)
        val userProvidedCustomName = !lowerInitial.startsWith("download") &&
            !lowerInitial.startsWith("file") &&
            !lowerInitial.startsWith("studio_export") &&
            !lowerInitial.endsWith(".bin") &&
            !lowerInitial.endsWith(".txt") &&
            lowerInitial.contains(".")
        if (userProvidedCustomName) {
            return sanitizeFileName(initialFileName, serverMime)
        }

        val dispFileName = extractFileNameFromContentDisposition(contentDisposition)
        if (!dispFileName.isNullOrBlank()) {
            return sanitizeFileName(dispFileName, serverMime)
        }
        try {
            val uri = Uri.parse(finalUrl)
            val dlParam = uri.getQueryParameter("dl")
                ?: uri.getQueryParameter("filename")
                ?: uri.getQueryParameter("response-content-disposition")?.let {
                    extractFileNameFromContentDisposition(it)
                }
            if (!dlParam.isNullOrBlank()) {
                return sanitizeFileName(dlParam, serverMime)
            }
        } catch (_: Exception) {
        }

        val isGenericInitial = lowerInitial.startsWith("download") ||
            lowerInitial.startsWith("file") ||
            lowerInitial.startsWith("studio_export") ||
            lowerInitial.endsWith(".bin") ||
            !lowerInitial.contains(".")
        if (isGenericInitial) {
            val guessedFromFinal = URLUtil.guessFileName(finalUrl, contentDisposition, serverMime)
            if (guessedFromFinal.isNotBlank() && !guessedFromFinal.endsWith(".bin")) {
                return sanitizeFileName(guessedFromFinal, serverMime)
            }
        }
        return sanitizeFileName(initialFileName, serverMime)
    }

    private fun extractFileNameFromContentDisposition(contentDisposition: String?): String? {
        if (contentDisposition.isNullOrBlank()) return null
        val utf8Regex = Regex("filename\\*\\s*=\\s*(?:UTF-8''|utf-8'')([^;]+)", RegexOption.IGNORE_CASE)
        utf8Regex.find(contentDisposition)?.groupValues?.getOrNull(1)?.let { encoded ->
            val clean = encoded.trim('"', '\'', ' ')
            return try {
                URLDecoder.decode(clean, "UTF-8")
            } catch (_: Exception) {
                clean
            }
        }
        val stdRegex = Regex("filename\\s*=\\s*\"([^\"]+)\"", RegexOption.IGNORE_CASE)
        stdRegex.find(contentDisposition)?.groupValues?.getOrNull(1)?.let { quoted ->
            if (quoted.isNotBlank()) return quoted.trim()
        }
        val unquotedRegex = Regex("filename\\s*=\\s*([^;\\s]+)", RegexOption.IGNORE_CASE)
        unquotedRegex.find(contentDisposition)?.groupValues?.getOrNull(1)?.let { raw ->
            val clean = raw.trim('"', '\'', ' ')
            if (clean.isNotBlank()) return clean
        }
        return null
    }

    private fun openFollowedHttpConnection(
        rawUrl: String,
        userAgent: String,
        refererUrl: String = ""
    ): HttpURLConnection {
        var currentUrl = rawUrl
        var currentReferer = refererUrl
        var redirects = 0
        val effectiveUa = userAgent.ifBlank { WebViewManager.MOBILE_CHROME_USER_AGENT }

        while (redirects < 10) {
            val conn = (URL(currentUrl).openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = false
                connectTimeout = 25_000
                readTimeout = 120_000
                setRequestProperty("User-Agent", effectiveUa)
                setRequestProperty("Accept", "*/*")
                setRequestProperty("Accept-Language", "en-US,en;q=0.9")
                if (currentReferer.isNotBlank()) {
                    setRequestProperty("Referer", currentReferer)
                }
                val cookies = try {
                    CookieManager.getInstance().getCookie(currentUrl)
                } catch (_: Exception) {
                    null
                }
                if (!cookies.isNullOrBlank()) {
                    setRequestProperty("Cookie", cookies)
                }
            }
            val code = conn.responseCode
            if (code in 300..399) {
                val location = conn.getHeaderField("Location")
                conn.disconnect()
                if (location.isNullOrBlank()) break
                val nextUrl = URL(URL(currentUrl), location).toString()
                currentReferer = try {
                    val u = Uri.parse(currentUrl)
                    "${u.scheme}://${u.host}/"
                } catch (_: Exception) {
                    currentUrl
                }
                currentUrl = nextUrl
                redirects++
            } else {
                return conn
            }
        }
        return (URL(currentUrl).openConnection() as HttpURLConnection).apply {
            instanceFollowRedirects = true
            connectTimeout = 25_000
            readTimeout = 120_000
            setRequestProperty("User-Agent", effectiveUa)
            setRequestProperty("Accept", "*/*")
            val cookies = try {
                CookieManager.getInstance().getCookie(currentUrl)
            } catch (_: Exception) {
                null
            }
            if (!cookies.isNullOrBlank()) {
                setRequestProperty("Cookie", cookies)
            }
        }
    }

    suspend fun syncActiveDownloads(context: Context, repository: BrowserRepository) {
        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as? DownloadManager
        val activeList = repository.getActiveDownloads()
        val now = System.currentTimeMillis()

        for (item in activeList) {
            if (item.systemDownloadId > 0L) {
                var shouldRescue = false
                if (dm != null) {
                    val query = DownloadManager.Query().setFilterById(item.systemDownloadId)
                    val cursor = try {
                        dm.query(query)
                    } catch (_: Exception) {
                        null
                    }
                    if (cursor == null || !cursor.moveToFirst()) {
                        cursor?.close()
                        shouldRescue = true
                    } else {
                        cursor.use { c ->
                            val statusIdx = c.getColumnIndex(DownloadManager.COLUMN_STATUS)
                            val totalIdx = c.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
                            val downloadedIdx = c.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
                            val localUriIdx = c.getColumnIndex(DownloadManager.COLUMN_LOCAL_URI)

                            val sysStatus = if (statusIdx >= 0) c.getInt(statusIdx) else DownloadManager.STATUS_RUNNING
                            val totalBytes = if (totalIdx >= 0) c.getLong(totalIdx) else item.totalBytes
                            val downloadedBytes = if (downloadedIdx >= 0) c.getLong(downloadedIdx) else item.downloadedBytes
                            val rawLocalUri = if (localUriIdx >= 0) c.getString(localUriIdx) ?: "" else ""

                            val isStuckAtZero = downloadedBytes <= 0L && (now - item.createdAt) > 2500L
                            if (sysStatus == DownloadManager.STATUS_FAILED ||
                                sysStatus == DownloadManager.STATUS_PAUSED ||
                                isStuckAtZero
                            ) {
                                shouldRescue = true
                            } else {
                                val newStatus = when (sysStatus) {
                                    DownloadManager.STATUS_PENDING -> DownloadStatus.PENDING
                                    DownloadManager.STATUS_RUNNING -> DownloadStatus.RUNNING
                                    DownloadManager.STATUS_PAUSED -> DownloadStatus.PAUSED
                                    DownloadManager.STATUS_SUCCESSFUL -> DownloadStatus.SUCCESSFUL
                                    DownloadManager.STATUS_FAILED -> DownloadStatus.FAILED
                                    else -> item.status
                                }
                                val contentUri = if (newStatus == DownloadStatus.SUCCESSFUL) {
                                    try {
                                        dm.getUriForDownloadedFile(item.systemDownloadId)?.toString() ?: rawLocalUri
                                    } catch (_: Exception) {
                                        rawLocalUri
                                    }
                                } else {
                                    rawLocalUri
                                }
                                repository.updateDownload(
                                    item.copy(
                                        status = newStatus,
                                        totalBytes = totalBytes,
                                        downloadedBytes = downloadedBytes,
                                        localUri = contentUri.ifBlank { item.localUri }
                                    )
                                )
                            }
                        }
                    }
                } else {
                    shouldRescue = true
                }

                if (shouldRescue && (item.url.startsWith("http://") || item.url.startsWith("https://"))) {
                    try {
                        dm?.remove(item.systemDownloadId)
                    } catch (_: Exception) {
                    }
                    retryDownload(context, repository, item)
                }
            } else {
                val isCurrentlyStreaming = activeInProcessRowIds.containsKey(item.id)
                if (!isCurrentlyStreaming && (now - item.createdAt) > 6000L) {
                    if (item.url.startsWith("http://") || item.url.startsWith("https://")) {
                        retryDownload(context, repository, item)
                    } else {
                        repository.updateDownload(item.copy(status = DownloadStatus.FAILED))
                    }
                }
            }
        }
    }

    fun retryDownload(
        context: Context,
        repository: BrowserRepository,
        download: DownloadEntity
    ) {
        if (activeInProcessRowIds.containsKey(download.id)) return
        if (!download.url.startsWith("http://") && !download.url.startsWith("https://")) {
            Toast.makeText(context, "Temporary blob expired — please click Download on the page again", Toast.LENGTH_SHORT).show()
            return
        }
        val preset = when (download.saveFolderLabel) {
            "/Downloads/Flowra" -> DownloadFolderPreset.STUDIO_DOWNLOADS
            "/Documents" -> DownloadFolderPreset.DOCUMENTS
            "/Pictures" -> DownloadFolderPreset.PICTURES
            "/Music" -> DownloadFolderPreset.MUSIC
            "/Movies" -> DownloadFolderPreset.MOVIES
            else -> DownloadFolderPreset.DOWNLOADS
        }
        launchBackgroundHttpDownload(
            context = context.applicationContext,
            repository = repository,
            url = download.url,
            fileName = download.fileName,
            mimeType = download.mimeType,
            userAgent = WebViewManager.MOBILE_CHROME_USER_AGENT,
            destination = DownloadDestination(preset = preset),
            existingRowId = download.id
        )
    }

    fun openSystemDownloadsFileManager(context: Context) {
        val candidates = listOf(
            Intent(DownloadManager.ACTION_VIEW_DOWNLOADS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            },
            Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    DocumentsContract.Document.MIME_TYPE_DIR
                )
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            },
            Intent(Intent.ACTION_GET_CONTENT).apply {
                type = "*/*"
                addCategory(Intent.CATEGORY_OPENABLE)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
        )
        for (intent in candidates) {
            try {
                context.startActivity(intent)
                return
            } catch (_: Exception) {
            }
        }
        Toast.makeText(context, "Saved in Internal Storage -> Download", Toast.LENGTH_SHORT).show()
    }

    private fun ensureDownloadNotificationChannels(context: Context, nm: NotificationManager) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val progressChannel = NotificationChannel(
                DOWNLOAD_PROGRESS_CHANNEL_ID,
                context.getString(R.string.download_progress_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = context.getString(R.string.download_progress_channel_desc)
                setShowBadge(false)
            }
            val completeChannel = NotificationChannel(
                DOWNLOAD_CHANNEL_ID,
                context.getString(R.string.download_complete_channel_name),
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = context.getString(R.string.download_complete_channel_desc)
            }
            nm.createNotificationChannel(progressChannel)
            nm.createNotificationChannel(completeChannel)
        }
    }

    private fun progressNotificationId(rowId: Long): Int = 70_000 + (rowId.toInt() and 0x7FFF)

    fun cancelDownloadNotification(context: Context, rowId: Long) {
        try {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
            nm.cancel(progressNotificationId(rowId))
        } catch (_: Exception) {
        }
    }

    fun postDownloadProgressNotification(
        context: Context,
        rowId: Long,
        fileName: String,
        downloadedBytes: Long,
        totalBytes: Long,
        folderLabel: String
    ) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                val granted = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
                if (!granted) return
            }
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
            ensureDownloadNotificationChannels(context, nm)

            val openDownloadsIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra(EXTRA_OPEN_DOWNLOADS, true)
            }
            val pendingOpen = PendingIntent.getActivity(
                context,
                progressNotificationId(rowId),
                openDownloadsIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val cancelIntent = Intent(context, BrowserService::class.java).apply {
                action = BrowserService.ACTION_CANCEL_DOWNLOAD
                putExtra(BrowserService.EXTRA_DOWNLOAD_ROW_ID, rowId)
            }
            val pendingCancel = PendingIntent.getService(
                context,
                progressNotificationId(rowId) + 10_000,
                cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val indeterminate = totalBytes <= 0L
            val percent = if (totalBytes > 0L) {
                ((downloadedBytes * 100L) / totalBytes).toInt().coerceIn(0, 100)
            } else {
                0
            }
            val statusLine = if (totalBytes > 0L) {
                "$percent% • ${formatBytes(downloadedBytes)} / ${formatBytes(totalBytes)} • $folderLabel"
            } else {
                "${formatBytes(downloadedBytes)} downloaded • $folderLabel"
            }

            val notification = NotificationCompat.Builder(context, DOWNLOAD_PROGRESS_CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle(fileName)
                .setContentText(statusLine)
                .setSubText("Downloading in background")
                .setProgress(100, percent, indeterminate)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setCategory(NotificationCompat.CATEGORY_PROGRESS)
                .setContentIntent(pendingOpen)
                .addAction(
                    android.R.drawable.ic_menu_close_clear_cancel,
                    context.getString(R.string.action_cancel_download),
                    pendingCancel
                )
                .build()

            nm.notify(progressNotificationId(rowId), notification)
        } catch (_: Exception) {
        }
    }

    fun postDownloadCompleteNotification(
        context: Context,
        fileName: String,
        mimeType: String,
        fileUri: Uri,
        folderLabel: String,
        sizeBytes: Long = -1L
    ) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                val granted = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
                if (!granted) return
            }
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
            ensureDownloadNotificationChannels(context, nm)

            val resolvedMime = resolveAccurateMimeType(fileName, mimeType)
            val openFileIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(fileUri, resolvedMime)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val openDownloadsIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra(EXTRA_OPEN_DOWNLOADS, true)
            }

            val canResolveFileViewer = try {
                openFileIntent.resolveActivity(context.packageManager) != null
            } catch (_: Exception) {
                true
            }
            val primaryIntent = if (canResolveFileViewer) openFileIntent else openDownloadsIntent

            val pendingPrimary = PendingIntent.getActivity(
                context,
                fileName.hashCode(),
                primaryIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val pendingDownloadsSheet = PendingIntent.getActivity(
                context,
                fileName.hashCode() + 1,
                openDownloadsIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val sizePrefix = if (sizeBytes > 0L) "${formatBytes(sizeBytes)} • " else ""
            val notification = NotificationCompat.Builder(context, DOWNLOAD_CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle(fileName)
                .setContentText("${sizePrefix}Saved in $folderLabel • Tap to open")
                .setSubText("Download complete")
                .setAutoCancel(true)
                .setContentIntent(pendingPrimary)
                .addAction(
                    android.R.drawable.ic_menu_view,
                    context.getString(R.string.action_open_downloads),
                    pendingDownloadsSheet
                )
                .build()

            nm.notify((System.currentTimeMillis() and 0xFFFFFFF).toInt(), notification)
        } catch (_: Exception) {
        }
    }

    fun postDownloadFailedNotification(
        context: Context,
        rowId: Long,
        fileName: String
    ) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                val granted = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
                if (!granted) return
            }
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
            ensureDownloadNotificationChannels(context, nm)

            val openDownloadsIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra(EXTRA_OPEN_DOWNLOADS, true)
            }
            val pendingOpen = PendingIntent.getActivity(
                context,
                progressNotificationId(rowId) + 20_000,
                openDownloadsIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val notification = NotificationCompat.Builder(context, DOWNLOAD_CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_notify_error)
                .setContentTitle("Download failed: $fileName")
                .setContentText("Tap to open Downloads and retry")
                .setAutoCancel(true)
                .setContentIntent(pendingOpen)
                .build()

            nm.notify(progressNotificationId(rowId) + 20_000, notification)
        } catch (_: Exception) {
        }
    }

    /**
     * Extracts a downloaded .zip archive when explicitly requested by the user via the "Extract" button.
     */
    fun extractDownloadedZip(
        context: Context,
        repository: BrowserRepository,
        download: DownloadEntity
    ) {
        val uri = resolveShareableUri(context, download)
        if (uri == null) {
            Toast.makeText(context, "ZIP file not found on storage", Toast.LENGTH_SHORT).show()
            return
        }
        backgroundDownloadScope.launch {
            val summary = ZipArchiveHelper.extractZipFromUri(
                context = context,
                zipUri = uri,
                destination = DownloadDestination(DownloadFolderPreset.DOWNLOADS)
            )
            if (summary.extractedFiles.isEmpty()) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(
                        context,
                        "Could not find extractable entries in ${download.fileName}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
                return@launch
            }

            val folderLabel = download.saveFolderLabel.ifBlank { "/Downloads" }
            for (item in summary.extractedFiles) {
                repository.insertDownload(
                    DownloadEntity(
                        systemDownloadId = -1L,
                        fileName = item.fileName,
                        url = "extracted://${download.fileName}/${item.fileName}",
                        mimeType = item.mimeType,
                        localUri = item.savedUri.toString(),
                        status = DownloadStatus.SUCCESSFUL,
                        totalBytes = item.sizeBytes,
                        downloadedBytes = item.sizeBytes,
                        saveFolderLabel = folderLabel
                    )
                )
            }

            withContext(Dispatchers.Main) {
                val names = summary.extractedFiles.take(4).joinToString(", ") { it.fileName }
                val message = "Extracted ${summary.extractedFiles.size} file(s) ($names) to $folderLabel"
                Toast.makeText(context, message, Toast.LENGTH_LONG).show()
            }
        }
    }

    fun openDownloadedFile(context: Context, download: DownloadEntity, repository: BrowserRepository? = null) {
        val uri = resolveShareableUri(context, download)
        if (uri == null) {
            Toast.makeText(context, "File not available on storage", Toast.LENGTH_SHORT).show()
            return
        }

        val resolvedMime = resolveAccurateMimeType(download.fileName, download.mimeType)
        try {
            val viewIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, resolvedMime)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(viewIntent, "Open ${download.fileName}"))
        } catch (_: Exception) {
            if (download.fileName.endsWith(".zip", ignoreCase = true) && repository != null) {
                extractDownloadedZip(context, repository, download)
            } else {
                openSystemDownloadsFileManager(context)
            }
        }
    }

    fun shareDownloadedFile(context: Context, download: DownloadEntity) {
        val uri = resolveShareableUri(context, download)
        if (uri == null) {
            Toast.makeText(context, "File cannot be shared yet", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val resolvedMime = resolveAccurateMimeType(download.fileName, download.mimeType)
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = resolvedMime.ifBlank { "*/*" }
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(shareIntent, "Share ${download.fileName}"))
        } catch (_: Exception) {
            Toast.makeText(context, "Unable to share file", Toast.LENGTH_SHORT).show()
        }
    }

    private fun resolveShareableUri(context: Context, download: DownloadEntity): Uri? {
        if (download.systemDownloadId > 0L) {
            val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as? DownloadManager
            val dmUri = try {
                dm?.getUriForDownloadedFile(download.systemDownloadId)
            } catch (_: Exception) {
                null
            }
            if (dmUri != null) return dmUri
        }
        if (download.localUri.isNotBlank()) {
            val parsed = Uri.parse(download.localUri)
            if (parsed.scheme == "content") return parsed
            if (parsed.scheme == "file" && parsed.path != null) {
                return try {
                    FileProvider.getUriForFile(
                        context,
                        "${context.packageName}.fileprovider",
                        File(parsed.path!!)
                    )
                } catch (_: Exception) {
                    null
                }
            }
        }
        try {
            @Suppress("DEPRECATION")
            val pubFile = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                download.fileName
            )
            if (pubFile.exists() && pubFile.length() > 0L) {
                return FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    pubFile
                )
            }
        } catch (_: Exception) {
        }
        return null
    }

    fun formatBytes(bytes: Long): String {
        if (bytes < 0L) return "Unknown size"
        if (bytes < 1024L) return "$bytes B"
        val kb = bytes / 1024.0
        if (kb < 1024.0) return String.format(Locale.US, "%.1f KB", kb)
        val mb = kb / 1024.0
        if (mb < 1024.0) return String.format(Locale.US, "%.1f MB", mb)
        val gb = mb / 1024.0
        return String.format(Locale.US, "%.2f GB", gb)
    }

    fun guessName(
        url: String,
        contentDisposition: String?,
        mimeType: String?,
        registeredBlobName: String? = null,
        registeredBlobMeta: RegisteredBlobMetadata? = null,
        refererUrl: String? = null
    ): String {
        val magicDetected = detectMimeAndExtFromMagicHex(registeredBlobMeta?.magicHex)
        val effectiveMime = when {
            magicDetected != null -> magicDetected.first
            !registeredBlobMeta?.mimeType.isNullOrBlank() &&
                !registeredBlobMeta!!.mimeType.equals("text/plain", ignoreCase = true) &&
                !registeredBlobMeta.mimeType.equals("application/octet-stream", ignoreCase = true) ->
                registeredBlobMeta.mimeType
            refererUrl?.contains("generate-speech", ignoreCase = true) == true &&
                (mimeType == null || mimeType == "text/plain" || mimeType == "application/octet-stream") ->
                "audio/wav"
            else -> mimeType ?: "application/octet-stream"
        }

        val candidateFromBlob = registeredBlobName?.takeIf { it.isNotBlank() }
            ?: registeredBlobMeta?.suggestedName?.takeIf { it.isNotBlank() }
        if (!candidateFromBlob.isNullOrBlank()) {
            val sanitized = sanitizeFileName(candidateFromBlob, effectiveMime)
            return if (magicDetected != null) {
                applyDetectedExtensionIfNeeded(sanitized, magicDetected.second)
            } else {
                sanitized
            }
        }

        val dispName = extractFileNameFromContentDisposition(contentDisposition)
        if (!dispName.isNullOrBlank()) {
            val sanitized = sanitizeFileName(dispName, effectiveMime)
            return if (magicDetected != null) {
                applyDetectedExtensionIfNeeded(sanitized, magicDetected.second)
            } else {
                sanitized
            }
        }

        if (url.startsWith("blob:") || url.startsWith("data:")) {
            return buildSmartBlobFileName(
                rawSuggestedName = null,
                rawMime = effectiveMime,
                magicHex = registeredBlobMeta?.magicHex,
                pageUrl = refererUrl ?: url
            )
        }

        try {
            val uri = Uri.parse(url)
            val dlParam = uri.getQueryParameter("dl")
                ?: uri.getQueryParameter("filename")
                ?: uri.getQueryParameter("response-content-disposition")?.let {
                    extractFileNameFromContentDisposition(it)
                }
            if (!dlParam.isNullOrBlank()) {
                return sanitizeFileName(dlParam, effectiveMime)
            }
        } catch (_: Exception) {
        }
        val guessed = URLUtil.guessFileName(url, contentDisposition, effectiveMime)
        return sanitizeFileName(guessed, effectiveMime)
    }
}
