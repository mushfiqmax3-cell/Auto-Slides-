package com.example

import android.content.Context
import android.content.Intent
import android.view.View
import androidx.test.core.app.ApplicationProvider
import com.example.data.BookmarkEntity
import com.example.data.BrowserDatabase
import com.example.data.BrowserRepository
import com.example.data.InstalledWebAppEntity
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `verify app name, 1 clean default startup tab, and arbitrary background WebView tabs keep View VISIBLE`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Flowra", appName)

        val manager = WebViewManager.getInstance(context)
        manager.closeAllTabsAndResetToStartPage()
        val initialTabs = manager.tabsState.value
        assertEquals(1, initialTabs.size)
        assertEquals(WebViewManager.NEW_TAB_URL, initialTabs[0].url)

        // Open 3 arbitrary websites and verify all WebViews remain View.VISIBLE inside persistentContainer
        assertTrue(manager.openNewTab("https://github.com", isIncognito = false))
        assertTrue(manager.openNewTab("https://www.youtube.com", isIncognito = false))
        assertTrue(manager.openNewTab("https://aistudio.google.com", isIncognito = false))

        val tabs = manager.tabsState.value
        assertEquals(4, tabs.size)

        // Switch to tab 2 and verify all 4 WebViews remain View.VISIBLE inside persistentContainer
        manager.selectTab(tabs[1].id)
        assertEquals(tabs[1].id, manager.activeTabId.value)
        assertEquals(4, manager.persistentContainer.childCount)
        for (i in 0 until manager.persistentContainer.childCount) {
            val child = manager.persistentContainer.getChildAt(i)
            assertEquals(View.VISIBLE, child.visibility)
        }

        // Persist session, close a tab, and verify reopenLastClosedTab restores it
        manager.persistSessionStateSync(commitImmediately = true, saveWebViewBundles = true)
        val closedTabUrl = tabs[2].url
        manager.closeTab(tabs[2].id)
        assertEquals(3, manager.tabsState.value.size)
        assertTrue(manager.recentlyClosedTabs.value.isNotEmpty())
        assertTrue(manager.reopenLastClosedTab())
        assertEquals(4, manager.tabsState.value.size)
        assertEquals(closedTabUrl, manager.tabsState.value.last().url)

        // Clean up back to 1 start tab
        manager.closeAllTabsAndResetToStartPage()

        // Verify User-Agent sanitization has no '; wv' token or Version/4.0 token
        assertFalse(WebViewManager.MOBILE_CHROME_USER_AGENT.contains("; wv"))
        assertFalse(WebViewManager.DESKTOP_CHROME_USER_AGENT.contains("; wv"))
        assertTrue(WebViewManager.MOBILE_CHROME_USER_AGENT.contains("Chrome/"))

        val dynamicUa = WebViewManager.getSanitizedMobileUserAgent(context)
        assertFalse(dynamicUa.contains("; wv"))
        assertFalse(dynamicUa.contains("Version/4.0"))
        assertTrue(dynamicUa.contains("Chrome/"))

        assertFalse(manager.aiStudioPermissionErrorDetected.value)
        manager.dismissAiStudioPermissionBanner()
        assertFalse(manager.aiStudioPermissionErrorDetected.value)
        manager.reSyncGoogleAuthForActiveTab()
        assertFalse(manager.aiStudioPermissionErrorDetected.value)
    }

    @Test
    fun `verify download helpers url normalization and incognito tab lifecycle`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val manager = WebViewManager.getInstance(context)

        // Download formatting & arbitrary extension filename sanitization
        assertEquals("512 B", DownloadHelper.formatBytes(512L))
        assertEquals("1.5 KB", DownloadHelper.formatBytes(1536L))
        assertEquals("2.0 MB", DownloadHelper.formatBytes(2L * 1024L * 1024L))
        assertEquals("report_v1.pdf", sanitizeFileName("report:v1.pdf", "application/pdf"))
        assertEquals("app-release.apk", sanitizeFileName("app-release.apk", "application/octet-stream"))
        assertEquals("model_weights.bin", sanitizeFileName("model_weights.bin", "application/octet-stream"))
        assertEquals("script.py", sanitizeFileName("script.py", "text/plain"))
        assertTrue(
            DownloadHelper.guessName(
                "blob:https://aistudio.google.com/1234",
                "attachment; filename=\"chat_export.json\"",
                "application/json"
            ).contains("chat_export.json")
        )

        // Destination folder labels
        val studioDest = DownloadDestination(preset = DownloadFolderPreset.STUDIO_DOWNLOADS)
        assertEquals("/Downloads/Flowra", studioDest.displayLabel())
        val customDest = DownloadDestination(
            preset = DownloadFolderPreset.CUSTOM_SAF,
            customTreeUri = "content://com.android.externalstorage.documents/tree/primary%3AWork",
            customFolderLabel = "Phone: Work"
        )
        assertEquals("Phone: Work", customDest.displayLabel())

        // Verify accurate MIME resolution and Unsplash-style download filename & direct MediaStore/Download writing
        assertEquals(
            "image/jpeg",
            resolveAccurateMimeType("jeremy-bishop-4kv4odtKd0U-unsplash.jpg", "application/octet-stream")
        )
        assertEquals(
            "jeremy-bishop-4kv4odtKd0U-unsplash.jpg",
            DownloadHelper.guessName(
                url = "https://unsplash.com/photos/4kv4odtKd0U/download?ixid=M3wxMjA3fDB8MXxhbGx8fHx8fHx8fHwxNzM",
                contentDisposition = "attachment; filename=\"jeremy-bishop-4kv4odtKd0U-unsplash.jpg\"",
                mimeType = "image/jpeg"
            )
        )
        val payloadBytes = "Flowra direct download test payload".toByteArray()
        val savedUri = writeBytesToDestination(
            context = context,
            fileName = "jeremy-bishop-4kv4odtKd0U-unsplash.jpg",
            mimeType = "image/jpeg",
            bytes = payloadBytes,
            destination = studioDest
        )
        assertTrue(savedUri != null && savedUri.toString().isNotBlank())

        // URL vs search query normalization
        assertEquals("https://github.com", manager.normalizeUrlOrSearchQuery("github.com"))
        assertTrue(manager.normalizeUrlOrSearchQuery("latest android compose").startsWith("https://www.google.com/search?q="))

        // Open and close an Incognito tab while keeping persistentContainer WebViews View.VISIBLE
        val initialCount = manager.tabsState.value.size
        assertTrue(manager.openNewTab(WebViewManager.NEW_TAB_URL, isIncognito = true))
        assertEquals(initialCount + 1, manager.tabsState.value.size)
        val incognitoTab = manager.tabsState.value.last()
        assertTrue(incognitoTab.isIncognito)
        assertEquals(WebViewManager.NEW_TAB_URL, incognitoTab.url)

        manager.closeTab(incognitoTab.id)
        assertEquals(initialCount, manager.tabsState.value.size)
    }

    @Test
    fun `verify multiple independent PWAs for same site have unique tasks profiles and icons`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val targetUrl = "https://aistudio.google.com/"
        val createdApps = mutableListOf<InstalledWebAppEntity>()
        val seenIds = mutableSetOf<String>()
        val seenUris = mutableSetOf<String>()
        val seenProfiles = mutableSetOf<String>()

        // Create 10 separate PWAs for the exact same website (Google AI Studio)
        for (i in 1..10) {
            val pwaId = PwaShortcutHelper.generateUniquePwaId()
            val suggestedName = PwaShortcutHelper.suggestNextAppName(
                rawPageTitle = "Google AI Studio",
                url = targetUrl,
                existingApps = createdApps
            )
            val entity = InstalledWebAppEntity(
                pwaId = pwaId,
                name = suggestedName,
                url = targetUrl,
                isStandalonePwa = true,
                isolatedProfile = true,
                profileName = "pwa_profile_$pwaId",
                badgeColorHex = PwaShortcutHelper.PRESET_BADGE_COLORS[i % PwaShortcutHelper.PRESET_BADGE_COLORS.size],
                badgeTag = i.toString()
            )
            createdApps.add(entity)
            assertTrue(seenIds.add(entity.pwaId))
            assertTrue(seenProfiles.add(entity.profileName))

            val launchIntent = PwaShortcutHelper.buildLaunchIntent(context, entity)
            assertEquals(PwaActivity::class.java.name, launchIntent.component?.className)
            assertTrue((launchIntent.flags and Intent.FLAG_ACTIVITY_NEW_DOCUMENT) != 0)
            assertTrue((launchIntent.flags and Intent.FLAG_ACTIVITY_MULTIPLE_TASK) != 0)
            assertTrue(seenUris.add(launchIntent.dataString!!))

            val icon = PwaShortcutHelper.buildLauncherIconBitmap(
                name = entity.name,
                favicon = null,
                badgeColorHex = entity.badgeColorHex,
                badgeTag = entity.badgeTag,
                isStandalonePwa = true
            )
            assertEquals(192, icon.width)
            assertEquals(192, icon.height)
        }

        assertEquals(10, createdApps.size)
        assertEquals("Google AI Studio", createdApps[0].name)
        assertEquals("Google AI Studio 2", createdApps[1].name)
        assertEquals("Google AI Studio 10", createdApps[9].name)
        assertNotEquals(createdApps[0].profileName, createdApps[1].profileName)

        // Verify Website Shortcut mode opens in MainActivity browser tab
        val shortcutEntity = InstalledWebAppEntity(
            pwaId = PwaShortcutHelper.generateUniquePwaId(),
            name = "AI Studio Shortcut",
            url = targetUrl,
            isStandalonePwa = false,
            isolatedProfile = false,
            profileName = "Default"
        )
        val shortcutIntent = PwaShortcutHelper.buildLaunchIntent(context, shortcutEntity)
        assertEquals(MainActivity::class.java.name, shortcutIntent.component?.className)
        assertEquals(Intent.ACTION_VIEW, shortcutIntent.action)
        assertTrue(shortcutIntent.getBooleanExtra(PwaShortcutHelper.EXTRA_OPEN_IN_NEW_TAB, false))

        // Verify Home Screen Pinning Intent for standalone PWA targets PwaActivity directly with ACTION_VIEW + self-contained studiopwa:// query parameters
        val pinnedPwaIntent = PwaShortcutHelper.buildLaunchIntent(context, createdApps[0], forShortcutPinning = true)
        assertEquals(PwaActivity::class.java.name, pinnedPwaIntent.component?.className)
        assertEquals(Intent.ACTION_VIEW, pinnedPwaIntent.action)
        assertEquals(targetUrl, pinnedPwaIntent.data?.getQueryParameter("url"))
        assertEquals("Google AI Studio", pinnedPwaIntent.data?.getQueryParameter("name"))
        val extracted = PwaShortcutHelper.extractEntityFromShortcutIntent(pinnedPwaIntent)
        assertEquals(createdApps[0].pwaId, extracted?.pwaId)
        assertEquals(true, extracted?.isStandalonePwa)
        assertTrue(PwaShortcutHelper.pinToHomeScreen(context, createdApps[0], null))
        // Re-pinning the same app a second time must also succeed without ID collision
        assertTrue(PwaShortcutHelper.pinToHomeScreen(context, createdApps[0], null))

        // Verify PwaSessionController initializes WebView cleanly without NullPointerException and PwaActivity launches from shortcut intent
        val pwaSession = PwaWebViewPool.getOrCreateSession(context, createdApps[0])
        assertEquals(createdApps[0].pwaId, pwaSession.app.pwaId)
        assertEquals(targetUrl, pwaSession.uiState.value.url)
        assertFalse(pwaSession.aiStudioPermissionErrorDetected.value)
        pwaSession.dismissAiStudioPermissionBanner()
        assertFalse(pwaSession.aiStudioPermissionErrorDetected.value)
        val pwaActivity = org.robolectric.Robolectric.buildActivity(PwaActivity::class.java, pinnedPwaIntent)
            .create()
            .start()
            .resume()
            .get()
        assertFalse(pwaActivity.isFinishing)
        pwaActivity.finish()
        PwaWebViewPool.removeAndDestroySession(createdApps[0].pwaId, context)

        // Verify standard File Manager chooser asks for 0 capture permissions by default
        assertEquals(0, DeviceAccessHelper.getOnDemandCapturePermissionsForFileChooser(context, null).size)
        DeviceAccessHelper.rememberSitePermissionGranted(context, targetUrl, "camera", true)
        assertTrue(DeviceAccessHelper.isSitePermissionRemembered(context, targetUrl, "camera"))
    }

    @Test
    fun `verify RAM-adaptive PWA budget, shortcut focusOrOpenTab reuse, and Room offline bookmarks & history`() = runBlocking {
        // 1. RAM budget scaling checks
        assertEquals(2, PwaWebViewPool.calculateMaxSlotsForRam(totalRamMb = 3072L, availRamMb = 1500L, isLowMemory = false))
        assertEquals(4, PwaWebViewPool.calculateMaxSlotsForRam(totalRamMb = 4096L, availRamMb = 1800L, isLowMemory = false))
        assertEquals(6, PwaWebViewPool.calculateMaxSlotsForRam(totalRamMb = 6144L, availRamMb = 2500L, isLowMemory = false))
        assertEquals(8, PwaWebViewPool.calculateMaxSlotsForRam(totalRamMb = 8192L, availRamMb = 3200L, isLowMemory = false))
        assertEquals(12, PwaWebViewPool.calculateMaxSlotsForRam(totalRamMb = 12288L, availRamMb = 5000L, isLowMemory = false))
        // Tight free RAM or lowMemory safely caps slots to prevent OS OOM kill
        assertEquals(1, PwaWebViewPool.calculateMaxSlotsForRam(totalRamMb = 8192L, availRamMb = 300L, isLowMemory = false))
        assertEquals(1, PwaWebViewPool.calculateMaxSlotsForRam(totalRamMb = 12288L, availRamMb = 4000L, isLowMemory = true))

        // 2. Shortcut focusOrOpenTab focuses existing open tab instead of duplicating
        val context = ApplicationProvider.getApplicationContext<Context>()
        val manager = WebViewManager.getInstance(context)
        val distinctUrl = "https://github.com"
        assertTrue(manager.openNewTab(distinctUrl, isIncognito = false))
        val targetTab = manager.tabsState.value.last()
        val countWithTarget = manager.tabsState.value.size
        manager.selectTab(manager.tabsState.value.first().id)
        manager.focusOrOpenTab(distinctUrl)
        assertEquals(countWithTarget, manager.tabsState.value.size)
        assertEquals(targetTab.id, manager.activeTabId.value)
        manager.closeTab(targetTab.id)

        // 3. Offline Room SQLite Bookmarks editing & History 15-minute deduplication
        val db = BrowserDatabase.getInstance(context)
        val repo = BrowserRepository(db)
        repo.addOrUpdateBookmark(
            BookmarkEntity(title = "Android Docs", url = "https://developer.android.com/compose", isSpeedDial = false)
        )
        val savedBookmark = repo.allBookmarks.first().first { it.url == "https://developer.android.com/compose" }
        repo.updateBookmarkFields(
            id = savedBookmark.id,
            title = "Jetpack Compose Docs",
            url = "https://developer.android.com/jetpack/compose",
            isSpeedDial = true
        )
        val updatedBookmark = repo.allBookmarks.first().first { it.id == savedBookmark.id }
        assertEquals("Jetpack Compose Docs", updatedBookmark.title)
        assertTrue(updatedBookmark.isSpeedDial)

        val testHistoryUrl = "https://kotlinlang.org/docs/home.html"
        repo.recordHistory("Kotlin Docs", testHistoryUrl)
        repo.recordHistory("Kotlin Docs", testHistoryUrl)
        val historyMatches = repo.allHistory.first().filter { it.url == testHistoryUrl }
        assertEquals(1, historyMatches.size)

        // 4. WebViewStartupHelper cleans corrupt/truncated variations_seed and stale staging files while preserving valid files
        val dataRoot = context.dataDir
        val mockWebViewDir = java.io.File(dataRoot, "app_webview").apply { mkdirs() }
        val truncatedSeed = java.io.File(mockWebViewDir, "variations_seed").apply { writeText("unsigned_short") }
        val staleNewSeed = java.io.File(mockWebViewDir, "variations_seed_new").apply { writeText("partial") }
        val validStamp = java.io.File(mockWebViewDir, "variations_stamp").apply { writeText("12345") }

        WebViewStartupHelper.sanitizeVariationsSeedFiles(context)
        assertFalse(truncatedSeed.exists())
        assertFalse(staleNewSeed.exists())
        assertTrue(validStamp.exists())
    }
}
