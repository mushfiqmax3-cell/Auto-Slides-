package com.example

import android.content.Context
import android.net.Uri
import android.webkit.CookieManager
import android.webkit.WebView
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.test.core.app.ApplicationProvider
import com.example.data.InstalledWebAppEntity
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class GoogleAuthAndOptionsTest {

    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun `verify WebViewAuthAndCompatHelper UA parity, host checks, cookie auth detection, scheme routing, and JS anti-throttle guard`() {
        val context = ApplicationProvider.getApplicationContext<Context>()

        // 1. Dynamic Desktop & Mobile Chrome UA must contain Chrome/version and never contain '; wv' or 'Version/4.0'
        val chromeVersion = WebViewAuthAndCompatHelper.extractChromiumVersion(context)
        assertTrue(chromeVersion.matches(Regex("[0-9]+\\.[0-9]+\\.[0-9]+\\.[0-9]+")))

        val desktopUa = WebViewAuthAndCompatHelper.getDesktopChromeUserAgent(context)
        assertTrue(desktopUa.contains("Chrome/$chromeVersion"))
        assertFalse(desktopUa.contains("; wv"))
        assertFalse(desktopUa.contains("Version/4.0"))

        val wv = WebView(context)
        WebViewAuthAndCompatHelper.applyChromeIdentityAndAuthSupport(context, wv.settings, isDesktop = false)
        assertFalse(wv.settings.userAgentString.contains("; wv"))
        assertTrue(wv.settings.userAgentString.contains("Chrome/"))

        WebViewAuthAndCompatHelper.applyChromeIdentityAndAuthSupport(context, wv.settings, isDesktop = true)
        assertEquals(desktopUa, wv.settings.userAgentString)

        WebViewAuthAndCompatHelper.configureInteractiveWebViewFocus(wv, allowAutofill = true)
        assertTrue(wv.isFocusable)
        assertTrue(wv.isFocusableInTouchMode)
        assertEquals(android.view.View.LAYER_TYPE_NONE, wv.layerType)

        // 2. Google Identity & Trusted Asset host allowlists
        assertTrue(WebViewAuthAndCompatHelper.isGoogleAuthOrIdentityHost("accounts.google.com"))
        assertTrue(WebViewAuthAndCompatHelper.isGoogleAuthOrIdentityHost("gds.google.com"))
        assertTrue(WebViewAuthAndCompatHelper.isGoogleAuthOrIdentityHost("accounts.youtube.com"))
        assertTrue(WebViewAuthAndCompatHelper.isGoogleAuthOrIdentityHost("myaccount.google.com"))
        assertTrue(WebViewAuthAndCompatHelper.isGoogleAuthOrIdentityHost("signin.withgoogle.com"))
        assertFalse(WebViewAuthAndCompatHelper.isGoogleAuthOrIdentityHost("example.com"))

        assertTrue(WebViewAuthAndCompatHelper.isGoogleTrustedOriginHost("aistudio.google.com"))
        assertTrue(WebViewAuthAndCompatHelper.isGoogleTrustedOriginHost("ssl.gstatic.com"))
        assertTrue(WebViewAuthAndCompatHelper.isGoogleTrustedOriginHost("www.googleapis.com"))
        assertTrue(WebViewAuthAndCompatHelper.isGoogleTrustedOriginHost("www.recaptcha.net"))
        assertFalse(WebViewAuthAndCompatHelper.isGoogleTrustedOriginHost("doubleclick.net"))

        // 3. Google Auth Cookies check covers legacy & modern __Secure-* cookies
        val cookieManager = CookieManager.getInstance()
        cookieManager.removeAllCookies(null)
        assertFalse(WebViewAuthAndCompatHelper.hasGoogleAuthCookies(cookieManager))

        cookieManager.setCookie("https://accounts.google.com", "__Secure-1PSID=test_token_123; Path=/")
        assertTrue(WebViewAuthAndCompatHelper.hasGoogleAuthCookies(cookieManager))

        cookieManager.removeAllCookies(null)
        assertFalse(WebViewAuthAndCompatHelper.hasGoogleAuthCookies(cookieManager))

        // 4. URL routing rules (http/https/about/javascript -> false, popup blob: -> callback, intent:// fallback -> loads fallback URL)
        assertFalse(
            WebViewAuthAndCompatHelper.handleShouldOverrideUrlLoading(
                context = context,
                webView = wv,
                uri = Uri.parse("https://accounts.google.com/v3/signin/identifier")
            )
        )
        assertFalse(
            WebViewAuthAndCompatHelper.handleShouldOverrideUrlLoading(
                context = context,
                webView = wv,
                uri = Uri.parse("about:blank")
            )
        )
        assertFalse(
            WebViewAuthAndCompatHelper.handleShouldOverrideUrlLoading(
                context = context,
                webView = wv,
                uri = Uri.parse("javascript:void(0)")
            )
        )

        var interceptedBlob: String? = null
        assertTrue(
            WebViewAuthAndCompatHelper.handleShouldOverrideUrlLoading(
                context = context,
                webView = wv,
                uri = Uri.parse("blob:https://aistudio.google.com/test-export"),
                isPopupWindow = true,
                onBlobOrDataUrl = { interceptedBlob = it }
            )
        )
        assertEquals("blob:https://aistudio.google.com/test-export", interceptedBlob)

        val fallbackUrl = "https://accounts.google.com/fallback-signin"
        // Self-package intent:// loop guard must load browser_fallback_url directly without re-launching app
        val selfIntentUri = "intent://auth#Intent;scheme=https;package=${context.packageName};S.browser_fallback_url=${Uri.encode(fallbackUrl)};end"
        assertTrue(
            WebViewAuthAndCompatHelper.handleShouldOverrideUrlLoading(
                context = context,
                webView = wv,
                uri = Uri.parse(selfIntentUri)
            )
        )
        assertEquals(fallbackUrl, Shadows.shadowOf(wv).lastLoadedUrl)

        // Missing external app (ActivityNotFoundException) must also load browser_fallback_url into WebView
        val missingAppFallbackUrl = "https://accounts.google.com/external-missing-fallback"
        val externalIntentUri = "intent://auth#Intent;scheme=https;package=com.google.nonexistent.authapp;S.browser_fallback_url=${Uri.encode(missingAppFallbackUrl)};end"
        val throwingContext = object : android.content.ContextWrapper(context) {
            override fun startActivity(intent: android.content.Intent?) {
                throw android.content.ActivityNotFoundException("Not installed in test")
            }
        }
        assertTrue(
            WebViewAuthAndCompatHelper.handleShouldOverrideUrlLoading(
                context = throwingContext,
                webView = wv,
                uri = Uri.parse(externalIntentUri)
            )
        )
        assertEquals(missingAppFallbackUrl, Shadows.shadowOf(wv).lastLoadedUrl)

        // 5. Blocked ad-resource MIME types
        assertEquals("application/javascript", WebViewAuthAndCompatHelper.blockedResourceMimeType("/ads/tag.js"))
        assertEquals("text/css", WebViewAuthAndCompatHelper.blockedResourceMimeType("/ads/banner.css"))
        assertEquals("text/plain", WebViewAuthAndCompatHelper.blockedResourceMimeType("/pixel.gif"))

        // 6. Verify PAGE_VISIBILITY_OVERRIDE_JS skips Google Identity origins and does not use MutationObserver
        val js = WebViewManager.PAGE_VISIBILITY_OVERRIDE_JS
        assertFalse(js.contains("MutationObserver"))
        assertTrue(js.contains("accounts.google.com"))
        assertTrue(js.contains("gds.google.com"))
        assertTrue(js.contains("myaccount.google.com"))
        assertTrue(js.contains("signin.withgoogle.com"))
    }

    @Test
    fun `verify WebViewManager Google Sign-In auto-enables JS, avoids Incognito trap, and PWA compat works`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val manager = WebViewManager.getInstance(context)
        manager.closeAllTabsAndResetToStartPage()

        // Simulate user having turned off JavaScript globally and wait for WebViewManager flow collector
        manager.preferences.setJavaScriptEnabled(false)
        repeat(20) {
            if (!manager.preferences.settingsFlow.first().javaScriptEnabled) return@repeat
            kotlinx.coroutines.delay(50)
        }

        // Open an Incognito tab and trigger Google Sign-In from it -> must open a normal non-Incognito tab and re-enable JS
        assertTrue(manager.openNewTab(WebViewManager.NEW_TAB_URL, isIncognito = true))
        val incognitoTab = manager.tabsState.value.last()
        assertTrue(incognitoTab.isIncognito)

        manager.openGoogleSignIn()
        val activeAfterSignIn = manager.tabsState.value.find { it.id == manager.activeTabId.value }
        assertNotNull(activeAfterSignIn)
        assertFalse(activeAfterSignIn!!.isIncognito)
        assertTrue(activeAfterSignIn.url.contains("accounts.google.com/ServiceLogin"))
        // Wait briefly for async DataStore write from ioScope to commit javaScriptEnabled = true
        repeat(30) {
            if (manager.preferences.settingsFlow.first().javaScriptEnabled) return@repeat
            kotlinx.coroutines.delay(50)
        }
        assertTrue(manager.preferences.settingsFlow.first().javaScriptEnabled)

        // Verify Account Manager & Re-Sync & Sign-Out route cleanly
        manager.openGoogleAccountManager()
        assertEquals(
            "https://myaccount.google.com/",
            manager.tabsState.value.first { it.id == manager.activeTabId.value }.url
        )

        manager.reSyncGoogleAuthForActiveTab()
        assertTrue(
            manager.tabsState.value.first { it.id == manager.activeTabId.value }
                .url.contains("accounts.google.com/ServiceLogin")
        )

        manager.signOutGoogleAccounts()
        assertEquals(
            "https://accounts.google.com/Logout",
            manager.tabsState.value.first { it.id == manager.activeTabId.value }.url
        )

        // Returning to Start Page must clear stale canGoBack / canGoForward flags
        manager.loadUrlInTab(manager.activeTabId.value, WebViewManager.NEW_TAB_URL)
        val homeTab = manager.tabsState.value.first { it.id == manager.activeTabId.value }
        assertEquals(WebViewManager.NEW_TAB_URL, homeTab.url)
        assertFalse(homeTab.canGoBack)
        assertFalse(homeTab.canGoForward)

        // Verify PwaSessionController uses aligned Chrome UA and supports Desktop toggle & reSyncGoogleAuth
        val pwaEntity = InstalledWebAppEntity(
            pwaId = PwaShortcutHelper.generateUniquePwaId(),
            name = "AI Studio Test PWA",
            url = "https://aistudio.google.com/",
            isStandalonePwa = true,
            isolatedProfile = true,
            profileName = "pwa_profile_auth_test"
        )
        val pwaSession = PwaWebViewPool.getOrCreateSession(context, pwaEntity)
        assertFalse(pwaSession.webView.settings.userAgentString.contains("; wv"))
        pwaSession.toggleDesktopMode()
        assertTrue(pwaSession.uiState.value.isDesktopMode)
        assertEquals(
            WebViewAuthAndCompatHelper.getDesktopChromeUserAgent(context),
            pwaSession.webView.settings.userAgentString
        )
        pwaSession.toggleDesktopMode()
        assertFalse(pwaSession.uiState.value.isDesktopMode)
        PwaWebViewPool.removeAndDestroySession(pwaEntity.pwaId, context)

        manager.closeAllTabsAndResetToStartPage()
    }

    @Test
    fun `verify Tab Switcher Reopen & Close All dismiss dialog, OAuth popup controls render, and Start Page Share-Copy guards work`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val manager = WebViewManager.getInstance(context)
        manager.closeAllTabsAndResetToStartPage()

        // 1. Open 2 tabs -> open Tab Switcher -> tap Close All -> verify dialog dismisses & 1 Start Page tab remains
        assertTrue(manager.openNewTab("https://github.com", isIncognito = false))
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("tab_switcher_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("close_all_tabs_button").assertIsDisplayed().performClick()
        composeRule.waitForIdle()
        assertEquals(1, manager.tabsState.value.size)
        assertEquals(WebViewManager.NEW_TAB_URL, manager.tabsState.value.first().url)

        // Open Tab Switcher again -> tap Reopen -> verify dialog dismisses & closed tab is restored
        composeRule.onNodeWithTag("tab_switcher_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("reopen_closed_tab_button").assertIsDisplayed().performClick()
        composeRule.waitForIdle()
        assertTrue(manager.tabsState.value.any { it.url == "https://github.com" })

        manager.closeAllTabsAndResetToStartPage()
        composeRule.waitForIdle()

        // 2. Verify Share & Copy Link safely guard on Start Page without crash
        composeRule.onNodeWithTag("chrome_menu_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("menu_share_button").performScrollTo().performClick()
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("chrome_menu_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("menu_copy_link_button").performScrollTo().performClick()
        composeRule.waitForIdle()

        // 3. Verify Start Page Google Sign-In chip triggers Google Sign-In URL cleanly
        composeRule.onNodeWithTag("ntp_google_chip").performClick()
        composeRule.waitForIdle()
        assertTrue(
            manager.tabsState.value.first { it.id == manager.activeTabId.value }
                .url.contains("accounts.google.com")
        )

        manager.closeAllTabsAndResetToStartPage()
    }

    @Test
    fun `verify Overflow Menu and Settings Google Sign-In buttons route to Google login cleanly`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val manager = WebViewManager.getInstance(context)
        manager.closeAllTabsAndResetToStartPage()
        composeRule.waitForIdle()

        // 1. Overflow menu Google Account row opens accounts.google.com
        composeRule.onNodeWithTag("chrome_menu_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("menu_google_account_item").assertIsDisplayed().performClick()
        composeRule.waitForIdle()
        assertTrue(
            manager.tabsState.value.first { it.id == manager.activeTabId.value }
                .url.contains("accounts.google.com")
        )

        // Reset back to Start Page
        composeRule.onNodeWithTag("nav_home_button").performClick()
        composeRule.waitForIdle()
        assertEquals(
            WebViewManager.NEW_TAB_URL,
            manager.tabsState.value.first { it.id == manager.activeTabId.value }.url
        )

        // 2. Settings sheet Google Sign In button dismisses Settings and opens accounts.google.com
        composeRule.onNodeWithTag("chrome_menu_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("menu_settings_button").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("settings_google_primary_button").performScrollTo().performClick()
        composeRule.waitForIdle()
        assertTrue(
            manager.tabsState.value.first { it.id == manager.activeTabId.value }
                .url.contains("accounts.google.com")
        )

        manager.closeAllTabsAndResetToStartPage()
    }
}
