package com.example

import android.content.Context
import android.os.Build
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewOutcomeReceiver
import androidx.webkit.WebViewStartUpConfig
import androidx.webkit.WebViewStartUpResult
import androidx.webkit.WebViewStartupException
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Coordinates safe, single-shot Chromium WebView startup and cleans up corrupted/zero-byte
 * variations seed staging files before native initialization runs.
 */
object WebViewStartupHelper {

    private val initialized = AtomicBoolean(false)
    private val startupExecutor by lazy { Executors.newSingleThreadExecutor() }

    fun ensureInitialized(context: Context) {
        val appCtx = context.applicationContext ?: context
        if (!initialized.compareAndSet(false, true)) return

        sanitizeVariationsSeedFiles(appCtx)

        try {
            val config = WebViewStartUpConfig.Builder(startupExecutor).build()
            WebViewCompat.startUpWebView(
                appCtx,
                config,
                object : WebViewOutcomeReceiver<WebViewStartUpResult, WebViewStartupException> {
                    override fun onResult(result: WebViewStartUpResult) {
                        // WebView initialized cleanly
                    }

                    override fun onError(error: WebViewStartupException) {
                        // Safe fallback: standard WebView creation will handle initialization
                    }
                }
            )
        } catch (_: Throwable) {
            // Safe fallback on environments/emulators where startUpWebView boundary is unavailable
        }
    }

    internal fun sanitizeVariationsSeedFiles(context: Context) {
        try {
            val dataDir = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                context.dataDir
            } else {
                context.filesDir?.parentFile
            } ?: return

            val webViewDirs = dataDir.listFiles { file ->
                file.isDirectory && file.name.startsWith("app_webview")
            } ?: return

            for (dir in webViewDirs) {
                cleanSeedFileIfCorrupt(File(dir, "variations_seed"), minValidBytes = 64L)
                cleanSeedFileIfCorrupt(File(dir, "variations_seed_new"), alwaysRemoveStaleStaging = true)
                cleanSeedFileIfCorrupt(File(dir, "variations_stamp"), minValidBytes = 1L)
            }
        } catch (_: Throwable) {
        }
    }

    private fun cleanSeedFileIfCorrupt(
        file: File,
        minValidBytes: Long = 1L,
        alwaysRemoveStaleStaging: Boolean = false
    ) {
        try {
            if (!file.exists() || !file.isFile) return
            if (alwaysRemoveStaleStaging || file.length() < minValidBytes) {
                file.delete()
            }
        } catch (_: Throwable) {
        }
    }
}
