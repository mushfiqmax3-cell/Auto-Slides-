package com.example

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.net.http.SslError
import android.os.Build
import android.view.View
import android.webkit.CookieManager
import android.webkit.JsPromptResult
import android.webkit.JsResult
import android.webkit.SslErrorHandler
import android.webkit.WebSettings
import android.webkit.WebView
import android.widget.EditText
import android.widget.Toast
import androidx.webkit.UserAgentMetadata
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature

/**
 * Shared Chromium WebView compatibility, Google Identity / OAuth / Passkey authentication,
 * URL scheme handling, and JS dialog utilities used consistently across Browser tabs, OAuth popups,
 * and standalone PWAs.
 */
object WebViewAuthAndCompatHelper {

    private val GOOGLE_AUTH_EXACT_HOSTS = setOf(
        "accounts.google.com",
        "accounts.youtube.com",
        "gds.google.com",
        "myaccount.google.com",
        "ogs.google.com",
        "signin.withgoogle.com"
    )

    private val GOOGLE_TRUSTED_ROOT_DOMAINS = setOf(
        "google.com",
        "googleapis.com",
        "gstatic.com",
        "googleusercontent.com",
        "youtube.com",
        "ytimg.com",
        "ggpht.com",
        "gvt1.com",
        "gvt2.com",
        "recaptcha.net",
        "withgoogle.com"
    )

    private val GOOGLE_AUTH_COOKIE_KEYS = listOf(
        "SID=",
        "HSID=",
        "SSID=",
        "APISID=",
        "SAPISID=",
        "__Secure-1PSID=",
        "__Secure-3PSID=",
        "__Host-1PSID=",
        "__Host-3PSID=",
        "OSID="
    )

    @Volatile
    private var cachedChromiumVersion: String? = null

    fun extractChromiumVersion(context: Context): String {
        cachedChromiumVersion?.let { return it }
        val extracted = try {
            val defaultUa = WebSettings.getDefaultUserAgent(context).orEmpty()
            Regex("Chrome/([0-9]+\\.[0-9]+\\.[0-9]+\\.[0-9]+)")
                .find(defaultUa)
                ?.groupValues
                ?.getOrNull(1)
                ?.takeIf { it.isNotBlank() }
                ?: "131.0.0.0"
        } catch (_: Throwable) {
            "131.0.0.0"
        }
        cachedChromiumVersion = extracted
        return extracted
    }

    fun getDesktopChromeUserAgent(context: Context): String {
        val chromeVersion = extractChromiumVersion(context)
        return "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/$chromeVersion Safari/537.36"
    }

    /**
     * Configures HTTP User-Agent, Sec-CH-UA User-Agent Client Hints, suppresses the X-Requested-With
     * WebView header leak, and enables WebAuthn / Passkey browser authentication support.
     */
    fun applyChromeIdentityAndAuthSupport(
        context: Context,
        settings: WebSettings,
        isDesktop: Boolean
    ) {
        // 1. Align HTTP User-Agent header cleanly with device Chromium version
        settings.userAgentString = if (isDesktop) {
            getDesktopChromeUserAgent(context)
        } else {
            WebViewManager.getSanitizedMobileUserAgent(context)
        }

        // 2. Strip X-Requested-With header so Google Identity / OAuth does not block embedded WebView
        try {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.REQUESTED_WITH_HEADER_ALLOW_LIST)) {
                WebSettingsCompat.setRequestedWithHeaderOriginAllowList(settings, emptySet())
            }
        } catch (_: Throwable) {
        }

        // 3. Replace "Android WebView" brand in Sec-CH-UA & navigator.userAgentData with "Google Chrome"
        try {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.USER_AGENT_METADATA)) {
                val currentMeta = WebSettingsCompat.getUserAgentMetadata(settings)
                val updatedBrands = currentMeta.brandVersionList.map { bv ->
                    if (bv.brand.contains("WebView", ignoreCase = true)) {
                        UserAgentMetadata.BrandVersion.Builder(bv)
                            .setBrand("Google Chrome")
                            .build()
                    } else {
                        bv
                    }
                }
                val builder = UserAgentMetadata.Builder(currentMeta)
                    .setBrandVersionList(updatedBrands)
                    .setMobile(!isDesktop)
                    .setPlatform(if (isDesktop) "Windows" else "Android")
                if (isDesktop) {
                    builder.setPlatformVersion("15.0.0")
                    builder.setModel("")
                }
                if (WebViewFeature.isFeatureSupported(WebViewFeature.USER_AGENT_METADATA_FORM_FACTORS)) {
                    builder.setFormFactors(
                        if (isDesktop) listOf(UserAgentMetadata.FORM_FACTOR_DESKTOP)
                        else listOf(UserAgentMetadata.FORM_FACTOR_MOBILE)
                    )
                }
                WebSettingsCompat.setUserAgentMetadata(settings, builder.build())
            }
        } catch (_: Throwable) {
        }

        // 4. Enable Passkeys / WebAuthn / FIDO2 device authentication inside browser & popups
        try {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.WEB_AUTHENTICATION)) {
                WebSettingsCompat.setWebAuthenticationSupport(
                    settings,
                    WebSettingsCompat.WEB_AUTHENTICATION_SUPPORT_FOR_BROWSER
                )
            }
        } catch (_: Throwable) {
        }
    }

    fun configureInteractiveWebViewFocus(webView: WebView, allowAutofill: Boolean) {
        webView.setLayerType(View.LAYER_TYPE_NONE, null)
        webView.isFocusable = true
        webView.isFocusableInTouchMode = true
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                webView.importantForAutofill = if (allowAutofill) {
                    View.IMPORTANT_FOR_AUTOFILL_YES
                } else {
                    View.IMPORTANT_FOR_AUTOFILL_NO
                }
            } catch (_: Throwable) {
            }
        }
    }

    fun isGoogleAuthOrIdentityHost(host: String): Boolean {
        val lower = host.trim().lowercase()
        if (lower.isEmpty()) return false
        return GOOGLE_AUTH_EXACT_HOSTS.any { lower == it || lower.endsWith(".$it") }
    }

    fun isGoogleTrustedOriginHost(host: String): Boolean {
        val lower = host.trim().lowercase()
        if (lower.isEmpty()) return false
        return GOOGLE_TRUSTED_ROOT_DOMAINS.any { domain ->
            lower == domain || lower.endsWith(".$domain")
        }
    }

    fun hasGoogleAuthCookies(cookieManager: CookieManager): Boolean {
        return try {
            val cookies = listOf(
                "https://accounts.google.com",
                "https://www.google.com",
                "https://myaccount.google.com",
                "https://aistudio.google.com"
            ).joinToString(";") { url ->
                cookieManager.getCookie(url).orEmpty()
            }
            GOOGLE_AUTH_COOKIE_KEYS.any { key -> cookies.contains(key) }
        } catch (_: Throwable) {
            false
        }
    }

    fun blockedResourceMimeType(urlPath: String?): String {
        val lower = urlPath?.lowercase().orEmpty()
        return when {
            lower.endsWith(".js") || lower.endsWith(".mjs") -> "application/javascript"
            lower.endsWith(".css") -> "text/css"
            else -> "text/plain"
        }
    }

    /**
     * Handles HTTP/HTTPS, internal browser schemes (`about:`, `javascript:`), downloads (`blob:`, `data:`),
     * `intent://` deep links (with safe sanitization & `browser_fallback_url`), and external schemes (`mailto:`, `tel:`, etc.).
     */
    fun handleShouldOverrideUrlLoading(
        context: Context,
        webView: WebView,
        uri: Uri,
        isPopupWindow: Boolean = false,
        onBlobOrDataUrl: ((String) -> Unit)? = null
    ): Boolean {
        val scheme = uri.scheme?.lowercase() ?: return false
        if (scheme == "http" || scheme == "https" || scheme == "about" || scheme == "javascript") {
            return false
        }

        if (scheme == "blob" || scheme == "data") {
            return if (isPopupWindow && onBlobOrDataUrl != null) {
                onBlobOrDataUrl(uri.toString())
                true
            } else {
                false
            }
        }

        if (scheme == "intent") {
            return handleIntentSchemeUri(context, webView, uri.toString())
        }

        return try {
            val externalIntent = Intent(Intent.ACTION_VIEW, uri).apply {
                addCategory(Intent.CATEGORY_BROWSABLE)
                if (context !is Activity) {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            }
            context.startActivity(externalIntent)
            true
        } catch (_: ActivityNotFoundException) {
            showShortToast(context, "No app found to open $scheme link")
            true
        } catch (_: Exception) {
            true
        }
    }

    internal fun handleIntentSchemeUri(
        context: Context,
        webView: WebView,
        rawIntentUri: String
    ): Boolean {
        val parsedIntent = try {
            Intent.parseUri(rawIntentUri, Intent.URI_INTENT_SCHEME)
        } catch (_: Exception) {
            return true
        }

        val fallbackUrl = parsedIntent.getStringExtra("browser_fallback_url")

        // Security hygiene: strip targeted components/selectors and restrict to browsable activities
        parsedIntent.component = null
        parsedIntent.selector = null
        parsedIntent.addCategory(Intent.CATEGORY_BROWSABLE)
        if (context !is Activity) {
            parsedIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        val targetPackage = parsedIntent.`package`
        if (targetPackage == context.packageName) {
            if (!fallbackUrl.isNullOrBlank() && isHttpOrHttps(fallbackUrl)) {
                webView.loadUrl(fallbackUrl)
            }
            return true
        }

        try {
            context.startActivity(parsedIntent)
            return true
        } catch (_: Exception) {
            if (!fallbackUrl.isNullOrBlank() && isHttpOrHttps(fallbackUrl)) {
                webView.loadUrl(fallbackUrl)
            } else {
                showShortToast(context, "Required app is not installed on this device")
            }
            return true
        }
    }

    private fun isHttpOrHttps(url: String): Boolean {
        return url.startsWith("https://", ignoreCase = true) ||
            url.startsWith("http://", ignoreCase = true)
    }

    fun handleJsAlert(activity: Activity?, message: String?, result: JsResult?): Boolean {
        if (activity == null || activity.isFinishing || activity.isDestroyed) {
            result?.confirm()
            return true
        }
        return try {
            AlertDialog.Builder(activity)
                .setMessage(message.orEmpty())
                .setPositiveButton(android.R.string.ok) { _, _ -> result?.confirm() }
                .setOnCancelListener { result?.cancel() }
                .show()
            true
        } catch (_: Exception) {
            result?.confirm()
            true
        }
    }

    fun handleJsConfirm(activity: Activity?, message: String?, result: JsResult?): Boolean {
        if (activity == null || activity.isFinishing || activity.isDestroyed) {
            result?.cancel()
            return true
        }
        return try {
            AlertDialog.Builder(activity)
                .setMessage(message.orEmpty())
                .setPositiveButton(android.R.string.ok) { _, _ -> result?.confirm() }
                .setNegativeButton(android.R.string.cancel) { _, _ -> result?.cancel() }
                .setOnCancelListener { result?.cancel() }
                .show()
            true
        } catch (_: Exception) {
            result?.cancel()
            true
        }
    }

    fun handleJsPrompt(
        activity: Activity?,
        message: String?,
        defaultValue: String?,
        result: JsPromptResult?
    ): Boolean {
        if (activity == null || activity.isFinishing || activity.isDestroyed) {
            result?.cancel()
            return true
        }
        return try {
            val input = EditText(activity).apply {
                setText(defaultValue.orEmpty())
                setSelection(text.length)
            }
            AlertDialog.Builder(activity)
                .setMessage(message.orEmpty())
                .setView(input)
                .setPositiveButton(android.R.string.ok) { _, _ ->
                    result?.confirm(input.text?.toString().orEmpty())
                }
                .setNegativeButton(android.R.string.cancel) { _, _ -> result?.cancel() }
                .setOnCancelListener { result?.cancel() }
                .show()
            true
        } catch (_: Exception) {
            result?.cancel()
            true
        }
    }

    fun handleSslErrorSafely(
        context: Context,
        error: SslError?,
        handler: SslErrorHandler?,
        onMainFrameInsecure: (() -> Unit)? = null
    ) {
        try {
            handler?.cancel()
            onMainFrameInsecure?.invoke()
            val urlHost = try {
                Uri.parse(error?.url.orEmpty()).host ?: "this site"
            } catch (_: Exception) {
                "this site"
            }
            showShortToast(context, "Blocked untrusted SSL certificate from $urlHost")
        } catch (_: Exception) {
        }
    }

    private fun showShortToast(context: Context, msg: String) {
        try {
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
        } catch (_: Exception) {
        }
    }
}
