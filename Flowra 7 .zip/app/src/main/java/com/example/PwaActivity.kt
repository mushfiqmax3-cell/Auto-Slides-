package com.example

import android.app.ActivityManager
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.AddToHomeScreen
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.DesktopWindows
import androidx.compose.material.icons.filled.FindInPage
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.BrowserSettings
import com.example.data.FrameRateMode
import com.example.data.InstalledWebAppEntity
import com.example.data.ThemeMode
import com.example.ui.AiStudioPermissionTroubleshooterBanner
import com.example.ui.DownloadConfirmDialog
import com.example.ui.FindInPageBar
import com.example.ui.OAuthPopupModalDialog
import com.example.ui.theme.ChromeEmeraldShield
import com.example.ui.theme.MyApplicationTheme

class PwaActivity : ComponentActivity() {

    private var sessionController by mutableStateOf<PwaSessionController?>(null)
    private var activeAppEntity by mutableStateOf<InstalledWebAppEntity?>(null)
    private var pendingPermissionCallback: ((Boolean) -> Unit)? = null
    private var pendingFolderCallback: ((String, String) -> Unit)? = null

    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        sessionController?.onFileChooserResult(result.resultCode, result.data)
    }

    private val runtimePermissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val granted = results.values.any { it }
        pendingPermissionCallback?.invoke(granted)
        pendingPermissionCallback = null
    }

    private val folderPickerLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { treeUri ->
        val callback = pendingFolderCallback
        pendingFolderCallback = null
        if (treeUri != null) {
            try {
                contentResolver.takePersistableUriPermission(
                    treeUri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (_: Exception) {
            }
            val label = formatSafTreeLabel(treeUri)
            sessionController?.savePreferredDestination(
                DownloadDestination(
                    preset = DownloadFolderPreset.CUSTOM_SAF,
                    customTreeUri = treeUri.toString(),
                    customFolderLabel = label
                )
            )
            callback?.invoke(treeUri.toString(), label)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WebViewStartupHelper.ensureInitialized(applicationContext)
        enableEdgeToEdge()
        FramePacingHelper.applyWindowFramePacing(this, FrameRateMode.SMOOTH_60)

        bindFromIntent(intent)

        setContent {
            val controller = sessionController
            val appEntity = activeAppEntity
            if (controller != null && appEntity != null) {
                val settingsState by controller.preferences.settingsFlow.collectAsStateWithLifecycle(
                    initialValue = BrowserSettings()
                )
                LaunchedEffect(settingsState.frameRateMode) {
                    FramePacingHelper.applyWindowFramePacing(this@PwaActivity, settingsState.frameRateMode)
                }
                val isDark = when (settingsState.themeMode) {
                    ThemeMode.DARK -> true
                    ThemeMode.LIGHT -> false
                    ThemeMode.SYSTEM -> isSystemInDarkTheme()
                }
                MyApplicationTheme(darkTheme = isDark, dynamicColor = false) {
                    PwaStandaloneScreen(
                        controller = controller,
                        badgeTag = appEntity.badgeTag,
                        onPickDownloadFolder = { cb ->
                            pendingFolderCallback = cb
                            try {
                                folderPickerLauncher.launch(null)
                            } catch (_: Exception) {
                                pendingFolderCallback = null
                            }
                        },
                        onOpenInMainBrowser = { currentUrl ->
                            val browserIntent = Intent(this, MainActivity::class.java).apply {
                                action = Intent.ACTION_VIEW
                                data = android.net.Uri.parse(currentUrl)
                                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                                putExtra(PwaShortcutHelper.EXTRA_OPEN_IN_NEW_TAB, true)
                            }
                            startActivity(browserIntent)
                        },
                        onPinToHomeScreen = {
                            window.decorView.postDelayed({
                                if (!isFinishing && !isDestroyed) {
                                    val ok = PwaShortcutHelper.pinToHomeScreen(
                                        context = this@PwaActivity,
                                        app = appEntity,
                                        favicon = controller.uiState.value.favicon
                                    )
                                    android.widget.Toast.makeText(
                                        this@PwaActivity,
                                        if (ok) "Adding \"${appEntity.name}\" to Home Screen" else "Saved shortcut for \"${appEntity.name}\"",
                                        android.widget.Toast.LENGTH_SHORT
                                    ).show()
                                }
                            }, 180L)
                        },
                        onClosePwa = { finishAndRemoveTask() }
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        bindFromIntent(intent)
    }

    private fun bindFromIntent(incomingIntent: Intent?) {
        val appEntity = extractEntityFromIntent(incomingIntent)
        val previousController = sessionController
        if (previousController != null && previousController.app.pwaId != appEntity.pwaId) {
            PwaWebViewPool.markForeground(previousController.app.pwaId, isForeground = false)
            previousController.detachActivity(this)
        }
        val controller = PwaWebViewPool.getOrCreateSession(applicationContext, appEntity)
        activeAppEntity = appEntity
        sessionController = controller

        controller.attachActivity(this)
        PwaWebViewPool.markForeground(controller.app.pwaId, isForeground = true)
        controller.onLaunchFileChooser = { chooserIntent ->
            try {
                fileChooserLauncher.launch(chooserIntent)
                true
            } catch (_: Exception) {
                false
            }
        }
        controller.onRequestRuntimePermissions = { perms, cb ->
            pendingPermissionCallback = cb
            try {
                runtimePermissionsLauncher.launch(perms)
            } catch (_: Exception) {
                pendingPermissionCallback = null
                cb(false)
            }
        }

        // Do NOT request Camera/Mic/Location permissions on PWA startup; only request on-demand when needed.
        if (incomingIntent?.getBooleanExtra(PwaShortcutHelper.EXTRA_REQUEST_PIN_ON_START, false) == true) {
            incomingIntent.removeExtra(PwaShortcutHelper.EXTRA_REQUEST_PIN_ON_START)
            window.decorView.postDelayed({
                if (!isFinishing && !isDestroyed) {
                    PwaShortcutHelper.pinToHomeScreen(
                        context = this@PwaActivity,
                        app = appEntity,
                        favicon = controller.uiState.value.favicon
                    )
                }
            }, 450L)
        }

        applyTaskDescription(appEntity)
        startKeepAliveForPwaPool()
    }

    override fun onResume() {
        super.onResume()
        sessionController?.let { ctrl ->
            ctrl.attachActivity(this)
            PwaWebViewPool.markForeground(ctrl.app.pwaId, isForeground = true)
        }
        startKeepAliveForPwaPool()
    }

    override fun onPause() {
        super.onPause()
        sessionController?.let { ctrl ->
            PwaWebViewPool.markForeground(ctrl.app.pwaId, isForeground = false)
            ctrl.flushCookies()
        }
    }

    override fun onStop() {
        super.onStop()
        sessionController?.let { ctrl ->
            PwaWebViewPool.markForeground(ctrl.app.pwaId, isForeground = false)
            ctrl.flushCookies()
        }
        startKeepAliveForPwaPool()
    }

    override fun onDestroy() {
        sessionController?.detachActivity(this)
        super.onDestroy()
    }

    private fun startKeepAliveForPwaPool() {
        val activeTabs = WebViewManager.getInstanceIfCreated()?.tabsState?.value?.size ?: 0
        BrowserService.startKeepAliveService(
            context = applicationContext,
            tabCount = activeTabs,
            pwaCount = PwaWebViewPool.liveCount()
        )
    }

    private fun extractEntityFromIntent(intent: Intent?): InstalledWebAppEntity {
        PwaShortcutHelper.extractEntityFromShortcutIntent(intent)?.let { extracted ->
            return extracted.copy(isStandalonePwa = true)
        }
        val dataUri = intent?.data
        val pwaId = intent?.getStringExtra(PwaShortcutHelper.EXTRA_PWA_ID)
            ?: dataUri?.lastPathSegment
            ?: "pwa_default"
        val name = intent?.getStringExtra(PwaShortcutHelper.EXTRA_PWA_NAME)
            ?: dataUri?.getQueryParameter("name")
            ?: "Studio Web App"
        val url = intent?.getStringExtra(PwaShortcutHelper.EXTRA_PWA_URL)
            ?: dataUri?.getQueryParameter("url")
            ?: WebViewManager.DEFAULT_HOME_URL
        val isolated = if (intent?.hasExtra(PwaShortcutHelper.EXTRA_ISOLATED_PROFILE) == true) {
            intent.getBooleanExtra(PwaShortcutHelper.EXTRA_ISOLATED_PROFILE, true)
        } else {
            dataUri?.getQueryParameter("isolated")?.toBooleanStrictOrNull() ?: true
        }
        val profileName = intent?.getStringExtra(PwaShortcutHelper.EXTRA_PROFILE_NAME)
            ?: dataUri?.getQueryParameter("profile")
            ?: "pwa_profile_$pwaId"
        val colorFromStr = intent?.getStringExtra(PwaShortcutHelper.EXTRA_BADGE_COLOR_STR)?.toLongOrNull()
            ?: dataUri?.getQueryParameter("color")?.toLongOrNull()
        val badgeColor = if (intent?.hasExtra(PwaShortcutHelper.EXTRA_BADGE_COLOR) == true) {
            intent.getLongExtra(PwaShortcutHelper.EXTRA_BADGE_COLOR, colorFromStr ?: 0xFF1A73E8L)
        } else {
            colorFromStr ?: 0xFF1A73E8L
        }
        val badgeTag = intent?.getStringExtra(PwaShortcutHelper.EXTRA_BADGE_TAG)
            ?: dataUri?.getQueryParameter("tag")
            ?: ""

        return InstalledWebAppEntity(
            pwaId = pwaId,
            name = name,
            url = url,
            isStandalonePwa = true,
            isolatedProfile = isolated,
            profileName = profileName,
            badgeColorHex = badgeColor,
            badgeTag = badgeTag
        )
    }

    @Suppress("DEPRECATION")
    private fun applyTaskDescription(app: InstalledWebAppEntity) {
        try {
            val iconBmp = PwaShortcutHelper.buildLauncherIconBitmap(
                name = app.name,
                favicon = null,
                badgeColorHex = app.badgeColorHex,
                badgeTag = app.badgeTag,
                isStandalonePwa = true
            )
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                setTaskDescription(ActivityManager.TaskDescription(app.name, iconBmp, app.badgeColorHex.toInt()))
            } else {
                setTaskDescription(ActivityManager.TaskDescription(app.name, iconBmp, app.badgeColorHex.toInt()))
            }
        } catch (_: Exception) {
        }
    }
}

@Composable
private fun PwaStandaloneScreen(
    controller: PwaSessionController,
    badgeTag: String,
    onPickDownloadFolder: (((String, String) -> Unit) -> Unit)? = null,
    onOpenInMainBrowser: (String) -> Unit,
    onPinToHomeScreen: () -> Unit = {},
    onClosePwa: () -> Unit
) {
    val uiState by controller.uiState.collectAsStateWithLifecycle()
    val oauthSession by controller.oauthPopupState.collectAsStateWithLifecycle()
    val pendingDownload by controller.pendingDownload.collectAsStateWithLifecycle()
    val findState by controller.findInPageState.collectAsStateWithLifecycle()
    val webViewGeneration by controller.webViewGeneration.collectAsStateWithLifecycle()
    val aiStudioPermissionError by controller.aiStudioPermissionErrorDetected.collectAsStateWithLifecycle()

    var immersiveMode by rememberSaveable { mutableStateOf(false) }
    var showMenu by rememberSaveable { mutableStateOf(false) }
    var askBeforeDownloadState by remember { mutableStateOf(controller.askBeforeDownload) }

    BackHandler(enabled = oauthSession != null || findState.isVisible || uiState.canGoBack) {
        when {
            oauthSession != null -> {
                val popup = oauthSession?.popupWebView
                if (popup?.canGoBack() == true) {
                    popup.goBack()
                } else {
                    controller.closeOAuthPopup()
                }
            }
            findState.isVisible -> controller.clearFindInPage()
            else -> controller.goBack()
        }
    }

    val accentColor = Color(uiState.badgeColorHex)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .windowInsetsPadding(WindowInsets.statusBars)
            .windowInsetsPadding(WindowInsets.navigationBars)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Standalone PWA Header (can be collapsed for full native immersion)
            AnimatedVisibility(visible = !immersiveMode) {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 2.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 6.dp, vertical = 4.dp)
                    ) {
                        IconButton(
                            onClick = { if (!controller.goBack()) onClosePwa() },
                            modifier = Modifier.size(44.dp).testTag("pwa_back_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back"
                            )
                        }

                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(accentColor)
                        ) {
                            Text(
                                text = badgeTag.ifBlank { uiState.appName.firstOrNull()?.uppercase() ?: "P" },
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                ),
                                color = Color.White
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = uiState.appName,
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (uiState.isProfileIsolated) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(ChromeEmeraldShield.copy(alpha = 0.16f))
                                            .padding(horizontal = 5.dp, vertical = 1.dp)
                                    ) {
                                        Text(
                                            text = "Isolated",
                                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                            color = ChromeEmeraldShield
                                        )
                                    }
                                }
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = null,
                                    tint = if (uiState.isSslSecure) ChromeEmeraldShield else MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(11.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = uiState.pageTitle,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        IconButton(
                            onClick = { controller.reloadOrStop() },
                            modifier = Modifier.size(42.dp)
                        ) {
                            Icon(
                                imageVector = if (uiState.isLoading) Icons.Default.Close else Icons.Default.Refresh,
                                contentDescription = "Reload"
                            )
                        }

                        Box {
                            IconButton(
                                onClick = { showMenu = true },
                                modifier = Modifier.size(42.dp).testTag("pwa_menu_button")
                            ) {
                                Icon(Icons.Default.MoreVert, contentDescription = "PWA options")
                            }
                            DropdownMenu(
                                expanded = showMenu,
                                onDismissRequest = { showMenu = false }
                            ) {
                                DropdownMenuItem(
                                    leadingIcon = { Icon(Icons.Default.Home, contentDescription = null) },
                                    text = { Text("App Home") },
                                    onClick = {
                                        showMenu = false
                                        controller.goHome()
                                    }
                                )
                                DropdownMenuItem(
                                    leadingIcon = { Icon(Icons.Default.Fullscreen, contentDescription = null) },
                                    text = { Text("Fullscreen Mode") },
                                    onClick = {
                                        showMenu = false
                                        immersiveMode = true
                                    }
                                )
                                DropdownMenuItem(
                                    leadingIcon = { Icon(Icons.Default.FindInPage, contentDescription = null) },
                                    text = { Text("Find in page") },
                                    onClick = {
                                        showMenu = false
                                        controller.showFindInPage()
                                    }
                                )
                                DropdownMenuItem(
                                    leadingIcon = { Icon(Icons.Default.DesktopWindows, contentDescription = null) },
                                    text = { Text("Desktop site") },
                                    trailingIcon = {
                                        Checkbox(checked = uiState.isDesktopMode, onCheckedChange = null)
                                    },
                                    onClick = {
                                        showMenu = false
                                        controller.toggleDesktopMode()
                                    }
                                )
                                DropdownMenuItem(
                                    leadingIcon = { Icon(Icons.Default.Bookmark, contentDescription = null) },
                                    text = { Text("Bookmark offline") },
                                    onClick = {
                                        showMenu = false
                                        controller.bookmarkCurrentPage()
                                    }
                                )
                                DropdownMenuItem(
                                    leadingIcon = { Icon(Icons.Default.Print, contentDescription = null) },
                                    text = { Text("Print / Save as PDF") },
                                    onClick = {
                                        showMenu = false
                                        controller.printPage()
                                    }
                                )
                                DropdownMenuItem(
                                    leadingIcon = { Icon(Icons.AutoMirrored.Filled.AddToHomeScreen, contentDescription = null) },
                                    text = { Text("Add to Home Screen") },
                                    onClick = {
                                        showMenu = false
                                        onPinToHomeScreen()
                                    }
                                )
                                DropdownMenuItem(
                                    leadingIcon = { Icon(Icons.Default.OpenInBrowser, contentDescription = null) },
                                    text = { Text("Open in Flowra") },
                                    onClick = {
                                        showMenu = false
                                        onOpenInMainBrowser(uiState.url)
                                    }
                                )
                                HorizontalDivider()
                                DropdownMenuItem(
                                    leadingIcon = { Icon(Icons.Default.DeleteSweep, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
                                    text = { Text("Reset this PWA session", color = MaterialTheme.colorScheme.error) },
                                    onClick = {
                                        showMenu = false
                                        controller.clearThisPwaSession()
                                    }
                                )
                                DropdownMenuItem(
                                    leadingIcon = { Icon(Icons.Default.Close, contentDescription = null) },
                                    text = { Text("Close PWA window") },
                                    onClick = {
                                        showMenu = false
                                        onClosePwa()
                                    }
                                )
                            }
                        }
                    }
                }
            }

            if (uiState.isLoading && uiState.progress in 1..99) {
                LinearProgressIndicator(
                    progress = { (uiState.progress / 100f).coerceIn(0.05f, 1f) },
                    color = accentColor,
                    modifier = Modifier.fillMaxWidth().height(2.5.dp)
                )
            }

            FindInPageBar(
                state = findState,
                onQueryChange = { controller.updateFindQuery(it) },
                onFindPrev = { controller.findNextMatch(forward = false) },
                onFindNext = { controller.findNextMatch(forward = true) },
                onClose = { controller.clearFindInPage() }
            )

            AiStudioPermissionTroubleshooterBanner(
                visible = aiStudioPermissionError,
                onRefreshAuth = { controller.reSyncGoogleAuth() },
                onOpenApiKeys = { controller.openAiStudioApiKeys() },
                onStartNewChat = { controller.startNewAiStudioPrompt() },
                onDismiss = { controller.dismissAiStudioPermissionBanner() }
            )

            AndroidView(
                factory = { ctx ->
                    FrameLayout(ctx).apply {
                        val wv = controller.webView
                        (wv.parent as? ViewGroup)?.removeView(wv)
                        addView(
                            wv,
                            FrameLayout.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                        )
                    }
                },
                update = { container ->
                    // Read webViewGeneration to trigger re-attach if renderer crashed and recreated WebView
                    @Suppress("UNUSED_EXPRESSION")
                    webViewGeneration
                    val currentWv = controller.webView
                    if (container.childCount != 1 || container.getChildAt(0) !== currentWv) {
                        container.removeAllViews()
                        (currentWv.parent as? ViewGroup)?.removeView(currentWv)
                        container.addView(
                            currentWv,
                            FrameLayout.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                        )
                    }
                },
                modifier = Modifier.weight(1f).fillMaxWidth()
            )
        }

        // Small floating pill to restore PWA top bar if user switched to Immersive Fullscreen
        if (immersiveMode) {
            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f),
                tonalElevation = 6.dp,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(10.dp)
                    .size(38.dp)
                    .clip(CircleShape)
                    .clickable { immersiveMode = false }
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.FullscreenExit,
                        contentDescription = "Exit fullscreen",
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }

    val currentPopup = oauthSession
    if (currentPopup != null) {
        OAuthPopupModalDialog(
            session = currentPopup,
            onDismiss = { controller.closeOAuthPopup() }
        )
    }

    val currentDl = pendingDownload
    if (currentDl != null) {
        DownloadConfirmDialog(
            request = currentDl,
            askBeforeDownload = askBeforeDownloadState,
            onToggleAskBeforeDownload = { checked ->
                askBeforeDownloadState = checked
                controller.updateAskBeforeDownload(checked)
            },
            onPickCustomFolder = onPickDownloadFolder,
            onConfirm = { customName, destination ->
                controller.confirmPendingDownload(customName, destination)
            },
            onDismiss = { controller.dismissPendingDownload() }
        )
    }
}
