package com.example

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.DownloadStatus
import com.example.ui.BatteryShieldDialog
import com.example.ui.BookmarksSheetDialog
import com.example.ui.ChromeNewTabPage
import com.example.ui.ChromeOverflowMenuOverlay
import com.example.ui.ChromeTopToolbar
import com.example.ui.CompactTabStripBar
import com.example.ui.CreateShortcutOrPwaDialog
import com.example.ui.DownloadConfirmDialog
import com.example.ui.DownloadsSheetDialog
import com.example.ui.FindInPageBar
import com.example.ui.HistorySheetDialog
import com.example.ui.InstalledWebAppsSheetDialog
import com.example.ui.IsolatedSlimProgressBar
import com.example.ui.OAuthPopupModalDialog
import com.example.ui.SettingsSheetDialog
import com.example.ui.SiteInfoDialog
import com.example.ui.TabGridSwitcherDialog
import com.example.ui.WebContextMenuDialog

@Composable
fun BrowserScreen(
    browserViewModel: BrowserViewModel,
    isBatteryUnrestricted: Boolean,
    onRefreshBatteryState: () -> Unit,
    permissionsStatus: DevicePermissionsStatus = DevicePermissionsStatus(),
    onRequestAllPermissions: () -> Unit = {},
    onPickDownloadFolder: (((String, String) -> Unit) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val webViewManager = browserViewModel.webViewManager

    val tabs by webViewManager.tabsState.collectAsStateWithLifecycle()
    val activeTabId by webViewManager.activeTabId.collectAsStateWithLifecycle()
    val oauthPopupSession by webViewManager.oauthPopupState.collectAsStateWithLifecycle()
    val pendingDownload by webViewManager.pendingDownload.collectAsStateWithLifecycle()
    val findInPageState by webViewManager.findInPageState.collectAsStateWithLifecycle()
    val contextMenuTarget by webViewManager.contextMenuTarget.collectAsStateWithLifecycle()
    val isGoogleSignedIn by webViewManager.isGoogleSignedIn.collectAsStateWithLifecycle()

    val shieldServiceState by BrowserService.serviceState.collectAsStateWithLifecycle()
    val pwaPoolStats by PwaWebViewPool.poolStats.collectAsStateWithLifecycle()
    val settings by browserViewModel.settings.collectAsStateWithLifecycle()
    val bookmarks by browserViewModel.bookmarks.collectAsStateWithLifecycle()
    val speedDialItems by browserViewModel.speedDialBookmarks.collectAsStateWithLifecycle()
    val history by browserViewModel.history.collectAsStateWithLifecycle()
    val downloads by browserViewModel.downloads.collectAsStateWithLifecycle()
    val installedWebApps by browserViewModel.installedWebApps.collectAsStateWithLifecycle()
    val isActiveBookmarked by browserViewModel.isActiveTabBookmarked.collectAsStateWithLifecycle()

    val activeTab = remember(tabs, activeTabId) {
        tabs.find { it.id == activeTabId } ?: tabs.firstOrNull()
    }
    val activeDownloadCount = remember(downloads) {
        downloads.count { it.status == DownloadStatus.RUNNING || it.status == DownloadStatus.PENDING }
    }

    var showOverflowMenu by rememberSaveable { mutableStateOf(false) }
    var showTabSwitcher by rememberSaveable { mutableStateOf(false) }
    var showDownloadsSheet by rememberSaveable { mutableStateOf(false) }
    var showBookmarksSheet by rememberSaveable { mutableStateOf(false) }
    var showHistorySheet by rememberSaveable { mutableStateOf(false) }
    var showSettingsSheet by rememberSaveable { mutableStateOf(false) }
    var showShieldDialog by rememberSaveable { mutableStateOf(false) }
    var showSiteInfoDialog by rememberSaveable { mutableStateOf(false) }
    var showCreatePwaDialog by rememberSaveable { mutableStateOf(false) }
    var showInstalledPwasSheet by rememberSaveable { mutableStateOf(false) }

    val externalZipPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            browserViewModel.extractExternalZipUri(context, uri)
        }
    }

    BackHandler(
        enabled = showOverflowMenu ||
            oauthPopupSession != null ||
            findInPageState.isVisible ||
            activeTab?.canGoBack == true
    ) {
        when {
            showOverflowMenu -> showOverflowMenu = false
            oauthPopupSession != null -> webViewManager.closeOAuthPopup()
            findInPageState.isVisible -> webViewManager.clearFindInPage()
            else -> webViewManager.goBackInActiveTab()
        }
    }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        val isWideScreen = maxWidth >= 600.dp

        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.statusBars)
                .windowInsetsPadding(WindowInsets.navigationBars)
        ) {
            // 1. Authentic Chrome Top Toolbar (Omnibox, Bookmark Star, Tab Count [5], Overflow Toggle Menu)
            ChromeTopToolbar(
                activeTab = activeTab,
                tabCount = tabs.size,
                isBookmarked = isActiveBookmarked,
                isOverflowMenuOpen = showOverflowMenu,
                webViewManager = webViewManager,
                bookmarks = bookmarks,
                history = history,
                onHomeClick = {
                    showOverflowMenu = false
                    webViewManager.goHomeInActiveTab()
                },
                onSubmitUrl = { query ->
                    showOverflowMenu = false
                    webViewManager.loadUrlInActiveTab(query)
                },
                onToggleBookmark = {
                    browserViewModel.toggleBookmarkForActiveTab()
                    Toast.makeText(
                        context,
                        if (isActiveBookmarked) "Removed bookmark" else "Bookmarked page",
                        Toast.LENGTH_SHORT
                    ).show()
                },
                onOpenTabSwitcher = {
                    showOverflowMenu = false
                    webViewManager.captureTabThumbnails()
                    showTabSwitcher = true
                },
                onOpenSiteInfo = {
                    showOverflowMenu = false
                    showSiteInfoDialog = true
                },
                onToggleOverflowMenu = {
                    val nextOpen = !showOverflowMenu
                    if (nextOpen) {
                        webViewManager.refreshGoogleSignInStatus()
                    }
                    showOverflowMenu = nextOpen
                },
                onDismissOverflowMenu = { showOverflowMenu = false }
            )

            // 2. Optional Tab Strip (auto-enabled on tablets or when toggled on phones)
            if (isWideScreen || settings.showTabStrip) {
                CompactTabStripBar(
                    tabs = tabs,
                    activeTabId = activeTabId,
                    onSelectTab = { webViewManager.selectTab(it) },
                    onCloseTab = { webViewManager.closeTab(it) },
                    onAddTab = { webViewManager.openNewTab(WebViewManager.NEW_TAB_URL, isIncognito = false) }
                )
            }

            // 3. Isolated Slim Progress Bar
            IsolatedSlimProgressBar(webViewManager = webViewManager)

            // 4. Find in Page Bar (when active)
            FindInPageBar(
                state = findInPageState,
                onQueryChange = { webViewManager.updateFindQuery(it) },
                onFindPrev = { webViewManager.findNextMatch(forward = false) },
                onFindNext = { webViewManager.findNextMatch(forward = true) },
                onClose = { webViewManager.clearFindInPage() }
            )

            // 5. Persistent 5-WebView Viewport + Chrome Start Page Overlay when url == about:newtab
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                PersistentWebViewViewport(
                    webViewManager = webViewManager,
                    modifier = Modifier.fillMaxSize()
                )

                if (activeTab?.url == WebViewManager.NEW_TAB_URL) {
                    ChromeNewTabPage(
                        isIncognito = activeTab.isIncognito,
                        isGoogleSignedIn = isGoogleSignedIn,
                        isBatteryUnrestricted = isBatteryUnrestricted,
                        searchEngine = settings.searchEngine,
                        speedDialItems = speedDialItems,
                        tabs = tabs,
                        recentDownloads = downloads,
                        installedWebApps = installedWebApps,
                        onSearchOrNavigate = { query -> webViewManager.loadUrlInActiveTab(query) },
                        onGoogleSignInClick = {
                            if (isGoogleSignedIn) {
                                webViewManager.openGoogleAccountManager()
                            } else {
                                webViewManager.openGoogleSignIn()
                            }
                        },
                        onOpenShield = {
                            onRefreshBatteryState()
                            showShieldDialog = true
                        },
                        onOpenDownloads = { showDownloadsSheet = true },
                        onSelectTab = { webViewManager.selectTab(it) },
                        onLaunchWebApp = { PwaShortcutHelper.launchWebApp(context, it) },
                        onCreateWebApp = { showCreatePwaDialog = true },
                        modifier = Modifier.fillMaxSize()
                    )
                }

                // 6. Toggleable 3-Dot Overflow Menu Overlay (clean bottom viewport, tap 3-dot to show/hide)
                ChromeOverflowMenuOverlay(
                    expanded = showOverflowMenu,
                    activeTab = activeTab,
                    isBookmarked = isActiveBookmarked,
                    isGoogleSignedIn = isGoogleSignedIn,
                    isBatteryUnrestricted = isBatteryUnrestricted,
                    activeDownloadCount = activeDownloadCount,
                    onDismiss = { showOverflowMenu = false },
                    onBack = { webViewManager.goBackInActiveTab() },
                    onForward = { webViewManager.goForwardInActiveTab() },
                    onToggleBookmark = {
                        browserViewModel.toggleBookmarkForActiveTab()
                        Toast.makeText(
                            context,
                            if (isActiveBookmarked) "Removed bookmark" else "Bookmarked page",
                            Toast.LENGTH_SHORT
                        ).show()
                    },
                    onDownloadCurrentPage = {
                        val url = activeTab?.url ?: return@ChromeOverflowMenuOverlay
                        if (url != WebViewManager.NEW_TAB_URL) {
                            webViewManager.triggerDirectDownload(url)
                        } else {
                            Toast.makeText(
                                context,
                                "Open a webpage first to download",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    },
                    onSiteInfo = { showSiteInfoDialog = true },
                    onReload = { webViewManager.reloadOrStopActiveTab() },
                    onGoogleSignIn = {
                        if (isGoogleSignedIn) {
                            webViewManager.openGoogleAccountManager()
                        } else {
                            webViewManager.openGoogleSignIn()
                        }
                    },
                    onNewTab = { webViewManager.openNewTab(WebViewManager.NEW_TAB_URL, isIncognito = false) },
                    onNewIncognitoTab = { webViewManager.openNewTab(WebViewManager.NEW_TAB_URL, isIncognito = true) },
                    onOpenBookmarks = { showBookmarksSheet = true },
                    onOpenHistory = { showHistorySheet = true },
                    onOpenDownloads = { showDownloadsSheet = true },
                    onFindInPage = { webViewManager.showFindInPage() },
                    onShare = { shareUrl(context, activeTab?.url ?: WebViewManager.DEFAULT_HOME_URL) },
                    onCopyUrl = { copyUrlToClipboard(context, activeTab?.url ?: WebViewManager.DEFAULT_HOME_URL) },
                    onPrintPdf = { webViewManager.printActivePage() },
                    onToggleDesktop = { webViewManager.toggleDesktopModeForActiveTab() },
                    onAddToHomeOrPwa = { showCreatePwaDialog = true },
                    onOpenInstalledPwas = { showInstalledPwasSheet = true },
                    onOpenShield = {
                        onRefreshBatteryState()
                        showShieldDialog = true
                    },
                    onOpenSettings = { showSettingsSheet = true }
                )
            }
        }
    }

    // --- Modal Sheets & Dialogs ---

    if (showTabSwitcher) {
        TabGridSwitcherDialog(
            tabs = tabs,
            activeTabId = activeTabId,
            onSelectTab = { webViewManager.selectTab(it) },
            onCloseTab = { webViewManager.closeTab(it) },
            onAddNewTab = { webViewManager.openNewTab(WebViewManager.NEW_TAB_URL, isIncognito = false) },
            onAddIncognitoTab = { webViewManager.openNewTab(WebViewManager.NEW_TAB_URL, isIncognito = true) },
            onRestoreFiveStudioTabs = { webViewManager.resetToDefaultFiveTabs() },
            onDismiss = { showTabSwitcher = false }
        )
    }

    if (showDownloadsSheet) {
        DownloadsSheetDialog(
            downloads = downloads,
            onOpenFile = { DownloadHelper.openDownloadedFile(context, it, webViewManager.repository) },
            onExtractZip = { browserViewModel.extractDownloadedZip(context, it) },
            onPickPhoneZipToExtract = {
                try {
                    externalZipPickerLauncher.launch("application/zip")
                } catch (_: Exception) {
                    try {
                        externalZipPickerLauncher.launch("*/*")
                    } catch (_: Exception) {
                    }
                }
            },
            onOpenPhoneFileManager = { DownloadHelper.openSystemDownloadsFileManager(context) },
            onRetryDownload = { browserViewModel.retryDownload(context, it) },
            onShareFile = { DownloadHelper.shareDownloadedFile(context, it) },
            onDeleteDownload = { browserViewModel.deleteDownloadRecord(it) },
            onClearFinished = { browserViewModel.clearFinishedDownloads() },
            onDismiss = { showDownloadsSheet = false }
        )
    }

    val currentPendingDownload = pendingDownload
    if (currentPendingDownload != null) {
        DownloadConfirmDialog(
            request = currentPendingDownload,
            askBeforeDownload = settings.askBeforeDownload,
            onToggleAskBeforeDownload = { browserViewModel.updateAskBeforeDownload(it) },
            onPickCustomFolder = onPickDownloadFolder,
            onConfirm = { customName, destination ->
                webViewManager.confirmPendingDownload(customName, destination)
            },
            onDismiss = { webViewManager.dismissPendingDownload() }
        )
    }

    if (showBookmarksSheet) {
        BookmarksSheetDialog(
            bookmarks = bookmarks,
            currentUrl = activeTab?.url,
            currentTitle = activeTab?.pageTitle,
            onOpenUrl = { webViewManager.loadUrlInActiveTab(it) },
            onAddCurrentPage = {
                val url = activeTab?.url ?: return@BookmarksSheetDialog
                browserViewModel.addBookmark(activeTab.pageTitle, url)
            },
            onEditBookmark = { id, title, url, isSpeedDial ->
                browserViewModel.updateBookmark(id, title, url, isSpeedDial)
            },
            onToggleSpeedDial = { bookmark ->
                browserViewModel.toggleBookmarkSpeedDial(bookmark)
            },
            onDeleteBookmark = { browserViewModel.deleteBookmark(it) },
            onDismiss = { showBookmarksSheet = false }
        )
    }

    if (showHistorySheet) {
        HistorySheetDialog(
            history = history,
            onOpenUrl = { webViewManager.loadUrlInActiveTab(it) },
            onDeleteItem = { browserViewModel.deleteHistoryItem(it) },
            onClearBrowsingData = { h, c, ck -> webViewManager.clearBrowsingData(h, c, ck) },
            onDismiss = { showHistorySheet = false }
        )
    }

    if (showSiteInfoDialog && activeTab != null) {
        SiteInfoDialog(
            activeTab = activeTab,
            permissionsStatus = permissionsStatus,
            onRequestAllPermissions = onRequestAllPermissions,
            onToggleDesktop = { webViewManager.toggleDesktopModeForActiveTab() },
            onClearCookies = { webViewManager.clearAllCacheAndCookies() },
            onDismiss = { showSiteInfoDialog = false }
        )
    }

    val currentContextTarget = contextMenuTarget
    if (currentContextTarget != null) {
        WebContextMenuDialog(
            target = currentContextTarget,
            onOpenNewTab = { url -> webViewManager.openNewTab(url, isIncognito = false) },
            onOpenIncognitoTab = { url -> webViewManager.openNewTab(url, isIncognito = true) },
            onDownload = { url -> webViewManager.triggerDirectDownload(url) },
            onCopyLink = { url -> copyUrlToClipboard(context, url) },
            onShareLink = { url -> shareUrl(context, url) },
            onDismiss = { webViewManager.dismissContextMenu() }
        )
    }

    if (showSettingsSheet) {
        SettingsSheetDialog(
            settings = settings,
            isGoogleSignedIn = isGoogleSignedIn,
            isBatteryUnrestricted = isBatteryUnrestricted,
            permissionsStatus = permissionsStatus,
            onRequestAllPermissions = onRequestAllPermissions,
            onSelectSearchEngine = { browserViewModel.updateSearchEngine(it) },
            onSelectThemeMode = { browserViewModel.updateThemeMode(it) },
            onSelectHomepageMode = { browserViewModel.updateHomepageMode(it) },
            onSelectFrameRateMode = { browserViewModel.updateFrameRateMode(it) },
            onToggleAskBeforeDownload = { browserViewModel.updateAskBeforeDownload(it) },
            onSelectDownloadPreset = { preset ->
                browserViewModel.updateDownloadDestination(preset.name)
            },
            onPickCustomDownloadFolder = onPickDownloadFolder,
            onToggleKeepPwasAlive = { browserViewModel.updateKeepPwasAliveInRam(it) },
            onToggleShowTabStrip = { browserViewModel.updateShowTabStrip(it) },
            onToggleAdBlock = { browserViewModel.updateAdBlockEnabled(it) },
            onToggleJavaScript = { browserViewModel.updateJavaScriptEnabled(it) },
            onToggleDarkWebPages = { browserViewModel.updateDarkWebPages(it) },
            onUpdateTextZoom = { browserViewModel.updateTextZoomPercent(it) },
            onGoogleSignIn = { webViewManager.openGoogleSignIn() },
            onGoogleManage = { webViewManager.openGoogleAccountManager() },
            onGoogleSignOut = { webViewManager.signOutGoogleAccounts() },
            onOpenShieldDialog = {
                onRefreshBatteryState()
                showShieldDialog = true
            },
            onDismiss = { showSettingsSheet = false }
        )
    }

    val currentPopup = oauthPopupSession
    if (currentPopup != null) {
        OAuthPopupModalDialog(
            session = currentPopup,
            onDismiss = { webViewManager.closeOAuthPopup() }
        )
    }

    if (showShieldDialog) {
        BatteryShieldDialog(
            isBatteryUnrestricted = isBatteryUnrestricted,
            shieldState = shieldServiceState,
            poolStats = pwaPoolStats,
            onRefreshBatteryStatus = onRefreshBatteryState,
            onDismiss = {
                onRefreshBatteryState()
                showShieldDialog = false
            }
        )
    }

    if (showCreatePwaDialog) {
        CreateShortcutOrPwaDialog(
            initialUrl = activeTab?.url ?: WebViewManager.DEFAULT_HOME_URL,
            initialTitle = activeTab?.pageTitle ?: "Google AI Studio",
            favicon = activeTab?.favicon,
            existingApps = installedWebApps,
            onConfirmCreate = { name, url, isPwa, isolated, colorHex, badgeTag, launchNow ->
                browserViewModel.createInstalledWebApp(
                    context = context,
                    name = name,
                    url = url,
                    isStandalonePwa = isPwa,
                    isolatedProfile = isolated,
                    badgeColorHex = colorHex,
                    badgeTag = badgeTag,
                    favicon = activeTab?.favicon,
                    launchImmediately = launchNow
                )
            },
            onDismiss = { showCreatePwaDialog = false }
        )
    }

    if (showInstalledPwasSheet) {
        InstalledWebAppsSheetDialog(
            webApps = installedWebApps,
            poolStats = pwaPoolStats,
            onLaunchApp = { PwaShortcutHelper.launchWebApp(context, it) },
            onRepinApp = { app ->
                showInstalledPwasSheet = false
                val ok = PwaShortcutHelper.pinToHomeScreen(context, app, activeTab?.favicon)
                Toast.makeText(
                    context,
                    if (ok) "Adding \"${app.name}\" to Home Screen" else "Saved shortcut for \"${app.name}\"",
                    Toast.LENGTH_SHORT
                ).show()
            },
            onHibernateApp = { app ->
                browserViewModel.hibernatePwaSession(context, app.pwaId)
                Toast.makeText(context, "Freed RAM for \"${app.name}\"", Toast.LENGTH_SHORT).show()
            },
            onDeleteApp = { browserViewModel.deleteInstalledWebApp(it) },
            onCreateNew = { showCreatePwaDialog = true },
            onDismiss = { showInstalledPwasSheet = false }
        )
    }
}

@Composable
private fun PersistentWebViewViewport(
    webViewManager: WebViewManager,
    modifier: Modifier = Modifier
) {
    AndroidView(
        factory = { ctx ->
            FrameLayout(ctx).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                val container = webViewManager.persistentContainer
                (container.parent as? ViewGroup)?.removeView(container)
                addView(
                    container,
                    FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                )
            }
        },
        update = { wrapper ->
            val container = webViewManager.persistentContainer
            if (container.parent !== wrapper) {
                (container.parent as? ViewGroup)?.removeView(container)
                wrapper.addView(
                    container,
                    FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                )
            }
        },
        modifier = modifier.testTag("webview_viewport")
    )
}

private fun copyUrlToClipboard(context: Context, url: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
    val clip = ClipData.newPlainText("Flowra URL", url)
    clipboard?.setPrimaryClip(clip)
    Toast.makeText(context, "Copied URL to clipboard", Toast.LENGTH_SHORT).show()
}

private fun shareUrl(context: Context, url: String) {
    try {
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, url)
        }
        val shareIntent = Intent.createChooser(sendIntent, "Share Tab URL")
        context.startActivity(shareIntent)
    } catch (_: Exception) {
    }
}
