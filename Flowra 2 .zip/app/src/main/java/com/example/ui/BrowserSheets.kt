package com.example.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.InsertDriveFile
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.DesktopWindows
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.BrowserTabModel
import com.example.DevicePermissionsStatus
import com.example.DownloadDestination
import com.example.DownloadFolderPreset
import com.example.DownloadHelper
import com.example.OAuthPopupSession
import com.example.PendingDownloadRequest
import com.example.R
import com.example.WebContextMenuTarget
import com.example.WebViewManager
import com.example.data.BookmarkEntity
import com.example.data.DownloadEntity
import com.example.data.DownloadStatus
import com.example.data.HistoryEntity
import com.example.ui.theme.ChromeAmberWarn
import com.example.ui.theme.ChromeCyanAccent
import com.example.ui.theme.ChromeElectricBlue
import com.example.ui.theme.ChromeEmeraldShield
import com.example.ui.theme.ChromeIncognitoBg
import com.example.ui.theme.ChromeIncognitoSurface
import java.text.DateFormat
import java.util.Date

@Composable
fun TabGridSwitcherDialog(
    tabs: List<BrowserTabModel>,
    activeTabId: Int,
    onSelectTab: (Int) -> Unit,
    onCloseTab: (Int) -> Unit,
    onAddNewTab: () -> Unit,
    onAddIncognitoTab: () -> Unit,
    onRestoreFiveStudioTabs: () -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            color = MaterialTheme.colorScheme.background,
            modifier = Modifier.fillMaxSize()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(top = 12.dp)
            ) {
                // Header Row
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedButton(
                            onClick = {
                                onAddNewTab()
                                onDismiss()
                            },
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("New tab")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        OutlinedButton(
                            onClick = {
                                onAddIncognitoTab()
                                onDismiss()
                            },
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.VisibilityOff, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Incognito")
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = {
                            onRestoreFiveStudioTabs()
                            onDismiss()
                        }) {
                            Icon(
                                imageVector = Icons.Default.RestartAlt,
                                contentDescription = "Restore 5 AI Studio tabs",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Close, contentDescription = "Close tab switcher")
                        }
                    }
                }

                Text(
                    text = "${tabs.size} open tabs (all active in background)",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                )

                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 160.dp),
                    contentPadding = PaddingValues(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    items(tabs, key = { it.id }) { tab ->
                        val isSelected = tab.id == activeTabId
                        val cardBg = if (tab.isIncognito) ChromeIncognitoSurface else MaterialTheme.colorScheme.surfaceVariant
                        val borderColor = when {
                            isSelected -> MaterialTheme.colorScheme.primary
                            else -> MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
                        }

                        Card(
                            colors = CardDefaults.cardColors(containerColor = cardBg),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(200.dp)
                                .border(
                                    width = if (isSelected) 2.5.dp else 1.dp,
                                    color = borderColor,
                                    shape = RoundedCornerShape(16.dp)
                                )
                                .clip(RoundedCornerShape(16.dp))
                                .clickable {
                                    onSelectTab(tab.id)
                                    onDismiss()
                                }
                        ) {
                            Column(modifier = Modifier.fillMaxSize()) {
                                // Tab Header
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(start = 10.dp, end = 4.dp, top = 4.dp, bottom = 4.dp)
                                ) {
                                    val fav = tab.favicon
                                    if (fav != null) {
                                        Image(
                                            bitmap = fav.asImageBitmap(),
                                            contentDescription = null,
                                            modifier = Modifier
                                                .size(16.dp)
                                                .clip(RoundedCornerShape(4.dp))
                                        )
                                    } else {
                                        Icon(
                                            imageVector = if (tab.isIncognito) Icons.Default.VisibilityOff else Icons.Default.Public,
                                            contentDescription = null,
                                            tint = if (tab.isIncognito) Color.White else MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = tab.pageTitle,
                                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                                        color = if (tab.isIncognito) Color.White else MaterialTheme.colorScheme.onSurface,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    IconButton(
                                        onClick = { onCloseTab(tab.id) },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Close,
                                            contentDescription = "Close tab",
                                            tint = if (tab.isIncognito) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }

                                // Thumbnail Preview Area
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxWidth()
                                        .padding(horizontal = 6.dp, vertical = 4.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (tab.isIncognito) ChromeIncognitoBg else MaterialTheme.colorScheme.surface)
                                ) {
                                    val thumb = tab.thumbnail
                                    if (thumb != null && tab.url != WebViewManager.NEW_TAB_URL) {
                                        Image(
                                            bitmap = thumb.asImageBitmap(),
                                            contentDescription = null,
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                    } else {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Icon(
                                                imageVector = if (tab.isIncognito) Icons.Default.VisibilityOff else Icons.Default.Public,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                                                modifier = Modifier.size(32.dp)
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = if (tab.url == WebViewManager.NEW_TAB_URL) "Start Page" else tab.slotTitle,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DownloadsSheetDialog(
    downloads: List<DownloadEntity>,
    onOpenFile: (DownloadEntity) -> Unit,
    onExtractZip: (DownloadEntity) -> Unit = {},
    onPickPhoneZipToExtract: (() -> Unit)? = null,
    onOpenPhoneFileManager: (() -> Unit)? = null,
    onRetryDownload: (DownloadEntity) -> Unit = {},
    onShareFile: (DownloadEntity) -> Unit,
    onDeleteDownload: (Long) -> Unit,
    onClearFinished: () -> Unit,
    onDismiss: () -> Unit
) {
    var filterMode by remember { mutableStateOf("All") }
    var searchQuery by remember { mutableStateOf("") }

    val filtered = remember(downloads, filterMode, searchQuery) {
        downloads.filter { item ->
            val matchesFilter = when (filterMode) {
                "Active" -> item.status == DownloadStatus.RUNNING || item.status == DownloadStatus.PENDING || item.status == DownloadStatus.PAUSED
                "Completed" -> item.status == DownloadStatus.SUCCESSFUL
                else -> true
            }
            val matchesQuery = searchQuery.isBlank() ||
                item.fileName.contains(searchQuery, ignoreCase = true)
            matchesFilter && matchesQuery
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            color = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.88f)
                .widthIn(max = 600.dp)
        ) {
            Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Download,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Downloads",
                            style = MaterialTheme.typography.titleLarge
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (downloads.any { it.status == DownloadStatus.SUCCESSFUL || it.status == DownloadStatus.FAILED }) {
                            TextButton(onClick = onClearFinished) {
                                Text("Clear")
                            }
                        }
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Close, contentDescription = "Close downloads")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search downloaded files") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.horizontalScroll(rememberScrollState())
                ) {
                    listOf("All", "Active", "Completed").forEach { label ->
                        FilterChip(
                            selected = filterMode == label,
                            onClick = { filterMode = label },
                            label = { Text(label) }
                        )
                    }
                    if (onOpenPhoneFileManager != null) {
                        OutlinedButton(
                            onClick = onOpenPhoneFileManager,
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("open_phone_file_manager_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.FolderOpen,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Open File Manager")
                        }
                    }
                    if (onPickPhoneZipToExtract != null) {
                        OutlinedButton(
                            onClick = onPickPhoneZipToExtract,
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("decompress_phone_zip_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.FolderZip,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Decompress Phone .ZIP / APK")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                if (filtered.isEmpty()) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.weight(1f).fillMaxWidth()
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.Download,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                                modifier = Modifier.size(56.dp)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "No downloads yet",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "Files, images, PDFs, and AI Studio ZIP/APK exports appear here.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.weight(1f).fillMaxWidth()
                    ) {
                        items(filtered, key = { it.id }) { item ->
                            DownloadItemCard(
                                item = item,
                                onOpen = { onOpenFile(item) },
                                onExtractZip = { onExtractZip(item) },
                                onRetry = { onRetryDownload(item) },
                                onShare = { onShareFile(item) },
                                onDelete = { onDeleteDownload(item.id) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DownloadItemCard(
    item: DownloadEntity,
    onOpen: () -> Unit,
    onExtractZip: () -> Unit,
    onRetry: () -> Unit,
    onShare: () -> Unit,
    onDelete: () -> Unit
) {
    val isZipFile = remember(item.fileName, item.mimeType) {
        item.fileName.endsWith(".zip", ignoreCase = true) ||
            item.mimeType.contains("zip", ignoreCase = true)
    }
    val fileIcon = remember(item.mimeType, item.fileName) {
        val m = item.mimeType.lowercase()
        val n = item.fileName.lowercase()
        when {
            m.startsWith("image/") || n.endsWith(".png") || n.endsWith(".jpg") -> Icons.Default.Image
            m.startsWith("video/") || n.endsWith(".mp4") -> Icons.Default.VideoFile
            m.startsWith("audio/") || n.endsWith(".mp3") || n.endsWith(".wav") -> Icons.Default.AudioFile
            m.contains("pdf") || m.startsWith("text/") || n.endsWith(".pdf") -> Icons.Default.Description
            m.contains("zip") || n.endsWith(".zip") || n.endsWith(".apk") -> Icons.Default.FolderZip
            else -> Icons.AutoMirrored.Filled.InsertDriveFile
        }
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = item.status == DownloadStatus.SUCCESSFUL, onClick = onOpen)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Icon(
                        imageVector = fileIcon,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = item.fileName,
                        style = MaterialTheme.typography.titleSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    val folderTag = item.saveFolderLabel.ifBlank { "/Downloads" }
                    val statusSubtext = when (item.status) {
                        DownloadStatus.SUCCESSFUL -> "${DownloadHelper.formatBytes(item.totalBytes)} • Saved in File Manager ($folderTag)"
                        DownloadStatus.FAILED -> "Failed • Tap retry or delete"
                        DownloadStatus.PAUSED -> "Paused • ${DownloadHelper.formatBytes(item.downloadedBytes)}"
                        else -> {
                            val totalStr = if (item.totalBytes > 0) " / ${DownloadHelper.formatBytes(item.totalBytes)}" else ""
                            "Downloading ${DownloadHelper.formatBytes(item.downloadedBytes)}$totalStr -> $folderTag"
                        }
                    }
                    Text(
                        text = statusSubtext,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (item.status == DownloadStatus.FAILED) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                if (item.status == DownloadStatus.SUCCESSFUL && isZipFile) {
                    TextButton(
                        onClick = onExtractZip,
                        modifier = Modifier.testTag("extract_zip_button_${item.id}")
                    ) {
                        Text("Extract", fontWeight = FontWeight.Bold)
                    }
                }
                if (item.status != DownloadStatus.SUCCESSFUL &&
                    (item.url.startsWith("http://", ignoreCase = true) || item.url.startsWith("https://", ignoreCase = true))
                ) {
                    IconButton(
                        onClick = onRetry,
                        modifier = Modifier.testTag("retry_download_button_${item.id}")
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Retry download")
                    }
                }
                if (item.status == DownloadStatus.SUCCESSFUL) {
                    IconButton(onClick = onShare) {
                        Icon(Icons.Default.Share, contentDescription = "Share file")
                    }
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, contentDescription = "Remove download")
                }
            }

            if (item.status == DownloadStatus.RUNNING || item.status == DownloadStatus.PENDING) {
                Spacer(modifier = Modifier.height(8.dp))
                if (item.totalBytes > 0) {
                    val pct = (item.downloadedBytes.toFloat() / item.totalBytes.toFloat()).coerceIn(0.02f, 1f)
                    LinearProgressIndicator(
                        progress = { pct },
                        modifier = Modifier.fillMaxWidth().height(4.dp)
                    )
                } else {
                    LinearProgressIndicator(
                        modifier = Modifier.fillMaxWidth().height(4.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun DownloadConfirmDialog(
    request: PendingDownloadRequest,
    askBeforeDownload: Boolean,
    onToggleAskBeforeDownload: (Boolean) -> Unit,
    onPickCustomFolder: (((uriString: String, label: String) -> Unit) -> Unit)? = null,
    onConfirm: (fileName: String, destination: DownloadDestination) -> Unit,
    onDismiss: () -> Unit
) {
    var fileName by remember(request) { mutableStateOf(request.suggestedFileName) }
    var destination by remember(request) { mutableStateOf(request.defaultDestination) }
    var showFolderPickerOptions by remember { mutableStateOf(false) }

    val fileIcon = remember(request.mimeType, fileName) {
        val m = request.mimeType.lowercase()
        val n = fileName.lowercase()
        when {
            m.startsWith("image/") || n.endsWith(".png") || n.endsWith(".jpg") || n.endsWith(".webp") -> Icons.Default.Image
            m.startsWith("video/") || n.endsWith(".mp4") || n.endsWith(".mkv") -> Icons.Default.VideoFile
            m.startsWith("audio/") || n.endsWith(".mp3") || n.endsWith(".wav") -> Icons.Default.AudioFile
            m.contains("pdf") || m.startsWith("text/") || n.endsWith(".pdf") || n.endsWith(".json") -> Icons.Default.Description
            m.contains("zip") || n.endsWith(".zip") || n.endsWith(".apk") || n.endsWith(".7z") -> Icons.Default.FolderZip
            else -> Icons.AutoMirrored.Filled.InsertDriveFile
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(22.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp,
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .widthIn(max = 520.dp)
        ) {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(42.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.primaryContainer)
                        ) {
                            Icon(
                                imageVector = fileIcon,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Download file",
                                style = MaterialTheme.typography.titleLarge
                            )
                            val sizeInfo = if (request.contentLength > 0) {
                                DownloadHelper.formatBytes(request.contentLength)
                            } else {
                                "Stream / Auto size"
                            }
                            Text(
                                text = "${request.mimeType} • $sizeInfo",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Cancel download")
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Editable File Name
                OutlinedTextField(
                    value = fileName,
                    onValueChange = { fileName = it },
                    label = { Text("File name (editable)") },
                    trailingIcon = {
                        if (fileName.isNotEmpty()) {
                            IconButton(onClick = { fileName = "" }) {
                                Icon(Icons.Default.Close, contentDescription = "Clear file name", modifier = Modifier.size(18.dp))
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("download_filename_input")
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Brave-Style Destination Folder Selector
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { showFolderPickerOptions = !showFolderPickerOptions }
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Icon(
                                    imageVector = Icons.Default.Folder,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Save to folder",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = destination.displayLabel(),
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                            TextButton(
                                onClick = { showFolderPickerOptions = !showFolderPickerOptions },
                                modifier = Modifier.testTag("download_change_folder_button")
                            ) {
                                Text(if (showFolderPickerOptions) "Hide" else "Change")
                            }
                        }

                        if (showFolderPickerOptions) {
                            Spacer(modifier = Modifier.height(10.dp))
                            val presets = listOf(
                                DownloadFolderPreset.DOWNLOADS,
                                DownloadFolderPreset.STUDIO_DOWNLOADS,
                                DownloadFolderPreset.DOCUMENTS,
                                DownloadFolderPreset.PICTURES,
                                DownloadFolderPreset.MUSIC,
                                DownloadFolderPreset.MOVIES
                            )
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState())
                            ) {
                                presets.forEach { preset ->
                                    FilterChip(
                                        selected = destination.preset == preset,
                                        onClick = {
                                            destination = destination.copy(preset = preset)
                                        },
                                        label = { Text(preset.displayName) }
                                    )
                                }
                            }
                            if (onPickCustomFolder != null) {
                                Spacer(modifier = Modifier.height(8.dp))
                                OutlinedButton(
                                    onClick = {
                                        onPickCustomFolder { treeUri, label ->
                                            destination = DownloadDestination(
                                                preset = DownloadFolderPreset.CUSTOM_SAF,
                                                customTreeUri = treeUri,
                                                customFolderLabel = label
                                            )
                                        }
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("download_choose_custom_folder_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.CreateNewFolder,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Choose any phone folder (SAF)...")
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { onToggleAskBeforeDownload(!askBeforeDownload) }
                ) {
                    Checkbox(
                        checked = askBeforeDownload,
                        onCheckedChange = { checked -> onToggleAskBeforeDownload(checked) }
                    )
                    Text(
                        text = "Always ask file name & folder before downloading",
                        style = MaterialTheme.typography.bodySmall
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))
                Row(
                    horizontalArrangement = Arrangement.End,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            onConfirm(
                                fileName.ifBlank { request.suggestedFileName },
                                destination
                            )
                        },
                        modifier = Modifier.testTag("confirm_download_button")
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Download")
                    }
                }
            }
        }
    }
}

@Composable
fun BookmarksSheetDialog(
    bookmarks: List<BookmarkEntity>,
    currentUrl: String?,
    currentTitle: String?,
    onOpenUrl: (String) -> Unit,
    onAddCurrentPage: () -> Unit,
    onEditBookmark: ((id: Long, title: String, url: String, isSpeedDial: Boolean) -> Unit)? = null,
    onToggleSpeedDial: ((BookmarkEntity) -> Unit)? = null,
    onDeleteBookmark: (Long) -> Unit,
    onDismiss: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    var editingBookmark by remember { mutableStateOf<BookmarkEntity?>(null) }

    val filtered = remember(bookmarks, query) {
        if (query.isBlank()) bookmarks
        else bookmarks.filter {
            it.title.contains(query, ignoreCase = true) || it.url.contains(query, ignoreCase = true)
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            color = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.86f)
                .widthIn(max = 600.dp)
        ) {
            Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Bookmark, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text("Bookmarks", style = MaterialTheme.typography.titleLarge)
                            Text(
                                text = "Offline Room SQLite • Instant Local Access",
                                style = MaterialTheme.typography.labelSmall,
                                color = ChromeEmeraldShield
                            )
                        }
                    }
                    Row {
                        if (!currentUrl.isNullOrBlank() && currentUrl != WebViewManager.NEW_TAB_URL) {
                            TextButton(onClick = onAddCurrentPage) {
                                Text("Save Page")
                            }
                        }
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Close, contentDescription = "Close bookmarks")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("Search bookmarks (${bookmarks.size} saved offline)") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(10.dp))

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.weight(1f).fillMaxWidth()
                ) {
                    items(filtered, key = { it.id }) { bm ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))
                                .clickable {
                                    onOpenUrl(bm.url)
                                    onDismiss()
                                }
                                .padding(horizontal = 12.dp, vertical = 10.dp)
                        ) {
                            Icon(Icons.Default.Public, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(bm.title, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(bm.url, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            if (onToggleSpeedDial != null) {
                                IconButton(onClick = { onToggleSpeedDial(bm) }) {
                                    Icon(
                                        imageVector = Icons.Default.PushPin,
                                        contentDescription = "Pin to Speed Dial",
                                        tint = if (bm.isSpeedDial) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                                    )
                                }
                            }
                            if (onEditBookmark != null) {
                                IconButton(onClick = { editingBookmark = bm }) {
                                    Icon(Icons.Default.Edit, contentDescription = "Edit bookmark")
                                }
                            }
                            IconButton(onClick = { onDeleteBookmark(bm.id) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete bookmark")
                            }
                        }
                    }
                }
            }
        }
    }

    val targetEdit = editingBookmark
    if (targetEdit != null && onEditBookmark != null) {
        var titleInput by remember(targetEdit) { mutableStateOf(targetEdit.title) }
        var urlInput by remember(targetEdit) { mutableStateOf(targetEdit.url) }
        var speedDial by remember(targetEdit) { mutableStateOf(targetEdit.isSpeedDial) }

        Dialog(onDismissRequest = { editingBookmark = null }) {
            Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surface) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text("Edit Bookmark", style = MaterialTheme.typography.titleLarge)
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = titleInput,
                        onValueChange = { titleInput = it },
                        label = { Text("Title") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = urlInput,
                        onValueChange = { urlInput = it },
                        label = { Text("URL") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth().clickable { speedDial = !speedDial }
                    ) {
                        Checkbox(checked = speedDial, onCheckedChange = { speedDial = it })
                        Text("Pin to Start Page Speed Dial")
                    }
                    Spacer(modifier = Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                        TextButton(onClick = { editingBookmark = null }) { Text("Cancel") }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(onClick = {
                            onEditBookmark(targetEdit.id, titleInput, urlInput, speedDial)
                            editingBookmark = null
                        }) {
                            Text("Save")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HistorySheetDialog(
    history: List<HistoryEntity>,
    onOpenUrl: (String) -> Unit,
    onDeleteItem: (Long) -> Unit,
    onClearBrowsingData: (history: Boolean, cache: Boolean, cookies: Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    var showClearDialog by remember { mutableStateOf(false) }

    val filtered = remember(history, query) {
        if (query.isBlank()) history
        else history.filter {
            it.title.contains(query, ignoreCase = true) || it.url.contains(query, ignoreCase = true)
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            color = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.86f)
                .widthIn(max = 600.dp)
        ) {
            Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.History, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("History", style = MaterialTheme.typography.titleLarge)
                    }
                    Row {
                        TextButton(onClick = { showClearDialog = true }) {
                            Text("Clear data...")
                        }
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Close, contentDescription = "Close history")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("Search history") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(10.dp))

                if (filtered.isEmpty()) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.weight(1f).fillMaxWidth()
                    ) {
                        Text(
                            text = "No browsing history recorded",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.weight(1f).fillMaxWidth()
                    ) {
                        items(filtered, key = { it.id }) { entry ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))
                                    .clickable {
                                        onOpenUrl(entry.url)
                                        onDismiss()
                                    }
                                    .padding(horizontal = 12.dp, vertical = 10.dp)
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(entry.title, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(entry.url, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(
                                        text = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(entry.visitedAt)),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                    )
                                }
                                IconButton(onClick = { onDeleteItem(entry.id) }) {
                                    Icon(Icons.Default.Close, contentDescription = "Remove history item")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showClearDialog) {
        ClearBrowsingDataDialog(
            onConfirm = { h, c, ck ->
                onClearBrowsingData(h, c, ck)
                showClearDialog = false
            },
            onDismiss = { showClearDialog = false }
        )
    }
}

@Composable
private fun ClearBrowsingDataDialog(
    onConfirm: (history: Boolean, cache: Boolean, cookies: Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    var clearHist by remember { mutableStateOf(true) }
    var clearCache by remember { mutableStateOf(true) }
    var clearCookies by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.DeleteSweep, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Clear browsing data", style = MaterialTheme.typography.titleLarge)
                }
                Spacer(modifier = Modifier.height(12.dp))

                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().clickable { clearHist = !clearHist }) {
                    Checkbox(checked = clearHist, onCheckedChange = { clearHist = it })
                    Text("Browsing history")
                }
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().clickable { clearCache = !clearCache }) {
                    Checkbox(checked = clearCache, onCheckedChange = { clearCache = it })
                    Text("Cached images and files")
                }
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().clickable { clearCookies = !clearCookies }) {
                    Checkbox(checked = clearCookies, onCheckedChange = { clearCookies = it })
                    Column {
                        Text("Cookies and site data")
                        Text("Signs you out of most websites", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(onClick = { onConfirm(clearHist, clearCache, clearCookies) }) {
                        Text("Clear data")
                    }
                }
            }
        }
    }
}

@Composable
fun SiteInfoDialog(
    activeTab: BrowserTabModel,
    permissionsStatus: DevicePermissionsStatus = DevicePermissionsStatus(),
    onRequestAllPermissions: () -> Unit = {},
    onToggleDesktop: () -> Unit,
    onClearCookies: () -> Unit,
    onDismiss: () -> Unit
) {
    val host = remember(activeTab.url) {
        try { Uri.parse(activeTab.url).host ?: activeTab.url } catch (_: Exception) { activeTab.url }
    }
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (activeTab.isSslSecure) Icons.Default.Lock else Icons.Default.Warning,
                        contentDescription = null,
                        tint = if (activeTab.isSslSecure) ChromeEmeraldShield else ChromeAmberWarn
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(host, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            text = if (activeTab.isSslSecure) "Connection is secure (HTTPS)" else "Connection is not secure (HTTP)",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (activeTab.isSslSecure) ChromeEmeraldShield else ChromeAmberWarn
                        )
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider()
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            onRequestAllPermissions()
                        }
                        .padding(vertical = 8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.FolderOpen, contentDescription = null, tint = ChromeEmeraldShield)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("File Manager, Camera, Mic & GPS")
                            Text(
                                text = "Phone File Manager, ZArchiver, Photos & Capture chooser active",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (permissionsStatus.allGranted) "ALL GRANTED" else "GRANT ALL",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = if (permissionsStatus.allGranted) ChromeEmeraldShield else MaterialTheme.colorScheme.primary
                    )
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth().clickable {
                        onToggleDesktop()
                        onDismiss()
                    }.padding(vertical = 8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.DesktopWindows, contentDescription = null)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("Desktop site mode")
                    }
                    Text(if (activeTab.isDesktopMode) "ON" else "OFF", color = MaterialTheme.colorScheme.primary)
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth().clickable {
                        onClearCookies()
                        onDismiss()
                    }.padding(vertical = 8.dp)
                ) {
                    Icon(Icons.Default.DeleteSweep, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text("Clear cookies & site storage", color = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
}

@Composable
fun WebContextMenuDialog(
    target: WebContextMenuTarget,
    onOpenNewTab: (String) -> Unit,
    onOpenIncognitoTab: (String) -> Unit,
    onDownload: (String) -> Unit,
    onCopyLink: (String) -> Unit,
    onShareLink: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val primaryUrl = target.linkUrl ?: target.imageUrl ?: return
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = primaryUrl,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider()

                if (target.linkUrl != null) {
                    ContextMenuActionRow("Open in new tab", Icons.AutoMirrored.Filled.OpenInNew) {
                        onOpenNewTab(target.linkUrl)
                        onDismiss()
                    }
                    ContextMenuActionRow("Open in Incognito tab", Icons.Default.VisibilityOff) {
                        onOpenIncognitoTab(target.linkUrl)
                        onDismiss()
                    }
                    ContextMenuActionRow("Copy link address", Icons.Default.ContentCopy) {
                        onCopyLink(target.linkUrl)
                        onDismiss()
                    }
                    ContextMenuActionRow("Download link", Icons.Default.Download) {
                        onDownload(target.linkUrl)
                        onDismiss()
                    }
                }
                if (target.imageUrl != null) {
                    ContextMenuActionRow("Download image", Icons.Default.Image) {
                        onDownload(target.imageUrl)
                        onDismiss()
                    }
                }
                ContextMenuActionRow("Share link", Icons.Default.Share) {
                    onShareLink(primaryUrl)
                    onDismiss()
                }
            }
        }
    }
}

@Composable
private fun ContextMenuActionRow(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp, horizontal = 6.dp)
    ) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(20.dp))
        Spacer(modifier = Modifier.width(12.dp))
        Text(label, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
fun OAuthPopupModalDialog(
    session: OAuthPopupSession,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = true,
            dismissOnClickOutside = false
        )
    ) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp,
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .fillMaxHeight(0.90f)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        tint = ChromeEmeraldShield,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = session.title,
                            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = session.url,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("close_oauth_popup_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = stringResource(R.string.cd_close_oauth)
                        )
                    }
                }

                if (session.isLoading) {
                    LinearProgressIndicator(
                        progress = { (session.progress / 100f).coerceIn(0.05f, 1f) },
                        color = ChromeCyanAccent,
                        modifier = Modifier.fillMaxWidth().height(3.dp)
                    )
                }

                AndroidView(
                    factory = { ctx ->
                        FrameLayout(ctx).apply {
                            val popupView = session.popupWebView
                            (popupView.parent as? ViewGroup)?.removeView(popupView)
                            addView(
                                popupView,
                                FrameLayout.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                    ViewGroup.LayoutParams.MATCH_PARENT
                                )
                            )
                        }
                    },
                    modifier = Modifier.weight(1f).fillMaxWidth()
                )
            }
        }
    }
}
