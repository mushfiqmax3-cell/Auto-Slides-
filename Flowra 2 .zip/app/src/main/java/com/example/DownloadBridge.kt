package com.example

import android.Manifest
import android.app.DownloadManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.util.Base64
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.MimeTypeMap
import android.webkit.URLUtil
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.example.data.BrowserRepository
import com.example.data.DownloadEntity
import com.example.data.DownloadStatus
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class DownloadFolderPreset(
    val displayName: String,
    val relativeDisplayPath: String,
    val publicDirType: String,
    val subFolder: String? = null
) {
    DOWNLOADS("Downloads", "/Downloads", Environment.DIRECTORY_DOWNLOADS, null),
    STUDIO_DOWNLOADS("Downloads / Flowra", "/Downloads/Flowra", Environment.DIRECTORY_DOWNLOADS, "Flowra"),
    DOCUMENTS("Documents", "/Documents", Environment.DIRECTORY_DOCUMENTS, null),
    PICTURES("Pictures", "/Pictures", Environment.DIRECTORY_PICTURES, null),
    MUSIC("Music", "/Music", Environment.DIRECTORY_MUSIC, null),
    MOVIES("Movies", "/Movies", Environment.DIRECTORY_MOVIES, null),
    CUSTOM_SAF("Custom Folder", "Custom folder", Environment.DIRECTORY_DOWNLOADS, null);

    companion object {
        fun fromId(id: String?): DownloadFolderPreset {
            return entries.find { it.name == id } ?: DOWNLOADS
        }
    }
}

data class DownloadDestination(
    val preset: DownloadFolderPreset = DownloadFolderPreset.DOWNLOADS,
    val customTreeUri: String = "",
    val customFolderLabel: String = ""
) {
    fun displayLabel(): String {
        return if (preset == DownloadFolderPreset.CUSTOM_SAF && customFolderLabel.isNotBlank()) {
            customFolderLabel
        } else {
            preset.relativeDisplayPath
        }
    }
}

data class PendingDownloadRequest(
    val url: String,
    val userAgent: String,
    val contentDisposition: String,
    val mimeType: String,
    val contentLength: Long,
    val suggestedFileName: String,
    val defaultDestination: DownloadDestination = DownloadDestination(),
    val refererUrl: String = ""
)

private data class ActiveBlobTransfer(
    val transferId: String,
    val tempFile: File,
    val fileName: String,
    val mimeType: String,
    val destination: DownloadDestination,
    @Volatile var dbRowId: Long = -1L,
    @Volatile var bytesReceived: Long = 0L
)

class StudioDownloadBridge(
    private val context: Context,
    private val repository: BrowserRepository? = null,
    private val onBase64Saved: (
        fileName: String,
        url: String,
        mimeType: String,
        uriString: String,
        sizeBytes: Long,
        saveFolderLabel: String
    ) -> Unit
) {
    private val activeTransfers = ConcurrentHashMap<String, ActiveBlobTransfer>()
    private val cachedBlobNames = ConcurrentHashMap<String, String>()

    @JavascriptInterface
    fun registerBlobSuggestedName(blobUrl: String, downloadAttrName: String) {
        if (blobUrl.isNotBlank() && downloadAttrName.isNotBlank()) {
            cachedBlobNames[blobUrl] = downloadAttrName.trim()
        }
    }

    fun getRegisteredBlobName(blobUrl: String): String? = cachedBlobNames[blobUrl]

    @JavascriptInterface
    fun startBlobTransfer(
        transferId: String,
        fileName: String,
        mimeType: String,
        presetName: String,
        customTreeUri: String,
        customFolderLabel: String
    ) {
        try {
            val rawMime = mimeType.ifBlank { "application/octet-stream" }
            val safeName = sanitizeFileName(
                fileName.ifBlank { "download_${System.currentTimeMillis()}" },
                rawMime
            )
            val safeMime = resolveAccurateMimeType(safeName, rawMime)
            val dir = File(context.cacheDir, "blob_transfers").apply { mkdirs() }
            val tempFile = File(dir, "blob_${transferId.replace(Regex("[^a-zA-Z0-9_-]"), "")}.tmp")
            if (tempFile.exists()) tempFile.delete()
            val destination = DownloadDestination(
                preset = DownloadFolderPreset.fromId(presetName),
                customTreeUri = customTreeUri,
                customFolderLabel = customFolderLabel
            )
            val session = ActiveBlobTransfer(
                transferId = transferId,
                tempFile = tempFile,
                fileName = safeName,
                mimeType = safeMime,
                destination = destination
            )
            activeTransfers[transferId] = session
            val repo = repository
            if (repo != null) {
                CoroutineScope(Dispatchers.IO).launch {
                    try {
                        val rowId = repo.insertDownload(
                            DownloadEntity(
                                systemDownloadId = -1L,
                                fileName = safeName,
                                url = "blob:transfer/$transferId",
                                mimeType = safeMime,
                                status = DownloadStatus.RUNNING,
                                totalBytes = -1L,
                                downloadedBytes = 0L,
                                saveFolderLabel = destination.displayLabel()
                            )
                        )
                        session.dbRowId = rowId
                    } catch (_: Exception) {
                    }
                }
            }
        } catch (_: Exception) {
        }
    }

    @JavascriptInterface
    fun appendBlobChunk(transferId: String, base64Chunk: String) {
        val session = activeTransfers[transferId] ?: return
        try {
            val cleanBase64 = if (base64Chunk.contains("base64,")) {
                base64Chunk.substringAfter("base64,")
            } else {
                base64Chunk
            }
            if (cleanBase64.isEmpty()) return
            val bytes = Base64.decode(cleanBase64, Base64.DEFAULT)
            FileOutputStream(session.tempFile, true).use { out ->
                out.write(bytes)
            }
            session.bytesReceived += bytes.size
            val rowId = session.dbRowId
            val repo = repository
            if (rowId > 0L && repo != null) {
                val currentTotal = session.bytesReceived
                CoroutineScope(Dispatchers.IO).launch {
                    try {
                        repo.updateDownloadProgress(rowId, currentTotal)
                    } catch (_: Exception) {
                    }
                }
            }
        } catch (_: Exception) {
        }
    }

    @JavascriptInterface
    fun finishBlobTransfer(transferId: String, sourceUrl: String) {
        val session = activeTransfers.remove(transferId) ?: return
        CoroutineScope(Dispatchers.IO).launch {
            try {
                if (!session.tempFile.exists() || session.tempFile.length() == 0L) {
                    val rowId = session.dbRowId
                    if (rowId > 0L && repository != null) {
                        repository.deleteDownload(rowId)
                    }
                    return@launch
                }
                val rawBytes = session.tempFile.readBytes()
                session.tempFile.delete()
                finalizeAndSaveDownloadedBytes(
                    rawBytes = rawBytes,
                    safeName = session.fileName,
                    safeMime = session.mimeType,
                    sourceUrl = sourceUrl,
                    destination = session.destination,
                    existingRowId = session.dbRowId
                )
            } catch (e: Exception) {
                session.tempFile.delete()
                val rowId = session.dbRowId
                if (rowId > 0L && repository != null) {
                    repository.updateDownload(
                        DownloadEntity(
                            id = rowId,
                            systemDownloadId = -1L,
                            fileName = session.fileName,
                            url = sourceUrl,
                            mimeType = session.mimeType,
                            status = DownloadStatus.FAILED,
                            saveFolderLabel = session.destination.displayLabel()
                        )
                    )
                }
                withContext(Dispatchers.Main) {
                    Toast.makeText(context, "Download failed: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    @JavascriptInterface
    fun saveBase64Data(base64DataUrl: String, fileName: String, mimeType: String) {
        saveBase64DataToDestination(
            base64DataUrl = base64DataUrl,
            fileName = fileName,
            mimeType = mimeType,
            presetName = DownloadFolderPreset.DOWNLOADS.name,
            customTreeUri = "",
            customFolderLabel = ""
        )
    }

    @JavascriptInterface
    fun saveBase64DataToDestination(
        base64DataUrl: String,
        fileName: String,
        mimeType: String,
        presetName: String,
        customTreeUri: String,
        customFolderLabel: String
    ) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val rawMime = mimeType.ifBlank {
                    extractMimeFromDataUrl(base64DataUrl) ?: "application/octet-stream"
                }
                val safeName = sanitizeFileName(
                    fileName.ifBlank { "download_${System.currentTimeMillis()}" },
                    rawMime
                )
                val safeMime = resolveAccurateMimeType(safeName, rawMime)
                val base64Part = if (base64DataUrl.contains("base64,")) {
                    base64DataUrl.substringAfter("base64,", "")
                } else {
                    base64DataUrl
                }
                if (base64Part.isEmpty()) return@launch
                val rawBytes = Base64.decode(base64Part, Base64.DEFAULT)

                val destination = DownloadDestination(
                    preset = DownloadFolderPreset.fromId(presetName),
                    customTreeUri = customTreeUri,
                    customFolderLabel = customFolderLabel
                )
                finalizeAndSaveDownloadedBytes(
                    rawBytes = rawBytes,
                    safeName = safeName,
                    safeMime = safeMime,
                    sourceUrl = base64DataUrl.take(96),
                    destination = destination,
                    existingRowId = -1L
                )
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(context, "Download failed: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private suspend fun finalizeAndSaveDownloadedBytes(
        rawBytes: ByteArray,
        safeName: String,
        safeMime: String,
        sourceUrl: String,
        destination: DownloadDestination,
        existingRowId: Long = -1L
    ) {
        val isZip = safeName.endsWith(".zip", ignoreCase = true) ||
            safeMime.contains("zip", ignoreCase = true)
        val finalBytes = if (isZip) {
            ZipArchiveHelper.normalizeZipBytes(rawBytes)
        } else {
            rawBytes
        }

        val resolvedMime = resolveAccurateMimeType(safeName, safeMime)
        val savedUri = writeBytesToDestination(context, safeName, resolvedMime, finalBytes, destination)
        val folderLabel = destination.displayLabel()
        if (savedUri != null) {
            val repo = repository
            if (existingRowId > 0L && repo != null) {
                repo.updateDownload(
                    DownloadEntity(
                        id = existingRowId,
                        systemDownloadId = -1L,
                        fileName = safeName,
                        url = sourceUrl,
                        mimeType = resolvedMime,
                        localUri = savedUri.toString(),
                        status = DownloadStatus.SUCCESSFUL,
                        totalBytes = finalBytes.size.toLong(),
                        downloadedBytes = finalBytes.size.toLong(),
                        saveFolderLabel = folderLabel
                    )
                )
            } else {
                onBase64Saved(
                    safeName,
                    sourceUrl,
                    resolvedMime,
                    savedUri.toString(),
                    finalBytes.size.toLong(),
                    folderLabel
                )
            }

            DownloadHelper.postDownloadCompleteNotification(
                context = context,
                fileName = safeName,
                mimeType = resolvedMime,
                fileUri = savedUri,
                folderLabel = folderLabel
            )

            // If this .zip contains an .apk (like VoiceTypePro-Release-APK.zip -> app-debug.apk),
            // automatically extract the inner files directly into the same Download folder!
            var autoExtractedApkName: String? = null
            var simulatedApkWarning = false
            if (isZip) {
                val summary = ZipArchiveHelper.extractZipBytesToDestination(
                    context = context,
                    zipBytes = finalBytes,
                    destination = destination
                )
                simulatedApkWarning = summary.containsSimulatedApk
                for (extracted in summary.extractedFiles) {
                    onBase64Saved(
                        extracted.fileName,
                        "extracted://${safeName}/${extracted.fileName}",
                        extracted.mimeType,
                        extracted.savedUri.toString(),
                        extracted.sizeBytes,
                        folderLabel
                    )
                    if (extracted.fileName.endsWith(".apk", ignoreCase = true)) {
                        autoExtractedApkName = extracted.fileName
                    }
                }
            }

            withContext(Dispatchers.Main) {
                val msg = when {
                    simulatedApkWarning ->
                        "Saved & extracted $safeName in $folderLabel (Note: inner APK is a web demo placeholder, not a compiled binary)"
                    autoExtractedApkName != null ->
                        "Saved $safeName & auto-extracted $autoExtractedApkName to $folderLabel"
                    else ->
                        "Saved $safeName in Phone File Manager ($folderLabel)"
                }
                Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun extractMimeFromDataUrl(dataUrl: String): String? {
        if (!dataUrl.startsWith("data:")) return null
        val header = dataUrl.substringAfter("data:").substringBefore(";")
        return header.takeIf { it.contains("/") }
    }
}

fun sanitizeFileName(rawName: String, mimeType: String): String {
    val decoded = try {
        if (rawName.contains("%")) URLDecoder.decode(rawName, "UTF-8") else rawName
    } catch (_: Exception) {
        rawName
    }
    val clean = decoded
        .replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001F]"), "_")
        .trim()
        .trimStart('.')
        .ifBlank { "download_${System.currentTimeMillis()}" }

    val hasValidExt = clean.contains(".") && !clean.endsWith(".") &&
        clean.substringAfterLast('.').length in 1..8
    if (hasValidExt) return clean

    val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mimeType)
        ?: guessExtensionFromMime(mimeType)
    return if (!ext.isNullOrBlank()) "${clean.trimEnd('.')}.$ext" else clean
}

private fun guessExtensionFromMime(mimeType: String): String? {
    val m = mimeType.lowercase(Locale.US).substringBefore(";").trim()
    return when (m) {
        "image/jpeg", "image/jpg" -> "jpg"
        "image/png" -> "png"
        "image/webp" -> "webp"
        "image/gif" -> "gif"
        "image/svg+xml" -> "svg"
        "video/mp4" -> "mp4"
        "video/webm" -> "webm"
        "video/x-matroska" -> "mkv"
        "audio/mpeg", "audio/mp3" -> "mp3"
        "audio/wav", "audio/x-wav" -> "wav"
        "audio/ogg" -> "ogg"
        "audio/mp4", "audio/x-m4a" -> "m4a"
        "application/pdf" -> "pdf"
        "application/zip", "application/x-zip-compressed" -> "zip"
        "application/vnd.android.package-archive" -> "apk"
        "application/json" -> "json"
        "text/plain" -> "txt"
        "text/html" -> "html"
        "text/csv" -> "csv"
        else -> null
    }
}

fun resolveAccurateMimeType(fileName: String, rawMimeType: String?): String {
    val cleanMime = rawMimeType?.substringBefore(";")?.trim().orEmpty()
    val lowerName = fileName.lowercase(Locale.US)
    val ext = lowerName.substringAfterLast('.', "")
    val mimeFromExt = when (ext) {
        "jpg", "jpeg" -> "image/jpeg"
        "png" -> "image/png"
        "webp" -> "image/webp"
        "gif" -> "image/gif"
        "bmp" -> "image/bmp"
        "svg" -> "image/svg+xml"
        "mp4", "m4v" -> "video/mp4"
        "mkv" -> "video/x-matroska"
        "webm" -> "video/webm"
        "mov" -> "video/quicktime"
        "mp3" -> "audio/mpeg"
        "wav" -> "audio/wav"
        "m4a" -> "audio/mp4"
        "ogg", "oga" -> "audio/ogg"
        "flac" -> "audio/flac"
        "pdf" -> "application/pdf"
        "apk" -> "application/vnd.android.package-archive"
        "zip" -> "application/zip"
        "rar" -> "application/vnd.rar"
        "7z" -> "application/x-7z-compressed"
        "tar" -> "application/x-tar"
        "gz", "tgz" -> "application/gzip"
        "json" -> "application/json"
        "txt", "log", "md", "kt", "java", "py", "js", "ts", "css" -> "text/plain"
        "html", "htm" -> "text/html"
        "csv" -> "text/csv"
        "xml" -> "text/xml"
        "doc" -> "application/msword"
        "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        "xls" -> "application/vnd.ms-excel"
        "xlsx" -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        "ppt" -> "application/vnd.ms-powerpoint"
        "pptx" -> "application/vnd.openxmlformats-officedocument.presentationml.presentation"
        else -> if (ext.isNotBlank()) MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) else null
    }
    if (!mimeFromExt.isNullOrBlank()) {
        return mimeFromExt
    }
    if (cleanMime.isNotBlank() &&
        !cleanMime.equals("application/octet-stream", ignoreCase = true) &&
        !cleanMime.equals("binary/octet-stream", ignoreCase = true)
    ) {
        return cleanMime
    }
    return "application/octet-stream"
}

fun formatSafTreeLabel(treeUri: Uri): String {
    return try {
        val docId = DocumentsContract.getTreeDocumentId(treeUri)
        val normalized = when {
            docId.startsWith("primary:", ignoreCase = true) -> {
                val rel = docId.substringAfter(":").trim('/')
                if (rel.isEmpty()) "/Internal Storage" else "/$rel"
            }
            docId.contains(":") -> {
                val vol = docId.substringBefore(":")
                val rel = docId.substringAfter(":").trim('/')
                if (rel.isEmpty()) "/$vol" else "/$vol/$rel"
            }
            else -> "/$docId"
        }
        normalized
    } catch (_: Exception) {
        treeUri.lastPathSegment ?: "Selected Folder"
    }
}

fun writeBytesToDownloads(
    context: Context,
    fileName: String,
    mimeType: String,
    bytes: ByteArray
): Uri? = writeBytesToDestination(context, fileName, mimeType, bytes, DownloadDestination())

fun writeBytesToDestination(
    context: Context,
    fileName: String,
    mimeType: String,
    bytes: ByteArray,
    destination: DownloadDestination
): Uri? {
    val resolvedMime = resolveAccurateMimeType(fileName, mimeType)

    // 1. Custom SAF Folder selected via ACTION_OPEN_DOCUMENT_TREE
    if (destination.preset == DownloadFolderPreset.CUSTOM_SAF && destination.customTreeUri.isNotBlank()) {
        try {
            val treeUri = Uri.parse(destination.customTreeUri)
            val parentDocUri = DocumentsContract.buildDocumentUriUsingTree(
                treeUri,
                DocumentsContract.getTreeDocumentId(treeUri)
            )
            val createdUri = DocumentsContract.createDocument(
                context.contentResolver,
                parentDocUri,
                resolvedMime,
                fileName
            )
            if (createdUri != null) {
                context.contentResolver.openOutputStream(createdUri)?.use { out ->
                    out.write(bytes)
                    out.flush()
                }
                triggerMediaScanForSafUri(context, treeUri, fileName, resolvedMime)
                return createdUri
            }
        } catch (_: Exception) {
            // Fall through to public Downloads if SAF permission was revoked
        }
    }

    // 2. Standard Scoped Storage & Public Directories (guaranteed visible in Phone File Manager)
    return writeStreamToMediaStore(
        context = context,
        fileName = fileName,
        mimeType = resolvedMime,
        preset = destination.preset,
        inputStream = bytes.inputStream(),
        onProgress = null
    )
}

private fun triggerMediaScanForSafUri(
    context: Context,
    treeUri: Uri,
    fileName: String,
    mimeType: String
) {
    try {
        val docId = DocumentsContract.getTreeDocumentId(treeUri)
        if (docId.startsWith("primary:", ignoreCase = true)) {
            val rel = docId.substringAfter(":").trim('/')
            @Suppress("DEPRECATION")
            val root = Environment.getExternalStorageDirectory()
            val targetDir = if (rel.isEmpty()) root else File(root, rel)
            val targetFile = File(targetDir, fileName)
            if (targetFile.exists()) {
                scanFileForFileManager(context, targetFile, mimeType)
            }
        }
    } catch (_: Exception) {
    }
}

private fun scanFileForFileManager(
    context: Context,
    file: File,
    mimeType: String
) {
    try {
        MediaScannerConnection.scanFile(
            context.applicationContext,
            arrayOf(file.absolutePath),
            arrayOf(mimeType),
            null
        )
    } catch (_: Exception) {
    }
    try {
        @Suppress("DEPRECATION")
        val scanIntent = Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(file))
        context.applicationContext.sendBroadcast(scanIntent)
    } catch (_: Exception) {
    }
}

private fun queryMediaStoreFilePath(context: Context, uri: Uri): String? {
    return try {
        val projection = arrayOf(MediaStore.MediaColumns.DATA)
        context.contentResolver.query(uri, projection, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex(MediaStore.MediaColumns.DATA)
                if (idx >= 0) cursor.getString(idx) else null
            } else {
                null
            }
        }
    } catch (_: Exception) {
        null
    }
}

private fun buildUniqueFileInDir(dir: File, desiredName: String): File {
    var candidate = File(dir, desiredName)
    if (!candidate.exists()) return candidate
    val dotIdx = desiredName.lastIndexOf('.')
    val base = if (dotIdx > 0) desiredName.substring(0, dotIdx) else desiredName
    val ext = if (dotIdx > 0) desiredName.substring(dotIdx) else ""
    var counter = 1
    while (candidate.exists() && counter < 999) {
        candidate = File(dir, "$base ($counter)$ext")
        counter++
    }
    return candidate
}

/**
 * Writes a downloaded stream into the phone's public storage so it is 100% visible in:
 * - Phone File Manager -> Downloads (/storage/emulated/0/Download)
 * - Phone File Manager -> Images / Videos / Audio / Documents / APKs / Archives (ZIP) / Recent
 * - System MediaStore & Gallery
 *
 * Avoids leaving hidden `.pending-*` files by writing without `IS_PENDING=1` and triggering
 * `MediaScannerConnection.scanFile` on the physical file path immediately after flush.
 */
private fun writeStreamToMediaStore(
    context: Context,
    fileName: String,
    mimeType: String,
    preset: DownloadFolderPreset,
    inputStream: InputStream,
    onProgress: ((bytesWritten: Long) -> Unit)?
): Uri? {
    val safeMime = resolveAccurateMimeType(fileName, mimeType)

    // Buffer to a temporary file first if needed so we can safely retry across MediaStore + Direct File
    val tempCopyDir = File(context.cacheDir, "save_staging").apply { mkdirs() }
    val stagingFile = File(tempCopyDir, "stage_${System.nanoTime()}_${fileName.takeLast(24)}")
    try {
        FileOutputStream(stagingFile).use { out ->
            copyStreamWithProgress(inputStream, out, onProgress)
        }
        if (!stagingFile.exists() || stagingFile.length() == 0L) {
            return null
        }

        // If preset is STUDIO_DOWNLOADS (/Downloads/Flowra) or DOWNLOADS (/Downloads),
        // also ensure the file is written to the root /Download directory so OEM File Managers'
        // top-level "Downloads" shortcut always displays it at the very top!
        val primaryDirType = preset.publicDirType

        // Strategy 1: On Android 10+ (API 29+), insert into MediaStore without IS_PENDING=1
        // so the file is created with its real visible name immediately.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val collectionUri = when (preset) {
                DownloadFolderPreset.PICTURES -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                DownloadFolderPreset.MUSIC -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                DownloadFolderPreset.MOVIES -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                DownloadFolderPreset.DOCUMENTS -> MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                else -> MediaStore.Downloads.EXTERNAL_CONTENT_URI
            }
            val effectiveMime = if (
                preset == DownloadFolderPreset.DOCUMENTS &&
                !safeMime.startsWith("text/") &&
                safeMime != "application/pdf"
            ) {
                "application/octet-stream"
            } else {
                safeMime
            }

            // Always use root DIRECTORY_DOWNLOADS for DOWNLOADS & STUDIO_DOWNLOADS so the file is
            // immediately visible in the main Downloads view of Vivo, Xiaomi, Samsung, and Google File Managers.
            val targetRelPath = when (preset) {
                DownloadFolderPreset.DOWNLOADS,
                DownloadFolderPreset.STUDIO_DOWNLOADS,
                DownloadFolderPreset.CUSTOM_SAF -> Environment.DIRECTORY_DOWNLOADS
                else -> buildString {
                    append(primaryDirType)
                    if (!preset.subFolder.isNullOrBlank()) {
                        append("/")
                        append(preset.subFolder)
                    }
                }
            }

            val resolver = context.contentResolver
            val candidateNames = listOf(
                fileName,
                buildDeduplicatedName(fileName, 1),
                buildDeduplicatedName(fileName, (System.currentTimeMillis() % 10000).toInt())
            )

            for (candidateName in candidateNames) {
                try {
                    val values = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, candidateName)
                        put(MediaStore.MediaColumns.MIME_TYPE, effectiveMime)
                        put(MediaStore.MediaColumns.RELATIVE_PATH, targetRelPath)
                    }
                    val insertedUri = resolver.insert(collectionUri, values)
                        ?: resolver.insert(
                            MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                            ContentValues().apply {
                                put(MediaStore.MediaColumns.DISPLAY_NAME, candidateName)
                                put(MediaStore.MediaColumns.MIME_TYPE, safeMime)
                                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                            }
                        )

                    if (insertedUri != null) {
                        var writeSucceeded = false
                        resolver.openOutputStream(insertedUri)?.use { out ->
                            FileInputStream(stagingFile).use { stageIn ->
                                stageIn.copyTo(out, 32 * 1024)
                            }
                            out.flush()
                            writeSucceeded = true
                        }
                        if (writeSucceeded) {
                            // If preset had a subfolder (e.g., Flowra), also place a copy in /Download/Flowra
                            // if direct File access is permitted, while keeping the primary file in /Download root!
                            if (!preset.subFolder.isNullOrBlank()) {
                                try {
                                    @Suppress("DEPRECATION")
                                    val subDir = File(
                                        Environment.getExternalStoragePublicDirectory(primaryDirType),
                                        preset.subFolder
                                    )
                                    if (subDir.exists() || subDir.mkdirs()) {
                                        val subFile = File(subDir, candidateName)
                                        stagingFile.copyTo(subFile, overwrite = true)
                                        scanFileForFileManager(context, subFile, safeMime)
                                    }
                                } catch (_: Exception) {
                                }
                            }

                            // Trigger MediaScannerConnection on the physical path so File Manager's
                            // "Recent", "Images", "Videos", "APKs", and "Archives" tabs index it immediately!
                            val realPath = queryMediaStoreFilePath(context, insertedUri)
                            if (!realPath.isNullOrBlank()) {
                                val realFile = File(realPath)
                                if (realFile.exists()) {
                                    scanFileForFileManager(context, realFile, safeMime)
                                }
                            } else {
                                @Suppress("DEPRECATION")
                                val fallbackPublicFile = File(
                                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                                    candidateName
                                )
                                if (fallbackPublicFile.exists()) {
                                    scanFileForFileManager(context, fallbackPublicFile, safeMime)
                                }
                            }
                            return insertedUri
                        }
                    }
                } catch (_: Exception) {
                }
            }
        }

        // Strategy 2: Direct Public Directory File write (/storage/emulated/0/Download/<fileName>)
        // + MediaScannerConnection indexing + FileProvider URI
        try {
            @Suppress("DEPRECATION")
            val publicRootDir = Environment.getExternalStoragePublicDirectory(primaryDirType)
            if (publicRootDir != null && (publicRootDir.exists() || publicRootDir.mkdirs())) {
                val targetFile = buildUniqueFileInDir(publicRootDir, fileName)
                FileInputStream(stagingFile).use { stageIn ->
                    FileOutputStream(targetFile).use { fileOut ->
                        stageIn.copyTo(fileOut, 32 * 1024)
                        fileOut.flush()
                        try {
                            fileOut.fd.sync()
                        } catch (_: Exception) {
                        }
                    }
                }
                if (targetFile.exists() && targetFile.length() > 0L) {
                    scanFileForFileManager(context, targetFile, safeMime)
                    return FileProvider.getUriForFile(
                        context,
                        "${context.packageName}.fileprovider",
                        targetFile
                    )
                }
            }
        } catch (_: Exception) {
        }

        // Strategy 3: App-specific external Downloads fallback (guaranteed writable on all sandboxes)
        try {
            val appDownloadsDir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
                ?: File(context.filesDir, "Downloads")
            if (!appDownloadsDir.exists()) appDownloadsDir.mkdirs()
            val fallbackFile = buildUniqueFileInDir(appDownloadsDir, fileName)
            stagingFile.copyTo(fallbackFile, overwrite = true)
            if (fallbackFile.exists() && fallbackFile.length() > 0L) {
                scanFileForFileManager(context, fallbackFile, safeMime)
                return FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    fallbackFile
                )
            }
        } catch (_: Exception) {
        }

        return null
    } finally {
        stagingFile.delete()
    }
}

private fun buildDeduplicatedName(fileName: String, index: Int): String {
    val dotIdx = fileName.lastIndexOf('.')
    return if (dotIdx > 0) {
        val base = fileName.substring(0, dotIdx)
        val ext = fileName.substring(dotIdx)
        "$base ($index)$ext"
    } else {
        "$fileName ($index)"
    }
}

private fun copyStreamWithProgress(
    input: InputStream,
    output: java.io.OutputStream,
    onProgress: ((Long) -> Unit)?
) {
    val buffer = ByteArray(16 * 1024)
    var total = 0L
    var lastReportedBytes = 0L
    var lastReportedTime = 0L
    while (true) {
        val read = input.read(buffer)
        if (read <= 0) break
        output.write(buffer, 0, read)
        total += read
        if (onProgress != null) {
            val now = System.currentTimeMillis()
            if (lastReportedBytes == 0L ||
                (total - lastReportedBytes >= 16 * 1024L && now - lastReportedTime >= 180L)
            ) {
                lastReportedBytes = total
                lastReportedTime = now
                onProgress(total)
            }
        }
    }
    output.flush()
    onProgress?.invoke(total)
}

object DownloadHelper {

    private const val DOWNLOAD_CHANNEL_ID = "flowra_downloads_channel"
    private val activeInProcessRowIds = ConcurrentHashMap<Long, Long>()

    /**
     * Streams blob: or data: URLs in 512 KB binary chunks via StudioDownloadBridge so large
     * .zip and .apk files (e.g. 18MB - 200MB) never hit WebView JNI Base64 string limits,
     * reads from window.__flowraBlobStore if the page already called URL.revokeObjectURL(),
     * and falls back to XMLHttpRequest if Content-Security-Policy (connect-src) blocks fetch().
     */
    fun buildBlobOrDataExtractionScript(
        blobOrDataUrl: String,
        suggestedName: String,
        mimeType: String,
        destination: DownloadDestination = DownloadDestination()
    ): String {
        val escapedUrl = blobOrDataUrl.replace("\\", "\\\\").replace("'", "\\'")
        val escapedName = suggestedName.replace("\\", "\\\\").replace("'", "\\'")
        val escapedMime = mimeType.replace("\\", "\\\\").replace("'", "\\'")
        val escapedPreset = destination.preset.name.replace("'", "\\'")
        val escapedTree = destination.customTreeUri.replace("\\", "\\\\").replace("'", "\\'")
        val escapedLabel = destination.customFolderLabel.replace("\\", "\\\\").replace("'", "\\'")
        return """
            (function() {
                try {
                    var targetUrl = '$escapedUrl';
                    var fallbackName = '$escapedName';
                    var fallbackMime = '$escapedMime';
                    var presetName = '$escapedPreset';
                    var customTree = '$escapedTree';
                    var customLabel = '$escapedLabel';

                    if (targetUrl.indexOf('data:') === 0) {
                        if (window.StudioDownloadBridge && window.StudioDownloadBridge.saveBase64DataToDestination) {
                            window.StudioDownloadBridge.saveBase64DataToDestination(
                                targetUrl, fallbackName, fallbackMime, presetName, customTree, customLabel
                            );
                        }
                        return;
                    }

                    function fetchBlobWithXhrFallback(url) {
                        var cached = (window.__flowraBlobStore && window.__flowraBlobStore[url]) || null;
                        if (cached) return Promise.resolve(cached);
                        return fetch(url).then(function(res) {
                            if (!res.ok) throw new Error('HTTP ' + res.status);
                            return res.blob();
                        }).catch(function() {
                            return new Promise(function(resolve, reject) {
                                try {
                                    var xhr = new XMLHttpRequest();
                                    xhr.open('GET', url, true);
                                    xhr.responseType = 'blob';
                                    xhr.onload = function() {
                                        if (xhr.status === 200 || xhr.status === 0) {
                                            resolve(xhr.response);
                                        } else {
                                            reject(new Error('XHR status ' + xhr.status));
                                        }
                                    };
                                    xhr.onerror = function() { reject(new Error('XHR error')); };
                                    xhr.send();
                                } catch (eXhr) {
                                    reject(eXhr);
                                }
                            });
                        });
                    }

                    fetchBlobWithXhrFallback(targetUrl).then(function(blob) {
                        if (!blob || !window.StudioDownloadBridge) return;
                        var effectiveMime = blob.type || fallbackMime || 'application/octet-stream';
                        var transferId = 'tr_' + Date.now() + '_' + Math.floor(Math.random() * 100000);
                        if (!window.StudioDownloadBridge.startBlobTransfer) {
                            var r = new FileReader();
                            r.onloadend = function() {
                                if (r.result) {
                                    window.StudioDownloadBridge.saveBase64DataToDestination(
                                        r.result, fallbackName, effectiveMime, presetName, customTree, customLabel
                                    );
                                }
                            };
                            r.readAsDataURL(blob);
                            return;
                        }

                        window.StudioDownloadBridge.startBlobTransfer(
                            transferId, fallbackName, effectiveMime, presetName, customTree, customLabel
                        );
                        var chunkSize = 512 * 1024;
                        var offset = 0;

                        function sendNextChunk() {
                            if (offset >= blob.size) {
                                window.StudioDownloadBridge.finishBlobTransfer(transferId, targetUrl);
                                return;
                            }
                            var slice = blob.slice(offset, Math.min(offset + chunkSize, blob.size));
                            offset += chunkSize;
                            var reader = new FileReader();
                            reader.onloadend = function() {
                                if (reader.result) {
                                    window.StudioDownloadBridge.appendBlobChunk(transferId, reader.result);
                                    sendNextChunk();
                                }
                            };
                            reader.readAsDataURL(slice);
                        }
                        sendNextChunk();
                    }).catch(function(err) {
                        console.error('Flowra blob download error:', err);
                    });
                } catch (e) {}
            })();
        """.trimIndent()
    }

    suspend fun enqueueHttpDownload(
        context: Context,
        repository: BrowserRepository,
        url: String,
        fileName: String,
        mimeType: String,
        userAgent: String
    ): Long = enqueueDownloadWithDestination(
        context = context,
        repository = repository,
        url = url,
        fileName = fileName,
        mimeType = mimeType,
        userAgent = userAgent,
        destination = DownloadDestination()
    )

    /**
     * Routes ALL HTTP/HTTPS downloads through Flowra's direct multi-redirect authenticated
     * streaming engine so downloads start immediately over both Wi-Fi and 4G/5G mobile data
     * (never stalling at 0 B in Android's system DownloadManager queue) and are immediately
     * indexed into the phone's File Manager & Gallery via MediaStore + MediaScannerConnection.
     */
    suspend fun enqueueDownloadWithDestination(
        context: Context,
        repository: BrowserRepository,
        url: String,
        fileName: String,
        mimeType: String,
        userAgent: String,
        destination: DownloadDestination,
        refererUrl: String = "",
        existingRowId: Long? = null
    ): Long {
        val rawMime = mimeType.ifBlank { "application/octet-stream" }
        val finalName = sanitizeFileName(fileName, rawMime)
        val safeMime = resolveAccurateMimeType(finalName, rawMime)
        val folderLabel = destination.displayLabel()

        return streamHttpDownloadToSafOrMediaStore(
            context = context,
            repository = repository,
            url = url,
            finalName = finalName,
            safeMime = safeMime,
            userAgent = userAgent,
            destination = destination,
            folderLabel = folderLabel,
            refererUrl = refererUrl,
            existingRowId = existingRowId
        )
    }

    private suspend fun streamHttpDownloadToSafOrMediaStore(
        context: Context,
        repository: BrowserRepository,
        url: String,
        finalName: String,
        safeMime: String,
        userAgent: String,
        destination: DownloadDestination,
        folderLabel: String,
        refererUrl: String = "",
        existingRowId: Long? = null
    ): Long {
        val rowId = if (existingRowId != null && existingRowId > 0L) {
            repository.updateDownload(
                DownloadEntity(
                    id = existingRowId,
                    systemDownloadId = -1L,
                    fileName = finalName,
                    url = url,
                    mimeType = safeMime,
                    status = DownloadStatus.RUNNING,
                    totalBytes = -1L,
                    downloadedBytes = 0L,
                    saveFolderLabel = folderLabel
                )
            )
            existingRowId
        } else {
            repository.insertDownload(
                DownloadEntity(
                    systemDownloadId = -1L,
                    fileName = finalName,
                    url = url,
                    mimeType = safeMime,
                    status = DownloadStatus.RUNNING,
                    saveFolderLabel = folderLabel
                )
            )
        }

        activeInProcessRowIds[rowId] = System.currentTimeMillis()

        return withContext(Dispatchers.IO) {
            var connection: HttpURLConnection? = null
            val tempDir = File(context.cacheDir, "http_downloads").apply { mkdirs() }
            val tempFile = File(tempDir, "dl_${rowId}_${System.currentTimeMillis()}.tmp")
            var resolvedFileName = finalName
            var effectiveMime = safeMime
            try {
                connection = openFollowedHttpConnection(url, userAgent, refererUrl)
                val responseCode = try {
                    connection.responseCode
                } catch (_: Exception) {
                    200
                }
                if (responseCode >= 400) {
                    throw IllegalStateException("HTTP $responseCode")
                }

                val totalLength = connection.contentLengthLong
                val serverMime = connection.contentType?.substringBefore(";")?.trim().orEmpty()
                val serverDisposition = connection.getHeaderField("Content-Disposition")
                val finalRedirectedUrl = connection.url?.toString() ?: url

                // Upgrade filename & MIME type if the redirected response provided a clearer name
                resolvedFileName = refineFileNameFromResponse(
                    initialFileName = finalName,
                    finalUrl = finalRedirectedUrl,
                    contentDisposition = serverDisposition,
                    serverMime = serverMime.ifBlank { safeMime }
                )
                effectiveMime = resolveAccurateMimeType(
                    resolvedFileName,
                    serverMime.ifBlank { safeMime }
                )

                val runningEntity = DownloadEntity(
                    id = rowId,
                    systemDownloadId = -1L,
                    fileName = resolvedFileName,
                    url = url,
                    mimeType = effectiveMime,
                    status = DownloadStatus.RUNNING,
                    totalBytes = totalLength,
                    downloadedBytes = 0L,
                    saveFolderLabel = folderLabel
                )
                repository.updateDownload(runningEntity)

                var finalBytes = 0L
                connection.inputStream.use { input ->
                    FileOutputStream(tempFile).use { tempOut ->
                        copyStreamWithProgress(input, tempOut) { written ->
                            finalBytes = written
                            CoroutineScope(Dispatchers.IO).launch {
                                try {
                                    repository.updateDownloadProgress(rowId, written)
                                } catch (_: Exception) {
                                }
                            }
                        }
                    }
                }

                if (!tempFile.exists() || tempFile.length() == 0L) {
                    throw IllegalStateException("Empty response stream")
                }
                finalBytes = tempFile.length()

                val isZip = resolvedFileName.endsWith(".zip", ignoreCase = true) ||
                    effectiveMime.contains("zip", ignoreCase = true)

                // If it's a .zip file under 64 MB, normalize its headers so Vivo/OEM File Managers never fail on it
                if (isZip && tempFile.length() in 1L..(64L * 1024L * 1024L)) {
                    try {
                        val rawBytes = tempFile.readBytes()
                        val normalized = ZipArchiveHelper.normalizeZipBytes(rawBytes)
                        tempFile.writeBytes(normalized)
                        finalBytes = normalized.size.toLong()
                    } catch (_: Exception) {
                    }
                }

                var savedUri: Uri? = null
                FileInputStream(tempFile).use { fileIn ->
                    if (destination.preset == DownloadFolderPreset.CUSTOM_SAF && destination.customTreeUri.isNotBlank()) {
                        try {
                            val treeUri = Uri.parse(destination.customTreeUri)
                            val parentDocUri = DocumentsContract.buildDocumentUriUsingTree(
                                treeUri,
                                DocumentsContract.getTreeDocumentId(treeUri)
                            )
                            val docUri = DocumentsContract.createDocument(
                                context.contentResolver,
                                parentDocUri,
                                effectiveMime,
                                resolvedFileName
                            )
                            if (docUri != null) {
                                context.contentResolver.openOutputStream(docUri)?.use { out ->
                                    copyStreamWithProgress(fileIn, out, null)
                                }
                                triggerMediaScanForSafUri(context, treeUri, resolvedFileName, effectiveMime)
                                savedUri = docUri
                            }
                        } catch (_: Exception) {
                        }
                    }

                    if (savedUri == null) {
                        savedUri = writeStreamToMediaStore(
                            context = context,
                            fileName = resolvedFileName,
                            mimeType = effectiveMime,
                            preset = destination.preset,
                            inputStream = fileIn,
                            onProgress = null
                        )
                    }
                }

                val isSuccess = savedUri != null
                repository.updateDownload(
                    runningEntity.copy(
                        fileName = resolvedFileName,
                        mimeType = effectiveMime,
                        localUri = savedUri?.toString() ?: "",
                        status = if (isSuccess) DownloadStatus.SUCCESSFUL else DownloadStatus.FAILED,
                        totalBytes = if (totalLength > 0) totalLength else finalBytes,
                        downloadedBytes = finalBytes
                    )
                )

                if (isSuccess && savedUri != null) {
                    postDownloadCompleteNotification(
                        context = context,
                        fileName = resolvedFileName,
                        mimeType = effectiveMime,
                        fileUri = savedUri,
                        folderLabel = folderLabel
                    )
                    withContext(Dispatchers.Main) {
                        Toast.makeText(
                            context,
                            "Downloaded $resolvedFileName -> Saved in File Manager ($folderLabel)",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }

                // Auto-extract inner .apk files when downloading a .zip
                if (isSuccess && isZip && tempFile.exists() && tempFile.length() in 1L..(64L * 1024L * 1024L)) {
                    try {
                        val summary = ZipArchiveHelper.extractZipBytesToDestination(
                            context = context,
                            zipBytes = tempFile.readBytes(),
                            destination = destination
                        )
                        for (extracted in summary.extractedFiles) {
                            repository.insertDownload(
                                DownloadEntity(
                                    systemDownloadId = -1L,
                                    fileName = extracted.fileName,
                                    url = "extracted://${resolvedFileName}/${extracted.fileName}",
                                    mimeType = extracted.mimeType,
                                    localUri = extracted.savedUri.toString(),
                                    status = DownloadStatus.SUCCESSFUL,
                                    totalBytes = extracted.sizeBytes,
                                    downloadedBytes = extracted.sizeBytes,
                                    saveFolderLabel = folderLabel
                                )
                            )
                        }
                    } catch (_: Exception) {
                    }
                }

                rowId
            } catch (e: Exception) {
                repository.updateDownload(
                    DownloadEntity(
                        id = rowId,
                        systemDownloadId = -1L,
                        fileName = resolvedFileName,
                        url = url,
                        mimeType = effectiveMime,
                        status = DownloadStatus.FAILED,
                        saveFolderLabel = folderLabel
                    )
                )
                withContext(Dispatchers.Main) {
                    Toast.makeText(
                        context,
                        "Download failed for $resolvedFileName. Tap Retry in Downloads.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
                -1L
            } finally {
                activeInProcessRowIds.remove(rowId)
                tempFile.delete()
                connection?.disconnect()
            }
        }
    }

    private fun refineFileNameFromResponse(
        initialFileName: String,
        finalUrl: String,
        contentDisposition: String?,
        serverMime: String
    ): String {
        val dispFileName = extractFileNameFromContentDisposition(contentDisposition)
        if (!dispFileName.isNullOrBlank()) {
            return sanitizeFileName(dispFileName, serverMime)
        }
        // Check if final redirected URL has a query parameter like ?dl=filename.jpg (used by Unsplash!)
        try {
            val uri = Uri.parse(finalUrl)
            val dlParam = uri.getQueryParameter("dl")
                ?: uri.getQueryParameter("filename")
                ?: uri.getQueryParameter("response-content-disposition")?.let {
                    extractFileNameFromContentDisposition(it)
                }
            if (!dlParam.isNullOrBlank()) {
                return sanitizeFileName(dlParam, serverMime)
            }
        } catch (_: Exception) {
        }

        val lowerInitial = initialFileName.lowercase(Locale.US)
        val isGenericInitial = lowerInitial.startsWith("download") ||
            lowerInitial.startsWith("file") ||
            lowerInitial.endsWith(".bin") ||
            !lowerInitial.contains(".")
        if (isGenericInitial) {
            val guessedFromFinal = URLUtil.guessFileName(finalUrl, contentDisposition, serverMime)
            if (guessedFromFinal.isNotBlank() && !guessedFromFinal.endsWith(".bin")) {
                return sanitizeFileName(guessedFromFinal, serverMime)
            }
        }
        return sanitizeFileName(initialFileName, serverMime)
    }

    private fun extractFileNameFromContentDisposition(contentDisposition: String?): String? {
        if (contentDisposition.isNullOrBlank()) return null
        // Match filename*=UTF-8''... first
        val utf8Regex = Regex("filename\\*\\s*=\\s*(?:UTF-8''|utf-8'')([^;]+)", RegexOption.IGNORE_CASE)
        utf8Regex.find(contentDisposition)?.groupValues?.getOrNull(1)?.let { encoded ->
            val clean = encoded.trim('"', '\'', ' ')
            return try {
                URLDecoder.decode(clean, "UTF-8")
            } catch (_: Exception) {
                clean
            }
        }
        // Match filename="..."
        val stdRegex = Regex("filename\\s*=\\s*\"([^\"]+)\"", RegexOption.IGNORE_CASE)
        stdRegex.find(contentDisposition)?.groupValues?.getOrNull(1)?.let { quoted ->
            if (quoted.isNotBlank()) return quoted.trim()
        }
        val unquotedRegex = Regex("filename\\s*=\\s*([^;\\s]+)", RegexOption.IGNORE_CASE)
        unquotedRegex.find(contentDisposition)?.groupValues?.getOrNull(1)?.let { raw ->
            val clean = raw.trim('"', '\'', ' ')
            if (clean.isNotBlank()) return clean
        }
        return null
    }

    private fun openFollowedHttpConnection(
        rawUrl: String,
        userAgent: String,
        refererUrl: String = ""
    ): HttpURLConnection {
        var currentUrl = rawUrl
        var currentReferer = refererUrl
        var redirects = 0
        val effectiveUa = userAgent.ifBlank { WebViewManager.MOBILE_CHROME_USER_AGENT }

        while (redirects < 10) {
            val conn = (URL(currentUrl).openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = false
                connectTimeout = 25_000
                readTimeout = 90_000
                setRequestProperty("User-Agent", effectiveUa)
                setRequestProperty("Accept", "*/*")
                setRequestProperty("Accept-Language", "en-US,en;q=0.9")
                if (currentReferer.isNotBlank()) {
                    setRequestProperty("Referer", currentReferer)
                }
                val cookies = try {
                    CookieManager.getInstance().getCookie(currentUrl)
                } catch (_: Exception) {
                    null
                }
                if (!cookies.isNullOrBlank()) {
                    setRequestProperty("Cookie", cookies)
                }
            }
            val code = conn.responseCode
            if (code in 300..399) {
                val location = conn.getHeaderField("Location")
                conn.disconnect()
                if (location.isNullOrBlank()) break
                val nextUrl = URL(URL(currentUrl), location).toString()
                currentReferer = try {
                    val u = Uri.parse(currentUrl)
                    "${u.scheme}://${u.host}/"
                } catch (_: Exception) {
                    currentUrl
                }
                currentUrl = nextUrl
                redirects++
            } else {
                return conn
            }
        }
        return (URL(currentUrl).openConnection() as HttpURLConnection).apply {
            instanceFollowRedirects = true
            connectTimeout = 25_000
            readTimeout = 90_000
            setRequestProperty("User-Agent", effectiveUa)
            setRequestProperty("Accept", "*/*")
            val cookies = try {
                CookieManager.getInstance().getCookie(currentUrl)
            } catch (_: Exception) {
                null
            }
            if (!cookies.isNullOrBlank()) {
                setRequestProperty("Cookie", cookies)
            }
        }
    }

    /**
     * Synchronizes active downloads and automatically rescues any legacy DownloadManager jobs
     * that are stuck at 0 B (e.g., on 4G mobile data or redirected URLs like Unsplash) by
     * switching them to Flowra's direct streaming engine!
     */
    suspend fun syncActiveDownloads(context: Context, repository: BrowserRepository) {
        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as? DownloadManager
        val activeList = repository.getActiveDownloads()
        val now = System.currentTimeMillis()

        for (item in activeList) {
            if (item.systemDownloadId > 0L) {
                var shouldRescue = false
                if (dm != null) {
                    val query = DownloadManager.Query().setFilterById(item.systemDownloadId)
                    val cursor = try {
                        dm.query(query)
                    } catch (_: Exception) {
                        null
                    }
                    if (cursor == null || !cursor.moveToFirst()) {
                        cursor?.close()
                        shouldRescue = true
                    } else {
                        cursor.use { c ->
                            val statusIdx = c.getColumnIndex(DownloadManager.COLUMN_STATUS)
                            val totalIdx = c.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
                            val downloadedIdx = c.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
                            val localUriIdx = c.getColumnIndex(DownloadManager.COLUMN_LOCAL_URI)

                            val sysStatus = if (statusIdx >= 0) c.getInt(statusIdx) else DownloadManager.STATUS_RUNNING
                            val totalBytes = if (totalIdx >= 0) c.getLong(totalIdx) else item.totalBytes
                            val downloadedBytes = if (downloadedIdx >= 0) c.getLong(downloadedIdx) else item.downloadedBytes
                            val rawLocalUri = if (localUriIdx >= 0) c.getString(localUriIdx) ?: "" else ""

                            // If system DownloadManager is stuck at 0 B or paused/failed, rescue it immediately!
                            val isStuckAtZero = downloadedBytes <= 0L && (now - item.createdAt) > 2500L
                            if (sysStatus == DownloadManager.STATUS_FAILED ||
                                sysStatus == DownloadManager.STATUS_PAUSED ||
                                isStuckAtZero
                            ) {
                                shouldRescue = true
                            } else {
                                val newStatus = when (sysStatus) {
                                    DownloadManager.STATUS_PENDING -> DownloadStatus.PENDING
                                    DownloadManager.STATUS_RUNNING -> DownloadStatus.RUNNING
                                    DownloadManager.STATUS_PAUSED -> DownloadStatus.PAUSED
                                    DownloadManager.STATUS_SUCCESSFUL -> DownloadStatus.SUCCESSFUL
                                    DownloadManager.STATUS_FAILED -> DownloadStatus.FAILED
                                    else -> item.status
                                }
                                val contentUri = if (newStatus == DownloadStatus.SUCCESSFUL) {
                                    try {
                                        dm.getUriForDownloadedFile(item.systemDownloadId)?.toString() ?: rawLocalUri
                                    } catch (_: Exception) {
                                        rawLocalUri
                                    }
                                } else {
                                    rawLocalUri
                                }
                                repository.updateDownload(
                                    item.copy(
                                        status = newStatus,
                                        totalBytes = totalBytes,
                                        downloadedBytes = downloadedBytes,
                                        localUri = contentUri.ifBlank { item.localUri }
                                    )
                                )
                            }
                        }
                    }
                } else {
                    shouldRescue = true
                }

                if (shouldRescue && (item.url.startsWith("http://") || item.url.startsWith("https://"))) {
                    try {
                        dm?.remove(item.systemDownloadId)
                    } catch (_: Exception) {
                    }
                    retryDownload(context, repository, item)
                }
            } else {
                // Direct engine row: if it's not active in activeInProcessRowIds and older than 4s,
                // it was interrupted by an app restart — auto-resume it!
                val isCurrentlyStreaming = activeInProcessRowIds.containsKey(item.id)
                if (!isCurrentlyStreaming && (now - item.createdAt) > 4000L) {
                    if (item.url.startsWith("http://") || item.url.startsWith("https://")) {
                        retryDownload(context, repository, item)
                    } else {
                        repository.updateDownload(item.copy(status = DownloadStatus.FAILED))
                    }
                }
            }
        }
    }

    fun retryDownload(
        context: Context,
        repository: BrowserRepository,
        download: DownloadEntity
    ) {
        if (activeInProcessRowIds.containsKey(download.id)) return
        if (!download.url.startsWith("http://") && !download.url.startsWith("https://")) {
            Toast.makeText(context, "Cannot retry temporary blob URL — please re-download from page", Toast.LENGTH_SHORT).show()
            return
        }
        val preset = when (download.saveFolderLabel) {
            "/Downloads/Flowra" -> DownloadFolderPreset.STUDIO_DOWNLOADS
            "/Documents" -> DownloadFolderPreset.DOCUMENTS
            "/Pictures" -> DownloadFolderPreset.PICTURES
            "/Music" -> DownloadFolderPreset.MUSIC
            "/Movies" -> DownloadFolderPreset.MOVIES
            else -> DownloadFolderPreset.DOWNLOADS
        }
        CoroutineScope(Dispatchers.IO).launch {
            enqueueDownloadWithDestination(
                context = context.applicationContext,
                repository = repository,
                url = download.url,
                fileName = download.fileName,
                mimeType = download.mimeType,
                userAgent = WebViewManager.MOBILE_CHROME_USER_AGENT,
                destination = DownloadDestination(preset = preset),
                existingRowId = download.id
            )
        }
    }

    fun openSystemDownloadsFileManager(context: Context) {
        val candidates = listOf(
            Intent(DownloadManager.ACTION_VIEW_DOWNLOADS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            },
            Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    DocumentsContract.Document.MIME_TYPE_DIR
                )
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            },
            Intent(Intent.ACTION_GET_CONTENT).apply {
                type = "*/*"
                addCategory(Intent.CATEGORY_OPENABLE)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
        )
        for (intent in candidates) {
            try {
                context.startActivity(intent)
                return
            } catch (_: Exception) {
            }
        }
        Toast.makeText(context, "Saved in Internal Storage -> Download", Toast.LENGTH_SHORT).show()
    }

    fun postDownloadCompleteNotification(
        context: Context,
        fileName: String,
        mimeType: String,
        fileUri: Uri,
        folderLabel: String
    ) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                val granted = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
                if (!granted) return
            }
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    DOWNLOAD_CHANNEL_ID,
                    "Flowra File Downloads",
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply {
                    description = "Notifications when files finish downloading to Phone File Manager"
                }
                nm.createNotificationChannel(channel)
            }

            val resolvedMime = resolveAccurateMimeType(fileName, mimeType)
            val openIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(fileUri, resolvedMime)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val pendingIntent = PendingIntent.getActivity(
                context,
                fileName.hashCode(),
                openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val notification = NotificationCompat.Builder(context, DOWNLOAD_CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle(fileName)
                .setContentText("Saved in File Manager ($folderLabel) • Tap to open")
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)
                .build()

            nm.notify((System.currentTimeMillis() and 0xFFFFFFF).toInt(), notification)
        } catch (_: Exception) {
        }
    }

    /**
     * Extracts a downloaded .zip archive directly using Flowra's built-in ZipArchiveHelper
     * and inserts all extracted files (such as app-debug.apk) into the Downloads list.
     */
    fun extractDownloadedZip(
        context: Context,
        repository: BrowserRepository,
        download: DownloadEntity
    ) {
        val uri = resolveShareableUri(context, download)
        if (uri == null) {
            Toast.makeText(context, "ZIP file not found on storage", Toast.LENGTH_SHORT).show()
            return
        }
        CoroutineScope(Dispatchers.IO).launch {
            val summary = ZipArchiveHelper.extractZipFromUri(
                context = context,
                zipUri = uri,
                destination = DownloadDestination(DownloadFolderPreset.DOWNLOADS)
            )
            if (summary.extractedFiles.isEmpty()) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(
                        context,
                        "Could not find extractable entries in ${download.fileName}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
                return@launch
            }

            val folderLabel = download.saveFolderLabel.ifBlank { "/Downloads" }
            for (item in summary.extractedFiles) {
                repository.insertDownload(
                    DownloadEntity(
                        systemDownloadId = -1L,
                        fileName = item.fileName,
                        url = "extracted://${download.fileName}/${item.fileName}",
                        mimeType = item.mimeType,
                        localUri = item.savedUri.toString(),
                        status = DownloadStatus.SUCCESSFUL,
                        totalBytes = item.sizeBytes,
                        downloadedBytes = item.sizeBytes,
                        saveFolderLabel = folderLabel
                    )
                )
            }

            withContext(Dispatchers.Main) {
                val names = summary.extractedFiles.joinToString(", ") { it.fileName }
                val message = if (summary.containsSimulatedApk) {
                    "Extracted $names to $folderLabel (Note: inner APK is a web demo placeholder, not a compiled binary)"
                } else {
                    "Extracted ${summary.extractedFiles.size} file(s) ($names) to $folderLabel"
                }
                Toast.makeText(context, message, Toast.LENGTH_LONG).show()
            }
        }
    }

    fun openDownloadedFile(context: Context, download: DownloadEntity, repository: BrowserRepository? = null) {
        val uri = resolveShareableUri(context, download)
        if (uri == null) {
            Toast.makeText(context, "File not available yet", Toast.LENGTH_SHORT).show()
            return
        }
        // If user taps a .zip file and repository is provided, also auto-extract it in Flowra
        if (download.fileName.endsWith(".zip", ignoreCase = true) && repository != null) {
            extractDownloadedZip(context, repository, download)
            return
        }

        val resolvedMime = resolveAccurateMimeType(download.fileName, download.mimeType)
        try {
            val viewIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, resolvedMime)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(viewIntent, "Open ${download.fileName}"))
        } catch (_: Exception) {
            Toast.makeText(context, "No app found to open ${download.fileName}", Toast.LENGTH_SHORT).show()
        }
    }

    fun shareDownloadedFile(context: Context, download: DownloadEntity) {
        val uri = resolveShareableUri(context, download)
        if (uri == null) {
            Toast.makeText(context, "File cannot be shared yet", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val resolvedMime = resolveAccurateMimeType(download.fileName, download.mimeType)
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = resolvedMime.ifBlank { "*/*" }
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(shareIntent, "Share ${download.fileName}"))
        } catch (_: Exception) {
            Toast.makeText(context, "Unable to share file", Toast.LENGTH_SHORT).show()
        }
    }

    private fun resolveShareableUri(context: Context, download: DownloadEntity): Uri? {
        if (download.systemDownloadId > 0L) {
            val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as? DownloadManager
            val dmUri = try {
                dm?.getUriForDownloadedFile(download.systemDownloadId)
            } catch (_: Exception) {
                null
            }
            if (dmUri != null) return dmUri
        }
        if (download.localUri.isNotBlank()) {
            val parsed = Uri.parse(download.localUri)
            if (parsed.scheme == "content") return parsed
            if (parsed.scheme == "file" && parsed.path != null) {
                return try {
                    FileProvider.getUriForFile(
                        context,
                        "${context.packageName}.fileprovider",
                        File(parsed.path!!)
                    )
                } catch (_: Exception) {
                    null
                }
            }
        }
        // Fallback: check if file exists in public /Download directory by name
        try {
            @Suppress("DEPRECATION")
            val pubFile = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                download.fileName
            )
            if (pubFile.exists() && pubFile.length() > 0L) {
                return FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    pubFile
                )
            }
        } catch (_: Exception) {
        }
        return null
    }

    fun formatBytes(bytes: Long): String {
        if (bytes < 0L) return "Unknown size"
        if (bytes < 1024L) return "$bytes B"
        val kb = bytes / 1024.0
        if (kb < 1024.0) return String.format(Locale.US, "%.1f KB", kb)
        val mb = kb / 1024.0
        if (mb < 1024.0) return String.format(Locale.US, "%.1f MB", mb)
        val gb = mb / 1024.0
        return String.format(Locale.US, "%.2f GB", gb)
    }

    fun guessName(
        url: String,
        contentDisposition: String?,
        mimeType: String?,
        registeredBlobName: String? = null
    ): String {
        val safeMime = mimeType ?: "application/octet-stream"
        if (!registeredBlobName.isNullOrBlank()) {
            return sanitizeFileName(registeredBlobName, safeMime)
        }
        val dispName = extractFileNameFromContentDisposition(contentDisposition)
        if (!dispName.isNullOrBlank()) {
            return sanitizeFileName(dispName, safeMime)
        }
        if (url.startsWith("blob:") || url.startsWith("data:")) {
            return sanitizeFileName("studio_export_${System.currentTimeMillis()}", safeMime)
        }
        try {
            val uri = Uri.parse(url)
            val dlParam = uri.getQueryParameter("dl") ?: uri.getQueryParameter("filename")
            if (!dlParam.isNullOrBlank()) {
                return sanitizeFileName(dlParam, safeMime)
            }
        } catch (_: Exception) {
        }
        val guessed = URLUtil.guessFileName(url, contentDisposition, mimeType)
        return sanitizeFileName(guessed, safeMime)
    }
}
