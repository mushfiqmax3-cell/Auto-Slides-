package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.FrameRateMode
import com.example.data.ThemeMode
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private val browserViewModel: BrowserViewModel by viewModels {
        BrowserViewModel.Factory(applicationContext)
    }

    private var isBatteryUnrestricted by mutableStateOf(false)
    private var permissionsStatus by mutableStateOf(DevicePermissionsStatus())
    private var pendingPermissionCallback: ((Boolean) -> Unit)? = null
    private var pendingFolderCallback: ((String, String) -> Unit)? = null

    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        browserViewModel.webViewManager.onFileChooserResult(result.resultCode, result.data)
    }

    private val runtimePermissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grantResults ->
        refreshPermissionsState()
        val anyGranted = grantResults.values.any { it }
        pendingPermissionCallback?.invoke(anyGranted)
        pendingPermissionCallback = null
    }

    private val startupPermissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        refreshPermissionsState()
        BrowserService.startKeepAliveService(
            applicationContext,
            browserViewModel.webViewManager.tabsState.value.size,
            PwaWebViewPool.liveCount()
        )
    }

    private val folderPickerLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { treeUri ->
        val callback = pendingFolderCallback
        pendingFolderCallback = null
        if (treeUri != null) {
            try {
                contentResolver.takePersistableUriPermission(
                    treeUri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (_: Exception) {
            }
            val label = formatSafTreeLabel(treeUri)
            browserViewModel.updateDownloadDestination(
                preset = DownloadFolderPreset.CUSTOM_SAF.name,
                customTreeUri = treeUri.toString(),
                customFolderLabel = label
            )
            callback?.invoke(treeUri.toString(), label)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Configure smooth 60 FPS frame-pacing display mode on initial launch
        FramePacingHelper.applyWindowFramePacing(this, FrameRateMode.SMOOTH_60)

        val manager = browserViewModel.webViewManager
        manager.attachActivity(this)

        // Wire file upload chooser and WebRTC/Geolocation runtime permission bridges
        manager.onLaunchFileChooser = { chooserIntent ->
            try {
                fileChooserLauncher.launch(chooserIntent)
                true
            } catch (_: Exception) {
                false
            }
        }

        manager.onRequestRuntimePermissions = { permissions, callback ->
            pendingPermissionCallback = callback
            try {
                runtimePermissionsLauncher.launch(permissions)
            } catch (_: Exception) {
                pendingPermissionCallback = null
                callback(false)
            }
        }

        // Start sticky foreground keep-alive service without nagging for permissions on startup
        // (Permissions are requested on-demand when a website or user action actually needs them, like Chrome/Brave)
        PwaWebViewPool.refreshStats(applicationContext)
        PwaShortcutHelper.syncExistingPinnedShortcuts(applicationContext)
        refreshPermissionsState()
        startBrowserKeepAliveServiceOnly()
        refreshBatteryOptimizationState()

        // Handle incoming external http/https deep-link if opened as a browser
        handleIncomingIntent(intent)

        setContent {
            val settingsState = browserViewModel.settings.collectAsStateWithLifecycle().value
            LaunchedEffect(settingsState.frameRateMode) {
                FramePacingHelper.applyWindowFramePacing(this@MainActivity, settingsState.frameRateMode)
            }
            val isDark = when (settingsState.themeMode) {
                com.example.data.ThemeMode.DARK -> true
                com.example.data.ThemeMode.LIGHT -> false
                com.example.data.ThemeMode.SYSTEM -> androidx.compose.foundation.isSystemInDarkTheme()
            }
            MyApplicationTheme(darkTheme = isDark, dynamicColor = false) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    BrowserScreen(
                        browserViewModel = browserViewModel,
                        isBatteryUnrestricted = isBatteryUnrestricted,
                        permissionsStatus = permissionsStatus,
                        onRefreshBatteryState = {
                            refreshBatteryOptimizationState()
                            refreshPermissionsState()
                        },
                        onRequestAllPermissions = {
                            requestAllBrowserPermissions(openAppSettingsIfAlreadyRequested = true)
                        },
                        onPickDownloadFolder = { cb ->
                            pendingFolderCallback = cb
                            try {
                                folderPickerLauncher.launch(null)
                            } catch (_: Exception) {
                                pendingFolderCallback = null
                            }
                        }
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent: Intent?) {
        if (intent?.getBooleanExtra(DownloadHelper.EXTRA_OPEN_DOWNLOADS, false) == true) {
            intent.removeExtra(DownloadHelper.EXTRA_OPEN_DOWNLOADS)
            browserViewModel.webViewManager.requestOpenDownloadsSheet()
        }
        val shortcutEntity = PwaShortcutHelper.extractEntityFromShortcutIntent(intent)
        if (shortcutEntity != null) {
            intent?.data = null
            intent?.removeExtra(PwaShortcutHelper.EXTRA_PWA_ID)
            if (shortcutEntity.isStandalonePwa) {
                PwaShortcutHelper.launchWebApp(this, shortcutEntity, requestPinOnStart = false)
            } else {
                browserViewModel.webViewManager.focusOrOpenTab(shortcutEntity.url)
            }
            return
        }
        if (intent?.action == Intent.ACTION_VIEW) {
            val dataUrl = intent.dataString
            if (!dataUrl.isNullOrBlank()) {
                val openInNewTab = intent.getBooleanExtra(PwaShortcutHelper.EXTRA_OPEN_IN_NEW_TAB, false)
                if (openInNewTab) {
                    // Re-focus already live matching tab first so shortcuts don't reload or duplicate tabs
                    browserViewModel.webViewManager.focusOrOpenTab(dataUrl)
                } else {
                    browserViewModel.webViewManager.loadUrlInActiveTab(dataUrl)
                }
            }
        }
    }

    private fun startBrowserKeepAliveServiceOnly() {
        val tabCount = browserViewModel.webViewManager.tabsState.value.size.coerceAtLeast(1)
        BrowserService.startKeepAliveService(applicationContext, tabCount, PwaWebViewPool.liveCount())
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val hasNotifPerm = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!hasNotifPerm) {
                try {
                    startupPermissionsLauncher.launch(arrayOf(Manifest.permission.POST_NOTIFICATIONS))
                } catch (_: Exception) {
                }
            }
        }
    }

    private fun requestAllBrowserPermissions(openAppSettingsIfAlreadyRequested: Boolean) {
        refreshPermissionsState()
        val missing = DeviceAccessHelper.getMissingBrowserRuntimePermissions(this)
        if (missing.isNotEmpty()) {
            try {
                startupPermissionsLauncher.launch(missing)
            } catch (_: Exception) {
                if (openAppSettingsIfAlreadyRequested) {
                    BatteryHelper.openAppDetailsSettings(this)
                }
            }
        } else {
            android.widget.Toast.makeText(
                this,
                "All Camera, Microphone, Location & File Manager permissions are active",
                android.widget.Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun refreshPermissionsState() {
        permissionsStatus = DeviceAccessHelper.getPermissionsStatus(this)
    }

    private fun refreshBatteryOptimizationState() {
        isBatteryUnrestricted = BatteryHelper.isIgnoringBatteryOptimizations(this)
    }

    override fun onResume() {
        super.onResume()
        refreshBatteryOptimizationState()
        refreshPermissionsState()
        PwaWebViewPool.refreshStats(applicationContext)
        browserViewModel.webViewManager.attachActivity(this)
        BrowserService.startKeepAliveService(
            applicationContext,
            browserViewModel.webViewManager.tabsState.value.size,
            PwaWebViewPool.liveCount()
        )
    }

    override fun onPause() {
        super.onPause()
        // CRITICAL: Never call webView.onPause() or pauseTimers()!
        // Only flush cookies so Google login sessions persist safely across app switches.
        browserViewModel.webViewManager.flushCookiesNow()
    }

    override fun onStop() {
        super.onStop()
        browserViewModel.webViewManager.flushCookiesNow()
        BrowserService.startKeepAliveService(
            applicationContext,
            browserViewModel.webViewManager.tabsState.value.size,
            PwaWebViewPool.liveCount()
        )
    }

    override fun onDestroy() {
        browserViewModel.webViewManager.detachActivity(this)
        super.onDestroy()
    }
}
