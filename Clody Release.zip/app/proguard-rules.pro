# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.
#
# For more details, see
#   http://developer.android.com/guide/developing/tools/proguard.html

# If your project uses WebView with JS, uncomment the following
# and specify the fully qualified class name to the JavaScript interface
# class:
#-keepclassmembers class fqcn.of.javascript.interface.for.webview {
#   public *;
#}

# Preserve file name and line numbers for production release stack traces
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# TDLib JNI keep rules (native C++ reflections on Client and TdApi inner classes)
-dontwarn org.drinkless.tdlib.**
-keep class org.drinkless.tdlib.** { *; }
-keepclassmembers class org.drinkless.tdlib.** { *; }
-keep class org.drinkless.tdlib.TdApi$** { *; }
-keepclassmembers class org.drinkless.tdlib.Client {
    <fields>;
    <methods>;
}
-keepclassmembers class org.drinkless.tdlib.TdApi$** {
    <fields>;
    <init>(...);
    <methods>;
}
-keepclasseswithmembernames,includedescriptorclasses class * {
    native <methods>;
}

# Room & kotlinx.serialization models (including CloudIndexSnapshot & nested metadata)
-keep class com.example.data.local.** { *; }
-keepclassmembers class com.example.data.local.** { *; }
-keep class com.example.telegram.CloudIndexSnapshot { *; }
-keepclassmembers class com.example.telegram.CloudIndexSnapshot { *; }
-keep class com.example.telegram.CloudIndexSnapshot$** { *; }
-keep,includedescriptorclasses class *$$serializer { *; }
-keepclassmembers class * {
    *** Companion;
}
-keepclassmembers class * {
    kotlinx.serialization.KSerializer serializer(...);
}

# Media3 / ExoPlayer & MediaSession keep rules
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**
-keep class androidx.room.** { *; }
-dontwarn androidx.room.**

