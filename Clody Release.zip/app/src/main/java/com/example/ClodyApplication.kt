package com.example

import android.app.Application
import android.content.Context
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import com.example.data.local.ClodyDao
import com.example.data.local.ClodyDatabase
import com.example.data.local.SecureStorage
import com.example.data.local.SettingsRepository
import com.example.files.DeviceFileManager
import com.example.media.ClodyStreamCache
import com.example.service.ClodyPlaybackController
import com.example.service.TransferBatchTracker
import com.example.service.TransferManager
import com.example.telegram.TelegramClientManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class AppContainer(context: Context) {
    val applicationScope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    val database: ClodyDatabase = ClodyDatabase.getInstance(context)
    val dao: ClodyDao = database.clodyDao()
    val secureStorage: SecureStorage = SecureStorage(context)
    val settingsRepository: SettingsRepository = SettingsRepository(context)
    val telegramClient: TelegramClientManager = TelegramClientManager(context, secureStorage, dao)
    val telegramClientManager: TelegramClientManager get() = telegramClient
    val transferBatchTracker: TransferBatchTracker = TransferBatchTracker(dao)
    val transferManager: TransferManager = TransferManager(context, dao, telegramClient, settingsRepository, transferBatchTracker)
    val deviceFileManager: DeviceFileManager = DeviceFileManager(context)

    @Volatile
    var lastExternalShareLaunchMs: Long = 0L

    fun markExternalShareLaunched() {
        lastExternalShareLaunchMs = System.currentTimeMillis()
    }
}

class ClodyApplication : Application() {
    lateinit var container: AppContainer
        private set

    val applicationScope: CoroutineScope get() = container.applicationScope
    val database: ClodyDatabase get() = container.database
    val dao: ClodyDao get() = container.dao
    val secureStorage: SecureStorage get() = container.secureStorage
    val settingsRepository: SettingsRepository get() = container.settingsRepository
    val telegramClient: TelegramClientManager get() = container.telegramClient
    val telegramClientManager: TelegramClientManager get() = container.telegramClientManager
    val transferBatchTracker: TransferBatchTracker get() = container.transferBatchTracker
    val transferManager: TransferManager get() = container.transferManager
    val deviceFileManager: DeviceFileManager get() = container.deviceFileManager

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)

        runCatching {
            ProcessLifecycleOwner.get().lifecycle.addObserver(object : DefaultLifecycleObserver {
                override fun onStart(owner: LifecycleOwner) {
                    container.applicationScope.launch {
                        if (container.secureStorage.isLoggedIn()) {
                            runCatching { container.transferManager.resumeInterruptedUploadsOnAppOpen() }
                        }
                    }
                }

                override fun onStop(owner: LifecycleOwner) {
                    container.applicationScope.launch {
                        if (ClodyPlaybackController.shouldPreserveBackgroundPlayback()) {
                            return@launch
                        }
                        val settings = runCatching { container.settingsRepository.settingsFlow.first() }.getOrNull()
                            ?: return@launch
                        if (settings.zeroStorageMode || settings.autoDeleteCacheOnExit) {
                            val withinShareChooser =
                                System.currentTimeMillis() - container.lastExternalShareLaunchMs < 8_000L
                            val clearShare = settings.zeroStorageMode || !withinShareChooser
                            runCatching { container.telegramClient.clearAllTdMediaTempFiles() }
                            ClodyStreamCache.clearAllStreamCache(
                                context = this@ClodyApplication,
                                includeSharedCache = clearShare
                            )
                            runCatching { container.dao.clearAllLocalCachePaths() }
                        }
                    }
                }
            })
        }
    }
}
