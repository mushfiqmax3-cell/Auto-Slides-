package com.example

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.Display
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.service.ClodyMediaPlaybackService
import com.example.ui.ClodyApp

data class PlaybackNotificationNavigation(
    val fileId: Long,
    val isVideo: Boolean,
    val seq: Long
)

class MainActivity : ComponentActivity() {

    private var pendingPlaybackNavigation by mutableStateOf<PlaybackNotificationNavigation?>(null)
    private var navSeq by mutableLongStateOf(0L)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
        )
        enableEdgeToEdge()
        unlockNativeHighRefreshRate()
        extractPlaybackNavigation(intent)
        setContent {
            ClodyApp(
                notificationNavigation = pendingPlaybackNavigation,
                onConsumeNotificationNavigation = { pendingPlaybackNavigation = null }
            )
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        extractPlaybackNavigation(intent)
    }

    override fun onResume() {
        super.onResume()
        unlockNativeHighRefreshRate()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            unlockNativeHighRefreshRate()
        }
    }

    private fun extractPlaybackNavigation(intent: Intent?) {
        if (intent == null) return
        val openPlayer = intent.getBooleanExtra(ClodyMediaPlaybackService.EXTRA_OPEN_ACTIVE_PLAYER, false)
        if (openPlayer) {
            val fileId = intent.getLongExtra(ClodyMediaPlaybackService.EXTRA_OPEN_PLAYER_FILE_ID, -1L)
            val isVideo = intent.getBooleanExtra(ClodyMediaPlaybackService.EXTRA_OPEN_PLAYER_IS_VIDEO, false)
            if (fileId > 0L) {
                navSeq += 1L
                pendingPlaybackNavigation = PlaybackNotificationNavigation(
                    fileId = fileId,
                    isVideo = isVideo,
                    seq = navSeq
                )
            }
        }
    }

    private fun unlockNativeHighRefreshRate() {
        runCatching {
            val activeDisplay: Display? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                display
            } else {
                @Suppress("DEPRECATION")
                windowManager.defaultDisplay
            }
            val currentMode = activeDisplay?.mode ?: return
            val bestMode = activeDisplay.supportedModes
                .filter {
                    it.physicalWidth == currentMode.physicalWidth &&
                        it.physicalHeight == currentMode.physicalHeight
                }
                .maxByOrNull { it.refreshRate }
                ?: activeDisplay.supportedModes.maxByOrNull { it.refreshRate }

            if (bestMode != null) {
                val attrs = window.attributes
                var changed = false
                if (attrs.preferredDisplayModeId != bestMode.modeId) {
                    attrs.preferredDisplayModeId = bestMode.modeId
                    changed = true
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && attrs.preferredRefreshRate != bestMode.refreshRate) {
                    attrs.preferredRefreshRate = bestMode.refreshRate
                    changed = true
                }
                if (changed) {
                    window.attributes = attrs
                }
            }
        }
    }
}
