package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "clody_settings")

enum class ThemeMode {
    SYSTEM, LIGHT, DARK
}

enum class SortOption {
    DATE_DESC, NAME_ASC, SIZE_DESC
}

enum class PlaybackCacheMode {
    CACHE_MODE,
    NO_CACHE_MODE
}

enum class MaxCacheLimit(val label: String, val maxBytes: Long) {
    MB_500("500 MB", 500L * 1024L * 1024L),
    GB_1("1 GB", 1024L * 1024L * 1024L),
    GB_2("2 GB", 2L * 1024L * 1024L * 1024L),
    GB_5("5 GB", 5L * 1024L * 1024L * 1024L),
    UNLIMITED("Unlimited", Long.MAX_VALUE)
}

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.LIGHT,
    val dynamicColors: Boolean = false,
    val showHiddenFiles: Boolean = false,
    val showFileExtensions: Boolean = true,
    val useRecycleBin: Boolean = true,
    val confirmBeforeDeleting: Boolean = true,
    val uploadWifiOnly: Boolean = false,
    val autoBackupNewMedia: Boolean = false,
    val autoBackupOnlyWhileCharging: Boolean = false,
    val zeroStorageMode: Boolean = false,
    val autoDeleteCacheOnExit: Boolean = false,
    val gridViewFolders: Boolean = true,
    val sortOption: SortOption = SortOption.DATE_DESC,
    val syncedFolderUris: Set<String> = emptySet(),
    val dismissedBackupIds: Set<String> = emptySet()
)

class SettingsRepository(private val context: Context) {

    private object Keys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val DYNAMIC_COLORS = booleanPreferencesKey("dynamic_colors")
        val SHOW_HIDDEN_FILES = booleanPreferencesKey("show_hidden_files")
        val SHOW_FILE_EXTENSIONS = booleanPreferencesKey("show_file_extensions")
        val USE_RECYCLE_BIN = booleanPreferencesKey("use_recycle_bin")
        val CONFIRM_DELETE = booleanPreferencesKey("confirm_delete")
        val UPLOAD_WIFI_ONLY = booleanPreferencesKey("upload_wifi_only")
        val AUTO_BACKUP_NEW_MEDIA = booleanPreferencesKey("auto_backup_new_media")
        val AUTO_BACKUP_ONLY_CHARGING = booleanPreferencesKey("auto_backup_only_charging")
        val ZERO_STORAGE_MODE = booleanPreferencesKey("zero_storage_mode")
        val AUTO_DELETE_CACHE_ON_EXIT = booleanPreferencesKey("auto_delete_cache_on_exit")
        val GRID_VIEW_FOLDERS = booleanPreferencesKey("grid_view_folders")
        val SORT_OPTION = stringPreferencesKey("sort_option")
        val SYNCED_FOLDER_URIS = stringSetPreferencesKey("synced_folder_uris")
        val DISMISSED_BACKUP_IDS = stringSetPreferencesKey("dismissed_backup_ids")
    }

    val settingsFlow: Flow<AppSettings> = context.dataStore.data.map { prefs ->
        AppSettings(
            themeMode = prefs[Keys.THEME_MODE]?.let { runCatching { ThemeMode.valueOf(it) }.getOrNull() } ?: ThemeMode.LIGHT,
            dynamicColors = prefs[Keys.DYNAMIC_COLORS] ?: false,
            showHiddenFiles = prefs[Keys.SHOW_HIDDEN_FILES] ?: false,
            showFileExtensions = prefs[Keys.SHOW_FILE_EXTENSIONS] ?: true,
            useRecycleBin = prefs[Keys.USE_RECYCLE_BIN] ?: true,
            confirmBeforeDeleting = prefs[Keys.CONFIRM_DELETE] ?: true,
            uploadWifiOnly = prefs[Keys.UPLOAD_WIFI_ONLY] ?: false,
            autoBackupNewMedia = prefs[Keys.AUTO_BACKUP_NEW_MEDIA] ?: false,
            autoBackupOnlyWhileCharging = prefs[Keys.AUTO_BACKUP_ONLY_CHARGING] ?: false,
            zeroStorageMode = prefs[Keys.ZERO_STORAGE_MODE] ?: false,
            autoDeleteCacheOnExit = prefs[Keys.AUTO_DELETE_CACHE_ON_EXIT] ?: false,
            gridViewFolders = prefs[Keys.GRID_VIEW_FOLDERS] ?: true,
            sortOption = prefs[Keys.SORT_OPTION]?.let { runCatching { SortOption.valueOf(it) }.getOrNull() } ?: SortOption.DATE_DESC,
            syncedFolderUris = prefs[Keys.SYNCED_FOLDER_URIS] ?: emptySet(),
            dismissedBackupIds = prefs[Keys.DISMISSED_BACKUP_IDS] ?: emptySet()
        )
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.dataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    suspend fun setDynamicColors(enabled: Boolean) {
        context.dataStore.edit { it[Keys.DYNAMIC_COLORS] = enabled }
    }

    suspend fun setShowHiddenFiles(enabled: Boolean) {
        context.dataStore.edit { it[Keys.SHOW_HIDDEN_FILES] = enabled }
    }

    suspend fun setShowFileExtensions(enabled: Boolean) {
        context.dataStore.edit { it[Keys.SHOW_FILE_EXTENSIONS] = enabled }
    }

    suspend fun setUseRecycleBin(enabled: Boolean) {
        context.dataStore.edit { it[Keys.USE_RECYCLE_BIN] = enabled }
    }

    suspend fun setConfirmBeforeDeleting(enabled: Boolean) {
        context.dataStore.edit { it[Keys.CONFIRM_DELETE] = enabled }
    }

    suspend fun setUploadWifiOnly(enabled: Boolean) {
        context.dataStore.edit { it[Keys.UPLOAD_WIFI_ONLY] = enabled }
    }

    suspend fun setZeroStorageMode(enabled: Boolean) {
        context.dataStore.edit { it[Keys.ZERO_STORAGE_MODE] = enabled }
    }

    suspend fun setAutoDeleteCacheOnExit(enabled: Boolean) {
        context.dataStore.edit { it[Keys.AUTO_DELETE_CACHE_ON_EXIT] = enabled }
    }

    suspend fun setGridViewFolders(grid: Boolean) {
        context.dataStore.edit { it[Keys.GRID_VIEW_FOLDERS] = grid }
    }

    suspend fun setSortOption(option: SortOption) {
        context.dataStore.edit { it[Keys.SORT_OPTION] = option.name }
    }

    suspend fun addSyncedFolderUri(uri: String) {
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.SYNCED_FOLDER_URIS] ?: emptySet()
            prefs[Keys.SYNCED_FOLDER_URIS] = current + uri
        }
    }

    suspend fun removeSyncedFolderUri(uri: String) {
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.SYNCED_FOLDER_URIS] ?: emptySet()
            prefs[Keys.SYNCED_FOLDER_URIS] = current - uri
        }
    }

    suspend fun addDismissedBackupIds(ids: Set<String>) {
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.DISMISSED_BACKUP_IDS] ?: emptySet()
            prefs[Keys.DISMISSED_BACKUP_IDS] = current + ids
        }
    }
}
