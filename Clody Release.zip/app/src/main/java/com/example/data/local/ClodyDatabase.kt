package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        FolderEntity::class,
        GalleryAlbumEntity::class,
        FileEntity::class,
        FileFtsEntity::class,
        UploadTaskEntity::class,
        DownloadRecordEntity::class
    ],
    version = 5,
    exportSchema = false
)
abstract class ClodyDatabase : RoomDatabase() {
    abstract fun clodyDao(): ClodyDao

    companion object {
        @Volatile
        private var INSTANCE: ClodyDatabase? = null

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE files ADD COLUMN localSourceUri TEXT")
            }
        }

        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE files ADD COLUMN albumId INTEGER")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_files_albumId ON files(albumId)")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS gallery_albums (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        name TEXT NOT NULL,
                        coverThumbnailPath TEXT,
                        createdAt INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
            }
        }

        private val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE files ADD COLUMN miniThumbnailBase64 TEXT")
                db.execSQL("ALTER TABLE files ADD COLUMN isPinnedOffline INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE files ADD COLUMN pinnedOfflinePath TEXT")
                db.execSQL("ALTER TABLE files ADD COLUMN isLockedVault INTEGER NOT NULL DEFAULT 0")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_files_sha256 ON files(sha256)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_files_isLockedVault ON files(isLockedVault)")
            }
        }

        private val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE upload_tasks ADD COLUMN tdFileId INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE upload_tasks ADD COLUMN stagedFilePath TEXT")
                db.execSQL("ALTER TABLE upload_tasks ADD COLUMN pausedBySystem INTEGER NOT NULL DEFAULT 0")
            }
        }

        fun getInstance(context: Context): ClodyDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    ClodyDatabase::class.java,
                    "clody_database.db"
                )
                    .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5)
                    .fallbackToDestructiveMigration(true)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
