package com.example.data.local

import androidx.compose.runtime.Immutable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Fts4
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Immutable
@Serializable
@Entity(
    tableName = "folders",
    indices = [Index(value = ["parentId"])]
)
data class FolderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val parentId: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val isFavorite: Boolean = false
)

@Immutable
@Serializable
@Entity(
    tableName = "gallery_albums",
    indices = [Index(value = ["createdAt"])]
)
data class GalleryAlbumEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val coverThumbnailPath: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Immutable
@Serializable
@Entity(
    tableName = "files",
    indices = [
        Index(value = ["folderId"]),
        Index(value = ["albumId"]),
        Index(value = ["telegramMessageId"]),
        Index(value = ["isDeleted"]),
        Index(value = ["sha256"]),
        Index(value = ["isLockedVault"])
    ]
)
data class FileEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val extension: String,
    val sizeBytes: Long,
    val mimeType: String,
    val folderId: Long? = null,
    val folderPath: String = "Cloud",
    val albumId: Long? = null,
    val telegramMessageId: Int = 0,
    val telegramDocumentId: Long = 0L,
    val telegramAccessHash: Long = 0L,
    val telegramFileReferenceHex: String = "",
    val telegramDcId: Int = 2,
    val durationMs: Long = 0L,
    val thumbnailPath: String? = null,
    val customThumbnailPath: String? = null,
    val miniThumbnailBase64: String? = null,
    val localCachePath: String? = null,
    val localSourceUri: String? = null,
    val isPinnedOffline: Boolean = false,
    val pinnedOfflinePath: String? = null,
    val isLockedVault: Boolean = false,
    val isFavorite: Boolean = false,
    val isDeleted: Boolean = false,
    val deletedAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val sha256: String = ""
) {
    val sha256Hash: String
        get() = sha256

    val activeThumbnailPath: String?
        get() = customThumbnailPath?.takeIf { it.isNotBlank() } ?: thumbnailPath

    val extLower: String
        get() = extension.lowercase().ifBlank { name.substringAfterLast('.', "").lowercase() }

    val isImage: Boolean
        get() = mimeType.startsWith("image/")

    val isVideo: Boolean
        get() = mimeType.startsWith("video/")

    val isAudio: Boolean
        get() = mimeType.startsWith("audio/") || extLower in setOf("mp3", "m4a", "wav", "ogg", "flac", "aac", "opus")

    val isPdf: Boolean
        get() = extLower == "pdf" || mimeType == "application/pdf"

    val isWordDoc: Boolean
        get() = extLower in setOf("docx", "rtf") ||
            mimeType == "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ||
            mimeType == "application/rtf" ||
            mimeType == "text/rtf"

    val isSpreadsheet: Boolean
        get() = extLower in setOf("xlsx", "xls", "csv") ||
            mimeType == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" ||
            mimeType == "application/vnd.ms-excel" ||
            mimeType == "text/csv"

    val isTextOrCode: Boolean
        get() = mimeType.startsWith("text/") || extLower in setOf(
            "txt", "md", "markdown", "json", "xml", "log", "html", "htm", "css",
            "js", "ts", "jsx", "tsx", "py", "kt", "kts", "java", "yaml", "yml",
            "ini", "conf", "sh", "sql", "gradle", "properties"
        )

    val isInAppDocument: Boolean
        get() = isPdf || isWordDoc || isSpreadsheet || isTextOrCode

    val isDocument: Boolean
        get() = isInAppDocument ||
            mimeType.contains("document") ||
            mimeType.contains("word") ||
            mimeType.contains("excel") ||
            mimeType.contains("powerpoint") ||
            extLower in setOf("doc", "ppt", "pptx")

    val isArchive: Boolean
        get() = extLower in setOf("zip", "7z", "tar", "gz", "rar")

    val isApp: Boolean
        get() = extLower == "apk" || mimeType == "application/vnd.android.package-archive"
}

@Immutable
@Fts4(contentEntity = FileEntity::class)
@Entity(tableName = "files_fts")
data class FileFtsEntity(
    @PrimaryKey @ColumnInfo(name = "rowid") val rowId: Long,
    val name: String,
    val extension: String,
    val folderPath: String
)

enum class UploadStatus {
    QUEUED,
    UPLOADING,
    PAUSED,
    COMPLETED,
    FAILED,
    CANCELLED
}

@Immutable
@Entity(tableName = "upload_tasks")
data class UploadTaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fileName: String,
    val localUriString: String,
    val mimeType: String,
    val sizeBytes: Long,
    val durationMs: Long = 0L,
    val folderId: Long? = null,
    val folderPath: String = "Cloud",
    val extractedThumbnailPath: String? = null,
    val customThumbnailPath: String? = null,
    val bytesUploaded: Long = 0L,
    val speedBytesPerSec: Long = 0L,
    val status: String = UploadStatus.QUEUED.name,
    val errorMessage: String? = null,
    val tdFileId: Int = 0,
    val stagedFilePath: String? = null,
    val pausedBySystem: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Immutable
@Entity(tableName = "download_records")
data class DownloadRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fileId: Long,
    val fileName: String,
    val sizeBytes: Long,
    val mimeType: String,
    val publicUriString: String = "",
    val publicPath: String = "",
    val status: String = "DOWNLOADING",
    val progressBytes: Long = 0L,
    val createdAt: Long = System.currentTimeMillis()
)
