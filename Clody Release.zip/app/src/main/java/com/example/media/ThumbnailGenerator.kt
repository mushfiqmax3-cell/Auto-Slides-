package com.example.media

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.ImageBitmapConfig
import androidx.compose.ui.graphics.asImageBitmap
import com.example.data.local.FileEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import kotlin.math.roundToInt

data class ExtractedMediaMetadata(
    val thumbnailPath: String?,
    val durationMs: Long
)

object ThumbnailGenerator {

    private const val MAX_WIDTH_PX = 320
    private const val TARGET_MAX_BYTES = 25 * 1024 // ~15-25 KB lightweight preview

    // Heap-bounded (~1/8th max app heap) in-memory LRU bitmap cache for zero-GC-jitter fast scrolling
    internal val maxMemoryCacheKb: Int =
        ((Runtime.getRuntime().maxMemory() / 1024L) / 8L).toInt().coerceAtLeast(4096)

    private val memoryBitmapCache = object : LruCache<String, ImageBitmap>(maxMemoryCacheKb) {
        override fun sizeOf(key: String, value: ImageBitmap): Int {
            val bytesPerPixel = if (value.config == ImageBitmapConfig.Rgb565) 2L else 4L
            return ((value.width.toLong() * value.height.toLong() * bytesPerPixel) / 1024L)
                .toInt()
                .coerceAtLeast(1)
        }
    }

    fun getMemoryCacheMaxSizeKb(): Int = memoryBitmapCache.maxSize()

    fun getMemoryCacheCurrentSizeKb(): Int = memoryBitmapCache.size()

    fun calculateInSampleSize(
        srcWidth: Int,
        srcHeight: Int,
        reqWidth: Int,
        reqHeight: Int
    ): Int {
        var inSampleSize = 1
        if (srcHeight > reqHeight || srcWidth > reqWidth) {
            val halfHeight = srcHeight / 2
            val halfWidth = srcWidth / 2
            while ((halfHeight / inSampleSize) >= reqHeight && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2
            }
        }
        return inSampleSize.coerceAtLeast(1)
    }

    /**
     * Persistent thumbnail directory inside filesDir (separate from temporary stream cache
     * in cacheDir/tdlib_files so thumbnails survive stream cache clearing).
     */
    fun getThumbnailsDir(context: Context): File {
        return File(context.filesDir, "thumbnails").apply { mkdirs() }
    }

    fun getPersistentThumbnailFile(context: Context, file: FileEntity): File {
        val uniqueKey = when {
            file.telegramAccessHash != 0L -> "msg_${file.telegramAccessHash}"
            file.telegramDocumentId != 0L -> "doc_${file.telegramDocumentId}"
            else -> "file_${file.id}"
        }
        return File(getThumbnailsDir(context), "td_thumb_$uniqueKey.jpg")
    }

    fun getFromMemoryCache(key: String): ImageBitmap? {
        return memoryBitmapCache.get(key)
    }

    suspend fun decodeBitmapAsync(path: String, maxSizePx: Int = MAX_WIDTH_PX): ImageBitmap? {
        val cacheKey = if (maxSizePx == MAX_WIDTH_PX) path else "${path}@${maxSizePx}"
        memoryBitmapCache.get(cacheKey)?.let { return it }
        return withContext(Dispatchers.IO) {
            memoryBitmapCache.get(cacheKey)?.let { return@withContext it }
            val file = File(path)
            if (!file.exists() || !file.isFile || file.length() <= 0L) return@withContext null
            runCatching {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(path, bounds)
                val w = bounds.outWidth
                val h = bounds.outHeight
                if (w <= 0 || h <= 0) return@withContext null

                val sampleSize = calculateInSampleSize(w, h, maxSizePx, maxSizePx)
                val decodeOpts = BitmapFactory.Options().apply {
                    inSampleSize = sampleSize
                    inPreferredConfig = Bitmap.Config.RGB_565
                }
                val bmp = BitmapFactory.decodeFile(path, decodeOpts) ?: return@withContext null
                val imageBitmap = bmp.asImageBitmap()
                memoryBitmapCache.put(cacheKey, imageBitmap)
                imageBitmap
            }.getOrNull()
        }
    }

    suspend fun decodeBytesAsync(
        cacheKey: String,
        bytes: ByteArray,
        maxSizePx: Int = MAX_WIDTH_PX
    ): ImageBitmap? {
        if (bytes.isEmpty()) return null
        memoryBitmapCache.get(cacheKey)?.let { return it }
        return withContext(Dispatchers.IO) {
            memoryBitmapCache.get(cacheKey)?.let { return@withContext it }
            runCatching {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
                val sampleSize = if (bounds.outWidth > 0 && bounds.outHeight > 0) {
                    calculateInSampleSize(bounds.outWidth, bounds.outHeight, maxSizePx, maxSizePx)
                } else 1
                val opts = BitmapFactory.Options().apply {
                    inSampleSize = sampleSize
                    inPreferredConfig = Bitmap.Config.RGB_565
                }
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
                    ?: return@withContext null
                val imageBitmap = bmp.asImageBitmap()
                memoryBitmapCache.put(cacheKey, imageBitmap)
                imageBitmap
            }.getOrNull()
        }
    }

    /**
     * Extracts embedded ID3 cover artwork on Dispatchers.IO from a local file or content URI
     * using Android's [MediaMetadataRetriever] with safe inSampleSize bounds.
     */
    suspend fun extractEmbeddedAudioCoverAsync(
        context: Context,
        filePath: String?,
        contentUri: Uri?,
        cacheKey: String,
        maxSizePx: Int = 512
    ): ImageBitmap? {
        memoryBitmapCache.get(cacheKey)?.let { return it }
        return withContext(Dispatchers.IO) {
            memoryBitmapCache.get(cacheKey)?.let { return@withContext it }
            val retriever = MediaMetadataRetriever()
            try {
                var configured = false
                if (!filePath.isNullOrBlank()) {
                    val f = File(filePath)
                    if (f.exists() && f.length() > 0L) {
                        retriever.setDataSource(f.absolutePath)
                        configured = true
                    }
                }
                if (!configured && contentUri != null) {
                    retriever.setDataSource(context, contentUri)
                    configured = true
                }
                if (!configured) return@withContext null

                val artBytes = retriever.embeddedPicture
                if (artBytes == null || artBytes.isEmpty()) return@withContext null

                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(artBytes, 0, artBytes.size, bounds)
                val w = bounds.outWidth
                val h = bounds.outHeight
                if (w <= 0 || h <= 0) return@withContext null

                val sampleSize = calculateInSampleSize(w, h, maxSizePx, maxSizePx)
                val opts = BitmapFactory.Options().apply {
                    inSampleSize = sampleSize
                    inPreferredConfig = Bitmap.Config.RGB_565
                }
                val bmp = BitmapFactory.decodeByteArray(artBytes, 0, artBytes.size, opts)
                    ?: return@withContext null
                val imageBitmap = bmp.asImageBitmap()
                memoryBitmapCache.put(cacheKey, imageBitmap)
                imageBitmap
            } catch (_: Throwable) {
                null
            } finally {
                runCatching { retriever.release() }
            }
        }
    }

    /**
     * Loads a compact downsampled Android [Bitmap] (max 256px) for media playback notifications.
     */
    suspend fun loadNotificationArtworkBitmap(
        context: Context,
        file: FileEntity,
        maxSizePx: Int = 256
    ): Bitmap? = withContext(Dispatchers.IO) {
        val existingThumb = resolveExistingThumbnailPath(context, file)
        if (existingThumb != null) {
            decodeFileToAndroidBitmap(existingThumb, maxSizePx)?.let { return@withContext it }
        }
        if (file.isAudio) {
            val localPath = file.pinnedOfflinePath?.takeIf { File(it).exists() }
                ?: file.localCachePath?.takeIf { File(it).exists() }
            val localUri = file.localSourceUri?.takeIf { it.isNotBlank() }?.let { runCatching { Uri.parse(it) }.getOrNull() }
            val retriever = MediaMetadataRetriever()
            try {
                var configured = false
                if (!localPath.isNullOrBlank()) {
                    retriever.setDataSource(localPath)
                    configured = true
                } else if (localUri != null) {
                    retriever.setDataSource(context, localUri)
                    configured = true
                }
                if (configured) {
                    val artBytes = retriever.embeddedPicture
                    if (artBytes != null && artBytes.isNotEmpty()) {
                        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        BitmapFactory.decodeByteArray(artBytes, 0, artBytes.size, bounds)
                        val sample = if (bounds.outWidth > 0 && bounds.outHeight > 0) {
                            calculateInSampleSize(bounds.outWidth, bounds.outHeight, maxSizePx, maxSizePx)
                        } else 1
                        val opts = BitmapFactory.Options().apply {
                            inSampleSize = sample
                            inPreferredConfig = Bitmap.Config.RGB_565
                        }
                        return@withContext BitmapFactory.decodeByteArray(artBytes, 0, artBytes.size, opts)
                    }
                }
            } catch (_: Throwable) {
            } finally {
                runCatching { retriever.release() }
            }
        }
        null
    }

    private fun decodeFileToAndroidBitmap(path: String, maxSizePx: Int): Bitmap? {
        val f = File(path)
        if (!f.exists() || f.length() <= 0L) return null
        return runCatching {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, bounds)
            val w = bounds.outWidth
            val h = bounds.outHeight
            if (w <= 0 || h <= 0) return null
            val opts = BitmapFactory.Options().apply {
                inSampleSize = calculateInSampleSize(w, h, maxSizePx, maxSizePx)
                inPreferredConfig = Bitmap.Config.RGB_565
            }
            BitmapFactory.decodeFile(path, opts)
        }.getOrNull()
    }

    suspend fun resolveExistingThumbnailPath(context: Context, file: FileEntity): String? =
        withContext(Dispatchers.IO) {
            val active = file.activeThumbnailPath?.takeIf { it.isNotBlank() }
            if (active != null) {
                val activeFile = File(active)
                if (activeFile.exists() && activeFile.length() > 0L) {
                    return@withContext activeFile.absolutePath
                }
            }
            val persistent = getPersistentThumbnailFile(context, file)
            if (persistent.exists() && persistent.length() > 0L) {
                return@withContext persistent.absolutePath
            }
            null
        }

    suspend fun generateForUri(
        context: Context,
        uri: Uri,
        mimeType: String,
        uniqueKey: String
    ): ExtractedMediaMetadata = withContext(Dispatchers.IO) {
        val outFile = File(getThumbnailsDir(context), "thumb_${uniqueKey.hashCode()}.jpg")
        if (mimeType.startsWith("video/")) {
            extractVideoFrameAndDuration(context, uri, outFile)
        } else if (mimeType.startsWith("image/")) {
            val path = compressImageUri(context, uri, outFile)
            ExtractedMediaMetadata(path, 0L)
        } else {
            ExtractedMediaMetadata(null, 0L)
        }
    }

    suspend fun saveCustomThumbnail(
        context: Context,
        imageUri: Uri,
        uniqueKey: String
    ): String? = withContext(Dispatchers.IO) {
        val outFile = File(getThumbnailsDir(context), "custom_${uniqueKey.hashCode()}_${System.currentTimeMillis()}.jpg")
        compressImageUri(context, imageUri, outFile)
    }

    private fun extractVideoFrameAndDuration(
        context: Context,
        uri: Uri,
        outFile: File
    ): ExtractedMediaMetadata {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, uri)
            val durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            val durationMs = durationStr?.toLongOrNull() ?: 0L
            val targetTimeUs = if (durationMs > 1200L) 1_000_000L else 0L
            val frame = retriever.getFrameAtTime(targetTimeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: retriever.getFrameAtTime(0L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
            val thumbPath = frame?.let { bmp ->
                val saved = writeScaledCompressedJpeg(bmp, outFile)
                bmp.recycle()
                saved
            }
            ExtractedMediaMetadata(thumbPath, durationMs)
        } catch (_: Exception) {
            ExtractedMediaMetadata(null, 0L)
        } finally {
            runCatching { retriever.release() }
        }
    }

    private fun compressImageUri(
        context: Context,
        uri: Uri,
        outFile: File
    ): String? {
        return try {
            val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, boundsOpts)
            }
            val srcW = boundsOpts.outWidth
            val srcH = boundsOpts.outHeight
            if (srcW <= 0 || srcH <= 0) return null

            val sampleSize = calculateInSampleSize(srcW, srcH, MAX_WIDTH_PX, MAX_WIDTH_PX)

            val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sampleSize }
            val decoded = context.contentResolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, decodeOpts)
            } ?: return null

            val path = writeScaledCompressedJpeg(decoded, outFile)
            decoded.recycle()
            path
        } catch (_: Exception) {
            null
        }
    }

    private fun writeScaledCompressedJpeg(bitmap: Bitmap, outFile: File): String? {
        val scale = if (bitmap.width > MAX_WIDTH_PX) {
            MAX_WIDTH_PX.toFloat() / bitmap.width.toFloat()
        } else 1f
        val targetW = maxOf(1, (bitmap.width * scale).roundToInt())
        val targetH = maxOf(1, (bitmap.height * scale).roundToInt())
        val scaled = if (scale < 1f) {
            Bitmap.createScaledBitmap(bitmap, targetW, targetH, true)
        } else {
            bitmap
        }

        val baos = ByteArrayOutputStream()
        var quality = 82
        while (quality >= 35) {
            baos.reset()
            scaled.compress(Bitmap.CompressFormat.JPEG, quality, baos)
            if (baos.size() <= TARGET_MAX_BYTES) break
            quality -= 12
        }

        FileOutputStream(outFile).use { fos ->
            fos.write(baos.toByteArray())
            fos.flush()
        }
        if (scaled !== bitmap) scaled.recycle()
        return outFile.absolutePath
    }
}
