package com.example.media

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CollectionsBookmark
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ClodyApplication
import com.example.data.local.FileEntity
import com.example.data.local.MaxCacheLimit
import com.example.data.local.PlaybackCacheMode
import com.example.telegram.TelegramClientManager
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.FavoriteGold
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun ImageViewerScreen(
    file: FileEntity,
    mediaList: List<FileEntity> = listOf(file),
    initialIndex: Int = mediaList.indexOfFirst { it.id == file.id }.coerceAtLeast(0),
    telegramClient: TelegramClientManager,
    zeroStorageMode: Boolean,
    onDownloadToGallery: (FileEntity) -> Unit,
    onToggleFavorite: (FileEntity) -> Unit,
    onAddToAlbum: (FileEntity) -> Unit,
    onShare: (FileEntity, File?) -> Unit,
    onDelete: (FileEntity) -> Unit,
    onOpenVideo: (FileEntity) -> Unit = {},
    onBack: () -> Unit,
    onCacheMutated: () -> Unit = {}
) {
    val context = LocalContext.current
    val effectiveList = remember(mediaList, file) {
        if (mediaList.isEmpty()) listOf(file) else mediaList
    }
    val safeInitial = remember(initialIndex, effectiveList.size) {
        initialIndex.coerceIn(0, (effectiveList.size - 1).coerceAtLeast(0))
    }
    val pagerState = rememberPagerState(
        initialPage = safeInitial,
        pageCount = { effectiveList.size }
    )

    var hudVisible by remember { mutableStateOf(true) }
    val pageScales = remember { mutableStateMapOf<Long, Float>() }
    val resolvedFullFiles = remember { mutableStateMapOf<Long, File>() }
    val resolvedOrigins = remember { mutableStateMapOf<Long, MediaPlaybackOrigin>() }

    val currentItem = effectiveList.getOrNull(pagerState.currentPage) ?: file
    val currentScale = pageScales[currentItem.id] ?: 1f

    val currentResolvedSource = remember(
        currentItem.id,
        currentItem.localSourceUri,
        currentItem.isPinnedOffline,
        currentItem.pinnedOfflinePath,
        currentItem.localCachePath,
        zeroStorageMode
    ) {
        LocalFirstResolver.resolve(context, currentItem, ignoreStreamCache = zeroStorageMode)
    }
    val currentOrigin = resolvedOrigins[currentItem.id] ?: currentResolvedSource.origin
    val currentFullFile = resolvedFullFiles[currentItem.id] ?: when (currentResolvedSource) {
        is ResolvedMediaSource.LocalDevice -> currentResolvedSource.directFile
        is ResolvedMediaSource.CloudStream -> currentResolvedSource.cachedOrPinnedFile
    }

    BackHandler(onBack = onBack)

    // Zero-Storage Mode: immediately purge previous photo cache when swiping to another page
    var lastViewedItem by remember { mutableStateOf<FileEntity?>(null) }
    LaunchedEffect(pagerState.currentPage, zeroStorageMode) {
        val prev = lastViewedItem
        val current = effectiveList.getOrNull(pagerState.currentPage)
        if (zeroStorageMode && prev != null && current != null && prev.id != current.id) {
            val prevOrigin = resolvedOrigins[prev.id]
                ?: LocalFirstResolver.resolve(context, prev, ignoreStreamCache = true).origin
            if (prevOrigin != MediaPlaybackOrigin.LOCAL_DEVICE && prevOrigin != MediaPlaybackOrigin.PINNED_OFFLINE) {
                resolvedFullFiles.remove(prev.id)
                LocalFirstResolver.cleanupTempLocalCopies(context, prev.id)
                ClodyStreamCache.deleteFileCache(context, prev)
                launch(Dispatchers.IO) {
                    runCatching { telegramClient.deleteTdFileCache(prev) }
                    ClodyStreamCache.deleteFileCache(context.applicationContext, prev)
                    onCacheMutated()
                }
            }
        }
        lastViewedItem = current
    }

    // Prefetch adjacent pages (currentPage - 1 and currentPage + 1) into private app cache
    LaunchedEffect(pagerState.currentPage, effectiveList, zeroStorageMode) {
        if (zeroStorageMode) return@LaunchedEffect
        val neighbors = listOf(pagerState.currentPage - 1, pagerState.currentPage + 1)
            .filter { it in effectiveList.indices }
            .map { effectiveList[it] }
            .filter { !it.isVideo && it.telegramDocumentId != 0L && resolvedFullFiles[it.id] == null }

        neighbors.forEach { neighbor ->
            launch(Dispatchers.IO) {
                val src = LocalFirstResolver.resolve(context, neighbor)
                if (src is ResolvedMediaSource.CloudStream && src.cachedOrPinnedFile == null) {
                    runCatching {
                        LocalFirstResolver.loadToReadableFile(
                            context = context,
                            telegramClient = telegramClient,
                            file = neighbor,
                            cacheMode = PlaybackCacheMode.CACHE_MODE,
                            maxCacheLimit = MaxCacheLimit.GB_1
                        )
                    }.onSuccess { (cached, orig) ->
                        resolvedFullFiles[neighbor.id] = cached
                        resolvedOrigins[neighbor.id] = orig
                    }
                }
            }
        }
    }

    DisposableEffect(zeroStorageMode) {
        onDispose {
            resolvedFullFiles.keys.forEach { id ->
                LocalFirstResolver.cleanupTempLocalCopies(context, id)
            }
            if (zeroStorageMode) {
                val itemsToClean = effectiveList.filter { item ->
                    val orig = resolvedOrigins[item.id]
                        ?: LocalFirstResolver.resolve(context, item, ignoreStreamCache = true).origin
                    orig != MediaPlaybackOrigin.LOCAL_DEVICE &&
                        orig != MediaPlaybackOrigin.PINNED_OFFLINE &&
                        (resolvedFullFiles.containsKey(item.id) || item.id == currentItem.id)
                }
                itemsToClean.forEach { item ->
                    LocalFirstResolver.cleanupTempLocalCopies(context, item.id)
                    ClodyStreamCache.deleteFileCache(context, item)
                }
                val appScope = (context.applicationContext as? ClodyApplication)?.applicationScope
                    ?: CoroutineScope(SupervisorJob() + Dispatchers.IO)
                appScope.launch {
                    itemsToClean.forEach { item ->
                        runCatching { telegramClient.deleteTdFileCache(item) }
                        ClodyStreamCache.deleteFileCache(context.applicationContext, item)
                    }
                    onCacheMutated()
                }
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        HorizontalPager(
            state = pagerState,
            beyondViewportPageCount = 1,
            userScrollEnabled = currentScale <= 1.02f,
            key = { page -> effectiveList.getOrNull(page)?.id ?: page.toLong() },
            modifier = Modifier
                .fillMaxSize()
                .testTag("image_viewer_pager")
        ) { page ->
            val item = effectiveList[page]
            if (item.isVideo) {
                PagerVideoSlide(
                    file = item,
                    telegramClient = telegramClient,
                    onToggleHud = { hudVisible = !hudVisible },
                    onPlayVideo = { onOpenVideo(item) }
                )
            } else {
                PagerImageSlide(
                    file = item,
                    telegramClient = telegramClient,
                    zeroStorageMode = zeroStorageMode,
                    preloadedFile = resolvedFullFiles[item.id],
                    onResolved = { loadedFile, loadedOrigin ->
                        if (loadedFile != null) resolvedFullFiles[item.id] = loadedFile
                        resolvedOrigins[item.id] = loadedOrigin
                    },
                    onScaleChanged = { newScale -> pageScales[item.id] = newScale },
                    onToggleHud = { hudVisible = !hudVisible }
                )
            }
        }

        AnimatedVisibility(
            visible = hudVisible,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.Black.copy(alpha = 0.58f))
                        .statusBarsPadding()
                        .padding(horizontal = 8.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = currentItem.name,
                            color = Color.White,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 15.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (effectiveList.size > 1) {
                            Text(
                                text = "${pagerState.currentPage + 1} / ${effectiveList.size}",
                                color = Color.White.copy(alpha = 0.72f),
                                fontSize = 11.sp
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    PlaybackOriginPill(origin = currentOrigin, darkSurface = true)
                    IconButton(
                        onClick = { onToggleFavorite(currentItem) },
                        modifier = Modifier.testTag("image_viewer_favorite_button")
                    ) {
                        Icon(
                            imageVector = if (currentItem.isFavorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                            contentDescription = if (currentItem.isFavorite) "Remove from Favorites" else "Add to Favorites",
                            tint = if (currentItem.isFavorite) CrimsonAlert else Color.White
                        )
                    }
                }

                Surface(
                    color = Color(0xFF141414).copy(alpha = 0.92f),
                    shape = RoundedCornerShape(28.dp),
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .navigationBarsPadding()
                        .padding(bottom = 20.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        DownloadOrSavedPill(
                            origin = currentOrigin,
                            onDownloadClick = { onDownloadToGallery(currentItem) },
                            darkMode = true
                        )
                        IconButton(
                            onClick = { onAddToAlbum(currentItem) },
                            modifier = Modifier.testTag("image_viewer_album_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.CollectionsBookmark,
                                contentDescription = "Add to Album",
                                tint = if (currentItem.albumId != null) FavoriteGold else Color.White
                            )
                        }
                        IconButton(
                            onClick = { onShare(currentItem, currentFullFile) },
                            modifier = Modifier.testTag("image_viewer_share_button")
                        ) {
                            Icon(Icons.Default.Share, contentDescription = "Share", tint = Color.White)
                        }
                        IconButton(
                            onClick = { onDelete(currentItem) },
                            modifier = Modifier.testTag("image_viewer_delete_button")
                        ) {
                            Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = Color.White)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PagerImageSlide(
    file: FileEntity,
    telegramClient: TelegramClientManager,
    zeroStorageMode: Boolean,
    preloadedFile: File?,
    onResolved: (File?, MediaPlaybackOrigin) -> Unit,
    onScaleChanged: (Float) -> Unit,
    onToggleHud: () -> Unit
) {
    val context = LocalContext.current
    val resolvedSource = remember(
        file.id,
        file.localSourceUri,
        file.isPinnedOffline,
        file.pinnedOfflinePath,
        file.localCachePath,
        zeroStorageMode
    ) {
        LocalFirstResolver.resolve(context, file, ignoreStreamCache = zeroStorageMode)
    }

    var fullResFile by remember(file.id, preloadedFile) {
        mutableStateOf(
            preloadedFile ?: when (resolvedSource) {
                is ResolvedMediaSource.LocalDevice -> resolvedSource.directFile
                is ResolvedMediaSource.CloudStream -> resolvedSource.cachedOrPinnedFile
            }
        )
    }
    var origin by remember(file.id, resolvedSource) { mutableStateOf(resolvedSource.origin) }
    var miniBitmap by remember(file.id) {
        mutableStateOf<ImageBitmap?>(
            if (file.telegramAccessHash != 0L) {
                ThumbnailGenerator.getFromMemoryCache("mini_${file.telegramAccessHash}")
            } else null
        )
    }
    var thumbFile by remember(file.id, file.activeThumbnailPath) {
        mutableStateOf(file.activeThumbnailPath?.let(::File)?.takeIf(File::exists))
    }
    var isLoadingFullRes by remember(file.id) {
        mutableStateOf(
            resolvedSource is ResolvedMediaSource.CloudStream &&
                fullResFile == null &&
                file.telegramDocumentId != 0L
        )
    }
    var loadError by remember(file.id) { mutableStateOf<String?>(null) }

    var scale by remember(file.id) { mutableFloatStateOf(1f) }
    var offset by remember(file.id) { mutableStateOf(Offset.Zero) }

    LaunchedEffect(preloadedFile) {
        if (preloadedFile != null && fullResFile == null) {
            fullResFile = preloadedFile
            isLoadingFullRes = false
        }
    }

    // Decode immediate minithumbnail/local thumbnail and stream HD image into private cache
    LaunchedEffect(file.id, zeroStorageMode) {
        if (thumbFile == null) {
            val resolvedThumb = ThumbnailGenerator.resolveExistingThumbnailPath(context, file)
            if (resolvedThumb != null) {
                thumbFile = File(resolvedThumb)
            }
        }
        if (miniBitmap == null && file.telegramAccessHash != 0L) {
            val miniBytes = telegramClient.getCachedOrFetchMinithumbnail(file)
            if (miniBytes != null && miniBytes.isNotEmpty()) {
                miniBitmap = ThumbnailGenerator.decodeBytesAsync("mini_${file.telegramAccessHash}", miniBytes)
            }
        }
        if (resolvedSource is ResolvedMediaSource.CloudStream && fullResFile == null && file.telegramDocumentId != 0L) {
            isLoadingFullRes = true
            val mode = if (zeroStorageMode) PlaybackCacheMode.NO_CACHE_MODE else PlaybackCacheMode.CACHE_MODE
            runCatching {
                LocalFirstResolver.loadToReadableFile(
                    context = context,
                    telegramClient = telegramClient,
                    file = file,
                    cacheMode = mode
                )
            }.onSuccess { (cached, newOrigin) ->
                fullResFile = cached
                origin = newOrigin
                isLoadingFullRes = false
                onResolved(cached, newOrigin)
            }.onFailure { err ->
                loadError = err.message
                isLoadingFullRes = false
                if (thumbFile == null && file.telegramAccessHash != 0L) {
                    val target = ThumbnailGenerator.getPersistentThumbnailFile(context, file)
                    val thumb = telegramClient.downloadThumbnailWithSemaphore(file, target)
                    if (thumb != null) thumbFile = thumb
                }
            }
        } else if (fullResFile != null) {
            onResolved(fullResFile, origin)
        }
    }

    val modelToDisplay: Any? = when (resolvedSource) {
        is ResolvedMediaSource.LocalDevice -> resolvedSource.uri
        is ResolvedMediaSource.CloudStream -> fullResFile ?: thumbFile
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(file.id) {
                detectTapGestures(
                    onTap = { onToggleHud() },
                    onDoubleTap = {
                        if (scale > 1.02f) {
                            scale = 1f
                            offset = Offset.Zero
                            onScaleChanged(1f)
                        } else {
                            scale = 2.5f
                            onScaleChanged(2.5f)
                        }
                    }
                )
            }
            .pointerInput(file.id) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val event = awaitPointerEvent()
                        val pressedCount = event.changes.count { it.pressed }
                        val zoomChange = event.calculateZoom()
                        val panChange = event.calculatePan()
                        if (pressedCount >= 2 || scale > 1.02f) {
                            val nextScale = (scale * zoomChange).coerceIn(1f, 5f)
                            scale = nextScale
                            onScaleChanged(nextScale)
                            offset = if (nextScale > 1.02f) offset + panChange else Offset.Zero
                            event.changes.forEach { if (it.positionChanged()) it.consume() }
                        }
                    } while (event.changes.any { it.pressed })
                }
            },
        contentAlignment = Alignment.Center
    ) {
        if (modelToDisplay != null) {
            AsyncImage(
                model = modelToDisplay,
                contentDescription = file.name,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                        translationX = offset.x
                        translationY = offset.y
                    }
            )
        } else if (miniBitmap != null) {
            Image(
                bitmap = miniBitmap!!,
                contentDescription = file.name,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                        translationX = offset.x
                        translationY = offset.y
                    }
            )
        }

        if (isLoadingFullRes) {
            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(36.dp))
        }
        if (loadError != null && modelToDisplay == null && miniBitmap == null) {
            Text(
                text = "Unable to stream photo: $loadError",
                color = Color.White.copy(alpha = 0.8f),
                modifier = Modifier.padding(24.dp)
            )
        }
    }
}

@Composable
private fun PagerVideoSlide(
    file: FileEntity,
    telegramClient: TelegramClientManager,
    onToggleHud: () -> Unit,
    onPlayVideo: () -> Unit
) {
    val context = LocalContext.current
    var thumbBitmap by remember(file.id, file.activeThumbnailPath) {
        mutableStateOf(
            file.activeThumbnailPath?.let { ThumbnailGenerator.getFromMemoryCache(it) }
                ?: ThumbnailGenerator.getFromMemoryCache(
                    ThumbnailGenerator.getPersistentThumbnailFile(context, file).absolutePath
                )
        )
    }
    var miniBitmap by remember(file.id) {
        mutableStateOf<ImageBitmap?>(
            if (file.telegramAccessHash != 0L) {
                ThumbnailGenerator.getFromMemoryCache("mini_${file.telegramAccessHash}")
            } else null
        )
    }

    LaunchedEffect(file.id, file.activeThumbnailPath, file.telegramAccessHash) {
        if (thumbBitmap == null) {
            val existing = ThumbnailGenerator.resolveExistingThumbnailPath(context, file)
            if (existing != null) {
                thumbBitmap = ThumbnailGenerator.decodeBitmapAsync(existing)
            }
        }
        if (thumbBitmap == null && miniBitmap == null && file.telegramAccessHash != 0L) {
            val mini = telegramClient.getCachedOrFetchMinithumbnail(file)
            if (mini != null && mini.isNotEmpty()) {
                miniBitmap = ThumbnailGenerator.decodeBytesAsync("mini_${file.telegramAccessHash}", mini)
            }
        }
        if (thumbBitmap == null && file.telegramAccessHash != 0L) {
            val target = ThumbnailGenerator.getPersistentThumbnailFile(context, file)
            val downloaded = telegramClient.downloadThumbnailWithSemaphore(file, target)
            if (downloaded != null) {
                thumbBitmap = ThumbnailGenerator.decodeBitmapAsync(downloaded.absolutePath)
            }
        }
    }

    val displayBitmap = thumbBitmap ?: miniBitmap
    val durationText = remember(file.durationMs) {
        if (file.durationMs > 0L) formatDuration(file.durationMs) else "Video"
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .clickable { onToggleHud() },
        contentAlignment = Alignment.Center
    ) {
        if (displayBitmap != null) {
            Image(
                bitmap = displayBitmap,
                contentDescription = file.name,
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF121216)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.VideoFile,
                    contentDescription = file.name,
                    tint = Color.White.copy(alpha = 0.45f),
                    modifier = Modifier.size(64.dp)
                )
            }
        }

        // Scrim + Centered Play CTA + Duration Pill
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.25f))
        )

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Surface(
                color = Color.Black.copy(alpha = 0.72f),
                shape = CircleShape,
                modifier = Modifier
                    .size(72.dp)
                    .clip(CircleShape)
                    .clickable(onClick = onPlayVideo)
                    .testTag("pager_video_play_button")
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Play ${file.name}",
                        tint = Color.White,
                        modifier = Modifier.size(40.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
            Surface(
                color = Color.Black.copy(alpha = 0.68f),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text(
                    text = durationText,
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                )
            }
        }
    }
}
