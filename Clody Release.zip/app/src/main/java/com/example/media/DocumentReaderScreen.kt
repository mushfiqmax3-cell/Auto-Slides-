package com.example.media

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.FontDownload
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ClodyApplication
import com.example.data.local.FileEntity
import com.example.telegram.TelegramClientManager
import com.example.ui.theme.EmeraldConnected
import com.example.ui.theme.JetBrainsMono
import com.example.ui.theme.PlusJakartaSans
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File

private sealed interface DocumentLoadState {
    data class Loading(val progress: Float) : DocumentLoadState
    data class Ready(val file: File, val origin: MediaPlaybackOrigin) : DocumentLoadState
    data class Error(val message: String) : DocumentLoadState
}

@Composable
fun DocumentReaderScreen(
    file: FileEntity,
    telegramClient: TelegramClientManager,
    zeroStorageMode: Boolean,
    onDownloadToDevice: (FileEntity) -> Unit,
    onBack: () -> Unit,
    onCacheMutated: () -> Unit = {}
) {
    val context = LocalContext.current
    var loadState by remember(file.id) { mutableStateOf<DocumentLoadState>(DocumentLoadState.Loading(0f)) }
    var darkReaderMode by remember { mutableStateOf(false) }

    LaunchedEffect(file.id, zeroStorageMode) {
        loadState = DocumentLoadState.Loading(0f)
        val mode = if (zeroStorageMode) {
            com.example.data.local.PlaybackCacheMode.NO_CACHE_MODE
        } else {
            com.example.data.local.PlaybackCacheMode.CACHE_MODE
        }
        runCatching {
            LocalFirstResolver.loadToReadableFile(
                context = context,
                telegramClient = telegramClient,
                file = file,
                cacheMode = mode
            ) { pct ->
                loadState = DocumentLoadState.Loading(pct)
            }
        }.onSuccess { (loadedFile, origin) ->
            loadState = DocumentLoadState.Ready(loadedFile, origin)
        }.onFailure { err ->
            loadState = DocumentLoadState.Error(err.message ?: "Unable to open document")
        }
    }

    DisposableEffect(file.id, zeroStorageMode) {
        onDispose {
            LocalFirstResolver.cleanupTempLocalCopies(context, file.id)
            val readyOrigin = (loadState as? DocumentLoadState.Ready)?.origin
                ?: LocalFirstResolver.resolve(context, file, ignoreStreamCache = zeroStorageMode).origin
            if (zeroStorageMode && readyOrigin != MediaPlaybackOrigin.LOCAL_DEVICE && readyOrigin != MediaPlaybackOrigin.PINNED_OFFLINE) {
                ClodyStreamCache.deleteFileCache(context, file)
                val appScope = (context.applicationContext as? ClodyApplication)?.applicationScope
                    ?: CoroutineScope(SupervisorJob() + Dispatchers.IO)
                appScope.launch {
                    runCatching { telegramClient.deleteTdFileCache(file) }
                    ClodyStreamCache.deleteFileCache(context.applicationContext, file)
                    onCacheMutated()
                }
            }
        }
    }

    BackHandler(onBack = onBack)

    val pageBg = if (darkReaderMode) Color(0xFF141414) else Color(0xFFF5F4F0)
    val cardBg = if (darkReaderMode) Color(0xFF1E1E1E) else Color.White
    val textPrimary = if (darkReaderMode) Color(0xFFF5F4F0) else Color(0xFF141414)
    val textSecondary = if (darkReaderMode) Color(0xFFA0A0A0) else Color(0xFF6B6A66)

    val currentOrigin = (loadState as? DocumentLoadState.Ready)?.origin
        ?: LocalFirstResolver.resolve(context, file, ignoreStreamCache = zeroStorageMode).origin

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(pageBg)
            .statusBarsPadding()
            .navigationBarsPadding()
            .testTag("document_reader_screen")
    ) {
        // Unified Warm Monochrome Reader Header
        Surface(
            color = cardBg,
            tonalElevation = 1.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack, modifier = Modifier.size(44.dp)) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = textPrimary
                        )
                    }
                    Column(modifier = Modifier.weight(1f).padding(horizontal = 6.dp)) {
                        Text(
                            text = file.name,
                            style = MaterialTheme.typography.titleMedium,
                            color = textPrimary,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(3.dp))
                        PlaybackOriginPill(
                            origin = currentOrigin,
                            darkSurface = darkReaderMode
                        )
                    }
                    IconButton(
                        onClick = { darkReaderMode = !darkReaderMode },
                        modifier = Modifier.size(42.dp).testTag("reader_theme_toggle")
                    ) {
                        Icon(
                            imageVector = if (darkReaderMode) Icons.Default.LightMode else Icons.Default.DarkMode,
                            contentDescription = "Toggle reading theme",
                            tint = textPrimary
                        )
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    DownloadOrSavedPill(
                        origin = currentOrigin,
                        onDownloadClick = { onDownloadToDevice(file) },
                        darkMode = darkReaderMode
                    )
                }
            }
        }

        when (val state = loadState) {
            is DocumentLoadState.Loading -> {
                Box(
                    modifier = Modifier.fillMaxSize().padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Surface(
                        color = cardBg,
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                "Preparing ${file.name}...",
                                style = MaterialTheme.typography.titleMedium,
                                color = textPrimary
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            LinearProgressIndicator(
                                progress = { state.progress.coerceIn(0f, 1f) },
                                color = textPrimary,
                                trackColor = textSecondary.copy(alpha = 0.2f),
                                modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp))
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                "${(state.progress * 100).toInt()}%",
                                style = MaterialTheme.typography.labelMedium,
                                color = textSecondary
                            )
                        }
                    }
                }
            }

            is DocumentLoadState.Error -> {
                Box(
                    modifier = Modifier.fillMaxSize().padding(28.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Surface(color = cardBg, shape = RoundedCornerShape(24.dp)) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("Unable to preview document", style = MaterialTheme.typography.titleMedium, color = textPrimary)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(state.message, style = MaterialTheme.typography.bodyMedium, color = textSecondary)
                            Spacer(modifier = Modifier.height(14.dp))
                            DownloadOrSavedPill(
                                origin = currentOrigin,
                                onDownloadClick = { onDownloadToDevice(file) },
                                darkMode = darkReaderMode
                            )
                        }
                    }
                }
            }

            is DocumentLoadState.Ready -> {
                when {
                    file.isPdf -> PdfReaderView(
                        loadedFile = state.file,
                        darkReaderMode = darkReaderMode,
                        cardBg = cardBg,
                        textPrimary = textPrimary
                    )

                    file.isWordDoc -> WordDocReaderView(
                        loadedFile = state.file,
                        isRtf = file.extLower == "rtf",
                        cardBg = cardBg,
                        textPrimary = textPrimary,
                        textSecondary = textSecondary,
                        darkReaderMode = darkReaderMode
                    )

                    file.isSpreadsheet -> SpreadsheetReaderView(
                        loadedFile = state.file,
                        ext = file.extLower,
                        cardBg = cardBg,
                        textPrimary = textPrimary,
                        textSecondary = textSecondary,
                        darkReaderMode = darkReaderMode
                    )

                    else -> TextCodeReaderView(
                        loadedFile = state.file,
                        ext = file.extLower,
                        cardBg = cardBg,
                        textPrimary = textPrimary,
                        textSecondary = textSecondary,
                        darkReaderMode = darkReaderMode
                    )
                }
            }
        }
    }
}

@Composable
private fun PdfReaderView(
    loadedFile: File,
    darkReaderMode: Boolean,
    cardBg: Color,
    textPrimary: Color
) {
    val density = LocalDensity.current
    var zoom by remember { mutableFloatStateOf(1f) }
    val listState = rememberLazyListState()
    val renderMutex = remember(loadedFile.absolutePath) { Mutex() }

    val pdfHandle = remember(loadedFile.absolutePath) {
        runCatching {
            val pfd = ParcelFileDescriptor.open(loadedFile, ParcelFileDescriptor.MODE_READ_ONLY)
            val renderer = PdfRenderer(pfd)
            pfd to renderer
        }.getOrNull()
    }

    DisposableEffect(pdfHandle) {
        onDispose {
            runCatching { pdfHandle?.second?.close() }
            runCatching { pdfHandle?.first?.close() }
        }
    }

    if (pdfHandle == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Unable to decode PDF pages.", color = textPrimary)
        }
        return
    }

    val renderer = pdfHandle.second
    val pageCount = renderer.pageCount.coerceAtLeast(1)
    val currentPage = (listState.firstVisibleItemIndex + 1).coerceIn(1, pageCount)

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTransformGestures { _, _, gestureZoom, _ ->
                    if (gestureZoom != 1f) {
                        zoom = (zoom * gestureZoom).coerceIn(1f, 3f)
                    }
                }
            }
    ) {
        val baseWidthPx = with(density) { (maxWidth - 24.dp).toPx().toInt().coerceAtLeast(360) }

        LazyColumn(
            state = listState,
            contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 12.dp, bottom = 92.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier
                .fillMaxSize()
                .horizontalScroll(rememberScrollState(), enabled = zoom > 1.05f)
        ) {
            items(pageCount, key = { it }) { pageIndex ->
                val pageBitmap by produceState<ImageBitmap?>(
                    initialValue = null,
                    key1 = pageIndex,
                    key2 = loadedFile.absolutePath,
                    key3 = (zoom * 10).toInt()
                ) {
                    value = withContext(Dispatchers.IO) {
                        renderMutex.withLock {
                            runCatching {
                                renderer.openPage(pageIndex).use { page ->
                                    val renderScale = zoom.coerceIn(1f, 2.5f)
                                    val targetW = (baseWidthPx * renderScale).toInt().coerceAtMost(2200)
                                    val targetH = ((targetW.toFloat() / maxOf(1, page.width)) * page.height)
                                        .toInt()
                                        .coerceAtLeast(100)
                                    val bmp = Bitmap.createBitmap(targetW, targetH, Bitmap.Config.ARGB_8888)
                                    Canvas(bmp).drawColor(AndroidColor.WHITE)
                                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                                    bmp.asImageBitmap()
                                }
                            }.getOrNull()
                        }
                    }
                }

                val targetCardWidth = (maxWidth - 24.dp) * zoom
                Surface(
                    color = Color.White,
                    shape = RoundedCornerShape(14.dp),
                    shadowElevation = 2.dp,
                    modifier = Modifier.width(targetCardWidth)
                ) {
                    val bmp = pageBitmap
                    if (bmp != null) {
                        Image(
                            bitmap = bmp,
                            contentDescription = "Page ${pageIndex + 1}",
                            contentScale = ContentScale.FillWidth,
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else {
                        Box(
                            modifier = Modifier.fillMaxWidth().height(420.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("Rendering page ${pageIndex + 1}...", color = Color(0xFF6B6A66))
                        }
                    }
                }
            }
        }

        // Floating Page X of Y Pill + Zoom Controls
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 18.dp, start = 16.dp, end = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Surface(
                color = if (darkReaderMode) Color.White else Color(0xFF141414),
                shape = RoundedCornerShape(22.dp),
                shadowElevation = 6.dp
            ) {
                Text(
                    text = "Page $currentPage of $pageCount",
                    color = if (darkReaderMode) Color(0xFF141414) else Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
                )
            }

            Surface(
                color = cardBg,
                shape = RoundedCornerShape(22.dp),
                shadowElevation = 6.dp
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 4.dp)
                ) {
                    IconButton(
                        onClick = { zoom = (zoom - 0.25f).coerceAtLeast(1f) },
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(Icons.Default.Remove, contentDescription = "Zoom out", tint = textPrimary)
                    }
                    Text(
                        text = "${(zoom * 100).toInt()}%",
                        color = textPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    IconButton(
                        onClick = { zoom = (zoom + 0.25f).coerceAtMost(3f) },
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Zoom in", tint = textPrimary)
                    }
                }
            }
        }
    }
}

@Composable
private fun WordDocReaderView(
    loadedFile: File,
    isRtf: Boolean,
    cardBg: Color,
    textPrimary: Color,
    textSecondary: Color,
    darkReaderMode: Boolean
) {
    val blocks by produceState<List<WordBlock>?>(initialValue = null, loadedFile.absolutePath) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                if (isRtf) DocumentParser.parseRtf(loadedFile)
                else DocumentParser.parseDocx(loadedFile)
            }.getOrElse {
                listOf(WordBlock.Paragraph("Unable to parse document: ${it.message}"))
            }
        }
    }

    val list = blocks
    if (list == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Formatting Word document...", color = textSecondary)
        }
        return
    }

    SelectionContainer {
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            item(key = "doc_surface") {
                Surface(
                    color = cardBg,
                    shape = RoundedCornerShape(24.dp),
                    tonalElevation = 1.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 22.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        list.forEach { block ->
                            when (block) {
                                is WordBlock.Heading -> {
                                    val size = when (block.level) {
                                        1 -> 22.sp
                                        2 -> 19.sp
                                        else -> 17.sp
                                    }
                                    Text(
                                        text = block.text,
                                        color = textPrimary,
                                        fontFamily = PlusJakartaSans,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = size,
                                        lineHeight = (size.value + 6).sp,
                                        modifier = Modifier.padding(top = 6.dp)
                                    )
                                }

                                is WordBlock.Paragraph -> {
                                    Text(
                                        text = block.text,
                                        color = textPrimary,
                                        fontFamily = PlusJakartaSans,
                                        fontWeight = if (block.isBold) FontWeight.SemiBold else FontWeight.Normal,
                                        fontStyle = if (block.isItalic) FontStyle.Italic else FontStyle.Normal,
                                        fontSize = 15.sp,
                                        lineHeight = 23.sp
                                    )
                                }

                                is WordBlock.BulletItem -> {
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(start = 6.dp),
                                        verticalAlignment = Alignment.Top
                                    ) {
                                        Text(
                                            text = block.index?.let { "$it." } ?: "•",
                                            color = textSecondary,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp,
                                            modifier = Modifier.width(20.dp)
                                        )
                                        Text(
                                            text = block.text,
                                            color = textPrimary,
                                            fontFamily = PlusJakartaSans,
                                            fontSize = 15.sp,
                                            lineHeight = 22.sp,
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }

                                is WordBlock.TableBlock -> {
                                    val borderColor = if (darkReaderMode) Color.White.copy(alpha = 0.16f) else Color(0xFFE0DFDA)
                                    val headerBg = if (darkReaderMode) Color(0xFF282828) else Color(0xFFF5F4F0)
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 6.dp)
                                            .clip(RoundedCornerShape(14.dp))
                                            .border(1.dp, borderColor, RoundedCornerShape(14.dp))
                                            .horizontalScroll(rememberScrollState())
                                    ) {
                                        block.rows.forEachIndexed { rIdx, row ->
                                            Row(
                                                modifier = Modifier
                                                    .background(if (rIdx == 0) headerBg else Color.Transparent)
                                            ) {
                                                row.forEach { cell ->
                                                    Text(
                                                        text = cell,
                                                        color = textPrimary,
                                                        fontWeight = if (rIdx == 0) FontWeight.SemiBold else FontWeight.Normal,
                                                        fontSize = 13.sp,
                                                        modifier = Modifier
                                                            .width(136.dp)
                                                            .padding(horizontal = 10.dp, vertical = 8.dp)
                                                    )
                                                }
                                            }
                                            if (rIdx < block.rows.lastIndex) {
                                                HorizontalDivider(color = borderColor)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun SpreadsheetReaderView(
    loadedFile: File,
    ext: String,
    cardBg: Color,
    textPrimary: Color,
    textSecondary: Color,
    darkReaderMode: Boolean
) {
    val sheets by produceState<List<SpreadsheetSheet>?>(initialValue = null, loadedFile.absolutePath) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                when (ext) {
                    "csv" -> DocumentParser.parseCsv(loadedFile)
                    "xls" -> DocumentParser.parseXlsFallback(loadedFile)
                    else -> DocumentParser.parseXlsx(loadedFile)
                }
            }.getOrElse {
                listOf(SpreadsheetSheet("Error", listOf(listOf("Failed to open spreadsheet: ${it.message}"))))
            }
        }
    }

    val sheetList = sheets
    if (sheetList == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Parsing spreadsheet...", color = textSecondary)
        }
        return
    }

    var selectedSheetIdx by remember(loadedFile.absolutePath) { mutableIntStateOf(0) }
    val activeSheet = sheetList.getOrElse(selectedSheetIdx) { sheetList.first() }
    val rows = activeSheet.rows
    val headerRow = rows.firstOrNull().orEmpty()
    val dataRows = if (rows.size > 1) rows.drop(1) else emptyList()

    val hScroll = rememberScrollState()
    val gridBorder = if (darkReaderMode) Color.White.copy(alpha = 0.14f) else Color(0xFFE2E0DA)
    val stickyHeaderBg = if (darkReaderMode) Color(0xFF262626) else Color(0xFFECEAE3)
    val zebraBg = if (darkReaderMode) Color(0xFF1A1A1A) else Color(0xFFFAF9F6)

    Column(modifier = Modifier.fillMaxSize()) {
        if (sheetList.size > 1) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                itemsIndexed(sheetList) { idx, sheet ->
                    val selected = idx == selectedSheetIdx
                    FilterChip(
                        selected = selected,
                        onClick = { selectedSheetIdx = idx },
                        label = { Text(sheet.name) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = textPrimary,
                            selectedLabelColor = cardBg
                        )
                    )
                }
            }
        }

        if (rows.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("This sheet is empty.", color = textSecondary)
            }
        } else {
            Surface(
                color = cardBg,
                shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 12.dp, vertical = 8.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .border(1.dp, gridBorder, RoundedCornerShape(20.dp))
            ) {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .horizontalScroll(hScroll)
                ) {
                    stickyHeader {
                        Row(
                            modifier = Modifier
                                .background(stickyHeaderBg)
                                .border(0.5.dp, gridBorder)
                        ) {
                            Box(
                                modifier = Modifier
                                    .width(46.dp)
                                    .padding(vertical = 10.dp, horizontal = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("#", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = textSecondary)
                            }
                            headerRow.forEach { col ->
                                Box(
                                    modifier = Modifier
                                        .width(132.dp)
                                        .padding(vertical = 10.dp, horizontal = 10.dp)
                                ) {
                                    Text(
                                        text = col.ifBlank { "—" },
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = textPrimary,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }

                    itemsIndexed(dataRows) { rIdx, row ->
                        Row(
                            modifier = Modifier
                                .background(if (rIdx % 2 == 1) zebraBg else cardBg)
                        ) {
                            Box(
                                modifier = Modifier
                                    .width(46.dp)
                                    .padding(vertical = 9.dp, horizontal = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "${rIdx + 2}",
                                    fontSize = 11.sp,
                                    color = textSecondary,
                                    fontFamily = JetBrainsMono
                                )
                            }
                            row.forEach { cell ->
                                Box(
                                    modifier = Modifier
                                        .width(132.dp)
                                        .padding(vertical = 9.dp, horizontal = 10.dp)
                                ) {
                                    Text(
                                        text = cell,
                                        fontSize = 13.sp,
                                        color = textPrimary,
                                        maxLines = 3,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                        HorizontalDivider(color = gridBorder.copy(alpha = 0.7f))
                    }
                }
            }
        }
    }
}

@Composable
private fun TextCodeReaderView(
    loadedFile: File,
    ext: String,
    cardBg: Color,
    textPrimary: Color,
    textSecondary: Color,
    darkReaderMode: Boolean
) {
    val clipboardManager = LocalClipboardManager.current
    val isCodeDefault = ext in setOf("json", "xml", "html", "htm", "css", "js", "ts", "jsx", "tsx", "py", "kt", "kts", "java", "yaml", "yml", "sql", "sh", "log", "gradle")
    var useMonoFont by remember(loadedFile.absolutePath) { mutableStateOf(isCodeDefault) }
    var showSearch by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var activeMatchIdx by remember { mutableIntStateOf(0) }
    var copiedFeedback by remember { mutableStateOf(false) }

    val fullText by produceState<String?>(initialValue = null, loadedFile.absolutePath) {
        value = withContext(Dispatchers.IO) {
            runCatching { DocumentParser.readSafeText(loadedFile) }
                .getOrElse { "Failed to read file text: ${it.message}" }
        }
    }

    val raw = fullText
    if (raw == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Loading text...", color = textSecondary)
        }
        return
    }

    val lines = remember(raw) { raw.lines() }
    val matchingLineIndices = remember(lines, searchQuery) {
        val q = searchQuery.trim()
        if (q.isEmpty()) emptyList()
        else lines.mapIndexedNotNull { idx, line ->
            if (line.contains(q, ignoreCase = true)) idx else null
        }
    }
    val listState = rememberLazyListState()

    LaunchedEffect(activeMatchIdx, matchingLineIndices) {
        val targetLine = matchingLineIndices.getOrNull(activeMatchIdx)
        if (targetLine != null) {
            listState.animateScrollToItem(targetLine)
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Text & Code Utility Bar: Font Toggle, Search, Copy Text
        Surface(
            color = cardBg,
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 8.dp)
        ) {
            Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(
                            selected = !useMonoFont,
                            onClick = { useMonoFont = false },
                            leadingIcon = { Icon(Icons.Default.FontDownload, contentDescription = null, modifier = Modifier.size(16.dp)) },
                            label = { Text("Sans") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = textPrimary,
                                selectedLabelColor = cardBg
                            )
                        )
                        FilterChip(
                            selected = useMonoFont,
                            onClick = { useMonoFont = true },
                            label = { Text("Mono") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = textPrimary,
                                selectedLabelColor = cardBg
                            )
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { showSearch = !showSearch }) {
                            Icon(Icons.Default.Search, contentDescription = "Search in text", tint = textPrimary)
                        }
                        TextButton(
                            onClick = {
                                clipboardManager.setText(AnnotatedString(raw))
                                copiedFeedback = true
                            }
                        ) {
                            Icon(
                                imageVector = if (copiedFeedback) Icons.Default.Check else Icons.Default.ContentCopy,
                                contentDescription = "Copy Text",
                                tint = if (copiedFeedback) EmeraldConnected else textPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = if (copiedFeedback) "Copied" else "Copy Text",
                                color = if (copiedFeedback) EmeraldConnected else textPrimary,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 12.sp
                            )
                        }
                    }
                }

                AnimatedVisibility(visible = showSearch) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = {
                                searchQuery = it
                                activeMatchIdx = 0
                            },
                            placeholder = { Text("Search in text...") },
                            singleLine = true,
                            shape = RoundedCornerShape(16.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = textPrimary,
                                unfocusedTextColor = textPrimary
                            ),
                            modifier = Modifier.weight(1f)
                        )
                        if (matchingLineIndices.isNotEmpty()) {
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "${activeMatchIdx + 1}/${matchingLineIndices.size}",
                                color = textSecondary,
                                fontSize = 12.sp
                            )
                            IconButton(
                                onClick = {
                                    activeMatchIdx = if (activeMatchIdx <= 0) matchingLineIndices.lastIndex else activeMatchIdx - 1
                                },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Previous match", tint = textPrimary)
                            }
                            IconButton(
                                onClick = {
                                    activeMatchIdx = (activeMatchIdx + 1) % matchingLineIndices.size
                                },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Next match", tint = textPrimary)
                            }
                        }
                        IconButton(
                            onClick = {
                                showSearch = false
                                searchQuery = ""
                            },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Close search", tint = textSecondary)
                        }
                    }
                }
            }
        }

        val isMarkdown = ext == "md" || ext == "markdown"
        val highlightBg = if (darkReaderMode) Color(0xFF594D00) else Color(0xFFFFEC8B)

        SelectionContainer {
            Surface(
                color = cardBg,
                shape = RoundedCornerShape(22.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 14.dp, vertical = 4.dp)
            ) {
                LazyColumn(
                    state = listState,
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(3.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    itemsIndexed(lines) { idx, line ->
                        val annotated = remember(line, searchQuery, isMarkdown, useMonoFont, darkReaderMode) {
                            buildHighlightedLine(
                                line = line,
                                query = searchQuery.trim(),
                                isMarkdown = isMarkdown && !useMonoFont,
                                highlightColor = highlightBg
                            )
                        }
                        Row(modifier = Modifier.fillMaxWidth()) {
                            if (useMonoFont) {
                                Text(
                                    text = "${idx + 1}",
                                    color = textSecondary.copy(alpha = 0.65f),
                                    fontFamily = JetBrainsMono,
                                    fontSize = 11.sp,
                                    modifier = Modifier.width(36.dp)
                                )
                            }
                            Text(
                                text = annotated,
                                color = textPrimary,
                                fontFamily = if (useMonoFont) JetBrainsMono else PlusJakartaSans,
                                fontSize = if (useMonoFont) 13.sp else 15.sp,
                                lineHeight = if (useMonoFont) 20.sp else 23.sp,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun buildHighlightedLine(
    line: String,
    query: String,
    isMarkdown: Boolean,
    highlightColor: Color
): AnnotatedString {
    return buildAnnotatedString {
        val displayLine = when {
            isMarkdown && line.startsWith("### ") -> {
                pushStyle(SpanStyle(fontWeight = FontWeight.Bold, fontSize = 16.sp))
                line.removePrefix("### ")
            }
            isMarkdown && line.startsWith("## ") -> {
                pushStyle(SpanStyle(fontWeight = FontWeight.Bold, fontSize = 18.sp))
                line.removePrefix("## ")
            }
            isMarkdown && line.startsWith("# ") -> {
                pushStyle(SpanStyle(fontWeight = FontWeight.Bold, fontSize = 21.sp))
                line.removePrefix("# ")
            }
            isMarkdown && (line.trimStart().startsWith("- ") || line.trimStart().startsWith("* ")) -> {
                "• " + line.trimStart().drop(2)
            }
            else -> line
        }
        append(displayLine)

        if (query.isNotEmpty()) {
            var startIndex = 0
            while (true) {
                val match = displayLine.indexOf(query, startIndex = startIndex, ignoreCase = true)
                if (match < 0) break
                addStyle(
                    style = SpanStyle(background = highlightColor, fontWeight = FontWeight.Bold),
                    start = match,
                    end = match + query.length
                )
                startIndex = match + query.length
            }
        }
    }
}
