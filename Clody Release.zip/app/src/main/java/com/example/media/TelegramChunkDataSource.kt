package com.example.media

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.Uri
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.BaseDataSource
import androidx.media3.datasource.DataSpec
import com.example.data.local.FileEntity
import com.example.telegram.TelegramClientManager
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import java.io.File
import java.io.RandomAccessFile
import java.util.BitSet
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.min

/**
 * Automatic Network Detection for Wi-Fi (full quality + lookahead) vs. Mobile Data (Data Saver).
 */
object NetworkStreamingPolicy {

    fun isMeteredCellular(context: Context): Boolean {
        return runCatching {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
                ?: return@runCatching false
            val activeNetwork = cm.activeNetwork ?: return@runCatching false
            val caps = cm.getNetworkCapabilities(activeNetwork) ?: return@runCatching false
            val hasWifiOrEthernet = caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
            if (hasWifiOrEthernet) return@runCatching false
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) || cm.isActiveNetworkMetered
        }.getOrDefault(false)
    }

    fun observeNetworkChanges(
        context: Context,
        onCellularDataSaverChanged: (Boolean) -> Unit
    ): () -> Unit {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return {}
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                onCellularDataSaverChanged(isMeteredCellular(context))
            }

            override fun onCapabilitiesChanged(
                network: Network,
                networkCapabilities: NetworkCapabilities
            ) {
                val hasWifiOrEthernet =
                    networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                        networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
                val cellularSaver = !hasWifiOrEthernet &&
                    (networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ||
                        cm.isActiveNetworkMetered)
                onCellularDataSaverChanged(cellularSaver)
            }

            override fun onLost(network: Network) {
                onCellularDataSaverChanged(isMeteredCellular(context))
            }
        }

        val registered = runCatching {
            val request = NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .build()
            cm.registerNetworkCallback(request, callback)
            true
        }.getOrDefault(false)

        return {
            if (registered) {
                runCatching { cm.unregisterNetworkCallback(callback) }
            }
        }
    }
}

/**
 * RAM-Safe 512 KB Sliding-Window Media3 DataSource for Clody:
 * - Never loads full multi-GB videos into RAM (prevents OutOfMemoryError).
 * - Fetches progressive 512 KB (524,288 bytes) sliding-window chunks on demand via TDLib
 *   `DownloadFile(..., priority = 32, offset, limit = 524288, synchronous = true)`.
 * - Releases stale read buffers immediately when seeking or advancing playback, keeping
 *   total DataSource + player RAM well under ~20 MB even for 2 GB+ files.
 * - Sparse-safe Cache Mode tracks fetched 512 KB chunk indices via BitSet so arbitrary seeks
 *   (e.g. reading MP4 moov atom at EOF then seeking back) never read zero-filled holes.
 * - Network-aware lookahead: prefetches the next 512 KB chunk ahead on Wi-Fi, and disables
 *   ahead-of-playhead prefetching on Mobile Data (Cellular Data Saver).
 */
@UnstableApi
class TelegramChunkDataSource(
    private val context: Context,
    private val telegramClient: TelegramClientManager,
    private val fileEntity: FileEntity,
    private val noCacheStreaming: Boolean = false,
    private val maxCacheBytes: Long = 1024L * 1024L * 1024L,
    private val enableLookaheadProvider: (() -> Boolean)? = null
) : BaseDataSource(/* isNetwork = */ true) {

    class Factory(
        private val context: Context,
        private val telegramClient: TelegramClientManager,
        private val fileEntity: FileEntity,
        private val noCacheStreaming: Boolean = false,
        private val maxCacheBytes: Long = 1024L * 1024L * 1024L,
        private val enableLookaheadProvider: (() -> Boolean)? = null
    ) : androidx.media3.datasource.DataSource.Factory {
        override fun createDataSource(): androidx.media3.datasource.DataSource {
            return TelegramChunkDataSource(
                context = context,
                telegramClient = telegramClient,
                fileEntity = fileEntity,
                noCacheStreaming = noCacheStreaming,
                maxCacheBytes = maxCacheBytes,
                enableLookaheadProvider = enableLookaheadProvider
            )
        }
    }

    companion object {
        const val SLIDING_CHUNK_SIZE: Int = 512 * 1024 // 512 KB (524,288 bytes)
        private const val MAX_RAM_WINDOW_CHUNKS_WIFI: Int = 6 // ~3 MB RAM sliding window on Wi-Fi
        private const val MAX_RAM_WINDOW_CHUNKS_CELLULAR: Int = 2 // ~1 MB RAM window on Mobile Data
    }

    private var uri: Uri? = null
    private var readPosition: Long = 0L
    private var bytesRemaining: Long = 0L
    private var opened = false

    private var directDiskFile: File? = null
    private var directRaf: RandomAccessFile? = null
    private var cacheFile: File? = null
    private var cacheRaf: RandomAccessFile? = null

    private val lookaheadScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val inFlightChunks = ConcurrentHashMap<Long, CompletableDeferred<ByteArray>>()

    // Bounded RAM sliding window for No-Cache Mode (strictly capped to prevent OOM)
    private val ramSlidingWindow = object : LinkedHashMap<Long, ByteArray>(10, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<Long, ByteArray>?): Boolean {
            return size > currentRamWindowLimit()
        }
    }

    private val fileReferenceBytes: ByteArray by lazy {
        hexToBytes(fileEntity.telegramFileReferenceHex)
    }

    private fun isLookaheadAllowed(): Boolean {
        return enableLookaheadProvider?.invoke()
            ?: !NetworkStreamingPolicy.isMeteredCellular(context)
    }

    private fun currentRamWindowLimit(): Int {
        return if (isLookaheadAllowed()) {
            MAX_RAM_WINDOW_CHUNKS_WIFI
        } else {
            MAX_RAM_WINDOW_CHUNKS_CELLULAR
        }
    }

    override fun open(dataSpec: DataSpec): Long {
        uri = dataSpec.uri
        transferInitializing(dataSpec)

        val totalSize = fileEntity.sizeBytes.coerceAtLeast(0L)
        readPosition = dataSpec.position.coerceAtLeast(0L)

        // Reset any stale in-RAM window chunks that don't bracket the new seek position
        evictStaleRamChunks(readPosition / SLIDING_CHUNK_SIZE)

        // 1. Check Pinned Offline or verified complete cache file first
        val pinned = fileEntity.pinnedOfflinePath?.let { File(it) }?.takeIf { it.exists() && it.length() > 0L }
            ?: LocalFirstResolver.getPinnedOfflineFile(context, fileEntity).takeIf {
                fileEntity.isPinnedOffline && it.exists() && it.length() > 0L
            }

        val readyCompleteCache = if (!noCacheStreaming && pinned == null && ClodyStreamCache.isFullyCached(context, fileEntity)) {
            ClodyStreamCache.getCachedVideoFile(context, fileEntity)
                .takeIf { it.exists() && it.length() > 0L }
        } else null

        val directFile = pinned ?: readyCompleteCache
        if (directFile != null) {
            directDiskFile = directFile
            directRaf = RandomAccessFile(directFile, "r")
        } else if (!noCacheStreaming) {
            // 2. Cache Mode: stream into sparse-tracked partial cache until 100% chunks arrive
            val partialTarget = ClodyStreamCache.getPartialCacheFile(context, fileEntity)
            val isFreshSession = !partialTarget.exists() || !ClodyStreamCache.hasTrackingFor(partialTarget)
            if (isFreshSession && partialTarget.exists()) {
                // Clean partial leftover from an earlier killed process so no stale sparse zeros remain
                partialTarget.delete()
            }
            if (!partialTarget.exists()) {
                partialTarget.parentFile?.mkdirs()
                partialTarget.createNewFile()
            }
            cacheFile = partialTarget
            cacheRaf = RandomAccessFile(partialTarget, "rw")
        }

        bytesRemaining = if (dataSpec.length != C.LENGTH_UNSET.toLong()) {
            dataSpec.length
        } else if (totalSize > 0L) {
            (totalSize - readPosition).coerceAtLeast(0L)
        } else {
            C.LENGTH_UNSET.toLong()
        }

        opened = true
        transferStarted(dataSpec)
        return bytesRemaining
    }

    override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
        if (length == 0) return 0
        if (bytesRemaining == 0L) return C.RESULT_END_OF_INPUT
        if (fileEntity.sizeBytes > 0L && readPosition >= fileEntity.sizeBytes) {
            return C.RESULT_END_OF_INPUT
        }

        val maxToRead = if (bytesRemaining == C.LENGTH_UNSET.toLong()) {
            length
        } else {
            min(length.toLong(), bytesRemaining).toInt()
        }

        // Case A: Reading from Pinned Offline or already-complete cached file directly
        val pinnedOrCompleteRaf = directRaf
        if (pinnedOrCompleteRaf != null) {
            synchronized(pinnedOrCompleteRaf) {
                if (readPosition >= pinnedOrCompleteRaf.length()) return C.RESULT_END_OF_INPUT
                pinnedOrCompleteRaf.seek(readPosition)
                val readCount = pinnedOrCompleteRaf.read(buffer, offset, maxToRead)
                if (readCount <= 0) return C.RESULT_END_OF_INPUT
                readPosition += readCount
                if (bytesRemaining != C.LENGTH_UNSET.toLong()) {
                    bytesRemaining = (bytesRemaining - readCount).coerceAtLeast(0L)
                }
                bytesTransferred(readCount)
                return readCount
            }
        }

        val chunkIndex = readPosition / SLIDING_CHUNK_SIZE
        val chunkStartOffset = chunkIndex * SLIDING_CHUNK_SIZE
        val offsetInsideChunk = (readPosition - chunkStartOffset).toInt()

        // Release old read buffers behind playback/seek window immediately
        evictStaleRamChunks(chunkIndex)

        // Case B: No-Cache Mode -> RAM-only 512 KB sliding window (0 bytes written to Clody cache)
        if (noCacheStreaming) {
            val chunkBytes = synchronized(ramSlidingWindow) {
                ramSlidingWindow[chunkStartOffset]
            } ?: run {
                val downloaded = runBlocking { getOrFetchChunk(chunkStartOffset) }
                if (downloaded.isNotEmpty()) {
                    synchronized(ramSlidingWindow) {
                        ramSlidingWindow[chunkStartOffset] = downloaded
                    }
                }
                downloaded
            }

            if (chunkBytes.isEmpty() || offsetInsideChunk >= chunkBytes.size) {
                return C.RESULT_END_OF_INPUT
            }

            val availableInChunk = chunkBytes.size - offsetInsideChunk
            val toCopy = min(maxToRead, availableInChunk)
            System.arraycopy(chunkBytes, offsetInsideChunk, buffer, offset, toCopy)
            readPosition += toCopy
            if (bytesRemaining != C.LENGTH_UNSET.toLong()) {
                bytesRemaining = (bytesRemaining - toCopy).coerceAtLeast(0L)
            }
            bytesTransferred(toCopy)

            // Lookahead ONLY on Wi-Fi / unmetered connections (disabled on Mobile Data)
            if (isLookaheadAllowed()) {
                scheduleLookaheadChunk(chunkStartOffset + SLIDING_CHUNK_SIZE)
            }
            return toCopy
        }

        // Case C: Cache Mode -> Sparse-safe 512 KB chunk tracking into partial cache file
        val raf = cacheRaf ?: return C.RESULT_END_OF_INPUT
        val partialFile = cacheFile ?: return C.RESULT_END_OF_INPUT

        val hasCurrentChunk = ClodyStreamCache.hasPartialChunk(partialFile, chunkIndex)
        if (!hasCurrentChunk) {
            val chunkBytes = runBlocking { getOrFetchChunk(chunkStartOffset) }
            if (chunkBytes.isEmpty() || offsetInsideChunk >= chunkBytes.size) {
                return C.RESULT_END_OF_INPUT
            }
            synchronized(raf) {
                raf.seek(chunkStartOffset)
                raf.write(chunkBytes)
            }
            ClodyStreamCache.markPartialChunkPresent(partialFile, chunkIndex)
        }

        val currentLen = synchronized(raf) { raf.length() }
        if (readPosition >= currentLen) {
            return C.RESULT_END_OF_INPUT
        }

        val maxInCurrentChunk = (SLIDING_CHUNK_SIZE - offsetInsideChunk).coerceAtLeast(1)
        val boundedToRead = min(maxToRead, maxInCurrentChunk)
        val actualRead = synchronized(raf) {
            raf.seek(readPosition)
            raf.read(buffer, offset, boundedToRead)
        }
        if (actualRead <= 0) return C.RESULT_END_OF_INPUT

        readPosition += actualRead
        if (bytesRemaining != C.LENGTH_UNSET.toLong()) {
            bytesRemaining = (bytesRemaining - actualRead).coerceAtLeast(0L)
        }
        bytesTransferred(actualRead)

        // Lookahead ONLY on Wi-Fi / unmetered connections (disabled on Mobile Data Data Saver)
        if (isLookaheadAllowed()) {
            val nextChunkOffset = chunkStartOffset + SLIDING_CHUNK_SIZE
            val nextChunkIndex = chunkIndex + 1L
            if ((fileEntity.sizeBytes <= 0L || nextChunkOffset < fileEntity.sizeBytes) &&
                !ClodyStreamCache.hasPartialChunk(partialFile, nextChunkIndex)
            ) {
                scheduleDiskLookaheadChunk(partialFile, raf, nextChunkOffset, nextChunkIndex)
            }
        }

        return actualRead
    }

    private suspend fun getOrFetchChunk(alignedOffset: Long): ByteArray {
        if (fileEntity.sizeBytes > 0L && alignedOffset >= fileEntity.sizeBytes) {
            return ByteArray(0)
        }
        val existingDeferred = inFlightChunks[alignedOffset]
        if (existingDeferred != null) {
            return runCatching { existingDeferred.await() }.getOrDefault(ByteArray(0))
        }

        val newDeferred = CompletableDeferred<ByteArray>()
        val prior = inFlightChunks.putIfAbsent(alignedOffset, newDeferred)
        if (prior != null) {
            return runCatching { prior.await() }.getOrDefault(ByteArray(0))
        }

        return try {
            val downloaded = runCatching {
                telegramClient.downloadChunk(
                    dcId = fileEntity.telegramDcId,
                    documentId = fileEntity.telegramDocumentId,
                    accessHash = fileEntity.telegramAccessHash,
                    fileReference = fileReferenceBytes,
                    offset = alignedOffset,
                    limit = SLIDING_CHUNK_SIZE
                )
            }.getOrDefault(ByteArray(0))
            newDeferred.complete(downloaded)
            downloaded
        } finally {
            inFlightChunks.remove(alignedOffset, newDeferred)
        }
    }

    private fun scheduleLookaheadChunk(nextOffset: Long) {
        if (fileEntity.sizeBytes > 0L && nextOffset >= fileEntity.sizeBytes) return
        val alreadyBuffered = synchronized(ramSlidingWindow) { ramSlidingWindow.containsKey(nextOffset) }
        if (alreadyBuffered || inFlightChunks.containsKey(nextOffset)) return

        lookaheadScope.launch {
            if (!opened || !isLookaheadAllowed()) return@launch
            val bytes = getOrFetchChunk(nextOffset)
            if (bytes.isNotEmpty() && opened) {
                synchronized(ramSlidingWindow) {
                    ramSlidingWindow[nextOffset] = bytes
                }
            }
        }
    }

    private fun scheduleDiskLookaheadChunk(
        partialFile: File,
        raf: RandomAccessFile,
        nextOffset: Long,
        nextIndex: Long
    ) {
        if (fileEntity.sizeBytes > 0L && nextOffset >= fileEntity.sizeBytes) return
        if (ClodyStreamCache.hasPartialChunk(partialFile, nextIndex) ||
            inFlightChunks.containsKey(nextOffset)
        ) {
            return
        }

        lookaheadScope.launch {
            if (!opened || !isLookaheadAllowed()) return@launch
            val bytes = getOrFetchChunk(nextOffset)
            if (bytes.isNotEmpty() && opened) {
                runCatching {
                    synchronized(raf) {
                        if (cacheRaf === raf) {
                            raf.seek(nextOffset)
                            raf.write(bytes)
                        }
                    }
                    ClodyStreamCache.markPartialChunkPresent(partialFile, nextIndex)
                }
            }
        }
    }

    private fun evictStaleRamChunks(currentChunkIndex: Long) {
        val minKeepOffset = ((currentChunkIndex - 1L).coerceAtLeast(0L)) * SLIDING_CHUNK_SIZE
        val maxKeepOffset = (currentChunkIndex + 2L) * SLIDING_CHUNK_SIZE
        synchronized(ramSlidingWindow) {
            val it = ramSlidingWindow.keys.iterator()
            while (it.hasNext()) {
                val keyOffset = it.next()
                if (keyOffset < minKeepOffset || keyOffset > maxKeepOffset) {
                    it.remove()
                }
            }
        }
    }

    override fun getUri(): Uri? = uri

    override fun close() {
        uri = null
        lookaheadScope.cancel()
        inFlightChunks.clear()
        synchronized(ramSlidingWindow) {
            ramSlidingWindow.clear()
        }
        runCatching { directRaf?.close() }
        directRaf = null
        directDiskFile = null

        val closedRaf = cacheRaf
        cacheRaf = null
        val closedPartialFile = cacheFile
        cacheFile = null

        runCatching {
            if (closedRaf != null) {
                synchronized(closedRaf) { closedRaf.close() }
            }
        }

        if (closedPartialFile != null && closedPartialFile.exists()) {
            val promoted = ClodyStreamCache.promoteIfComplete(
                context = context,
                file = fileEntity,
                partialFile = closedPartialFile
            )
            val touchTarget = promoted ?: closedPartialFile
            touchTarget.setLastModified(System.currentTimeMillis())
            if (maxCacheBytes < Long.MAX_VALUE) {
                runCatching {
                    ClodyStreamCache.enforceCacheLimit(
                        context = context,
                        maxBytes = maxCacheBytes,
                        excludeFile = touchTarget
                    )
                }
            }
        }

        if (opened) {
            opened = false
            transferEnded()
        }
    }

    private fun hexToBytes(hex: String): ByteArray {
        if (hex.isEmpty() || hex.length % 2 != 0) return ByteArray(0)
        return ByteArray(hex.length / 2) { i ->
            hex.substring(i * 2, i * 2 + 2).toInt(16).toByte()
        }
    }
}

object ClodyStreamCache {
    private const val CACHE_DIR_NAME = "clody_media_cache"
    private val partialChunkBitsets = ConcurrentHashMap<String, BitSet>()

    fun getCacheDir(context: Context): File =
        File(context.cacheDir, CACHE_DIR_NAME).apply { mkdirs() }

    fun getCachedVideoFile(context: Context, file: FileEntity): File {
        val safeName = file.name.replace(Regex("[^a-zA-Z0-9._-]"), "_")
        return File(getCacheDir(context), "stream_${file.id}_${file.telegramMessageId}_$safeName")
    }

    fun getPartialCacheFile(context: Context, file: FileEntity): File {
        val safeName = file.name.replace(Regex("[^a-zA-Z0-9._-]"), "_")
        return File(getCacheDir(context), "partial_${file.id}_${file.telegramMessageId}_$safeName.part")
    }

    fun hasTrackingFor(partialFile: File): Boolean =
        partialChunkBitsets.containsKey(partialFile.absolutePath)

    fun hasPartialChunk(partialFile: File, chunkIndex: Long): Boolean {
        if (chunkIndex < 0L || chunkIndex > Int.MAX_VALUE) return false
        val bitSet = partialChunkBitsets[partialFile.absolutePath] ?: return false
        synchronized(bitSet) {
            return bitSet.get(chunkIndex.toInt())
        }
    }

    fun markPartialChunkPresent(partialFile: File, chunkIndex: Long) {
        if (chunkIndex < 0L || chunkIndex > Int.MAX_VALUE) return
        val bitSet = partialChunkBitsets.getOrPut(partialFile.absolutePath) { BitSet() }
        synchronized(bitSet) {
            bitSet.set(chunkIndex.toInt())
        }
    }

    fun promoteIfComplete(context: Context, file: FileEntity, partialFile: File): File? {
        if (file.sizeBytes <= 0L) return null
        val chunkSize = TelegramChunkDataSource.SLIDING_CHUNK_SIZE.toLong()
        val expectedChunks = ((file.sizeBytes + chunkSize - 1L) / chunkSize).toInt()
        if (expectedChunks <= 0) return null
        val bitSet = partialChunkBitsets[partialFile.absolutePath] ?: return null
        val allComplete = synchronized(bitSet) {
            bitSet.nextClearBit(0) >= expectedChunks
        }
        if (!allComplete) return null

        val finalFile = getCachedVideoFile(context, file)
        return runCatching {
            if (finalFile.exists()) finalFile.delete()
            if (partialFile.renameTo(finalFile)) {
                partialChunkBitsets.remove(partialFile.absolutePath)
                finalFile
            } else {
                null
            }
        }.getOrNull()
    }

    fun isFullyCached(context: Context, file: FileEntity): Boolean {
        val finalFile = getCachedVideoFile(context, file)
        return finalFile.exists() && file.sizeBytes > 0L && finalFile.length() >= file.sizeBytes
    }

    fun deleteFileCache(context: Context, file: FileEntity) {
        runCatching {
            val cached = getCachedVideoFile(context, file)
            if (cached.exists()) cached.delete()
            val partial = getPartialCacheFile(context, file)
            partialChunkBitsets.remove(partial.absolutePath)
            if (partial.exists()) partial.delete()
            file.localCachePath?.let { path ->
                val f = File(path)
                // Never delete pinned offline files when clearing transient stream cache
                if (f.exists() && !f.absolutePath.contains("pinned_offline")) {
                    f.delete()
                }
            }
        }
    }

    /**
     * Enforces the user's Max Cache Size limit (500 MB, 1 GB, 2 GB, 5 GB, Unlimited)
     * by evicting the oldest LRU cached stream files in `cacheDir/clody_media_cache`.
     * Never touches `filesDir/pinned_offline` or `filesDir/thumbnails`.
     */
    fun enforceCacheLimit(context: Context, maxBytes: Long, excludeFile: File? = null) {
        if (maxBytes <= 0L || maxBytes == Long.MAX_VALUE) return
        val dir = getCacheDir(context)
        val files = dir.listFiles()?.filter { it.isFile }?.sortedBy { it.lastModified() } ?: return
        var total = files.sumOf { it.length() }
        for (f in files) {
            if (total <= maxBytes) break
            if (excludeFile != null && f.absolutePath == excludeFile.absolutePath) continue
            val len = f.length()
            if (f.delete()) {
                partialChunkBitsets.remove(f.absolutePath)
                total = (total - len).coerceAtLeast(0L)
            }
        }
    }

    private val TDLIB_MEDIA_TEMP_SUBDIRS = listOf("videos", "photos", "documents", "music", "temp")

    private fun getTdlibMediaTempDirs(context: Context): List<File> {
        val tdFilesRoot = File(context.filesDir, "tdlib_files")
        if (!tdFilesRoot.exists()) return emptyList()
        return TDLIB_MEDIA_TEMP_SUBDIRS.mapNotNull { sub ->
            File(tdFilesRoot, sub).takeIf { it.exists() && it.isDirectory }
        }
    }

    private fun dirSizeBytes(dir: File): Long {
        if (!dir.exists()) return 0L
        var total = 0L
        dir.listFiles()?.forEach { child ->
            if (child.name == "clody_index.json") return@forEach
            total += if (child.isDirectory) dirSizeBytes(child) else child.length()
        }
        return total
    }

    private fun clearDirContents(dir: File): Long {
        if (!dir.exists()) return 0L
        var freed = 0L
        dir.listFiles()?.forEach { child ->
            if (child.name == "clody_index.json") return@forEach
            if (child.isDirectory) {
                freed += clearDirContents(child)
                runCatching { child.delete() }
            } else {
                val len = child.length()
                if (child.delete()) freed += len
            }
        }
        return freed
    }

    /**
     * Safely clears ONLY temporary streamed media caches in `cacheDir/clody_media_cache`,
     * `cacheDir/local_open_temp`, `cacheDir/volatile_stream_ram`, optional `cacheDir/shared_cache`,
     * and TDLib's temporary media subdirs (`filesDir/tdlib_files/{videos, photos, documents, music, temp}`).
     * NEVER deletes TDLib auth/db files (`filesDir/tdlib_db` / `td.binlog`), `clody_index.json`,
     * `filesDir/pinned_offline`, `filesDir/thumbnails`, `filesDir/pending_uploads`, or profile photos.
     */
    fun clearAllStreamCache(context: Context, includeSharedCache: Boolean = true): Long {
        var freed = 0L
        partialChunkBitsets.clear()
        val cacheTargets = buildList {
            add(getCacheDir(context))
            add(File(context.cacheDir, "local_open_temp"))
            add(File(context.cacheDir, "volatile_stream_ram"))
            if (includeSharedCache) {
                add(File(context.cacheDir, "shared_cache"))
            }
        }
        for (dir in cacheTargets) {
            freed += clearDirContents(dir)
        }
        for (tdMediaDir in getTdlibMediaTempDirs(context)) {
            freed += clearDirContents(tdMediaDir)
        }
        return freed
    }

    fun clearStreamCache(context: Context, includeSharedCache: Boolean = true): Long =
        clearAllStreamCache(context, includeSharedCache)

    fun getCurrentCacheBytes(context: Context): Long {
        var total = 0L
        val cacheTargets = listOf(
            getCacheDir(context),
            File(context.cacheDir, "local_open_temp"),
            File(context.cacheDir, "volatile_stream_ram"),
            File(context.cacheDir, "shared_cache")
        )
        for (dir in cacheTargets) {
            total += dirSizeBytes(dir)
        }
        for (tdMediaDir in getTdlibMediaTempDirs(context)) {
            total += dirSizeBytes(tdMediaDir)
        }
        return total
    }

    fun getStreamCacheSizeBytes(context: Context): Long = getCurrentCacheBytes(context)
}
