package com.example.media

import android.content.Context
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.OfflinePin
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.FileEntity
import com.example.data.local.MaxCacheLimit
import com.example.data.local.PlaybackCacheMode
import com.example.telegram.TelegramClientManager
import com.example.ui.theme.EmeraldConnected
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

enum class MediaPlaybackOrigin {
    LOCAL_DEVICE,
    PINNED_OFFLINE,
    CACHED_OFFLINE,
    CLOUD_STREAM;

    companion object {
        val ON_DEVICE: MediaPlaybackOrigin get() = LOCAL_DEVICE
    }
}

sealed interface ResolvedMediaSource {
    val origin: MediaPlaybackOrigin

    data class LocalDevice(
        val uri: Uri,
        val directFile: File?
    ) : ResolvedMediaSource {
        override val origin: MediaPlaybackOrigin = MediaPlaybackOrigin.LOCAL_DEVICE
    }

    data class CloudStream(
        val file: FileEntity,
        val cachedOrPinnedFile: File? = null,
        override val origin: MediaPlaybackOrigin = MediaPlaybackOrigin.CLOUD_STREAM
    ) : ResolvedMediaSource
}

/**
 * Local-First, Dual Playback Mode (`Cache Mode` vs `No-Cache Mode`) & Offline Pinning Resolver:
 * 1. Checks if the file is Pinned Offline (`filesDir/pinned_offline`).
 * 2. Checks if the original device URI (`localSourceUri`) still exists on the phone.
 * 3. Checks if the file is already cached in `cacheDir/clody_media_cache` (Cache Mode).
 * 4. Otherwise streams from Telegram Cloud via TDLib 512 KB chunks.
 */
object LocalFirstResolver {

    fun getPinnedOfflineDir(context: Context): File =
        File(context.filesDir, "pinned_offline").apply { mkdirs() }

    fun getPinnedOfflineFile(context: Context, file: FileEntity): File {
        val safeName = file.name.replace(Regex("[^a-zA-Z0-9._-]"), "_")
        return File(getPinnedOfflineDir(context), "pinned_${file.id}_$safeName")
    }

    fun resolve(context: Context, file: FileEntity, ignoreStreamCache: Boolean = false): ResolvedMediaSource {
        // 1. Check Pinned Offline first (permanent offline storage)
        val pinnedPath = file.pinnedOfflinePath
        if (file.isPinnedOffline && !pinnedPath.isNullOrBlank()) {
            val pf = File(pinnedPath)
            if (pf.exists() && pf.length() > 0L) {
                return ResolvedMediaSource.CloudStream(
                    file = file,
                    cachedOrPinnedFile = pf,
                    origin = MediaPlaybackOrigin.PINNED_OFFLINE
                )
            }
        }
        val defaultPinned = getPinnedOfflineFile(context, file)
        if (file.isPinnedOffline && defaultPinned.exists() && defaultPinned.length() > 0L) {
            return ResolvedMediaSource.CloudStream(
                file = file,
                cachedOrPinnedFile = defaultPinned,
                origin = MediaPlaybackOrigin.PINNED_OFFLINE
            )
        }

        // 2. Check original local device URI
        val uriStr = file.localSourceUri
        if (!uriStr.isNullOrBlank()) {
            val parsed = runCatching { Uri.parse(uriStr) }.getOrNull()
            if (parsed != null && canReadLocalUri(context, parsed)) {
                val directFile = if (parsed.scheme == "file") {
                    parsed.path?.let { File(it) }?.takeIf { it.exists() && it.canRead() }
                } else null
                return ResolvedMediaSource.LocalDevice(parsed, directFile)
            }
        }

        // 3. Check Cache Mode cached file (skip when Zero-Storage / No-Cache mode is active)
        if (!ignoreStreamCache) {
            val cachedFile = file.localCachePath?.let { File(it) }
                ?.takeIf { it.exists() && !it.name.endsWith(".part") && (file.sizeBytes <= 0L || it.length() >= file.sizeBytes) }
                ?: ClodyStreamCache.getCachedVideoFile(context, file)
                    .takeIf { ClodyStreamCache.isFullyCached(context, file) }

            if (cachedFile != null) {
                return ResolvedMediaSource.CloudStream(
                    file = file,
                    cachedOrPinnedFile = cachedFile,
                    origin = MediaPlaybackOrigin.CACHED_OFFLINE
                )
            }
        }

        return ResolvedMediaSource.CloudStream(
            file = file,
            cachedOrPinnedFile = null,
            origin = MediaPlaybackOrigin.CLOUD_STREAM
        )
    }

    fun canReadLocalUri(context: Context, uri: Uri): Boolean {
        return try {
            when (uri.scheme) {
                "file" -> {
                    val f = File(uri.path ?: return false)
                    f.exists() && f.canRead() && f.length() > 0L
                }
                "content" -> {
                    context.contentResolver.openAssetFileDescriptor(uri, "r")?.use { afd ->
                        afd.length != 0L
                    } ?: false
                }
                else -> false
            }
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Loads a file for in-app viewers (ImageViewer, DocumentReader) respecting Cache Mode vs No-Cache Mode.
     */
    suspend fun loadToReadableFile(
        context: Context,
        telegramClient: TelegramClientManager,
        file: FileEntity,
        cacheMode: PlaybackCacheMode = PlaybackCacheMode.CACHE_MODE,
        maxCacheLimit: MaxCacheLimit = MaxCacheLimit.GB_1,
        onProgress: (Float) -> Unit = {}
    ): Pair<File, MediaPlaybackOrigin> = withContext(Dispatchers.IO) {
        when (val resolved = resolve(context, file, ignoreStreamCache = (cacheMode == PlaybackCacheMode.NO_CACHE_MODE))) {
            is ResolvedMediaSource.LocalDevice -> {
                val existingDirect = resolved.directFile
                if (existingDirect != null && existingDirect.exists()) {
                    onProgress(1f)
                    return@withContext existingDirect to MediaPlaybackOrigin.LOCAL_DEVICE
                }
                val tempDir = File(context.cacheDir, "local_open_temp").apply { mkdirs() }
                val safeName = file.name.replace(Regex("[^a-zA-Z0-9._-]"), "_")
                val tempFile = File(tempDir, "local_${file.id}_$safeName")
                if (!tempFile.exists() || tempFile.length() == 0L) {
                    context.contentResolver.openInputStream(resolved.uri)?.use { input ->
                        FileOutputStream(tempFile).use { output ->
                            input.copyTo(output)
                        }
                    } ?: throw IllegalStateException("Cannot open local URI")
                }
                onProgress(1f)
                tempFile to MediaPlaybackOrigin.LOCAL_DEVICE
            }

            is ResolvedMediaSource.CloudStream -> {
                val readyFile = resolved.cachedOrPinnedFile
                if (readyFile != null && readyFile.exists() && readyFile.length() > 0L) {
                    readyFile.setLastModified(System.currentTimeMillis())
                    onProgress(1f)
                    return@withContext readyFile to resolved.origin
                }

                if (file.telegramDocumentId == 0L) {
                    throw IllegalStateException("File has no cloud reference or local copy")
                }

                val targetFile = if (cacheMode == PlaybackCacheMode.NO_CACHE_MODE) {
                    val volatileDir = File(context.cacheDir, "volatile_stream_ram").apply { mkdirs() }
                    val safeName = file.name.replace(Regex("[^a-zA-Z0-9._-]"), "_")
                    File(volatileDir, "volatile_${file.id}_$safeName")
                } else {
                    ClodyStreamCache.getCachedVideoFile(context, file)
                }

                val refBytes = hexToBytes(file.telegramFileReferenceHex)
                val total = maxOf(file.sizeBytes, 1L)
                var offset = if (cacheMode == PlaybackCacheMode.CACHE_MODE && targetFile.exists()) {
                    targetFile.length()
                } else {
                    if (targetFile.exists()) targetFile.delete()
                    0L
                }

                FileOutputStream(targetFile, offset > 0L).use { fos ->
                    while (offset < file.sizeBytes || (file.sizeBytes == 0L && offset == 0L)) {
                        val chunk = telegramClient.downloadChunk(
                            dcId = file.telegramDcId,
                            documentId = file.telegramDocumentId,
                            accessHash = file.telegramAccessHash,
                            fileReference = refBytes,
                            offset = offset,
                            limit = TelegramClientManager.DEFAULT_CHUNK_SIZE
                        )
                        if (chunk.isEmpty()) break
                        fos.write(chunk)
                        offset += chunk.size
                        onProgress((offset.toFloat() / total.toFloat()).coerceIn(0f, 1f))
                        if (chunk.size < TelegramClientManager.DEFAULT_CHUNK_SIZE) break
                    }
                }
                targetFile.setLastModified(System.currentTimeMillis())

                if (cacheMode == PlaybackCacheMode.CACHE_MODE) {
                    ClodyStreamCache.enforceCacheLimit(context, maxCacheLimit.maxBytes, excludeFile = targetFile)
                    onProgress(1f)
                    targetFile to MediaPlaybackOrigin.CACHED_OFFLINE
                } else {
                    onProgress(1f)
                    targetFile to MediaPlaybackOrigin.CLOUD_STREAM
                }
            }
        }
    }

    /**
     * Pins a cloud or local file permanently into `filesDir/pinned_offline` so it plays instantly
     * with 0 internet and is never deleted by "Clear Media Cache" or "No-Cache Mode".
     */
    suspend fun pinFileOffline(
        context: Context,
        telegramClient: TelegramClientManager,
        file: FileEntity,
        onProgress: (Float) -> Unit = {}
    ): Result<File> = withContext(Dispatchers.IO) {
        runCatching {
            val destFile = getPinnedOfflineFile(context, file)
            if (destFile.exists() && file.sizeBytes > 0L && destFile.length() == file.sizeBytes) {
                onProgress(1f)
                return@runCatching destFile
            }

            // Copy from local device or verified complete cache if already present
            val existingCached = ClodyStreamCache.getCachedVideoFile(context, file)
            if (ClodyStreamCache.isFullyCached(context, file) && existingCached.exists()) {
                existingCached.copyTo(destFile, overwrite = true)
                onProgress(1f)
                return@runCatching destFile
            }

            val localUriStr = file.localSourceUri
            if (!localUriStr.isNullOrBlank()) {
                val uri = runCatching { Uri.parse(localUriStr) }.getOrNull()
                if (uri != null && canReadLocalUri(context, uri)) {
                    context.contentResolver.openInputStream(uri)?.use { input ->
                        FileOutputStream(destFile).use { output -> input.copyTo(output) }
                    }
                    if (destFile.exists() && destFile.length() > 0L) {
                        onProgress(1f)
                        return@runCatching destFile
                    }
                }
            }

            // Otherwise invoke full-speed TDLib DownloadFile(priority=32, offset=0, limit=0, synchronous=false)
            // in 100% Original Quality regardless of Wi-Fi or Mobile Data
            val refBytes = hexToBytes(file.telegramFileReferenceHex)
            telegramClient.downloadOriginalFile(
                documentId = file.telegramDocumentId,
                accessHash = file.telegramAccessHash,
                fileReference = refBytes,
                expectedSizeBytes = file.sizeBytes,
                destFile = destFile,
                onProgress = { downloaded, total ->
                    val pct = (downloaded.toFloat() / maxOf(total, 1L).toFloat()).coerceIn(0f, 1f)
                    onProgress(pct)
                }
            )
            onProgress(1f)
            destFile
        }
    }

    fun unpinFileOffline(context: Context, file: FileEntity) {
        file.pinnedOfflinePath?.let { runCatching { File(it).delete() } }
        runCatching { getPinnedOfflineFile(context, file).delete() }
    }

    fun cleanupTempLocalCopies(context: Context, fileId: Long) {
        val tempDir = File(context.cacheDir, "local_open_temp")
        tempDir.listFiles()?.forEach { f ->
            if (f.name.startsWith("local_${fileId}_")) {
                f.delete()
            }
        }
        val volatileDir = File(context.cacheDir, "volatile_stream_ram")
        volatileDir.listFiles()?.forEach { f ->
            if (f.name.startsWith("volatile_${fileId}_")) {
                f.delete()
            }
        }
    }

    private fun hexToBytes(hex: String): ByteArray {
        if (hex.isEmpty() || hex.length % 2 != 0) return ByteArray(0)
        return ByteArray(hex.length / 2) { i ->
            hex.substring(i * 2, i * 2 + 2).toInt(16).toByte()
        }
    }
}

@Composable
fun PlaybackOriginPill(
    origin: MediaPlaybackOrigin,
    darkSurface: Boolean = true,
    modifier: Modifier = Modifier
) {
    val isLocalOrCached = origin != MediaPlaybackOrigin.CLOUD_STREAM
    val bgColor = if (darkSurface) {
        Color.White.copy(alpha = 0.14f)
    } else {
        MaterialTheme.colorScheme.surfaceVariant
    }
    val contentColor = if (darkSurface) Color.White else MaterialTheme.colorScheme.onSurface
    val badgeIcon = when (origin) {
        MediaPlaybackOrigin.LOCAL_DEVICE -> Icons.Default.PhoneAndroid
        MediaPlaybackOrigin.PINNED_OFFLINE -> Icons.Default.OfflinePin
        MediaPlaybackOrigin.CACHED_OFFLINE -> Icons.Default.CheckCircle
        MediaPlaybackOrigin.CLOUD_STREAM -> Icons.Default.Cloud
    }
    val badgeLabel = when (origin) {
        MediaPlaybackOrigin.LOCAL_DEVICE -> "Playing from Device"
        MediaPlaybackOrigin.PINNED_OFFLINE -> "Pinned Offline ✓"
        MediaPlaybackOrigin.CACHED_OFFLINE -> "Cached Offline ✓"
        MediaPlaybackOrigin.CLOUD_STREAM -> "Streaming from Cloud"
    }

    Surface(
        color = bgColor,
        shape = RoundedCornerShape(16.dp),
        modifier = modifier.testTag("playback_origin_pill")
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = badgeIcon,
                contentDescription = null,
                tint = if (isLocalOrCached) EmeraldConnected else contentColor,
                modifier = Modifier.size(13.dp)
            )
            Spacer(modifier = Modifier.width(5.dp))
            Text(
                text = badgeLabel,
                color = contentColor,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
fun DownloadOrSavedPill(
    origin: MediaPlaybackOrigin,
    onDownloadClick: () -> Unit,
    darkMode: Boolean = false,
    modifier: Modifier = Modifier
) {
    if (origin == MediaPlaybackOrigin.LOCAL_DEVICE || origin == MediaPlaybackOrigin.PINNED_OFFLINE) {
        Surface(
            color = EmeraldConnected.copy(alpha = if (darkMode) 0.22f else 0.14f),
            shape = RoundedCornerShape(18.dp),
            modifier = modifier.testTag("saved_on_device_pill")
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = EmeraldConnected,
                    modifier = Modifier.size(15.dp)
                )
                Spacer(modifier = Modifier.width(5.dp))
                Text(
                    text = if (origin == MediaPlaybackOrigin.PINNED_OFFLINE) "Pinned Offline ✓" else "Saved on Device",
                    color = if (darkMode) Color.White else MaterialTheme.colorScheme.onSurface,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    } else {
        Surface(
            color = if (darkMode) Color.White.copy(alpha = 0.16f) else MaterialTheme.colorScheme.primary,
            shape = RoundedCornerShape(18.dp),
            modifier = modifier
                .clip(RoundedCornerShape(18.dp))
                .clickable(onClick = onDownloadClick)
                .testTag("download_to_device_button")
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Download,
                    contentDescription = "Download to Device",
                    tint = if (darkMode) Color.White else MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.size(15.dp)
                )
                Spacer(modifier = Modifier.width(5.dp))
                Text(
                    text = "Download to Device",
                    color = if (darkMode) Color.White else MaterialTheme.colorScheme.onPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}
