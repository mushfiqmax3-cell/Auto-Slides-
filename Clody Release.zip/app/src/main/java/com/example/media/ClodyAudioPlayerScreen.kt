package com.example.media

import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.QueueMusic
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.C
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import com.example.data.local.ClodyDatabase
import com.example.data.local.FileEntity
import com.example.service.ClodyPlaybackController
import com.example.telegram.TelegramClientManager
import com.example.ui.formatFileSize
import com.example.ui.theme.ClodyMotion
import com.example.ui.theme.bounceClick
import kotlinx.coroutines.delay
import java.io.File
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sin

private enum class AudioEqPreset(val label: String) {
    NORMAL("Normal"),
    BASS_BOOST("Bass Boost"),
    VOCAL_CLARITY("Vocal / Lecture Clarity"),
    TREBLE_BOOST("Treble Boost")
}

@kotlin.OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@OptIn(UnstableApi::class)
@Composable
fun ClodyAudioPlayerScreen(
    file: FileEntity,
    telegramClient: TelegramClientManager,
    zeroStorageMode: Boolean,
    onDownloadToDevice: (FileEntity) -> Unit,
    onBack: () -> Unit,
    playlist: List<FileEntity> = emptyList(),
    onSelectAudio: ((FileEntity) -> Unit)? = null,
    onCacheMutated: () -> Unit = {}
) {
    val context = LocalContext.current
    val dao = remember(context) { ClodyDatabase.getInstance(context).clodyDao() }

    var currentTrack by remember(file.id) { mutableStateOf(file) }
    val folderFilesFlow = remember(currentTrack.folderId) {
        dao.observeFilesInFolder(currentTrack.folderId)
    }
    val folderFiles by folderFilesFlow.collectAsStateWithLifecycle(initialValue = emptyList())
    val queueTracks = remember(playlist, folderFiles, currentTrack) {
        val discovered = if (playlist.isNotEmpty()) {
            playlist.filter { it.isAudio }
        } else {
            folderFiles.filter { it.isAudio }
        }
        if (discovered.any { it.id == currentTrack.id }) discovered
        else listOf(currentTrack) + discovered
    }
    val currentQueueIndex = remember(queueTracks, currentTrack.id) {
        queueTracks.indexOfFirst { it.id == currentTrack.id }.coerceAtLeast(0)
    }
    val hasPrevTrack = currentQueueIndex > 0
    val hasNextTrack = currentQueueIndex in 0 until (queueTracks.size - 1)

    val resolvedSource = remember(
        currentTrack.id,
        currentTrack.localSourceUri,
        currentTrack.isPinnedOffline,
        currentTrack.pinnedOfflinePath,
        currentTrack.localCachePath,
        zeroStorageMode
    ) {
        LocalFirstResolver.resolve(context, currentTrack, ignoreStreamCache = zeroStorageMode)
    }
    val origin = resolvedSource.origin

    var isPlaying by remember { mutableStateOf(true) }
    var isBuffering by remember { mutableStateOf(true) }
    var currentPosMs by remember { mutableLongStateOf(0L) }
    var durationMs by remember(currentTrack.id) { mutableLongStateOf(maxOf(currentTrack.durationMs, 1L)) }
    var isScrubbing by remember { mutableStateOf(false) }
    var scrubMs by remember { mutableLongStateOf(0L) }
    var playbackSpeed by remember { mutableFloatStateOf(1.0f) }
    var skipSilenceEnabled by remember { mutableStateOf(false) }
    var isLooping by remember { mutableStateOf(false) }

    // Audio Effects (Equalizer + BassBoost)
    var audioSessionId by remember { mutableIntStateOf(C.AUDIO_SESSION_ID_UNSET) }
    var eqPreset by remember { mutableStateOf(AudioEqPreset.NORMAL) }
    var bassBoostStrength by remember { mutableFloatStateOf(0f) }

    // Sleep Timer
    var sleepTimerRemainingSec by remember { mutableIntStateOf(0) }
    var sleepTimerEndOfTrack by remember { mutableStateOf(false) }

    // A-B Repeat Loop
    var abPointA by remember(currentTrack.id) { mutableStateOf<Long?>(null) }
    var abPointB by remember(currentTrack.id) { mutableStateOf<Long?>(null) }

    // Sheets
    var showEqSheet by remember { mutableStateOf(false) }
    var showSleepSheet by remember { mutableStateOf(false) }
    var showQueueSheet by remember { mutableStateOf(false) }

    val serviceActiveFile by ClodyPlaybackController.activeFile.collectAsStateWithLifecycle()
    LaunchedEffect(serviceActiveFile) {
        val sf = serviceActiveFile
        if (sf != null && sf.id != currentTrack.id && !sf.isVideo) {
            currentPosMs = 0L
            abPointA = null
            abPointB = null
            currentTrack = sf
        }
    }

    // Embedded Album Art loading: Telegram cover (albumCoverMinithumbnail + albumCoverThumbnail) + local/cached ID3 cover + Warm Monochrome fallback
    var fullCoverBitmap by remember(currentTrack.id) {
        mutableStateOf(
            currentTrack.activeThumbnailPath?.let { ThumbnailGenerator.getFromMemoryCache(it) }
                ?: ThumbnailGenerator.getFromMemoryCache(
                    ThumbnailGenerator.getPersistentThumbnailFile(context, currentTrack).absolutePath
                )
        )
    }
    var miniCoverBitmap by remember(currentTrack.id) {
        mutableStateOf(
            if (currentTrack.telegramAccessHash != 0L) {
                ThumbnailGenerator.getFromMemoryCache("mini_${currentTrack.telegramAccessHash}")
            } else null
        )
    }
    var id3CoverBitmap by remember(currentTrack.id) {
        mutableStateOf(ThumbnailGenerator.getFromMemoryCache("audio_id3_${currentTrack.id}"))
    }

    LaunchedEffect(currentTrack.id, resolvedSource) {
        val existingThumbPath = ThumbnailGenerator.resolveExistingThumbnailPath(context, currentTrack)
        if (existingThumbPath != null && fullCoverBitmap == null) {
            fullCoverBitmap = ThumbnailGenerator.decodeBitmapAsync(existingThumbPath, maxSizePx = 512)
        }
        val localDirectPath = (resolvedSource as? ResolvedMediaSource.LocalDevice)?.directFile?.absolutePath
            ?: (resolvedSource as? ResolvedMediaSource.CloudStream)?.cachedOrPinnedFile?.absolutePath
            ?: currentTrack.localCachePath?.takeIf { File(it).exists() }
        val localUri = (resolvedSource as? ResolvedMediaSource.LocalDevice)?.uri
            ?: currentTrack.localSourceUri?.takeIf { it.isNotBlank() }?.let { runCatching { Uri.parse(it) }.getOrNull() }

        if (id3CoverBitmap == null && (!localDirectPath.isNullOrBlank() || localUri != null)) {
            id3CoverBitmap = ThumbnailGenerator.extractEmbeddedAudioCoverAsync(
                context = context,
                filePath = localDirectPath,
                contentUri = localUri,
                cacheKey = "audio_id3_${currentTrack.id}",
                maxSizePx = 512
            )
        }

        if (currentTrack.telegramAccessHash != 0L) {
            if (miniCoverBitmap == null && fullCoverBitmap == null) {
                val miniBytes = telegramClient.getCachedOrFetchMinithumbnail(currentTrack)
                if (miniBytes != null && miniBytes.isNotEmpty()) {
                    miniCoverBitmap = ThumbnailGenerator.decodeBytesAsync(
                        cacheKey = "mini_${currentTrack.telegramAccessHash}",
                        bytes = miniBytes,
                        maxSizePx = 512
                    )
                }
            }
            if (fullCoverBitmap == null) {
                val targetFile = ThumbnailGenerator.getPersistentThumbnailFile(context, currentTrack)
                val downloaded = telegramClient.downloadThumbnailWithSemaphore(currentTrack, targetFile)
                if (downloaded != null) {
                    fullCoverBitmap = ThumbnailGenerator.decodeBitmapAsync(downloaded.absolutePath, maxSizePx = 512)
                }
            }
        }
    }

    val displayArtwork: ImageBitmap? = fullCoverBitmap ?: id3CoverBitmap ?: miniCoverBitmap
    LaunchedEffect(displayArtwork, currentTrack.id) {
        displayArtwork?.let { art ->
            runCatching { art.asAndroidBitmap() }.getOrNull()?.let { bmp ->
                ClodyPlaybackController.updateArtworkBitmap(currentTrack.id, bmp)
            }
        }
    }

    fun switchToTrack(track: FileEntity) {
        currentPosMs = 0L
        abPointA = null
        abPointB = null
        currentTrack = track
        onSelectAudio?.invoke(track)
    }

    fun handleExplicitExit() {
        ClodyPlaybackController.stopAndCleanup(context)
        onBack()
    }

    val exoPlayer = remember(currentTrack.id, zeroStorageMode, queueTracks) {
        ClodyPlaybackController.ensurePlaybackSession(
            context = context,
            file = currentTrack,
            isVideo = false,
            playlist = queueTracks,
            telegramClient = telegramClient,
            zeroStorageMode = zeroStorageMode,
            onCacheMutated = onCacheMutated
        )
    }

    DisposableEffect(exoPlayer) {
        audioSessionId = exoPlayer.audioSessionId
        isPlaying = exoPlayer.isPlaying || exoPlayer.playWhenReady
        isBuffering = exoPlayer.playbackState == Player.STATE_BUFFERING
        if (exoPlayer.duration > 0L) durationMs = exoPlayer.duration
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                isBuffering = state == Player.STATE_BUFFERING
                if (exoPlayer.duration > 0L) durationMs = exoPlayer.duration
                if (state == Player.STATE_ENDED) {
                    if (sleepTimerEndOfTrack) {
                        sleepTimerEndOfTrack = false
                        exoPlayer.pause()
                    } else if (!isLooping && hasNextTrack) {
                        switchToTrack(queueTracks[currentQueueIndex + 1])
                    }
                }
            }

            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }

            override fun onAudioSessionIdChanged(sessionId: Int) {
                audioSessionId = sessionId
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            // Do NOT release ExoPlayer or wipe Zero-Storage cache on mere background/configuration changes;
            // explicit Back / Close calls handleExplicitExit() -> ClodyPlaybackController.stopAndCleanup().
            exoPlayer.removeListener(listener)
        }
    }

    // Safely attach Android Equalizer & BassBoost audio effects to ExoPlayer's audioSessionId
    DisposableEffect(audioSessionId, eqPreset, bassBoostStrength) {
        var equalizer: Equalizer? = null
        var bassBoost: BassBoost? = null
        if (audioSessionId != C.AUDIO_SESSION_ID_UNSET && audioSessionId != 0) {
            runCatching {
                equalizer = Equalizer(0, audioSessionId).apply {
                    enabled = eqPreset != AudioEqPreset.NORMAL
                    val numBands = numberOfBands.toInt()
                    val minLevel = bandLevelRange[0]
                    val maxLevel = bandLevelRange[1]
                    for (band in 0 until numBands) {
                        val level = when (eqPreset) {
                            AudioEqPreset.NORMAL -> 0
                            AudioEqPreset.BASS_BOOST -> when (band) {
                                0 -> (maxLevel * 0.85f).toInt()
                                1 -> (maxLevel * 0.55f).toInt()
                                else -> 0
                            }
                            AudioEqPreset.VOCAL_CLARITY -> when {
                                band == 0 -> (minLevel * 0.4f).toInt()
                                band in 1..(numBands - 2) -> (maxLevel * 0.65f).toInt()
                                else -> (maxLevel * 0.25f).toInt()
                            }
                            AudioEqPreset.TREBLE_BOOST -> when {
                                band >= numBands - 2 -> (maxLevel * 0.80f).toInt()
                                else -> 0
                            }
                        }.coerceIn(minLevel.toInt(), maxLevel.toInt()).toShort()
                        setBandLevel(band.toShort(), level)
                    }
                }
            }
            runCatching {
                bassBoost = BassBoost(0, audioSessionId).apply {
                    val effective = when {
                        bassBoostStrength > 0f -> (bassBoostStrength * 1000f).roundToInt().coerceIn(0, 1000).toShort()
                        eqPreset == AudioEqPreset.BASS_BOOST -> 800.toShort()
                        else -> 0.toShort()
                    }
                    enabled = effective > 0
                    if (strengthSupported && effective > 0) {
                        setStrength(effective)
                    }
                }
            }
        }
        onDispose {
            runCatching { equalizer?.release() }
            runCatching { bassBoost?.release() }
        }
    }

    LaunchedEffect(exoPlayer, playbackSpeed) {
        exoPlayer.playbackParameters = PlaybackParameters(playbackSpeed)
    }

    LaunchedEffect(exoPlayer, skipSilenceEnabled) {
        exoPlayer.skipSilenceEnabled = skipSilenceEnabled
    }

    LaunchedEffect(exoPlayer, isLooping) {
        exoPlayer.repeatMode = if (isLooping) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
    }

    LaunchedEffect(sleepTimerRemainingSec) {
        if (sleepTimerRemainingSec > 0) {
            delay(1000L)
            val next = sleepTimerRemainingSec - 1
            sleepTimerRemainingSec = next
            if (next == 0) {
                exoPlayer.pause()
            }
        }
    }

    LaunchedEffect(exoPlayer, abPointA, abPointB, isPlaying) {
        while (true) {
            if (!isScrubbing) {
                val pos = exoPlayer.currentPosition.coerceAtLeast(0L)
                currentPosMs = pos
                val a = abPointA
                val b = abPointB
                if (a != null && b != null && b > a + 300L && isPlaying && pos >= b) {
                    exoPlayer.seekTo(a)
                    currentPosMs = a
                }
            }
            if (exoPlayer.duration > 0L) durationMs = exoPlayer.duration
            delay(80L)
        }
    }

    BackHandler(onBack = { handleExplicitExit() })

    val infiniteTransition = rememberInfiniteTransition(label = "audio_motion")
    val discAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 12_000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "disc_rotation"
    )
    val wavePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (Math.PI * 2).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave_phase"
    )

    val activeDiscAngle by animateFloatAsState(
        targetValue = if (isPlaying) discAngle else 0f,
        animationSpec = ClodyMotion.defaultSpring(),
        label = "disc_active"
    )

    val bgColor = MaterialTheme.colorScheme.background
    val cardColor = MaterialTheme.colorScheme.surface
    val accentColor = MaterialTheme.colorScheme.primary
    val onAccent = MaterialTheme.colorScheme.onPrimary

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(bgColor)
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp)
            .testTag("clody_audio_player"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Top Header Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Surface(
                color = cardColor,
                shape = CircleShape,
                tonalElevation = 1.dp,
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .clickable(onClick = { handleExplicitExit() })
                    .testTag("audio_back_button")
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
            }
            PlaybackOriginPill(origin = origin, darkSurface = false)
            DownloadOrSavedPill(
                origin = origin,
                onDownloadClick = { onDownloadToDevice(currentTrack) },
                darkMode = false
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Embedded Album Art Card (Telegram coverThumbnail / local ID3) + Warm Monochrome Spinning Vinyl Fallback
        Surface(
            color = cardColor,
            shape = RoundedCornerShape(32.dp),
            tonalElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 22.dp, vertical = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (displayArtwork != null) {
                    Box(
                        modifier = Modifier
                            .size(176.dp)
                            .clip(RoundedCornerShape(24.dp))
                            .border(
                                width = 1.dp,
                                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.22f),
                                shape = RoundedCornerShape(24.dp)
                            )
                            .testTag("audio_album_artwork_image"),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            bitmap = displayArtwork,
                            contentDescription = "${currentTrack.name} album art",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(8.dp)
                                .size(34.dp)
                                .graphicsLayer {
                                    rotationZ = if (isPlaying) activeDiscAngle else 0f
                                }
                                .clip(CircleShape)
                                .background(Color(0xFF141414).copy(alpha = 0.84f))
                                .border(1.dp, Color.White.copy(alpha = 0.28f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.MusicNote,
                                contentDescription = null,
                                tint = Color(0xFFF5F4F0),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .size(152.dp)
                            .graphicsLayer {
                                rotationZ = if (isPlaying) activeDiscAngle else 0f
                            }
                            .testTag("audio_artwork_fallback_vinyl"),
                        contentAlignment = Alignment.Center
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val r = size.minDimension / 2f
                            drawCircle(color = Color(0xFF141414), radius = r)
                            drawCircle(
                                color = Color.White.copy(alpha = 0.14f),
                                radius = r * 0.78f,
                                style = Stroke(width = 2.dp.toPx())
                            )
                            drawCircle(
                                color = Color.White.copy(alpha = 0.10f),
                                radius = r * 0.58f,
                                style = Stroke(width = 1.5.dp.toPx())
                            )
                            drawCircle(color = Color(0xFFF5F4F0), radius = r * 0.24f)
                        }
                        Icon(
                            imageVector = Icons.Default.MusicNote,
                            contentDescription = null,
                            tint = Color(0xFF141414),
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Animated Warm Monochrome Waveform
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(32.dp)
                ) {
                    val bars = 28
                    val barW = size.width / (bars * 1.8f)
                    val gap = (size.width - bars * barW) / (bars - 1)
                    for (i in 0 until bars) {
                        val amp = if (isPlaying) {
                            (0.28f + 0.68f * abs(sin(wavePhase + i * 0.45f))).coerceIn(0.2f, 1f)
                        } else {
                            0.22f
                        }
                        val h = size.height * amp
                        val x = i * (barW + gap)
                        val y = (size.height - h) / 2f
                        drawRoundRect(
                            color = accentColor.copy(alpha = if (isPlaying) 0.85f else 0.35f),
                            topLeft = Offset(x, y),
                            size = Size(barW, h),
                            cornerRadius = CornerRadius(barW / 2f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = currentTrack.name,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "${formatFileSize(currentTrack.sizeBytes)} • ${currentTrack.folderPath}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                // Active Badges (Sleep Timer countdown / A-B Loop status)
                if (sleepTimerRemainingSec > 0 || sleepTimerEndOfTrack || (abPointA != null && abPointB != null)) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (sleepTimerRemainingSec > 0 || sleepTimerEndOfTrack) {
                            Surface(
                                color = accentColor.copy(alpha = 0.12f),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Text(
                                    text = if (sleepTimerEndOfTrack) {
                                        "Sleep: End of Track"
                                    } else {
                                        val m = sleepTimerRemainingSec / 60
                                        val s = sleepTimerRemainingSec % 60
                                        String.format("Sleep %02d:%02d", m, s)
                                    },
                                    color = accentColor,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }
                        if (abPointA != null && abPointB != null) {
                            Surface(
                                color = accentColor,
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Text(
                                    text = "Loop ${formatDuration(abPointA!!)} – ${formatDuration(abPointB!!)}",
                                    color = onAccent,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Interactive Seek Scrubber
                val displayPos = if (isScrubbing) scrubMs else currentPosMs
                val safeDur = maxOf(1L, durationMs).toFloat()
                Slider(
                    value = (displayPos.toFloat() / safeDur).coerceIn(0f, 1f),
                    onValueChange = { frac ->
                        isScrubbing = true
                        scrubMs = (frac * safeDur).toLong()
                    },
                    onValueChangeFinished = {
                        isScrubbing = false
                        currentPosMs = scrubMs
                        exoPlayer.seekTo(scrubMs)
                    },
                    colors = SliderDefaults.colors(
                        thumbColor = accentColor,
                        activeTrackColor = accentColor,
                        inactiveTrackColor = MaterialTheme.colorScheme.surfaceVariant
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = formatDuration(displayPos),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = formatDuration(durationMs),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Transport Controls: Prev, -10s, Play/Pause, +10s, Next
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    IconButton(
                        onClick = { if (hasPrevTrack) switchToTrack(queueTracks[currentQueueIndex - 1]) },
                        enabled = hasPrevTrack,
                        modifier = Modifier.size(48.dp)
                    ) {
                        Icon(Icons.Default.SkipPrevious, contentDescription = "Previous track", modifier = Modifier.size(28.dp))
                    }

                    IconButton(
                        onClick = {
                            val t = (exoPlayer.currentPosition - 10_000L).coerceAtLeast(0L)
                            exoPlayer.seekTo(t)
                            currentPosMs = t
                        },
                        modifier = Modifier.size(48.dp)
                    ) {
                        Icon(Icons.Default.Replay10, contentDescription = "Rewind 10 seconds", modifier = Modifier.size(28.dp))
                    }

                    Box(
                        modifier = Modifier
                            .size(66.dp)
                            .clip(CircleShape)
                            .background(accentColor)
                            .bounceClick {
                                ClodyPlaybackController.togglePlayPause(context)
                            }
                            .testTag("audio_play_pause_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isBuffering) {
                            CircularProgressIndicator(
                                color = onAccent,
                                strokeWidth = 2.5.dp,
                                modifier = Modifier.size(28.dp)
                            )
                        } else {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (isPlaying) "Pause" else "Play",
                                tint = onAccent,
                                modifier = Modifier.size(34.dp)
                            )
                        }
                    }

                    IconButton(
                        onClick = {
                            val t = (exoPlayer.currentPosition + 10_000L).coerceAtMost(durationMs)
                            exoPlayer.seekTo(t)
                            currentPosMs = t
                        },
                        modifier = Modifier.size(48.dp)
                    ) {
                        Icon(Icons.Default.Forward10, contentDescription = "Forward 10 seconds", modifier = Modifier.size(28.dp))
                    }

                    IconButton(
                        onClick = { if (hasNextTrack) switchToTrack(queueTracks[currentQueueIndex + 1]) },
                        enabled = hasNextTrack,
                        modifier = Modifier.size(48.dp)
                    ) {
                        Icon(Icons.Default.SkipNext, contentDescription = "Next track", modifier = Modifier.size(28.dp))
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Speed, Skip Silence & Loop Strip
        Surface(
            color = cardColor,
            shape = RoundedCornerShape(22.dp),
            tonalElevation = 1.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Playback Speed", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                    Surface(
                        color = if (isLooping) accentColor else MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .clickable { isLooping = !isLooping }
                            .testTag("audio_loop_button")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (isLooping) Icons.Default.RepeatOne else Icons.Default.Repeat,
                                contentDescription = "Loop",
                                tint = if (isLooping) onAccent else MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (isLooping) "Loop On" else "Loop",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (isLooping) onAccent else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f, 2.5f, 3.0f).forEach { spd ->
                        val selected = abs(playbackSpeed - spd) < 0.01f
                        FilterChip(
                            selected = selected,
                            onClick = { playbackSpeed = spd },
                            label = { Text(if (spd == 1.0f) "1x" else "${spd}x") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = accentColor,
                                selectedLabelColor = onAccent
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Skip Silence",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Trim silent pauses in lectures & audiobooks",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = skipSilenceEnabled,
                        onCheckedChange = { skipSilenceEnabled = it },
                        modifier = Modifier.testTag("audio_skip_silence_switch")
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // A-B Repeat Card
        Surface(
            color = cardColor,
            shape = RoundedCornerShape(22.dp),
            tonalElevation = 1.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("A-B Repeat Loop", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                    if (abPointA != null || abPointB != null) {
                        Text(
                            text = "Clear",
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp,
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .clickable {
                                    abPointA = null
                                    abPointB = null
                                }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            val pos = exoPlayer.currentPosition.coerceAtLeast(0L)
                            abPointA = pos
                            if (abPointB != null && abPointB!! <= pos + 300L) {
                                abPointB = null
                            }
                        },
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                    ) {
                        Text(abPointA?.let { "A: ${formatDuration(it)}" } ?: "Mark A")
                    }
                    Button(
                        onClick = {
                            val pos = exoPlayer.currentPosition.coerceAtLeast(0L)
                            val startA = abPointA ?: 0L
                            if (abPointA == null) abPointA = 0L
                            if (pos > startA + 300L) {
                                abPointB = pos
                                exoPlayer.seekTo(startA)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = accentColor, contentColor = onAccent),
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                    ) {
                        Text(abPointB?.let { "B: ${formatDuration(it)}" } ?: "Mark B")
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Pro Audio Tools Action Row: Equalizer & Bass Boost, Sleep Timer, Up Next Queue
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Surface(
                color = cardColor,
                shape = RoundedCornerShape(18.dp),
                tonalElevation = 1.dp,
                modifier = Modifier
                    .weight(1f)
                    .heightIn(min = 56.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .clickable { showEqSheet = true }
                    .testTag("audio_eq_button")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(Icons.Default.GraphicEq, contentDescription = "Equalizer", modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (eqPreset == AudioEqPreset.NORMAL && bassBoostStrength == 0f) "EQ" else eqPreset.label.substringBefore(' '),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1
                    )
                }
            }

            Surface(
                color = cardColor,
                shape = RoundedCornerShape(18.dp),
                tonalElevation = 1.dp,
                modifier = Modifier
                    .weight(1f)
                    .heightIn(min = 56.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .clickable { showSleepSheet = true }
                    .testTag("audio_sleep_timer_button")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(Icons.Default.Timer, contentDescription = "Sleep Timer", modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = when {
                            sleepTimerEndOfTrack -> "Track End"
                            sleepTimerRemainingSec > 0 -> "${(sleepTimerRemainingSec + 59) / 60}m"
                            else -> "Timer"
                        },
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1
                    )
                }
            }

            Surface(
                color = accentColor,
                shape = RoundedCornerShape(18.dp),
                tonalElevation = 1.dp,
                modifier = Modifier
                    .weight(1.25f)
                    .heightIn(min = 56.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .clickable { showQueueSheet = true }
                    .testTag("audio_up_next_button")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(Icons.AutoMirrored.Filled.QueueMusic, contentDescription = "Up Next Playlist", tint = onAccent, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Up Next (${queueTracks.size})",
                        color = onAccent,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
    }

    // Equalizer & Bass Boost Modal Sheet
    if (showEqSheet) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(
            onDismissRequest = { showEqSheet = false },
            sheetState = sheetState,
            containerColor = cardColor
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 10.dp)
                    .navigationBarsPadding()
            ) {
                Text("Equalizer & Bass Boost", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(14.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AudioEqPreset.entries.forEach { preset ->
                        FilterChip(
                            selected = eqPreset == preset,
                            onClick = { eqPreset = preset },
                            label = { Text(preset.label) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = accentColor,
                                selectedLabelColor = onAccent
                            )
                        )
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Bass Boost (${(bassBoostStrength * 100f).roundToInt()}%)",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.SemiBold
                )
                Slider(
                    value = bassBoostStrength,
                    onValueChange = { bassBoostStrength = it },
                    colors = SliderDefaults.colors(thumbColor = accentColor, activeTrackColor = accentColor)
                )
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }

    // Sleep Timer Modal Sheet
    if (showSleepSheet) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(
            onDismissRequest = { showSleepSheet = false },
            sheetState = sheetState,
            containerColor = cardColor
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 10.dp)
                    .navigationBarsPadding()
            ) {
                Text("Sleep Timer", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(14.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(15, 30, 45, 60).forEach { mins ->
                        FilterChip(
                            selected = !sleepTimerEndOfTrack && sleepTimerRemainingSec in ((mins - 1) * 60 + 1)..(mins * 60),
                            onClick = {
                                sleepTimerEndOfTrack = false
                                sleepTimerRemainingSec = mins * 60
                                showSleepSheet = false
                            },
                            label = { Text("$mins min") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = accentColor,
                                selectedLabelColor = onAccent
                            )
                        )
                    }
                    FilterChip(
                        selected = sleepTimerEndOfTrack,
                        onClick = {
                            sleepTimerRemainingSec = 0
                            sleepTimerEndOfTrack = true
                            showSleepSheet = false
                        },
                        label = { Text("End of Track") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = accentColor,
                            selectedLabelColor = onAccent
                        )
                    )
                    FilterChip(
                        selected = !sleepTimerEndOfTrack && sleepTimerRemainingSec == 0,
                        onClick = {
                            sleepTimerRemainingSec = 0
                            sleepTimerEndOfTrack = false
                            showSleepSheet = false
                        },
                        label = { Text("Off") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = accentColor,
                            selectedLabelColor = onAccent
                        )
                    )
                }
                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }

    // Folder Playlist ("Up Next") Modal Sheet
    if (showQueueSheet) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(
            onDismissRequest = { showQueueSheet = false },
            sheetState = sheetState,
            containerColor = cardColor
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp)
                    .navigationBarsPadding()
            ) {
                Text(
                    text = "Up Next • ${currentTrack.folderPath}",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(10.dp))
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 380.dp)
                ) {
                    itemsIndexed(
                        items = queueTracks,
                        key = { _, item -> item.id },
                        contentType = { _, _ -> "audio_queue_item" }
                    ) { index, track ->
                        val isActive = track.id == currentTrack.id
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(
                                    if (isActive) accentColor.copy(alpha = 0.12f) else Color.Transparent
                                )
                                .clickable {
                                    switchToTrack(track)
                                    showQueueSheet = false
                                }
                                .padding(horizontal = 12.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (isActive) Icons.Default.Check else Icons.Default.MusicNote,
                                contentDescription = null,
                                tint = if (isActive) accentColor else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = track.name,
                                    fontWeight = if (isActive) FontWeight.Bold else FontWeight.Medium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${index + 1}/${queueTracks.size} • ${formatFileSize(track.sizeBytes)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(14.dp))
            }
        }
    }
}
