package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.DriveFileMove
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CollectionsBookmark
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PermMedia
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.local.FileEntity
import com.example.files.LocalMediaCandidate
import com.example.media.ThumbnailGenerator
import com.example.media.formatDuration
import com.example.service.TransferBatchSummary
import com.example.telegram.TelegramClientManager
import com.example.telegram.TelegramConnectionState
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.LocalClodyMetrics
import com.example.ui.theme.VideoIconIndigo
import com.example.ui.theme.VideoTintSurface
import com.example.ui.theme.bounceClick
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

@Immutable
private data class GalleryMediaUiItem(
    val file: FileEntity,
    val durationLabel: String,
    val formattedSize: String
)

@Immutable
private data class GalleryDateSection(
    val headerLabel: String,
    val pillLabel: String,
    val items: List<GalleryMediaUiItem>,
    val gridItemIndex: Int
)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun GalleryScreen(
    mediaFiles: List<FileEntity>,
    detectedLocalMedia: List<LocalMediaCandidate>,
    hasMediaPermission: Boolean,
    connectionState: TelegramConnectionState,
    batchSummaryFlow: StateFlow<TransferBatchSummary>,
    telegramClient: TelegramClientManager? = null,
    onRequestMediaPermission: () -> Unit,
    onOpenUploadPicker: () -> Unit,
    onOpenOrganizationHub: () -> Unit,
    onOpenTransfers: () -> Unit,
    onUploadDetectedLocal: () -> Unit,
    onDismissDetectedLocal: () -> Unit,
    onOpenPhoto: (FileEntity) -> Unit,
    onOpenVideo: (FileEntity) -> Unit,
    onOpenFileMenu: (FileEntity) -> Unit,
    onOpenConnectionSheet: () -> Unit,
    onShareSelected: (List<FileEntity>) -> Unit = {},
    onDownloadSelected: (List<FileEntity>) -> Unit = {},
    onMoveSelected: (List<FileEntity>) -> Unit = {},
    onDeleteSelected: (List<FileEntity>) -> Unit = {}
) {
    val metrics = LocalClodyMetrics.current
    val gridState = rememberLazyGridState()
    val coroutineScope = rememberCoroutineScope()
    val density = LocalDensity.current

    var selectedIds by remember { mutableStateOf<Set<Long>>(emptySet()) }
    val isSelectionMode = selectedIds.isNotEmpty()

    BackHandler(enabled = isSelectionMode) {
        selectedIds = emptySet()
    }

    // Prune deleted IDs from selection automatically if mediaFiles shrinks
    LaunchedEffect(mediaFiles) {
        if (selectedIds.isNotEmpty()) {
            val validIds = mediaFiles.map { it.id }.toSet()
            selectedIds = selectedIds.intersect(validIds)
        }
    }

    val sortedMedia by produceState<List<FileEntity>>(
        initialValue = emptyList(),
        mediaFiles
    ) {
        value = withContext(Dispatchers.Default) {
            mediaFiles.sortedByDescending { it.createdAt }
        }
    }

    val headerOffset = remember(hasMediaPermission, detectedLocalMedia.size) {
        var count = 1 // gallery_header
        if (!hasMediaPermission) count++
        if (detectedLocalMedia.isNotEmpty()) count++
        count
    }

    val dateSections by produceState<List<GalleryDateSection>?>(
        initialValue = null,
        sortedMedia,
        headerOffset
    ) {
        value = withContext(Dispatchers.Default) {
            if (sortedMedia.isEmpty()) return@withContext emptyList()
            val fullFmt = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
            val pillFmt = SimpleDateFormat("MMM yyyy", Locale.getDefault())

            val nowCal = Calendar.getInstance()
            val todayYear = nowCal.get(Calendar.YEAR)
            val todayDay = nowCal.get(Calendar.DAY_OF_YEAR)
            val yestCal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
            val yestYear = yestCal.get(Calendar.YEAR)
            val yestDay = yestCal.get(Calendar.DAY_OF_YEAR)
            val itemCal = Calendar.getInstance()

            val grouped = linkedMapOf<String, Pair<String, MutableList<GalleryMediaUiItem>>>()
            for (file in sortedMedia) {
                val ts = if (file.createdAt > 0L) file.createdAt else System.currentTimeMillis()
                itemCal.timeInMillis = ts
                val y = itemCal.get(Calendar.YEAR)
                val d = itemCal.get(Calendar.DAY_OF_YEAR)
                val headerLabel = when {
                    y == todayYear && d == todayDay -> "Today"
                    y == yestYear && d == yestDay -> "Yesterday"
                    else -> fullFmt.format(Date(ts))
                }
                val pillLabel = pillFmt.format(Date(ts))
                val entry = grouped.getOrPut(headerLabel) { pillLabel to mutableListOf() }
                entry.second.add(
                    GalleryMediaUiItem(
                        file = file,
                        durationLabel = if (file.durationMs > 0L) formatDuration(file.durationMs) else "Video",
                        formattedSize = formatFileSize(file.sizeBytes)
                    )
                )
            }

            var cursor = headerOffset
            grouped.entries.map { (header, pair) ->
                val section = GalleryDateSection(
                    headerLabel = header,
                    pillLabel = pair.first,
                    items = pair.second,
                    gridItemIndex = cursor
                )
                cursor += 1 + pair.second.size
                section
            }
        }
    }

    val mediaIndexById = remember(sortedMedia) {
        sortedMedia.withIndex().associate { (index, item) -> item.id to index }
    }

    // Track only visible viewport items + 1-row overscan so we never fire 1,000+ offscreen downloads
    val activeViewportFileIds by remember(sortedMedia, mediaIndexById) {
        derivedStateOf {
            val visibleItems = gridState.layoutInfo.visibleItemsInfo
            if (visibleItems.isEmpty() || sortedMedia.isEmpty()) {
                return@derivedStateOf emptySet<Long>()
            }
            val visibleMediaItems = visibleItems.filter { it.key is Long }
            if (visibleMediaItems.isEmpty()) {
                return@derivedStateOf emptySet<Long>()
            }
            val estimatedCols = visibleMediaItems
                .groupBy { it.row }
                .values
                .maxOfOrNull { it.size }
                ?.coerceIn(2, 6) ?: 3
            var minIdx = Int.MAX_VALUE
            var maxIdx = Int.MIN_VALUE
            for (info in visibleMediaItems) {
                val id = info.key as? Long ?: continue
                val pos = mediaIndexById[id] ?: continue
                if (pos < minIdx) minIdx = pos
                if (pos > maxIdx) maxIdx = pos
            }
            if (minIdx == Int.MAX_VALUE || maxIdx == Int.MIN_VALUE) {
                return@derivedStateOf emptySet<Long>()
            }
            val start = (minIdx - estimatedCols).coerceAtLeast(0)
            val end = (maxIdx + estimatedCols).coerceAtMost(sortedMedia.lastIndex)
            val ids = HashSet<Long>(end - start + 1)
            for (i in start..end) {
                ids.add(sortedMedia[i].id)
            }
            ids
        }
    }

    // Fast-scroller drag state
    var isFastScrolling by remember { mutableStateOf(false) }
    var fastScrollFraction by remember { mutableFloatStateOf(0f) }
    var activePillText by remember { mutableStateOf("") }
    var scrollerHeightPx by remember { mutableIntStateOf(1) }

    val passiveFraction by remember(dateSections, headerOffset) {
        derivedStateOf {
            val sections = dateSections.orEmpty()
            if (sections.size <= 1) return@derivedStateOf 0f
            val totalGridItems = sections.last().let { it.gridItemIndex + 1 + it.items.size }
            val maxIndex = (totalGridItems - 1).coerceAtLeast(1)
            (gridState.firstVisibleItemIndex.toFloat() / maxIndex.toFloat()).coerceIn(0f, 1f)
        }
    }
    val displayFraction = if (isFastScrolling) fastScrollFraction else passiveFraction

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Contextual Multi-Select Action Bar
            AnimatedVisibility(visible = isSelectionMode) {
                val selectedFiles = remember(selectedIds, sortedMedia) {
                    sortedMedia.filter { it.id in selectedIds }
                }
                val allSelected = selectedIds.size == sortedMedia.size && sortedMedia.isNotEmpty()
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 2.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .testTag("gallery_multiselect_bar")
                ) {
                    Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = { selectedIds = emptySet() },
                                modifier = Modifier.testTag("gallery_multiselect_close")
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "Cancel selection")
                            }
                            Text(
                                text = "${selectedIds.size} selected",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(1f)
                            )
                            TextButton(
                                onClick = {
                                    selectedIds = if (allSelected) emptySet() else sortedMedia.map { it.id }.toSet()
                                },
                                modifier = Modifier.testTag("gallery_select_all_button")
                            ) {
                                Icon(Icons.Default.SelectAll, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(if (allSelected) "Deselect All" else "Select All")
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            BatchActionIconLabel(
                                icon = Icons.Default.Share,
                                label = "Share",
                                testTag = "gallery_batch_share",
                                onClick = {
                                    onShareSelected(selectedFiles)
                                    selectedIds = emptySet()
                                }
                            )
                            BatchActionIconLabel(
                                icon = Icons.Default.Download,
                                label = "Download",
                                testTag = "gallery_batch_download",
                                onClick = {
                                    onDownloadSelected(selectedFiles)
                                    selectedIds = emptySet()
                                }
                            )
                            BatchActionIconLabel(
                                icon = Icons.AutoMirrored.Filled.DriveFileMove,
                                label = "Move",
                                testTag = "gallery_batch_move",
                                onClick = {
                                    onMoveSelected(selectedFiles)
                                    selectedIds = emptySet()
                                }
                            )
                            BatchActionIconLabel(
                                icon = Icons.Default.DeleteOutline,
                                label = "Delete",
                                tint = CrimsonAlert,
                                testTag = "gallery_batch_delete",
                                onClick = {
                                    onDeleteSelected(selectedFiles)
                                    selectedIds = emptySet()
                                }
                            )
                        }
                    }
                }
            }

            LazyVerticalGrid(
                state = gridState,
                columns = GridCells.Adaptive(minSize = metrics.galleryMinCellSize),
                contentPadding = PaddingValues(
                    start = metrics.horizontalPadding,
                    end = metrics.horizontalPadding,
                    top = if (isSelectionMode) 8.dp else 12.dp,
                    bottom = 160.dp
                ),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .then(if (isSelectionMode) Modifier else Modifier.statusBarsPadding())
            ) {
                // Header + Connection Pill + Gallery Search Trigger + Live Transfer Progress Ring
                item(span = { GridItemSpan(maxLineSpan) }, key = "gallery_header", contentType = "header") {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        if (!isSelectionMode) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Gallery", style = MaterialTheme.typography.displaySmall)
                                TelegramConnectionStatusPill(state = connectionState, onClick = onOpenConnectionSheet)
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                        }

                        // Search Bar Pill (opens Gallery Organization Hub: Favorites, Trash, Albums) + Render-Isolated Transfer Ring
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = MaterialTheme.colorScheme.surface,
                                shape = RoundedCornerShape(28.dp),
                                tonalElevation = 1.dp,
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 50.dp)
                                    .clip(RoundedCornerShape(28.dp))
                                    .bounceClick(onClick = onOpenOrganizationHub)
                                    .testTag("gallery_search_input")
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 13.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.Default.Search,
                                        contentDescription = "Search & Albums",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(
                                        text = "Search, Albums, Favorites",
                                        style = MaterialTheme.typography.bodyLarge,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Icon(
                                        Icons.Default.CollectionsBookmark,
                                        contentDescription = "Albums",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            LiveTransferRingButton(
                                batchSummaryFlow = batchSummaryFlow,
                                onClick = onOpenTransfers
                            )
                        }
                    }
                }

                // Contextual Media Permission Banner (only if not yet granted)
                if (!hasMediaPermission) {
                    item(span = { GridItemSpan(maxLineSpan) }, key = "media_perm_banner", contentType = "banner") {
                        Surface(
                            color = MaterialTheme.colorScheme.surface,
                            shape = RoundedCornerShape(22.dp),
                            modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.surfaceVariant),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.PermMedia, contentDescription = null)
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Auto-Detect New Media", style = MaterialTheme.typography.titleMedium)
                                    Text(
                                        "Allow media access to scan new device photos & videos for backup.",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Button(
                                    onClick = onRequestMediaPermission,
                                    shape = RoundedCornerShape(18.dp),
                                    modifier = Modifier.height(42.dp)
                                ) {
                                    Text("Allow", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }

                // Smart Auto-Backup Prompt Card (STRICTLY ONLY when real new local files are detected)
                if (detectedLocalMedia.isNotEmpty()) {
                    item(span = { GridItemSpan(maxLineSpan) }, key = "smart_backup_card", contentType = "backup_card") {
                        Surface(
                            color = MaterialTheme.colorScheme.surface,
                            shape = RoundedCornerShape(22.dp),
                            tonalElevation = 1.dp,
                            modifier = Modifier.fillMaxWidth().padding(top = 6.dp).testTag("detected_media_card")
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "Found ${detectedLocalMedia.size} items. Do you want to upload them?",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    items(
                                        items = detectedLocalMedia,
                                        key = { it.id },
                                        contentType = { "detected_local_thumb" }
                                    ) { item ->
                                        val thumbFile by produceState<File?>(initialValue = null, item.thumbnailPath) {
                                            value = item.thumbnailPath?.let { path ->
                                                withContext(Dispatchers.IO) { File(path).takeIf(File::exists) }
                                            }
                                        }
                                        Box(
                                            modifier = Modifier
                                                .size(66.dp)
                                                .clip(RoundedCornerShape(14.dp))
                                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                        ) {
                                            if (thumbFile != null) {
                                                AsyncImage(
                                                    model = thumbFile,
                                                    contentDescription = item.displayName,
                                                    contentScale = ContentScale.Crop,
                                                    modifier = Modifier.fillMaxSize()
                                                )
                                            } else {
                                                Icon(
                                                    Icons.Default.VideoFile,
                                                    contentDescription = null,
                                                    modifier = Modifier.align(Alignment.Center)
                                                )
                                            }
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(12.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    OutlinedButton(
                                        onClick = onDismissDetectedLocal,
                                        shape = RoundedCornerShape(22.dp),
                                        modifier = Modifier.weight(1f).height(46.dp)
                                    ) {
                                        Text("Cancel")
                                    }
                                    Button(
                                        onClick = onUploadDetectedLocal,
                                        shape = RoundedCornerShape(22.dp),
                                        modifier = Modifier.weight(1f).height(46.dp)
                                    ) {
                                        Text("Upload")
                                    }
                                }
                            }
                        }
                    }
                }

                // Clean 100% Empty State when no media has been uploaded
                val sections = dateSections
                if (sections != null && sections.isEmpty()) {
                    item(span = { GridItemSpan(maxLineSpan) }, key = "gallery_empty", contentType = "empty") {
                        ClodyEmptyStateCard(
                            title = "No files yet",
                            subtitle = "Tap + Upload to add your photos, videos, or files",
                            ctaLabel = "Upload",
                            onCtaClick = onOpenUploadPicker,
                            modifier = Modifier.padding(top = 18.dp)
                        )
                    }
                } else if (sections != null) {
                    sections.forEach { section ->
                        item(
                            span = { GridItemSpan(maxLineSpan) },
                            key = "date_${section.headerLabel}",
                            contentType = "date_header"
                        ) {
                            Text(
                                text = section.headerLabel,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)
                            )
                        }

                        items(
                            items = section.items,
                            key = { it.file.id },
                            contentType = { if (it.file.isVideo) "video_thumb" else "image_thumb" }
                        ) { uiItem ->
                            val file = uiItem.file
                            val isInViewportWindow = file.id in activeViewportFileIds
                            val isSelected = file.id in selectedIds
                            GalleryMediaCell(
                                file = file,
                                durationLabel = uiItem.durationLabel,
                                isInViewportWindow = isInViewportWindow,
                                isSelectionMode = isSelectionMode,
                                isSelected = isSelected,
                                telegramClient = telegramClient,
                                onToggleSelection = {
                                    selectedIds = if (isSelected) selectedIds - file.id else selectedIds + file.id
                                },
                                onEnterSelection = {
                                    selectedIds = selectedIds + file.id
                                },
                                onOpenPhoto = onOpenPhoto,
                                onOpenVideo = onOpenVideo,
                                onOpenFileMenu = onOpenFileMenu
                            )
                        }
                    }
                }
            }
        }

        // Google-Photos Style Right-Edge Draggable Timeline Fast-Scroller
        val sections = dateSections.orEmpty()
        if (sections.size >= 2 || sortedMedia.size >= 12) {
            Box(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .fillMaxHeight()
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(top = 140.dp, bottom = 165.dp, end = 4.dp)
                    .width(42.dp)
                    .onSizeChanged { scrollerHeightPx = maxOf(it.height, 1) }
                    .pointerInput(sections) {
                        detectVerticalDragGestures(
                            onDragStart = { offset ->
                                if (sections.isEmpty()) return@detectVerticalDragGestures
                                isFastScrolling = true
                                val frac = (offset.y / scrollerHeightPx.toFloat()).coerceIn(0f, 1f)
                                fastScrollFraction = frac
                                val sectionIdx = (frac * sections.lastIndex).roundToInt().coerceIn(0, sections.lastIndex)
                                val targetSection = sections[sectionIdx]
                                activePillText = targetSection.pillLabel
                                coroutineScope.launch {
                                    gridState.scrollToItem(targetSection.gridItemIndex)
                                }
                            },
                            onVerticalDrag = { change, _ ->
                                change.consume()
                                if (sections.isEmpty()) return@detectVerticalDragGestures
                                val frac = (change.position.y / scrollerHeightPx.toFloat()).coerceIn(0f, 1f)
                                fastScrollFraction = frac
                                val sectionIdx = (frac * sections.lastIndex).roundToInt().coerceIn(0, sections.lastIndex)
                                val targetSection = sections[sectionIdx]
                                activePillText = targetSection.pillLabel
                                coroutineScope.launch {
                                    gridState.scrollToItem(targetSection.gridItemIndex)
                                }
                            },
                            onDragEnd = { isFastScrolling = false },
                            onDragCancel = { isFastScrolling = false }
                        )
                    }
                    .testTag("gallery_timeline_fast_scroller")
            ) {
                val thumbSizePx = with(density) { 44.dp.toPx() }
                val travelPx = (scrollerHeightPx - thumbSizePx).coerceAtLeast(1f)
                val thumbY = (displayFraction * travelPx).roundToInt()

                // Floating Date Pill alongside the drag handle
                AnimatedVisibility(
                    visible = isFastScrolling && activePillText.isNotBlank(),
                    enter = fadeIn(),
                    exit = fadeOut(),
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .offset { IntOffset(-with(density) { 52.dp.roundToPx() }, thumbY) }
                ) {
                    Surface(
                        color = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary,
                        shape = RoundedCornerShape(18.dp),
                        tonalElevation = 4.dp,
                        modifier = Modifier.testTag("gallery_fast_scroller_date_pill")
                    ) {
                        Text(
                            text = activePillText,
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                        )
                    }
                }

                // Draggable Handle Thumb
                Surface(
                    color = if (isFastScrolling) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
                    contentColor = if (isFastScrolling) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                    shape = RoundedCornerShape(18.dp),
                    tonalElevation = 3.dp,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .offset { IntOffset(0, thumbY) }
                        .width(26.dp)
                        .height(44.dp)
                        .border(
                            width = 1.dp,
                            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.28f),
                            shape = RoundedCornerShape(18.dp)
                        )
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .width(10.dp)
                                .height(2.dp)
                                .background(
                                    if (isFastScrolling) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                    RoundedCornerShape(1.dp)
                                )
                        )
                        Spacer(modifier = Modifier.height(3.dp))
                        Box(
                            modifier = Modifier
                                .width(10.dp)
                                .height(2.dp)
                                .background(
                                    if (isFastScrolling) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                    RoundedCornerShape(1.dp)
                                )
                        )
                    }
                }
            }
        }

        // Gallery Bottom-Right Elevated Floating "+ Upload" Pill CTA (hidden while multi-selecting)
        if (!isSelectionMode) {
            Surface(
                color = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                shape = RoundedCornerShape(28.dp),
                tonalElevation = 2.dp,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .navigationBarsPadding()
                    .padding(end = metrics.horizontalPadding, bottom = 92.dp)
                    .heightIn(min = 52.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .bounceClick(onClick = onOpenUploadPicker)
                    .testTag("gallery_upload_button")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Upload",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
internal fun BatchActionIconLabel(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    tint: Color = MaterialTheme.colorScheme.onSurface,
    testTag: String,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .testTag(testTag),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(22.dp))
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = tint,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
private fun GalleryMediaCell(
    file: FileEntity,
    durationLabel: String,
    isInViewportWindow: Boolean,
    isSelectionMode: Boolean,
    isSelected: Boolean,
    telegramClient: TelegramClientManager?,
    onToggleSelection: () -> Unit,
    onEnterSelection: () -> Unit,
    onOpenPhoto: (FileEntity) -> Unit,
    onOpenVideo: (FileEntity) -> Unit,
    onOpenFileMenu: (FileEntity) -> Unit
) {
    val context = LocalContext.current
    val initialCachedBitmap = remember(file.id, file.activeThumbnailPath) {
        val active = file.activeThumbnailPath
        val persistent = ThumbnailGenerator.getPersistentThumbnailFile(context, file).absolutePath
        (active?.let { ThumbnailGenerator.getFromMemoryCache(it) })
            ?: ThumbnailGenerator.getFromMemoryCache(persistent)
            ?: ThumbnailGenerator.getFromMemoryCache("mini_${file.telegramAccessHash}")
    }
    var fullBitmap by remember(file.id, file.activeThumbnailPath) {
        mutableStateOf(
            file.activeThumbnailPath?.let { ThumbnailGenerator.getFromMemoryCache(it) }
                ?: ThumbnailGenerator.getFromMemoryCache(
                    ThumbnailGenerator.getPersistentThumbnailFile(context, file).absolutePath
                )
        )
    }
    var miniBitmap by remember(file.id) {
        mutableStateOf(
            if (file.telegramAccessHash != 0L) {
                ThumbnailGenerator.getFromMemoryCache("mini_${file.telegramAccessHash}")
            } else null
        )
    }

    // 1. Check permanent local thumbnail store on Dispatchers.IO + render TDLib minithumbnail immediately at zero file-download cost
    LaunchedEffect(file.id, file.activeThumbnailPath) {
        if (fullBitmap == null) {
            val existingPath = ThumbnailGenerator.resolveExistingThumbnailPath(context, file)
            if (existingPath != null) {
                fullBitmap = ThumbnailGenerator.decodeBitmapAsync(existingPath)
            }
        }
        if (fullBitmap == null && miniBitmap == null && telegramClient != null && file.telegramAccessHash != 0L) {
            val miniBytes = telegramClient.getCachedOrFetchMinithumbnail(file)
            if (miniBytes != null && miniBytes.isNotEmpty()) {
                miniBitmap = ThumbnailGenerator.decodeBytesAsync("mini_${file.telegramAccessHash}", miniBytes)
            }
        }
    }

    // 2. Viewport-only full preview download gated by Semaphore(3) and saved permanently into filesDir/thumbnails
    LaunchedEffect(isInViewportWindow, file.id, file.telegramAccessHash) {
        if (isInViewportWindow && fullBitmap == null && telegramClient != null && file.telegramAccessHash != 0L) {
            val targetFile = ThumbnailGenerator.getPersistentThumbnailFile(context, file)
            val downloaded = telegramClient.downloadThumbnailWithSemaphore(file, targetFile)
            if (downloaded != null) {
                fullBitmap = ThumbnailGenerator.decodeBitmapAsync(downloaded.absolutePath)
            }
        }
    }

    val displayBitmap: ImageBitmap? = fullBitmap ?: miniBitmap ?: initialCachedBitmap

    Box(
        modifier = Modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(16.dp))
            .background(if (file.isVideo) VideoTintSurface else MaterialTheme.colorScheme.surfaceVariant)
            .then(
                if (isSelected) {
                    Modifier.border(3.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(16.dp))
                } else Modifier
            )
            .bounceClick(
                onLongClick = { onEnterSelection() }
            ) {
                if (isSelectionMode) {
                    onToggleSelection()
                } else if (file.isVideo) {
                    onOpenVideo(file)
                } else {
                    onOpenPhoto(file)
                }
            }
            .testTag("gallery_item_${file.id}")
    ) {
        if (displayBitmap != null) {
            Image(
                bitmap = displayBitmap,
                contentDescription = file.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Icon(
                imageVector = if (file.isVideo) Icons.Default.VideoFile else Icons.Default.Image,
                contentDescription = file.name,
                tint = if (file.isVideo) VideoIconIndigo else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(34.dp).align(Alignment.Center)
            )
        }

        if (isSelected) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.22f))
            )
        }

        if (isSelectionMode) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(6.dp)
                    .size(22.dp)
                    .clip(CircleShape)
                    .background(if (isSelected) MaterialTheme.colorScheme.primary else Color.Black.copy(alpha = 0.45f))
                    .border(1.5.dp, Color.White, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                if (isSelected) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Selected",
                        tint = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        if (file.isVideo) {
            Surface(
                color = Color.Black.copy(alpha = 0.68f),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(6.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(2.dp))
                    Text(
                        text = durationLabel,
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        if (!isSelectionMode) {
            IconButton(
                onClick = { onOpenFileMenu(file) },
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(4.dp)
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.45f))
            ) {
                Icon(
                    Icons.Default.MoreVert,
                    contentDescription = "More options for ${file.name}",
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}
