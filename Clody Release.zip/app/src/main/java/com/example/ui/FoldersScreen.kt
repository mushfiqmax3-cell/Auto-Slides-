package com.example.ui

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.DriveFileMove
import androidx.compose.material.icons.automirrored.filled.InsertDriveFile
import androidx.compose.material.icons.automirrored.filled.Label
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.automirrored.filled.ViewList
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.FileEntity
import com.example.data.local.FolderEntity
import com.example.data.local.SortOption
import com.example.media.ThumbnailGenerator
import com.example.media.formatDuration
import com.example.telegram.TelegramClientManager
import com.example.telegram.TelegramConnectionState
import com.example.ui.theme.AmberConnecting
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.EmeraldConnected
import com.example.ui.theme.FavoriteGold
import com.example.ui.theme.VideoIconIndigo
import com.example.ui.theme.VideoTintSurface
import com.example.ui.theme.bounceClick
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

enum class FileManagerCategory(
    val label: String,
    val accentColor: Color,
    val icon: ImageVector
) {
    IMAGES("Images", Color(0xFF2563EB), Icons.Default.Image),
    VIDEOS("Videos", Color(0xFFEF4444), Icons.Default.VideoFile),
    AUDIO("Audio", Color(0xFF334155), Icons.Default.GraphicEq),
    DOCUMENTS("Documents", Color(0xFFF59E0B), Icons.Default.Description),
    APKS("APKs", Color(0xFF22C55E), Icons.Default.Android),
    ARCHIVES("Archives", Color(0xFFEAB308), Icons.Default.FolderZip),
    TAGS("Tags", Color(0xFF3B82F6), Icons.AutoMirrored.Filled.Label);

    fun matches(file: FileEntity): Boolean = when (this) {
        IMAGES -> file.isImage
        VIDEOS -> file.isVideo
        AUDIO -> file.isAudio
        DOCUMENTS -> file.isDocument
        APKS -> file.isApp
        ARCHIVES -> file.isArchive
        TAGS -> file.isFavorite
    }
}

@Immutable
private data class FolderGridUiItem(
    val folder: FolderEntity,
    val itemCount: Int,
    val itemCountLabel: String
)

@Immutable
private data class FolderFileUiItem(
    val file: FileEntity,
    val displayName: String,
    val formattedSize: String
)

@Composable
fun FoldersScreen(
    connectionState: TelegramConnectionState,
    breadcrumbs: List<FolderEntity>,
    subfolders: List<FolderEntity>,
    files: List<FileEntity>,
    allActiveFiles: List<FileEntity> = files,
    folderItemCounts: Map<Long, Int> = emptyMap(),
    telegramClient: TelegramClientManager? = null,
    isGridView: Boolean,
    showFileExtensions: Boolean,
    sortOption: SortOption,
    onToggleGridView: (Boolean) -> Unit,
    onChangeSort: (SortOption) -> Unit,
    onJumpToSearch: () -> Unit,
    onSyncCloud: () -> Unit,
    onOpenConnectionSheet: () -> Unit,
    onOpenUploadPicker: () -> Unit,
    onCreateFolder: (String) -> Unit,
    onOpenFolder: (FolderEntity) -> Unit,
    onNavigateRoot: () -> Unit,
    onNavigateBreadcrumb: (Long) -> Unit,
    onNavigateUp: () -> Boolean,
    onOpenFile: (FileEntity) -> Unit,
    onToggleFavorite: (FileEntity) -> Unit,
    onOpenFileMenu: (FileEntity) -> Unit,
    onRenameFolder: (FolderEntity, String) -> Unit = { _, _ -> },
    onMoveFolder: (FolderEntity) -> Unit = {},
    onDownloadFolder: (FolderEntity) -> Unit = {},
    onShareFolder: (FolderEntity) -> Unit = {},
    onDeleteFolder: (FolderEntity) -> Unit = {},
    onMoveFile: (FileEntity) -> Unit = {},
    onCopyFile: (FileEntity) -> Unit = {},
    onDownloadFile: (FileEntity) -> Unit = {},
    onShareFileItem: (FileEntity) -> Unit = {},
    onRenameFileItem: (FileEntity, String) -> Unit = { _, _ -> },
    onDeleteFileItem: (FileEntity) -> Unit = {},
    onBatchShare: (List<FileEntity>, List<FolderEntity>) -> Unit = { _, _ -> },
    onBatchDownload: (List<FileEntity>, List<FolderEntity>) -> Unit = { _, _ -> },
    onBatchMove: (List<FileEntity>, List<FolderEntity>) -> Unit = { _, _ -> },
    onBatchDelete: (List<FileEntity>, List<FolderEntity>) -> Unit = { _, _ -> }
) {
    var showNewFolderDialog by remember { mutableStateOf(false) }
    var showSortMenu by remember { mutableStateOf(false) }
    var activeCategory by remember { mutableStateOf<FileManagerCategory?>(null) }
    var categoryQuery by remember { mutableStateOf("") }

    var renameFolderTarget by remember { mutableStateOf<FolderEntity?>(null) }
    var renameFileTarget by remember { mutableStateOf<FileEntity?>(null) }

    var selectedFileIds by remember { mutableStateOf<Set<Long>>(emptySet()) }
    var selectedFolderIds by remember { mutableStateOf<Set<Long>>(emptySet()) }
    val isSelectionMode = selectedFileIds.isNotEmpty() || selectedFolderIds.isNotEmpty()

    // Clear selection automatically when switching folders or categories
    LaunchedEffect(breadcrumbs, activeCategory) {
        selectedFileIds = emptySet()
        selectedFolderIds = emptySet()
    }

    val categoryCounts by produceState<Map<FileManagerCategory, Int>>(
        initialValue = emptyMap(),
        allActiveFiles
    ) {
        value = withContext(Dispatchers.Default) {
            FileManagerCategory.entries.associateWith { cat -> allActiveFiles.count { cat.matches(it) } }
        }
    }

    val categoryFilteredFiles by produceState<List<FileEntity>>(
        initialValue = emptyList(),
        activeCategory,
        categoryQuery,
        allActiveFiles,
        sortOption
    ) {
        value = withContext(Dispatchers.Default) {
            val cat = activeCategory ?: return@withContext emptyList()
            val q = categoryQuery.trim().lowercase()
            val matching = allActiveFiles.filter { f ->
                cat.matches(f) && (q.isEmpty() || f.name.lowercase().contains(q) || f.extension.lowercase().contains(q) || f.folderPath.lowercase().contains(q))
            }
            when (sortOption) {
                SortOption.DATE_DESC -> matching.sortedByDescending { it.createdAt }
                SortOption.NAME_ASC -> matching.sortedBy { it.name.lowercase() }
                SortOption.SIZE_DESC -> matching.sortedByDescending { it.sizeBytes }
            }
        }
    }

    val isRootDirectory = activeCategory == null && breadcrumbs.isEmpty()
    val displayedFiles = when {
        activeCategory != null -> categoryFilteredFiles
        isRootDirectory -> emptyList()
        else -> files
    }
    val displayedFolders = if (activeCategory != null) emptyList() else subfolders

    val gridState = rememberLazyGridState()
    val listState = rememberLazyListState()

    val fileIndexById = remember(displayedFiles) {
        displayedFiles.withIndex().associate { (index, item) -> item.id to index }
    }

    val activeViewportFileIds by remember(displayedFiles, fileIndexById, isGridView) {
        derivedStateOf {
            if (displayedFiles.isEmpty()) return@derivedStateOf emptySet<Long>()
            val visibleKeys = if (isGridView) {
                gridState.layoutInfo.visibleItemsInfo.mapNotNull { it.key as? String }
            } else {
                listState.layoutInfo.visibleItemsInfo.mapNotNull { it.key as? String }
            }
            val visibleIndices = visibleKeys.mapNotNull { key ->
                val rawId = when {
                    key.startsWith("file_l_") -> key.removePrefix("file_l_").toLongOrNull()
                    key.startsWith("file_") -> key.removePrefix("file_").toLongOrNull()
                    else -> null
                }
                rawId?.let { fileIndexById[it] }
            }
            if (visibleIndices.isEmpty()) {
                return@derivedStateOf displayedFiles.take(12).map { it.id }.toSet()
            }
            val overscan = if (isGridView) 6 else 4
            val start = (visibleIndices.min() - overscan).coerceAtLeast(0)
            val end = (visibleIndices.max() + overscan).coerceAtMost(displayedFiles.lastIndex)
            val ids = HashSet<Long>(end - start + 1)
            for (i in start..end) {
                ids.add(displayedFiles[i].id)
            }
            ids
        }
    }

    val displayedFolderUiItems by produceState<List<FolderGridUiItem>>(
        initialValue = displayedFolders.map { folder ->
            val count = folderItemCounts[folder.id] ?: 0
            FolderGridUiItem(
                folder = folder,
                itemCount = count,
                itemCountLabel = if (count == 1) "1 item" else "$count items"
            )
        },
        displayedFolders,
        folderItemCounts
    ) {
        value = withContext(Dispatchers.Default) {
            displayedFolders.map { folder ->
                val count = folderItemCounts[folder.id] ?: 0
                FolderGridUiItem(
                    folder = folder,
                    itemCount = count,
                    itemCountLabel = if (count == 1) "1 item" else "$count items"
                )
            }
        }
    }

    val displayedFileUiItems by produceState<List<FolderFileUiItem>>(
        initialValue = emptyList(),
        displayedFiles,
        showFileExtensions
    ) {
        value = withContext(Dispatchers.Default) {
            displayedFiles.map { file ->
                FolderFileUiItem(
                    file = file,
                    displayName = if (showFileExtensions) file.name else file.name.substringBeforeLast('.'),
                    formattedSize = formatFileSize(file.sizeBytes)
                )
            }
        }
    }

    BackHandler(enabled = isSelectionMode) {
        selectedFileIds = emptySet()
        selectedFolderIds = emptySet()
    }
    BackHandler(enabled = !isSelectionMode && activeCategory != null) {
        activeCategory = null
        categoryQuery = ""
    }
    BackHandler(enabled = !isSelectionMode && activeCategory == null && breadcrumbs.isNotEmpty()) {
        onNavigateUp()
    }

    val dotColor = when (connectionState) {
        is TelegramConnectionState.Connected -> EmeraldConnected
        is TelegramConnectionState.Connecting -> AmberConnecting
        is TelegramConnectionState.Disconnected -> CrimsonAlert
    }
    val statusSubtext = when (connectionState) {
        is TelegramConnectionState.Connected -> connectionState.userDisplayName ?: "Connected"
        is TelegramConnectionState.Connecting -> "Connecting..."
        is TelegramConnectionState.Disconnected -> "Tap to Connect"
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(horizontal = 16.dp)
    ) {
        if (isSelectionMode) {
            val selectedFiles = remember(selectedFileIds, displayedFiles) {
                displayedFiles.filter { it.id in selectedFileIds }
            }
            val selectedFolders = remember(selectedFolderIds, displayedFolders) {
                displayedFolders.filter { it.id in selectedFolderIds }
            }
            val totalSelected = selectedFiles.size + selectedFolders.size
            val allSelected = displayedFiles.all { it.id in selectedFileIds } &&
                displayedFolders.all { it.id in selectedFolderIds } &&
                (displayedFiles.isNotEmpty() || displayedFolders.isNotEmpty())

            Surface(
                color = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(22.dp),
                tonalElevation = 2.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp)
                    .testTag("folders_multiselect_bar")
            ) {
                Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = {
                                selectedFileIds = emptySet()
                                selectedFolderIds = emptySet()
                            },
                            modifier = Modifier.testTag("folders_multiselect_close")
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Cancel selection")
                        }
                        Text(
                            text = "$totalSelected selected",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(
                            onClick = {
                                if (allSelected) {
                                    selectedFileIds = emptySet()
                                    selectedFolderIds = emptySet()
                                } else {
                                    selectedFileIds = displayedFiles.map { it.id }.toSet()
                                    selectedFolderIds = displayedFolders.map { it.id }.toSet()
                                }
                            },
                            modifier = Modifier.testTag("folders_select_all_button")
                        ) {
                            Icon(Icons.Default.SelectAll, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (allSelected) "Deselect All" else "Select All")
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        BatchActionIconLabel(
                            icon = Icons.Default.Share,
                            label = "Share",
                            testTag = "folders_batch_share",
                            onClick = {
                                onBatchShare(selectedFiles, selectedFolders)
                                selectedFileIds = emptySet()
                                selectedFolderIds = emptySet()
                            }
                        )
                        BatchActionIconLabel(
                            icon = Icons.Default.Download,
                            label = "Download",
                            testTag = "folders_batch_download",
                            onClick = {
                                onBatchDownload(selectedFiles, selectedFolders)
                                selectedFileIds = emptySet()
                                selectedFolderIds = emptySet()
                            }
                        )
                        BatchActionIconLabel(
                            icon = Icons.AutoMirrored.Filled.DriveFileMove,
                            label = "Move",
                            testTag = "folders_batch_move",
                            onClick = {
                                onBatchMove(selectedFiles, selectedFolders)
                                selectedFileIds = emptySet()
                                selectedFolderIds = emptySet()
                            }
                        )
                        BatchActionIconLabel(
                            icon = Icons.Default.DeleteOutline,
                            label = "Delete",
                            tint = CrimsonAlert,
                            testTag = "folders_batch_delete",
                            onClick = {
                                onBatchDelete(selectedFiles, selectedFolders)
                                selectedFileIds = emptySet()
                                selectedFolderIds = emptySet()
                            }
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
        } else {
            Spacer(modifier = Modifier.height(10.dp))
        }

        // Top Bar (Standard File Manager vs Active Category Filtered View)
        val cat = activeCategory
        if (cat != null) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        activeCategory = null
                        categoryQuery = ""
                    },
                    modifier = Modifier.testTag("category_back_button")
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back to File Manager")
                }
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(cat.accentColor.copy(alpha = 0.16f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(cat.icon, contentDescription = null, tint = cat.accentColor, modifier = Modifier.size(18.dp))
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(cat.label, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text(
                        "${categoryFilteredFiles.size} item(s)",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Box {
                    CircularHeaderIcon(Icons.AutoMirrored.Filled.Sort, "Sort") { showSortMenu = true }
                    SortDropdownMenu(
                        expanded = showSortMenu,
                        sortOption = sortOption,
                        onChangeSort = onChangeSort,
                        onDismiss = { showSortMenu = false }
                    )
                }
                Spacer(modifier = Modifier.width(6.dp))
                CircularHeaderIcon(
                    icon = if (isGridView) Icons.AutoMirrored.Filled.ViewList else Icons.Default.GridView,
                    desc = "Switch view",
                    onClick = { onToggleGridView(!isGridView) }
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = categoryQuery,
                onValueChange = { categoryQuery = it },
                placeholder = { Text("Search ${cat.label.lowercase()}...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (categoryQuery.isNotEmpty()) {
                        IconButton(onClick = { categoryQuery = "" }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear search")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(22.dp),
                modifier = Modifier.fillMaxWidth().testTag("category_search_input")
            )
            Spacer(modifier = Modifier.height(12.dp))
        } else {
            // Standard Header Row
            if (!isSelectionMode) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.clickable(onClick = onOpenConnectionSheet)) {
                        Text("Files", style = MaterialTheme.typography.displaySmall)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(dotColor)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = statusSubtext,
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        CircularHeaderIcon(Icons.Default.Search, "Search", onJumpToSearch)
                        Box {
                            CircularHeaderIcon(Icons.AutoMirrored.Filled.Sort, "Sort") { showSortMenu = true }
                            SortDropdownMenu(
                                expanded = showSortMenu,
                                sortOption = sortOption,
                                onChangeSort = onChangeSort,
                                onDismiss = { showSortMenu = false }
                            )
                        }
                        CircularHeaderIcon(
                            icon = if (isGridView) Icons.AutoMirrored.Filled.ViewList else Icons.Default.GridView,
                            desc = "Switch view",
                            onClick = { onToggleGridView(!isGridView) }
                        )
                        CircularHeaderIcon(Icons.Default.CloudSync, "Sync Cloud", onSyncCloud)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Side-by-side Primary Action Pills: Upload + New Folder
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onOpenUploadPicker,
                        shape = RoundedCornerShape(24.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary
                        ),
                        modifier = Modifier.weight(1f).height(48.dp).testTag("folders_upload_button")
                    ) {
                        Icon(Icons.Default.Cloud, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Upload", fontWeight = FontWeight.SemiBold)
                    }
                    OutlinedButton(
                        onClick = { showNewFolderDialog = true },
                        shape = RoundedCornerShape(24.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = MaterialTheme.colorScheme.surface,
                            contentColor = MaterialTheme.colorScheme.onSurface
                        ),
                        modifier = Modifier.weight(1f).height(48.dp).testTag("folders_new_folder_button")
                    ) {
                        Icon(Icons.Default.CreateNewFolder, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("New folder", fontWeight = FontWeight.SemiBold)
                    }
                }
            }

            // Clickable Breadcrumb Navigation Bar when inside nested sub-folders
            if (breadcrumbs.isNotEmpty()) {
                Spacer(modifier = Modifier.height(12.dp))
                LazyRow(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.testTag("folders_breadcrumb_bar")
                ) {
                    item(key = "root_crumb", contentType = "breadcrumb_root") {
                        Surface(
                            color = MaterialTheme.colorScheme.surface,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .clip(RoundedCornerShape(14.dp))
                                .clickable(onClick = onNavigateRoot)
                                .testTag("breadcrumb_root")
                        ) {
                            Text(
                                "Cloud",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                            )
                        }
                    }
                    items(breadcrumbs, key = { it.id }, contentType = { "breadcrumb_item" }) { crumb ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.ChevronRight,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(16.dp)
                            )
                            val isCurrent = crumb.id == breadcrumbs.lastOrNull()?.id
                            Surface(
                                color = if (isCurrent) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                                else MaterialTheme.colorScheme.surface,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(14.dp))
                                    .clickable { onNavigateBreadcrumb(crumb.id) }
                                    .testTag("breadcrumb_folder_${crumb.id}")
                            ) {
                                Text(
                                    crumb.name,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (isCurrent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
        }

        val showCategoriesCard = activeCategory == null && breadcrumbs.isEmpty() && !isSelectionMode

        // Main Directory / Category Content
        if (isGridView) {
            LazyVerticalGrid(
                state = gridState,
                columns = GridCells.Fixed(3),
                contentPadding = PaddingValues(bottom = 115.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                if (showCategoriesCard) {
                    item(span = { GridItemSpan(maxLineSpan) }, key = "category_cards_section", contentType = "categories") {
                        SevenCategoryCardsContainer(
                            categoryCounts = categoryCounts,
                            onSelectCategory = { activeCategory = it }
                        )
                    }
                }

                if (displayedFolderUiItems.isEmpty() && displayedFileUiItems.isEmpty()) {
                    item(span = { GridItemSpan(maxLineSpan) }, key = "empty_dir_grid", contentType = "empty") {
                        ClodyEmptyStateCard(
                            title = when {
                                activeCategory != null -> "No ${activeCategory?.label?.lowercase()} found"
                                breadcrumbs.isEmpty() -> "No folders yet"
                                else -> "This folder is empty"
                            },
                            subtitle = when {
                                activeCategory != null -> "Upload matching files from Gallery or File Manager"
                                breadcrumbs.isEmpty() -> "Tap New folder to organize files, or tap Upload to save directly to Categories"
                                else -> "Tap Upload to add files or New folder to organize your tree"
                            },
                            ctaLabel = "Upload",
                            onCtaClick = onOpenUploadPicker
                        )
                    }
                } else {
                    items(displayedFolderUiItems, key = { "folder_${it.folder.id}" }, contentType = { "folder_grid" }) { folderItem ->
                        val folder = folderItem.folder
                        val isSelected = folder.id in selectedFolderIds
                        FolderGridCell(
                            folder = folder,
                            itemCountLabel = folderItem.itemCountLabel,
                            isSelectionMode = isSelectionMode,
                            isSelected = isSelected,
                            onClick = {
                                if (isSelectionMode) {
                                    selectedFolderIds = if (isSelected) selectedFolderIds - folder.id else selectedFolderIds + folder.id
                                } else {
                                    onOpenFolder(folder)
                                }
                            },
                            onLongClick = { selectedFolderIds = selectedFolderIds + folder.id },
                            onRename = { renameFolderTarget = folder },
                            onMove = { onMoveFolder(folder) },
                            onDownload = { onDownloadFolder(folder) },
                            onShare = { onShareFolder(folder) },
                            onDelete = { onDeleteFolder(folder) }
                        )
                    }

                    items(displayedFileUiItems, key = { "file_${it.file.id}" }, contentType = { "file_grid" }) { fileItem ->
                        val file = fileItem.file
                        val isSelected = file.id in selectedFileIds
                        val isInViewportWindow = file.id in activeViewportFileIds
                        FileGridCell(
                            file = file,
                            displayName = fileItem.displayName,
                            formattedSize = fileItem.formattedSize,
                            isInViewportWindow = isInViewportWindow,
                            telegramClient = telegramClient,
                            isSelectionMode = isSelectionMode,
                            isSelected = isSelected,
                            onClick = {
                                if (isSelectionMode) {
                                    selectedFileIds = if (isSelected) selectedFileIds - file.id else selectedFileIds + file.id
                                } else {
                                    onOpenFile(file)
                                }
                            },
                            onLongClick = { selectedFileIds = selectedFileIds + file.id },
                            onToggleFavorite = { onToggleFavorite(file) },
                            onRename = { renameFileTarget = file },
                            onMove = { onMoveFile(file) },
                            onCopy = { onCopyFile(file) },
                            onDownload = { onDownloadFile(file) },
                            onShare = { onShareFileItem(file) },
                            onDelete = { onDeleteFileItem(file) }
                        )
                    }
                }
            }
        } else {
            LazyColumn(
                state = listState,
                contentPadding = PaddingValues(bottom = 115.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                if (showCategoriesCard) {
                    item(key = "category_cards_section_list", contentType = "categories") {
                        Column {
                            SevenCategoryCardsContainer(
                                categoryCounts = categoryCounts,
                                onSelectCategory = { activeCategory = it }
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                        }
                    }
                }

                if (displayedFolderUiItems.isEmpty() && displayedFileUiItems.isEmpty()) {
                    item(key = "empty_dir_list", contentType = "empty") {
                        ClodyEmptyStateCard(
                            title = when {
                                activeCategory != null -> "No ${activeCategory?.label?.lowercase()} found"
                                breadcrumbs.isEmpty() -> "No folders yet"
                                else -> "This folder is empty"
                            },
                            subtitle = when {
                                activeCategory != null -> "Upload matching files from Gallery or File Manager"
                                breadcrumbs.isEmpty() -> "Tap New folder to organize files, or tap Upload to save directly to Categories"
                                else -> "Tap Upload to add files or New folder to organize your tree"
                            },
                            ctaLabel = "Upload",
                            onCtaClick = onOpenUploadPicker
                        )
                    }
                } else {
                    items(displayedFolderUiItems, key = { "folder_l_${it.folder.id}" }, contentType = { "folder_list" }) { folderItem ->
                        val folder = folderItem.folder
                        val isSelected = folder.id in selectedFolderIds
                        FolderListRow(
                            folder = folder,
                            itemCountLabel = folderItem.itemCountLabel,
                            isSelectionMode = isSelectionMode,
                            isSelected = isSelected,
                            onClick = {
                                if (isSelectionMode) {
                                    selectedFolderIds = if (isSelected) selectedFolderIds - folder.id else selectedFolderIds + folder.id
                                } else {
                                    onOpenFolder(folder)
                                }
                            },
                            onLongClick = { selectedFolderIds = selectedFolderIds + folder.id },
                            onRename = { renameFolderTarget = folder },
                            onMove = { onMoveFolder(folder) },
                            onDownload = { onDownloadFolder(folder) },
                            onShare = { onShareFolder(folder) },
                            onDelete = { onDeleteFolder(folder) }
                        )
                    }

                    items(displayedFileUiItems, key = { "file_l_${it.file.id}" }, contentType = { "file_list" }) { fileItem ->
                        val file = fileItem.file
                        val isSelected = file.id in selectedFileIds
                        val isInViewportWindow = file.id in activeViewportFileIds
                        FileListRow(
                            file = file,
                            displayName = fileItem.displayName,
                            formattedSize = fileItem.formattedSize,
                            isInViewportWindow = isInViewportWindow,
                            telegramClient = telegramClient,
                            isSelectionMode = isSelectionMode,
                            isSelected = isSelected,
                            onClick = {
                                if (isSelectionMode) {
                                    selectedFileIds = if (isSelected) selectedFileIds - file.id else selectedFileIds + file.id
                                } else {
                                    onOpenFile(file)
                                }
                            },
                            onLongClick = { selectedFileIds = selectedFileIds + file.id },
                            onToggleFavorite = { onToggleFavorite(file) },
                            onRename = { renameFileTarget = file },
                            onMove = { onMoveFile(file) },
                            onCopy = { onCopyFile(file) },
                            onDownload = { onDownloadFile(file) },
                            onShare = { onShareFileItem(file) },
                            onDelete = { onDeleteFileItem(file) }
                        )
                    }
                }
            }
        }
    }

    if (showNewFolderDialog) {
        var folderName by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showNewFolderDialog = false },
            title = { Text("Create New Folder") },
            text = {
                OutlinedTextField(
                    value = folderName,
                    onValueChange = { folderName = it },
                    label = { Text("Folder name") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp)
                )
            },
            confirmButton = {
                TextButton(
                    enabled = folderName.isNotBlank(),
                    onClick = {
                        onCreateFolder(folderName)
                        showNewFolderDialog = false
                    }
                ) { Text("Create") }
            },
            dismissButton = {
                TextButton(onClick = { showNewFolderDialog = false }) { Text("Cancel") }
            }
        )
    }

    renameFolderTarget?.let { target ->
        var newName by remember(target.id) { mutableStateOf(target.name) }
        AlertDialog(
            onDismissRequest = { renameFolderTarget = null },
            title = { Text("Rename Folder") },
            text = {
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    label = { Text("Folder name") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp)
                )
            },
            confirmButton = {
                TextButton(
                    enabled = newName.isNotBlank(),
                    onClick = {
                        onRenameFolder(target, newName)
                        renameFolderTarget = null
                    }
                ) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { renameFolderTarget = null }) { Text("Cancel") }
            }
        )
    }

    renameFileTarget?.let { target ->
        var newName by remember(target.id) { mutableStateOf(target.name) }
        AlertDialog(
            onDismissRequest = { renameFileTarget = null },
            title = { Text("Rename File") },
            text = {
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    label = { Text("File name") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp)
                )
            },
            confirmButton = {
                TextButton(
                    enabled = newName.isNotBlank(),
                    onClick = {
                        onRenameFileItem(target, newName)
                        renameFileTarget = null
                    }
                ) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { renameFileTarget = null }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun SevenCategoryCardsContainer(
    categoryCounts: Map<FileManagerCategory, Int>,
    onSelectCategory: (FileManagerCategory) -> Unit
) {
    val allCats = FileManagerCategory.entries
    val firstRow = allCats.take(4)
    val secondRow = allCats.drop(4)

    Surface(
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(22.dp),
        tonalElevation = 1.dp,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("file_manager_categories_card")
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                firstRow.forEach { cat ->
                    CategoryTile(
                        category = cat,
                        count = categoryCounts[cat] ?: 0,
                        onClick = { onSelectCategory(cat) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                secondRow.forEach { cat ->
                    CategoryTile(
                        category = cat,
                        count = categoryCounts[cat] ?: 0,
                        onClick = { onSelectCategory(cat) },
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(modifier = Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun CategoryTile(
    category: FileManagerCategory,
    count: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val tint = if (category == FileManagerCategory.AUDIO) {
        MaterialTheme.colorScheme.primary
    } else {
        category.accentColor
    }
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .bounceClick(onClick = onClick)
            .padding(vertical = 6.dp, horizontal = 4.dp)
            .testTag("category_tile_${category.name.lowercase()}"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(tint.copy(alpha = 0.14f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = category.icon,
                contentDescription = category.label,
                tint = tint,
                modifier = Modifier.size(22.dp)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = category.label,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )
        Text(
            text = count.toString(),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1
        )
    }
}

@Composable
private fun FolderGridCell(
    folder: FolderEntity,
    itemCountLabel: String,
    isSelectionMode: Boolean,
    isSelected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onRename: () -> Unit,
    onMove: () -> Unit,
    onDownload: () -> Unit,
    onShare: () -> Unit,
    onDelete: () -> Unit
) {
    var menuExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .bounceClick(onLongClick = onLongClick, onClick = onClick)
            .testTag("folder_item_${folder.id}"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Surface(
            color = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.14f) else MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(18.dp),
            tonalElevation = 1.dp,
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .then(
                    if (isSelected) Modifier.border(2.5.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(18.dp))
                    else Modifier
                )
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                Icon(
                    Icons.Default.Folder,
                    contentDescription = folder.name,
                    tint = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.size(44.dp).align(Alignment.Center)
                )
                if (isSelectionMode) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = if (isSelected) "Selected" else "Not selected",
                        tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
                        modifier = Modifier.align(Alignment.TopStart).padding(6.dp).size(20.dp)
                    )
                } else {
                    Box(modifier = Modifier.align(Alignment.BottomEnd)) {
                        IconButton(
                            onClick = { menuExpanded = true },
                            modifier = Modifier.size(30.dp).testTag("folder_menu_btn_${folder.id}")
                        ) {
                            Icon(Icons.Default.MoreVert, contentDescription = "Folder actions", modifier = Modifier.size(16.dp))
                        }
                        FolderItemDropdownMenu(
                            expanded = menuExpanded,
                            onDismiss = { menuExpanded = false },
                            onRename = onRename,
                            onMove = onMove,
                            onDownload = onDownload,
                            onShare = onShare,
                            onDelete = onDelete
                        )
                    }
                }
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = folder.name,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = itemCountLabel,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun FolderListRow(
    folder: FolderEntity,
    itemCountLabel: String,
    isSelectionMode: Boolean,
    isSelected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onRename: () -> Unit,
    onMove: () -> Unit,
    onDownload: () -> Unit,
    onShare: () -> Unit,
    onDelete: () -> Unit
) {
    var menuExpanded by remember { mutableStateOf(false) }

    Surface(
        color = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier
            .fillMaxWidth()
            .then(
                if (isSelected) Modifier.border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(18.dp))
                else Modifier
            )
            .bounceClick(onLongClick = onLongClick, onClick = onClick)
            .testTag("folder_item_${folder.id}")
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Folder, contentDescription = null, modifier = Modifier.size(26.dp))
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    folder.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = itemCountLabel,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (isSelectionMode) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = if (isSelected) "Selected" else "Not selected",
                    tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.45f),
                    modifier = Modifier.padding(end = 6.dp).size(22.dp)
                )
            } else {
                Box {
                    IconButton(
                        onClick = { menuExpanded = true },
                        modifier = Modifier.testTag("folder_menu_btn_${folder.id}")
                    ) {
                        Icon(Icons.Default.MoreVert, contentDescription = "More actions for ${folder.name}")
                    }
                    FolderItemDropdownMenu(
                        expanded = menuExpanded,
                        onDismiss = { menuExpanded = false },
                        onRename = onRename,
                        onMove = onMove,
                        onDownload = onDownload,
                        onShare = onShare,
                        onDelete = onDelete
                    )
                }
            }
        }
    }
}

@Composable
private fun rememberFilePreviewBitmap(
    file: FileEntity,
    isInViewportWindow: Boolean,
    telegramClient: TelegramClientManager?
): ImageBitmap? {
    val context = LocalContext.current
    val supportsVisualPreview = file.isImage || file.isVideo || file.isAudio
    val initialCachedBitmap = remember(file.id, file.activeThumbnailPath) {
        if (!supportsVisualPreview) return@remember null
        val active = file.activeThumbnailPath
        val persistent = ThumbnailGenerator.getPersistentThumbnailFile(context, file).absolutePath
        (active?.let { ThumbnailGenerator.getFromMemoryCache(it) })
            ?: ThumbnailGenerator.getFromMemoryCache(persistent)
            ?: ThumbnailGenerator.getFromMemoryCache("audio_cover_${file.id}")
            ?: ThumbnailGenerator.getFromMemoryCache("mini_${file.telegramAccessHash}")
    }
    var fullBitmap by remember(file.id, file.activeThumbnailPath) {
        mutableStateOf(initialCachedBitmap)
    }
    var miniBitmap by remember(file.id) {
        mutableStateOf(
            if (supportsVisualPreview && file.telegramAccessHash != 0L) {
                ThumbnailGenerator.getFromMemoryCache("mini_${file.telegramAccessHash}")
            } else null
        )
    }

    LaunchedEffect(
        file.id,
        file.activeThumbnailPath,
        file.localSourceUri,
        file.localCachePath,
        file.pinnedOfflinePath
    ) {
        if (!supportsVisualPreview) return@LaunchedEffect
        if (fullBitmap == null) {
            val existingPath = ThumbnailGenerator.resolveExistingThumbnailPath(context, file)
            if (existingPath != null) {
                fullBitmap = ThumbnailGenerator.decodeBitmapAsync(existingPath)
            }
        }
        if (fullBitmap == null && file.isAudio) {
            val localPath = withContext(Dispatchers.IO) {
                file.pinnedOfflinePath?.takeIf { File(it).exists() }
                    ?: file.localCachePath?.takeIf { File(it).exists() }
            }
            val contentUri = file.localSourceUri?.takeIf { it.isNotBlank() }?.let {
                runCatching { Uri.parse(it) }.getOrNull()
            }
            val id3Art = ThumbnailGenerator.extractEmbeddedAudioCoverAsync(
                context = context,
                filePath = localPath,
                contentUri = contentUri,
                cacheKey = "audio_cover_${file.id}",
                maxSizePx = 320
            )
            if (id3Art != null) {
                fullBitmap = id3Art
            }
        }
        if (fullBitmap == null && miniBitmap == null && telegramClient != null && file.telegramAccessHash != 0L) {
            val miniBytes = telegramClient.getCachedOrFetchMinithumbnail(file)
            if (miniBytes != null && miniBytes.isNotEmpty()) {
                miniBitmap = ThumbnailGenerator.decodeBytesAsync("mini_${file.telegramAccessHash}", miniBytes)
            }
        }
    }

    LaunchedEffect(isInViewportWindow, file.id, file.telegramAccessHash) {
        if (supportsVisualPreview &&
            isInViewportWindow &&
            fullBitmap == null &&
            telegramClient != null &&
            file.telegramAccessHash != 0L
        ) {
            val targetFile = ThumbnailGenerator.getPersistentThumbnailFile(context, file)
            val downloaded = telegramClient.downloadThumbnailWithSemaphore(file, targetFile)
            if (downloaded != null) {
                fullBitmap = ThumbnailGenerator.decodeBitmapAsync(downloaded.absolutePath)
            }
        }
    }

    return fullBitmap ?: miniBitmap ?: initialCachedBitmap
}

@Composable
private fun FileGridCell(
    file: FileEntity,
    displayName: String,
    formattedSize: String,
    isInViewportWindow: Boolean,
    telegramClient: TelegramClientManager?,
    isSelectionMode: Boolean,
    isSelected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    onRename: () -> Unit,
    onMove: () -> Unit,
    onCopy: () -> Unit,
    onDownload: () -> Unit,
    onShare: () -> Unit,
    onDelete: () -> Unit
) {
    var menuExpanded by remember { mutableStateOf(false) }
    val previewBitmap = rememberFilePreviewBitmap(
        file = file,
        isInViewportWindow = isInViewportWindow,
        telegramClient = telegramClient
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .bounceClick(onLongClick = onLongClick, onClick = onClick)
            .testTag("file_grid_item_${file.id}")
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .clip(RoundedCornerShape(16.dp))
                .background(if (file.isVideo) VideoTintSurface else MaterialTheme.colorScheme.surface)
                .then(
                    if (isSelected) Modifier.border(2.5.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(16.dp))
                    else Modifier
                )
        ) {
            if (previewBitmap != null) {
                Image(
                    bitmap = previewBitmap,
                    contentDescription = file.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Icon(
                    imageVector = fileCategoryIcon(file),
                    contentDescription = file.name,
                    tint = if (file.isVideo) VideoIconIndigo else MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.size(34.dp).align(Alignment.Center)
                )
            }

            if (isSelectionMode) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = if (isSelected) "Selected" else "Unselected",
                    tint = if (isSelected) MaterialTheme.colorScheme.primary else Color.White.copy(alpha = 0.7f),
                    modifier = Modifier.align(Alignment.TopStart).padding(6.dp).size(20.dp)
                )
            } else {
                IconButton(
                    onClick = onToggleFavorite,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(4.dp)
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.45f))
                ) {
                    Icon(
                        imageVector = if (file.isFavorite) Icons.Filled.Star else Icons.Outlined.StarBorder,
                        contentDescription = "Favorite",
                        tint = if (file.isFavorite) FavoriteGold else Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }

                Box(modifier = Modifier.align(Alignment.BottomEnd).padding(4.dp)) {
                    IconButton(
                        onClick = { menuExpanded = true },
                        modifier = Modifier
                            .size(26.dp)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.45f))
                            .testTag("file_menu_btn_${file.id}")
                    ) {
                        Icon(
                            Icons.Default.MoreVert,
                            contentDescription = "More actions",
                            tint = Color.White,
                            modifier = Modifier.size(15.dp)
                        )
                    }
                    FileItemDropdownMenu(
                        expanded = menuExpanded,
                        onDismiss = { menuExpanded = false },
                        onRename = onRename,
                        onMove = onMove,
                        onCopy = onCopy,
                        onDownload = onDownload,
                        onShare = onShare,
                        onDelete = onDelete
                    )
                }
            }

            if (file.isVideo) {
                Surface(
                    color = Color.Black.copy(alpha = 0.68f),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(6.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.PlayArrow,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(11.dp)
                        )
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(
                            text = if (file.durationMs > 0L) formatDuration(file.durationMs) else "Video",
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = displayName,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = formattedSize,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun FileListRow(
    file: FileEntity,
    displayName: String,
    formattedSize: String,
    isInViewportWindow: Boolean,
    telegramClient: TelegramClientManager?,
    isSelectionMode: Boolean,
    isSelected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    onRename: () -> Unit,
    onMove: () -> Unit,
    onCopy: () -> Unit,
    onDownload: () -> Unit,
    onShare: () -> Unit,
    onDelete: () -> Unit
) {
    var menuExpanded by remember { mutableStateOf(false) }
    val previewBitmap = rememberFilePreviewBitmap(
        file = file,
        isInViewportWindow = isInViewportWindow,
        telegramClient = telegramClient
    )

    Surface(
        color = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier
            .fillMaxWidth()
            .then(
                if (isSelected) Modifier.border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(18.dp))
                else Modifier
            )
            .bounceClick(onLongClick = onLongClick, onClick = onClick)
            .testTag("file_list_item_${file.id}")
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (file.isVideo) VideoTintSurface else MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                if (previewBitmap != null) {
                    Image(
                        bitmap = previewBitmap,
                        contentDescription = file.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(
                        fileCategoryIcon(file),
                        contentDescription = null,
                        tint = if (file.isVideo) VideoIconIndigo else MaterialTheme.colorScheme.onSurface
                    )
                }
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(displayName, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                val metaText = if (file.isVideo && file.durationMs > 0L) {
                    "$formattedSize • ${formatDuration(file.durationMs)}"
                } else {
                    formattedSize
                }
                Text(metaText, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (isSelectionMode) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = if (isSelected) "Selected" else "Unselected",
                    tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.45f),
                    modifier = Modifier.padding(end = 6.dp).size(22.dp)
                )
            } else {
                IconButton(onClick = onToggleFavorite) {
                    Icon(
                        if (file.isFavorite) Icons.Filled.Star else Icons.Outlined.StarBorder,
                        contentDescription = "Favorite",
                        tint = if (file.isFavorite) FavoriteGold else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Box {
                    IconButton(
                        onClick = { menuExpanded = true },
                        modifier = Modifier.testTag("file_menu_btn_${file.id}")
                    ) {
                        Icon(Icons.Default.MoreVert, contentDescription = "More actions")
                    }
                    FileItemDropdownMenu(
                        expanded = menuExpanded,
                        onDismiss = { menuExpanded = false },
                        onRename = onRename,
                        onMove = onMove,
                        onCopy = onCopy,
                        onDownload = onDownload,
                        onShare = onShare,
                        onDelete = onDelete
                    )
                }
            }
        }
    }
}

@Composable
private fun FolderItemDropdownMenu(
    expanded: Boolean,
    onDismiss: () -> Unit,
    onRename: () -> Unit,
    onMove: () -> Unit,
    onDownload: () -> Unit,
    onShare: () -> Unit,
    onDelete: () -> Unit
) {
    DropdownMenu(expanded = expanded, onDismissRequest = onDismiss) {
        DropdownMenuItem(
            text = { Text("Rename") },
            leadingIcon = { Icon(Icons.Default.DriveFileRenameOutline, contentDescription = null, modifier = Modifier.size(18.dp)) },
            onClick = { onDismiss(); onRename() }
        )
        DropdownMenuItem(
            text = { Text("Move to Folder") },
            leadingIcon = { Icon(Icons.AutoMirrored.Filled.DriveFileMove, contentDescription = null, modifier = Modifier.size(18.dp)) },
            onClick = { onDismiss(); onMove() }
        )
        DropdownMenuItem(
            text = { Text("Download") },
            leadingIcon = { Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp)) },
            onClick = { onDismiss(); onDownload() }
        )
        DropdownMenuItem(
            text = { Text("Share") },
            leadingIcon = { Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp)) },
            onClick = { onDismiss(); onShare() }
        )
        DropdownMenuItem(
            text = { Text("Delete", color = CrimsonAlert) },
            leadingIcon = { Icon(Icons.Default.DeleteOutline, contentDescription = null, tint = CrimsonAlert, modifier = Modifier.size(18.dp)) },
            onClick = { onDismiss(); onDelete() }
        )
    }
}

@Composable
private fun FileItemDropdownMenu(
    expanded: Boolean,
    onDismiss: () -> Unit,
    onRename: () -> Unit,
    onMove: () -> Unit,
    onCopy: () -> Unit,
    onDownload: () -> Unit,
    onShare: () -> Unit,
    onDelete: () -> Unit
) {
    DropdownMenu(expanded = expanded, onDismissRequest = onDismiss) {
        DropdownMenuItem(
            text = { Text("Rename") },
            leadingIcon = { Icon(Icons.Default.DriveFileRenameOutline, contentDescription = null, modifier = Modifier.size(18.dp)) },
            onClick = { onDismiss(); onRename() }
        )
        DropdownMenuItem(
            text = { Text("Move to Folder") },
            leadingIcon = { Icon(Icons.AutoMirrored.Filled.DriveFileMove, contentDescription = null, modifier = Modifier.size(18.dp)) },
            onClick = { onDismiss(); onMove() }
        )
        DropdownMenuItem(
            text = { Text("Copy") },
            leadingIcon = { Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(18.dp)) },
            onClick = { onDismiss(); onCopy() }
        )
        DropdownMenuItem(
            text = { Text("Download") },
            leadingIcon = { Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp)) },
            onClick = { onDismiss(); onDownload() }
        )
        DropdownMenuItem(
            text = { Text("Share") },
            leadingIcon = { Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp)) },
            onClick = { onDismiss(); onShare() }
        )
        DropdownMenuItem(
            text = { Text("Delete", color = CrimsonAlert) },
            leadingIcon = { Icon(Icons.Default.DeleteOutline, contentDescription = null, tint = CrimsonAlert, modifier = Modifier.size(18.dp)) },
            onClick = { onDismiss(); onDelete() }
        )
    }
}

@Composable
private fun SortDropdownMenu(
    expanded: Boolean,
    sortOption: SortOption,
    onChangeSort: (SortOption) -> Unit,
    onDismiss: () -> Unit
) {
    DropdownMenu(expanded = expanded, onDismissRequest = onDismiss) {
        DropdownMenuItem(
            text = { Text("Newest First${if (sortOption == SortOption.DATE_DESC) " ✓" else ""}") },
            onClick = { onChangeSort(SortOption.DATE_DESC); onDismiss() }
        )
        DropdownMenuItem(
            text = { Text("Name A–Z${if (sortOption == SortOption.NAME_ASC) " ✓" else ""}") },
            onClick = { onChangeSort(SortOption.NAME_ASC); onDismiss() }
        )
        DropdownMenuItem(
            text = { Text("Largest First${if (sortOption == SortOption.SIZE_DESC) " ✓" else ""}") },
            onClick = { onChangeSort(SortOption.SIZE_DESC); onDismiss() }
        )
    }
}

@Composable
private fun CircularHeaderIcon(
    icon: ImageVector,
    desc: String,
    onClick: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        shape = CircleShape,
        tonalElevation = 1.dp,
        modifier = Modifier.size(42.dp).clip(CircleShape).clickable(onClick = onClick)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = desc, modifier = Modifier.size(20.dp))
        }
    }
}

internal fun fileCategoryIcon(file: FileEntity): ImageVector {
    return when {
        file.isVideo -> Icons.Default.VideoFile
        file.isAudio -> Icons.Default.MusicNote
        file.isPdf -> Icons.Default.PictureAsPdf
        file.isSpreadsheet -> Icons.Default.TableChart
        file.isWordDoc || file.isTextOrCode -> Icons.Default.Description
        file.isArchive -> Icons.Default.FolderZip
        file.isApp -> Icons.Default.Apps
        else -> Icons.AutoMirrored.Filled.InsertDriveFile
    }
}
