package com.example.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.DriveFileMove
import androidx.compose.material.icons.automirrored.filled.InsertDriveFile
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CollectionsBookmark
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.data.local.FileEntity
import com.example.data.local.FolderEntity
import com.example.data.local.GalleryAlbumEntity
import com.example.service.TransferBatchSummary
import com.example.service.UploadCandidate
import com.example.telegram.TelegramAuthStep
import com.example.telegram.TelegramConnectionState
import com.example.ui.theme.AmberConnecting
import com.example.ui.theme.ClodyMotion
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.DeepCharcoal
import com.example.ui.theme.EmeraldConnected
import com.example.ui.theme.FavoriteGold
import com.example.ui.theme.LocalClodyMetrics
import com.example.ui.theme.SoftStoneGray
import com.example.ui.theme.VideoIconIndigo
import com.example.ui.theme.VideoTintSurface
import com.example.ui.theme.bounceClick
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import java.io.File

enum class ClodyTab(val label: String, val icon: ImageVector) {
    GALLERY("Gallery", Icons.Default.PhotoLibrary),
    FOLDERS("Folders", Icons.Default.Folder),
    TRANSFERS("Cloud", Icons.AutoMirrored.Filled.Send),
    SEARCH("Search", Icons.Default.Search),
    TOOLS("Tools", Icons.Default.GridView)
}

@Composable
fun TelegramConnectionStatusPill(
    state: TelegramConnectionState,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val (dotColor, label) = when (state) {
        is TelegramConnectionState.Connecting -> AmberConnecting to "Connecting to Telegram Server..."
        is TelegramConnectionState.Connected -> EmeraldConnected to (
            if (!state.userDisplayName.isNullOrBlank()) "Connected • ${state.userDisplayName}"
            else "Connected to Telegram Live Server"
        )
        is TelegramConnectionState.Disconnected -> CrimsonAlert to (
            if (state.reason.isNullOrBlank()) "Disconnected — Tap to Connect"
            else "Network Error: ${state.reason}"
        )
    }

    Surface(
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(20.dp),
        tonalElevation = 1.dp,
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .testTag("connection_status_pill")
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(dotColor)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun MorphingFloatingBottomBar(
    selectedTab: ClodyTab,
    connectionState: TelegramConnectionState,
    onSelectTab: (ClodyTab) -> Unit,
    modifier: Modifier = Modifier
) {
    val metrics = LocalClodyMetrics.current
    val statusDotColor = when (connectionState) {
        is TelegramConnectionState.Connected -> EmeraldConnected
        is TelegramConnectionState.Connecting -> AmberConnecting
        is TelegramConnectionState.Disconnected -> CrimsonAlert
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(bottom = 12.dp, top = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            color = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(34.dp),
            tonalElevation = 2.dp,
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .widthIn(max = 460.dp)
                .height(metrics.navBarHeight)
                .border(
                    width = 1.dp,
                    color = MaterialTheme.colorScheme.outline.copy(alpha = 0.28f),
                    shape = RoundedCornerShape(34.dp)
                )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                ClodyTab.entries.forEach { tab ->
                    val isSelected = tab == selectedTab
                    val containerColor by animateColorAsState(
                        targetValue = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
                        animationSpec = ClodyMotion.crispTween(200),
                        label = "nav_pill_bg"
                    )
                    val contentColor by animateColorAsState(
                        targetValue = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                        animationSpec = ClodyMotion.crispTween(200),
                        label = "nav_pill_fg"
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(28.dp))
                            .background(containerColor)
                            .bounceClick { onSelectTab(tab) }
                            .padding(horizontal = if (isSelected) 16.dp else 13.dp)
                            .testTag("nav_tab_${tab.name.lowercase()}"),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Box {
                            Icon(
                                imageVector = tab.icon,
                                contentDescription = tab.label,
                                tint = contentColor,
                                modifier = Modifier.size(metrics.navIconSize)
                            )
                            if (tab == ClodyTab.TRANSFERS) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .align(Alignment.TopEnd)
                                        .clip(CircleShape)
                                        .background(statusDotColor)
                                )
                            }
                        }
                        AnimatedVisibility(visible = isSelected) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Spacer(modifier = Modifier.width(7.dp))
                                Text(
                                    text = tab.label,
                                    color = contentColor,
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Render-isolated circular live transfer progress ring next to the Gallery Search bar.
 * Collects [batchSummaryFlow] internally so rapid upload/download progress ticks NEVER
 * trigger recomposition of the surrounding Gallery grid or viewers.
 */
@Composable
fun LiveTransferRingButton(
    batchSummaryFlow: StateFlow<TransferBatchSummary>,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val summary by batchSummaryFlow.collectAsStateWithLifecycle()
    val animatedFraction by animateFloatAsState(
        targetValue = if (summary.isActive) summary.overallFraction else 0f,
        animationSpec = ClodyMotion.crispTween(160),
        label = "ring_fraction"
    )
    val trackColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.28f)
    val activeColor = if (summary.overallPercent >= 99) EmeraldConnected else MaterialTheme.colorScheme.primary

    Box(
        modifier = modifier
            .size(50.dp)
            .testTag("live_transfer_ring_button"),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            color = MaterialTheme.colorScheme.surface,
            shape = CircleShape,
            tonalElevation = 2.dp,
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .bounceClick(onClick = onClick)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Canvas(modifier = Modifier.size(42.dp)) {
                    val strokeWidth = 3.dp.toPx()
                    drawArc(
                        color = trackColor,
                        startAngle = -90f,
                        sweepAngle = 360f,
                        useCenter = false,
                        style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                    )
                    if (summary.isActive && animatedFraction > 0f) {
                        drawArc(
                            color = activeColor,
                            startAngle = -90f,
                            sweepAngle = 360f * animatedFraction.coerceIn(0.03f, 1f),
                            useCenter = false,
                            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                        )
                    }
                }
                if (summary.isActive) {
                    Text(
                        text = "${summary.overallPercent}%",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.SwapVert,
                        contentDescription = "Transfers queue",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        if (summary.activeCount > 0) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .offset(x = 2.dp, y = (-1).dp)
                    .size(19.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary)
                    .border(1.5.dp, MaterialTheme.colorScheme.background, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = summary.activeCount.coerceAtMost(99).toString(),
                    color = MaterialTheme.colorScheme.onPrimary,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConnectClodyBottomSheet(
    connectionState: TelegramConnectionState,
    authStep: TelegramAuthStep,
    initialApiId: String,
    initialApiHash: String,
    initialPhone: String,
    isBusy: Boolean,
    busyLabel: String?,
    errorMessage: String?,
    onVerifyApi: (apiId: String, apiHash: String) -> Unit,
    onEditApi: () -> Unit,
    onSendCode: (phone: String) -> Unit,
    onVerifyCode: (String) -> Unit,
    onResendCode: () -> Unit,
    onVerifyPassword: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var apiId by remember(initialApiId) { mutableStateOf(initialApiId) }
    var apiHash by remember(initialApiHash) { mutableStateOf(initialApiHash) }
    var phone by remember(initialPhone) { mutableStateOf(initialPhone) }
    var otpCode by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var showGuide by remember { mutableStateOf(false) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 22.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Connect Clody Cloud", style = MaterialTheme.typography.headlineMedium)
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close")
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            TelegramConnectionStatusPill(state = connectionState, onClick = {})
            Spacer(modifier = Modifier.height(14.dp))

            if (!errorMessage.isNullOrBlank()) {
                Surface(
                    color = CrimsonAlert.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().testTag("auth_error_pill")
                ) {
                    Text(
                        text = errorMessage,
                        color = CrimsonAlert,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(12.dp)
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            AnimatedContent(targetState = authStep, label = "auth_step_anim") { step ->
                when (step) {
                    is TelegramAuthStep.VerifyApiCredentials -> {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "Step 1 of 3 • API Credentials",
                                    style = MaterialTheme.typography.titleMedium
                                )
                                OutlinedButton(
                                    onClick = {
                                        runCatching {
                                            context.startActivity(
                                                Intent(Intent.ACTION_VIEW, Uri.parse("https://my.telegram.org"))
                                            )
                                        }
                                    },
                                    shape = RoundedCornerShape(18.dp)
                                ) {
                                    Icon(Icons.Default.Key, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Get Free API Key", fontSize = 12.sp)
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant)
                                    .clickable { showGuide = !showGuide }
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "How to get api_id & api_hash in 60s",
                                    style = MaterialTheme.typography.labelMedium
                                )
                                Icon(
                                    if (showGuide) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            AnimatedVisibility(visible = showGuide) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = 8.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                                        .padding(12.dp)
                                ) {
                                    Text("1. Sign in at my.telegram.org with your phone.", style = MaterialTheme.typography.bodyMedium)
                                    Text("2. Open 'API development tools' and create an app.", style = MaterialTheme.typography.bodyMedium)
                                    Text("3. Copy App api_id and App api_hash below.", style = MaterialTheme.typography.bodyMedium)
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))
                            OutlinedTextField(
                                value = apiId,
                                onValueChange = { apiId = it.filter(Char::isDigit) },
                                label = { Text("API ID (numeric)") },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier.fillMaxWidth().testTag("auth_api_id_input")
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            OutlinedTextField(
                                value = apiHash,
                                onValueChange = { apiHash = it },
                                label = { Text("API Hash (32-char string)") },
                                singleLine = true,
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier.fillMaxWidth().testTag("auth_api_hash_input")
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = { onVerifyApi(apiId, apiHash) },
                                enabled = !isBusy,
                                shape = RoundedCornerShape(24.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.primary,
                                    contentColor = MaterialTheme.colorScheme.onPrimary
                                ),
                                modifier = Modifier.fillMaxWidth().height(50.dp).testTag("auth_verify_api_button")
                            ) {
                                if (isBusy) {
                                    CircularProgressIndicator(
                                        color = MaterialTheme.colorScheme.onPrimary,
                                        strokeWidth = 2.dp,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(
                                        text = busyLabel ?: "Connecting to Telegram...",
                                        fontWeight = FontWeight.SemiBold
                                    )
                                } else {
                                    Text("Verify API", fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }

                    is TelegramAuthStep.EnterPhoneNumber -> {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Surface(
                                color = EmeraldConnected.copy(alpha = 0.12f),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth().testTag("auth_api_verified_badge")
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 14.dp, vertical = 10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            Icons.Default.CheckCircle,
                                            contentDescription = "API Verified",
                                            tint = EmeraldConnected,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "✓ API Verified",
                                            color = EmeraldConnected,
                                            fontWeight = FontWeight.SemiBold,
                                            style = MaterialTheme.typography.labelLarge
                                        )
                                    }
                                    Text(
                                        text = "Edit",
                                        color = MaterialTheme.colorScheme.onSurface,
                                        fontWeight = FontWeight.SemiBold,
                                        style = MaterialTheme.typography.labelLarge,
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .clickable(enabled = !isBusy, onClick = onEditApi)
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                            .testTag("auth_edit_api_link")
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))
                            Text(
                                "Step 2 of 3 • Phone Number",
                                style = MaterialTheme.typography.titleMedium
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            OutlinedTextField(
                                value = phone,
                                onValueChange = { phone = it },
                                label = { Text("Phone Number (with country code, e.g. +880...)") },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier.fillMaxWidth().testTag("auth_phone_input")
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = { onSendCode(phone) },
                                enabled = !isBusy,
                                shape = RoundedCornerShape(24.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.primary,
                                    contentColor = MaterialTheme.colorScheme.onPrimary
                                ),
                                modifier = Modifier.fillMaxWidth().height(50.dp).testTag("auth_send_code_button")
                            ) {
                                if (isBusy) {
                                    CircularProgressIndicator(
                                        color = MaterialTheme.colorScheme.onPrimary,
                                        strokeWidth = 2.dp,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(
                                        text = busyLabel ?: "Sending Code...",
                                        fontWeight = FontWeight.SemiBold
                                    )
                                } else {
                                    Text("Send Code", fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }

                    is TelegramAuthStep.AwaitingOtp -> {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Text(
                                "Step 3 of 3 • Verification Code",
                                style = MaterialTheme.typography.titleMedium
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                "Telegram sent a 5-digit code to ${step.phoneNumber}.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            OutlinedTextField(
                                value = otpCode,
                                onValueChange = { otpCode = it.filter(Char::isDigit).take(6) },
                                label = { Text("Verification Code") },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier.fillMaxWidth().testTag("auth_otp_input")
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                TextButton(
                                    onClick = onResendCode,
                                    enabled = !isBusy,
                                    modifier = Modifier.testTag("auth_resend_code_button")
                                ) {
                                    Text("Resend Code", fontWeight = FontWeight.SemiBold)
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = { onVerifyCode(otpCode) },
                                enabled = !isBusy && otpCode.isNotBlank(),
                                shape = RoundedCornerShape(24.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.primary,
                                    contentColor = MaterialTheme.colorScheme.onPrimary
                                ),
                                modifier = Modifier.fillMaxWidth().height(50.dp).testTag("auth_verify_otp_button")
                            ) {
                                if (isBusy) {
                                    CircularProgressIndicator(
                                        color = MaterialTheme.colorScheme.onPrimary,
                                        strokeWidth = 2.dp,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(
                                        text = busyLabel ?: "Verifying...",
                                        fontWeight = FontWeight.SemiBold
                                    )
                                } else {
                                    Text("Verify & Connect", fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }

                    is TelegramAuthStep.AwaitingPassword -> {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Text(
                                "Step 3 of 3 • 2FA Cloud Password",
                                style = MaterialTheme.typography.titleMedium
                            )
                            if (step.hint.isNotBlank()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    "Hint: ${step.hint}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            OutlinedTextField(
                                value = password,
                                onValueChange = { password = it },
                                label = { Text("2FA Cloud Password") },
                                singleLine = true,
                                visualTransformation = PasswordVisualTransformation(),
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier.fillMaxWidth().testTag("auth_2fa_input")
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = { onVerifyPassword(password) },
                                enabled = !isBusy && password.isNotEmpty(),
                                shape = RoundedCornerShape(24.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.primary,
                                    contentColor = MaterialTheme.colorScheme.onPrimary
                                ),
                                modifier = Modifier.fillMaxWidth().height(50.dp).testTag("auth_verify_2fa_button")
                            ) {
                                if (isBusy) {
                                    CircularProgressIndicator(
                                        color = MaterialTheme.colorScheme.onPrimary,
                                        strokeWidth = 2.dp,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(
                                        text = busyLabel ?: "Verifying...",
                                        fontWeight = FontWeight.SemiBold
                                    )
                                } else {
                                    Text("Verify & Connect", fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }

                    is TelegramAuthStep.Authorized -> {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Text(
                                "Signed in as ${step.displayName}",
                                style = MaterialTheme.typography.titleMedium
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                "Your private \"Clody Cloud Storage\" channel is active.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(14.dp))
                            Button(
                                onClick = onDismiss,
                                shape = RoundedCornerShape(24.dp),
                                modifier = Modifier.fillMaxWidth().height(48.dp)
                            ) {
                                Text("Done")
                            }
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UploadPreviewModalSheet(
    candidates: List<UploadCandidate>,
    onPickCustomThumbnail: (UploadCandidate) -> Unit,
    onConfirmUpload: () -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp)
        ) {
            Text("Upload Preview (${candidates.size})", style = MaterialTheme.typography.headlineMedium)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                "Lightweight preview thumbnails generated. You can set a custom cover thumbnail for any video.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(12.dp))

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth().height(280.dp)
            ) {
                items(candidates, key = { it.uri.toString() }, contentType = { "upload_candidate" }) { candidate ->
                    val thumb = candidate.customThumbnailPath ?: candidate.extractedThumbnailPath
                    val thumbFile by produceState<File?>(initialValue = null, thumb) {
                        value = if (thumb.isNullOrBlank()) null else {
                            withContext(Dispatchers.IO) { File(thumb).takeIf(File::exists) }
                        }
                    }
                    val formattedSize = remember(candidate.sizeBytes) { formatFileSize(candidate.sizeBytes) }
                    val isVideo = candidate.mimeType.startsWith("video/")
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(64.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (isVideo) VideoTintSurface else SoftStoneGray),
                                contentAlignment = Alignment.Center
                            ) {
                                if (thumbFile != null) {
                                    AsyncImage(
                                        model = thumbFile,
                                        contentDescription = candidate.fileName,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.matchParentSize()
                                    )
                                } else {
                                    Icon(
                                        imageVector = if (isVideo) Icons.Default.VideoFile else Icons.AutoMirrored.Filled.InsertDriveFile,
                                        contentDescription = null,
                                        tint = if (isVideo) VideoIconIndigo else DeepCharcoal
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = candidate.fileName,
                                    style = MaterialTheme.typography.titleMedium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = formattedSize,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (isVideo) {
                                    Spacer(modifier = Modifier.height(6.dp))
                                    OutlinedButton(
                                        onClick = { onPickCustomThumbnail(candidate) },
                                        shape = RoundedCornerShape(14.dp),
                                        modifier = Modifier.height(32.dp).testTag("set_custom_thumb_button")
                                    ) {
                                        Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            if (candidate.customThumbnailPath != null) "Custom Thumbnail Set" else "Set Custom Thumbnail",
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = onDismiss,
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.weight(1f).height(50.dp)
                ) {
                    Text("Cancel")
                }
                Button(
                    onClick = onConfirmUpload,
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.weight(1f).height(50.dp).testTag("confirm_upload_button")
                ) {
                    Icon(Icons.Default.Cloud, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Upload Now", fontWeight = FontWeight.SemiBold)
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FileActionBottomSheet(
    file: FileEntity,
    confirmDelete: Boolean,
    onChangeThumbnail: (FileEntity) -> Unit,
    onAddToAlbum: ((FileEntity) -> Unit)? = null,
    onMoveToFolder: ((FileEntity) -> Unit)? = null,
    onCopyFile: ((FileEntity) -> Unit)? = null,
    onShare: ((FileEntity) -> Unit)? = null,
    onDownload: (FileEntity) -> Unit,
    onToggleFavorite: (FileEntity) -> Unit,
    onRename: (FileEntity, String) -> Unit,
    onDelete: (FileEntity) -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var showRenameDialog by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp)
        ) {
            val fileSubtitle = remember(file.sizeBytes, file.folderPath) {
                "${formatFileSize(file.sizeBytes)} • ${file.folderPath}"
            }
            Text(file.name, style = MaterialTheme.typography.titleLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                fileSubtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(14.dp))

            if ((file.isImage || file.isVideo) && onAddToAlbum != null) {
                ActionMenuRow(
                    icon = Icons.Default.CollectionsBookmark,
                    label = "Add to Album",
                    onClick = {
                        onDismiss()
                        onAddToAlbum(file)
                    }
                )
            }
            if (onMoveToFolder != null) {
                ActionMenuRow(
                    icon = Icons.AutoMirrored.Filled.DriveFileMove,
                    label = "Move to Folder",
                    onClick = {
                        onDismiss()
                        onMoveToFolder(file)
                    }
                )
            }
            if (onCopyFile != null) {
                ActionMenuRow(
                    icon = Icons.Default.ContentCopy,
                    label = "Copy to Folder",
                    onClick = {
                        onDismiss()
                        onCopyFile(file)
                    }
                )
            }
            if (file.isVideo) {
                ActionMenuRow(
                    icon = Icons.Default.Image,
                    label = "Change Thumbnail",
                    onClick = {
                        onDismiss()
                        onChangeThumbnail(file)
                    }
                )
            }
            if (onShare != null) {
                ActionMenuRow(
                    icon = Icons.Default.Share,
                    label = "Share via Private Cache",
                    onClick = {
                        onDismiss()
                        onShare(file)
                    }
                )
            }
            ActionMenuRow(
                icon = Icons.Default.Download,
                label = "Download to Phone Storage",
                onClick = {
                    onDismiss()
                    onDownload(file)
                }
            )
            ActionMenuRow(
                icon = if (file.isFavorite) Icons.Filled.Star else Icons.Outlined.StarBorder,
                label = if (file.isFavorite) "Remove from Favorites" else "Add to Favorites",
                tint = if (file.isFavorite) FavoriteGold else MaterialTheme.colorScheme.onSurface,
                onClick = {
                    onToggleFavorite(file)
                    onDismiss()
                }
            )
            ActionMenuRow(
                icon = Icons.Default.DriveFileRenameOutline,
                label = "Rename",
                onClick = { showRenameDialog = true }
            )
            ActionMenuRow(
                icon = Icons.Default.DeleteOutline,
                label = "Delete",
                tint = CrimsonAlert,
                onClick = {
                    if (confirmDelete) {
                        showDeleteConfirm = true
                    } else {
                        onDelete(file)
                        onDismiss()
                    }
                }
            )
            Spacer(modifier = Modifier.height(22.dp))
        }
    }

    if (showRenameDialog) {
        var name by remember(file.id) { mutableStateOf(file.name) }
        AlertDialog(
            onDismissRequest = { showRenameDialog = false },
            title = { Text("Rename File") },
            text = {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp)
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    onRename(file, name)
                    showRenameDialog = false
                    onDismiss()
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { showRenameDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Delete ${file.name}?") },
            text = { Text("This file will be moved to the Recycle Bin if enabled.") },
            confirmButton = {
                TextButton(onClick = {
                    onDelete(file)
                    showDeleteConfirm = false
                    onDismiss()
                }) { Text("Delete", color = CrimsonAlert) }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun ActionMenuRow(
    icon: ImageVector,
    label: String,
    tint: Color = MaterialTheme.colorScheme.onSurface,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(22.dp))
        Spacer(modifier = Modifier.width(14.dp))
        Text(label, style = MaterialTheme.typography.bodyLarge, color = tint, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun ClodyEmptyStateCard(
    title: String,
    subtitle: String,
    ctaLabel: String,
    onCtaClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(22.dp),
        tonalElevation = 1.dp,
        modifier = modifier.fillMaxWidth().testTag("clean_empty_state_card")
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(58.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Cloud,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.size(28.dp)
                )
            }
            Spacer(modifier = Modifier.height(14.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(18.dp))
            Button(
                onClick = onCtaClick,
                shape = RoundedCornerShape(24.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ),
                modifier = Modifier.height(48.dp)
            ) {
                Text(ctaLabel, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FolderUploadChooserSheet(
    onPickGallery: () -> Unit,
    onPickFileManager: () -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 10.dp)
        ) {
            Text("Upload to Folder", style = MaterialTheme.typography.headlineMedium)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                "Choose photos & videos from Gallery or any file type via File Manager.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(16.dp))

            // Option 1: Gallery (Photos & Videos)
            Surface(
                color = MaterialTheme.colorScheme.primary,
                shape = RoundedCornerShape(22.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(22.dp))
                    .bounceClick {
                        onDismiss()
                        onPickGallery()
                    }
                    .testTag("chooser_gallery_option")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.14f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.PhotoLibrary,
                            contentDescription = "Gallery",
                            tint = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "Gallery",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Photos & videos from your device library",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Option 2: File Manager (All File Types)
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
                shape = RoundedCornerShape(22.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(22.dp))
                    .bounceClick {
                        onDismiss()
                        onPickFileManager()
                    }
                    .testTag("chooser_file_manager_option")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surface),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.FolderOpen,
                            contentDescription = "File Manager",
                            tint = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "File Manager",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Audio, PDF, Word, Excel, ZIP, APK & any document",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

sealed interface BinaryBannerState {
    val fileName: String

    data class Downloading(override val fileName: String) : BinaryBannerState
    data class Completed(override val fileName: String, val message: String) : BinaryBannerState
    data class Error(override val fileName: String, val message: String) : BinaryBannerState
}

@Composable
fun BinaryDownloadBanner(
    state: BinaryBannerState,
    onOpenDeviceFileManager: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = DeepCharcoal,
        shape = RoundedCornerShape(22.dp),
        tonalElevation = 2.dp,
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .testTag("binary_download_banner")
    ) {
        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = when (state) {
                        is BinaryBannerState.Downloading -> Icons.Default.Download
                        is BinaryBannerState.Completed -> Icons.Default.CheckCircle
                        is BinaryBannerState.Error -> Icons.Default.Close
                    },
                    contentDescription = null,
                    tint = when (state) {
                        is BinaryBannerState.Downloading -> Color.White
                        is BinaryBannerState.Completed -> EmeraldConnected
                        is BinaryBannerState.Error -> CrimsonAlert
                    },
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = when (state) {
                            is BinaryBannerState.Downloading -> "Downloading ${state.fileName}..."
                            is BinaryBannerState.Completed -> state.message
                            is BinaryBannerState.Error -> "Download failed: ${state.fileName}"
                        },
                        color = Color.White,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (state is BinaryBannerState.Error) {
                        Text(
                            text = state.message,
                            color = Color.White.copy(alpha = 0.75f),
                            style = MaterialTheme.typography.labelSmall,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                if (state is BinaryBannerState.Completed) {
                    TextButton(onClick = onOpenDeviceFileManager) {
                        Icon(
                            Icons.Default.OpenInNew,
                            contentDescription = "Open File Manager",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Files", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
                IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                    Icon(
                        Icons.Default.Close,
                        contentDescription = "Dismiss",
                        tint = Color.White.copy(alpha = 0.7f),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
            if (state is BinaryBannerState.Downloading) {
                Spacer(modifier = Modifier.height(8.dp))
                LinearProgressIndicator(
                    color = Color.White,
                    trackColor = Color.White.copy(alpha = 0.22f),
                    modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp))
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddToAlbumBottomSheet(
    file: FileEntity,
    albums: List<GalleryAlbumEntity>,
    onSelectAlbum: (GalleryAlbumEntity) -> Unit,
    onCreateAlbumAndAssign: (String) -> Unit,
    onRemoveFromAlbum: (() -> Unit)? = null,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var showCreateDialog by remember { mutableStateOf(false) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Add to Album", style = MaterialTheme.typography.headlineMedium)
                    Text(
                        file.name,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Button(
                    onClick = { showCreateDialog = true },
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.heightIn(min = 44.dp).testTag("create_album_from_sheet_btn")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("New Album")
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (file.albumId != null && onRemoveFromAlbum != null) {
                OutlinedButton(
                    onClick = {
                        onRemoveFromAlbum()
                        onDismiss()
                    },
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                ) {
                    Text("Remove from Current Album")
                }
                Spacer(modifier = Modifier.height(10.dp))
            }

            if (albums.isEmpty()) {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            Icons.Default.CollectionsBookmark,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("No albums yet", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "Create a photo/video album to organize your Gallery.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth().heightIn(max = 300.dp)
                ) {
                    items(albums, key = { it.id }, contentType = { "album_item" }) { album ->
                        val isAssigned = file.albumId == album.id
                        val cover = album.coverThumbnailPath
                        val coverFile by produceState<File?>(initialValue = null, cover) {
                            value = if (cover.isNullOrBlank()) null else {
                                withContext(Dispatchers.IO) { File(cover).takeIf(File::exists) }
                            }
                        }
                        Surface(
                            color = if (isAssigned) {
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)
                            } else {
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                            },
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(18.dp))
                                .bounceClick {
                                    onSelectAlbum(album)
                                    onDismiss()
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(MaterialTheme.colorScheme.surfaceVariant),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (coverFile != null) {
                                        AsyncImage(
                                            model = coverFile,
                                            contentDescription = album.name,
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                    } else {
                                        Icon(
                                            Icons.Default.CollectionsBookmark,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = album.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.weight(1f),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (isAssigned) {
                                    Icon(
                                        Icons.Default.Check,
                                        contentDescription = "Selected",
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(18.dp))
        }
    }

    if (showCreateDialog) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text("New Album") },
            text = {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    placeholder = { Text("e.g. Trips, Portraits, Reels") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp)
                )
            },
            confirmButton = {
                TextButton(
                    enabled = name.isNotBlank(),
                    onClick = {
                        onCreateAlbumAndAssign(name)
                        showCreateDialog = false
                        onDismiss()
                    }
                ) { Text("Create & Add") }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
fun FolderPickerDialog(
    title: String,
    allFolders: List<FolderEntity>,
    excludedFolderIds: Set<Long> = emptySet(),
    onSelectDestination: (Long?) -> Unit,
    onDismiss: () -> Unit
) {
    val folderMap = remember(allFolders) { allFolders.associateBy { it.id } }
    fun pathLabel(folder: FolderEntity): String {
        val parts = mutableListOf<String>()
        var cursor: FolderEntity? = folder
        val seen = HashSet<Long>()
        while (cursor != null && seen.add(cursor.id)) {
            parts.add(cursor.name)
            cursor = cursor.parentId?.let { folderMap[it] }
        }
        return "Cloud / " + parts.reversed().joinToString(" / ")
    }

    val eligibleFolders = remember(allFolders, excludedFolderIds) {
        allFolders.filter { it.id !in excludedFolderIds }.sortedBy { pathLabel(it).lowercase() }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth().heightIn(max = 320.dp)
            ) {
                item(key = "dest_root") {
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .clickable {
                                onSelectDestination(null)
                                onDismiss()
                            }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Cloud, contentDescription = null, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Text("Cloud (Root Directory)", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
                items(eligibleFolders, key = { it.id }, contentType = { "folder_picker_row" }) { folder ->
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .clickable {
                                onSelectDestination(folder.id)
                                onDismiss()
                            }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Folder, contentDescription = null, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = pathLabel(folder),
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Medium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun ShareCacheProgressDialog(state: ShareCacheProgressState) {
    val fraction = if (state.totalCount > 0) {
        (state.completedCount.toFloat() / state.totalCount.toFloat()).coerceIn(0f, 1f)
    } else 0f

    AlertDialog(
        onDismissRequest = {},
        title = { Text("Preparing Share (${state.completedCount}/${state.totalCount})") },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Caching into private app share cache (zero phone gallery clutter)...",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = state.currentFileName,
                    style = MaterialTheme.typography.labelLarge,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(10.dp))
                LinearProgressIndicator(
                    progress = { fraction },
                    modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp))
                )
            }
        },
        confirmButton = {}
    )
}



