package com.example.ui.theme

import androidx.compose.animation.ContentTransform
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FiniteAnimationSpec
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer

object ClodyMotion {
    /** Crisp out-quartic curve equivalent to cubic-bezier(0.22, 1, 0.36, 1) */
    val CrispOutEasing = CubicBezierEasing(0.22f, 1f, 0.36f, 1f)

    fun <T> defaultSpring(@Suppress("UNUSED_PARAMETER") animationsEnabled: Boolean = true): FiniteAnimationSpec<T> {
        return spring(
            dampingRatio = Spring.DampingRatioNoBouncy,
            stiffness = Spring.StiffnessMediumLow
        )
    }

    fun <T> snappySpring(@Suppress("UNUSED_PARAMETER") animationsEnabled: Boolean = true): FiniteAnimationSpec<T> {
        return spring(
            dampingRatio = Spring.DampingRatioNoBouncy,
            stiffness = Spring.StiffnessMedium
        )
    }

    fun <T> crispTween(
        durationMs: Int = 220,
        @Suppress("UNUSED_PARAMETER") animationsEnabled: Boolean = true
    ): FiniteAnimationSpec<T> {
        return tween(durationMillis = durationMs.coerceAtLeast(100), easing = CrispOutEasing)
    }

    fun gpuScreenTransition(): ContentTransform {
        return (fadeIn(defaultSpring()) +
            scaleIn(
                initialScale = 0.985f,
                animationSpec = defaultSpring()
            )) togetherWith fadeOut(snappySpring())
    }

    fun gpuDialogEnter(): EnterTransition {
        return fadeIn(snappySpring()) + scaleIn(
            initialScale = 0.94f,
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioNoBouncy,
                stiffness = Spring.StiffnessMediumLow
            )
        )
    }

    fun gpuDialogExit(): ExitTransition {
        return fadeOut(snappySpring()) + scaleOut(
            targetScale = 0.96f,
            animationSpec = snappySpring()
        )
    }
}

/**
 * Pure GPU-composited tactile scale press feedback running on the GPU render thread
 * with zero layout invalidation during animation and crisp NoBouncy spring physics.
 */
@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
fun Modifier.bounceClick(
    enabled: Boolean = true,
    scaleDown: Float = 0.97f,
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit
): Modifier = composed {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed && enabled) scaleDown else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioNoBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "gpu_bounce_scale"
    )

    val clickModifier = if (onLongClick != null) {
        Modifier.combinedClickable(
            interactionSource = interactionSource,
            indication = null,
            enabled = enabled,
            onLongClick = onLongClick,
            onClick = onClick
        )
    } else {
        Modifier.clickable(
            interactionSource = interactionSource,
            indication = null,
            enabled = enabled,
            onClick = onClick
        )
    }

    this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .then(clickModifier)
}
