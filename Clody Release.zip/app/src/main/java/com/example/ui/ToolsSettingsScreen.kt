package com.example.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.DesktopWindows
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RestoreFromTrash
import androidx.compose.material.icons.filled.SdStorage
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Unarchive
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.AppSettings
import com.example.data.local.FileEntity
import com.example.data.local.ThemeMode
import com.example.files.DeviceStorageStats
import com.example.files.DuplicateGroup
import com.example.files.InstalledAppItem
import com.example.files.LocalFileItem
import com.example.telegram.TelegramAuthStep
import com.example.telegram.TelegramUserProfile
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.DeepCharcoal
import com.example.ui.theme.EmeraldConnected
import com.example.ui.theme.PureWhiteSurface
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.ButtonDefaults
import coil.compose.AsyncImage
import androidx.compose.ui.layout.ContentScale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private enum class ActiveToolModal {
    NONE,
    FILE_MANAGER,
    LARGE_FILES,
    DUPLICATES,
    RECYCLE_BIN,
    INSTALLED_APPS,
    STORAGE_BREAKDOWN
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ToolsSettingsScreen(
    settings: AppSettings,
    authStep: TelegramAuthStep,
    userProfile: TelegramUserProfile?,
    deviceStorage: DeviceStorageStats,
    totalCloudBytes: Long,
    streamCacheBytes: Long,
    hasAllFilesAccess: Boolean,
    hasNotificationPermission: Boolean,
    localDirectoryItems: List<LocalFileItem>,
    currentLocalDir: File,
    largeLocalFiles: List<LocalFileItem>,
    largeCloudFiles: List<FileEntity>,
    duplicateGroups: List<DuplicateGroup>,
    deletedFiles: List<FileEntity>,
    installedApps: List<InstalledAppItem>,
    onRequestNotificationPermission: () -> Unit,
    onRequestAllFilesAccess: () -> Unit,
    onClearStreamCache: () -> Unit,
    onSetZeroStorageMode: (Boolean) -> Unit,
    onSetAutoDeleteCacheOnExit: (Boolean) -> Unit,
    onSetThemeMode: (ThemeMode) -> Unit,
    onSetDynamicColors: (Boolean) -> Unit,
    onSetShowHidden: (Boolean) -> Unit,
    onSetShowExtensions: (Boolean) -> Unit,
    onSetUseRecycleBin: (Boolean) -> Unit,
    onSetConfirmDelete: (Boolean) -> Unit,
    onSetUploadWifiOnly: (Boolean) -> Unit,
    onLoadLocalDirectory: (File) -> Unit,
    onUploadLocalFile: (LocalFileItem) -> Unit,
    onScanLargeFiles: () -> Unit,
    onScanDuplicates: () -> Unit,
    onLoadInstalledApps: () -> Unit,
    onBackupApk: (InstalledAppItem) -> Unit,
    onRestoreDeleted: (FileEntity) -> Unit,
    onPermanentDelete: (FileEntity) -> Unit,
    onOpenCompressPicker: () -> Unit,
    onOpenExtractPicker: () -> Unit,
    onAssignFolderToSync: () -> Unit,
    onRemoveSyncedFolder: (String) -> Unit,
    onForceCloudIndexSync: () -> Unit,
    onRebuildIndex: () -> Unit,
    onOptimizeFts: () -> Unit,
    onOpenConnectSheet: () -> Unit,
    onLogout: () -> Unit
) {
    var activeModal by remember { mutableStateOf(ActiveToolModal.NONE) }
    var showPrivacyDialog by remember { mutableStateOf(false) }
    var showUploadNetworkDialog by remember { mutableStateOf(false) }

    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
    ) {
        item(key = "tools_title", contentType = "title") {
            Text("Tools & Settings", style = MaterialTheme.typography.displaySmall)
        }

        // 0. Dedicated Warm Monochrome Telegram Profile Card at top of Settings
        item(key = "profile_hero", contentType = "profile_hero") {
            TelegramProfileHeroCard(
                authStep = authStep,
                userProfile = userProfile,
                onLoginClick = onOpenConnectSheet
            )
        }

        // 2. Storage Analyzer Hero Card (#141414)
        item(key = "storage_hero", contentType = "storage_hero") {
            Surface(
                color = DeepCharcoal,
                shape = RoundedCornerShape(22.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { activeModal = ActiveToolModal.STORAGE_BREAKDOWN }
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Device Storage", color = PureWhiteSurface, style = MaterialTheme.typography.titleLarge)
                        Text(
                            "${deviceStorage.usedPercent}%",
                            color = PureWhiteSurface,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleLarge
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        "${formatFileSize(deviceStorage.usedBytes)} of ${formatFileSize(deviceStorage.totalBytes)} used",
                        color = PureWhiteSurface.copy(alpha = 0.8f),
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    LinearProgressIndicator(
                        progress = { deviceStorage.usedPercent / 100f },
                        color = PureWhiteSurface,
                        trackColor = PureWhiteSurface.copy(alpha = 0.2f),
                        modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp))
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        "Clody Cloud: ${formatFileSize(totalCloudBytes)} (Unlimited) • Stream Cache: ${formatStreamCacheSize(streamCacheBytes)}",
                        color = PureWhiteSurface.copy(alpha = 0.78f),
                        style = MaterialTheme.typography.labelMedium
                    )
                }
            }
        }

        // 3. Data & Storage (Cache Control & Upload Network)
        item(key = "section_cache", contentType = "section_card") {
            SectionCard("Data & Storage") {
                SettingActionRow(
                    icon = Icons.Default.CleaningServices,
                    title = "Clear Stream Cache",
                    subtitle = "${formatStreamCacheSize(streamCacheBytes)} in private cache (keeps you logged in)",
                    onClick = onClearStreamCache,
                    modifier = Modifier.testTag("setting_clear_stream_cache")
                )
                SettingToggleRow(
                    icon = Icons.Default.VisibilityOff,
                    title = "Zero-Storage Mode",
                    subtitle = "Auto-delete streamed files immediately on closing player/viewer",
                    checked = settings.zeroStorageMode,
                    onCheckedChange = onSetZeroStorageMode,
                    modifier = Modifier.testTag("toggle_zero_storage_mode")
                )
                SettingToggleRow(
                    icon = Icons.Default.DeleteSweep,
                    title = "Auto-Delete Cache on App Exit",
                    subtitle = if (settings.zeroStorageMode) {
                        "Clear stream & share cache automatically when leaving the app (handled by Zero-Storage Mode)"
                    } else {
                        "Clear stream & share cache automatically when leaving the app"
                    },
                    checked = settings.zeroStorageMode || settings.autoDeleteCacheOnExit,
                    enabled = !settings.zeroStorageMode,
                    onCheckedChange = onSetAutoDeleteCacheOnExit,
                    modifier = Modifier.testTag("toggle_auto_delete_cache_on_exit")
                )
                SettingActionRow(
                    icon = Icons.Default.Wifi,
                    title = "Upload Network",
                    subtitle = if (settings.uploadWifiOnly) "Only Wi-Fi" else "Wi-Fi + Mobile Data",
                    onClick = { showUploadNetworkDialog = true },
                    modifier = Modifier.testTag("setting_upload_network")
                )
            }
        }

        // 4. Clean Up Utilities
        item(key = "section_cleanup", contentType = "section_card") {
            SectionCard("Clean Up Utilities") {
                SettingActionRow(
                    icon = Icons.Default.SdStorage,
                    title = "Large files (> 50 MB)",
                    subtitle = "${largeCloudFiles.size} cloud items over 50 MB",
                    onClick = {
                        onScanLargeFiles()
                        activeModal = ActiveToolModal.LARGE_FILES
                    }
                )
                SettingActionRow(
                    icon = Icons.Default.ContentCopy,
                    title = "Duplicates",
                    subtitle = "Detect identical files by size + SHA-256 hash",
                    onClick = {
                        onScanDuplicates()
                        activeModal = ActiveToolModal.DUPLICATES
                    }
                )
                SettingActionRow(
                    icon = Icons.Default.RestoreFromTrash,
                    title = "Recycle bin",
                    subtitle = "${deletedFiles.size} soft-deleted item(s) • 30-day retention",
                    onClick = { activeModal = ActiveToolModal.RECYCLE_BIN }
                )
            }
        }

        // 5. Local File Tools
        item(key = "section_local_tools", contentType = "section_card") {
            SectionCard("Local File Tools") {
                SettingActionRow(
                    icon = Icons.Default.Folder,
                    title = "Device File Manager & Hidden Files",
                    subtitle = if (hasAllFilesAccess) "Full storage access granted" else "Tap to browse or grant All Files Access",
                    onClick = {
                        onLoadLocalDirectory(currentLocalDir)
                        activeModal = ActiveToolModal.FILE_MANAGER
                    }
                )
                SettingActionRow(
                    icon = Icons.Default.FolderZip,
                    title = "Compress to .zip",
                    subtitle = "Select files to pack into a .zip archive",
                    onClick = onOpenCompressPicker
                )
                SettingActionRow(
                    icon = Icons.Default.Unarchive,
                    title = "Extract archive (.zip / .tar / .7z)",
                    subtitle = "Unpack archives directly into local files",
                    onClick = onOpenExtractPicker
                )
                SettingActionRow(
                    icon = Icons.Default.Apps,
                    title = "Installed Apps & APK Backup",
                    subtitle = "Inspect user apps and upload .apk backups to Clody Cloud",
                    onClick = {
                        onLoadInstalledApps()
                        activeModal = ActiveToolModal.INSTALLED_APPS
                    }
                )
            }
        }

        // 6. Appearance
        item(key = "section_appearance", contentType = "section_card") {
            SectionCard("Appearance") {
                Text("Theme", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ThemeMode.entries.forEach { mode ->
                        FilterChip(
                            selected = settings.themeMode == mode,
                            onClick = { onSetThemeMode(mode) },
                            label = { Text(mode.name.lowercase().replaceFirstChar { it.uppercase() }) }
                        )
                    }
                }
                SettingToggleRow(
                    icon = Icons.Default.Info,
                    title = "Dynamic colours",
                    subtitle = "Android 12+ wallpaper-based Material You palette",
                    checked = settings.dynamicColors,
                    onCheckedChange = onSetDynamicColors
                )
            }
        }

        // 7. File Management & Transfers
        item(key = "section_file_mgmt", contentType = "section_card") {
            SectionCard("File Management & Transfers") {
                SettingToggleRow(
                    icon = Icons.Default.VisibilityOff,
                    title = "Show hidden files",
                    subtitle = "Display dot-files and hidden local folders",
                    checked = settings.showHiddenFiles,
                    onCheckedChange = onSetShowHidden
                )
                SettingToggleRow(
                    icon = Icons.Default.Folder,
                    title = "Show file extensions",
                    subtitle = "Display .mp4, .jpg, .pdf suffixes",
                    checked = settings.showFileExtensions,
                    onCheckedChange = onSetShowExtensions
                )
                SettingToggleRow(
                    icon = Icons.Default.RestoreFromTrash,
                    title = "Use recycle bin",
                    subtitle = "Keep deleted files for 30 days before purging",
                    checked = settings.useRecycleBin,
                    onCheckedChange = onSetUseRecycleBin
                )
                SettingToggleRow(
                    icon = Icons.Default.DeleteOutline,
                    title = "Confirm before deleting",
                    subtitle = "Show confirmation dialog before deleting",
                    checked = settings.confirmBeforeDeleting,
                    onCheckedChange = onSetConfirmDelete
                )
                if (!hasNotificationPermission) {
                    SettingActionRow(
                        icon = Icons.Default.Notifications,
                        title = "Enable Upload Notifications",
                        subtitle = "Required on Android 13+ to show live upload progress bar",
                        onClick = onRequestNotificationPermission
                    )
                }
            }
        }

        // 8. Synchronization & Folder Sync
        item(key = "section_sync", contentType = "section_card") {
            SectionCard("Synchronization") {
                SettingActionRow(
                    icon = Icons.Default.Sync,
                    title = "Assign a folder to sync",
                    subtitle = "${settings.syncedFolderUris.size} folder(s) linked via Storage Access Framework",
                    onClick = onAssignFolderToSync
                )
                settings.syncedFolderUris.forEach { uriStr ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            Uri.parse(uriStr).lastPathSegment ?: uriStr,
                            style = MaterialTheme.typography.bodyMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(onClick = { onRemoveSyncedFolder(uriStr) }) { Text("Remove", color = CrimsonAlert) }
                    }
                }
                SettingActionRow(
                    icon = Icons.Default.CloudSync,
                    title = "Force Cloud Index Sync",
                    subtitle = "Backup & restore clody_index.json with Telegram",
                    onClick = onForceCloudIndexSync
                )
            }
        }

        // 9. Advanced & Account + 2.0s Long-Click Logout
        item(key = "section_advanced", contentType = "section_card") {
            SectionCard("Advanced & Account") {
                SettingActionRow(
                    icon = Icons.Default.Refresh,
                    title = "Rebuild file index",
                    subtitle = "Rescan local media & refresh FTS4 search index",
                    onClick = onRebuildIndex
                )
                SettingActionRow(
                    icon = Icons.Default.Speed,
                    title = "Search optimization",
                    subtitle = "Compact and optimize local FTS4 database",
                    onClick = onOptimizeFts
                )
                SettingActionRow(
                    icon = Icons.Default.DesktopWindows,
                    title = "Desktop / Web Access",
                    subtitle = "Access all uploaded files anytime in Telegram Desktop under \"Clody Cloud Storage\"",
                    onClick = {}
                )
                SettingActionRow(
                    icon = Icons.Default.Info,
                    title = "Privacy policy & About Clody",
                    subtitle = "Version 1.0.0 • Zero external servers",
                    onClick = { showPrivacyDialog = true }
                )

                if (authStep is TelegramAuthStep.Authorized) {
                    Spacer(modifier = Modifier.height(6.dp))
                    LongClickLogoutCard(onLogout = onLogout)
                }
            }
        }

        // 10. Centered Developer Credit Footer
        item(key = "developer_credit_footer", contentType = "footer") {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 18.dp, bottom = 8.dp)
                    .testTag("developer_credit_footer"),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Developed By",
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                    fontSize = 12.sp,
                    letterSpacing = 0.8.sp,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "MushfiQ",
                    color = MaterialTheme.colorScheme.onSurface,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Center
                )
            }
        }
    }

    if (showUploadNetworkDialog) {
        AlertDialog(
            onDismissRequest = { showUploadNetworkDialog = false },
            title = { Text("Upload Network") },
            text = {
                Column {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable {
                                onSetUploadWifiOnly(true)
                                showUploadNetworkDialog = false
                            }
                            .padding(vertical = 10.dp, horizontal = 4.dp)
                            .testTag("upload_network_wifi_only"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = settings.uploadWifiOnly,
                            onClick = {
                                onSetUploadWifiOnly(true)
                                showUploadNetworkDialog = false
                            }
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Only Wi-Fi", style = MaterialTheme.typography.bodyLarge)
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable {
                                onSetUploadWifiOnly(false)
                                showUploadNetworkDialog = false
                            }
                            .padding(vertical = 10.dp, horizontal = 4.dp)
                            .testTag("upload_network_wifi_and_mobile"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = !settings.uploadWifiOnly,
                            onClick = {
                                onSetUploadWifiOnly(false)
                                showUploadNetworkDialog = false
                            }
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Wi-Fi + Mobile Data", style = MaterialTheme.typography.bodyLarge)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showUploadNetworkDialog = false }) { Text("Close") }
            }
        )
    }

    if (showPrivacyDialog) {
        AlertDialog(
            onDismissRequest = { showPrivacyDialog = false },
            title = { Text("Clody v1.0.0") },
            text = {
                Text(
                    "Clody connects directly from your Android device to Telegram's official MTProto servers with zero middleman servers. Your API credentials and auth keys are encrypted using Android Keystore AES-256-GCM."
                )
            },
            confirmButton = {
                TextButton(onClick = { showPrivacyDialog = false }) { Text("Close") }
            }
        )
    }

    // Tool Sub-Modals
    if (activeModal != ActiveToolModal.NONE) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(
            onDismissRequest = { activeModal = ActiveToolModal.NONE },
            sheetState = sheetState,
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp)) {
                when (activeModal) {
                    ActiveToolModal.STORAGE_BREAKDOWN -> {
                        Text("Storage Breakdown", style = MaterialTheme.typography.titleLarge)
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("Device Used: ${formatFileSize(deviceStorage.usedBytes)} / ${formatFileSize(deviceStorage.totalBytes)}")
                        Text("Clody Cloud Files: ${formatFileSize(totalCloudBytes)} (Stored on Telegram)")
                        Text("Private Stream Cache: ${formatFileSize(streamCacheBytes)}")
                        Spacer(modifier = Modifier.height(14.dp))
                        Button(onClick = { onClearStreamCache(); activeModal = ActiveToolModal.NONE }) {
                            Text("Clear Stream Cache")
                        }
                    }

                    ActiveToolModal.LARGE_FILES -> {
                        Text("Large Files (> 50 MB)", style = MaterialTheme.typography.titleLarge)
                        Spacer(modifier = Modifier.height(10.dp))
                        LazyColumn(modifier = Modifier.height(340.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(largeCloudFiles, key = { "lc_${it.id}" }, contentType = { "large_cloud_file" }) { f ->
                                val sizeLabel = remember(f.sizeBytes) { formatFileSize(f.sizeBytes) }
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                                    Text("Cloud • $sizeLabel", fontWeight = FontWeight.SemiBold)
                                }
                            }
                            items(largeLocalFiles, key = { "ll_${it.file.absolutePath}" }, contentType = { "large_local_file" }) { item ->
                                val sizeLabel = remember(item.sizeBytes) { formatFileSize(item.sizeBytes) }
                                Row(
                                    Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(Modifier.weight(1f)) {
                                        Text(item.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text("Local • $sizeLabel", style = MaterialTheme.typography.bodyMedium)
                                    }
                                    TextButton(onClick = { onUploadLocalFile(item) }) { Text("Upload") }
                                }
                            }
                        }
                    }

                    ActiveToolModal.DUPLICATES -> {
                        Text("Duplicate Cloud Files", style = MaterialTheme.typography.titleLarge)
                        Spacer(modifier = Modifier.height(10.dp))
                        if (duplicateGroups.isEmpty()) {
                            Text("No duplicate files detected across SHA-256 hashes.")
                        } else {
                            LazyColumn(modifier = Modifier.height(320.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                items(duplicateGroups, key = { it.hash }, contentType = { "dup_group" }) { grp ->
                                    val sizeLabel = remember(grp.sizeBytes) { formatFileSize(grp.sizeBytes) }
                                    Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(14.dp)) {
                                        Column(Modifier.padding(12.dp)) {
                                            Text("${grp.files.size} copies • $sizeLabel each", fontWeight = FontWeight.Bold)
                                            grp.files.forEach { f ->
                                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                    Text(f.name, modifier = Modifier.weight(1f))
                                                    TextButton(onClick = { onPermanentDelete(f) }) { Text("Delete", color = CrimsonAlert) }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    ActiveToolModal.RECYCLE_BIN -> {
                        Text("Recycle Bin (30-day retention)", style = MaterialTheme.typography.titleLarge)
                        Spacer(modifier = Modifier.height(10.dp))
                        if (deletedFiles.isEmpty()) {
                            Text("Recycle bin is empty.")
                        } else {
                            LazyColumn(modifier = Modifier.height(320.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(deletedFiles, key = { it.id }, contentType = { "recycle_item" }) { f ->
                                    val sizeLabel = remember(f.sizeBytes) { formatFileSize(f.sizeBytes) }
                                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) {
                                            Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            Text(sizeLabel, style = MaterialTheme.typography.bodyMedium)
                                        }
                                        TextButton(onClick = { onRestoreDeleted(f) }) { Text("Restore") }
                                        TextButton(onClick = { onPermanentDelete(f) }) { Text("Purge", color = CrimsonAlert) }
                                    }
                                }
                            }
                        }
                    }

                    ActiveToolModal.FILE_MANAGER -> {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            val parent = currentLocalDir.parentFile
                            if (parent != null && parent.canRead()) {
                                IconButton(onClick = { onLoadLocalDirectory(parent) }) {
                                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Up")
                                }
                            }
                            Text(
                                currentLocalDir.name.ifBlank { "Device Storage" },
                                style = MaterialTheme.typography.titleLarge,
                                modifier = Modifier.weight(1f)
                            )
                            if (!hasAllFilesAccess) {
                                OutlinedButton(onClick = onRequestAllFilesAccess) { Text("All Files Access", fontSize = 11.sp) }
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        LazyColumn(modifier = Modifier.height(360.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(localDirectoryItems, key = { it.file.absolutePath }, contentType = { if (it.isDirectory) "local_dir" else "local_file" }) { item ->
                                val sizeLabel = remember(item.sizeBytes) { formatFileSize(item.sizeBytes) }
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .clickable {
                                            if (item.isDirectory) onLoadLocalDirectory(item.file)
                                            else onUploadLocalFile(item)
                                        }
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        if (item.isDirectory) Icons.Default.Folder else Icons.Default.Archive,
                                        contentDescription = null
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(item.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        if (!item.isDirectory) {
                                            Text(sizeLabel, style = MaterialTheme.typography.bodyMedium)
                                        }
                                    }
                                    if (!item.isDirectory) {
                                        Text("Upload", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }

                    ActiveToolModal.INSTALLED_APPS -> {
                        Text("Installed User Apps (${installedApps.size})", style = MaterialTheme.typography.titleLarge)
                        Spacer(modifier = Modifier.height(10.dp))
                        LazyColumn(modifier = Modifier.height(360.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(installedApps, key = { it.packageName }, contentType = { "installed_app" }) { app ->
                                val sizeLabel = remember(app.sizeBytes) { formatFileSize(app.sizeBytes) }
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(app.appName, fontWeight = FontWeight.SemiBold)
                                        Text(
                                            "${app.packageName} • v${app.versionName} • $sizeLabel",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    OutlinedButton(onClick = { onBackupApk(app) }) {
                                        Text("Backup APK", fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }

                    ActiveToolModal.NONE -> Unit
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun SectionCard(
    title: String,
    content: @Composable () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(22.dp),
        tonalElevation = 1.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
private fun SettingActionRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(20.dp))
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
            Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun SettingToggleRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    enabled: Boolean = true,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurface.copy(alpha = if (enabled) 1f else 0.45f),
                modifier = Modifier.size(20.dp)
            )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                title,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = if (enabled) 1f else 0.55f)
            )
            Text(
                subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = if (enabled) 1f else 0.6f)
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Switch(checked = checked, onCheckedChange = onCheckedChange, enabled = enabled)
    }
}

private fun formatStreamCacheSize(bytes: Long): String {
    if (bytes <= 0L) return "0.0 MB"
    return formatFileSize(bytes)
}

/**
 * 2.0-second Long-Click Logout card with animated circular progress ring + haptic feedback.
 */
@Composable
private fun LongClickLogoutCard(onLogout: () -> Unit) {
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    var holdProgress by remember { mutableFloatStateOf(0f) }
    var holding by remember { mutableStateOf(false) }

    Surface(
        color = CrimsonAlert.copy(alpha = 0.1f),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier
            .fillMaxWidth()
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        holding = true
                        val job = scope.launch {
                            val totalMs = 2000L
                            val start = System.currentTimeMillis()
                            while (holding) {
                                val elapsed = System.currentTimeMillis() - start
                                holdProgress = (elapsed.toFloat() / totalMs.toFloat()).coerceIn(0f, 1f)
                                if (elapsed >= totalMs) {
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    holding = false
                                    holdProgress = 0f
                                    onLogout()
                                    break
                                }
                                delay(16L)
                            }
                        }
                        tryAwaitRelease()
                        holding = false
                        job.cancel()
                        holdProgress = 0f
                    }
                )
            }
            .testTag("long_click_logout_card")
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(modifier = Modifier.size(44.dp), contentAlignment = Alignment.Center) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawArc(
                        color = CrimsonAlert.copy(alpha = 0.25f),
                        startAngle = 0f,
                        sweepAngle = 360f,
                        useCenter = false,
                        style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                    )
                    if (holdProgress > 0f) {
                        drawArc(
                            color = CrimsonAlert,
                            startAngle = -90f,
                            sweepAngle = 360f * holdProgress,
                            useCenter = false,
                            style = Stroke(width = 3.5.dp.toPx(), cap = StrokeCap.Round)
                        )
                    }
                }
                Icon(Icons.Default.PowerSettingsNew, contentDescription = "Logout", tint = CrimsonAlert)
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text("Long click to logout", color = CrimsonAlert, fontWeight = FontWeight.Bold)
                Text(
                    if (holding) "Keep holding (${(holdProgress * 100).toInt()}%)..." else "Hold for 2.0 seconds to sign out of Telegram",
                    style = MaterialTheme.typography.bodyMedium,
                    color = CrimsonAlert.copy(alpha = 0.85f)
                )
            }
        }
    }
}

@Composable
private fun TelegramProfileHeroCard(
    authStep: TelegramAuthStep,
    userProfile: TelegramUserProfile?,
    onLoginClick: () -> Unit
) {
    val isLoggedIn = authStep is TelegramAuthStep.Authorized
    Surface(
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(24.dp),
        tonalElevation = 1.dp,
        modifier = Modifier.fillMaxWidth().testTag("settings_profile_card")
    ) {
        Row(
            modifier = Modifier.padding(18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val avatarPath = userProfile?.avatarPath
            val avatarFile by produceState<File?>(initialValue = null, avatarPath) {
                value = if (avatarPath.isNullOrBlank()) null else {
                    withContext(Dispatchers.IO) { File(avatarPath).takeIf(File::exists) }
                }
            }
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(
                        if (isLoggedIn) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.surfaceVariant
                    ),
                contentAlignment = Alignment.Center
            ) {
                when {
                    isLoggedIn && avatarFile != null -> {
                        AsyncImage(
                            model = avatarFile,
                            contentDescription = "Profile photo",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    isLoggedIn -> {
                        val initials = userProfile?.initials
                            ?: (authStep as TelegramAuthStep.Authorized).displayName
                                .split(" ")
                                .mapNotNull { it.firstOrNull()?.uppercaseChar() }
                                .take(2)
                                .joinToString("")
                                .ifBlank { "TG" }
                        Text(
                            text = initials,
                            color = MaterialTheme.colorScheme.onPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp
                        )
                    }
                    else -> {
                        Icon(
                            Icons.Default.Person,
                            contentDescription = "Telegram Profile",
                            tint = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(14.dp))

            if (isLoggedIn) {
                val authorized = authStep as TelegramAuthStep.Authorized
                val fullName = userProfile?.fullName?.takeIf { it.isNotBlank() } ?: authorized.displayName
                val sub = userProfile?.handleOrPhone?.takeIf { it.isNotBlank() }
                    ?: authorized.phoneNumber.ifBlank { "Telegram Cloud" }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = fullName,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = sub,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Surface(
                    color = EmeraldConnected.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(EmeraldConnected)
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = "Connected",
                            color = EmeraldConnected,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            } else {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Telegram Cloud",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Sign in to sync and store unlimited files",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Button(
                    onClick = onLoginClick,
                    shape = RoundedCornerShape(22.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    modifier = Modifier.height(42.dp).testTag("settings_login_button")
                ) {
                    Text("Login", fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}
