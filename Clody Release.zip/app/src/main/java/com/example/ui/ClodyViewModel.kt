package com.example.ui

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ClodyApplication
import com.example.data.local.AppSettings
import com.example.data.local.DownloadRecordEntity
import com.example.data.local.FileEntity
import com.example.data.local.FolderEntity
import com.example.data.local.GalleryAlbumEntity
import com.example.data.local.SortOption
import com.example.data.local.ThemeMode
import com.example.data.local.UploadTaskEntity
import com.example.files.DeviceStorageStats
import com.example.files.DuplicateGroup
import com.example.files.InstalledAppItem
import com.example.files.LocalFileItem
import com.example.files.LocalMediaCandidate
import com.example.media.ClodyStreamCache
import com.example.media.LocalFirstResolver
import com.example.media.ResolvedMediaSource
import com.example.media.ThumbnailGenerator
import com.example.service.ClodyPlaybackController
import com.example.service.TransferBatchSummary
import com.example.service.UploadCandidate
import com.example.telegram.TelegramAuthStep
import com.example.telegram.TelegramConnectionState
import com.example.telegram.TelegramUserProfile
import com.example.telegram.VerifyOtpOutcome
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

enum class SearchCategory(val label: String) {
    ALL("All"),
    IMAGES("Images"),
    VIDEOS("Videos"),
    AUDIO("Audio"),
    DOCS("Docs"),
    APPS("Apps"),
    ARCHIVES("Archives")
}

enum class PendingUploadIntent {
    NONE,
    GALLERY_MEDIA,
    FOLDERS_CHOOSER,
    DETECTED_AUTO_BACKUP,
    LOCAL_URIS
}

data class ShareCacheProgressState(
    val totalCount: Int,
    val completedCount: Int,
    val currentFileName: String
)

@OptIn(ExperimentalCoroutinesApi::class)
class ClodyViewModel(application: Application) : AndroidViewModel(application) {

    private val container = (application as ClodyApplication).container
    private val dao = container.dao
    val secureStorage = container.secureStorage
    private val settingsRepo = container.settingsRepository
    val telegramClient = container.telegramClient
    private val transferManager = container.transferManager
    val deviceFileManager = container.deviceFileManager

    val settings: StateFlow<AppSettings> = settingsRepo.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettings())

    val connectionState: StateFlow<TelegramConnectionState> = telegramClient.connectionState
    val authStep: StateFlow<TelegramAuthStep> = telegramClient.authStep
    val userProfile: StateFlow<TelegramUserProfile?> = telegramClient.userProfile

    val galleryMedia: StateFlow<List<FileEntity>> = dao.observeGalleryMedia()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val galleryAlbums: StateFlow<List<GalleryAlbumEntity>> = dao.observeGalleryAlbums()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favoriteGalleryMedia: StateFlow<List<FileEntity>> = dao.observeFavoriteGalleryMedia()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val deletedGalleryMedia: StateFlow<List<FileEntity>> = dao.observeDeletedGalleryMedia()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allActiveFiles: StateFlow<List<FileEntity>> = dao.observeActiveFiles()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val deletedFiles: StateFlow<List<FileEntity>> = dao.observeDeletedFiles()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val largeCloudFiles: StateFlow<List<FileEntity>> = dao.observeLargeFiles()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val uploadTasks: StateFlow<List<UploadTaskEntity>> = dao.observeActiveUploadTasks()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val downloadRecords: StateFlow<List<DownloadRecordEntity>> = dao.observeActiveDownloadRecords()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val transferBatchSummary: StateFlow<TransferBatchSummary> = container.transferBatchTracker.batchSummary
    val downloadSpeeds: StateFlow<Map<Long, Long>> = container.transferBatchTracker.downloadSpeeds

    val totalCloudBytes: StateFlow<Long> = dao.observeTotalCloudBytes()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    // Folders navigation
    private val _currentFolderId = MutableStateFlow<Long?>(null)
    val currentFolderId: StateFlow<Long?> = _currentFolderId.asStateFlow()

    private val _breadcrumbs = MutableStateFlow<List<FolderEntity>>(emptyList())
    val breadcrumbs: StateFlow<List<FolderEntity>> = _breadcrumbs.asStateFlow()

    val allFolders: StateFlow<List<FolderEntity>> = dao.observeAllFolders()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val currentSubfolders: StateFlow<List<FolderEntity>> = _currentFolderId
        .flatMapLatest { parentId -> dao.observeFolders(parentId) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val currentFolderFiles: StateFlow<List<FileEntity>> = combine(
        _currentFolderId.flatMapLatest { fid -> dao.observeFileManagerFilesInFolder(fid) },
        settings
    ) { files, appSettings ->
        val filtered = if (appSettings.showHiddenFiles) files else files.filter { !it.name.startsWith(".") }
        when (appSettings.sortOption) {
            SortOption.DATE_DESC -> filtered.sortedByDescending { it.createdAt }
            SortOption.NAME_ASC -> filtered.sortedBy { it.name.lowercase() }
            SortOption.SIZE_DESC -> filtered.sortedByDescending { it.sizeBytes }
        }
    }.flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val folderItemCounts: StateFlow<Map<Long, Int>> = combine(
        allFolders,
        allActiveFiles
    ) { folders, files ->
        val subfolderCounts = folders.groupBy { it.parentId }.mapValues { it.value.size }
        val fileCounts = files.filter { it.folderId != null }.groupBy { it.folderId!! }.mapValues { it.value.size }
        folders.associate { folder ->
            folder.id to ((subfolderCounts[folder.id] ?: 0) + (fileCounts[folder.id] ?: 0))
        }
    }.flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    // Search
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _searchCategory = MutableStateFlow(SearchCategory.ALL)
    val searchCategory: StateFlow<SearchCategory> = _searchCategory.asStateFlow()

    val searchResults: StateFlow<List<FileEntity>> = combine(
        _searchQuery,
        _searchCategory,
        settings
    ) { q, cat, appSettings -> Triple(q.trim(), cat, appSettings) }
        .flatMapLatest { (q, cat, appSettings) ->
            val baseFlow = if (q.isBlank()) {
                dao.observeActiveFiles()
            } else {
                val safeFts = q.replace("\"", "").split(Regex("\\s+"))
                    .filter { it.isNotBlank() }
                    .joinToString(" ") { "$it*" }
                if (safeFts.isNotBlank()) dao.searchFilesFts(safeFts) else dao.searchFilesLike(q)
            }
            baseFlow.combine(MutableStateFlow(cat to appSettings.showHiddenFiles)) { list, (category, showHidden) ->
                list.filter { file ->
                    val hiddenOk = showHidden || !file.name.startsWith(".")
                    val catOk = when (category) {
                        SearchCategory.ALL -> true
                        SearchCategory.IMAGES -> file.isImage
                        SearchCategory.VIDEOS -> file.isVideo
                        SearchCategory.AUDIO -> file.isAudio
                        SearchCategory.DOCS -> file.isDocument
                        SearchCategory.APPS -> file.isApp
                        SearchCategory.ARCHIVES -> file.isArchive
                    }
                    hiddenOk && catOk
                }
            }
        }
        .flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Real detected device media (strictly empty unless real new local files are scanned)
    private val _detectedLocalMedia = MutableStateFlow<List<LocalMediaCandidate>>(emptyList())
    val detectedLocalMedia: StateFlow<List<LocalMediaCandidate>> = _detectedLocalMedia.asStateFlow()

    // Upload Preview Modal candidates
    private val _uploadPreviewCandidates = MutableStateFlow<List<UploadCandidate>>(emptyList())
    val uploadPreviewCandidates: StateFlow<List<UploadCandidate>> = _uploadPreviewCandidates.asStateFlow()

    // Auth / Connect Bottom Sheet
    private val _showConnectSheet = MutableStateFlow(false)
    val showConnectSheet: StateFlow<Boolean> = _showConnectSheet.asStateFlow()

    private val _authBusy = MutableStateFlow(false)
    val authBusy: StateFlow<Boolean> = _authBusy.asStateFlow()

    private val _authBusyLabel = MutableStateFlow<String?>(null)
    val authBusyLabel: StateFlow<String?> = _authBusyLabel.asStateFlow()

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    // Storage & Tools state
    private val _deviceStorage = MutableStateFlow(deviceFileManager.getDeviceStorageStats())
    val deviceStorage: StateFlow<DeviceStorageStats> = _deviceStorage.asStateFlow()

    private val _streamCacheBytes = MutableStateFlow(ClodyStreamCache.getStreamCacheSizeBytes(application))
    val streamCacheBytes: StateFlow<Long> = _streamCacheBytes.asStateFlow()

    private val _localDirectoryItems = MutableStateFlow<List<LocalFileItem>>(emptyList())
    val localDirectoryItems: StateFlow<List<LocalFileItem>> = _localDirectoryItems.asStateFlow()

    private val _currentLocalDir = MutableStateFlow(deviceFileManager.getRootDirectory())
    val currentLocalDir: StateFlow<File> = _currentLocalDir.asStateFlow()

    private val _largeLocalFiles = MutableStateFlow<List<LocalFileItem>>(emptyList())
    val largeLocalFiles: StateFlow<List<LocalFileItem>> = _largeLocalFiles.asStateFlow()

    private val _installedApps = MutableStateFlow<List<InstalledAppItem>>(emptyList())
    val installedApps: StateFlow<List<InstalledAppItem>> = _installedApps.asStateFlow()

    private val _duplicateGroups = MutableStateFlow<List<DuplicateGroup>>(emptyList())
    val duplicateGroups: StateFlow<List<DuplicateGroup>> = _duplicateGroups.asStateFlow()

    // Media viewer active targets
    private val _activeVideoFile = MutableStateFlow<FileEntity?>(null)
    val activeVideoFile: StateFlow<FileEntity?> = _activeVideoFile.asStateFlow()

    private val _activeImageFile = MutableStateFlow<FileEntity?>(null)
    val activeImageFile: StateFlow<FileEntity?> = _activeImageFile.asStateFlow()

    private val _activeAudioFile = MutableStateFlow<FileEntity?>(null)
    val activeAudioFile: StateFlow<FileEntity?> = _activeAudioFile.asStateFlow()

    private val _activeDocumentFile = MutableStateFlow<FileEntity?>(null)
    val activeDocumentFile: StateFlow<FileEntity?> = _activeDocumentFile.asStateFlow()

    private val _binaryDownloadBanner = MutableStateFlow<BinaryBannerState?>(null)
    val binaryDownloadBanner: StateFlow<BinaryBannerState?> = _binaryDownloadBanner.asStateFlow()

    private val _completedAuthUploadIntent = MutableStateFlow(PendingUploadIntent.NONE)
    val completedAuthUploadIntent: StateFlow<PendingUploadIntent> = _completedAuthUploadIntent.asStateFlow()

    private val _shareCacheProgress = MutableStateFlow<ShareCacheProgressState?>(null)
    val shareCacheProgress: StateFlow<ShareCacheProgressState?> = _shareCacheProgress.asStateFlow()

    private var queuedPendingIntent = PendingUploadIntent.NONE
    private var queuedLocalUris: List<Uri> = emptyList()
    private var uploadOriginIsGallery: Boolean = false
    private var cloudIndexSyncJob: Job? = null

    init {
        viewModelScope.launch(Dispatchers.IO) {
            // Purge recycle bin items older than 30 days & clean any leftover finished transfer records
            val cutoff = System.currentTimeMillis() - 30L * 24L * 60L * 60L * 1000L
            dao.purgeExpiredRecycleBin(cutoff)
            dao.clearFinishedUploads()
            dao.clearCompletedDownloads()
            _deviceStorage.value = deviceFileManager.getDeviceStorageStats()
            _streamCacheBytes.value = ClodyStreamCache.getStreamCacheSizeBytes(getApplication())

            // Auto-restore cloud hierarchy on reinstall / fresh DB once Telegram Live connection is ready
            if (secureStorage.isLoggedIn()) {
                runCatching {
                    telegramClient.connectionState.first { it is TelegramConnectionState.Connected }
                    val localEmpty = dao.getAllFilesOnceIncludingTrash().isEmpty() && dao.getAllFoldersOnce().isEmpty()
                    val restored = telegramClient.syncFromTelegramChannel().getOrDefault(0)
                    if (localEmpty && restored > 0) {
                        withContext(Dispatchers.Main) {
                            showMessage("Restored $restored items from Clody Cloud")
                        }
                    }
                }
            }
        }

        // Apply recorded original MediaStore timestamps whenever background upload service inserts new files
        viewModelScope.launch(Dispatchers.IO) {
            dao.observeActiveFiles().collect { files ->
                var patchedAny = false
                for (file in files) {
                    val origMs = transferManager.consumeRecordedOriginalDateMs(
                        localUriString = file.localSourceUri,
                        fileName = file.name,
                        sizeBytes = file.sizeBytes
                    )
                    if (origMs != null && origMs > 0L && kotlin.math.abs(origMs - file.createdAt) > 2000L) {
                        dao.updateFileCreatedAt(file.id, origMs)
                        patchedAny = true
                    }
                }
                if (patchedAny) {
                    scheduleCloudIndexSync()
                }
            }
        }
    }

    fun scheduleCloudIndexSync() {
        if (!secureStorage.isLoggedIn()) return
        cloudIndexSyncJob?.cancel()
        cloudIndexSyncJob = viewModelScope.launch(Dispatchers.IO) {
            delay(2000L)
            telegramClient.pushCloudIndexSnapshot()
        }
    }

    fun showMessage(msg: String) {
        _snackbarMessage.value = msg
    }

    fun clearMessage() {
        _snackbarMessage.value = null
    }

    fun openConnectSheet() {
        _authError.value = null
        _showConnectSheet.value = true
    }

    fun dismissConnectSheet() {
        _showConnectSheet.value = false
    }

    fun verifyApiCredentials(apiIdStr: String, apiHash: String) {
        val apiId = apiIdStr.trim().toIntOrNull()
        val cleanHash = apiHash.trim()
        if (apiId == null || apiId <= 0) {
            _authError.value = "API ID must be a positive integer"
            return
        }
        if (!cleanHash.matches(Regex("^[0-9a-fA-F]{32}$"))) {
            _authError.value = "API Hash must be a 32-character hexadecimal string"
            return
        }
        viewModelScope.launch {
            _authBusy.value = true
            _authBusyLabel.value = "Connecting to Telegram..."
            _authError.value = null
            val res = telegramClient.verifyApiCredentials(apiId, cleanHash) { label ->
                _authBusyLabel.value = label
            }
            _authBusy.value = false
            _authBusyLabel.value = null
            res.onFailure { err ->
                _authError.value = err.message ?: "Failed to verify API credentials"
            }
        }
    }

    fun editApiCredentials() {
        _authError.value = null
        _authBusyLabel.value = null
        telegramClient.editApiCredentials()
    }

    fun sendPhoneCode(phone: String) {
        viewModelScope.launch {
            _authBusy.value = true
            _authBusyLabel.value = "Sending Code..."
            _authError.value = null
            val res = telegramClient.sendPhoneCode(phone)
            _authBusy.value = false
            _authBusyLabel.value = null
            res.onFailure { err ->
                _authError.value = err.message ?: "Failed to send verification code"
            }
        }
    }

    fun resendOtpCode() {
        viewModelScope.launch {
            _authBusy.value = true
            _authBusyLabel.value = "Resending Code..."
            _authError.value = null
            val res = telegramClient.resendOtpCode()
            _authBusy.value = false
            _authBusyLabel.value = null
            res.onSuccess {
                showMessage("Verification code resent")
            }.onFailure { err ->
                _authError.value = err.message ?: "Failed to resend code"
            }
        }
    }

    fun requireAuthForUpload(intent: PendingUploadIntent, onAuthorized: () -> Unit) {
        if (secureStorage.isLoggedIn() && authStep.value is TelegramAuthStep.Authorized) {
            onAuthorized()
        } else {
            queuedPendingIntent = intent
            openConnectSheet()
        }
    }

    fun consumeCompletedAuthUploadIntent() {
        _completedAuthUploadIntent.value = PendingUploadIntent.NONE
    }

    private fun handlePostAuthSuccess() {
        _showConnectSheet.value = false
        showMessage("Connected to Telegram Live Server")
        syncFromTelegram()
        when (val pending = queuedPendingIntent) {
            PendingUploadIntent.NONE -> Unit
            PendingUploadIntent.DETECTED_AUTO_BACKUP -> {
                queuedPendingIntent = PendingUploadIntent.NONE
                uploadDetectedLocalMedia()
            }
            PendingUploadIntent.LOCAL_URIS -> {
                queuedPendingIntent = PendingUploadIntent.NONE
                val uris = queuedLocalUris
                queuedLocalUris = emptyList()
                if (uris.isNotEmpty()) prepareUploadFromUris(uris)
            }
            PendingUploadIntent.GALLERY_MEDIA, PendingUploadIntent.FOLDERS_CHOOSER -> {
                queuedPendingIntent = PendingUploadIntent.NONE
                _completedAuthUploadIntent.value = pending
            }
        }
    }

    fun verifyOtpCode(code: String) {
        viewModelScope.launch {
            _authBusy.value = true
            _authBusyLabel.value = "Verifying..."
            _authError.value = null
            val res = telegramClient.verifyOtpCode(code)
            _authBusy.value = false
            _authBusyLabel.value = null
            res.onSuccess { outcome ->
                if (outcome == VerifyOtpOutcome.AUTHORIZED) {
                    handlePostAuthSuccess()
                }
            }.onFailure { err ->
                _authError.value = err.message ?: "Verification failed"
            }
        }
    }

    fun verifyTwoFactorPassword(password: String) {
        viewModelScope.launch {
            _authBusy.value = true
            _authBusyLabel.value = "Verifying..."
            _authError.value = null
            val res = telegramClient.verifyTwoFactorPassword(password)
            _authBusy.value = false
            _authBusyLabel.value = null
            res.onSuccess {
                handlePostAuthSuccess()
            }.onFailure { err ->
                _authError.value = err.message ?: "Invalid 2FA password"
            }
        }
    }

    fun logout() {
        viewModelScope.launch {
            telegramClient.logout()
            showMessage("Signed out of Telegram")
        }
    }

    fun syncFromTelegram() {
        if (!secureStorage.isLoggedIn()) {
            openConnectSheet()
            return
        }
        viewModelScope.launch {
            val res = telegramClient.syncFromTelegramChannel()
            res.onSuccess { count ->
                showMessage(if (count > 0) "Synced $count cloud items" else "Cloud index is up to date")
            }.onFailure { err ->
                showMessage("Sync error: ${err.message}")
            }
        }
    }

    fun forceCloudIndexSync() {
        if (!secureStorage.isLoggedIn()) {
            openConnectSheet()
            return
        }
        viewModelScope.launch {
            telegramClient.pushCloudIndexSnapshot()
                .onSuccess { showMessage("Cloud index backed up to Telegram") }
                .onFailure { showMessage("Index backup failed: ${it.message}") }
        }
    }

    // --- Real Local Media Scan (NO dummy data) ---
    fun refreshLocalMediaScan() {
        viewModelScope.launch {
            val existing = dao.getAllActiveFilesOnce().map { it.name to it.sizeBytes }.toSet()
            val dismissed = settings.value.dismissedBackupIds
            val found = deviceFileManager.scanUnbackedUpLocalMedia(existing, dismissed)
            _detectedLocalMedia.value = found
        }
    }

    fun dismissLocalBackupCard() {
        viewModelScope.launch {
            val ids = _detectedLocalMedia.value.map { it.id }.toSet()
            settingsRepo.addDismissedBackupIds(ids)
            _detectedLocalMedia.value = emptyList()
        }
    }

    fun setNextUploadOriginGallery(isGallery: Boolean) {
        uploadOriginIsGallery = isGallery
    }

    fun uploadDetectedLocalMedia() {
        if (!secureStorage.isLoggedIn()) {
            queuedPendingIntent = PendingUploadIntent.DETECTED_AUTO_BACKUP
            openConnectSheet()
            return
        }
        val items = _detectedLocalMedia.value
        if (items.isEmpty()) return
        viewModelScope.launch {
            val candidates = items.map {
                UploadCandidate(
                    uri = it.uri,
                    fileName = it.displayName,
                    mimeType = it.mimeType,
                    sizeBytes = it.sizeBytes,
                    durationMs = it.durationMs,
                    extractedThumbnailPath = it.thumbnailPath,
                    originalDateMs = it.originalDateMs
                )
            }
            transferManager.enqueueUploads(candidates, folderId = null, folderPath = "Gallery")
            settingsRepo.addDismissedBackupIds(items.map { it.id }.toSet())
            _detectedLocalMedia.value = emptyList()
            showMessage("Added ${candidates.size} items to background upload queue")
        }
    }

    // --- Upload Staging + Custom Video Thumbnail ---
    fun prepareUploadFromUris(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            val prepared = transferManager.prepareUploadCandidates(uris)
            _uploadPreviewCandidates.value = prepared
        }
    }

    fun setCustomThumbnailForCandidate(candidateUri: Uri, imageUri: Uri) {
        viewModelScope.launch {
            val savedPath = ThumbnailGenerator.saveCustomThumbnail(
                context = getApplication(),
                imageUri = imageUri,
                uniqueKey = candidateUri.toString()
            )
            if (savedPath != null) {
                _uploadPreviewCandidates.value = _uploadPreviewCandidates.value.map { c ->
                    if (c.uri == candidateUri) c.copy(customThumbnailPath = savedPath) else c
                }
            }
        }
    }

    fun dismissUploadPreview() {
        _uploadPreviewCandidates.value = emptyList()
        uploadOriginIsGallery = false
    }

    fun confirmEnqueueUploads() {
        val candidates = _uploadPreviewCandidates.value
        if (candidates.isEmpty()) return
        if (!secureStorage.isLoggedIn()) {
            openConnectSheet()
            return
        }
        val toGallery = uploadOriginIsGallery
        uploadOriginIsGallery = false
        viewModelScope.launch {
            if (toGallery) {
                transferManager.enqueueUploads(candidates, folderId = null, folderPath = "Gallery")
            } else {
                transferManager.enqueueUploads(candidates, currentFolderId.value, currentFolderPathString())
            }
            _uploadPreviewCandidates.value = emptyList()
            showMessage("Uploading ${candidates.size} item(s) in background")
        }
    }

    fun changeThumbnailForUploadedVideo(fileId: Long, imageUri: Uri) {
        viewModelScope.launch {
            val path = ThumbnailGenerator.saveCustomThumbnail(
                context = getApplication(),
                imageUri = imageUri,
                uniqueKey = "uploaded_$fileId"
            )
            if (path != null) {
                dao.updateCustomThumbnail(fileId, path)
                showMessage("Video thumbnail updated")
            }
        }
    }

    // --- Folder Navigation & File Operations ---
    fun createFolder(name: String) {
        val clean = name.trim()
        if (clean.isEmpty()) return
        viewModelScope.launch {
            dao.insertFolder(FolderEntity(name = clean, parentId = _currentFolderId.value))
            scheduleCloudIndexSync()
        }
    }

    fun openFolder(folder: FolderEntity) {
        _currentFolderId.value = folder.id
        _breadcrumbs.value = _breadcrumbs.value + folder
    }

    fun navigateToRootFolder() {
        _currentFolderId.value = null
        _breadcrumbs.value = emptyList()
    }

    fun navigateToBreadcrumb(folderId: Long) {
        val idx = _breadcrumbs.value.indexOfFirst { it.id == folderId }
        if (idx >= 0) {
            _currentFolderId.value = folderId
            _breadcrumbs.value = _breadcrumbs.value.take(idx + 1)
        }
    }

    fun navigateUpFolder(): Boolean {
        val crumbs = _breadcrumbs.value
        if (crumbs.isEmpty()) return false
        val updated = crumbs.dropLast(1)
        _breadcrumbs.value = updated
        _currentFolderId.value = updated.lastOrNull()?.id
        return true
    }

    private fun currentFolderPathString(): String {
        val crumbs = _breadcrumbs.value
        return if (crumbs.isEmpty()) "Cloud" else "Cloud / " + crumbs.joinToString(" / ") { it.name }
    }

    private fun buildFolderPathForId(folderId: Long?, folderMap: Map<Long, FolderEntity>): String {
        if (folderId == null) return "Cloud"
        val chain = mutableListOf<String>()
        var cursor: Long? = folderId
        val visited = HashSet<Long>()
        while (cursor != null && visited.add(cursor)) {
            val f = folderMap[cursor] ?: break
            chain.add(f.name)
            cursor = f.parentId
        }
        return if (chain.isEmpty()) "Cloud" else "Cloud / " + chain.reversed().joinToString(" / ")
    }

    private fun collectDescendantFolderIds(rootFolderId: Long, folders: List<FolderEntity>): Set<Long> {
        val childrenByParent = folders.groupBy { it.parentId }
        val collected = LinkedHashSet<Long>()
        val queue = ArrayDeque<Long>()
        queue.add(rootFolderId)
        while (queue.isNotEmpty()) {
            val id = queue.removeFirst()
            if (collected.add(id)) {
                childrenByParent[id]?.forEach { child -> queue.add(child.id) }
            }
        }
        return collected
    }

    private suspend fun syncSubtreeFileFolderPaths(subtreeRootIds: Set<Long>) {
        if (subtreeRootIds.isEmpty()) return
        val folderMap = dao.getAllFoldersOnce().associateBy { it.id }
        val activeFiles = dao.getAllActiveFilesOnce()
        for (file in activeFiles) {
            val fid = file.folderId ?: continue
            if (fid in subtreeRootIds) {
                val updatedPath = buildFolderPathForId(fid, folderMap)
                if (updatedPath != file.folderPath) {
                    dao.updateFile(file.copy(folderPath = updatedPath))
                }
            }
        }
    }

    fun renameFolder(folder: FolderEntity, newName: String) {
        val clean = newName.trim()
        if (clean.isEmpty() || clean == folder.name) return
        viewModelScope.launch(Dispatchers.IO) {
            val updated = folder.copy(name = clean)
            dao.updateFolder(updated)
            val subtree = collectDescendantFolderIds(folder.id, dao.getAllFoldersOnce())
            syncSubtreeFileFolderPaths(subtree)
            _breadcrumbs.value = _breadcrumbs.value.map { if (it.id == folder.id) updated else it }
            scheduleCloudIndexSync()
            withContext(Dispatchers.Main) { showMessage("Renamed folder to \"$clean\"") }
        }
    }

    fun moveFolderToParent(folder: FolderEntity, targetParentId: Long?) {
        viewModelScope.launch(Dispatchers.IO) {
            val all = dao.getAllFoldersOnce()
            val forbidden = collectDescendantFolderIds(folder.id, all)
            if (targetParentId != null && targetParentId in forbidden) {
                withContext(Dispatchers.Main) { showMessage("Cannot move a folder inside itself") }
                return@launch
            }
            dao.moveFolderToParent(folder.id, targetParentId)
            syncSubtreeFileFolderPaths(forbidden)
            scheduleCloudIndexSync()
            val targetName = targetParentId?.let { id -> all.firstOrNull { it.id == id }?.name } ?: "Cloud Root"
            withContext(Dispatchers.Main) { showMessage("Moved \"${folder.name}\" to $targetName") }
        }
    }

    fun deleteFolderRecursively(folder: FolderEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            val allFolders = dao.getAllFoldersOnce()
            val subtreeIds = collectDescendantFolderIds(folder.id, allFolders)
            val allFiles = dao.getAllActiveFilesOnce()
            val targetFiles = allFiles.filter { it.folderId != null && it.folderId in subtreeIds }

            if (targetFiles.isNotEmpty()) {
                val fileIds = targetFiles.map { it.id }
                if (settings.value.useRecycleBin) {
                    dao.softDeleteFiles(fileIds)
                } else {
                    dao.permanentlyDeleteFiles(fileIds)
                    targetFiles.forEach { ClodyStreamCache.deleteFileCache(getApplication(), it) }
                }
            }
            dao.deleteFoldersByIds(subtreeIds.toList())
            if (_breadcrumbs.value.any { it.id in subtreeIds }) {
                navigateToRootFolder()
            }
            scheduleCloudIndexSync()
            withContext(Dispatchers.Main) {
                showMessage("Deleted folder \"${folder.name}\"")
            }
        }
    }

    fun moveFilesToFolder(files: List<FileEntity>, targetFolderId: Long?) {
        if (files.isEmpty()) return
        viewModelScope.launch(Dispatchers.IO) {
            val folderMap = dao.getAllFoldersOnce().associateBy { it.id }
            val targetPath = buildFolderPathForId(targetFolderId, folderMap)
            dao.moveFilesToFolder(files.map { it.id }, targetFolderId, targetPath)
            scheduleCloudIndexSync()
            withContext(Dispatchers.Main) {
                showMessage("Moved ${files.size} item(s) to $targetPath")
            }
        }
    }

    fun copyFileToFolder(file: FileEntity, targetFolderId: Long?) {
        viewModelScope.launch(Dispatchers.IO) {
            val folderMap = dao.getAllFoldersOnce().associateBy { it.id }
            val targetPath = buildFolderPathForId(targetFolderId, folderMap)
            val copyName = if (file.folderId == targetFolderId) {
                val base = file.name.substringBeforeLast('.')
                val ext = file.name.substringAfterLast('.', "")
                if (ext.isNotEmpty()) "$base (Copy).$ext" else "$base (Copy)"
            } else file.name
            dao.insertFile(
                file.copy(
                    id = 0L,
                    name = copyName,
                    folderId = targetFolderId,
                    folderPath = targetPath
                )
            )
            scheduleCloudIndexSync()
            withContext(Dispatchers.Main) {
                showMessage("Copied ${file.name} to $targetPath")
            }
        }
    }

    suspend fun getFilesInsideFolderTree(folderIds: List<Long>): List<FileEntity> = withContext(Dispatchers.IO) {
        if (folderIds.isEmpty()) return@withContext emptyList()
        val allFolders = dao.getAllFoldersOnce()
        val subtreeIds = folderIds.flatMap { collectDescendantFolderIds(it, allFolders) }.toSet()
        dao.getAllActiveFilesOnce().filter { it.folderId != null && it.folderId in subtreeIds }
    }

    fun toggleFavorite(file: FileEntity) {
        val nextFav = !file.isFavorite
        if (_activeImageFile.value?.id == file.id) {
            _activeImageFile.value = _activeImageFile.value?.copy(isFavorite = nextFav)
        }
        if (_activeVideoFile.value?.id == file.id) {
            _activeVideoFile.value = _activeVideoFile.value?.copy(isFavorite = nextFav)
        }
        viewModelScope.launch {
            dao.setFileFavorite(file.id, nextFav)
            scheduleCloudIndexSync()
        }
    }

    // --- Gallery Albums (strictly separate from File Folders) ---
    fun createGalleryAlbum(name: String, initialFile: FileEntity? = null) {
        val clean = name.trim()
        if (clean.isEmpty()) return
        viewModelScope.launch {
            val newId = dao.insertAlbum(
                GalleryAlbumEntity(
                    name = clean,
                    coverThumbnailPath = initialFile?.activeThumbnailPath
                )
            )
            if (initialFile != null) {
                dao.setFileAlbum(initialFile.id, newId)
                if (_activeImageFile.value?.id == initialFile.id) {
                    _activeImageFile.value = _activeImageFile.value?.copy(albumId = newId)
                }
                if (_activeVideoFile.value?.id == initialFile.id) {
                    _activeVideoFile.value = _activeVideoFile.value?.copy(albumId = newId)
                }
                showMessage("Created album \"$clean\" & added ${initialFile.name}")
            } else {
                showMessage("Created album \"$clean\"")
            }
            scheduleCloudIndexSync()
        }
    }

    fun assignFileToAlbum(file: FileEntity, album: GalleryAlbumEntity) {
        viewModelScope.launch {
            dao.setFileAlbum(file.id, album.id)
            if (album.coverThumbnailPath.isNullOrBlank() && !file.activeThumbnailPath.isNullOrBlank()) {
                dao.insertAlbum(album.copy(coverThumbnailPath = file.activeThumbnailPath))
            }
            if (_activeImageFile.value?.id == file.id) {
                _activeImageFile.value = _activeImageFile.value?.copy(albumId = album.id)
            }
            if (_activeVideoFile.value?.id == file.id) {
                _activeVideoFile.value = _activeVideoFile.value?.copy(albumId = album.id)
            }
            showMessage("Added to ${album.name}")
            scheduleCloudIndexSync()
        }
    }

    fun removeFileFromAlbum(file: FileEntity) {
        viewModelScope.launch {
            dao.setFileAlbum(file.id, null)
            if (_activeImageFile.value?.id == file.id) {
                _activeImageFile.value = _activeImageFile.value?.copy(albumId = null)
            }
            if (_activeVideoFile.value?.id == file.id) {
                _activeVideoFile.value = _activeVideoFile.value?.copy(albumId = null)
            }
            showMessage("Removed from album")
            scheduleCloudIndexSync()
        }
    }

    fun deleteGalleryAlbum(album: GalleryAlbumEntity) {
        viewModelScope.launch {
            dao.clearAlbumFromFiles(album.id)
            dao.deleteAlbum(album.id)
            showMessage("Deleted album \"${album.name}\"")
            scheduleCloudIndexSync()
        }
    }

    fun emptyGalleryTrash() {
        viewModelScope.launch {
            val items = deletedGalleryMedia.value
            dao.emptyGalleryTrash()
            items.forEach { ClodyStreamCache.deleteFileCache(getApplication(), it) }
            showMessage("Gallery trash emptied")
            scheduleCloudIndexSync()
        }
    }

    fun renameFile(file: FileEntity, newName: String) {
        val clean = newName.trim()
        if (clean.isEmpty()) return
        viewModelScope.launch {
            val ext = clean.substringAfterLast('.', file.extension)
            dao.updateFile(file.copy(name = clean, extension = ext))
            scheduleCloudIndexSync()
        }
    }

    fun deleteFile(file: FileEntity) {
        viewModelScope.launch {
            if (settings.value.useRecycleBin && !file.isDeleted) {
                dao.softDeleteFile(file.id)
                showMessage("Moved to Recycle Bin")
            } else {
                dao.permanentlyDeleteFile(file.id)
                ClodyStreamCache.deleteFileCache(getApplication(), file)
                showMessage("Permanently deleted")
            }
            scheduleCloudIndexSync()
        }
    }

    fun restoreFile(file: FileEntity) {
        viewModelScope.launch {
            dao.restoreFile(file.id)
            showMessage("Restored ${file.name}")
            scheduleCloudIndexSync()
        }
    }

    fun permanentlyDeleteFile(file: FileEntity) {
        viewModelScope.launch {
            dao.permanentlyDeleteFile(file.id)
            ClodyStreamCache.deleteFileCache(getApplication(), file)
            scheduleCloudIndexSync()
        }
    }

    fun downloadToPublicGallery(file: FileEntity) {
        showMessage("Saving ${file.name} to phone storage...")
        transferManager.exportToPublicStorage(file) { res ->
            res.onSuccess { path ->
                showMessage("Saved to $path")
            }.onFailure { err ->
                showMessage("Download failed: ${err.message}")
            }
        }
    }

    fun shareFile(file: FileEntity, cachedFile: File?) {
        val ctx = getApplication<Application>()
        val target = cachedFile?.takeIf { it.exists() && !it.name.endsWith(".part") }
        if (target == null) {
            shareFilesViaPrivateCache(listOf(file))
            return
        }
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", target)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = file.mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        container.markExternalShareLaunched()
        ctx.startActivity(Intent.createChooser(intent, "Share ${file.name}").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        })
    }

    fun shareFilesViaPrivateCache(files: List<FileEntity>, includeFolderIds: List<Long> = emptyList()) {
        viewModelScope.launch {
            val nestedFiles = if (includeFolderIds.isNotEmpty()) getFilesInsideFolderTree(includeFolderIds) else emptyList()
            val combined = (files + nestedFiles).distinctBy { it.id }
            if (combined.isEmpty()) {
                showMessage("No files selected to share")
                return@launch
            }
            _shareCacheProgress.value = ShareCacheProgressState(
                totalCount = combined.size,
                completedCount = 0,
                currentFileName = combined.first().name
            )
            val result = transferManager.prepareFilesInSharedCache(combined) { done, total, currentName ->
                _shareCacheProgress.value = ShareCacheProgressState(total, done, currentName)
            }
            _shareCacheProgress.value = null
            _streamCacheBytes.value = ClodyStreamCache.getStreamCacheSizeBytes(getApplication())

            result.onSuccess { cachedFiles ->
                if (cachedFiles.isEmpty()) {
                    showMessage("Unable to prepare files for sharing")
                    return@onSuccess
                }
                val ctx = getApplication<Application>()
                val authority = "${ctx.packageName}.fileprovider"
                val uris = ArrayList(cachedFiles.map { FileProvider.getUriForFile(ctx, authority, it) })
                val shareIntent = if (uris.size == 1) {
                    Intent(Intent.ACTION_SEND).apply {
                        type = combined.first().mimeType.ifBlank { "*/*" }
                        putExtra(Intent.EXTRA_STREAM, uris.first())
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                } else {
                    val mime = when {
                        combined.all { it.isImage } -> "image/*"
                        combined.all { it.isVideo } -> "video/*"
                        combined.all { it.isImage || it.isVideo } -> "*/*"
                        else -> "*/*"
                    }
                    Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                        type = mime
                        putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                }
                container.markExternalShareLaunched()
                ctx.startActivity(
                    Intent.createChooser(shareIntent, "Share ${uris.size} item(s)").apply {
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                )
            }.onFailure { err ->
                showMessage("Share failed: ${err.message ?: "Unable to fetch cloud files"}")
            }
        }
    }

    fun downloadBatchToPublic(files: List<FileEntity>, includeFolderIds: List<Long> = emptyList()) {
        viewModelScope.launch {
            val nestedFiles = if (includeFolderIds.isNotEmpty()) getFilesInsideFolderTree(includeFolderIds) else emptyList()
            val combined = (files + nestedFiles).distinctBy { it.id }
            if (combined.isEmpty()) {
                showMessage("No files selected to download")
                return@launch
            }
            showMessage("Downloading ${combined.size} file(s) in Original Quality...")
            var successCount = 0
            for (file in combined) {
                val res = transferManager.downloadToPublicStorage(file)
                if (res.isSuccess) successCount++
            }
            showMessage("Saved $successCount/${combined.size} file(s) to phone storage")
        }
    }

    fun deleteBatch(files: List<FileEntity>, folders: List<FolderEntity> = emptyList()) {
        if (files.isEmpty() && folders.isEmpty()) return
        viewModelScope.launch(Dispatchers.IO) {
            val allFolders = dao.getAllFoldersOnce()
            val subtreeIds = folders.flatMap { collectDescendantFolderIds(it.id, allFolders) }.toSet()
            val folderFiles = if (subtreeIds.isNotEmpty()) {
                dao.getAllActiveFilesOnce().filter { it.folderId != null && it.folderId in subtreeIds }
            } else emptyList()
            val allTargetFiles = (files + folderFiles).distinctBy { it.id }
            val fileIds = allTargetFiles.map { it.id }

            if (fileIds.isNotEmpty()) {
                if (settings.value.useRecycleBin) {
                    dao.softDeleteFiles(fileIds)
                } else {
                    dao.permanentlyDeleteFiles(fileIds)
                    allTargetFiles.forEach { ClodyStreamCache.deleteFileCache(getApplication(), it) }
                }
            }
            if (subtreeIds.isNotEmpty()) {
                dao.deleteFoldersByIds(subtreeIds.toList())
                if (_breadcrumbs.value.any { it.id in subtreeIds }) {
                    navigateToRootFolder()
                }
            }
            scheduleCloudIndexSync()
            withContext(Dispatchers.Main) {
                val msg = when {
                    folders.isNotEmpty() && files.isNotEmpty() -> "Deleted ${files.size} file(s) & ${folders.size} folder(s)"
                    folders.isNotEmpty() -> "Deleted ${folders.size} folder(s)"
                    settings.value.useRecycleBin -> "Moved ${files.size} item(s) to Recycle Bin"
                    else -> "Permanently deleted ${files.size} item(s)"
                }
                showMessage(msg)
            }
        }
    }

    fun openCloudFile(file: FileEntity) {
        when {
            file.isVideo -> openVideoPlayer(file)
            file.isImage -> openImageViewer(file)
            file.isAudio -> openAudioPlayer(file)
            file.isInAppDocument -> openDocumentReader(file)
            else -> triggerDirectBinaryDownload(file)
        }
    }

    fun openVideoPlayer(file: FileEntity) {
        _activeVideoFile.value = file
    }

    fun closeVideoPlayer() {
        ClodyPlaybackController.stopAndCleanup(getApplication())
        _activeVideoFile.value = null
        refreshStorageMetrics()
    }

    fun openImageViewer(file: FileEntity) {
        _activeImageFile.value = file
    }

    fun closeImageViewer() {
        _activeImageFile.value = null
        refreshStorageMetrics()
    }

    fun openAudioPlayer(file: FileEntity) {
        _activeAudioFile.value = file
    }

    fun closeAudioPlayer() {
        ClodyPlaybackController.stopAndCleanup(getApplication())
        _activeAudioFile.value = null
        refreshStorageMetrics()
    }

    fun openPlayerFromNotification(fileId: Long, isVideo: Boolean) {
        val currentServiceFile = ClodyPlaybackController.activeFile.value
        if (currentServiceFile != null && currentServiceFile.id == fileId) {
            if (isVideo) {
                _activeAudioFile.value = null
                _activeVideoFile.value = currentServiceFile
            } else {
                _activeVideoFile.value = null
                _activeAudioFile.value = currentServiceFile
            }
            return
        }
        viewModelScope.launch {
            val file = withContext(Dispatchers.IO) {
                dao.getAllActiveFilesOnce().firstOrNull { it.id == fileId }
            } ?: currentServiceFile ?: return@launch
            if (isVideo || file.isVideo) {
                _activeAudioFile.value = null
                _activeVideoFile.value = file
            } else {
                _activeVideoFile.value = null
                _activeAudioFile.value = file
            }
        }
    }

    fun openDocumentReader(file: FileEntity) {
        _activeDocumentFile.value = file
    }

    fun closeDocumentReader() {
        _activeDocumentFile.value = null
        refreshStorageMetrics()
    }

    fun triggerDirectBinaryDownload(file: FileEntity) {
        viewModelScope.launch {
            val localCheck = withContext(Dispatchers.IO) {
                LocalFirstResolver.resolve(getApplication(), file)
            }
            if (localCheck is ResolvedMediaSource.LocalDevice) {
                _binaryDownloadBanner.value = BinaryBannerState.Completed(
                    fileName = file.name,
                    message = "${file.name} is Saved on Device ✓ — Open from your device File Manager"
                )
                return@launch
            }
            _binaryDownloadBanner.value = BinaryBannerState.Downloading(file.name)
            transferManager.exportToPublicStorage(file) { res ->
                res.onSuccess {
                    _binaryDownloadBanner.value = BinaryBannerState.Completed(
                        fileName = file.name,
                        message = "Downloaded ${file.name} — Open from your device File Manager"
                    )
                }.onFailure { err ->
                    _binaryDownloadBanner.value = BinaryBannerState.Error(
                        fileName = file.name,
                        message = err.message ?: "Unable to download file"
                    )
                }
            }
        }
    }

    fun dismissBinaryBanner() {
        _binaryDownloadBanner.value = null
    }

    fun pauseUpload(taskId: Long) = transferManager.pauseUpload(taskId)
    fun resumeUpload(taskId: Long) = transferManager.resumeUpload(taskId)
    fun cancelUpload(taskId: Long) = transferManager.cancelUpload(taskId)
    fun cancelDownload(recordId: Long) = transferManager.cancelDownload(recordId)
    fun clearFinishedUploads() { viewModelScope.launch { dao.clearFinishedUploads() } }
    fun clearCompletedDownloads() { viewModelScope.launch { dao.clearCompletedDownloads() } }

    fun updateSearchQuery(q: String) { _searchQuery.value = q }
    fun updateSearchCategory(cat: SearchCategory) { _searchCategory.value = cat }

    // --- Settings & Tools ---
    fun setThemeMode(mode: ThemeMode) { viewModelScope.launch { settingsRepo.setThemeMode(mode) } }
    fun setDynamicColors(enabled: Boolean) { viewModelScope.launch { settingsRepo.setDynamicColors(enabled) } }
    fun setShowHiddenFiles(enabled: Boolean) { viewModelScope.launch { settingsRepo.setShowHiddenFiles(enabled) } }
    fun setShowFileExtensions(enabled: Boolean) { viewModelScope.launch { settingsRepo.setShowFileExtensions(enabled) } }
    fun setUseRecycleBin(enabled: Boolean) { viewModelScope.launch { settingsRepo.setUseRecycleBin(enabled) } }
    fun setConfirmBeforeDeleting(enabled: Boolean) { viewModelScope.launch { settingsRepo.setConfirmBeforeDeleting(enabled) } }
    fun setUploadWifiOnly(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepo.setUploadWifiOnly(enabled)
            transferManager.onUploadNetworkPolicyChanged(enabled)
        }
    }

    fun setZeroStorageMode(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepo.setZeroStorageMode(enabled)
            if (enabled) {
                withContext(Dispatchers.IO) {
                    runCatching { telegramClient.clearAllTdMediaTempFiles() }
                    ClodyStreamCache.clearAllStreamCache(getApplication(), includeSharedCache = true)
                    dao.clearAllLocalCachePaths()
                    _deviceStorage.value = deviceFileManager.getDeviceStorageStats()
                    _streamCacheBytes.value = ClodyStreamCache.getCurrentCacheBytes(getApplication())
                }
            }
        }
    }

    fun setAutoDeleteCacheOnExit(enabled: Boolean) {
        viewModelScope.launch { settingsRepo.setAutoDeleteCacheOnExit(enabled) }
    }

    fun setGridViewFolders(grid: Boolean) { viewModelScope.launch { settingsRepo.setGridViewFolders(grid) } }
    fun setSortOption(option: SortOption) { viewModelScope.launch { settingsRepo.setSortOption(option) } }

    fun clearStreamCache() {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { telegramClient.clearAllTdMediaTempFiles() }
            val freed = ClodyStreamCache.clearAllStreamCache(getApplication(), includeSharedCache = true)
            dao.clearAllLocalCachePaths()
            _deviceStorage.value = deviceFileManager.getDeviceStorageStats()
            _streamCacheBytes.value = ClodyStreamCache.getCurrentCacheBytes(getApplication())
            withContext(Dispatchers.Main) {
                showMessage("Freed ${formatFileSize(freed)} stream & share cache")
            }
        }
    }

    fun refreshStorageMetrics() {
        viewModelScope.launch(Dispatchers.IO) {
            _deviceStorage.value = deviceFileManager.getDeviceStorageStats()
            _streamCacheBytes.value = ClodyStreamCache.getCurrentCacheBytes(getApplication())
        }
    }

    fun loadLocalDirectory(dir: File = _currentLocalDir.value) {
        viewModelScope.launch {
            _currentLocalDir.value = dir
            _localDirectoryItems.value = deviceFileManager.listDirectory(dir, settings.value.showHiddenFiles)
        }
    }

    fun uploadLocalFile(item: LocalFileItem) {
        if (item.isDirectory) return
        val uris = listOf(Uri.fromFile(item.file))
        if (!secureStorage.isLoggedIn()) {
            queuedLocalUris = uris
            queuedPendingIntent = PendingUploadIntent.LOCAL_URIS
            openConnectSheet()
            return
        }
        prepareUploadFromUris(uris)
    }

    fun scanLargeLocalFiles() {
        viewModelScope.launch {
            _largeLocalFiles.value = deviceFileManager.scanLargeLocalFiles()
        }
    }

    fun scanDuplicates() {
        viewModelScope.launch {
            _duplicateGroups.value = deviceFileManager.findDuplicateCloudFiles(allActiveFiles.value)
        }
    }

    fun loadInstalledApps() {
        viewModelScope.launch {
            _installedApps.value = deviceFileManager.getInstalledUserApps()
        }
    }

    fun backupApkToCloud(app: InstalledAppItem) {
        val uris = listOf(Uri.fromFile(File(app.apkPath)))
        if (!secureStorage.isLoggedIn()) {
            queuedLocalUris = uris
            queuedPendingIntent = PendingUploadIntent.LOCAL_URIS
            openConnectSheet()
            return
        }
        prepareUploadFromUris(uris)
    }

    fun compressFiles(uris: List<Uri>, archiveName: String) {
        viewModelScope.launch {
            deviceFileManager.compressToZip(uris, archiveName)
                .onSuccess { file -> showMessage("Created ${file.name} (${formatFileSize(file.length())})") }
                .onFailure { err -> showMessage("Compression failed: ${err.message}") }
        }
    }

    fun extractArchive(uri: Uri) {
        viewModelScope.launch {
            deviceFileManager.extractArchive(uri)
                .onSuccess { dir -> showMessage("Extracted to ${dir.name}/") }
                .onFailure { err -> showMessage("Extraction failed: ${err.message}") }
        }
    }

    fun addSyncedFolder(treeUri: Uri) {
        val ctx = getApplication<Application>()
        runCatching {
            ctx.contentResolver.takePersistableUriPermission(
                treeUri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        }
        viewModelScope.launch {
            settingsRepo.addSyncedFolderUri(treeUri.toString())
            val files = withContext(Dispatchers.IO) {
                val list = mutableListOf<Uri>()
                val docId = DocumentsContract.getTreeDocumentId(treeUri)
                val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, docId)
                ctx.contentResolver.query(
                    childrenUri,
                    arrayOf(
                        DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                        DocumentsContract.Document.COLUMN_MIME_TYPE
                    ),
                    null,
                    null,
                    null
                )?.use { cursor ->
                    while (cursor.moveToNext() && list.size < 25) {
                        val childId = cursor.getString(0)
                        val mime = cursor.getString(1) ?: ""
                        if (mime != DocumentsContract.Document.MIME_TYPE_DIR) {
                            list += DocumentsContract.buildDocumentUriUsingTree(treeUri, childId)
                        }
                    }
                }
                list
            }
            val folderLabel = treeUri.lastPathSegment?.substringAfterLast(':') ?: "Synced"
            if (files.isNotEmpty() && secureStorage.isLoggedIn()) {
                val prepared = transferManager.prepareUploadCandidates(files)
                transferManager.enqueueUploads(prepared, null, folderLabel)
                showMessage("Syncing ${prepared.size} files from $folderLabel")
            } else {
                showMessage("Folder assigned for sync")
            }
        }
    }

    fun removeSyncedFolder(uriString: String) {
        viewModelScope.launch { settingsRepo.removeSyncedFolderUri(uriString) }
    }

    fun rebuildFileIndex() {
        viewModelScope.launch(Dispatchers.IO) {
            dao.rebuildFtsIndex()
            refreshLocalMediaScan()
            withContext(Dispatchers.Main) { showMessage("File index rebuilt") }
        }
    }

    fun optimizeSearchIndex() {
        viewModelScope.launch(Dispatchers.IO) {
            dao.optimizeFtsIndex()
            withContext(Dispatchers.Main) { showMessage("FTS4 search index optimized") }
        }
    }
}

fun formatFileSize(bytes: Long): String {
    if (bytes <= 0L) return "0 B"
    val kb = 1024.0
    val mb = kb * 1024.0
    val gb = mb * 1024.0
    return when {
        bytes >= gb -> String.format("%.1f GB", bytes / gb)
        bytes >= mb -> String.format("%.1f MB", bytes / mb)
        bytes >= kb -> String.format("%.0f KB", bytes / kb)
        else -> "$bytes B"
    }
}
