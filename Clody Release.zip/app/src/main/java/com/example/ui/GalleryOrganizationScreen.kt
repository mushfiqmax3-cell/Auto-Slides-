package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CollectionsBookmark
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RestoreFromTrash
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.local.FileEntity
import com.example.data.local.GalleryAlbumEntity
import com.example.media.formatDuration
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.LocalClodyMetrics
import com.example.ui.theme.VideoIconIndigo
import com.example.ui.theme.VideoTintSurface
import com.example.ui.theme.bounceClick
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

private sealed interface GalleryOrgSubPage {
    data object Hub : GalleryOrgSubPage
    data object Favorites : GalleryOrgSubPage
    data object Trash : GalleryOrgSubPage
    data class AlbumDetail(val albumId: Long) : GalleryOrgSubPage
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun GalleryOrganizationScreen(
    allMedia: List<FileEntity>,
    albums: List<GalleryAlbumEntity>,
    favoriteMedia: List<FileEntity>,
    trashMedia: List<FileEntity>,
    lockedVaultCount: Int = 0,
    onOpenLockedVault: () -> Unit = {},
    onCreateAlbum: (String) -> Unit,
    onDeleteAlbum: (GalleryAlbumEntity) -> Unit,
    onAssignToAlbum: (FileEntity, GalleryAlbumEntity) -> Unit,
    onRemoveFromAlbum: (FileEntity) -> Unit,
    onRestoreTrashItem: (FileEntity) -> Unit,
    onPermanentDeleteItem: (FileEntity) -> Unit,
    onEmptyTrash: () -> Unit,
    onOpenPhoto: (FileEntity) -> Unit,
    onOpenVideo: (FileEntity) -> Unit,
    onOpenFileMenu: (FileEntity) -> Unit,
    onBack: () -> Unit
) {
    val metrics = LocalClodyMetrics.current
    var subPage by remember { mutableStateOf<GalleryOrgSubPage>(GalleryOrgSubPage.Hub) }
    var searchQuery by remember { mutableStateOf("") }
    var showCreateAlbumDialog by remember { mutableStateOf(false) }
    var albumPendingDelete by remember { mutableStateOf<GalleryAlbumEntity?>(null) }
    var showAddMediaToAlbumSheet by remember { mutableStateOf<GalleryAlbumEntity?>(null) }
    var showEmptyTrashConfirm by remember { mutableStateOf(false) }

    BackHandler {
        if (subPage != GalleryOrgSubPage.Hub) {
            subPage = GalleryOrgSubPage.Hub
        } else {
            onBack()
        }
    }

    val searchResults = remember(allMedia, searchQuery) {
        val q = searchQuery.trim()
        if (q.isEmpty()) emptyList()
        else allMedia.filter { it.name.contains(q, ignoreCase = true) }
    }

    val albumItemCounts = remember(allMedia) {
        allMedia.filter { it.albumId != null }.groupingBy { it.albumId!! }.eachCount()
    }

    Surface(
        color = MaterialTheme.colorScheme.background,
        modifier = Modifier
            .fillMaxSize()
            .testTag("gallery_organization_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
        ) {
            // Top bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        if (subPage != GalleryOrgSubPage.Hub) {
                            subPage = GalleryOrgSubPage.Hub
                        } else {
                            onBack()
                        }
                    },
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }

                when (val current = subPage) {
                    is GalleryOrgSubPage.Hub -> {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Search photos & videos") },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { searchQuery = "" }) {
                                        Icon(Icons.Default.Close, contentDescription = "Clear search")
                                    }
                                }
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(28.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = MaterialTheme.colorScheme.surface,
                                unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                                focusedBorderColor = Color.Transparent,
                                unfocusedBorderColor = Color.Transparent
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .padding(end = 6.dp)
                                .testTag("gallery_org_search_input")
                        )
                    }

                    is GalleryOrgSubPage.Favorites -> {
                        Text(
                            text = "Favorites (${favoriteMedia.size})",
                            style = MaterialTheme.typography.headlineMedium,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    is GalleryOrgSubPage.Trash -> {
                        Text(
                            text = "Trash (${trashMedia.size})",
                            style = MaterialTheme.typography.headlineMedium,
                            modifier = Modifier.weight(1f)
                        )
                        if (trashMedia.isNotEmpty()) {
                            TextButton(onClick = { showEmptyTrashConfirm = true }) {
                                Text("Empty", color = CrimsonAlert, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }

                    is GalleryOrgSubPage.AlbumDetail -> {
                        val album = albums.firstOrNull { it.id == current.albumId }
                        Text(
                            text = album?.name ?: "Album",
                            style = MaterialTheme.typography.headlineMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        if (album != null) {
                            IconButton(
                                onClick = { showAddMediaToAlbumSheet = album },
                                modifier = Modifier.size(48.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = "Add media to album")
                            }
                            IconButton(
                                onClick = { albumPendingDelete = album },
                                modifier = Modifier.size(48.dp)
                            ) {
                                Icon(Icons.Default.DeleteOutline, contentDescription = "Delete album", tint = CrimsonAlert)
                            }
                        }
                    }
                }
            }

            // Content body
            when (val current = subPage) {
                is GalleryOrgSubPage.Hub -> {
                    if (searchQuery.isNotBlank()) {
                        if (searchResults.isEmpty()) {
                            Box(
                                modifier = Modifier.fillMaxSize().padding(24.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "No photos or videos match \"$searchQuery\"",
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        } else {
                            MediaOrganizationGrid(
                                items = searchResults,
                                minCellSize = metrics.galleryMinCellSize,
                                onOpenPhoto = onOpenPhoto,
                                onOpenVideo = onOpenVideo,
                                onOpenMenu = onOpenFileMenu
                            )
                        }
                    } else {
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(2),
                            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 100.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            // Top Quick-Access Cards: Favorites, Trash & Biometric Locked Vault
                            item(key = "quick_favorites") {
                                Surface(
                                    color = MaterialTheme.colorScheme.surface,
                                    shape = RoundedCornerShape(22.dp),
                                    tonalElevation = 1.dp,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(22.dp))
                                        .bounceClick { subPage = GalleryOrgSubPage.Favorites }
                                        .testTag("gallery_favorites_card")
                                ) {
                                    Column(modifier = Modifier.padding(16.dp)) {
                                        Box(
                                            modifier = Modifier
                                                .size(42.dp)
                                                .clip(CircleShape)
                                                .background(MaterialTheme.colorScheme.surfaceVariant),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                Icons.Default.Favorite,
                                                contentDescription = null,
                                                tint = CrimsonAlert,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(12.dp))
                                        Text("Favorites", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                        Text(
                                            "${favoriteMedia.size} item(s)",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }

                            item(key = "quick_trash") {
                                Surface(
                                    color = MaterialTheme.colorScheme.surface,
                                    shape = RoundedCornerShape(22.dp),
                                    tonalElevation = 1.dp,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(22.dp))
                                        .bounceClick { subPage = GalleryOrgSubPage.Trash }
                                        .testTag("gallery_trash_card")
                                ) {
                                    Column(modifier = Modifier.padding(16.dp)) {
                                        Box(
                                            modifier = Modifier
                                                .size(42.dp)
                                                .clip(CircleShape)
                                                .background(MaterialTheme.colorScheme.surfaceVariant),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                Icons.Default.DeleteOutline,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.onSurface,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(12.dp))
                                        Text("Trash", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                        Text(
                                            "${trashMedia.size} item(s)",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }

                            item(span = { GridItemSpan(maxLineSpan) }, key = "quick_locked_vault") {
                                Surface(
                                    color = MaterialTheme.colorScheme.surface,
                                    shape = RoundedCornerShape(22.dp),
                                    tonalElevation = 1.dp,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(22.dp))
                                        .bounceClick(onClick = onOpenLockedVault)
                                        .testTag("gallery_locked_vault_card")
                                ) {
                                    Row(
                                        modifier = Modifier.padding(16.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(42.dp)
                                                .clip(CircleShape)
                                                .background(MaterialTheme.colorScheme.primary),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = androidx.compose.material.icons.Icons.Default.Check,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.onPrimary,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(14.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "Locked Vault",
                                                style = MaterialTheme.typography.titleMedium,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = "$lockedVaultCount private item(s) • Biometric protected",
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                }
                            }

                            // Dedicated Albums Section Header
                            item(span = { GridItemSpan(maxLineSpan) }, key = "albums_header") {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = 12.dp, bottom = 2.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text("Albums", style = MaterialTheme.typography.titleLarge)
                                        Text(
                                            "Visual media collections separate from File Folders",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Button(
                                        onClick = { showCreateAlbumDialog = true },
                                        shape = RoundedCornerShape(20.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = MaterialTheme.colorScheme.primary,
                                            contentColor = MaterialTheme.colorScheme.onPrimary
                                        ),
                                        modifier = Modifier
                                            .heightIn(min = 44.dp)
                                            .testTag("create_gallery_album_button")
                                    ) {
                                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("New Album", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                    }
                                }
                            }

                            if (albums.isEmpty()) {
                                item(span = { GridItemSpan(maxLineSpan) }, key = "albums_empty") {
                                    Surface(
                                        color = MaterialTheme.colorScheme.surface,
                                        shape = RoundedCornerShape(22.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(24.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(52.dp)
                                                    .clip(CircleShape)
                                                    .background(MaterialTheme.colorScheme.surfaceVariant),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    Icons.Default.CollectionsBookmark,
                                                    contentDescription = null,
                                                    tint = MaterialTheme.colorScheme.onSurface
                                                )
                                            }
                                            Spacer(modifier = Modifier.height(10.dp))
                                            Text("No Albums Yet", style = MaterialTheme.typography.titleMedium)
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                "Tap New Album to group favorite trips, reels, or moments.",
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                }
                            } else {
                                items(albums, key = { "album_${it.id}" }, contentType = { "org_album" }) { album ->
                                    val count = albumItemCounts[album.id] ?: 0
                                    val firstMediaThumb = remember(allMedia, album.id) {
                                        allMedia.firstOrNull { it.albumId == album.id }?.activeThumbnailPath
                                    }
                                    val resolvedCoverFile by produceState<File?>(
                                        initialValue = null,
                                        album.coverThumbnailPath,
                                        firstMediaThumb
                                    ) {
                                        value = withContext(Dispatchers.IO) {
                                            album.coverThumbnailPath?.takeIf { File(it).exists() }?.let(::File)
                                                ?: firstMediaThumb?.takeIf { File(it).exists() }?.let(::File)
                                        }
                                    }
                                    Surface(
                                        color = MaterialTheme.colorScheme.surface,
                                        shape = RoundedCornerShape(22.dp),
                                        tonalElevation = 1.dp,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(22.dp))
                                            .bounceClick(
                                                onLongClick = { albumPendingDelete = album }
                                            ) {
                                                subPage = GalleryOrgSubPage.AlbumDetail(album.id)
                                            }
                                            .testTag("gallery_album_card_${album.id}")
                                    ) {
                                        Column {
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .aspectRatio(1.15f)
                                                    .background(MaterialTheme.colorScheme.surfaceVariant),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                if (resolvedCoverFile != null) {
                                                    AsyncImage(
                                                        model = resolvedCoverFile,
                                                        contentDescription = album.name,
                                                        contentScale = ContentScale.Crop,
                                                        modifier = Modifier.fillMaxSize()
                                                    )
                                                } else {
                                                    Icon(
                                                        Icons.Default.CollectionsBookmark,
                                                        contentDescription = null,
                                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                                        modifier = Modifier.size(34.dp)
                                                    )
                                                }
                                            }
                                            Column(modifier = Modifier.padding(12.dp)) {
                                                Text(
                                                    text = album.name,
                                                    style = MaterialTheme.typography.titleMedium,
                                                    fontWeight = FontWeight.Bold,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                                Text(
                                                    text = "$count item(s)",
                                                    style = MaterialTheme.typography.bodyMedium,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                is GalleryOrgSubPage.Favorites -> {
                    if (favoriteMedia.isEmpty()) {
                        Box(
                            modifier = Modifier.fillMaxSize().padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    Icons.Default.Favorite,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(40.dp)
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Text("No favorites yet", style = MaterialTheme.typography.titleMedium)
                                Text(
                                    "Tap the heart icon while viewing any photo or video to save it here.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    } else {
                        MediaOrganizationGrid(
                            items = favoriteMedia,
                            minCellSize = metrics.galleryMinCellSize,
                            onOpenPhoto = onOpenPhoto,
                            onOpenVideo = onOpenVideo,
                            onOpenMenu = onOpenFileMenu
                        )
                    }
                }

                is GalleryOrgSubPage.Trash -> {
                    if (trashMedia.isEmpty()) {
                        Box(
                            modifier = Modifier.fillMaxSize().padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    Icons.Default.DeleteOutline,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(40.dp)
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Text("Trash is empty", style = MaterialTheme.typography.titleMedium)
                                Text(
                                    "Deleted photos & videos stay here for 30 days before permanent cleanup.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(trashMedia, key = { "trash_${it.id}" }, contentType = { "org_trash" }) { file ->
                                val thumbPath = file.activeThumbnailPath
                                val thumbFile by produceState<File?>(initialValue = null, thumbPath) {
                                    value = withContext(Dispatchers.IO) {
                                        thumbPath?.takeIf { File(it).exists() }?.let(::File)
                                    }
                                }
                                Surface(
                                    color = MaterialTheme.colorScheme.surface,
                                    shape = RoundedCornerShape(18.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(56.dp)
                                                .clip(RoundedCornerShape(12.dp))
                                                .background(MaterialTheme.colorScheme.surfaceVariant),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            if (thumbFile != null) {
                                                AsyncImage(
                                                    model = thumbFile,
                                                    contentDescription = file.name,
                                                    contentScale = ContentScale.Crop,
                                                    modifier = Modifier.fillMaxSize()
                                                )
                                            } else {
                                                Icon(Icons.Default.VideoFile, contentDescription = null)
                                            }
                                        }
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                file.name,
                                                style = MaterialTheme.typography.titleMedium,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                formatFileSize(file.sizeBytes),
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        IconButton(onClick = { onRestoreTrashItem(file) }) {
                                            Icon(Icons.Default.RestoreFromTrash, contentDescription = "Restore")
                                        }
                                        IconButton(onClick = { onPermanentDeleteItem(file) }) {
                                            Icon(Icons.Default.DeleteForever, contentDescription = "Delete forever", tint = CrimsonAlert)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                is GalleryOrgSubPage.AlbumDetail -> {
                    val album = albums.firstOrNull { it.id == current.albumId }
                    val albumItems = remember(allMedia, current.albumId) {
                        allMedia.filter { it.albumId == current.albumId }
                    }
                    if (album == null) {
                        subPage = GalleryOrgSubPage.Hub
                    } else if (albumItems.isEmpty()) {
                        Box(
                            modifier = Modifier.fillMaxSize().padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("No media in ${album.name}", style = MaterialTheme.typography.titleMedium)
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    "Add photos or videos from your Gallery.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(14.dp))
                                Button(
                                    onClick = { showAddMediaToAlbumSheet = album },
                                    shape = RoundedCornerShape(22.dp),
                                    modifier = Modifier.heightIn(min = 48.dp)
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Add Photos & Videos")
                                }
                            }
                        }
                    } else {
                        MediaOrganizationGrid(
                            items = albumItems,
                            minCellSize = metrics.galleryMinCellSize,
                            onOpenPhoto = onOpenPhoto,
                            onOpenVideo = onOpenVideo,
                            onOpenMenu = { onOpenFileMenu(it) },
                            onQuickRemoveFromAlbum = onRemoveFromAlbum
                        )
                    }
                }
            }
        }
    }

    if (showCreateAlbumDialog) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showCreateAlbumDialog = false },
            title = { Text("Create Gallery Album") },
            text = {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    placeholder = { Text("Album name (e.g. Travel, Favorites)") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp)
                )
            },
            confirmButton = {
                TextButton(
                    enabled = name.isNotBlank(),
                    onClick = {
                        onCreateAlbum(name)
                        showCreateAlbumDialog = false
                    }
                ) { Text("Create") }
            },
            dismissButton = {
                TextButton(onClick = { showCreateAlbumDialog = false }) { Text("Cancel") }
            }
        )
    }

    albumPendingDelete?.let { album ->
        AlertDialog(
            onDismissRequest = { albumPendingDelete = null },
            title = { Text("Delete \"${album.name}\"?") },
            text = { Text("Photos & videos stay safely in your Gallery; only the album grouping is removed.") },
            confirmButton = {
                TextButton(onClick = {
                    onDeleteAlbum(album)
                    albumPendingDelete = null
                    if (subPage is GalleryOrgSubPage.AlbumDetail) {
                        subPage = GalleryOrgSubPage.Hub
                    }
                }) { Text("Delete Album", color = CrimsonAlert) }
            },
            dismissButton = {
                TextButton(onClick = { albumPendingDelete = null }) { Text("Cancel") }
            }
        )
    }

    if (showEmptyTrashConfirm) {
        AlertDialog(
            onDismissRequest = { showEmptyTrashConfirm = false },
            title = { Text("Empty Gallery Trash?") },
            text = { Text("This permanently deletes all ${trashMedia.size} item(s) in Trash.") },
            confirmButton = {
                TextButton(onClick = {
                    onEmptyTrash()
                    showEmptyTrashConfirm = false
                }) { Text("Delete All", color = CrimsonAlert) }
            },
            dismissButton = {
                TextButton(onClick = { showEmptyTrashConfirm = false }) { Text("Cancel") }
            }
        )
    }

    showAddMediaToAlbumSheet?.let { album ->
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(
            onDismissRequest = { showAddMediaToAlbumSheet = null },
            sheetState = sheetState,
            containerColor = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 10.dp)
            ) {
                Text("Add Media to ${album.name}", style = MaterialTheme.typography.headlineMedium)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    "Tap any photo or video below to include it in this album.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(12.dp))
                if (allMedia.isEmpty()) {
                    Text(
                        "Upload photos or videos in Gallery first.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 20.dp)
                    )
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(3),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth().heightIn(max = 360.dp)
                    ) {
                        items(allMedia, key = { "pick_${it.id}" }, contentType = { "org_pick" }) { media ->
                            val inAlbum = media.albumId == album.id
                            val thumb = media.activeThumbnailPath
                            val thumbFile by produceState<File?>(initialValue = null, thumb) {
                                value = withContext(Dispatchers.IO) {
                                    thumb?.takeIf { File(it).exists() }?.let(::File)
                                }
                            }
                            Box(
                                modifier = Modifier
                                    .aspectRatio(1f)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant)
                                    .clickable {
                                        if (inAlbum) onRemoveFromAlbum(media) else onAssignToAlbum(media, album)
                                    }
                            ) {
                                if (thumbFile != null) {
                                    AsyncImage(
                                        model = thumbFile,
                                        contentDescription = media.name,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                } else {
                                    Icon(Icons.Default.VideoFile, contentDescription = null, modifier = Modifier.align(Alignment.Center))
                                }
                                if (inAlbum) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .background(Color.Black.copy(alpha = 0.35f))
                                    )
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.TopEnd)
                                            .padding(6.dp)
                                            .size(22.dp)
                                            .clip(CircleShape)
                                            .background(MaterialTheme.colorScheme.primary),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            Icons.Default.Check,
                                            contentDescription = "In album",
                                            tint = MaterialTheme.colorScheme.onPrimary,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(14.dp))
                OutlinedButton(
                    onClick = { showAddMediaToAlbumSheet = null },
                    shape = RoundedCornerShape(22.dp),
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) {
                    Text("Done")
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun MediaOrganizationGrid(
    items: List<FileEntity>,
    minCellSize: androidx.compose.ui.unit.Dp,
    onOpenPhoto: (FileEntity) -> Unit,
    onOpenVideo: (FileEntity) -> Unit,
    onOpenMenu: (FileEntity) -> Unit,
    onQuickRemoveFromAlbum: ((FileEntity) -> Unit)? = null
) {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(minSize = minCellSize),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 100.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(items, key = { "org_${it.id}" }, contentType = { "org_media" }) { file ->
            val thumbPath = file.activeThumbnailPath
            val thumbFile by produceState<File?>(initialValue = null, thumbPath) {
                value = withContext(Dispatchers.IO) {
                    thumbPath?.takeIf { File(it).exists() }?.let(::File)
                }
            }
            Box(
                modifier = Modifier
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(if (file.isVideo) VideoTintSurface else MaterialTheme.colorScheme.surfaceVariant)
                    .bounceClick(onLongClick = { onOpenMenu(file) }) {
                        if (file.isVideo) onOpenVideo(file) else onOpenPhoto(file)
                    }
            ) {
                if (thumbFile != null) {
                    AsyncImage(
                        model = thumbFile,
                        contentDescription = file.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.VideoFile,
                        contentDescription = file.name,
                        tint = VideoIconIndigo,
                        modifier = Modifier.size(32.dp).align(Alignment.Center)
                    )
                }

                if (file.isVideo) {
                    Surface(
                        color = Color.Black.copy(alpha = 0.68f),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.align(Alignment.TopEnd).padding(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.White, modifier = Modifier.size(11.dp))
                            Spacer(modifier = Modifier.width(2.dp))
                            Text(
                                text = if (file.durationMs > 0L) formatDuration(file.durationMs) else "Video",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }

                if (onQuickRemoveFromAlbum != null) {
                    IconButton(
                        onClick = { onQuickRemoveFromAlbum(file) },
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(4.dp)
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.55f))
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Remove from album", tint = Color.White, modifier = Modifier.size(15.dp))
                    }
                } else {
                    IconButton(
                        onClick = { onOpenMenu(file) },
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(4.dp)
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.45f))
                    ) {
                        Icon(Icons.Default.MoreVert, contentDescription = "More", tint = Color.White, modifier = Modifier.size(15.dp))
                    }
                }
            }
        }
    }
}
