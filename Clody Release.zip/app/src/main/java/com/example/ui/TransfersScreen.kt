package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.InsertDriveFile
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.data.local.DownloadRecordEntity
import com.example.data.local.UploadStatus
import com.example.data.local.UploadTaskEntity
import com.example.service.TransferBatchSummary
import com.example.service.formatSpeed
import com.example.service.isGalleryMimeType
import com.example.telegram.TelegramConnectionState
import com.example.ui.theme.ClodyMotion
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.EmeraldConnected
import com.example.ui.theme.LocalClodyMetrics
import com.example.ui.theme.bounceClick
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import java.io.File

private enum class TransferCategoryTab {
    GALLERY,
    FILES
}

/**
 * Render-isolated live Transfers screen.
 * Collects [batchSummaryFlow], [uploadTasksFlow], [downloadRecordsFlow], and [downloadSpeedsFlow]
 * directly inside this screen so high-frequency transfer progress ticks never recompose sibling tabs.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun TransfersScreen(
    connectionState: TelegramConnectionState,
    batchSummaryFlow: StateFlow<TransferBatchSummary>,
    uploadTasksFlow: StateFlow<List<UploadTaskEntity>>,
    downloadRecordsFlow: StateFlow<List<DownloadRecordEntity>>,
    downloadSpeedsFlow: StateFlow<Map<Long, Long>>,
    onOpenConnectionSheet: () -> Unit,
    onOpenUploadPicker: () -> Unit,
    onPauseUpload: (Long) -> Unit,
    onResumeUpload: (Long) -> Unit,
    onCancelUpload: (Long) -> Unit,
    onCancelDownload: (Long) -> Unit
) {
    val batchSummary by batchSummaryFlow.collectAsStateWithLifecycle()
    val uploadTasks by uploadTasksFlow.collectAsStateWithLifecycle()
    val downloadRecords by downloadRecordsFlow.collectAsStateWithLifecycle()
    val downloadSpeeds by downloadSpeedsFlow.collectAsStateWithLifecycle()
    val metrics = LocalClodyMetrics.current

    var selectedCategory by remember { mutableStateOf(TransferCategoryTab.GALLERY) }

    val categorizedUploads by produceState(
        initialValue = emptyList<UploadTaskEntity>() to emptyList<UploadTaskEntity>(),
        uploadTasks
    ) {
        value = withContext(Dispatchers.Default) {
            val gallery = uploadTasks.filter { isGalleryMimeType(it.mimeType) }
            val files = uploadTasks.filter { !isGalleryMimeType(it.mimeType) }
            gallery to files
        }
    }
    val categorizedDownloads by produceState(
        initialValue = emptyList<DownloadRecordEntity>() to emptyList<DownloadRecordEntity>(),
        downloadRecords
    ) {
        value = withContext(Dispatchers.Default) {
            val gallery = downloadRecords.filter { isGalleryMimeType(it.mimeType) }
            val files = downloadRecords.filter { !isGalleryMimeType(it.mimeType) }
            gallery to files
        }
    }

    val (galleryUploads, filesUploads) = categorizedUploads
    val (galleryDownloads, filesDownloads) = categorizedDownloads

    val visibleUploads = if (selectedCategory == TransferCategoryTab.GALLERY) galleryUploads else filesUploads
    val visibleDownloads = if (selectedCategory == TransferCategoryTab.GALLERY) galleryDownloads else filesDownloads
    val galleryCount = galleryUploads.size + galleryDownloads.size
    val filesCount = filesUploads.size + filesDownloads.size

    LazyColumn(
        contentPadding = PaddingValues(
            start = metrics.horizontalPadding,
            end = metrics.horizontalPadding,
            top = 12.dp,
            bottom = 116.dp
        ),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .testTag("transfers_screen")
    ) {
        item(key = "transfers_header", contentType = "header") {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Transfers", style = MaterialTheme.typography.displaySmall)
                    Button(
                        onClick = onOpenUploadPicker,
                        shape = RoundedCornerShape(22.dp),
                        modifier = Modifier.heightIn(min = 48.dp)
                    ) {
                        Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Upload", fontWeight = FontWeight.SemiBold)
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                TelegramConnectionStatusPill(state = connectionState, onClick = onOpenConnectionSheet)
            }
        }

        // Unified 100% Batch Progress Bar Card (visible whenever any active batch transfer runs)
        item(key = "unified_batch_card", contentType = "batch_card") {
            AnimatedVisibility(
                visible = batchSummary.isActive,
                enter = fadeIn(ClodyMotion.crispTween(200)) + expandVertically(),
                exit = fadeOut(ClodyMotion.crispTween(200)) + shrinkVertically()
            ) {
                val animatedBatchFraction by animateFloatAsState(
                    targetValue = batchSummary.overallFraction,
                    animationSpec = ClodyMotion.crispTween(160),
                    label = "unified_batch_progress"
                )
                Surface(
                    color = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    shape = RoundedCornerShape(22.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("unified_batch_progress_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Batch Progress • ${batchSummary.activeCount} active",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${formatFileSize(batchSummary.transferredBatchBytes)} / ${formatFileSize(batchSummary.totalBatchBytes)} • ${formatSpeed(batchSummary.combinedSpeedBytesPerSec)}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.82f)
                                )
                            }
                            Text(
                                text = "${batchSummary.overallPercent}%",
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        LinearProgressIndicator(
                            progress = { animatedBatchFraction },
                            color = EmeraldConnected,
                            trackColor = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.22f),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp))
                        )
                    }
                }
            }
        }

        // Gallery vs Files Segmented Switcher
        item(key = "transfer_tabs", contentType = "tabs") {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(22.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(5.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    TransferCategoryTabButton(
                        label = "Gallery ($galleryCount)",
                        selected = selectedCategory == TransferCategoryTab.GALLERY,
                        onClick = { selectedCategory = TransferCategoryTab.GALLERY },
                        modifier = Modifier.weight(1f).testTag("transfers_tab_gallery")
                    )
                    TransferCategoryTabButton(
                        label = "Files ($filesCount)",
                        selected = selectedCategory == TransferCategoryTab.FILES,
                        onClick = { selectedCategory = TransferCategoryTab.FILES },
                        modifier = Modifier.weight(1f).testTag("transfers_tab_files")
                    )
                }
            }
        }

        if (visibleUploads.isEmpty() && visibleDownloads.isEmpty()) {
            item(key = "transfers_empty_${selectedCategory.name}", contentType = "empty") {
                val categoryTitle = if (selectedCategory == TransferCategoryTab.GALLERY) "Gallery" else "Files"
                ClodyEmptyStateCard(
                    title = "No active $categoryTitle transfers",
                    subtitle = "Completed transfers reach 100% and vanish automatically so your queue stays clean.",
                    ctaLabel = "Upload",
                    onCtaClick = onOpenUploadPicker
                )
            }
        } else {
            items(visibleUploads, key = { "up_${it.id}" }, contentType = { "upload_task" }) { task ->
                val isMarkedCompleted = task.status == UploadStatus.COMPLETED.name
                val isFinalizingAt100 = !isMarkedCompleted &&
                    task.status != UploadStatus.FAILED.name &&
                    task.status != UploadStatus.PAUSED.name &&
                    task.sizeBytes > 0L &&
                    task.bytesUploaded >= task.sizeBytes
                val isDoneOrFinalizing = isMarkedCompleted || isFinalizingAt100
                val rawPct = if (isDoneOrFinalizing) 1f else if (task.sizeBytes > 0L) {
                    (task.bytesUploaded.toFloat() / task.sizeBytes.toFloat()).coerceIn(0f, 1f)
                } else 0f
                val pct by animateFloatAsState(
                    targetValue = rawPct,
                    animationSpec = ClodyMotion.crispTween(140),
                    label = "item_upload_pct_${task.id}"
                )
                val thumbPath by produceState<String?>(
                    initialValue = null,
                    task.customThumbnailPath,
                    task.extractedThumbnailPath
                ) {
                    value = withContext(Dispatchers.IO) {
                        task.customThumbnailPath?.takeIf { File(it).exists() }
                            ?: task.extractedThumbnailPath?.takeIf { File(it).exists() }
                    }
                }

                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .animateItem(
                            fadeInSpec = ClodyMotion.crispTween(180),
                            fadeOutSpec = ClodyMotion.crispTween(220)
                        )
                        .testTag("transfer_upload_item_${task.id}")
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TransferItemThumbnail(
                                thumbnailPath = thumbPath,
                                isVideo = task.mimeType.startsWith("video/"),
                                isUpload = true
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = task.fileName,
                                    style = MaterialTheme.typography.titleMedium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                val statusLine = when {
                                    isMarkedCompleted ->
                                        "100% • ${formatFileSize(task.sizeBytes)} / ${formatFileSize(task.sizeBytes)} • Done"
                                    isFinalizingAt100 ->
                                        "100% • ${formatFileSize(task.sizeBytes)} / ${formatFileSize(task.sizeBytes)} • Finalizing..."
                                    task.status == UploadStatus.UPLOADING.name ->
                                        "${(pct * 100).toInt()}% • ${formatFileSize(task.bytesUploaded)} / ${formatFileSize(task.sizeBytes)} • ${formatSpeed(task.speedBytesPerSec)}"
                                    task.status == UploadStatus.FAILED.name -> task.errorMessage ?: "Upload failed"
                                    task.status == UploadStatus.PAUSED.name -> {
                                        val reason = task.errorMessage?.takeIf { it.isNotBlank() } ?: "Paused"
                                        "$reason • ${formatFileSize(task.bytesUploaded)} / ${formatFileSize(task.sizeBytes)}"
                                    }
                                    else -> "Queued • ${formatFileSize(task.sizeBytes)}"
                                }
                                Text(
                                    text = statusLine,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = when {
                                        isDoneOrFinalizing -> EmeraldConnected
                                        task.status == UploadStatus.FAILED.name -> CrimsonAlert
                                        else -> MaterialTheme.colorScheme.onSurfaceVariant
                                    },
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            if (isDoneOrFinalizing) {
                                Icon(
                                    Icons.Default.CheckCircle,
                                    contentDescription = if (isMarkedCompleted) "Completed" else "Finalizing",
                                    tint = EmeraldConnected,
                                    modifier = Modifier.padding(end = 8.dp).size(24.dp)
                                )
                            } else {
                                if (task.status == UploadStatus.UPLOADING.name || task.status == UploadStatus.QUEUED.name) {
                                    IconButton(
                                        onClick = { onPauseUpload(task.id) },
                                        modifier = Modifier.size(48.dp)
                                    ) {
                                        Icon(Icons.Default.Pause, contentDescription = "Pause upload")
                                    }
                                } else if (task.status == UploadStatus.PAUSED.name || task.status == UploadStatus.FAILED.name) {
                                    IconButton(
                                        onClick = { onResumeUpload(task.id) },
                                        modifier = Modifier.size(48.dp)
                                    ) {
                                        Icon(Icons.Default.PlayArrow, contentDescription = "Resume upload")
                                    }
                                }
                                IconButton(
                                    onClick = { onCancelUpload(task.id) },
                                    modifier = Modifier.size(48.dp)
                                ) {
                                    Icon(Icons.Default.Cancel, contentDescription = "Cancel upload", tint = CrimsonAlert)
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = { pct },
                            color = if (isDoneOrFinalizing) EmeraldConnected else MaterialTheme.colorScheme.primary,
                            trackColor = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp))
                        )
                    }
                }
            }

            items(visibleDownloads, key = { "dl_${it.id}" }, contentType = { "download_task" }) { dl ->
                val isCompleted = dl.status == "COMPLETED"
                val rawPct = if (isCompleted) 1f else if (dl.sizeBytes > 0L) {
                    (dl.progressBytes.toFloat() / dl.sizeBytes.toFloat()).coerceIn(0f, 1f)
                } else 0f
                val pct by animateFloatAsState(
                    targetValue = rawPct,
                    animationSpec = ClodyMotion.crispTween(140),
                    label = "item_dl_pct_${dl.id}"
                )
                val speed = downloadSpeeds[dl.id] ?: 0L

                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .animateItem(
                            fadeInSpec = ClodyMotion.crispTween(180),
                            fadeOutSpec = ClodyMotion.crispTween(220)
                        )
                        .testTag("transfer_download_item_${dl.id}")
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TransferItemThumbnail(
                                thumbnailPath = null,
                                isVideo = dl.mimeType.startsWith("video/"),
                                isUpload = false
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = dl.fileName,
                                    style = MaterialTheme.typography.titleMedium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                val statusLine = if (isCompleted) {
                                    "100% • ${formatFileSize(dl.sizeBytes)} / ${formatFileSize(dl.sizeBytes)} • Saved"
                                } else {
                                    "${(pct * 100).toInt()}% • ${formatFileSize(dl.progressBytes)} / ${formatFileSize(dl.sizeBytes)} • ${formatSpeed(speed)}"
                                }
                                Text(
                                    text = statusLine,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = if (isCompleted) EmeraldConnected else MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            if (isCompleted) {
                                Icon(
                                    Icons.Default.CheckCircle,
                                    contentDescription = "Download complete",
                                    tint = EmeraldConnected,
                                    modifier = Modifier.padding(end = 8.dp).size(24.dp)
                                )
                            } else {
                                IconButton(
                                    onClick = { onCancelDownload(dl.id) },
                                    modifier = Modifier.size(48.dp)
                                ) {
                                    Icon(Icons.Default.Cancel, contentDescription = "Cancel download", tint = CrimsonAlert)
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = { pct },
                            color = if (isCompleted) EmeraldConnected else MaterialTheme.colorScheme.primary,
                            trackColor = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp))
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TransferCategoryTabButton(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = if (selected) MaterialTheme.colorScheme.primary else Color.Transparent,
        contentColor = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
        shape = RoundedCornerShape(18.dp),
        modifier = modifier
            .heightIn(min = 48.dp)
            .clip(RoundedCornerShape(18.dp))
            .bounceClick(onClick = onClick)
    ) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(vertical = 12.dp)) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun TransferItemThumbnail(
    thumbnailPath: String?,
    isVideo: Boolean,
    isUpload: Boolean
) {
    val thumbFile by produceState<File?>(initialValue = null, thumbnailPath) {
        value = if (thumbnailPath.isNullOrBlank()) null else {
            withContext(Dispatchers.IO) { File(thumbnailPath).takeIf(File::exists) }
        }
    }
    Box(
        modifier = Modifier
            .size(48.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center
    ) {
        if (thumbFile != null) {
            AsyncImage(
                model = thumbFile,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(3.dp)
                    .size(18.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.72f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isUpload) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(11.dp)
                )
            }
        } else {
            Icon(
                imageVector = when {
                    isVideo -> Icons.Default.VideoFile
                    isUpload -> Icons.Default.ArrowUpward
                    else -> Icons.AutoMirrored.Filled.InsertDriveFile
                },
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.size(22.dp)
            )
        }
    }
}
