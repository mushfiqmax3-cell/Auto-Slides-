package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.example.ClodyApplication
import com.example.MainActivity
import com.example.data.local.FileEntity
import com.example.data.local.UploadStatus
import com.example.data.local.UploadTaskEntity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

class ClodyUploadService : Service() {

    companion object {
        const val CHANNEL_ID = "clody_transfers_channel"
        const val NOTIFICATION_ID = 4102
        const val ACTION_START_QUEUE = "com.example.action.START_QUEUE"
        const val ACTION_PAUSE_TASK = "com.example.action.PAUSE_TASK"
        const val ACTION_CANCEL_TASK = "com.example.action.CANCEL_TASK"
        const val ACTION_REFRESH_NETWORK_POLICY = "com.example.action.REFRESH_NETWORK_POLICY"
        const val EXTRA_TASK_ID = "extra_task_id"

        private const val MAX_PARALLEL_UPLOADS = 3

        @Volatile
        var isRunning: Boolean = false
            private set

        fun start(context: Context) {
            val intent = Intent(context, ClodyUploadService::class.java).apply {
                action = ACTION_START_QUEUE
            }
            runCatching {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            }
        }

        fun notifyNetworkPolicyChanged(context: Context) {
            if (!isRunning) return
            val intent = Intent(context, ClodyUploadService::class.java).apply {
                action = ACTION_REFRESH_NETWORK_POLICY
            }
            runCatching { context.startService(intent) }
        }
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var dispatcherJob: Job? = null
    private val activeTaskJobs = ConcurrentHashMap<Long, Job>()
    private val queueClaimMutex = Mutex()
    private var wakeLock: PowerManager.WakeLock? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null

    @Volatile
    private var isUnmeteredWifiAvailable: Boolean = false

    @Volatile
    private var isStoppingForTaskRemoved: Boolean = false

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        createNotificationChannel()
        registerLiveWifiMonitor()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val app = application as ClodyApplication
        val dao = app.database.clodyDao()

        when (intent?.action) {
            ACTION_PAUSE_TASK -> {
                val id = intent.getLongExtra(EXTRA_TASK_ID, -1L)
                if (id > 0) {
                    activeTaskJobs.remove(id)?.cancel()
                    serviceScope.launch {
                        val existing = dao.getUploadTaskById(id)
                        dao.pauseUploadByUser(id)
                        if (existing != null && existing.tdFileId > 0) {
                            app.telegramClientManager.cancelUploadFile(existing.tdFileId)
                        }
                    }
                }
            }
            ACTION_CANCEL_TASK -> {
                val id = intent.getLongExtra(EXTRA_TASK_ID, -1L)
                if (id > 0) {
                    activeTaskJobs.remove(id)?.cancel()
                    serviceScope.launch {
                        val existing = dao.getUploadTaskById(id)
                        if (existing != null) {
                            if (existing.tdFileId > 0) {
                                app.telegramClientManager.cancelUploadFile(existing.tdFileId)
                            }
                            existing.stagedFilePath?.let { path ->
                                runCatching { File(path).delete() }
                            }
                        }
                        dao.deleteUploadTaskById(id)
                        val remaining = dao.countActiveUploads()
                        TransferBatchTracker.reconcileActiveQueue(
                            remainingInDb = remaining,
                            cancelledTaskId = id,
                            uniqueKey = existing?.localUriString.orEmpty()
                        )
                    }
                }
            }
            ACTION_REFRESH_NETWORK_POLICY -> {
                serviceScope.launch {
                    evaluateNetworkPolicy()
                }
            }
            else -> {
                isStoppingForTaskRemoved = false
                startForegroundCompat(buildNotification("Preparing Clody Cloud transfers...", 0, 100, true))
                ensureQueueDispatcherRunning()
            }
        }
        return START_NOT_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        isStoppingForTaskRemoved = true
        dispatcherJob?.cancel()
        val runningJobs = activeTaskJobs.values.toList()
        activeTaskJobs.clear()
        runningJobs.forEach { it.cancel() }
        ClodyUploadWorker.cancelOneTimeWork(applicationContext)

        val app = applicationContext as? ClodyApplication
        if (app != null) {
            runCatching {
                runBlocking(Dispatchers.IO) {
                    withTimeoutOrNull(850L) {
                        val dao = app.database.clodyDao()
                        val resumables = runCatching { dao.getResumableOrActiveUploads() }.getOrDefault(emptyList())
                        dao.markActiveUploadsSystemPaused("Paused on close")
                        for (t in resumables) {
                            if (t.tdFileId > 0) {
                                app.telegramClientManager.cancelUploadFile(t.tdFileId)
                            }
                        }
                        val settings = runCatching { app.settingsRepository.settingsFlow.first() }.getOrNull()
                        if (settings != null && (settings.zeroStorageMode || settings.autoDeleteCacheOnExit)) {
                            app.telegramClientManager.clearAllTdMediaTempFiles()
                            com.example.media.ClodyStreamCache.clearAllStreamCache(
                                applicationContext,
                                includeSharedCache = true
                            )
                            dao.clearAllLocalCachePaths()
                        }
                    }
                }
            }
        }

        TransferBatchTracker.clearBanner()
        releaseWakeLock()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        super.onTaskRemoved(rootIntent)
    }

    private fun registerLiveWifiMonitor() {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return
        isUnmeteredWifiAvailable = checkCurrentWifiConnected(cm)

        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                handleWifiStateChange(checkCurrentWifiConnected(cm))
            }

            override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
                handleWifiStateChange(checkCurrentWifiConnected(cm))
            }

            override fun onLost(network: Network) {
                handleWifiStateChange(checkCurrentWifiConnected(cm))
            }
        }
        networkCallback = callback
        runCatching {
            val req = NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .build()
            cm.registerNetworkCallback(req, callback)
        }
    }

    private fun checkCurrentWifiConnected(cm: ConnectivityManager): Boolean {
        return runCatching {
            val net = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(net) ?: return false
            val hasInternet = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            val hasWifiOrEthernet = caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) ||
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
            hasInternet && hasWifiOrEthernet
        }.getOrDefault(false)
    }

    private fun handleWifiStateChange(wifiConnected: Boolean) {
        isUnmeteredWifiAvailable = wifiConnected
        if (isStoppingForTaskRemoved) return
        serviceScope.launch {
            evaluateNetworkPolicy()
        }
    }

    private suspend fun evaluateNetworkPolicy() {
        if (isStoppingForTaskRemoved) return
        val app = application as ClodyApplication
        val dao = app.database.clodyDao()
        val settings = app.settingsRepository.settingsFlow.first()
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val wifiConnected = if (cm != null) checkCurrentWifiConnected(cm) else isUnmeteredWifiAvailable
        isUnmeteredWifiAvailable = wifiConnected

        val enforceWifiOnly = settings.uploadWifiOnly
        if (!wifiConnected && enforceWifiOnly) {
            // Immediately pause in-flight uploads so 0 bytes of mobile data are consumed
            TransferBatchTracker.setPausedForWifi(true)
            val jobs = activeTaskJobs.values.toList()
            activeTaskJobs.clear()
            jobs.forEach { it.cancel() }

            val activeTasks = dao.getResumableOrActiveUploads()
            dao.markActiveUploadsSystemPaused("Waiting for Wi-Fi")
            for (t in activeTasks) {
                if (t.tdFileId > 0) {
                    app.telegramClientManager.cancelUploadFile(t.tdFileId)
                }
            }
            ClodyUploadWorker.enqueue(
                context = applicationContext,
                wifiOnly = true,
                onlyWhileCharging = settings.autoBackupOnlyWhileCharging,
                replaceExisting = true
            )
            updateNotification("Paused • Waiting for Wi-Fi to resume", 0, 100, true)
        } else {
            TransferBatchTracker.setPausedForWifi(false)
            val resumedCount = dao.resumeSystemPausedUploads()
            if (resumedCount > 0 || dao.countActiveUploads() > 0) {
                ensureQueueDispatcherRunning()
            }
        }
    }

    private fun ensureQueueDispatcherRunning() {
        if (dispatcherJob?.isActive == true || isStoppingForTaskRemoved) return
        acquireWakeLock()
        dispatcherJob = serviceScope.launch {
            val app = application as ClodyApplication
            val dao = app.database.clodyDao()

            try {
                while (isActive && !isStoppingForTaskRemoved) {
                    val settings = app.settingsRepository.settingsFlow.first()
                    val requireWifi = settings.uploadWifiOnly
                    val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
                    if (cm != null) {
                        isUnmeteredWifiAvailable = checkCurrentWifiConnected(cm)
                    }

                    if (requireWifi && !isUnmeteredWifiAvailable) {
                        TransferBatchTracker.setPausedForWifi(true)
                        if (activeTaskJobs.isNotEmpty()) {
                            val jobs = activeTaskJobs.values.toList()
                            activeTaskJobs.clear()
                            jobs.forEach { it.cancel() }
                            dao.markActiveUploadsSystemPaused("Waiting for Wi-Fi")
                        }
                        updateNotification("Paused • Waiting for Wi-Fi connection...", 0, 100, true)
                        delay(2000L)
                        continue
                    }

                    TransferBatchTracker.setPausedForWifi(false)
                    // Resume any system-paused tasks once eligible network is back
                    dao.resumeSystemPausedUploads()

                    // Clean up finished jobs
                    activeTaskJobs.entries.removeIf { !it.value.isActive }

                    val availableSlots = (MAX_PARALLEL_UPLOADS - activeTaskJobs.size).coerceAtLeast(0)
                    if (availableSlots > 0) {
                        val claimedTasks = queueClaimMutex.withLock {
                            val candidates = dao.getPendingQueuedUploads(limit = availableSlots)
                            candidates.forEach { t ->
                                dao.updateUploadStatus(t.id, UploadStatus.UPLOADING.name, null)
                            }
                            candidates
                        }

                        for (task in claimedTasks) {
                            val job = serviceScope.launch {
                                processSingleUploadTask(task)
                            }
                            activeTaskJobs[task.id] = job
                        }
                    }

                    if (activeTaskJobs.isEmpty()) {
                        val remaining = dao.countActiveUploads()
                        val resumable = dao.getResumableOrActiveUploads().size
                        if (remaining == 0 && resumable == 0) {
                            break
                        }
                    }

                    delay(250L)
                }
            } finally {
                releaseWakeLock()
                if (!isStoppingForTaskRemoved) {
                    delay(1200L)
                }
                TransferBatchTracker.clearBanner()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
    }

    private suspend fun processSingleUploadTask(task: UploadTaskEntity) {
        val app = application as ClodyApplication
        val dao = app.database.clodyDao()
        val telegram = app.telegramClientManager
        val currentTaskSnapshot = dao.getUploadTaskById(task.id) ?: return

        val pendingCount = dao.countActiveUploads().coerceAtLeast(1)
        val taskUniqueKey = currentTaskSnapshot.localUriString
        TransferBatchTracker.onFileStarted(
            fileName = currentTaskSnapshot.fileName,
            totalBytes = currentTaskSnapshot.sizeBytes,
            pendingCountInDb = pendingCount,
            taskId = currentTaskSnapshot.id,
            uniqueKey = taskUniqueKey
        )
        updateNotification(
            "Uploading ${currentTaskSnapshot.fileName}",
            TransferBatchTracker.summary.value.overallPercent,
            100,
            false
        )

        val uri = Uri.parse(currentTaskSnapshot.localUriString)

        // 1. Compute SHA-256 on Dispatchers.IO BEFORE uploading for Instant Cloud Deduplication
        val sha256 = computeUriSha256(uri)
        if (sha256.isNotBlank()) {
            val existingMatch = dao.findActiveFileBySha256(sha256)
            if (existingMatch != null && existingMatch.telegramDocumentId != 0L) {
                // Instant Cloud Match! Skip re-uploading over the network and link metadata directly.
                val ext = currentTaskSnapshot.fileName.substringAfterLast('.', "").lowercase()
                val chosenThumb = currentTaskSnapshot.customThumbnailPath
                    ?: currentTaskSnapshot.extractedThumbnailPath
                    ?: existingMatch.thumbnailPath
                val linkedEntity = FileEntity(
                    name = currentTaskSnapshot.fileName,
                    extension = ext,
                    sizeBytes = if (currentTaskSnapshot.sizeBytes > 0L) currentTaskSnapshot.sizeBytes else existingMatch.sizeBytes,
                    mimeType = currentTaskSnapshot.mimeType,
                    folderId = currentTaskSnapshot.folderId,
                    folderPath = currentTaskSnapshot.folderPath,
                    telegramMessageId = existingMatch.telegramMessageId,
                    telegramDocumentId = existingMatch.telegramDocumentId,
                    telegramAccessHash = existingMatch.telegramAccessHash,
                    telegramFileReferenceHex = existingMatch.telegramFileReferenceHex,
                    telegramDcId = existingMatch.telegramDcId,
                    durationMs = if (currentTaskSnapshot.durationMs > 0L) currentTaskSnapshot.durationMs else existingMatch.durationMs,
                    thumbnailPath = chosenThumb,
                    customThumbnailPath = currentTaskSnapshot.customThumbnailPath ?: existingMatch.customThumbnailPath,
                    miniThumbnailBase64 = existingMatch.miniThumbnailBase64,
                    localCachePath = existingMatch.localCachePath,
                    localSourceUri = currentTaskSnapshot.localUriString,
                    sha256 = sha256
                )
                dao.insertFile(linkedEntity)
                dao.deleteUploadTaskById(currentTaskSnapshot.id)
                currentTaskSnapshot.stagedFilePath?.let { p -> runCatching { File(p).delete() } }

                TransferBatchTracker.notifyInstantCloudMatch(currentTaskSnapshot.fileName)
                val remaining = dao.countActiveUploads()
                TransferBatchTracker.onFileCompleted(
                    remainingInDb = remaining,
                    taskId = currentTaskSnapshot.id,
                    uniqueKey = taskUniqueKey
                )
                updateNotification("Instant Cloud Match ✓: ${currentTaskSnapshot.fileName}", 100, 100, false)

                runCatching { withTimeoutOrNull(8_000L) { telegram.pushCloudIndexSnapshot() } }
                return
            }
        }

        // 2. Get or create deterministic staging file in filesDir/pending_uploads for resumable TDLib uploads
        val stagedFile = getOrCreateStagedUploadFile(currentTaskSnapshot, uri)
        if (stagedFile == null || !stagedFile.exists()) {
            dao.updateUploadStatus(currentTaskSnapshot.id, UploadStatus.FAILED.name, "Cannot read source file")
            val remaining = dao.countActiveUploads()
            TransferBatchTracker.onFileCompleted(
                remainingInDb = remaining,
                taskId = currentTaskSnapshot.id,
                uniqueKey = taskUniqueKey
            )
            return
        }
        if (currentTaskSnapshot.stagedFilePath != stagedFile.absolutePath) {
            dao.updateUploadStagedPath(currentTaskSnapshot.id, stagedFile.absolutePath)
        }

        try {
            val chosenThumbPath = currentTaskSnapshot.customThumbnailPath ?: currentTaskSnapshot.extractedThumbnailPath
            val thumbFile = chosenThumbPath?.let { File(it) }?.takeIf { it.exists() }
            val isVideo = currentTaskSnapshot.mimeType.startsWith("video/")

            val uploadResult = telegram.uploadFile(
                file = stagedFile,
                fileName = currentTaskSnapshot.fileName,
                mimeType = currentTaskSnapshot.mimeType,
                thumbnailFile = thumbFile,
                isVideo = isVideo,
                durationSec = currentTaskSnapshot.durationMs / 1000.0,
                resumeTdFileId = currentTaskSnapshot.tdFileId,
                initialBytesUploaded = currentTaskSnapshot.bytesUploaded,
                onTdFileIdAssigned = { assignedTdId ->
                    dao.updateUploadTdFileId(currentTaskSnapshot.id, assignedTdId)
                }
            ) { bytesSent, speed ->
                if (isStoppingForTaskRemoved) {
                    throw CancellationException("Upload stopped on task removal")
                }
                val latest = dao.getUploadTaskById(currentTaskSnapshot.id)
                if (latest == null || latest.status == UploadStatus.PAUSED.name || latest.status == UploadStatus.CANCELLED.name) {
                    throw CancellationException("Upload paused or cancelled")
                }
                val wifiRequired = runCatching { app.settingsRepository.settingsFlow.first().uploadWifiOnly }.getOrDefault(false)
                if (wifiRequired && !isUnmeteredWifiAvailable) {
                    throw CancellationException("Paused for Wi-Fi")
                }
                val monotonicSent = maxOf(bytesSent, latest.bytesUploaded)
                dao.updateUploadProgress(currentTaskSnapshot.id, monotonicSent, speed)
                TransferBatchTracker.onFileProgress(
                    fileName = currentTaskSnapshot.fileName,
                    bytesSent = monotonicSent,
                    totalBytes = maxOf(1L, currentTaskSnapshot.sizeBytes),
                    speedBytesPerSec = speed,
                    taskId = currentTaskSnapshot.id,
                    uniqueKey = taskUniqueKey
                )
                val summary = TransferBatchTracker.summary.value
                val speedStr = formatSpeed(summary.speedBytesPerSec)
                val label = if (summary.activeParallelCount > 1) {
                    "Uploading ${summary.activeParallelCount} files (${summary.completedCount + 1}/${summary.totalCount}) • $speedStr"
                } else {
                    "Uploading (${summary.completedCount + 1}/${summary.totalCount}): ${currentTaskSnapshot.fileName} ($speedStr)"
                }
                updateNotification(label, summary.overallPercent, 100, false)
            }

            uploadResult.onSuccess { uploaded ->
                val ext = currentTaskSnapshot.fileName.substringAfterLast('.', "").lowercase()
                val refHex = uploaded.fileReference.joinToString("") { "%02x".format(it) }
                val persistentThumbPath = currentTaskSnapshot.extractedThumbnailPath
                    ?.takeIf { File(it).let { f -> f.exists() && f.length() > 0L } }
                val fileEntity = FileEntity(
                    name = currentTaskSnapshot.fileName,
                    extension = ext,
                    sizeBytes = uploaded.sizeBytes,
                    mimeType = currentTaskSnapshot.mimeType,
                    folderId = currentTaskSnapshot.folderId,
                    folderPath = currentTaskSnapshot.folderPath,
                    telegramMessageId = uploaded.messageId,
                    telegramDocumentId = uploaded.documentId,
                    telegramAccessHash = uploaded.accessHash,
                    telegramFileReferenceHex = refHex,
                    telegramDcId = uploaded.dcId,
                    durationMs = currentTaskSnapshot.durationMs,
                    thumbnailPath = persistentThumbPath,
                    customThumbnailPath = currentTaskSnapshot.customThumbnailPath,
                    miniThumbnailBase64 = uploaded.miniThumbnailBase64,
                    localCachePath = null,
                    localSourceUri = currentTaskSnapshot.localUriString,
                    sha256 = sha256
                )
                dao.insertFile(fileEntity)
                dao.deleteUploadTaskById(currentTaskSnapshot.id)
                runCatching { stagedFile.delete() }

                val remaining = dao.countActiveUploads()
                TransferBatchTracker.onFileCompleted(
                    remainingInDb = remaining,
                    taskId = currentTaskSnapshot.id,
                    uniqueKey = taskUniqueKey
                )
                updateNotification("Uploaded ${currentTaskSnapshot.fileName}", 100, 100, false)

                runCatching { withTimeoutOrNull(8_000L) { telegram.pushCloudIndexSnapshot() } }
            }.onFailure { err ->
                if (err !is CancellationException) {
                    runCatching { stagedFile.delete() }
                    dao.updateUploadStatus(currentTaskSnapshot.id, UploadStatus.FAILED.name, err.message ?: "Upload failed")
                    val remaining = dao.countActiveUploads()
                    TransferBatchTracker.onFileCompleted(
                        remainingInDb = remaining,
                        taskId = currentTaskSnapshot.id,
                        uniqueKey = taskUniqueKey
                    )
                }
            }
        } catch (ce: CancellationException) {
            // Preserve stagedFile on disk so reopen / Wi-Fi reconnect resumes at exact byte offset!
            throw ce
        }
    }

    private fun getOrCreateStagedUploadFile(task: UploadTaskEntity, uri: Uri): File? {
        return try {
            val existingPath = task.stagedFilePath
            if (!existingPath.isNullOrBlank()) {
                val existing = File(existingPath)
                if (existing.exists() && existing.length() > 0L && (task.sizeBytes <= 0L || existing.length() == task.sizeBytes)) {
                    return existing
                }
            }
            val stagingDir = File(filesDir, "pending_uploads").apply { mkdirs() }
            val safeName = task.fileName.replace(Regex("[^a-zA-Z0-9._-]"), "_")
            val dest = File(stagingDir, "upload_${task.id}_$safeName")
            if (dest.exists() && dest.length() > 0L && (task.sizeBytes <= 0L || dest.length() == task.sizeBytes)) {
                return dest
            }
            if (uri.scheme == "file") {
                val direct = File(uri.path ?: return null)
                if (direct.exists()) {
                    direct.copyTo(dest, overwrite = true)
                    return dest
                }
            }
            contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(dest).use { fos ->
                    input.copyTo(fos)
                }
            } ?: return null
            dest
        } catch (_: Exception) {
            null
        }
    }

    private fun computeUriSha256(uri: Uri): String {
        return runCatching {
            val md = MessageDigest.getInstance("SHA-256")
            if (uri.scheme == "file") {
                val direct = File(uri.path ?: return "")
                if (!direct.exists()) return ""
                direct.inputStream().use { fis ->
                    val buf = ByteArray(32 * 1024)
                    while (true) {
                        val r = fis.read(buf)
                        if (r <= 0) break
                        md.update(buf, 0, r)
                    }
                }
            } else {
                contentResolver.openInputStream(uri)?.use { input ->
                    val buf = ByteArray(32 * 1024)
                    while (true) {
                        val r = input.read(buf)
                        if (r <= 0) break
                        md.update(buf, 0, r)
                    }
                } ?: return ""
            }
            md.digest().joinToString("") { "%02x".format(it) }
        }.getOrDefault("")
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Clody::UploadWakeLock").apply {
            acquire(30 * 60 * 1000L)
        }
    }

    private fun releaseWakeLock() {
        runCatching {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Clody Cloud Transfers",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Background Telegram Cloud file uploads and downloads"
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(
        title: String,
        progress: Int,
        max: Int,
        indeterminate: Boolean
    ): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("Clody Cloud")
            .setContentText(title)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setProgress(max, progress, indeterminate)
            .setContentIntent(pendingIntent)
            .build()
    }

    private fun updateNotification(title: String, progress: Int, max: Int, indeterminate: Boolean) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIFICATION_ID, buildNotification(title, progress, max, indeterminate))
    }

    private fun startForegroundCompat(notification: Notification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    override fun onDestroy() {
        isRunning = false
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        networkCallback?.let { cb ->
            runCatching { cm?.unregisterNetworkCallback(cb) }
        }
        networkCallback = null
        releaseWakeLock()
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
