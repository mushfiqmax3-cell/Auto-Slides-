package com.example.service

import android.content.Context
import android.provider.MediaStore
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.ClodyApplication
import com.example.data.local.UploadStatus
import com.example.data.local.UploadTaskEntity
import com.example.files.DeviceFileManager
import kotlinx.coroutines.flow.first
import java.util.concurrent.TimeUnit

class ClodyUploadWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        val app = applicationContext as? ClodyApplication ?: return Result.success()
        val dao = app.database.clodyDao()
        val settings = app.settingsRepository.settingsFlow.first()

        // 1. If Smart Wi-Fi Auto-Backup is enabled, scan MediaStore for new unbacked-up photos & videos
        if (settings.autoBackupNewMedia && app.secureStorage.isLoggedIn()) {
            val fileManager = DeviceFileManager(applicationContext)
            val activeFiles = dao.getAllActiveFilesOnce()
            val existingSet = activeFiles.map { it.name to it.sizeBytes }.toSet()
            val candidates = fileManager.scanUnbackedUpLocalMedia(
                existingNamesAndSizes = existingSet,
                dismissedIds = settings.dismissedBackupIds,
                limit = 25
            )
            if (candidates.isNotEmpty()) {
                for (cand in candidates) {
                    val task = UploadTaskEntity(
                        fileName = cand.displayName,
                        localUriString = cand.uri.toString(),
                        mimeType = cand.mimeType,
                        sizeBytes = cand.sizeBytes,
                        durationMs = cand.durationMs,
                        folderId = null,
                        folderPath = "Gallery",
                        extractedThumbnailPath = cand.thumbnailPath,
                        customThumbnailPath = null,
                        status = UploadStatus.QUEUED.name
                    )
                    dao.insertUploadTask(task)
                }
                TransferBatchTracker.onBatchEnqueued(
                    addedCount = candidates.size,
                    firstFileName = candidates.first().displayName
                )
            }
        }

        // 2. Resume system-paused / interrupted uploads only if Upload Network policy allows current network
        val isWifi = isWifiOrUnmeteredConnected(applicationContext)
        if (settings.uploadWifiOnly && !isWifi) {
            // Ensure background worker waits for unmetered Wi-Fi without starting cellular upload
            dao.markActiveUploadsSystemPaused("Waiting for Wi-Fi")
            enqueue(applicationContext, wifiOnly = true, onlyWhileCharging = settings.autoBackupOnlyWhileCharging, replaceExisting = true)
            return Result.success()
        }

        dao.resumeSystemPausedUploads()
        val pending = dao.getNextPendingUpload()
        if (pending != null) {
            ClodyUploadService.start(applicationContext)
        }

        // 3. Re-arm content URI trigger for continuous camera roll auto-backup on Wi-Fi
        if (settings.autoBackupNewMedia) {
            scheduleMediaContentTrigger(
                context = applicationContext,
                onlyWhileCharging = settings.autoBackupOnlyWhileCharging
            )
        }

        return Result.success()
    }

    private fun isWifiOrUnmeteredConnected(context: Context): Boolean {
        return runCatching {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? android.net.ConnectivityManager
                ?: return false
            val net = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(net) ?: return false
            val hasInternet = caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET)
            val hasWifiOrEthernet = caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI) ||
                caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_ETHERNET) ||
                caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
            hasInternet && hasWifiOrEthernet
        }.getOrDefault(false)
    }

    companion object {
        private const val WORK_NAME_ONE_TIME = "clody_upload_worker"
        private const val WORK_NAME_MEDIA_TRIGGER = "clody_wifi_media_trigger_worker"
        private const val WORK_NAME_PERIODIC_BACKUP = "clody_wifi_periodic_backup_worker"

        fun enqueue(
            context: Context,
            wifiOnly: Boolean,
            onlyWhileCharging: Boolean = false,
            replaceExisting: Boolean = false
        ) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(
                    if (wifiOnly) NetworkType.UNMETERED else NetworkType.CONNECTED
                )
                .setRequiresCharging(onlyWhileCharging)
                .build()

            val request = OneTimeWorkRequestBuilder<ClodyUploadWorker>()
                .setConstraints(constraints)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 15, TimeUnit.SECONDS)
                .build()

            WorkManager.getInstance(context).enqueueUniqueWork(
                WORK_NAME_ONE_TIME,
                if (replaceExisting) ExistingWorkPolicy.REPLACE else ExistingWorkPolicy.KEEP,
                request
            )
        }

        fun cancelOneTimeWork(context: Context) {
            runCatching {
                WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME_ONE_TIME)
            }
        }

        fun configureAutoBackupSchedule(
            context: Context,
            enabled: Boolean,
            onlyWhileCharging: Boolean
        ) {
            val wm = WorkManager.getInstance(context)
            if (!enabled) {
                wm.cancelUniqueWork(WORK_NAME_MEDIA_TRIGGER)
                wm.cancelUniqueWork(WORK_NAME_PERIODIC_BACKUP)
                return
            }

            // Schedule Periodic Unmetered Wi-Fi Auto-Backup
            val periodicConstraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.UNMETERED)
                .setRequiresCharging(onlyWhileCharging)
                .build()

            val periodicRequest = PeriodicWorkRequestBuilder<ClodyUploadWorker>(
                6, TimeUnit.HOURS
            )
                .setConstraints(periodicConstraints)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
                .build()

            wm.enqueueUniquePeriodicWork(
                WORK_NAME_PERIODIC_BACKUP,
                ExistingPeriodicWorkPolicy.UPDATE,
                periodicRequest
            )

            // Schedule immediate MediaStore ContentUriTriggers on Unmetered Wi-Fi
            scheduleMediaContentTrigger(context, onlyWhileCharging)
        }

        private fun scheduleMediaContentTrigger(
            context: Context,
            onlyWhileCharging: Boolean
        ) {
            val triggerConstraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.UNMETERED)
                .setRequiresCharging(onlyWhileCharging)
                .addContentUriTrigger(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, true)
                .addContentUriTrigger(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true)
                .setTriggerContentUpdateDelay(10, TimeUnit.SECONDS)
                .setTriggerContentMaxDelay(60, TimeUnit.SECONDS)
                .build()

            val triggerRequest = OneTimeWorkRequestBuilder<ClodyUploadWorker>()
                .setConstraints(triggerConstraints)
                .build()

            WorkManager.getInstance(context).enqueueUniqueWork(
                WORK_NAME_MEDIA_TRIGGER,
                ExistingWorkPolicy.REPLACE,
                triggerRequest
            )
        }
    }
}
