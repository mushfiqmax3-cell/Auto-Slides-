package com.example.service

import com.example.data.local.ClodyDao
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

typealias TransferBatchSummary = UploadBatchSummary

data class UploadBatchSummary(
    val totalCount: Int = 0,
    val completedCount: Int = 0,
    val currentFileName: String = "",
    val currentFileBytesSent: Long = 0L,
    val currentFileTotalBytes: Long = 0L,
    val speedBytesPerSec: Long = 0L,
    val activeParallelCount: Int = 0,
    val galleryActiveCount: Int = 0,
    val filesActiveCount: Int = 0,
    val isActive: Boolean = false,
    val isPausedForWifi: Boolean = false,
    val justCompleted: Boolean = false
) {
    val activeCount: Int
        get() = if (galleryActiveCount + filesActiveCount > 0) {
            galleryActiveCount + filesActiveCount
        } else if (isActive) {
            maxOf(activeParallelCount, totalCount - completedCount, 1)
        } else 0

    val totalBatchBytes: Long
        get() = currentFileTotalBytes

    val transferredBatchBytes: Long
        get() = currentFileBytesSent

    val combinedSpeedBytesPerSec: Long
        get() = speedBytesPerSec

    val overallFraction: Float
        get() {
            if (currentFileTotalBytes > 0L && (galleryActiveCount + filesActiveCount > 0 || totalCount <= 1)) {
                return (currentFileBytesSent.toFloat() / currentFileTotalBytes.toFloat()).coerceIn(0f, 1f)
            }
            if (totalCount <= 0) return 0f
            val currentFileFrac = if (currentFileTotalBytes > 0L) {
                (currentFileBytesSent.toFloat() / currentFileTotalBytes.toFloat()).coerceIn(0f, 1f)
            } else 0f
            return ((completedCount.toFloat() + currentFileFrac) / totalCount.toFloat()).coerceIn(0f, 1f)
        }

    val overallPercent: Int
        get() = (overallFraction * 100f).toInt().coerceIn(0, 100)
}

fun computeTransferBatchSummary(
    activeUploads: List<com.example.data.local.UploadTaskEntity>,
    activeDownloads: List<com.example.data.local.DownloadRecordEntity>,
    downloadSpeeds: Map<Long, Long>,
    completedBatchBytes: Long = 0L
): UploadBatchSummary {
    val activeCount = activeUploads.size + activeDownloads.size
    if (activeCount == 0) {
        return UploadBatchSummary()
    }
    val galleryCount = activeUploads.count { isGalleryMimeType(it.mimeType) } +
        activeDownloads.count { isGalleryMimeType(it.mimeType) }
    val filesCount = activeCount - galleryCount

    val totalBytes = completedBatchBytes +
        activeUploads.sumOf { it.sizeBytes.coerceAtLeast(0L) } +
        activeDownloads.sumOf { it.sizeBytes.coerceAtLeast(0L) }
    val transferredBytes = completedBatchBytes +
        activeUploads.sumOf { it.bytesUploaded.coerceIn(0L, it.sizeBytes.coerceAtLeast(0L)) } +
        activeDownloads.sumOf { it.progressBytes.coerceIn(0L, it.sizeBytes.coerceAtLeast(0L)) }
    val combinedSpeed = activeUploads.sumOf { it.speedBytesPerSec.coerceAtLeast(0L) } +
        activeDownloads.sumOf { (downloadSpeeds[it.id] ?: 0L).coerceAtLeast(0L) }

    val firstName = activeUploads.firstOrNull()?.fileName
        ?: activeDownloads.firstOrNull()?.fileName.orEmpty()

    return UploadBatchSummary(
        totalCount = activeCount,
        completedCount = 0,
        currentFileName = firstName,
        currentFileBytesSent = transferredBytes,
        currentFileTotalBytes = totalBytes,
        speedBytesPerSec = combinedSpeed,
        activeParallelCount = activeCount,
        galleryActiveCount = galleryCount,
        filesActiveCount = filesCount,
        isActive = true
    )
}

fun formatSpeed(bytesPerSec: Long): String {
    if (bytesPerSec <= 0L) return "0 KB/s"
    val kb = bytesPerSec / 1024.0
    if (kb < 1024.0) return String.format(Locale.US, "%.0f KB/s", kb)
    val mb = kb / 1024.0
    return String.format(Locale.US, "%.1f MB/s", mb)
}

fun isGalleryMimeType(mimeType: String): Boolean {
    return mimeType.startsWith("image/") || mimeType.startsWith("video/")
}

class MovingAverageSpeedTracker(
    private val windowMs: Long = 1_500L,
    private val minWarmupMs: Long = 300L
) {
    private data class SpeedSample(val timestampMs: Long, val totalBytes: Long)

    private val samples = ArrayDeque<SpeedSample>()
    private var startTimeMs: Long = -1L
    private var baselineBytes: Long = -1L
    private var lastComputedSpeed: Long = 0L

    @Synchronized
    fun reset(initialBytes: Long = 0L, nowMs: Long = System.currentTimeMillis()) {
        samples.clear()
        startTimeMs = nowMs
        baselineBytes = initialBytes.coerceAtLeast(0L)
        lastComputedSpeed = 0L
        samples.addLast(SpeedSample(nowMs, baselineBytes))
    }

    @Synchronized
    fun recordProgress(totalBytesSent: Long, nowMs: Long = System.currentTimeMillis()): Long {
        val safeBytes = totalBytesSent.coerceAtLeast(0L)
        if (startTimeMs < 0L) {
            reset(safeBytes, nowMs)
            return 0L
        }

        val sinceStart = nowMs - startTimeMs
        // Ignore initial TDLib chunk-registration bursts during the first 300ms
        if (sinceStart < minWarmupMs) {
            baselineBytes = maxOf(baselineBytes, safeBytes)
            samples.clear()
            samples.addLast(SpeedSample(startTimeMs, baselineBytes))
            return 0L
        }

        val last = samples.lastOrNull()
        if (last == null || safeBytes > last.totalBytes) {
            samples.addLast(SpeedSample(nowMs, maxOf(safeBytes, baselineBytes)))
        } else if (nowMs - last.timestampMs >= 250L) {
            samples.addLast(SpeedSample(nowMs, last.totalBytes))
        }

        val cutoff = nowMs - windowMs
        while (samples.size > 2 && samples.first().timestampMs < cutoff) {
            // Keep at least one anchor sample at or right before the cutoff
            val next = samples.elementAtOrNull(1)
            if (next != null && next.timestampMs <= cutoff) {
                samples.removeFirst()
            } else {
                break
            }
        }

        val oldest = samples.firstOrNull() ?: return 0L
        val newest = samples.lastOrNull() ?: return 0L
        val deltaBytes = (newest.totalBytes - oldest.totalBytes).coerceAtLeast(0L)
        val deltaTimeMs = (nowMs - oldest.timestampMs).coerceAtLeast(minWarmupMs)

        if (deltaBytes == 0L && (nowMs - newest.timestampMs) > windowMs) {
            lastComputedSpeed = 0L
            return 0L
        }

        val instantWindowSpeed = (deltaBytes * 1_000L) / deltaTimeMs
        lastComputedSpeed = if (lastComputedSpeed > 0L) {
            ((lastComputedSpeed * 3L) + (instantWindowSpeed * 7L)) / 10L
        } else {
            instantWindowSpeed
        }
        return lastComputedSpeed.coerceAtLeast(0L)
    }
}

class TransferBatchTracker(
    @Suppress("UNUSED_PARAMETER") dao: ClodyDao? = null
) {
    val summary: StateFlow<UploadBatchSummary> get() = Companion.summary
    val batchSummary: StateFlow<TransferBatchSummary> get() = Companion.summary
    val downloadSpeeds: StateFlow<Map<Long, Long>> get() = Companion.downloadSpeeds
    val instantMatchEvents: SharedFlow<String> get() = Companion.instantMatchEvents

    fun updateDownloadSpeed(recordId: Long, speedBytesPerSec: Long) {
        Companion.updateDownloadSpeed(recordId, speedBytesPerSec)
    }

    fun clearDownloadSpeed(recordId: Long) {
        Companion.clearDownloadSpeed(recordId)
    }

    companion object {
        private val _summary = MutableStateFlow(UploadBatchSummary())
        val summary: StateFlow<UploadBatchSummary> = _summary.asStateFlow()

        private val _downloadSpeeds = MutableStateFlow<Map<Long, Long>>(emptyMap())
        val downloadSpeeds: StateFlow<Map<Long, Long>> = _downloadSpeeds.asStateFlow()

        private val _instantMatchEvents = MutableSharedFlow<String>(extraBufferCapacity = 16)
        val instantMatchEvents: SharedFlow<String> = _instantMatchEvents.asSharedFlow()

        fun updateDownloadSpeed(recordId: Long, speedBytesPerSec: Long) {
            _downloadSpeeds.value = _downloadSpeeds.value + (recordId to speedBytesPerSec)
        }

        fun clearDownloadSpeed(recordId: Long) {
            _downloadSpeeds.value = _downloadSpeeds.value - recordId
        }

        private data class ActiveItemProgress(
            val fileName: String,
            val bytesSent: Long,
            val totalBytes: Long,
            val speedBytesPerSec: Long
        )

        private val activeItems = ConcurrentHashMap<String, ActiveItemProgress>()
        private val enqueuedKeys = LinkedHashSet<String>()
        private val completedKeys = LinkedHashSet<String>()

        private fun resolveKey(taskId: Long, uniqueKey: String, fileName: String): String {
            return when {
                uniqueKey.isNotBlank() -> uniqueKey
                taskId > 0L -> "task_$taskId"
                else -> "name_$fileName"
            }
        }

        @Synchronized
        fun onBatchEnqueued(taskKeys: List<String>, firstFileName: String) {
            val cleanKeys = taskKeys.filter { it.isNotBlank() }
            if (cleanKeys.isEmpty()) return
            var newlyAdded = 0
            for (k in cleanKeys) {
                completedKeys.remove(k)
                if (enqueuedKeys.add(k)) {
                    newlyAdded++
                }
            }
            if (newlyAdded == 0 && _summary.value.isActive) return
            val cur = _summary.value
            val total = enqueuedKeys.size + completedKeys.size
            _summary.value = UploadBatchSummary(
                totalCount = maxOf(total, 1),
                completedCount = completedKeys.size,
                currentFileName = cur.currentFileName.ifBlank { firstFileName },
                currentFileBytesSent = cur.currentFileBytesSent,
                currentFileTotalBytes = cur.currentFileTotalBytes,
                speedBytesPerSec = cur.speedBytesPerSec,
                activeParallelCount = maxOf(activeItems.size, enqueuedKeys.size, 1),
                isActive = true,
                isPausedForWifi = false,
                justCompleted = false
            )
        }

        @Synchronized
        fun onBatchEnqueued(addedCount: Int, firstFileName: String) {
            if (addedCount <= 0) return
            val cur = _summary.value
            val syntheticKeys = (1..addedCount).map { idx -> "batch_${System.nanoTime()}_$idx" }
            enqueuedKeys.addAll(syntheticKeys)
            val total = maxOf(
                if (cur.isActive) maxOf(enqueuedKeys.size + completedKeys.size, cur.totalCount + addedCount) else addedCount,
                1
            )
            val baseDone = if (cur.isActive) maxOf(cur.completedCount, completedKeys.size) else 0
            _summary.value = UploadBatchSummary(
                totalCount = total,
                completedCount = baseDone,
                currentFileName = cur.currentFileName.ifBlank { firstFileName },
                currentFileBytesSent = cur.currentFileBytesSent,
                currentFileTotalBytes = cur.currentFileTotalBytes,
                speedBytesPerSec = cur.speedBytesPerSec,
                activeParallelCount = maxOf(activeItems.size, enqueuedKeys.size, 1),
                isActive = true,
                isPausedForWifi = false,
                justCompleted = false
            )
        }

        @Synchronized
        fun onFileStarted(
            fileName: String,
            totalBytes: Long,
            pendingCountInDb: Int,
            taskId: Long = 0L,
            uniqueKey: String = ""
        ) {
            val key = resolveKey(taskId, uniqueKey, fileName)
            enqueuedKeys.add(key)
            activeItems[key] = ActiveItemProgress(fileName, 0L, maxOf(totalBytes, 1L), 0L)
            val cur = _summary.value
            val remainingCount = maxOf(pendingCountInDb, enqueuedKeys.size, activeItems.size)
            val total = maxOf(completedKeys.size + remainingCount, activeItems.size, 1)
            val combinedSent = activeItems.values.sumOf { it.bytesSent }
            val combinedTotal = activeItems.values.sumOf { it.totalBytes }.coerceAtLeast(1L)
            val combinedSpeed = activeItems.values.sumOf { it.speedBytesPerSec }
            _summary.value = cur.copy(
                totalCount = total,
                completedCount = completedKeys.size,
                currentFileName = fileName,
                currentFileBytesSent = combinedSent,
                currentFileTotalBytes = combinedTotal,
                speedBytesPerSec = combinedSpeed,
                activeParallelCount = activeItems.size.coerceAtLeast(1),
                isActive = true,
                isPausedForWifi = false,
                justCompleted = false
            )
        }

        @Synchronized
        fun onFileProgress(
            fileName: String,
            bytesSent: Long,
            totalBytes: Long,
            speedBytesPerSec: Long,
            taskId: Long = 0L,
            uniqueKey: String = ""
        ) {
            val key = resolveKey(taskId, uniqueKey, fileName)
            val safeTotal = maxOf(totalBytes, 1L)
            val safeSent = bytesSent.coerceIn(0L, safeTotal)
            activeItems[key] = ActiveItemProgress(fileName, safeSent, safeTotal, speedBytesPerSec.coerceAtLeast(0L))
            enqueuedKeys.add(key)

            val cur = _summary.value
            val combinedSpeed = activeItems.values.sumOf { it.speedBytesPerSec }
            val combinedSent = activeItems.values.sumOf { it.bytesSent }
            val combinedTotal = activeItems.values.sumOf { it.totalBytes }.coerceAtLeast(1L)
            val total = maxOf(cur.totalCount, completedKeys.size + maxOf(enqueuedKeys.size, activeItems.size), 1)

            _summary.value = cur.copy(
                totalCount = total,
                completedCount = completedKeys.size,
                currentFileName = fileName,
                currentFileBytesSent = combinedSent,
                currentFileTotalBytes = combinedTotal,
                speedBytesPerSec = combinedSpeed,
                activeParallelCount = activeItems.size.coerceAtLeast(1),
                isActive = true,
                isPausedForWifi = false,
                justCompleted = false
            )
        }

        @Synchronized
        fun onFileCompleted(
            remainingInDb: Int,
            taskId: Long = 0L,
            uniqueKey: String = ""
        ) {
            if (taskId > 0L) {
                activeItems.remove("task_$taskId")
                enqueuedKeys.remove("task_$taskId")
            }
            if (uniqueKey.isNotBlank()) {
                activeItems.remove(uniqueKey)
                enqueuedKeys.remove(uniqueKey)
            }
            val trackKey = resolveKey(taskId, uniqueKey, "item_${completedKeys.size + 1}")
            completedKeys.add(trackKey)

            if (remainingInDb <= 0 && activeItems.isEmpty()) {
                enqueuedKeys.clear()
                completedKeys.clear()
                _summary.value = UploadBatchSummary(
                    totalCount = 0,
                    completedCount = 0,
                    currentFileName = "",
                    currentFileBytesSent = 0L,
                    currentFileTotalBytes = 0L,
                    speedBytesPerSec = 0L,
                    activeParallelCount = 0,
                    galleryActiveCount = 0,
                    filesActiveCount = 0,
                    isActive = false,
                    isPausedForWifi = false,
                    justCompleted = true
                )
            } else {
                val cur = _summary.value
                val combinedSpeed = activeItems.values.sumOf { it.speedBytesPerSec }
                val combinedSent = activeItems.values.sumOf { it.bytesSent }
                val combinedTotal = activeItems.values.sumOf { it.totalBytes }.coerceAtLeast(0L)
                val activeRem = maxOf(remainingInDb, activeItems.size)
                val total = maxOf(completedKeys.size + activeRem, activeItems.size)
                _summary.value = cur.copy(
                    totalCount = total,
                    completedCount = completedKeys.size,
                    currentFileName = activeItems.values.firstOrNull()?.fileName ?: cur.currentFileName,
                    currentFileBytesSent = combinedSent,
                    currentFileTotalBytes = combinedTotal,
                    speedBytesPerSec = combinedSpeed,
                    activeParallelCount = activeItems.size,
                    isActive = true
                )
            }
        }

        @Synchronized
        fun reconcileActiveQueue(remainingInDb: Int, cancelledTaskId: Long = 0L, uniqueKey: String = "") {
            if (cancelledTaskId > 0L) {
                activeItems.remove("task_$cancelledTaskId")
                enqueuedKeys.remove("task_$cancelledTaskId")
            }
            if (uniqueKey.isNotBlank()) {
                activeItems.remove(uniqueKey)
                enqueuedKeys.remove(uniqueKey)
            }
            if (remainingInDb <= 0 && activeItems.isEmpty()) {
                clearBanner()
            } else {
                val cur = _summary.value
                val combinedSpeed = activeItems.values.sumOf { it.speedBytesPerSec }
                val combinedSent = activeItems.values.sumOf { it.bytesSent }
                val combinedTotal = activeItems.values.sumOf { it.totalBytes }.coerceAtLeast(0L)
                _summary.value = cur.copy(
                    totalCount = maxOf(completedKeys.size + remainingInDb, activeItems.size),
                    currentFileBytesSent = combinedSent,
                    currentFileTotalBytes = combinedTotal,
                    speedBytesPerSec = combinedSpeed,
                    activeParallelCount = activeItems.size
                )
            }
        }

        @Synchronized
        fun setPausedForWifi(paused: Boolean) {
            val cur = _summary.value
            if (cur.isActive || paused) {
                _summary.value = cur.copy(
                    isPausedForWifi = paused,
                    speedBytesPerSec = if (paused) 0L else cur.speedBytesPerSec
                )
            }
        }

        fun notifyInstantCloudMatch(fileName: String) {
            _instantMatchEvents.tryEmit("Instant Cloud Match ✓ ($fileName)")
        }

        @Synchronized
        fun clearBanner() {
            activeItems.clear()
            enqueuedKeys.clear()
            completedKeys.clear()
            _summary.value = UploadBatchSummary()
        }
    }
}
