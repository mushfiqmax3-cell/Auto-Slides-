package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.annotation.OptIn
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.media3.common.AudioAttributes as Media3AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.ForwardingPlayer
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaStyleNotificationHelper
import com.example.ClodyApplication
import com.example.MainActivity
import com.example.R
import com.example.data.local.FileEntity
import com.example.data.local.PlaybackCacheMode
import com.example.media.ClodyStreamCache
import com.example.media.LocalFirstResolver
import com.example.media.MediaPlaybackOrigin
import com.example.media.ResolvedMediaSource
import com.example.media.TelegramChunkDataSource
import com.example.media.ThumbnailGenerator
import com.example.telegram.TelegramClientManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.io.File

@OptIn(UnstableApi::class)
object ClodyPlaybackController {

    private val mainHandler = Handler(Looper.getMainLooper())
    private val controllerScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _activeFile = MutableStateFlow<FileEntity?>(null)
    val activeFile: StateFlow<FileEntity?> = _activeFile.asStateFlow()

    private val _activeIsVideo = MutableStateFlow(false)
    val activeIsVideo: StateFlow<Boolean> = _activeIsVideo.asStateFlow()

    private val _playlist = MutableStateFlow<List<FileEntity>>(emptyList())
    val playlist: StateFlow<List<FileEntity>> = _playlist.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _isBuffering = MutableStateFlow(false)
    val isBuffering: StateFlow<Boolean> = _isBuffering.asStateFlow()

    private val _artworkBitmap = MutableStateFlow<Bitmap?>(null)
    val artworkBitmap: StateFlow<Bitmap?> = _artworkBitmap.asStateFlow()

    private val _audioFocusPaused = MutableStateFlow(false)
    val audioFocusPaused: StateFlow<Boolean> = _audioFocusPaused.asStateFlow()

    @Volatile
    var exoPlayer: ExoPlayer? = null
        private set

    @Volatile
    var trackSelector: DefaultTrackSelector? = null
        private set

    private var currentFileId: Long = -1L
    private var currentIsVideo: Boolean = false
    private var currentZeroStorage: Boolean = false
    private var currentCellularSaver: Boolean = false
    private var currentOrigin: MediaPlaybackOrigin = MediaPlaybackOrigin.CLOUD_STREAM
    private var cachedTelegramClient: TelegramClientManager? = null
    private var cachedOnCacheMutated: (() -> Unit)? = null
    private var artworkLoadJob: Job? = null

    private var appContextRef: Context? = null
    private var audioManagerRef: AudioManager? = null
    private var audioFocusRequest: AudioFocusRequest? = null
    private var hasAudioFocus: Boolean = false
    private var wasPlayingBeforeTransientLoss: Boolean = false

    private val audioFocusListener = AudioManager.OnAudioFocusChangeListener { focusChange ->
        handleAudioFocusChange(focusChange)
    }

    private val sharedPlayerListener = object : Player.Listener {
        override fun onPlaybackStateChanged(playbackState: Int) {
            _isBuffering.value = playbackState == Player.STATE_BUFFERING
            _isPlaying.value = exoPlayer?.isPlaying == true
            appContextRef?.let { ClodyMediaPlaybackService.syncNotification(it) }
        }

        override fun onIsPlayingChanged(playing: Boolean) {
            _isPlaying.value = playing
            appContextRef?.let { ClodyMediaPlaybackService.syncNotification(it) }
        }
    }

    internal fun handleAudioFocusChange(focusChange: Int) {
        when (focusChange) {
            AudioManager.AUDIOFOCUS_LOSS -> {
                hasAudioFocus = false
                wasPlayingBeforeTransientLoss = false
                _audioFocusPaused.value = true
                runOnMain {
                    exoPlayer?.pause()
                }
            }

            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                val currentlyPlaying = exoPlayer?.let { it.isPlaying || it.playWhenReady } == true
                wasPlayingBeforeTransientLoss = currentlyPlaying
                _audioFocusPaused.value = true
                runOnMain {
                    exoPlayer?.pause()
                }
            }

            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                runOnMain {
                    exoPlayer?.volume = 0.25f
                }
            }

            AudioManager.AUDIOFOCUS_GAIN -> {
                hasAudioFocus = true
                runOnMain {
                    exoPlayer?.volume = 1.0f
                    if (wasPlayingBeforeTransientLoss) {
                        wasPlayingBeforeTransientLoss = false
                        _audioFocusPaused.value = false
                        exoPlayer?.play()
                    }
                }
            }
        }
    }

    private fun runOnMain(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            block()
        } else {
            mainHandler.post(block)
        }
    }

    fun requestAudioFocus(context: Context): Boolean {
        val am = audioManagerRef ?: (context.applicationContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager).also {
            audioManagerRef = it
        }
        val result = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(
                    if (_activeIsVideo.value) AudioAttributes.CONTENT_TYPE_MOVIE else AudioAttributes.CONTENT_TYPE_MUSIC
                )
                .build()
            val req = audioFocusRequest ?: AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(attrs)
                .setAcceptsDelayedFocusGain(true)
                .setOnAudioFocusChangeListener(audioFocusListener)
                .build().also { audioFocusRequest = it }
            am.requestAudioFocus(req)
        } else {
            @Suppress("DEPRECATION")
            am.requestAudioFocus(
                audioFocusListener,
                AudioManager.STREAM_MUSIC,
                AudioManager.AUDIOFOCUS_GAIN
            )
        }
        hasAudioFocus = (result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED)
        if (hasAudioFocus) {
            _audioFocusPaused.value = false
        }
        return hasAudioFocus
    }

    private fun abandonAudioFocus() {
        val am = audioManagerRef ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            audioFocusRequest?.let { req ->
                runCatching { am.abandonAudioFocusRequest(req) }
            }
            audioFocusRequest = null
        } else {
            @Suppress("DEPRECATION")
            am.abandonAudioFocus(audioFocusListener)
        }
        hasAudioFocus = false
        wasPlayingBeforeTransientLoss = false
        _audioFocusPaused.value = false
    }

    fun ensurePlaybackSession(
        context: Context,
        file: FileEntity,
        isVideo: Boolean,
        playlist: List<FileEntity>,
        telegramClient: TelegramClientManager,
        zeroStorageMode: Boolean,
        isCellularDataSaver: Boolean = false,
        subtitlesEnabled: Boolean = true,
        onCacheMutated: () -> Unit = {}
    ): ExoPlayer {
        val appCtx = context.applicationContext
        appContextRef = appCtx
        cachedTelegramClient = telegramClient
        cachedOnCacheMutated = onCacheMutated

        val normalizedPlaylist = if (playlist.any { it.id == file.id }) {
            playlist
        } else {
            listOf(file) + playlist
        }
        _playlist.value = normalizedPlaylist

        val existing = exoPlayer
        val sameTrack = existing != null &&
            currentFileId == file.id &&
            currentIsVideo == isVideo &&
            currentZeroStorage == zeroStorageMode

        if (sameTrack) {
            currentCellularSaver = isCellularDataSaver
            _activeFile.value = file
            _activeIsVideo.value = isVideo
            ClodyMediaPlaybackService.startOrUpdate(appCtx)
            return existing!!
        }

        val previousFile = _activeFile.value
        val previousOrigin = currentOrigin
        val previousZeroStorage = currentZeroStorage
        if (previousFile != null && previousFile.id != file.id && previousZeroStorage &&
            previousOrigin != MediaPlaybackOrigin.LOCAL_DEVICE && previousOrigin != MediaPlaybackOrigin.PINNED_OFFLINE
        ) {
            cleanupFileTempCache(appCtx, previousFile, telegramClient, onCacheMutated)
        }

        val selector = DefaultTrackSelector(appCtx)
        val paramsBuilder = selector.buildUponParameters()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, !subtitlesEnabled)
        if (isVideo && isCellularDataSaver) {
            paramsBuilder
                .setMaxVideoSize(854, 480)
                .setMaxVideoBitrate(1_200_000)
        } else {
            paramsBuilder
                .clearVideoSizeConstraints()
                .setMaxVideoBitrate(Int.MAX_VALUE)
        }
        selector.parameters = paramsBuilder.build()

        val loadControl = if (!isVideo) {
            DefaultLoadControl.Builder()
                .setBufferDurationsMs(1200, 15_000, 400, 800)
                .setTargetBufferBytes(2 * 1024 * 1024)
                .build()
        } else if (isCellularDataSaver) {
            DefaultLoadControl.Builder()
                .setBufferDurationsMs(2_500, 5_000, 1_500, 2_500)
                .setTargetBufferBytes(3 * 1024 * 1024)
                .setPrioritizeTimeOverSizeThresholds(true)
                .build()
        } else {
            DefaultLoadControl.Builder()
                .setBufferDurationsMs(15_000, 30_000, 1_000, 2_000)
                .setTargetBufferBytes(8 * 1024 * 1024)
                .setPrioritizeTimeOverSizeThresholds(false)
                .build()
        }

        val resolvedSource = LocalFirstResolver.resolve(appCtx, file, ignoreStreamCache = zeroStorageMode)
        currentOrigin = resolvedSource.origin

        val readyOfflineFile = (resolvedSource as? ResolvedMediaSource.CloudStream)?.cachedOrPinnedFile
            ?.takeIf { it.exists() && it.length() > 0L }
            ?: if (!zeroStorageMode) {
                file.localCachePath?.let { File(it) }?.takeIf {
                    it.exists() && !it.name.endsWith(".part") && it.length() > 0L
                }
            } else null

        val dataSourceFactory = when {
            resolvedSource is ResolvedMediaSource.LocalDevice -> DefaultDataSource.Factory(appCtx)
            readyOfflineFile != null || file.telegramDocumentId == 0L -> DefaultDataSource.Factory(appCtx)
            else -> TelegramChunkDataSource.Factory(
                context = appCtx,
                telegramClient = telegramClient,
                fileEntity = file,
                noCacheStreaming = zeroStorageMode,
                enableLookaheadProvider = { !isCellularDataSaver }
            )
        }

        val mediaUri = when {
            resolvedSource is ResolvedMediaSource.LocalDevice -> resolvedSource.uri
            readyOfflineFile != null -> Uri.fromFile(readyOfflineFile)
            else -> Uri.parse("clody://telegram/${file.telegramDocumentId}/${file.name}")
        }

        existing?.let { old ->
            old.removeListener(sharedPlayerListener)
            old.release()
        }

        val media3Attrs = Media3AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(if (isVideo) C.AUDIO_CONTENT_TYPE_MOVIE else C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()

        val metadata = MediaMetadata.Builder()
            .setTitle(file.name)
            .setArtist("Clody Cloud")
            .setSubtitle("Clody Cloud")
            .build()

        val mediaItem = MediaItem.Builder()
            .setUri(mediaUri)
            .setMediaId(file.id.toString())
            .setMediaMetadata(metadata)
            .build()

        val newPlayer = ExoPlayer.Builder(appCtx)
            .setTrackSelector(selector)
            .setLoadControl(loadControl)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dataSourceFactory))
            .build().apply {
                setAudioAttributes(media3Attrs, false)
                setHandleAudioBecomingNoisy(true)
                addListener(sharedPlayerListener)
                setMediaItem(mediaItem)
                prepare()
            }

        exoPlayer = newPlayer
        trackSelector = selector
        currentFileId = file.id
        currentIsVideo = isVideo
        currentZeroStorage = zeroStorageMode
        currentCellularSaver = isCellularDataSaver
        _activeFile.value = file
        _activeIsVideo.value = isVideo
        _artworkBitmap.value = null

        requestAudioFocus(appCtx)
        newPlayer.playWhenReady = true
        _isPlaying.value = true
        _isBuffering.value = true

        loadArtworkAsync(appCtx, file, telegramClient)
        ClodyMediaPlaybackService.startOrUpdate(appCtx)
        return newPlayer
    }

    private fun loadArtworkAsync(
        appCtx: Context,
        file: FileEntity,
        telegramClient: TelegramClientManager
    ) {
        artworkLoadJob?.cancel()
        artworkLoadJob = controllerScope.launch {
            var bmp = ThumbnailGenerator.loadNotificationArtworkBitmap(appCtx, file, maxSizePx = 256)
            if (bmp == null && file.telegramAccessHash != 0L) {
                val targetThumb = ThumbnailGenerator.getPersistentThumbnailFile(appCtx, file)
                val downloaded = runCatching {
                    telegramClient.downloadThumbnailWithSemaphore(file, targetThumb)
                }.getOrNull()
                if (downloaded != null) {
                    bmp = ThumbnailGenerator.loadNotificationArtworkBitmap(appCtx, file, maxSizePx = 256)
                }
                if (bmp == null) {
                    val miniBytes = runCatching {
                        telegramClient.getCachedOrFetchMinithumbnail(file)
                    }.getOrNull()
                    if (miniBytes != null && miniBytes.isNotEmpty()) {
                        bmp = runCatching {
                            BitmapFactory.decodeByteArray(miniBytes, 0, miniBytes.size)
                        }.getOrNull()
                    }
                }
            }
            if (currentFileId == file.id && bmp != null) {
                _artworkBitmap.value = bmp
                runOnMain {
                    ClodyMediaPlaybackService.syncNotification(appCtx)
                }
            }
        }
    }

    fun updateArtworkBitmap(fileId: Long, bitmap: Bitmap?) {
        if (currentFileId != fileId || bitmap == null) return
        _artworkBitmap.value = bitmap
        appContextRef?.let { ctx ->
            runOnMain { ClodyMediaPlaybackService.syncNotification(ctx) }
        }
    }

    fun hasPrevious(): Boolean {
        val list = _playlist.value
        val active = _activeFile.value ?: return false
        val idx = list.indexOfFirst { it.id == active.id }
        return idx > 0
    }

    fun hasNext(): Boolean {
        val list = _playlist.value
        val active = _activeFile.value ?: return false
        val idx = list.indexOfFirst { it.id == active.id }
        return idx in 0 until (list.size - 1)
    }

    fun skipToPrevious(context: Context): FileEntity? {
        val list = _playlist.value
        val active = _activeFile.value ?: return null
        val idx = list.indexOfFirst { it.id == active.id }
        if (idx <= 0) return null
        val target = list[idx - 1]
        val client = cachedTelegramClient ?: (context.applicationContext as? ClodyApplication)?.telegramClient ?: return null
        ensurePlaybackSession(
            context = context,
            file = target,
            isVideo = currentIsVideo,
            playlist = list,
            telegramClient = client,
            zeroStorageMode = currentZeroStorage,
            isCellularDataSaver = currentCellularSaver,
            onCacheMutated = cachedOnCacheMutated ?: {}
        )
        return target
    }

    fun skipToNext(context: Context): FileEntity? {
        val list = _playlist.value
        val active = _activeFile.value ?: return null
        val idx = list.indexOfFirst { it.id == active.id }
        if (idx !in 0 until (list.size - 1)) return null
        val target = list[idx + 1]
        val client = cachedTelegramClient ?: (context.applicationContext as? ClodyApplication)?.telegramClient ?: return null
        ensurePlaybackSession(
            context = context,
            file = target,
            isVideo = currentIsVideo,
            playlist = list,
            telegramClient = client,
            zeroStorageMode = currentZeroStorage,
            isCellularDataSaver = currentCellularSaver,
            onCacheMutated = cachedOnCacheMutated ?: {}
        )
        return target
    }

    fun togglePlayPause(context: Context) {
        val player = exoPlayer ?: return
        runOnMain {
            if (player.playbackState == Player.STATE_ENDED) {
                requestAudioFocus(context)
                player.seekTo(0L)
                player.play()
            } else if (player.isPlaying) {
                wasPlayingBeforeTransientLoss = false
                player.pause()
            } else {
                requestAudioFocus(context)
                player.play()
            }
            ClodyMediaPlaybackService.syncNotification(context)
        }
    }

    fun playWithFocus(context: Context) {
        val player = exoPlayer ?: return
        runOnMain {
            requestAudioFocus(context)
            if (player.playbackState == Player.STATE_ENDED) {
                player.seekTo(0L)
            }
            player.play()
            ClodyMediaPlaybackService.syncNotification(context)
        }
    }

    fun shouldPreserveBackgroundPlayback(): Boolean {
        return exoPlayer != null && _activeFile.value != null && ClodyMediaPlaybackService.isRunning
    }

    fun stopAndCleanup(context: Context, fromTaskRemoved: Boolean = false) {
        val appCtx = context.applicationContext
        val closingFile = _activeFile.value
        val closingOrigin = currentOrigin
        val wasZeroStorage = currentZeroStorage
        val client = cachedTelegramClient ?: (appCtx as? ClodyApplication)?.telegramClient
        val mutatedCb = cachedOnCacheMutated

        artworkLoadJob?.cancel()
        artworkLoadJob = null

        runOnMain {
            exoPlayer?.let { p ->
                p.removeListener(sharedPlayerListener)
                p.stop()
                p.release()
            }
            exoPlayer = null
            trackSelector = null
        }

        abandonAudioFocus()

        currentFileId = -1L
        _activeFile.value = null
        _isPlaying.value = false
        _isBuffering.value = false
        _artworkBitmap.value = null

        ClodyMediaPlaybackService.stopService(appCtx)

        if (closingFile != null && wasZeroStorage &&
            closingOrigin != MediaPlaybackOrigin.LOCAL_DEVICE &&
            closingOrigin != MediaPlaybackOrigin.PINNED_OFFLINE
        ) {
            if (client != null) {
                cleanupFileTempCache(appCtx, closingFile, client, mutatedCb ?: {})
            } else {
                LocalFirstResolver.cleanupTempLocalCopies(appCtx, closingFile.id)
                ClodyStreamCache.deleteFileCache(appCtx, closingFile)
            }
        }

        if (fromTaskRemoved) {
            val app = appCtx as? ClodyApplication
            if (app != null) {
                controllerScope.launch {
                    val settings = runCatching { app.settingsRepository.settingsFlow.first() }.getOrNull()
                    if (settings != null && (settings.zeroStorageMode || settings.autoDeleteCacheOnExit)) {
                        runCatching { app.telegramClient.clearAllTdMediaTempFiles() }
                        ClodyStreamCache.clearAllStreamCache(appCtx, includeSharedCache = true)
                        runCatching { app.dao.clearAllLocalCachePaths() }
                    }
                }
            }
        }
    }

    private fun cleanupFileTempCache(
        appCtx: Context,
        file: FileEntity,
        telegramClient: TelegramClientManager,
        onCacheMutated: () -> Unit
    ) {
        LocalFirstResolver.cleanupTempLocalCopies(appCtx, file.id)
        ClodyStreamCache.deleteFileCache(appCtx, file)
        controllerScope.launch {
            runCatching { telegramClient.deleteTdFileCache(file) }
            ClodyStreamCache.deleteFileCache(appCtx, file)
            runOnMain { onCacheMutated() }
        }
    }
}

@OptIn(UnstableApi::class)
class ClodyMediaPlaybackService : Service() {

    companion object {
        const val CHANNEL_ID = "clody_media_playback_channel"
        const val NOTIFICATION_ID = 4103

        const val ACTION_SYNC_NOTIFICATION = "com.example.action.MEDIA_SYNC_NOTIFICATION"
        const val ACTION_PREVIOUS = "com.example.action.MEDIA_PREVIOUS"
        const val ACTION_PLAY_PAUSE = "com.example.action.MEDIA_PLAY_PAUSE"
        const val ACTION_NEXT = "com.example.action.MEDIA_NEXT"
        const val ACTION_STOP_PLAYBACK = "com.example.action.MEDIA_STOP_PLAYBACK"

        const val EXTRA_OPEN_ACTIVE_PLAYER = "extra_open_active_player"
        const val EXTRA_OPEN_PLAYER_FILE_ID = "extra_open_player_file_id"
        const val EXTRA_OPEN_PLAYER_IS_VIDEO = "extra_open_player_is_video"

        @Volatile
        var isRunning: Boolean = false
            private set

        fun startOrUpdate(context: Context) {
            val appCtx = context.applicationContext
            val intent = Intent(appCtx, ClodyMediaPlaybackService::class.java).apply {
                action = ACTION_SYNC_NOTIFICATION
            }
            runCatching {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    appCtx.startForegroundService(intent)
                } else {
                    appCtx.startService(intent)
                }
            }
        }

        fun syncNotification(context: Context) {
            if (!isRunning) return
            val appCtx = context.applicationContext
            val intent = Intent(appCtx, ClodyMediaPlaybackService::class.java).apply {
                action = ACTION_SYNC_NOTIFICATION
            }
            runCatching { appCtx.startService(intent) }
        }

        fun stopService(context: Context) {
            val appCtx = context.applicationContext
            if (!isRunning) return
            runCatching {
                appCtx.stopService(Intent(appCtx, ClodyMediaPlaybackService::class.java))
            }
        }

        fun buildOpenPlayerIntent(
            context: Context,
            fileId: Long,
            isVideo: Boolean
        ): Intent {
            return Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra(EXTRA_OPEN_ACTIVE_PLAYER, true)
                putExtra(EXTRA_OPEN_PLAYER_FILE_ID, fileId)
                putExtra(EXTRA_OPEN_PLAYER_IS_VIDEO, isVideo)
            }
        }
    }

    private var mediaSession: MediaSession? = null
    private var attachedExoPlayer: ExoPlayer? = null

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PREVIOUS -> ClodyPlaybackController.skipToPrevious(this)
            ACTION_PLAY_PAUSE -> ClodyPlaybackController.togglePlayPause(this)
            ACTION_NEXT -> ClodyPlaybackController.skipToNext(this)
            ACTION_STOP_PLAYBACK -> {
                ClodyPlaybackController.stopAndCleanup(this)
                return START_NOT_STICKY
            }
        }

        val player = ClodyPlaybackController.exoPlayer
        val activeFile = ClodyPlaybackController.activeFile.value
        if (player == null || activeFile == null) {
            val placeholder = NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_clody_media_notification)
                .setContentTitle("Clody Media")
                .setContentText("Clody Cloud")
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build()
            startForegroundCompat(placeholder)
            stopSelfCleanly()
            return START_NOT_STICKY
        }

        val session = ensureMediaSession(player, activeFile, ClodyPlaybackController.activeIsVideo.value)
        val notification = buildPlaybackNotification(
            file = activeFile,
            isVideo = ClodyPlaybackController.activeIsVideo.value,
            isPlaying = ClodyPlaybackController.isPlaying.value || player.playWhenReady,
            artworkBitmap = ClodyPlaybackController.artworkBitmap.value,
            session = session
        )
        startForegroundCompat(notification)
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        ClodyPlaybackController.stopAndCleanup(applicationContext, fromTaskRemoved = true)
        stopSelfCleanly()
    }

    override fun onDestroy() {
        isRunning = false
        runCatching {
            mediaSession?.release()
            mediaSession = null
            attachedExoPlayer = null
        }
        super.onDestroy()
    }

    private fun stopSelfCleanly() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
        stopSelf()
    }

    private fun ensureMediaSession(
        exoPlayer: ExoPlayer,
        activeFile: FileEntity,
        isVideo: Boolean
    ): MediaSession {
        val existing = mediaSession
        if (existing != null && attachedExoPlayer === exoPlayer) {
            val pi = buildContentPendingIntent(activeFile.id, isVideo)
            existing.setSessionActivity(pi)
            return existing
        }

        existing?.release()
        attachedExoPlayer = exoPlayer

        val forwardingPlayer = object : ForwardingPlayer(exoPlayer) {
            override fun getAvailableCommands(): Player.Commands {
                return super.getAvailableCommands().buildUpon()
                    .addAll(
                        Player.COMMAND_PLAY_PAUSE,
                        Player.COMMAND_SEEK_BACK,
                        Player.COMMAND_SEEK_FORWARD,
                        Player.COMMAND_SEEK_IN_CURRENT_MEDIA_ITEM,
                        Player.COMMAND_SEEK_TO_PREVIOUS,
                        Player.COMMAND_SEEK_TO_PREVIOUS_MEDIA_ITEM,
                        Player.COMMAND_SEEK_TO_NEXT,
                        Player.COMMAND_SEEK_TO_NEXT_MEDIA_ITEM
                    )
                    .build()
            }

            override fun isCommandAvailable(command: Int): Boolean {
                return when (command) {
                    Player.COMMAND_SEEK_TO_PREVIOUS,
                    Player.COMMAND_SEEK_TO_PREVIOUS_MEDIA_ITEM -> ClodyPlaybackController.hasPrevious()
                    Player.COMMAND_SEEK_TO_NEXT,
                    Player.COMMAND_SEEK_TO_NEXT_MEDIA_ITEM -> ClodyPlaybackController.hasNext()
                    Player.COMMAND_PLAY_PAUSE -> true
                    else -> super.isCommandAvailable(command)
                }
            }

            override fun hasPreviousMediaItem(): Boolean = ClodyPlaybackController.hasPrevious()
            override fun hasNextMediaItem(): Boolean = ClodyPlaybackController.hasNext()

            override fun seekToPrevious() {
                ClodyPlaybackController.skipToPrevious(this@ClodyMediaPlaybackService)
            }

            override fun seekToPreviousMediaItem() {
                ClodyPlaybackController.skipToPrevious(this@ClodyMediaPlaybackService)
            }

            override fun seekToNext() {
                ClodyPlaybackController.skipToNext(this@ClodyMediaPlaybackService)
            }

            override fun seekToNextMediaItem() {
                ClodyPlaybackController.skipToNext(this@ClodyMediaPlaybackService)
            }

            override fun play() {
                ClodyPlaybackController.playWithFocus(this@ClodyMediaPlaybackService)
            }

            override fun pause() {
                super.pause()
                syncNotification(this@ClodyMediaPlaybackService)
            }
        }

        val session = MediaSession.Builder(this, forwardingPlayer)
            .setId("clody_media_session_${System.currentTimeMillis()}")
            .setSessionActivity(buildContentPendingIntent(activeFile.id, isVideo))
            .build()
        mediaSession = session
        return session
    }

    private fun buildContentPendingIntent(fileId: Long, isVideo: Boolean): PendingIntent {
        val intent = buildOpenPlayerIntent(this, fileId, isVideo)
        return PendingIntent.getActivity(
            this,
            901,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun buildActionPendingIntent(actionName: String, requestCode: Int): PendingIntent {
        val intent = Intent(this, ClodyMediaPlaybackService::class.java).apply {
            action = actionName
        }
        return PendingIntent.getService(
            this,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun buildPlaybackNotification(
        file: FileEntity,
        isVideo: Boolean,
        isPlaying: Boolean,
        artworkBitmap: Bitmap?,
        session: MediaSession
    ): Notification {
        val contentIntent = buildContentPendingIntent(file.id, isVideo)
        val prevIntent = buildActionPendingIntent(ACTION_PREVIOUS, 911)
        val playPauseIntent = buildActionPendingIntent(ACTION_PLAY_PAUSE, 912)
        val nextIntent = buildActionPendingIntent(ACTION_NEXT, 913)
        val stopIntent = buildActionPendingIntent(ACTION_STOP_PLAYBACK, 914)

        val playPauseIcon = if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
        val playPauseLabel = if (isPlaying) "Pause" else "Play"

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_clody_media_notification)
            .setContentTitle(file.name)
            .setContentText("Clody Cloud")
            .setSubText(if (isVideo) "Video" else "Audio")
            .setLargeIcon(artworkBitmap)
            .setContentIntent(contentIntent)
            .setDeleteIntent(stopIntent)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(isPlaying)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(android.R.drawable.ic_media_previous, "Previous", prevIntent)
            .addAction(playPauseIcon, playPauseLabel, playPauseIntent)
            .addAction(android.R.drawable.ic_media_next, "Next", nextIntent)
            .setStyle(
                MediaStyleNotificationHelper.MediaStyle(session)
                    .setShowActionsInCompactView(0, 1, 2)
            )

        return builder.build()
    }

    private fun startForegroundCompat(notification: Notification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Media Playback",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Background audio and video playback controls for Clody"
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                setShowBadge(false)
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm?.createNotificationChannel(channel)
        }
    }
}
