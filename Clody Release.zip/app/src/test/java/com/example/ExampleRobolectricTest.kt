package com.example

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.AudioManager
import android.net.Uri
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.SpringSpec
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.ClodyDatabase
import com.example.data.local.DownloadRecordEntity
import com.example.data.local.FileEntity
import com.example.data.local.FolderEntity
import com.example.data.local.GalleryAlbumEntity
import com.example.data.local.UploadStatus
import com.example.data.local.UploadTaskEntity
import com.example.media.DocumentParser
import com.example.media.LocalFirstResolver
import com.example.media.MediaPlaybackOrigin
import com.example.media.ResolvedMediaSource
import com.example.media.WordBlock
import com.example.data.local.SecureStorage
import com.example.service.computeTransferBatchSummary
import com.example.service.isGalleryMimeType
import com.example.telegram.TelegramAuthStep
import com.example.telegram.TelegramClientManager
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.test.runTest
import org.drinkless.tdlib.Client
import org.drinkless.tdlib.TdApi
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Before
    fun resetDatabase() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = ClodyDatabase.getInstance(context)
        val dao = db.clodyDao()
        dao.clearAllFiles()
        dao.clearAllFolders()
        dao.clearAllAlbums()
        db.openHelper.writableDatabase.execSQL("DELETE FROM upload_tasks")
        db.openHelper.writableDatabase.execSQL("DELETE FROM download_records")
    }

    @Test
    fun `app name is Clody`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Clody", appName)
    }

    @Test
    fun `database starts completely empty with zero mock files`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = ClodyDatabase.getInstance(context)
        val files = db.clodyDao().observeActiveFiles().first()
        val folders = db.clodyDao().observeAllFolders().first()
        assertTrue(files.isEmpty())
        assertTrue(folders.isEmpty())
    }

    @Test
    fun `gallery strictly isolates images and videos from audio docs and binaries`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = ClodyDatabase.getInstance(context)
        val dao = db.clodyDao()

        dao.insertFile(FileEntity(name = "photo.jpg", extension = "jpg", sizeBytes = 100, mimeType = "image/jpeg"))
        dao.insertFile(FileEntity(name = "clip.mp4", extension = "mp4", sizeBytes = 200, mimeType = "video/mp4"))
        dao.insertFile(FileEntity(name = "song.mp3", extension = "mp3", sizeBytes = 300, mimeType = "audio/mpeg"))
        dao.insertFile(FileEntity(name = "report.pdf", extension = "pdf", sizeBytes = 400, mimeType = "application/pdf"))
        dao.insertFile(FileEntity(name = "budget.xlsx", extension = "xlsx", sizeBytes = 500, mimeType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
        dao.insertFile(FileEntity(name = "app.apk", extension = "apk", sizeBytes = 600, mimeType = "application/vnd.android.package-archive"))

        val gallery = dao.observeGalleryMedia().first()
        assertEquals(2, gallery.size)
        assertTrue(gallery.all { it.isImage || it.isVideo })
    }

    @Test
    fun `file entity detects audio pdf word spreadsheet text and binary types`() {
        val audio = FileEntity(name = "track.flac", extension = "flac", sizeBytes = 10, mimeType = "audio/flac")
        val pdf = FileEntity(name = "spec.pdf", extension = "pdf", sizeBytes = 10, mimeType = "application/pdf")
        val docx = FileEntity(name = "memo.docx", extension = "docx", sizeBytes = 10, mimeType = "application/vnd.openxmlformats-officedocument.wordprocessingml.document")
        val xlsx = FileEntity(name = "sheet.xlsx", extension = "xlsx", sizeBytes = 10, mimeType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
        val md = FileEntity(name = "README.md", extension = "md", sizeBytes = 10, mimeType = "text/plain")
        val apk = FileEntity(name = "build.apk", extension = "apk", sizeBytes = 10, mimeType = "application/vnd.android.package-archive")

        assertTrue(audio.isAudio)
        assertFalse(audio.isInAppDocument)
        assertTrue(pdf.isPdf && pdf.isInAppDocument)
        assertTrue(docx.isWordDoc && docx.isInAppDocument)
        assertTrue(xlsx.isSpreadsheet && xlsx.isInAppDocument)
        assertTrue(md.isTextOrCode && md.isInAppDocument)
        assertTrue(apk.isApp && !apk.isInAppDocument && !apk.isAudio)
    }

    @Test
    fun `local first resolver returns on device when file exists and cloud fallback when deleted`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val tempFile = File(context.cacheDir, "local_first_test.txt").apply {
            writeText("Hello Clody Local-First")
        }
        val entity = FileEntity(
            name = "local_first_test.txt",
            extension = "txt",
            sizeBytes = tempFile.length(),
            mimeType = "text/plain",
            localSourceUri = Uri.fromFile(tempFile).toString(),
            telegramDocumentId = 123456L
        )

        val firstResolve = LocalFirstResolver.resolve(context, entity)
        assertTrue(firstResolve is ResolvedMediaSource.LocalDevice)
        assertEquals(MediaPlaybackOrigin.ON_DEVICE, firstResolve.origin)

        assertTrue(tempFile.delete())

        val secondResolve = LocalFirstResolver.resolve(context, entity)
        assertTrue(secondResolve is ResolvedMediaSource.CloudStream)
        assertEquals(MediaPlaybackOrigin.CLOUD_STREAM, secondResolve.origin)
    }

    @Test
    fun `document parser handles csv docx and xlsx accurately`() {
        val context = ApplicationProvider.getApplicationContext<Context>()

        // 1. CSV
        val csvFile = File(context.cacheDir, "test_data.csv").apply {
            writeText("Name,Role,City\n\"Rahman, A.\",Engineer,Dhaka\nSara,Designer,Chattogram\n")
        }
        val csvSheets = DocumentParser.parseCsv(csvFile)
        assertEquals(1, csvSheets.size)
        assertEquals(3, csvSheets[0].rows.size)
        assertEquals("Rahman, A.", csvSheets[0].rows[1][0])
        assertEquals("Dhaka", csvSheets[0].rows[1][2])
        csvFile.delete()

        // 2. DOCX
        val docxFile = File(context.cacheDir, "test_doc.docx")
        ZipOutputStream(FileOutputStream(docxFile)).use { zos ->
            zos.putNextEntry(ZipEntry("word/document.xml"))
            zos.write(
                """
                <w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
                  <w:body>
                    <w:p><w:pPr><w:pStyle w:val="Heading1"/></w:pPr><w:r><w:t>Project Summary</w:t></w:r></w:p>
                    <w:p><w:r><w:t>Clody stores files cleanly.</w:t></w:r></w:p>
                  </w:body>
                </w:document>
                """.trimIndent().toByteArray(Charsets.UTF_8)
            )
            zos.closeEntry()
        }
        val blocks = DocumentParser.parseDocx(docxFile)
        assertTrue(blocks.any { it is WordBlock.Heading && it.text == "Project Summary" })
        assertTrue(blocks.any { it is WordBlock.Paragraph && it.text == "Clody stores files cleanly." })
        docxFile.delete()

        // 3. XLSX
        val xlsxFile = File(context.cacheDir, "test_sheet.xlsx")
        ZipOutputStream(FileOutputStream(xlsxFile)).use { zos ->
            zos.putNextEntry(ZipEntry("xl/sharedStrings.xml"))
            zos.write("""<sst><si><t>Item</t></si><si><t>Count</t></si></sst>""".toByteArray())
            zos.closeEntry()
            zos.putNextEntry(ZipEntry("xl/worksheets/sheet1.xml"))
            zos.write(
                """
                <worksheet>
                  <sheetData>
                    <row r="1"><c r="A1" t="s"><v>0</v></c><c r="B1" t="s"><v>1</v></c></row>
                    <row r="2"><c r="A2" t="inlineStr"><is><t>Photos</t></is></c><c r="B2"><v>42</v></c></row>
                  </sheetData>
                </worksheet>
                """.trimIndent().toByteArray()
            )
            zos.closeEntry()
        }
        val xlsxSheets = DocumentParser.parseXlsx(xlsxFile)
        assertEquals(1, xlsxSheets.size)
        assertEquals(listOf("Item", "Count"), xlsxSheets[0].rows[0])
        assertEquals(listOf("Photos", "42"), xlsxSheets[0].rows[1])
        xlsxFile.delete()
    }

    @Test
    fun `tdlib error formatter translates telegram error codes clearly`() {
        val apiErr = TelegramClientManager.formatTdError(TdApi.Error(400, "API_ID_INVALID"))
        assertTrue(apiErr.contains("API_ID_INVALID"))

        val phoneErr = TelegramClientManager.formatTdError(TdApi.Error(400, "PHONE_NUMBER_INVALID"))
        assertTrue(phoneErr.contains("PHONE_NUMBER_INVALID"))

        val codeErr = TelegramClientManager.formatTdError(TdApi.Error(400, "PHONE_CODE_INVALID"))
        assertTrue(codeErr.contains("PHONE_CODE_INVALID"))

        val pwdErr = TelegramClientManager.formatTdError(TdApi.Error(400, "PASSWORD_HASH_INVALID"))
        assertTrue(pwdErr.contains("PASSWORD_HASH_INVALID"))

        val floodErr = TelegramClientManager.formatTdError(TdApi.Error(429, "FLOOD_WAIT_42"))
        assertTrue(floodErr.contains("FLOOD_WAIT_42"))
        assertTrue(floodErr.contains("42 seconds"))
    }

    @Test
    fun `tdlib client and tdapi constructors initialize cleanly without crashing`() {
        val params = TdApi.SetTdlibParameters(
            false,
            "/tmp/tdlib_db",
            "/tmp/tdlib_files",
            ByteArray(0),
            true,
            true,
            true,
            false,
            12345,
            "0123456789abcdef0123456789abcdef",
            "en",
            "Pixel",
            "Android 15",
            "1.0.0"
        )
        assertEquals(12345, params.apiId)
        assertTrue(params.useMessageDatabase)
        assertTrue(params.useFileDatabase)
        assertFalse(params.useSecretChats)

        val channelReq = TdApi.CreateNewSupergroupChat(
            "Clody Cloud Storage",
            false,
            true,
            "Private cloud storage managed by Clody",
            null,
            0,
            false
        )
        assertTrue(channelReq.isChannel)
        assertEquals("Clody Cloud Storage", channelReq.title)
    }

    @Test
    fun `gallery albums stay isolated from file folders and track favorites and trash`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = ClodyDatabase.getInstance(context)
        val dao = db.clodyDao()

        val folderId = dao.insertFolder(FolderEntity(name = "WorkDocs"))
        val albumId = dao.insertAlbum(GalleryAlbumEntity(name = "Summer Trips"))

        val photoId = dao.insertFile(
            FileEntity(
                name = "beach.jpg",
                extension = "jpg",
                sizeBytes = 1000,
                mimeType = "image/jpeg",
                folderId = null,
                albumId = null,
                isFavorite = true
            )
        )
        val videoId = dao.insertFile(
            FileEntity(
                name = "sunset.mp4",
                extension = "mp4",
                sizeBytes = 2000,
                mimeType = "video/mp4",
                folderId = folderId
            )
        )
        dao.insertFile(
            FileEntity(
                name = "notes.pdf",
                extension = "pdf",
                sizeBytes = 500,
                mimeType = "application/pdf",
                folderId = folderId,
                isFavorite = true
            )
        )

        dao.setFileAlbum(photoId, albumId)
        val albumItems = dao.observeFilesInAlbum(albumId).first()
        assertEquals(1, albumItems.size)
        assertEquals("beach.jpg", albumItems[0].name)

        // Gallery favorites only includes visual media, not PDF
        val favMedia = dao.observeFavoriteGalleryMedia().first()
        assertEquals(1, favMedia.size)
        assertEquals("beach.jpg", favMedia[0].name)

        // Folders remain strictly untouched by albums
        assertEquals(1, dao.observeAllFolders().first().size)
        assertEquals(1, dao.observeGalleryAlbums().first().size)

        // Soft-delete moves video to Gallery Trash
        dao.softDeleteFile(videoId)
        val trashMedia = dao.observeDeletedGalleryMedia().first()
        assertEquals(1, trashMedia.size)
        assertEquals("sunset.mp4", trashMedia[0].name)
    }

    @Test
    fun `unified batch progress stays monotonic as earlier items finish and auto vanish`() = runTest {
        val up1 = UploadTaskEntity(
            id = 1,
            fileName = "photo1.jpg",
            localUriString = "file:///tmp/1.jpg",
            mimeType = "image/jpeg",
            sizeBytes = 100L,
            bytesUploaded = 100L,
            speedBytesPerSec = 0L,
            status = UploadStatus.COMPLETED.name
        )
        val up2 = UploadTaskEntity(
            id = 2,
            fileName = "clip.mp4",
            localUriString = "file:///tmp/2.mp4",
            mimeType = "video/mp4",
            sizeBytes = 100L,
            bytesUploaded = 0L,
            speedBytesPerSec = 50L,
            status = UploadStatus.UPLOADING.name
        )
        val dl1 = DownloadRecordEntity(
            id = 10,
            fileId = 5,
            fileName = "report.pdf",
            sizeBytes = 200L,
            mimeType = "application/pdf",
            status = "DOWNLOADING",
            progressBytes = 100L
        )

        // Step 1: up1 at 100%, up2 at 0%, dl1 at 50% -> 200 / 400 = 50%
        val mid = computeTransferBatchSummary(
            activeUploads = listOf(up1, up2),
            activeDownloads = listOf(dl1),
            downloadSpeeds = mapOf(10L to 25L),
            completedBatchBytes = 0L
        )
        assertEquals(3, mid.activeCount)
        assertEquals(2, mid.galleryActiveCount)
        assertEquals(1, mid.filesActiveCount)
        assertEquals(400L, mid.totalBatchBytes)
        assertEquals(200L, mid.transferredBatchBytes)
        assertEquals(50, mid.overallPercent)
        assertEquals(75L, mid.combinedSpeedBytesPerSec)

        // Step 2: up1 auto-vanishes (deleted from DB), its 100L moves to completedBatchBytes -> still 50%!
        val afterVanish = computeTransferBatchSummary(
            activeUploads = listOf(up2),
            activeDownloads = listOf(dl1),
            downloadSpeeds = mapOf(10L to 25L),
            completedBatchBytes = 100L
        )
        assertEquals(2, afterVanish.activeCount)
        assertEquals(400L, afterVanish.totalBatchBytes)
        assertEquals(200L, afterVanish.transferredBatchBytes)
        assertEquals(50, afterVanish.overallPercent)

        // Step 3: DAO auto-vanish delete clears active queue cleanly
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = ClodyDatabase.getInstance(context)
        val dao = db.clodyDao()
        val insertedId = dao.insertUploadTask(up2.copy(id = 0))
        assertEquals(1, dao.observeActiveUploadTasks().first().size)
        dao.deleteUploadTaskById(insertedId)
        assertTrue(dao.observeActiveUploadTasks().first().isEmpty())
        assertTrue(isGalleryMimeType("video/mp4"))
        assertFalse(isGalleryMimeType("application/pdf"))
    }

    @Test
    fun `three step auth validates api id and 32 char hex hash before phone entry`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = ClodyDatabase.getInstance(context)
        val storage = SecureStorage(context)
        storage.clearAll()
        val manager = com.example.telegram.TelegramClientManager(context, storage, db.clodyDao())

        assertTrue(manager.authStep.value is com.example.telegram.TelegramAuthStep.VerifyApiCredentials)

        val badId = manager.verifyApiCredentials(0, "0123456789abcdef0123456789abcdef")
        assertTrue(badId.isFailure)
        assertTrue(badId.exceptionOrNull()?.message?.contains("positive integer") == true)

        val badHash = manager.verifyApiCredentials(12345, "not-a-valid-hash")
        assertTrue(badHash.isFailure)
        assertTrue(badHash.exceptionOrNull()?.message?.contains("32-character hexadecimal") == true)

        manager.editApiCredentials()
        assertTrue(manager.authStep.value is com.example.telegram.TelegramAuthStep.VerifyApiCredentials)
    }

    @Test
    fun `cloud index snapshot round-trips nested folders albums trash and favorites via dao helpers`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = ClodyDatabase.getInstance(context)
        val dao = db.clodyDao()

        val rootFolderId = dao.insertFolder(FolderEntity(name = "Work"))
        val childFolderId = dao.insertFolder(FolderEntity(name = "2026", parentId = rootFolderId))
        val albumId = dao.insertAlbum(GalleryAlbumEntity(name = "Highlights"))

        val activeId = dao.insertFile(
            FileEntity(
                name = "deck.pdf",
                extension = "pdf",
                sizeBytes = 2048L,
                mimeType = "application/pdf",
                folderId = childFolderId,
                folderPath = "Cloud / Work / 2026",
                telegramMessageId = 701,
                telegramAccessHash = 99001L,
                isFavorite = true
            )
        )
        dao.insertFile(
            FileEntity(
                name = "clip.mp4",
                extension = "mp4",
                sizeBytes = 4096L,
                mimeType = "video/mp4",
                albumId = albumId,
                telegramMessageId = 702,
                telegramAccessHash = 99002L,
                isDeleted = true,
                deletedAt = 1700000000000L
            )
        )
        dao.insertUploadTask(
            UploadTaskEntity(
                fileName = "deck.pdf",
                localUriString = "file:///tmp/deck.pdf",
                mimeType = "application/pdf",
                sizeBytes = 2048L,
                folderId = childFolderId,
                folderPath = "Cloud / Work / 2026"
            )
        )

        val allFilesIncludingTrash = dao.getAllFilesOnceIncludingTrash()
        assertEquals(2, allFilesIncludingTrash.size)
        assertEquals(activeId, dao.getFileByTelegramDocOrMsg(701, 99001L)?.id)
        assertEquals("Cloud / Work / 2026", dao.getLatestUploadTaskByNameAndSize("deck.pdf", 2048L)?.folderPath)

        val json = kotlinx.serialization.json.Json { ignoreUnknownKeys = true; encodeDefaults = true }
        val snapshot = com.example.telegram.CloudIndexSnapshot(
            folders = dao.getAllFoldersOnce(),
            albums = dao.getAllAlbumsOnce(),
            files = allFilesIncludingTrash
        )
        val decoded = json.decodeFromString<com.example.telegram.CloudIndexSnapshot>(
            json.encodeToString(com.example.telegram.CloudIndexSnapshot.serializer(), snapshot)
        )
        assertEquals(2, decoded.folders.size)
        assertEquals(1, decoded.albums.size)
        assertEquals(2, decoded.files.size)
        assertTrue(decoded.files.any { it.isDeleted && it.albumId == albumId })
    }

    @Test
    fun `file manager root excludes gallery timeline clutter while categories still include all matching files`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = ClodyDatabase.getInstance(context)
        val dao = db.clodyDao()

        val studyId = dao.insertFolder(FolderEntity(name = "Study"))
        val electricalId = dao.insertFolder(FolderEntity(name = "Electrical", parentId = studyId))
        val notesId = dao.insertFolder(FolderEntity(name = "Notes", parentId = electricalId))

        // Gallery timeline upload (folderPath = "Gallery", folderId = null) -> MUST NOT appear in File Manager root
        val galleryPhotoId = dao.insertFile(
            FileEntity(
                name = "holiday.jpg",
                extension = "jpg",
                sizeBytes = 1024L,
                mimeType = "image/jpeg",
                folderId = null,
                folderPath = "Gallery"
            )
        )
        // Explicit File Manager root upload (folderPath = "Cloud", folderId = null)
        dao.insertFile(
            FileEntity(
                name = "diagram.png",
                extension = "png",
                sizeBytes = 2048L,
                mimeType = "image/png",
                folderId = null,
                folderPath = "Cloud"
            )
        )
        // Nested subfolder files + varied types for 7 categories
        dao.insertFile(
            FileEntity(
                name = "circuits.pdf",
                extension = "pdf",
                sizeBytes = 4096L,
                mimeType = "application/pdf",
                folderId = notesId,
                folderPath = "Cloud / Study / Electrical / Notes",
                isFavorite = true
            )
        )
        dao.insertFile(
            FileEntity(
                name = "podcast.mp3",
                extension = "mp3",
                sizeBytes = 512L,
                mimeType = "audio/mpeg",
                folderId = studyId,
                folderPath = "Cloud / Study"
            )
        )
        dao.insertFile(
            FileEntity(
                name = "backup.zip",
                extension = "zip",
                sizeBytes = 3072L,
                mimeType = "application/zip",
                folderId = studyId,
                folderPath = "Cloud / Study"
            )
        )
        dao.insertFile(
            FileEntity(
                name = "tool.apk",
                extension = "apk",
                sizeBytes = 8192L,
                mimeType = "application/vnd.android.package-archive",
                folderId = null,
                folderPath = "Cloud"
            )
        )

        val rootFiles = dao.observeFileManagerFilesInFolder(null).first()
        assertTrue(rootFiles.isEmpty())

        val nestedFiles = dao.observeFileManagerFilesInFolder(notesId).first()
        assertEquals(1, nestedFiles.size)
        assertEquals("circuits.pdf", nestedFiles[0].name)

        val galleryMedia = dao.observeGalleryMedia().first()
        assertEquals(2, galleryMedia.size)

        val activeFiles = dao.observeActiveFiles().first()
        assertEquals(2, activeFiles.count { com.example.ui.FileManagerCategory.IMAGES.matches(it) })
        assertEquals(0, activeFiles.count { com.example.ui.FileManagerCategory.VIDEOS.matches(it) })
        assertEquals(1, activeFiles.count { com.example.ui.FileManagerCategory.AUDIO.matches(it) })
        assertEquals(1, activeFiles.count { com.example.ui.FileManagerCategory.DOCUMENTS.matches(it) })
        assertEquals(1, activeFiles.count { com.example.ui.FileManagerCategory.APKS.matches(it) })
        assertEquals(1, activeFiles.count { com.example.ui.FileManagerCategory.ARCHIVES.matches(it) })
        assertEquals(1, activeFiles.count { com.example.ui.FileManagerCategory.TAGS.matches(it) })

        // Explicitly moving holiday.jpg into Notes makes it appear in File Manager inside Notes
        dao.moveFilesToFolder(listOf(galleryPhotoId), notesId, "Cloud / Study / Electrical / Notes")
        assertEquals(2, dao.observeFileManagerFilesInFolder(notesId).first().size)
    }

    @Test
    fun `original date extraction and private shared cache clearing work cleanly`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = ClodyDatabase.getInstance(context)
        val dao = db.clodyDao()
        val dfm = com.example.files.DeviceFileManager(context)

        val tempMedia = File(context.cacheDir, "vintage_shot.jpg").apply {
            writeBytes(byteArrayOf(1, 2, 3, 4))
            setLastModified(1609459200000L) // 2021-01-01 00:00:00 UTC
        }
        val extractedMs = dfm.extractOriginalMediaDateMs(Uri.fromFile(tempMedia))
        assertEquals(1609459200000L, extractedMs)
        tempMedia.delete()

        val tm = com.example.service.TransferManager(
            context = context,
            dao = dao,
            telegramClient = TelegramClientManager(context, SecureStorage(context), dao)
        )
        val sharedDir = tm.getSharedCacheDir()
        assertTrue(sharedDir.absolutePath.startsWith(context.cacheDir.absolutePath))
        assertEquals("shared_cache", sharedDir.name)

        val dummyCached = File(sharedDir, "10_clip.mp4").apply {
            writeBytes(ByteArray(128))
        }
        assertTrue(dummyCached.exists())
        val freed = tm.clearSharedCache()
        assertTrue(freed >= 128L)
        assertFalse(dummyCached.exists())
    }

    @Test
    fun `stream cache calculation and clear preserve tdlib db index thumbnails pinned offline and pending uploads`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()

        // Clean slate first
        com.example.media.ClodyStreamCache.clearAllStreamCache(context, includeSharedCache = true)

        // Protected files that MUST NEVER be deleted
        val tdDbFile = File(File(context.filesDir, "tdlib_db").apply { mkdirs() }, "td.binlog").apply {
            writeBytes(ByteArray(64))
        }
        val tdIndexFile = File(File(context.filesDir, "tdlib_files/temp").apply { mkdirs() }, "clody_index.json").apply {
            writeText("{\"v\":1}")
        }
        val thumbFile = File(File(context.filesDir, "thumbnails").apply { mkdirs() }, "thumb_1.jpg").apply {
            writeBytes(ByteArray(128))
        }
        val pinnedFile = File(File(context.filesDir, "pinned_offline").apply { mkdirs() }, "pinned_1_video.mp4").apply {
            writeBytes(ByteArray(256))
        }
        val pendingUploadFile = File(File(context.filesDir, "pending_uploads").apply { mkdirs() }, "upload_1_doc.pdf").apply {
            writeBytes(ByteArray(512))
        }

        // Transient stream & TDLib media temp files that MUST be counted and deleted
        val tdVideoTemp = File(File(context.filesDir, "tdlib_files/videos").apply { mkdirs() }, "stream.mp4").apply {
            writeBytes(ByteArray(1000))
        }
        val tdPhotoTemp = File(File(context.filesDir, "tdlib_files/photos").apply { mkdirs() }, "img.jpg").apply {
            writeBytes(ByteArray(500))
        }
        val streamCacheFile = File(com.example.media.ClodyStreamCache.getCacheDir(context), "stream_99.mp4").apply {
            writeBytes(ByteArray(2000))
        }
        val shareCacheFile = File(File(context.cacheDir, "shared_cache").apply { mkdirs() }, "share.jpg").apply {
            writeBytes(ByteArray(300))
        }

        val currentBytes = com.example.media.ClodyStreamCache.getCurrentCacheBytes(context)
        assertEquals(3800L, currentBytes)

        val freed = com.example.media.ClodyStreamCache.clearAllStreamCache(context, includeSharedCache = true)
        assertEquals(3800L, freed)
        assertEquals(0L, com.example.media.ClodyStreamCache.getCurrentCacheBytes(context))

        // Transient files deleted
        assertFalse(tdVideoTemp.exists())
        assertFalse(tdPhotoTemp.exists())
        assertFalse(streamCacheFile.exists())
        assertFalse(shareCacheFile.exists())

        // Protected files untouched
        assertTrue(tdDbFile.exists())
        assertTrue(tdIndexFile.exists())
        assertTrue(thumbFile.exists())
        assertTrue(pinnedFile.exists())
        assertTrue(pendingUploadFile.exists())
    }

    @Test
    fun `settings repository persists auto delete cache on exit and upload wifi only policy`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = com.example.data.local.SettingsRepository(context)

        repo.setAutoDeleteCacheOnExit(true)
        repo.setUploadWifiOnly(true)
        val afterEnable = repo.settingsFlow.first()
        assertTrue(afterEnable.autoDeleteCacheOnExit)
        assertTrue(afterEnable.uploadWifiOnly)

        repo.setAutoDeleteCacheOnExit(false)
        repo.setUploadWifiOnly(false)
        val afterDisable = repo.settingsFlow.first()
        assertFalse(afterDisable.autoDeleteCacheOnExit)
        assertFalse(afterDisable.uploadWifiOnly)
    }

    @Test
    fun `dao system-paused uploads auto-resume with byte offset and tdFileId while manual pauses stay paused`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = ClodyDatabase.getInstance(context)
        val dao = db.clodyDao()

        val activeId = dao.insertUploadTask(
            UploadTaskEntity(
                fileName = "big_video.mp4",
                localUriString = "content://media/1",
                mimeType = "video/mp4",
                sizeBytes = 10_000L,
                bytesUploaded = 4_096L,
                status = UploadStatus.UPLOADING.name,
                tdFileId = 777,
                stagedFilePath = "/tmp/pending_uploads/upload_1_big_video.mp4"
            )
        )
        val userPausedId = dao.insertUploadTask(
            UploadTaskEntity(
                fileName = "manual_pause.zip",
                localUriString = "content://media/2",
                mimeType = "application/zip",
                sizeBytes = 5_000L,
                bytesUploaded = 1_000L,
                status = UploadStatus.UPLOADING.name
            )
        )
        dao.pauseUploadByUser(userPausedId)

        // Simulate app close / swipe from Recents -> marks only active uploads as system-paused
        dao.markActiveUploadsSystemPaused("Paused on close")
        val allAfterClose = dao.observeUploadTasks().first()
        val activeAfterClose = allAfterClose.first { it.id == activeId }
        val manualAfterClose = allAfterClose.first { it.id == userPausedId }
        assertEquals(UploadStatus.PAUSED.name, activeAfterClose.status)
        assertTrue(activeAfterClose.pausedBySystem)
        assertEquals(4_096L, activeAfterClose.bytesUploaded)
        assertEquals(777, activeAfterClose.tdFileId)
        assertEquals("/tmp/pending_uploads/upload_1_big_video.mp4", activeAfterClose.stagedFilePath)
        assertEquals(UploadStatus.PAUSED.name, manualAfterClose.status)
        assertFalse(manualAfterClose.pausedBySystem)

        // Reopen Clody -> system-paused upload auto-resumes to QUEUED preserving offset; user-paused stays PAUSED
        dao.resumeSystemPausedUploads()
        val allAfterReopen = dao.observeUploadTasks().first()
        val activeAfterReopen = allAfterReopen.first { it.id == activeId }
        val manualAfterReopen = allAfterReopen.first { it.id == userPausedId }
        assertEquals(UploadStatus.QUEUED.name, activeAfterReopen.status)
        assertFalse(activeAfterReopen.pausedBySystem)
        assertEquals(4_096L, activeAfterReopen.bytesUploaded)
        assertEquals(777, activeAfterReopen.tdFileId)
        assertEquals(UploadStatus.PAUSED.name, manualAfterReopen.status)
    }

    @Test
    fun `thumbnail generator downsamples with power-of-two inSampleSize bounds and caches bytes`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()

        // Heap-bounded LRU (~1/8th heap, at least 4MB)
        assertTrue(com.example.media.ThumbnailGenerator.getMemoryCacheMaxSizeKb() >= 4096)

        // Power-of-two sample size math (returns largest power-of-2 keeping width & height >= req)
        assertEquals(1, com.example.media.ThumbnailGenerator.calculateInSampleSize(300, 300, 320, 320))
        assertEquals(2, com.example.media.ThumbnailGenerator.calculateInSampleSize(1024, 1024, 320, 320))
        assertEquals(4, com.example.media.ThumbnailGenerator.calculateInSampleSize(1600, 1600, 320, 320))

        // Real compressed bitmap decode + memory cache round-trip
        val bmp = Bitmap.createBitmap(640, 640, Bitmap.Config.ARGB_8888)
        val baos = java.io.ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 80, baos)
        val bytes = baos.toByteArray()
        bmp.recycle()

        val decoded = com.example.media.ThumbnailGenerator.decodeBytesAsync(
            cacheKey = "test_sample_thumb_640",
            bytes = bytes,
            maxSizePx = 160
        )
        assertTrue(decoded != null)
        assertTrue((decoded?.width ?: 999) <= 320)
        assertTrue(com.example.media.ThumbnailGenerator.getFromMemoryCache("test_sample_thumb_640") != null)

        // Safe null fallback when audio file has no embedded ID3 cover
        val plainAudio = File(context.cacheDir, "empty_audio.mp3").apply { writeBytes(byteArrayOf(1, 2, 3, 4)) }
        val cover = com.example.media.ThumbnailGenerator.extractEmbeddedAudioCoverAsync(
            context = context,
            filePath = plainAudio.absolutePath,
            contentUri = null,
            cacheKey = "test_no_id3"
        )
        assertEquals(null, cover)
        plainAudio.delete()
    }

    @Test
    fun `tdlib audio cover extractors read albumCoverMinithumbnail and albumCoverThumbnail from MessageAudio`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = ClodyDatabase.getInstance(context)
        val storage = SecureStorage(context)
        val manager = TelegramClientManager(context, storage, db.clodyDao())

        val expectedMini = byteArrayOf(10, 20, 30)
        val expectedThumbFile = TdApi.File().apply { id = 8899 }
        val tdAudio = TdApi.Audio().apply {
            albumCoverMinithumbnail = TdApi.Minithumbnail().apply { data = expectedMini }
            albumCoverThumbnail = TdApi.Thumbnail().apply { file = expectedThumbFile }
        }
        val msg = TdApi.Message().apply {
            content = TdApi.MessageAudio().apply { audio = tdAudio }
        }

        assertEquals(expectedMini, manager.extractMinithumbnailBytesFromMessage(msg))
        assertEquals(8899, manager.extractThumbnailTdFileFromMessage(msg)?.id)
    }

    @Test
    fun `background playback notification intent and audio focus transitions behave safely`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val openVideoIntent = com.example.service.ClodyMediaPlaybackService.buildOpenPlayerIntent(
            context = context,
            fileId = 42L,
            isVideo = true
        )
        assertTrue((openVideoIntent.flags and Intent.FLAG_ACTIVITY_SINGLE_TOP) != 0)
        assertTrue(openVideoIntent.getBooleanExtra(com.example.service.ClodyMediaPlaybackService.EXTRA_OPEN_ACTIVE_PLAYER, false))
        assertEquals(42L, openVideoIntent.getLongExtra(com.example.service.ClodyMediaPlaybackService.EXTRA_OPEN_PLAYER_FILE_ID, -1L))
        assertTrue(openVideoIntent.getBooleanExtra(com.example.service.ClodyMediaPlaybackService.EXTRA_OPEN_PLAYER_IS_VIDEO, false))

        assertFalse(com.example.service.ClodyPlaybackController.shouldPreserveBackgroundPlayback())

        com.example.service.ClodyPlaybackController.handleAudioFocusChange(AudioManager.AUDIOFOCUS_LOSS)
        assertTrue(com.example.service.ClodyPlaybackController.audioFocusPaused.value)

        com.example.service.ClodyPlaybackController.handleAudioFocusChange(AudioManager.AUDIOFOCUS_LOSS_TRANSIENT)
        assertTrue(com.example.service.ClodyPlaybackController.audioFocusPaused.value)

        // Motion uses crisp NoBouncy spring physics
        val spec = com.example.ui.theme.ClodyMotion.defaultSpring<Float>() as? SpringSpec<Float>
        assertEquals(Spring.DampingRatioNoBouncy, spec?.dampingRatio)
        assertEquals(Spring.StiffnessMediumLow, spec?.stiffness)
    }

    @Test
    fun `moving average speed tracker ignores initial burst spikes and computes smooth throughput`() {
        val tracker = com.example.service.MovingAverageSpeedTracker(windowMs = 1_500L, minWarmupMs = 300L)
        tracker.reset(initialBytes = 0L, nowMs = 1_000L)

        // First 200ms TDLib buffer-allocation burst must NOT produce fake 50 MB/s spike
        val earlySpikeSpeed = tracker.recordProgress(totalBytesSent = 2_000_000L, nowMs = 1_150L)
        assertEquals(0L, earlySpikeSpeed)

        // Over the next 1 second (from 1_150ms baseline 2MB -> 2_200ms at 3MB), true throughput is ~1 MB/s
        val steadySpeed = tracker.recordProgress(totalBytesSent = 3_000_000L, nowMs = 2_000L)
        assertTrue(steadySpeed in 500_000L..1_500_000L)
    }

    @Test
    fun `transfer batch tracker deduplicates repeated batch keys and resets counts cleanly on completion`() {
        com.example.service.TransferBatchTracker.clearBanner()

        // Same URI keys enqueued twice (e.g., enqueue + service resume) must NOT inflate totalCount from 2 to 4
        val keys = listOf("content://media/10", "content://media/11")
        com.example.service.TransferBatchTracker.onBatchEnqueued(keys, "a.jpg")
        com.example.service.TransferBatchTracker.onBatchEnqueued(keys, "a.jpg")
        assertEquals(2, com.example.service.TransferBatchTracker.summary.value.totalCount)

        com.example.service.TransferBatchTracker.onFileStarted(
            fileName = "a.jpg",
            totalBytes = 1000L,
            pendingCountInDb = 2,
            taskId = 1L,
            uniqueKey = keys[0]
        )
        com.example.service.TransferBatchTracker.onFileCompleted(remainingInDb = 1, taskId = 1L, uniqueKey = keys[0])
        assertTrue(com.example.service.TransferBatchTracker.summary.value.isActive)
        assertEquals(1, com.example.service.TransferBatchTracker.summary.value.completedCount)

        com.example.service.TransferBatchTracker.onFileCompleted(remainingInDb = 0, taskId = 2L, uniqueKey = keys[1])
        val done = com.example.service.TransferBatchTracker.summary.value
        assertFalse(done.isActive)
        assertEquals(0, done.totalCount)
        assertEquals(0, done.completedCount)
        assertEquals(0L, done.speedBytesPerSec)
    }
}



