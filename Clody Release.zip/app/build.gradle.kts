import com.google.gms.googleservices.GoogleServicesPlugin.MissingGoogleServicesStrategy
import java.net.HttpURLConnection
import java.net.URI
import java.util.zip.ZipFile

plugins {
  alias(libs.plugins.android.application)
  alias(libs.plugins.kotlin.compose)
  alias(libs.plugins.kotlin.serialization)
  alias(libs.plugins.google.devtools.ksp)
  alias(libs.plugins.secrets)
  alias(libs.plugins.google.services)
}

android {
  namespace = "com.example"
  compileSdk { version = release(36) { minorApiLevel = 1 } }

  defaultConfig {
    applicationId = "com.aistudio.clodycloud.m9k2xp"
    minSdk = 24
    targetSdk = 36
    versionCode = 1
    versionName = "1.0"

    testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

    ndk {
      abiFilters += listOf("arm64-v8a")
    }
  }

  // Do not remove or modify these signingConfigs. They are necessary for building, installing,
  // and updating Android apps in AI Studio.
  signingConfigs {
    create("release") {
      val keystorePath = System.getenv("KEYSTORE_PATH") ?: "${rootDir}/my-upload-key.jks"
      storeFile = file(keystorePath)
      storePassword = System.getenv("STORE_PASSWORD")
      keyAlias = "upload"
      keyPassword = System.getenv("KEY_PASSWORD")
    }
    create("debugConfig") {
      storeFile = file("${rootDir}/debug.keystore")
      storePassword = "android"
      keyAlias = "androiddebugkey"
      keyPassword = "android"
    }
  }

  buildTypes {
    release {
      isDebuggable = false
      isCrunchPngs = false
      isMinifyEnabled = true
      isShrinkResources = true
      proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
      // Do not remove or modify this signingConfig assignment. It is necessary for Android apps in
      // AI Studio.
      signingConfig = signingConfigs.getByName("release")
    }
    debug {
      // Do not remove or modify this signingConfig assignment. It is necessary for Android apps in
      // AI Studio.
      signingConfig = signingConfigs.getByName("debugConfig")
    }
  }
  compileOptions {
    sourceCompatibility = JavaVersion.VERSION_11
    targetCompatibility = JavaVersion.VERSION_11
  }
  buildFeatures {
    compose = true
    buildConfig = true
  }
  testOptions { unitTests { isIncludeAndroidResources = true } }
  packaging {
    jniLibs {
      pickFirsts += "**/libtdjni.so"
    }
  }
  dependenciesInfo {
    includeInApk = false
    includeInBundle = true
  }
}

val fetchTdlibNatives by tasks.registering {
  description = "Automatically downloads and extracts official TDLib Android AAR native binaries (libtdjni.so) if missing."
  val jniLibsDir = layout.projectDirectory.dir("src/main/jniLibs")
  val arm64So = jniLibsDir.file("arm64-v8a/libtdjni.so")
  val armv7So = jniLibsDir.file("armeabi-v7a/libtdjni.so")
  outputs.files(arm64So, armv7So)

  doLast {
    val targetArm64 = arm64So.asFile
    val targetArmv7 = armv7So.asFile
    if (targetArm64.exists() && targetArm64.length() > 1024L &&
        targetArmv7.exists() && targetArmv7.length() > 1024L) {
      logger.lifecycle("TDLib native libraries already present in src/main/jniLibs.")
      return@doLast
    }

    val aarUrls = listOf(
      "https://jitpack.io/com/github/tdlibx/td/1.8.56/td-1.8.56.aar",
      "https://jitpack.io/com/github/tdlibx/td/1.8.35/td-1.8.35.aar",
      "https://repo1.maven.org/maven2/io/github/tdlib-android/core/0.1.1/core-0.1.1.aar"
    )

    val tempAar = File(temporaryDir, "tdlib.aar")
    var downloaded = false

    for (urlStr in aarUrls) {
      try {
        logger.lifecycle("Attempting automatic TDLib AAR download from: $urlStr")
        val conn = URI(urlStr).toURL().openConnection() as HttpURLConnection
        conn.connectTimeout = 15_000
        conn.readTimeout = 60_000
        conn.instanceFollowRedirects = true
        conn.setRequestProperty("User-Agent", "Gradle/Clody-TDLib-Fetcher")
        if (conn.responseCode in 200..299) {
          conn.inputStream.use { input ->
            tempAar.outputStream().use { output -> input.copyTo(output) }
          }
          if (tempAar.exists() && tempAar.length() > 100_000L) {
            downloaded = true
            logger.lifecycle("Downloaded TDLib AAR (${tempAar.length() / 1024} KB) from $urlStr")
            break
          }
        } else {
          logger.warn("TDLib mirror returned HTTP ${conn.responseCode} for $urlStr")
        }
      } catch (e: Exception) {
        logger.warn("Could not reach TDLib mirror $urlStr: ${e.message}")
      }
    }

    if (downloaded && tempAar.exists()) {
      ZipFile(tempAar).use { zip ->
        val entries = zip.entries()
        while (entries.hasMoreElements()) {
          val entry = entries.nextElement()
          if (!entry.isDirectory && entry.name.startsWith("jni/") && entry.name.endsWith(".so")) {
            val relPath = entry.name.removePrefix("jni/")
            val outFile = File(jniLibsDir.asFile, relPath)
            outFile.parentFile?.mkdirs()
            zip.getInputStream(entry).use { input ->
              outFile.outputStream().use { output -> input.copyTo(output) }
            }
            logger.lifecycle("Extracted TDLib native binary: jniLibs/$relPath (${outFile.length() / 1024} KB)")
          }
        }
      }
    } else {
      logger.warn("Offline/restricted build environment detected; skipping remote TDLib AAR download.")
    }
  }
}

tasks.named("preBuild").configure {
  dependsOn(fetchTdlibNatives)
}

// Configure the Secrets Gradle Plugin to use .env and .env.example files
// to match the convention used in Web projects.
secrets {
  propertiesFileName = ".env"
  defaultPropertiesFileName = ".env.example"
  ignoreList.add("FIREBASE_APPCHECK_DEBUG_TOKEN")
}

googleServices { missingGoogleServicesStrategy = MissingGoogleServicesStrategy.WARN }

// Some unused dependencies are commented out below instead of being removed.
// This makes it easy to add them back in the future if needed.
dependencies {
  implementation(platform(libs.androidx.compose.bom))
  // implementation(platform(libs.firebase.bom))
  // implementation(libs.accompanist.permissions)
  implementation(libs.androidx.activity.compose)
  // implementation(libs.androidx.camera.camera2)
  // implementation(libs.androidx.camera.core)
  // implementation(libs.androidx.camera.lifecycle)
  // implementation(libs.androidx.camera.view)
  implementation(libs.androidx.compose.material.icons.core)
  implementation(libs.androidx.compose.material.icons.extended)
  implementation(libs.androidx.compose.material3)
  implementation(libs.androidx.compose.ui)
  implementation(libs.androidx.compose.ui.graphics)
  implementation(libs.androidx.compose.ui.tooling.preview)
  implementation(libs.androidx.core.ktx)
  implementation(libs.androidx.datastore.preferences)
  implementation(libs.androidx.lifecycle.runtime.compose)
  implementation(libs.androidx.lifecycle.runtime.ktx)
  implementation(libs.androidx.lifecycle.process)
  implementation(libs.androidx.lifecycle.viewmodel.compose)
  implementation(libs.androidx.navigation.compose)
  implementation(libs.androidx.room.ktx)
  implementation(libs.androidx.room.runtime)
  implementation(libs.coil.compose)
  // implementation(libs.converter.moshi)
  // implementation(libs.firebase.ai)
  // implementation(libs.firebase.firestore)
  // implementation(libs.firebase.auth)
  // implementation(libs.androidx.credentials)
  // implementation(libs.androidx.credentials.play.services)
  // implementation(libs.googleid)
  // implementation(libs.firebase.appcheck.recaptcha)
  // implementation(libs.firebase.appcheck.debug)
  implementation(libs.kotlinx.coroutines.android)
  implementation(libs.kotlinx.coroutines.core)
  implementation(libs.kotlinx.serialization.json)
  // implementation(libs.logging.interceptor)
  // implementation(libs.moshi.kotlin)
  implementation(libs.okhttp)
  // implementation(libs.play.services.location)
  // implementation(libs.retrofit)
  implementation(libs.androidx.media3.exoplayer)
  implementation(libs.androidx.media3.ui)
  implementation(libs.androidx.media3.common)
  implementation(libs.androidx.media3.session)
  implementation(libs.androidx.profileinstaller)
  implementation(libs.androidx.work.runtime.ktx)
  implementation(libs.commons.compress)
  implementation(libs.tukaani.xz)
  implementation(libs.tdlib)
  testImplementation(libs.androidx.compose.ui.test.junit4)
  testImplementation(libs.androidx.core)
  testImplementation(libs.androidx.junit)
  testImplementation(libs.junit)
  testImplementation(libs.kotlinx.coroutines.test)
  testImplementation(libs.robolectric)
  androidTestImplementation(platform(libs.androidx.compose.bom))
  androidTestImplementation(libs.androidx.compose.ui.test.junit4)
  androidTestImplementation(libs.androidx.espresso.core)
  androidTestImplementation(libs.androidx.junit)
  androidTestImplementation(libs.androidx.runner)
  debugImplementation(libs.androidx.compose.ui.test.manifest)
  debugImplementation(libs.androidx.compose.ui.tooling)
  "ksp"(libs.androidx.room.compiler)
  // "ksp"(libs.moshi.kotlin.codegen)
}
