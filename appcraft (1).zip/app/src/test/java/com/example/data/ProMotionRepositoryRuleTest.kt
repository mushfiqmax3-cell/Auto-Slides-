package com.example.data

import com.example.base.FirestoreEmulatorTestBase
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.UUID

class ProMotionRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun saveAndObserveProject_authenticatedOwner_succeeds() = runBlocking {
        signInTestUser(ALICE_EMAIL)
        val repo = ProMotionRepository(firestore)
        val projectId = "proj_${UUID.randomUUID().toString().replace("-", "_")}"
        val project = DemoProjects.digitalElectronicsDemo.copy(id = projectId, title = "Alice Test Video")

        val saveResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.saveProject(project)
        }
        assertTrue(saveResult.isSuccess)

        val emitted = withTimeout(FLOW_TIMEOUT_MS) {
            repo.observeProjects().first { list -> list.any { it.id == projectId } }
        }
        assertTrue(emitted.any { it.id == projectId && it.title == "Alice Test Video" })
    }

    @Test
    fun getProjectById_crossUserAccess_failsWithPermissionDenied() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val aliceRepo = ProMotionRepository(firestore)
        val projectId = "proj_${UUID.randomUUID().toString().replace("-", "_")}"
        val project = DemoProjects.batteryPhysicsDemo.copy(id = projectId)
        withTimeout(DEFAULT_TIMEOUT_MS) {
            aliceRepo.saveProject(project).getOrThrow()
        }

        signInTestUser(BOB_EMAIL)
        val bobRepo = ProMotionRepository(firestore)
        val bobResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            bobRepo.getProjectById(aliceUid, projectId)
        }
        assertTrue(bobResult.isFailure)
        val fsEx = bobResult.exceptionOrNull()?.unwrapFirestoreException()
        assertNotNull(fsEx)
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx?.code)
    }

    @Test
    fun observeProjects_unauthenticatedUser_failsWithPermissionDenied() = runBlocking {
        auth.signOut()
        val repo = ProMotionRepository(firestore)

        var caught: Throwable? = null
        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repo.observeProjects().first()
            }
        } catch (e: Throwable) {
            caught = e
        }
        assertNotNull(caught)
        val fsEx = caught?.unwrapFirestoreException()
        assertNotNull(fsEx)
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx?.code)
    }

    private companion object {
        const val ALICE_EMAIL = "alice@promotion.test"
        const val BOB_EMAIL = "bob@promotion.test"
        const val DEFAULT_TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 4000L
    }
}
