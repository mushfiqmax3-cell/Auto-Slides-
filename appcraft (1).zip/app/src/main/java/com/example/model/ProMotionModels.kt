package com.example.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.max

@IgnoreExtraProperties
data class VideoProjectDoc(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "",
    val aspectRatio: String = "16:9",
    val lookId: String = "dual_theme_master",
    val projectJson: String = "{}",
    val durationSec: Double = 30.0,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class SavedThemeDoc(
    @DocumentId val id: String = "",
    val userId: String = "",
    val name: String = "",
    val bgHex: String = "#07222E",
    val cardHex: String = "#123849",
    val inkHex: String = "#F8FAFC",
    val accentHex: String = "#38BDF8",
    val hlHex: String = "#FFD166",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

enum class SceneTemplate(val id: String, val labelBn: String, val category: String) {
    SPLIT_CARD("split_card", "Split Card ও Vector Animation", "Promo & Explainer"),
    WAVEFORM_LAB("waveform_lab", "Oscilloscope ও Waveform Lab", "Science"),
    LOGIC_LEVEL_BAND("logic_level_band", "TTL Logic Level ও নিষিদ্ধ রেঞ্জ", "Science"),
    CUTAWAY_XRAY("cutaway_xray", "Cutaway X-Ray ও ইলেকট্রন ফ্লো", "Science"),
    MAGNIFIER_LOUPE("magnifier_loupe", "4× Magnifier Loupe ও রেজিস্ট্যান্স", "Science"),
    COMPARISON_CARDS("comparison_cards", "পাশাপাশি ✓ বনাম ✕ তুলনা", "Explainer"),
    PROGRESS_BARS_COUNTER("progress_bars_counter", "লাইভ নাম্বার কাউন্টার ও রিং গেজ", "Stats"),
    STAT_DASHBOARD("stat_dashboard", "3D/Glass Stat ও চার্ট ড্যাশবোর্ড", "Stats"),
    DEVICE_GRID("device_grid", "ডিভাইস ও আইকন শোকেস গ্রিড", "Explainer"),
    HERO_TITLE("hero_title", "সিনেমাটিক চ্যাপ্টার টাইটেল", "Intro"),
    IMAGE_SHOWCASE("image_showcase", "বইয়ের পাতা / গ্যালারি ছবি ফ্রেম", "Media"),
    OUTRO_CTA("outro_cta", "কমেন্ট বক্স ও সোশ্যাল ফলো কার্ড", "Outro");

    companion object {
        fun fromId(id: String): SceneTemplate =
            entries.firstOrNull { it.id.equals(id.trim(), ignoreCase = true) } ?: SPLIT_CARD
    }
}

enum class WaveformVariant(val id: String, val label: String) {
    SQUARE_WAVE("square_wave", "Square Wave (0/1)"),
    POS_RECT_WAVE("pos_rect_wave", "Positive Rectangular Pulse"),
    NEG_RECT_WAVE("neg_rect_wave", "Negative Rectangular Pulse"),
    DIGITIZED_STAIRCASE("digitized_staircase", "Digitized Staircase Signal"),
    SINE_VS_NOISE("sine_vs_noise", "Analog Noise vs Clean Digital"),
    NON_IDEAL_PULSE("non_ideal_pulse", "Rise Time (tr) & Fall Time (tf)");

    companion object {
        fun fromId(id: String): WaveformVariant =
            entries.firstOrNull { it.id.equals(id.trim(), ignoreCase = true) } ?: SQUARE_WAVE
    }
}

enum class SubtitleStyle(val id: String, val label: String) {
    PILL("Pill", "Pill (রেফারেন্স স্টাইল)"),
    KARAOKE("Karaoke", "Karaoke Word Glow"),
    BOLD("Bold", "Bold Clean"),
    CINEMA("Cinema", "Cinema Letterbox"),
    GLASS("Glass", "Frosted Glass"),
    HORMOZI("Hormozi", "Hormozi Pop"),
    NEON("Neon", "Cyber Neon"),
    HIGHLIGHT("Highlight", "Marker Highlight");

    companion object {
        fun fromId(id: String): SubtitleStyle =
            entries.firstOrNull { it.id.equals(id.trim(), ignoreCase = true) } ?: PILL
    }
}

data class LookPreset(
    val id: String,
    val name: String,
    val subtitleBn: String,
    val category: String,
    val bgHex: String,
    val bgSecondaryHex: String,
    val cardHex: String,
    val inkHex: String,
    val accentHex: String,
    val hlHex: String,
    val successHex: String = "#10B981",
    val dangerHex: String = "#EF4444",
    val bgPattern: String = "ocean_rays",
    val isDualTheme: Boolean = false
)

val BUILTIN_LOOKS: List<LookPreset> = listOf(
    LookPreset(
        id = "auto",
        name = "Auto (Gemini বাছবে)",
        subtitleBn = "বিষয় বুঝে AI সেরা থিম বাছবে",
        category = "⭐ নতুন",
        bgHex = "#07222E",
        bgSecondaryHex = "#12485B",
        cardHex = "#10374A",
        inkHex = "#F8FAFC",
        accentHex = "#38BDF8",
        hlHex = "#FFD166",
        bgPattern = "ocean_rays",
        isDualTheme = true
    ),
    LookPreset(
        id = "deep_ocean",
        name = "Deep Ocean Explainer",
        subtitleBn = "ডায়াগোনাল আলোর রশ্মি ও সায়ান-গোল্ড এক্সপ্লেনার",
        category = "🔬 সায়েন্স ও বই",
        bgHex = "#07222E",
        bgSecondaryHex = "#12485B",
        cardHex = "#0E3547",
        inkHex = "#F8FAFC",
        accentHex = "#38BDF8",
        hlHex = "#FFD166",
        bgPattern = "ocean_rays"
    ),
    LookPreset(
        id = "clean_grid",
        name = "Clean Grid Science",
        subtitleBn = "গ্রাফ-পেপার গ্রিড ও পরিষ্কার ভেক্টর ডায়াগ্রাম",
        category = "🔬 সায়েন্স ও বই",
        bgHex = "#F3F7F8",
        bgSecondaryHex = "#E2ECEF",
        cardHex = "#FFFFFF",
        inkHex = "#0F172A",
        accentHex = "#0284C7",
        hlHex = "#D97706",
        bgPattern = "light_grid"
    ),
    LookPreset(
        id = "dual_theme_master",
        name = "Dual-Theme Master (Ocean + Grid)",
        subtitleBn = "প্রতি সিনে Ocean Teal ও Light Grid অদলবদল হবে",
        category = "⭐ নতুন",
        bgHex = "#07222E",
        bgSecondaryHex = "#F3F7F8",
        cardHex = "#10374A",
        inkHex = "#F8FAFC",
        accentHex = "#38BDF8",
        hlHex = "#FFD166",
        bgPattern = "ocean_rays",
        isDualTheme = true
    ),
    LookPreset(
        id = "digital_circuit_lab",
        name = "Digital Circuit Lab",
        subtitleBn = "অসিলোস্কোপ ওয়েভফর্ম, বাইনারি 0/1 ও IC ল্যাব",
        category = "🔬 সায়েন্স ও বই",
        bgHex = "#091326",
        bgSecondaryHex = "#132647",
        cardHex = "#112240",
        inkHex = "#F1F5F9",
        accentHex = "#00F5D4",
        hlHex = "#F59E0B",
        bgPattern = "cyber_grid"
    ),
    LookPreset(
        id = "glass_ui",
        name = "Glass UI",
        subtitleBn = "ফ্রস্টেড গ্লাস কার্ড ও অ্যাপল-স্টাইল টাইপোগ্রাফি",
        category = "Product",
        bgHex = "#0F172A",
        bgSecondaryHex = "#1E1B4B",
        cardHex = "#1E293B",
        inkHex = "#F8FAFC",
        accentHex = "#60A5FA",
        hlHex = "#C084FC",
        bgPattern = "glass_blur"
    ),
    LookPreset(
        id = "cinematic_dark",
        name = "Cinematic Dark",
        subtitleBn = "গভীর চারকোল ব্যাকগ্রাউন্ডে গোল্ডেন স্পটলাইট",
        category = "গল্প",
        bgHex = "#12100E",
        bgSecondaryHex = "#241E18",
        cardHex = "#1C1917",
        inkHex = "#FAFAF9",
        accentHex = "#F59E0B",
        hlHex = "#FBBF24",
        bgPattern = "golden_sunburst"
    ),
    LookPreset(
        id = "soft_product",
        name = "Soft Product",
        subtitleBn = "উষ্ণ ক্রিম ব্যাকগ্রাউন্ড ও প্যাস্টেল প্রোডাক্ট কার্ড",
        category = "Product",
        bgHex = "#FAF6F0",
        bgSecondaryHex = "#F3ECE1",
        cardHex = "#FFFFFF",
        inkHex = "#1C1917",
        accentHex = "#EA580C",
        hlHex = "#0284C7",
        bgPattern = "warm_gradient"
    ),
    LookPreset(
        id = "tech_hud",
        name = "Tech HUD",
        subtitleBn = "ভারিটাসিয়াম ডার্ক গ্রিড ও টেলিমেট্রি কাউন্টার",
        category = "3D ও HUD",
        bgHex = "#050B14",
        bgSecondaryHex = "#0D1F33",
        cardHex = "#0F243C",
        inkHex = "#E2E8F0",
        accentHex = "#38BDF8",
        hlHex = "#10B981",
        bgPattern = "cyber_grid"
    ),
    LookPreset(
        id = "medical_bio",
        name = "Medical & Bio Clean",
        subtitleBn = "এমেরাল্ড ও টিল ক্লিনিক্যাল ডায়াগ্রাম কার্ড",
        category = "🔬 সায়েন্স ও বই",
        bgHex = "#062825",
        bgSecondaryHex = "#0D4742",
        cardHex = "#0B3B36",
        inkHex = "#F0FDFA",
        accentHex = "#2DD4BF",
        hlHex = "#FBBF24",
        bgPattern = "aurora"
    ),
    LookPreset(
        id = "retro_neon",
        name = "Retro Neon",
        subtitleBn = "সিন্থওয়েভ ম্যাজেন্টা ও সায়ান গ্লো কার্ড",
        category = "3D ও HUD",
        bgHex = "#140826",
        bgSecondaryHex = "#2A0F4D",
        cardHex = "#210E3B",
        inkHex = "#FAF5FF",
        accentHex = "#F472B6",
        hlHex = "#22D3EE",
        bgPattern = "aurora"
    ),
    LookPreset(
        id = "golden_doc",
        name = "Golden Documentary",
        subtitleBn = "ঐতিহাসিক এডিটোরিয়াল পেপার ও গোল্ড অ্যাকসেন্ট",
        category = "গল্প",
        bgHex = "#1A1612",
        bgSecondaryHex = "#2C241D",
        cardHex = "#261F18",
        inkHex = "#F5F5F4",
        accentHex = "#D97706",
        hlHex = "#FDE047",
        bgPattern = "golden_sunburst"
    ),
    LookPreset(
        id = "brand_royal",
        name = "Royal Brand Studio",
        subtitleBn = "প্রিমিয়াম কর্পোরেট ও এজেন্সি ব্র্যান্ডিং",
        category = "Brand",
        bgHex = "#0C1938",
        bgSecondaryHex = "#172E63",
        cardHex = "#142754",
        inkHex = "#FFFFFF",
        accentHex = "#F59E0B",
        hlHex = "#38BDF8",
        bgPattern = "glass_blur"
    ),
    LookPreset(
        id = "emerald_matrix",
        name = "Physics & Math Slate",
        subtitleBn = "ডার্ক স্লেট বোর্ড ও চক-গ্রিন ফর্মুলা",
        category = "🔬 সায়েন্স ও বই",
        bgHex = "#0D1F18",
        bgSecondaryHex = "#16362B",
        cardHex = "#132E24",
        inkHex = "#ECFDF5",
        accentHex = "#34D399",
        hlHex = "#FBBF24",
        bgPattern = "cyber_grid"
    ),
    LookPreset(
        id = "coral_story",
        name = "Warm Storyteller",
        subtitleBn = "গল্প ও মোটিভেশনাল ভিডিওর উষ্ণ থিম",
        category = "গল্প",
        bgHex = "#1F1218",
        bgSecondaryHex = "#381D2A",
        cardHex = "#2D1822",
        inkHex = "#FFF1F2",
        accentHex = "#FB7185",
        hlHex = "#FBBF24",
        bgPattern = "warm_gradient"
    ),
    LookPreset(
        id = "minimal_mono",
        name = "Minimal Editorial",
        subtitleBn = "হাই-কনট্রাস্ট মিনিমাল প্রোডাক্ট লুক",
        category = "Brand",
        bgHex = "#111827",
        bgSecondaryHex = "#1F2937",
        cardHex = "#1F2937",
        inkHex = "#F9FAFB",
        accentHex = "#38BDF8",
        hlHex = "#F59E0B",
        bgPattern = "light_grid"
    )
)

data class ChartDataPoint(
    val label: String,
    val value: Float,
    val unit: String = "%",
    val isPositive: Boolean = true
)

data class SrtCue(
    val index: Int,
    val startSec: Float,
    val endSec: Float,
    val text: String
)

data class SceneLayerConfig(
    val id: String,
    val nameBn: String,
    val visible: Boolean = true,
    val locked: Boolean = false,
    val order: Int = 0
)

fun defaultSceneLayers(): List<SceneLayerConfig> = listOf(
    SceneLayerConfig("background", "Background (ব্যাকগ্রাউন্ড)", true, false, 0),
    SceneLayerConfig("chapter_badge", "Chapter Badge (টপ ব্যাজ)", true, false, 1),
    SceneLayerConfig("main_diagram", "Main Diagram / Card (মূল দৃশ্য)", true, false, 2),
    SceneLayerConfig("callouts", "Callout Labels (লেবেলসমূহ)", true, false, 3),
    SceneLayerConfig("force_arrows", "Force Arrows (তীর ও নির্দেশক)", true, false, 4),
    SceneLayerConfig("particles", "Particles & Stickers (কণা ও ব্যাজ)", true, false, 5),
    SceneLayerConfig("subtitle", "Subtitle (সাবটাইটেল)", true, false, 6)
)

data class ProMotionScene(
    val id: String,
    val chapterNum: Int,
    val chapterBadge: String,
    val heading: String,
    val subtext: String,
    val durationSec: Float,
    val template: SceneTemplate = SceneTemplate.SPLIT_CARD,
    val waveformVariant: WaveformVariant = WaveformVariant.SQUARE_WAVE,
    val calloutLabels: List<String> = listOf("লেবেল ১", "লেবেল ২", "লেবেল ৩"),
    val statusPills: List<String> = listOf("✓ সঠিক অবস্থা", "✕ নিষিদ্ধ অবস্থা"),
    val chartItems: List<ChartDataPoint> = listOf(
        ChartDataPoint("Digital", 95f, "%", true),
        ChartDataPoint("Analog", 62f, "%", false),
        ChartDataPoint("Efficiency", 88f, "%", true)
    ),
    val counterTarget: Int = 95,
    val counterSuffix: String = "%",
    val stickerBadge: String = "",
    val stickerEmoji: String = "🔬",
    val stickerSizePx: Int = 52,
    val imageSlotKey: String = "img1",
    val transitionType: String = "Fade",
    val layers: List<SceneLayerConfig> = defaultSceneLayers()
)

data class ContactOutroConfig(
    val enabled: Boolean = true,
    val brandName: String = "ProMotion Studio",
    val phone: String = "+880 1700-000000",
    val website: String = "www.promotionstudio.bd",
    val whatsapp: String = "+880 1700-000000",
    val questionPrompt: String = "আপনার মতামত কমেন্টে জানান!",
    val showSocialCards: Boolean = true
)

data class ProMotionProject(
    val id: String,
    val title: String,
    val aspectRatio: String = "16:9",
    val lookId: String = "dual_theme_master",
    val languageMode: String = "বাংলা + English",
    val fontName: String = "Hind Siliguri",
    val textScalePercent: Int = 100,
    val bgHex: String = "#07222E",
    val bgSecondaryHex: String = "#12485B",
    val cardHex: String = "#10374A",
    val inkHex: String = "#F8FAFC",
    val accentHex: String = "#38BDF8",
    val hlHex: String = "#FFD166",
    val successHex: String = "#10B981",
    val dangerHex: String = "#EF4444",
    val bgPattern: String = "ocean_rays",
    val isDualTheme: Boolean = true,
    val subtitleEnabled: Boolean = true,
    val subtitleStyle: SubtitleStyle = SubtitleStyle.PILL,
    val subtitlePosition: String = "নিচে",
    val subtitleSizePercent: Int = 100,
    val voiceVolumePercent: Int = 100,
    val bgmTrackId: String = "ambient_science",
    val bgmVolumePercent: Int = 18,
    val logoIntro: Boolean = false,
    val logoOutro: Boolean = true,
    val contactConfig: ContactOutroConfig = ContactOutroConfig(),
    val scenes: List<ProMotionScene> = emptyList(),
    val srtCues: List<SrtCue> = emptyList(),
    val imageSlots: Map<String, String> = emptyMap()
) {
    val totalDurationSec: Float
        get() = max(1f, scenes.sumOf { it.durationSec.toDouble() }.toFloat())
}

object SrtParser {
    fun parseSrt(rawSrt: String): List<SrtCue> {
        if (rawSrt.isBlank()) return emptyList()
        val blocks = rawSrt.trim().replace("\r\n", "\n").split(Regex("\n\\s*\n"))
        val cues = mutableListOf<SrtCue>()
        var idx = 1
        val timeRegex = Regex("""(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})\s*-->\s*(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})""")

        for (block in blocks) {
            val lines = block.lines().map { it.trim() }.filter { it.isNotEmpty() }
            if (lines.isEmpty()) continue
            val timeLineIndex = lines.indexOfFirst { timeRegex.containsMatchIn(it) }
            if (timeLineIndex >= 0) {
                val match = timeRegex.find(lines[timeLineIndex]) ?: continue
                val startSec = toSeconds(
                    match.groupValues[1],
                    match.groupValues[2],
                    match.groupValues[3],
                    match.groupValues[4]
                )
                val endSec = toSeconds(
                    match.groupValues[5],
                    match.groupValues[6],
                    match.groupValues[7],
                    match.groupValues[8]
                )
                val textLines = lines.drop(timeLineIndex + 1)
                val text = textLines.joinToString(" ").ifBlank { "..." }
                cues.add(SrtCue(index = idx++, startSec = startSec, endSec = max(startSec + 0.5f, endSec), text = text))
            }
        }
        return cues
    }

    fun generateSrtFromProject(project: ProMotionProject): String {
        if (project.srtCues.isNotEmpty()) {
            return project.srtCues.joinToString("\n\n") { cue ->
                "${cue.index}\n${formatSrtTime(cue.startSec)} --> ${formatSrtTime(cue.endSec)}\n${stripBrackets(cue.text)}"
            }
        }
        val sb = StringBuilder()
        var elapsed = 0f
        project.scenes.forEachIndexed { index, scene ->
            val start = elapsed
            val end = elapsed + scene.durationSec
            elapsed = end
            sb.append("${index + 1}\n")
            sb.append("${formatSrtTime(start)} --> ${formatSrtTime(end)}\n")
            sb.append("${stripBrackets(scene.subtext.ifBlank { scene.heading })}\n\n")
        }
        return sb.toString().trim()
    }

    private fun toSeconds(h: String, m: String, s: String, ms: String): Float {
        val hours = h.toIntOrNull() ?: 0
        val mins = m.toIntOrNull() ?: 0
        val secs = s.toIntOrNull() ?: 0
        val millisNormalized = ms.padEnd(3, '0').take(3).toIntOrNull() ?: 0
        return hours * 3600f + mins * 60f + secs + (millisNormalized / 1000f)
    }

    fun formatSrtTime(sec: Float): String {
        val totalMs = (sec * 1000).toInt().coerceAtLeast(0)
        val hours = totalMs / 3_600_000
        val mins = (totalMs % 3_600_000) / 60_000
        val secs = (totalMs % 60_000) / 1000
        val ms = totalMs % 1000
        return "%02d:%02d:%02d,%03d".format(hours, mins, secs, ms)
    }

    fun stripBrackets(text: String): String = text.replace("[", "").replace("]", "")
}

object ProMotionJsonCodec {
    fun toJsonString(project: ProMotionProject, pretty: Boolean = true): String {
        val root = JSONObject()
        root.put("specVersion", "ProMotion JSON Spec v5")
        root.put("id", project.id)
        root.put("title", project.title)
        root.put("aspectRatio", project.aspectRatio)
        root.put("lookId", project.lookId)
        root.put("languageMode", project.languageMode)
        root.put("fontName", project.fontName)
        root.put("textScalePercent", project.textScalePercent)
        root.put("bgHex", project.bgHex)
        root.put("bgSecondaryHex", project.bgSecondaryHex)
        root.put("cardHex", project.cardHex)
        root.put("inkHex", project.inkHex)
        root.put("accentHex", project.accentHex)
        root.put("hlHex", project.hlHex)
        root.put("successHex", project.successHex)
        root.put("dangerHex", project.dangerHex)
        root.put("bgPattern", project.bgPattern)
        root.put("isDualTheme", project.isDualTheme)
        root.put("subtitleEnabled", project.subtitleEnabled)
        root.put("subtitleStyle", project.subtitleStyle.id)
        root.put("subtitlePosition", project.subtitlePosition)
        root.put("subtitleSizePercent", project.subtitleSizePercent)
        root.put("voiceVolumePercent", project.voiceVolumePercent)
        root.put("bgmTrackId", project.bgmTrackId)
        root.put("bgmVolumePercent", project.bgmVolumePercent)
        root.put("logoIntro", project.logoIntro)
        root.put("logoOutro", project.logoOutro)

        val contactObj = JSONObject().apply {
            put("enabled", project.contactConfig.enabled)
            put("brandName", project.contactConfig.brandName)
            put("phone", project.contactConfig.phone)
            put("website", project.contactConfig.website)
            put("whatsapp", project.contactConfig.whatsapp)
            put("questionPrompt", project.contactConfig.questionPrompt)
            put("showSocialCards", project.contactConfig.showSocialCards)
        }
        root.put("contactConfig", contactObj)

        val scenesArray = JSONArray()
        project.scenes.forEach { scene ->
            val sObj = JSONObject()
            sObj.put("id", scene.id)
            sObj.put("chapterNum", scene.chapterNum)
            sObj.put("chapterBadge", scene.chapterBadge)
            sObj.put("heading", scene.heading)
            sObj.put("subtext", scene.subtext)
            sObj.put("durationSec", scene.durationSec.toDouble())
            sObj.put("template", scene.template.id)
            sObj.put("waveformVariant", scene.waveformVariant.id)
            sObj.put("calloutLabels", JSONArray(scene.calloutLabels))
            sObj.put("statusPills", JSONArray(scene.statusPills))
            val chartArr = JSONArray()
            scene.chartItems.forEach { pt ->
                chartArr.put(
                    JSONObject().apply {
                        put("label", pt.label)
                        put("value", pt.value.toDouble())
                        put("unit", pt.unit)
                        put("isPositive", pt.isPositive)
                    }
                )
            }
            sObj.put("chartItems", chartArr)
            sObj.put("counterTarget", scene.counterTarget)
            sObj.put("counterSuffix", scene.counterSuffix)
            sObj.put("stickerBadge", scene.stickerBadge)
            sObj.put("stickerEmoji", scene.stickerEmoji)
            sObj.put("stickerSizePx", scene.stickerSizePx)
            sObj.put("imageSlotKey", scene.imageSlotKey)
            sObj.put("transitionType", scene.transitionType)
            scenesArray.put(sObj)
        }
        root.put("scenes", scenesArray)

        val cuesArray = JSONArray()
        project.srtCues.forEach { cue ->
            cuesArray.put(
                JSONObject().apply {
                    put("index", cue.index)
                    put("startSec", cue.startSec.toDouble())
                    put("endSec", cue.endSec.toDouble())
                    put("text", cue.text)
                }
            )
        }
        root.put("srtCues", cuesArray)

        return if (pretty) root.toString(2) else root.toString()
    }

    fun parseAndFixProjectJson(rawInput: String): Result<ProMotionProject> {
        return try {
            var cleaned = rawInput.trim()
            val firstBrace = cleaned.indexOf('{')
            val lastBrace = cleaned.lastIndexOf('}')
            if (firstBrace >= 0 && lastBrace > firstBrace) {
                cleaned = cleaned.substring(firstBrace, lastBrace + 1)
            }
            val root = JSONObject(cleaned)
            val lookId = root.optString("lookId", "dual_theme_master")
            val look = BUILTIN_LOOKS.firstOrNull { it.id == lookId } ?: BUILTIN_LOOKS[3]

            val scenesArr = root.optJSONArray("scenes") ?: JSONArray()
            val parsedScenes = mutableListOf<ProMotionScene>()
            for (i in 0 until scenesArr.length()) {
                val sObj = scenesArr.optJSONObject(i) ?: continue
                val calloutsArr = sObj.optJSONArray("calloutLabels")
                val callouts = mutableListOf<String>()
                if (calloutsArr != null) {
                    for (j in 0 until minOf(4, calloutsArr.length())) {
                        callouts.add(calloutsArr.optString(j, "লেবেল ${j + 1}"))
                    }
                }
                if (callouts.isEmpty()) {
                    callouts.addAll(listOf("মূল পয়েন্ট ১", "মূল পয়েন্ট ২", "মূল পয়েন্ট ৩"))
                }

                val pillsArr = sObj.optJSONArray("statusPills")
                val pills = mutableListOf<String>()
                if (pillsArr != null) {
                    for (j in 0 until minOf(3, pillsArr.length())) {
                        pills.add(pillsArr.optString(j))
                    }
                }
                if (pills.isEmpty()) {
                    pills.addAll(listOf("✓ সঠিক অবস্থা", "✕ তুলনামূলক অবস্থা"))
                }

                val chartArr = sObj.optJSONArray("chartItems")
                val chartItems = mutableListOf<ChartDataPoint>()
                if (chartArr != null) {
                    for (j in 0 until chartArr.length()) {
                        val cObj = chartArr.optJSONObject(j) ?: continue
                        chartItems.add(
                            ChartDataPoint(
                                label = cObj.optString("label", "Item ${j + 1}"),
                                value = cObj.optDouble("value", 75.0).toFloat(),
                                unit = cObj.optString("unit", "%"),
                                isPositive = cObj.optBoolean("isPositive", true)
                            )
                        )
                    }
                }
                if (chartItems.isEmpty()) {
                    chartItems.addAll(
                        listOf(
                            ChartDataPoint("সিগন্যাল ১", 92f, "%", true),
                            ChartDataPoint("সিগন্যাল ২", 64f, "%", false),
                            ChartDataPoint("আউটপুট", 88f, "%", true)
                        )
                    )
                }

                parsedScenes.add(
                    ProMotionScene(
                        id = sObj.optString("id", "scene_${i + 1}"),
                        chapterNum = sObj.optInt("chapterNum", i + 1),
                        chapterBadge = sObj.optString("chapterBadge", "অধ্যায় ${i + 1}"),
                        heading = sObj.optString("heading", "দৃশ্য [${i + 1}]"),
                        subtext = sObj.optString("subtext", sObj.optString("heading", "বিস্তারিত ব্যাখ্যা")),
                        durationSec = sObj.optDouble("durationSec", 5.0).toFloat().coerceIn(1.5f, 60f),
                        template = SceneTemplate.fromId(sObj.optString("template", "split_card")),
                        waveformVariant = WaveformVariant.fromId(sObj.optString("waveformVariant", "square_wave")),
                        calloutLabels = callouts,
                        statusPills = pills,
                        chartItems = chartItems,
                        counterTarget = sObj.optInt("counterTarget", 95),
                        counterSuffix = sObj.optString("counterSuffix", "%"),
                        stickerBadge = sObj.optString("stickerBadge", ""),
                        stickerEmoji = sObj.optString("stickerEmoji", "🔬"),
                        stickerSizePx = sObj.optInt("stickerSizePx", 52),
                        imageSlotKey = sObj.optString("imageSlotKey", "img1"),
                        transitionType = sObj.optString("transitionType", "Fade")
                    )
                )
            }

            val cuesArr = root.optJSONArray("srtCues")
            val parsedCues = mutableListOf<SrtCue>()
            if (cuesArr != null) {
                for (i in 0 until cuesArr.length()) {
                    val cObj = cuesArr.optJSONObject(i) ?: continue
                    parsedCues.add(
                        SrtCue(
                            index = cObj.optInt("index", i + 1),
                            startSec = cObj.optDouble("startSec", i * 4.0).toFloat(),
                            endSec = cObj.optDouble("endSec", (i + 1) * 4.0).toFloat(),
                            text = cObj.optString("text", "")
                        )
                    )
                }
            }

            val cObj = root.optJSONObject("contactConfig")
            val contactConfig = if (cObj != null) {
                ContactOutroConfig(
                    enabled = cObj.optBoolean("enabled", true),
                    brandName = cObj.optString("brandName", "ProMotion Studio"),
                    phone = cObj.optString("phone", "+880 1700-000000"),
                    website = cObj.optString("website", "www.promotionstudio.bd"),
                    whatsapp = cObj.optString("whatsapp", "+880 1700-000000"),
                    questionPrompt = cObj.optString("questionPrompt", "আপনার মতামত কমেন্টে জানান!"),
                    showSocialCards = cObj.optBoolean("showSocialCards", true)
                )
            } else {
                ContactOutroConfig()
            }

            val project = ProMotionProject(
                id = root.optString("id", "proj_${System.currentTimeMillis()}"),
                title = root.optString("title", "নতুন মোশন ভিডিও"),
                aspectRatio = root.optString("aspectRatio", "16:9"),
                lookId = look.id,
                languageMode = root.optString("languageMode", "বাংলা + English"),
                fontName = root.optString("fontName", "Hind Siliguri"),
                textScalePercent = root.optInt("textScalePercent", 100),
                bgHex = root.optString("bgHex", look.bgHex),
                bgSecondaryHex = root.optString("bgSecondaryHex", look.bgSecondaryHex),
                cardHex = root.optString("cardHex", look.cardHex),
                inkHex = root.optString("inkHex", look.inkHex),
                accentHex = root.optString("accentHex", look.accentHex),
                hlHex = root.optString("hlHex", look.hlHex),
                successHex = root.optString("successHex", look.successHex),
                dangerHex = root.optString("dangerHex", look.dangerHex),
                bgPattern = root.optString("bgPattern", look.bgPattern),
                isDualTheme = root.optBoolean("isDualTheme", look.isDualTheme),
                subtitleEnabled = root.optBoolean("subtitleEnabled", true),
                subtitleStyle = SubtitleStyle.fromId(root.optString("subtitleStyle", "Pill")),
                subtitlePosition = root.optString("subtitlePosition", "নিচে"),
                subtitleSizePercent = root.optInt("subtitleSizePercent", 100),
                voiceVolumePercent = root.optInt("voiceVolumePercent", 100),
                bgmTrackId = root.optString("bgmTrackId", "ambient_science"),
                bgmVolumePercent = root.optInt("bgmVolumePercent", 18),
                logoIntro = root.optBoolean("logoIntro", false),
                logoOutro = root.optBoolean("logoOutro", true),
                contactConfig = contactConfig,
                scenes = parsedScenes,
                srtCues = parsedCues
            )
            Result.success(project)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
