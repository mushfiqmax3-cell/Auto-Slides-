package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.auth.configureAppCheck
import com.example.data.ProMotionRepository
import com.example.ui.StudioMainScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.ProMotionViewModel
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Mandatory App Check configuration with launch intent before any UI or Firebase calls
        configureAppCheck(this, intent)

        enableEdgeToEdge()
        setContent {
            AppRootContent()
        }
    }
}

@Composable
fun AppRootContent() {
    val viewModel: ProMotionViewModel = viewModel(
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY])
                val databaseId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(databaseId)
                ProMotionViewModel(ProMotionRepository(db), "local_studio_user")
            }
        }
    )
    val isDarkStudio by viewModel.isDarkStudio.collectAsState()

    MyApplicationTheme(darkTheme = isDarkStudio) {
        StudioMainScreen(
            viewModel = viewModel,
            onSignOut = {}
        )
    }
}
