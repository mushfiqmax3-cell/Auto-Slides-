package com.example.data

import com.example.model.ChartDataPoint
import com.example.model.ContactOutroConfig
import com.example.model.ProMotionProject
import com.example.model.ProMotionScene
import com.example.model.SceneTemplate
import com.example.model.SrtCue
import com.example.model.SubtitleStyle
import com.example.model.WaveformVariant

object DemoProjects {
    val digitalElectronicsDemo = ProMotionProject(
        id = "demo_digital_electronics",
        title = "ডিজিটাল ইলেকট্রনিক্স ও সিগন্যাল — এক্সপ্লেনার",
        aspectRatio = "16:9",
        lookId = "dual_theme_master",
        languageMode = "বাংলা + English",
        fontName = "Hind Siliguri",
        bgHex = "#07222E",
        bgSecondaryHex = "#12485B",
        cardHex = "#0E3547",
        inkHex = "#F8FAFC",
        accentHex = "#38BDF8",
        hlHex = "#FFD166",
        isDualTheme = true,
        subtitleEnabled = true,
        subtitleStyle = SubtitleStyle.PILL,
        scenes = listOf(
            ProMotionScene(
                id = "de_s1",
                chapterNum = 1,
                chapterBadge = "অধ্যায় ১.১ • সিগন্যাল পরিচিতি",
                heading = "ডিজিটাল সিগন্যালের মাত্র [দুটি অবস্থা] থাকে",
                subtext = "ডিজিটাল সিগন্যালে ভোল্টেজ কেবল [HIGH (1)] অথবা [LOW (0)] অবস্থায় পরিবর্তিত হয়।",
                durationSec = 5.5f,
                template = SceneTemplate.SPLIT_CARD,
                calloutLabels = listOf("HIGH = +5V (Logic 1)", "LOW = 0V (Logic 0)", "Discrete স্টেপ"),
                statusPills = listOf("✓ Binary 1 = ON (5V)", "✕ Analog = ক্রমাগত পরিবর্তন"),
                stickerBadge = "CHAPTER 01",
                stickerEmoji = "⚡"
            ),
            ProMotionScene(
                id = "de_s2",
                chapterNum = 2,
                chapterBadge = "অধ্যায় ১.২ • অসিলোস্কোপ ওয়েভফর্ম ল্যাব",
                heading = "[Square Wave] ও পালস ওয়েভফর্ম বিশ্লেষণ",
                subtext = "আদর্শ ও অনাদর্শ পালসের [Rise Time (tr)], [Fall Time (tf)] এবং [Pulse Width (tw)] দেখুন।",
                durationSec = 6.5f,
                template = SceneTemplate.WAVEFORM_LAB,
                waveformVariant = WaveformVariant.NON_IDEAL_PULSE,
                calloutLabels = listOf("Rise Time (tr: 10%→90%)", "Pulse Width (tw: 50%)", "Fall Time (tf: 90%→10%)"),
                statusPills = listOf("✓ ক্লিন ডিজিটাল পালস", "✕ নয়েজ-মুক্ত সিগন্যাল"),
                stickerBadge = "WAVE LAB",
                stickerEmoji = "📈"
            ),
            ProMotionScene(
                id = "de_s3",
                chapterNum = 3,
                chapterBadge = "অধ্যায় ১.৩ • চিত্র ১.২ লজিক লেভেল ব্যান্ড",
                heading = "TTL ভোল্টেজ রেঞ্জ ও [নিষিদ্ধ অঞ্চল]",
                subtext = "[2V থেকে 5V] হলো Logic 1 এবং [0V থেকে 0.8V] হলো Logic 0; মাঝের অংশ নিষিদ্ধ!",
                durationSec = 6.5f,
                template = SceneTemplate.LOGIC_LEVEL_BAND,
                calloutLabels = listOf("HIGH (1): 2.0V – 5.0V", "Forbidden: 0.8V – 2.0V", "LOW (0): 0.0V – 0.8V"),
                statusPills = listOf("✓ 3.5V ➔ High (1)", "✕ 1.4V ➔ Error Zone!"),
                stickerBadge = "TTL LEVEL",
                stickerEmoji = "🔬"
            ),
            ProMotionScene(
                id = "de_s4",
                chapterNum = 4,
                chapterBadge = "অধ্যায় ১.৪ • ডিজিটাল ডিভাইসের ব্যবহার",
                heading = "আধুনিক [ডিজিটাল সিস্টেম] ও আইসি চিপ",
                subtext = "কম্পিউটার, ক্যালকুলেটর, ডিজিটাল ঘড়ি ও মেডিক্যাল যন্ত্রে [১০০% নিখুঁত] ডেটা প্রসেসিং।",
                durationSec = 5.5f,
                template = SceneTemplate.DEVICE_GRID,
                calloutLabels = listOf("Microcomputer", "IC Logic Gate", "Digital Watch", "Smart Meter"),
                statusPills = listOf("✓ নয়েজ সহনশীল", "✓ সহজে মেমোরিতে সংরক্ষণ"),
                stickerBadge = "DEVICES",
                stickerEmoji = "🖥️"
            ),
            ProMotionScene(
                id = "de_s5",
                chapterNum = 5,
                chapterBadge = "প্রশ্ন ও সমাপ্তি",
                heading = "১.৪ ভোল্ট সিগন্যাল কোন [লজিক লেভেলে] পড়বে?",
                subtext = "আপনার উত্তর [কমেন্টে লিখুন] এবং পরবর্তী পলিটেকনিক ক্লাসের জন্য সাবস্ক্রাইব করুন!",
                durationSec = 5.0f,
                template = SceneTemplate.OUTRO_CTA,
                calloutLabels = listOf("Facebook — ✓ ফলো", "Instagram — ✓ ফলো", "YouTube — ✓ সাবস্ক্রাইব 🔔"),
                statusPills = listOf("✓ ফ্রি PDF নোট", "✓ পরবর্তী ক্লাস আগামীকাল"),
                stickerBadge = "QUIZ",
                stickerEmoji = "💬"
            )
        ),
        srtCues = listOf(
            SrtCue(1, 0.0f, 5.5f, "ডিজিটাল সিগন্যালের মাত্র [দুটি অবস্থা] থাকে — HIGH এবং LOW।"),
            SrtCue(2, 5.5f, 12.0f, "অসিলোস্কোপে পালসের [Rise Time], [Fall Time] এবং [Pulse Width] স্পষ্ট দেখা যাচ্ছে।"),
            SrtCue(3, 12.0f, 18.5f, "[2V থেকে 5V] হলো High এবং [0.8V থেকে 2V] হলো নিষিদ্ধ বা Unacceptable রেঞ্জ।"),
            SrtCue(4, 18.5f, 24.0f, "আধুনিক সব [মাইক্রোকম্পিউটার ও আইসি চিপ] এই ডিজিটাল লজিকে কাজ করে।"),
            SrtCue(5, 24.0f, 29.0f, "১.৪ ভোল্ট কোন রেঞ্জে পড়বে? এখনই [কমেন্টে লিখে জানান]!")
        )
    )

    val batteryPhysicsDemo = ProMotionProject(
        id = "demo_battery_physics",
        title = "ব্যাটারিতে কামড় দিলে রিমোট কেন চলে?",
        aspectRatio = "16:9",
        lookId = "deep_ocean",
        languageMode = "বাংলা + English",
        fontName = "Hind Siliguri",
        bgHex = "#07222E",
        bgSecondaryHex = "#12485B",
        cardHex = "#0E3547",
        inkHex = "#F8FAFC",
        accentHex = "#38BDF8",
        hlHex = "#FFD166",
        isDualTheme = false,
        subtitleEnabled = true,
        subtitleStyle = SubtitleStyle.PILL,
        scenes = listOf(
            ProMotionScene(
                id = "bat_s1",
                chapterNum = 1,
                chapterBadge = "দৃশ্য ১ • রহস্যের শুরু",
                heading = "ডেড ব্যাটারিতে [চাপ বা কামড়] দিলে রিমোট চলে কেন?",
                subtext = "টিভি রিমোটের ব্যাটারি শেষ হয়ে গেলে [হালকা চাপ] দিলেই আবার কাজ শুরু করে!",
                durationSec = 5.0f,
                template = SceneTemplate.HERO_TITLE,
                calloutLabels = listOf("Zinc-Carbon AA Cell", "1.5V Nominal", "Internal Resistance"),
                statusPills = listOf("✓ রাসায়নিক শক্তির রহস্য", "✕ জাদু নয়, পদার্থবিজ্ঞান!"),
                stickerBadge = "SCIENCE EXPLAINER",
                stickerEmoji = "🔋"
            ),
            ProMotionScene(
                id = "bat_s2",
                chapterNum = 2,
                chapterBadge = "দৃশ্য ২ • ব্যাটারির ভেতরের এক্স-রে",
                heading = "AA ব্যাটারির ভেতরের [৩টি স্তর] ও ইলেকট্রন প্রবাহ",
                subtext = "বাইরে [দস্তার খোলস (Zinc)], মাঝখানে রাসায়নিক পেস্ট এবং কেন্দ্রে [কার্বন রড] থাকে।",
                durationSec = 6.5f,
                template = SceneTemplate.CUTAWAY_XRAY,
                calloutLabels = listOf("Zinc Outer Shell (-)", "Electrolyte Paste", "Carbon Center Rod (+)"),
                statusPills = listOf("✓ সচল ইলেকট্রন প্রবাহ (e⁻)", "✕ শুকিয়ে গেলে প্রবাহ থামে"),
                stickerBadge = "X-RAY CUTAWAY",
                stickerEmoji = "🔬"
            ),
            ProMotionScene(
                id = "bat_s3",
                chapterNum = 3,
                chapterBadge = "দৃশ্য ৩ • 4× মাইক্রোস্কোপিক লুপ",
                heading = "চাপ দিলে [Internal Resistance] দেয়াল ভেঙে যায়!",
                subtext = "কার্বন রডের চারপাশে জমা [বাধা বা ফাটল] ভেঙে পেস্ট আবার রডের সংস্পর্শে আসে।",
                durationSec = 6.5f,
                template = SceneTemplate.MAGNIFIER_LOUPE,
                calloutLabels = listOf("4× Microscopic Loupe", "Resistance Barrier 💥", "Electrolyte Contact ✓"),
                statusPills = listOf("✓ বাধা ভেঙে কণা মুক্ত", "✓ ১০%–১৫% বাড়তি শক্তি"),
                stickerBadge = "4× ZOOM LOUPE",
                stickerEmoji = "🔍"
            ),
            ProMotionScene(
                id = "bat_s4",
                chapterNum = 4,
                chapterBadge = "দৃশ্য ৪ • সতর্কতা ও সঠিক নিয়ম",
                heading = "দাঁত দিয়ে কামড়ানো [বিপজ্জনক] — কী করবেন?",
                subtext = "ক্ষতিকর রাসায়নিক লিক হতে পারে; কেবল [হালকা প্লায়ার্স] বা নতুন ব্যাটারি ব্যবহার করুন।",
                durationSec = 5.5f,
                template = SceneTemplate.COMPARISON_CARDS,
                calloutLabels = listOf("✕ দাঁতে কামড় (Toxic Leak)", "✓ নতুন Alkaline ব্যাটারি", "১০–১৫% সাময়িক চার্জ"),
                statusPills = listOf("✓ নিরাপদ পদ্ধতি মেনে চলুন", "✕ লিথিয়াম ব্যাটারিতে কখনোই চাপ দেবেন না"),
                counterTarget = 15,
                counterSuffix = "% Extra",
                stickerBadge = "SAFETY FIRST",
                stickerEmoji = "⚠️"
            )
        ),
        srtCues = listOf(
            SrtCue(1, 0.0f, 5.0f, "ডেড ব্যাটারিতে [চাপ বা কামড়] দিলে রিমোট আবার কেন চলে?"),
            SrtCue(2, 5.0f, 11.5f, "ব্যাটারির ভেতরে [দস্তার খোলস], রাসায়নিক পেস্ট এবং কেন্দ্রে [কার্বন রড] থাকে।"),
            SrtCue(3, 11.5f, 18.0f, "চাপ দিলে কার্বন রডের চারপাশের [Internal Resistance] দেয়াল ভেঙে পেস্ট সংস্পর্শে আসে!"),
            SrtCue(4, 18.0f, 23.5f, "তবে দাঁত দিয়ে কামড়ানো [বিপজ্জনক] — এতে বিষাক্ত কেমিক্যাল লিক হতে পারে।")
        )
    )

    val promoStudioDemo = ProMotionProject(
        id = "demo_promotion_studio",
        title = "ProMotion Studio — ফোনেই মোশন ভিডিও",
        aspectRatio = "16:9",
        lookId = "glass_ui",
        languageMode = "বাংলা + English",
        fontName = "Hind Siliguri",
        bgHex = "#0F172A",
        bgSecondaryHex = "#1E1B4B",
        cardHex = "#1E293B",
        inkHex = "#F8FAFC",
        accentHex = "#38BDF8",
        hlHex = "#F59E0B",
        isDualTheme = false,
        subtitleEnabled = true,
        subtitleStyle = SubtitleStyle.KARAOKE,
        scenes = listOf(
            ProMotionScene(
                id = "pm_s1",
                chapterNum = 1,
                chapterBadge = "PROMOTION v2.0 • STUDIO",
                heading = "ফোনেই বানান [প্রিমিয়াম মোশন] ও এক্সপ্লেনার ভিডিও",
                subtext = "ভারী পিসি ছাড়াই আপনার অ্যান্ড্রয়েড ফোনে [30 FPS ল্যাগ-মুক্ত] ভিডিও এডিটিং ও রেন্ডারিং।",
                durationSec = 5.0f,
                template = SceneTemplate.HERO_TITLE,
                calloutLabels = listOf("30 FPS Canvas Engine", "Gemini AI Powered", "Offline MP4 Export"),
                statusPills = listOf("✓ ১০০% মোবাইল অপ্টিমাইজড", "✓ জিরো ওভারল্যাপ লেআউট"),
                stickerBadge = "NEW v2.0",
                stickerEmoji = "🚀"
            ),
            ProMotionScene(
                id = "pm_s2",
                chapterNum = 2,
                chapterBadge = "ড্যাশবোর্ড ও পারফরম্যান্স",
                heading = "[১০ গুণ দ্রুত] ভিডিও প্রোডাকশন ও অ্যানালিটিক্স",
                subtext = "স্ক্রিপ্ট বা ভয়েসওভার থেকে সরাসরি [চার্ট, কাউন্টার ও ডায়াগ্রাম] অ্যানিমেশন।",
                durationSec = 6.0f,
                template = SceneTemplate.STAT_DASHBOARD,
                chartItems = listOf(
                    ChartDataPoint("রেন্ডার স্পিড", 96f, "%", true),
                    ChartDataPoint("ভয়েস সিঙ্ক", 100f, "%", true),
                    ChartDataPoint("সময় সাশ্রয়", 85f, "%", true)
                ),
                calloutLabels = listOf("1080p HD MP4", "16+ Master Looks", "14 Touch Tools"),
                statusPills = listOf("✓ রিয়েল-টাইম ক্যানভাস প্রিভিউ", "✓ ওয়ান-ট্যাপ থিম পরিবর্তন"),
                stickerBadge = "LIVE STATS",
                stickerEmoji = "📊"
            ),
            ProMotionScene(
                id = "pm_s3",
                chapterNum = 3,
                chapterBadge = "গ্যালারি ও বইয়ের পাতা ফ্রেম",
                heading = "বইয়ের পাতা বা [প্রোডাক্ট ছবি] দিয়ে স্মার্ট শোকেস",
                subtext = "আপনার গ্যালারি থেকে যেকোনো ছবি যোগ করুন এবং [অ্যানিমেটেড কলআউট] দিন।",
                durationSec = 5.0f,
                template = SceneTemplate.IMAGE_SHOWCASE,
                imageSlotKey = "img1",
                calloutLabels = listOf("স্মার্ট ফ্রেম জুম", "অটো কলআউট পয়েন্টার", "লোগো ওয়াটারমার্ক"),
                statusPills = listOf("✓ গ্যালারি থেকে ছবি আপলোড", "✓ স্বচ্ছ ব্যাকগ্রাউন্ড সাপোর্ট"),
                stickerBadge = "SHOWCASE",
                stickerEmoji = "🖼️"
            ),
            ProMotionScene(
                id = "pm_s4",
                chapterNum = 4,
                chapterBadge = "সরাসরি MP4 ডাউনলোড ও শেয়ার",
                heading = "এখনই আপনার প্রথম [মোশন ভিডিও] এক্সপোর্ট করুন!",
                subtext = "উপরে ডানপাশে [Export] বাটনে ট্যাপ করে ফোনেই 1080p MP4 ভিডিও সেভ করুন।",
                durationSec = 5.0f,
                template = SceneTemplate.PROGRESS_BARS_COUNTER,
                counterTarget = 100,
                counterSuffix = "% Ready",
                calloutLabels = listOf("1080p Full HD", "AAC Audio Muxing", "Instant Share"),
                statusPills = listOf("✓ ইন্টারনেট ছাড়াই MP4 তৈরি", "✓ WhatsApp ও YouTube রেডি"),
                stickerBadge = "EXPORT READY",
                stickerEmoji = "🎬"
            )
        ),
        srtCues = listOf(
            SrtCue(1, 0.0f, 5.0f, "ফোনেই বানান [প্রিমিয়াম মোশন] ও সায়েন্স এক্সপ্লেনার ভিডিও!"),
            SrtCue(2, 5.0f, 11.0f, "স্ক্রিপ্ট বা ভয়েস থেকে [১০ গুণ দ্রুত] চার্ট, কাউন্টার ও ডায়াগ্রাম তৈরি করুন।"),
            SrtCue(3, 11.0f, 16.0f, "বইয়ের পাতা বা [প্রোডাক্টের ছবি] যোগ করে অ্যানিমেটেড কলআউট দিন।"),
            SrtCue(4, 16.0f, 21.0f, "এখনই [Export] বাটনে ট্যাপ করে সরাসরি ফোনে MP4 ভিডিও ডাউনলোড করুন!")
        ),
        contactConfig = ContactOutroConfig(
            enabled = true,
            brandName = "ProMotion Studio BD",
            phone = "+880 1711-000000",
            website = "www.promotionstudio.app",
            whatsapp = "+880 1711-000000",
            questionPrompt = "আপনি কোন বিষয়ে ভিডিও বানাতে চান? কমেন্টে জানান!",
            showSocialCards = true
        )
    )

    val allDemos: List<ProMotionProject> = listOf(
        digitalElectronicsDemo,
        batteryPhysicsDemo,
        promoStudioDemo
    )
}
