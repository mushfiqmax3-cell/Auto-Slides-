package com.example.data

import android.content.Context
import android.util.Log
import com.example.R
import com.example.model.ProMotionJsonCodec
import com.example.model.ProMotionProject
import com.example.model.SavedThemeDoc
import com.example.model.VideoProjectDoc
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import org.json.JSONArray
import org.json.JSONObject

enum class OperationType(val value: String) {
    CREATE("create"),
    UPDATE("update"),
    DELETE("delete"),
    LIST("list"),
    GET("get"),
    WRITE("write"),
}

fun handleFirestoreError(exception: Throwable, operationType: OperationType, path: String?): String {
    val causes = generateSequence(exception) { it.cause }
    val rootError = causes.firstOrNull { it is FirebaseFirestoreException }
        ?: causes.firstOrNull { it !is CancellationException }
        ?: exception

    val auth = FirebaseAuth.getInstance()
    val currentUser = auth.currentUser

    val providerInfoList = currentUser?.providerData?.map { provider ->
        JSONObject().apply {
            put("providerId", provider.providerId)
            put("email", provider.email)
        }
    } ?: emptyList()

    val authInfoJson = JSONObject().apply {
        put("userId", currentUser?.uid)
        put("email", currentUser?.email)
        put("emailVerified", currentUser?.isEmailVerified)
        put("tenantId", currentUser?.tenantId)
        put("providerInfo", JSONArray(providerInfoList))
    }

    val errorInfoJson = JSONObject().apply {
        put("error", rootError.message ?: rootError.toString())
        put("operationType", operationType.value)
        put("path", path)
        put("authInfo", authInfoJson)
    }

    val jsonString = errorInfoJson.toString()
    Log.e("FirestoreError", "Firestore Error: $jsonString")
    return jsonString
}

class ProMotionRepository(private val db: FirebaseFirestore) {

    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private val auth: FirebaseAuth
        get() = Firebase.auth

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    fun observeProjects(): Flow<List<VideoProjectDoc>> = flow {
        val uid = auth.currentUser?.uid
            ?: throw FirebaseFirestoreException(
                "User must be signed in to observe projects.",
                FirebaseFirestoreException.Code.PERMISSION_DENIED
            )
        val path = "users/$uid/projects"
        emitAll(
            db.collection("users").document(uid).collection("projects")
                .whereEqualTo("userId", uid)
                .snapshots()
                .map { snapshot ->
                    snapshot.documents.mapNotNull { doc ->
                        doc.toObject(VideoProjectDoc::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    }
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun saveProject(project: ProMotionProject): Result<String> = runCatching {
        val uid = requireUserId()
        val docId = project.id.replace(Regex("[^a-zA-Z0-9_\\-]"), "_").take(100).ifBlank {
            "proj_${System.currentTimeMillis()}"
        }
        val docRef = db.collection("users").document(uid).collection("projects").document(docId)
        val existingSnap = try {
            docRef.get().await()
        } catch (e: Exception) {
            null
        }
        val jsonStr = ProMotionJsonCodec.toJsonString(project, pretty = false)
        if (existingSnap != null && existingSnap.exists()) {
            val updatePayload = mapOf(
                "title" to project.title.take(200).ifBlank { "Untitled Video" },
                "aspectRatio" to project.aspectRatio,
                "lookId" to project.lookId.take(80),
                "projectJson" to jsonStr,
                "durationSec" to project.totalDurationSec.toDouble(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            try {
                docRef.update(updatePayload).await()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.UPDATE, docRef.path)
                throw e
            }
        } else {
            val createPayload = mapOf(
                "userId" to uid,
                "title" to project.title.take(200).ifBlank { "Untitled Video" },
                "aspectRatio" to project.aspectRatio,
                "lookId" to project.lookId.take(80),
                "projectJson" to jsonStr,
                "durationSec" to project.totalDurationSec.toDouble(),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            try {
                docRef.set(createPayload).await()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.CREATE, docRef.path)
                throw e
            }
        }
        docId
    }

    suspend fun getProjectById(ownerUid: String, projectId: String): Result<VideoProjectDoc> = runCatching {
        val docRef = db.collection("users").document(ownerUid).collection("projects").document(projectId)
        try {
            val snap = docRef.get().await()
            snap.toObject(VideoProjectDoc::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                ?: throw IllegalStateException("Project not found")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, docRef.path)
            throw e
        }
    }

    suspend fun deleteProject(projectId: String): Result<Unit> = runCatching {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid).collection("projects").document(projectId)
        try {
            docRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            throw e
        }
    }

    fun observeThemes(): Flow<List<SavedThemeDoc>> = flow {
        val uid = auth.currentUser?.uid
            ?: throw FirebaseFirestoreException(
                "User must be signed in to observe themes.",
                FirebaseFirestoreException.Code.PERMISSION_DENIED
            )
        val path = "users/$uid/themes"
        emitAll(
            db.collection("users").document(uid).collection("themes")
                .whereEqualTo("userId", uid)
                .snapshots()
                .map { snapshot ->
                    snapshot.documents.mapNotNull { doc ->
                        doc.toObject(SavedThemeDoc::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    }
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun saveCustomTheme(
        name: String,
        bgHex: String,
        cardHex: String,
        inkHex: String,
        accentHex: String,
        hlHex: String
    ): Result<String> = runCatching {
        val uid = requireUserId()
        val themeId = "theme_${System.currentTimeMillis()}"
        val docRef = db.collection("users").document(uid).collection("themes").document(themeId)
        val payload = mapOf(
            "userId" to uid,
            "name" to name.take(100).ifBlank { "Custom Look" },
            "bgHex" to bgHex.take(16),
            "cardHex" to cardHex.take(16),
            "inkHex" to inkHex.take(16),
            "accentHex" to accentHex.take(16),
            "hlHex" to hlHex.take(16),
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        try {
            docRef.set(payload).await()
            themeId
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }
}
