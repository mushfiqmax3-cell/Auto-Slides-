package com.example.engine

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import com.example.model.ProMotionProject
import com.example.model.ProMotionScene
import com.example.model.SceneTemplate
import com.example.model.SrtParser
import com.example.model.SubtitleStyle
import com.example.model.WaveformVariant
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

object CanvasVideoEngine {

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }

    fun parseColorSafe(hex: String, fallback: Int = Color.parseColor("#07222E")): Int {
        return try {
            val cleaned = if (hex.startsWith("#")) hex else "#$hex"
            Color.parseColor(cleaned)
        } catch (e: Exception) {
            fallback
        }
    }

    fun findSceneAtTime(project: ProMotionProject, timeSec: Float): Pair<Int, Float> {
        if (project.scenes.isEmpty()) return 0 to 0f
        var acc = 0f
        project.scenes.forEachIndexed { index, scene ->
            val end = acc + scene.durationSec
            if (timeSec <= end || index == project.scenes.lastIndex) {
                val localProgress = ((timeSec - acc) / max(0.1f, scene.durationSec)).coerceIn(0f, 1f)
                return index to localProgress
            }
            acc = end
        }
        return 0 to 0f
    }

    fun renderFrame(
        canvas: Canvas,
        width: Float,
        height: Float,
        project: ProMotionProject,
        globalTimeSec: Float,
        customImages: Map<String, Bitmap> = emptyMap()
    ) {
        if (width <= 1f || height <= 1f) return
        val (sceneIndex, sceneProgress) = findSceneAtTime(project, globalTimeSec)
        val scene = project.scenes.getOrNull(sceneIndex) ?: return
        val scale = min(width / 1280f, height / 720f).coerceAtLeast(0.28f)
        val textScale = (project.textScalePercent / 100f).coerceIn(0.7f, 1.5f)

        val useLightGridForDual = project.isDualTheme && (sceneIndex % 2 == 1)
        val bgColor = if (useLightGridForDual) Color.parseColor("#F3F7F8") else parseColorSafe(project.bgHex)
        val bgSecColor = if (useLightGridForDual) Color.parseColor("#E2ECEF") else parseColorSafe(project.bgSecondaryHex)
        val cardColor = if (useLightGridForDual) Color.parseColor("#FFFFFF") else parseColorSafe(project.cardHex)
        val inkColor = if (useLightGridForDual) Color.parseColor("#0F172A") else parseColorSafe(project.inkHex, Color.WHITE)
        val accentColor = if (useLightGridForDual) Color.parseColor("#0284C7") else parseColorSafe(project.accentHex, Color.parseColor("#38BDF8"))
        val hlColor = if (useLightGridForDual) Color.parseColor("#D97706") else parseColorSafe(project.hlHex, Color.parseColor("#FFD166"))
        val successColor = parseColorSafe(project.successHex, Color.parseColor("#10B981"))
        val dangerColor = parseColorSafe(project.dangerHex, Color.parseColor("#EF4444"))

        val visibleLayerIds = scene.layers.filter { it.visible }.map { it.id }.toSet()

        // 1. Background Safe Layer
        if ("background" in visibleLayerIds) {
            drawBackground(canvas, width, height, bgColor, bgSecColor, accentColor, project.bgPattern, useLightGridForDual, globalTimeSec)
        } else {
            fillPaint.shader = null
            fillPaint.color = bgColor
            canvas.drawRect(0f, 0f, width, height, fillPaint)
        }

        // 2. Top-Left Chapter Badge Safe Zone (Y: 4% - 11%)
        if ("chapter_badge" in visibleLayerIds) {
            drawTopChapterBadge(canvas, width, height, scale, scene, accentColor, hlColor, inkColor, cardColor)
        }

        // 3. Main Visual & Diagram Safe Zone (Y: 13% - 80%)
        if ("main_diagram" in visibleLayerIds) {
            val mainRect = RectF(width * 0.05f, height * 0.14f, width * 0.95f, height * 0.80f)
            val showCallouts = "callouts" in visibleLayerIds
            val showArrows = "force_arrows" in visibleLayerIds
            when (scene.template) {
                SceneTemplate.SPLIT_CARD -> drawSplitCardScene(
                    canvas, mainRect, scale, textScale, scene, sceneProgress, globalTimeSec,
                    cardColor, inkColor, accentColor, hlColor, successColor, dangerColor, showCallouts
                )
                SceneTemplate.WAVEFORM_LAB -> drawWaveformLabScene(
                    canvas, mainRect, scale, textScale, scene, sceneProgress, globalTimeSec,
                    cardColor, inkColor, accentColor, hlColor, successColor, dangerColor, showCallouts, showArrows
                )
                SceneTemplate.LOGIC_LEVEL_BAND -> drawLogicLevelBandScene(
                    canvas, mainRect, scale, textScale, scene, sceneProgress, globalTimeSec,
                    cardColor, inkColor, accentColor, hlColor, successColor, dangerColor, showCallouts, showArrows
                )
                SceneTemplate.CUTAWAY_XRAY -> drawCutawayXrayScene(
                    canvas, mainRect, scale, textScale, scene, sceneProgress, globalTimeSec,
                    cardColor, inkColor, accentColor, hlColor, successColor, dangerColor, showCallouts, showArrows
                )
                SceneTemplate.MAGNIFIER_LOUPE -> drawMagnifierLoupeScene(
                    canvas, mainRect, scale, textScale, scene, sceneProgress, globalTimeSec,
                    cardColor, inkColor, accentColor, hlColor, successColor, dangerColor, showCallouts, showArrows
                )
                SceneTemplate.COMPARISON_CARDS -> drawComparisonCardsScene(
                    canvas, mainRect, scale, textScale, scene, sceneProgress,
                    cardColor, inkColor, accentColor, hlColor, successColor, dangerColor
                )
                SceneTemplate.PROGRESS_BARS_COUNTER -> drawProgressCounterScene(
                    canvas, mainRect, scale, textScale, scene, sceneProgress,
                    cardColor, inkColor, accentColor, hlColor, successColor
                )
                SceneTemplate.STAT_DASHBOARD -> drawStatDashboardScene(
                    canvas, mainRect, scale, textScale, scene, sceneProgress,
                    cardColor, inkColor, accentColor, hlColor, successColor, dangerColor
                )
                SceneTemplate.DEVICE_GRID -> drawDeviceGridScene(
                    canvas, mainRect, scale, textScale, scene, sceneProgress,
                    cardColor, inkColor, accentColor, hlColor, successColor
                )
                SceneTemplate.HERO_TITLE -> drawHeroTitleScene(
                    canvas, mainRect, scale, textScale, scene, sceneProgress, globalTimeSec,
                    cardColor, inkColor, accentColor, hlColor
                )
                SceneTemplate.IMAGE_SHOWCASE -> drawImageShowcaseScene(
                    canvas, mainRect, scale, textScale, scene, sceneProgress,
                    cardColor, inkColor, accentColor, hlColor, customImages[scene.imageSlotKey]
                )
                SceneTemplate.OUTRO_CTA -> drawOutroCtaScene(
                    canvas, mainRect, scale, textScale, project, scene, sceneProgress, globalTimeSec,
                    cardColor, inkColor, accentColor, hlColor, successColor
                )
            }
        }

        // 4. Particles & Sticker Badge Layer
        if ("particles" in visibleLayerIds) {
            drawParticlesAndSticker(canvas, width, height, scale, scene, globalTimeSec, accentColor, hlColor)
        }

        // 5. Bottom Voice-Synced Subtitle Safe Zone (Y: 83% - 96%)
        if (project.subtitleEnabled && "subtitle" in visibleLayerIds) {
            val activeCueText = project.srtCues.firstOrNull {
                globalTimeSec >= it.startSec && globalTimeSec <= it.endSec
            }?.text ?: scene.subtext.ifBlank { scene.heading }

            drawBottomSubtitle(
                canvas = canvas,
                width = width,
                height = height,
                scale = scale,
                text = activeCueText,
                style = project.subtitleStyle,
                position = project.subtitlePosition,
                sizePercent = project.subtitleSizePercent,
                inkColor = Color.WHITE,
                hlColor = hlColor,
                accentColor = accentColor,
                progress = sceneProgress
            )
        }
    }

    private fun drawBackground(
        canvas: Canvas,
        width: Float,
        height: Float,
        bgColor: Int,
        bgSecColor: Int,
        accentColor: Int,
        pattern: String,
        isLightGrid: Boolean,
        timeSec: Float
    ) {
        fillPaint.shader = LinearGradient(
            0f, 0f, width, height,
            bgColor, bgSecColor, Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, width, height, fillPaint)
        fillPaint.shader = null

        if (isLightGrid || pattern == "light_grid" || pattern == "cyber_grid") {
            strokePaint.pathEffect = null
            strokePaint.strokeWidth = 1.2f
            strokePaint.color = if (isLightGrid) Color.argb(28, 15, 23, 42) else Color.argb(25, 56, 189, 248)
            val step = max(24f, width / 28f)
            var x = 0f
            while (x < width) {
                canvas.drawLine(x, 0f, x, height, strokePaint)
                x += step
            }
            var y = 0f
            while (y < height) {
                canvas.drawLine(0f, y, width, y, strokePaint)
                y += step
            }
        } else {
            // Diagonal light rays
            fillPaint.color = Color.argb(14, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor))
            for (i in 0..3) {
                val shift = sin(timeSec * 0.7f + i) * 30f
                val path = Path().apply {
                    moveTo(width * (0.12f + i * 0.22f) + shift, 0f)
                    lineTo(width * (0.22f + i * 0.22f) + shift, 0f)
                    lineTo(width * (0.42f + i * 0.22f) + shift, height)
                    lineTo(width * (0.30f + i * 0.22f) + shift, height)
                    close()
                }
                canvas.drawPath(path, fillPaint)
            }
        }
    }

    private fun drawTopChapterBadge(
        canvas: Canvas,
        width: Float,
        height: Float,
        scale: Float,
        scene: ProMotionScene,
        accentColor: Int,
        hlColor: Int,
        inkColor: Int,
        cardColor: Int
    ) {
        val left = width * 0.05f
        val top = height * 0.045f
        val badgeHeight = 36f * scale

        // Number circle
        fillPaint.color = hlColor
        val radius = badgeHeight * 0.5f
        canvas.drawCircle(left + radius, top + radius, radius, fillPaint)

        textPaint.color = Color.parseColor("#0B0F19")
        textPaint.textSize = 16f * scale
        textPaint.textAlign = Paint.Align.CENTER
        canvas.drawText("${scene.chapterNum}", left + radius, top + radius + 5.5f * scale, textPaint)

        // Pill beside circle
        textPaint.textSize = 15f * scale
        textPaint.textAlign = Paint.Align.LEFT
        val badgeText = scene.chapterBadge.ifBlank { "অধ্যায় ${scene.chapterNum}" }
        val textW = textPaint.measureText(badgeText)
        val pillRect = RectF(
            left + badgeHeight + 8f * scale,
            top,
            left + badgeHeight + textW + 32f * scale,
            top + badgeHeight
        )
        fillPaint.color = cardColor
        canvas.drawRoundRect(pillRect, badgeHeight / 2f, badgeHeight / 2f, fillPaint)
        strokePaint.color = accentColor
        strokePaint.strokeWidth = 1.6f * scale
        canvas.drawRoundRect(pillRect, badgeHeight / 2f, badgeHeight / 2f, strokePaint)

        textPaint.color = inkColor
        canvas.drawText(badgeText, pillRect.left + 12f * scale, top + radius + 5.5f * scale, textPaint)
    }

    private fun drawSplitCardScene(
        canvas: Canvas,
        rect: RectF,
        scale: Float,
        textScale: Float,
        scene: ProMotionScene,
        progress: Float,
        timeSec: Float,
        cardColor: Int,
        inkColor: Int,
        accentColor: Int,
        hlColor: Int,
        successColor: Int,
        dangerColor: Int,
        showCallouts: Boolean
    ) {
        val ease = easeOutCubic(progress)
        val leftRect = RectF(rect.left, rect.top, rect.left + rect.width() * 0.46f, rect.bottom)
        val rightRect = RectF(rect.left + rect.width() * 0.50f, rect.top, rect.right, rect.bottom)

        // Left Typography & Status Pills
        drawBracketHighlightedMultilineText(
            canvas = canvas,
            text = scene.heading,
            x = leftRect.left,
            y = leftRect.top + 48f * scale,
            maxWidth = leftRect.width(),
            fontSize = 30f * scale * textScale,
            inkColor = inkColor,
            hlColor = hlColor
        )

        // Animated wavy underline
        strokePaint.color = hlColor
        strokePaint.strokeWidth = 3.5f * scale
        val lineY = leftRect.top + 145f * scale
        canvas.drawLine(leftRect.left, lineY, leftRect.left + leftRect.width() * 0.65f * ease, lineY, strokePaint)

        // Status pills
        scene.statusPills.take(2).forEachIndexed { idx, pill ->
            val pTop = lineY + 26f * scale + idx * 52f * scale
            val pRect = RectF(leftRect.left, pTop, leftRect.left + leftRect.width() * 0.92f, pTop + 40f * scale)
            val isNegative = pill.contains("✕") || pill.contains("নিষিদ্ধ")
            val pColor = if (isNegative) dangerColor else successColor
            fillPaint.color = Color.argb(38, Color.red(pColor), Color.green(pColor), Color.blue(pColor))
            canvas.drawRoundRect(pRect, 12f * scale, 12f * scale, fillPaint)
            strokePaint.color = pColor
            strokePaint.strokeWidth = 1.8f * scale
            canvas.drawRoundRect(pRect, 12f * scale, 12f * scale, strokePaint)

            textPaint.color = inkColor
            textPaint.textSize = 15.5f * scale * textScale
            textPaint.textAlign = Paint.Align.LEFT
            canvas.drawText(pill, pRect.left + 14f * scale, pRect.centerY() + 5.5f * scale, textPaint)
        }

        // Right Framed Vector Card
        fillPaint.color = cardColor
        canvas.drawRoundRect(rightRect, 22f * scale, 22f * scale, fillPaint)
        strokePaint.color = accentColor
        strokePaint.strokeWidth = 2.2f * scale
        canvas.drawRoundRect(rightRect, 22f * scale, 22f * scale, strokePaint)

        // Interactive animated switch / signal nodes inside right card
        val cx = rightRect.centerX()
        val cy = rightRect.centerY() - 18f * scale
        val isHigh = (sin(timeSec * 2.5f) >= 0f)

        // Glowing pulse ring
        fillPaint.color = if (isHigh) Color.argb(45, Color.red(successColor), Color.green(successColor), Color.blue(successColor))
        else Color.argb(45, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor))
        canvas.drawCircle(cx, cy, (68f + sin(timeSec * 4f) * 6f) * scale, fillPaint)

        fillPaint.color = if (isHigh) successColor else accentColor
        canvas.drawCircle(cx, cy, 46f * scale, fillPaint)

        textPaint.color = Color.parseColor("#0B0F19")
        textPaint.textSize = 26f * scale
        textPaint.textAlign = Paint.Align.CENTER
        canvas.drawText(if (isHigh) "HIGH (1)" else "LOW (0)", cx, cy + 9f * scale, textPaint)

        if (showCallouts) {
            scene.calloutLabels.take(3).forEachIndexed { idx, label ->
                val tagW = (rightRect.width() - 32f * scale) / 3f
                val tagLeft = rightRect.left + 12f * scale + idx * (tagW + 4f * scale)
                val tagTop = rightRect.bottom - 56f * scale
                val tagRect = RectF(tagLeft, tagTop, tagLeft + tagW, tagTop + 38f * scale)
                fillPaint.color = Color.argb(45, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor))
                canvas.drawRoundRect(tagRect, 10f * scale, 10f * scale, fillPaint)
                textPaint.color = inkColor
                textPaint.textSize = 13f * scale * textScale
                textPaint.textAlign = Paint.Align.CENTER
                canvas.drawText(label, tagRect.centerX(), tagRect.centerY() + 4.5f * scale, textPaint)
            }
        }
    }

    private fun drawWaveformLabScene(
        canvas: Canvas,
        rect: RectF,
        scale: Float,
        textScale: Float,
        scene: ProMotionScene,
        progress: Float,
        timeSec: Float,
        cardColor: Int,
        inkColor: Int,
        accentColor: Int,
        hlColor: Int,
        successColor: Int,
        dangerColor: Int,
        showCallouts: Boolean,
        showArrows: Boolean
    ) {
        // Heading at top of main zone
        drawBracketHighlightedMultilineText(
            canvas = canvas,
            text = scene.heading,
            x = rect.left,
            y = rect.top + 32f * scale,
            maxWidth = rect.width(),
            fontSize = 26f * scale * textScale,
            inkColor = inkColor,
            hlColor = hlColor
        )

        val scopeRect = RectF(rect.left, rect.top + 54f * scale, rect.right, rect.bottom - 10f * scale)
        fillPaint.color = cardColor
        canvas.drawRoundRect(scopeRect, 20f * scale, 20f * scale, fillPaint)
        strokePaint.color = accentColor
        strokePaint.strokeWidth = 2f * scale
        canvas.drawRoundRect(scopeRect, 20f * scale, 20f * scale, strokePaint)

        val plotLeft = scopeRect.left + 72f * scale
        val plotRight = scopeRect.right - 36f * scale
        val plotTop = scopeRect.top + 42f * scale
        val plotBottom = scopeRect.bottom - 58f * scale
        val plotMidY = (plotTop + plotBottom) * 0.5f

        // Coordinate axes
        strokePaint.color = Color.argb(140, Color.red(inkColor), Color.green(inkColor), Color.blue(inkColor))
        strokePaint.strokeWidth = 2f * scale
        canvas.drawLine(plotLeft, plotTop, plotLeft, plotBottom, strokePaint)
        canvas.drawLine(plotLeft, plotMidY, plotRight, plotMidY, strokePaint)

        // Axis labels (+V, 0, -V, Time)
        textPaint.color = inkColor
        textPaint.textSize = 13f * scale
        textPaint.textAlign = Paint.Align.RIGHT
        canvas.drawText("+5V (90%)", plotLeft - 10f * scale, plotTop + 18f * scale, textPaint)
        canvas.drawText("50%", plotLeft - 10f * scale, plotMidY + 5f * scale, textPaint)
        canvas.drawText("0V (10%)", plotLeft - 10f * scale, plotBottom - 6f * scale, textPaint)

        // 10%, 50%, 90% dashed reference lines for non-ideal pulse
        strokePaint.pathEffect = DashPathEffect(floatArrayOf(8f * scale, 6f * scale), 0f)
        strokePaint.strokeWidth = 1.2f * scale
        strokePaint.color = Color.argb(90, Color.red(hlColor), Color.green(hlColor), Color.blue(hlColor))
        val y90 = plotTop + (plotBottom - plotTop) * 0.15f
        val y10 = plotBottom - (plotBottom - plotTop) * 0.15f
        canvas.drawLine(plotLeft, y90, plotRight, y90, strokePaint)
        canvas.drawLine(plotLeft, y10, plotRight, y10, strokePaint)
        strokePaint.pathEffect = null

        // Draw live waveform path
        val wavePath = Path()
        val totalW = (plotRight - plotLeft) * easeOutCubic(progress).coerceAtLeast(0.15f)
        val steps = 140
        for (i in 0..steps) {
            val t = i.toFloat() / steps
            val x = plotLeft + t * totalW
            val phase = t * 3.0f * PI.toFloat() - timeSec * 1.5f
            val y = when (scene.waveformVariant) {
                WaveformVariant.SQUARE_WAVE -> if (sin(phase) >= 0f) y90 else y10
                WaveformVariant.POS_RECT_WAVE -> if (sin(phase) > 0.2f) y90 else plotMidY
                WaveformVariant.NEG_RECT_WAVE -> if (sin(phase) < -0.2f) y10 else plotMidY
                WaveformVariant.DIGITIZED_STAIRCASE -> {
                    val stepVal = ((sin(phase) + 1f) * 2.5f).toInt() / 5f
                    y10 - stepVal * (y10 - y90)
                }
                WaveformVariant.SINE_VS_NOISE -> {
                    plotMidY - sin(phase) * (plotBottom - plotTop) * 0.35f + sin(phase * 9f) * 8f * scale
                }
                WaveformVariant.NON_IDEAL_PULSE -> {
                    // Smooth trapezoidal pulse showing rise time tr, pulse width tw, fall time tf
                    val cycle = (t * 2f) % 1f
                    when {
                        cycle < 0.15f -> y10
                        cycle < 0.30f -> {
                            val r = (cycle - 0.15f) / 0.15f
                            y10 - r * (y10 - y90)
                        }
                        cycle < 0.65f -> y90
                        cycle < 0.80f -> {
                            val f = (cycle - 0.65f) / 0.15f
                            y90 + f * (y10 - y90)
                        }
                        else -> y10
                    }
                }
            }
            if (i == 0) wavePath.moveTo(x, y) else wavePath.lineTo(x, y)
        }
        strokePaint.color = successColor
        strokePaint.strokeWidth = 4.2f * scale
        canvas.drawPath(wavePath, strokePaint)

        // Double arrows & callouts at bottom of scope
        if (showArrows) {
            strokePaint.color = hlColor
            strokePaint.strokeWidth = 2.5f * scale
            val arrowY = plotBottom + 18f * scale
            canvas.drawLine(plotLeft + 40f * scale, arrowY, plotRight - 40f * scale, arrowY, strokePaint)
        }
        if (showCallouts) {
            scene.calloutLabels.take(3).forEachIndexed { idx, label ->
                val pillW = (scopeRect.width() - 48f * scale) / 3f
                val pLeft = scopeRect.left + 16f * scale + idx * (pillW + 8f * scale)
                val pRect = RectF(pLeft, scopeRect.bottom - 44f * scale, pLeft + pillW, scopeRect.bottom - 10f * scale)
                fillPaint.color = Color.argb(45, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor))
                canvas.drawRoundRect(pRect, 8f * scale, 8f * scale, fillPaint)
                textPaint.color = hlColor
                textPaint.textSize = 13.5f * scale * textScale
                textPaint.textAlign = Paint.Align.CENTER
                canvas.drawText(label, pRect.centerX(), pRect.centerY() + 5f * scale, textPaint)
            }
        }
    }

    private fun drawLogicLevelBandScene(
        canvas: Canvas,
        rect: RectF,
        scale: Float,
        textScale: Float,
        scene: ProMotionScene,
        progress: Float,
        timeSec: Float,
        cardColor: Int,
        inkColor: Int,
        accentColor: Int,
        hlColor: Int,
        successColor: Int,
        dangerColor: Int,
        showCallouts: Boolean,
        showArrows: Boolean
    ) {
        drawBracketHighlightedMultilineText(
            canvas = canvas,
            text = scene.heading,
            x = rect.left,
            y = rect.top + 32f * scale,
            maxWidth = rect.width(),
            fontSize = 26f * scale * textScale,
            inkColor = inkColor,
            hlColor = hlColor
        )

        val towerRect = RectF(rect.left + rect.width() * 0.05f, rect.top + 56f * scale, rect.left + rect.width() * 0.52f, rect.bottom - 8f * scale)
        val bandH = towerRect.height() / 3f

        // 1. Top Band: HIGH (Binary 1) [2V - 5V]
        val highRect = RectF(towerRect.left, towerRect.top, towerRect.right, towerRect.top + bandH - 4f * scale)
        fillPaint.color = Color.argb(65, Color.red(successColor), Color.green(successColor), Color.blue(successColor))
        canvas.drawRoundRect(highRect, 14f * scale, 14f * scale, fillPaint)
        strokePaint.color = successColor
        strokePaint.strokeWidth = 2.5f * scale
        canvas.drawRoundRect(highRect, 14f * scale, 14f * scale, strokePaint)
        textPaint.color = inkColor
        textPaint.textSize = 17f * scale * textScale
        textPaint.textAlign = Paint.Align.CENTER
        canvas.drawText("HIGH (Binary 1) • 2.0V – 5.0V", highRect.centerX(), highRect.centerY() + 6f * scale, textPaint)

        // 2. Middle Band: Forbidden / Unacceptable [0.8V - 2V]
        val midRect = RectF(towerRect.left, towerRect.top + bandH, towerRect.right, towerRect.top + bandH * 2f - 4f * scale)
        val pulseAlpha = (55 + (sin(timeSec * 5f) + 1f) * 35).toInt().coerceIn(30, 140)
        fillPaint.color = Color.argb(pulseAlpha, Color.red(dangerColor), Color.green(dangerColor), Color.blue(dangerColor))
        canvas.drawRoundRect(midRect, 14f * scale, 14f * scale, fillPaint)
        strokePaint.color = dangerColor
        canvas.drawRoundRect(midRect, 14f * scale, 14f * scale, strokePaint)
        textPaint.color = inkColor
        canvas.drawText("✕ নিষিদ্ধ রেঞ্জ (Unacceptable) • 0.8V – 2.0V", midRect.centerX(), midRect.centerY() + 6f * scale, textPaint)

        // 3. Bottom Band: LOW (Binary 0) [0V - 0.8V]
        val lowRect = RectF(towerRect.left, towerRect.top + bandH * 2f, towerRect.right, towerRect.bottom)
        fillPaint.color = Color.argb(65, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor))
        canvas.drawRoundRect(lowRect, 14f * scale, 14f * scale, fillPaint)
        strokePaint.color = accentColor
        canvas.drawRoundRect(lowRect, 14f * scale, 14f * scale, strokePaint)
        textPaint.color = inkColor
        canvas.drawText("LOW (Binary 0) • 0.0V – 0.8V", lowRect.centerX(), lowRect.centerY() + 6f * scale, textPaint)

        // Right Voltage Test Probes
        val rightX = rect.left + rect.width() * 0.56f
        val probes = listOf(
            Triple("3.5V Probe ➔ ✓ Logic 1", highRect.centerY(), successColor),
            Triple("1.4V Probe ➔ ✕ Error!", midRect.centerY(), dangerColor),
            Triple("0.4V Probe ➔ ✓ Logic 0", lowRect.centerY(), accentColor)
        )
        probes.forEach { (label, centerY, color) ->
            val pRect = RectF(rightX, centerY - 22f * scale, rect.right, centerY + 22f * scale)
            fillPaint.color = cardColor
            canvas.drawRoundRect(pRect, 12f * scale, 12f * scale, fillPaint)
            strokePaint.color = color
            strokePaint.strokeWidth = 2f * scale
            canvas.drawRoundRect(pRect, 12f * scale, 12f * scale, strokePaint)

            if (showArrows) {
                canvas.drawLine(towerRect.right + 4f * scale, centerY, rightX - 4f * scale, centerY, strokePaint)
            }
            if (showCallouts) {
                textPaint.color = inkColor
                textPaint.textSize = 15f * scale * textScale
                textPaint.textAlign = Paint.Align.CENTER
                canvas.drawText(label, pRect.centerX(), centerY + 5.5f * scale, textPaint)
            }
        }
    }

    private fun drawCutawayXrayScene(
        canvas: Canvas,
        rect: RectF,
        scale: Float,
        textScale: Float,
        scene: ProMotionScene,
        progress: Float,
        timeSec: Float,
        cardColor: Int,
        inkColor: Int,
        accentColor: Int,
        hlColor: Int,
        successColor: Int,
        dangerColor: Int,
        showCallouts: Boolean,
        showArrows: Boolean
    ) {
        drawBracketHighlightedMultilineText(
            canvas = canvas,
            text = scene.heading,
            x = rect.left,
            y = rect.top + 32f * scale,
            maxWidth = rect.width(),
            fontSize = 26f * scale * textScale,
            inkColor = inkColor,
            hlColor = hlColor
        )

        val batRect = RectF(
            rect.centerX() - 210f * scale,
            rect.top + 85f * scale,
            rect.centerX() + 190f * scale,
            rect.bottom - 55f * scale
        )
        // Outer Zinc Shell
        fillPaint.color = cardColor
        canvas.drawRoundRect(batRect, 22f * scale, 22f * scale, fillPaint)
        strokePaint.color = accentColor
        strokePaint.strokeWidth = 3f * scale
        canvas.drawRoundRect(batRect, 22f * scale, 22f * scale, strokePaint)

        // Positive terminal nub on right
        val nubRect = RectF(batRect.right, batRect.centerY() - 28f * scale, batRect.right + 22f * scale, batRect.centerY() + 28f * scale)
        fillPaint.color = hlColor
        canvas.drawRoundRect(nubRect, 6f * scale, 6f * scale, fillPaint)

        // Electrolyte Paste Layer
        val pasteRect = RectF(batRect.left + 16f * scale, batRect.top + 16f * scale, batRect.right - 16f * scale, batRect.bottom - 16f * scale)
        fillPaint.color = Color.argb(55, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor))
        canvas.drawRoundRect(pasteRect, 14f * scale, 14f * scale, fillPaint)

        // Center Carbon Rod
        val rodRect = RectF(batRect.left + 26f * scale, batRect.centerY() - 16f * scale, batRect.right - 8f * scale, batRect.centerY() + 16f * scale)
        fillPaint.color = Color.parseColor("#334155")
        canvas.drawRoundRect(rodRect, 8f * scale, 8f * scale, fillPaint)
        strokePaint.color = hlColor
        strokePaint.strokeWidth = 1.6f * scale
        canvas.drawRoundRect(rodRect, 8f * scale, 8f * scale, strokePaint)

        // Animated oscillating electrolyte granules & e- flow
        if (showArrows) {
            fillPaint.color = successColor
            for (i in 0..14) {
                val gx = pasteRect.left + ((i * 37f + timeSec * 45f) % max(1f, pasteRect.width() / scale)) * scale
                val gy = if (i % 2 == 0) pasteRect.top + 20f * scale + sin(timeSec * 3f + i) * 8f * scale
                else pasteRect.bottom - 20f * scale + cos(timeSec * 3f + i) * 8f * scale
                canvas.drawCircle(gx, gy, 5.5f * scale, fillPaint)
            }
        }

        // Exterior Callout Labels
        if (showCallouts) {
            scene.calloutLabels.take(3).forEachIndexed { idx, label ->
                val pillW = (rect.width() - 32f * scale) / 3f
                val pLeft = rect.left + idx * (pillW + 16f * scale)
                val pRect = RectF(pLeft, rect.bottom - 42f * scale, pLeft + pillW, rect.bottom - 4f * scale)
                fillPaint.color = cardColor
                canvas.drawRoundRect(pRect, 10f * scale, 10f * scale, fillPaint)
                strokePaint.color = hlColor
                strokePaint.strokeWidth = 1.8f * scale
                canvas.drawRoundRect(pRect, 10f * scale, 10f * scale, strokePaint)
                textPaint.color = inkColor
                textPaint.textSize = 14f * scale * textScale
                textPaint.textAlign = Paint.Align.CENTER
                canvas.drawText(label, pRect.centerX(), pRect.centerY() + 5f * scale, textPaint)
            }
        }
    }

    private fun drawMagnifierLoupeScene(
        canvas: Canvas,
        rect: RectF,
        scale: Float,
        textScale: Float,
        scene: ProMotionScene,
        progress: Float,
        timeSec: Float,
        cardColor: Int,
        inkColor: Int,
        accentColor: Int,
        hlColor: Int,
        successColor: Int,
        dangerColor: Int,
        showCallouts: Boolean,
        showArrows: Boolean
    ) {
        drawBracketHighlightedMultilineText(
            canvas = canvas,
            text = scene.heading,
            x = rect.left,
            y = rect.top + 32f * scale,
            maxWidth = rect.width(),
            fontSize = 25f * scale * textScale,
            inkColor = inkColor,
            hlColor = hlColor
        )

        // Left Macro Object with compression force arrows
        val macroRect = RectF(rect.left + 20f * scale, rect.top + 88f * scale, rect.left + rect.width() * 0.42f, rect.bottom - 36f * scale)
        fillPaint.color = cardColor
        canvas.drawRoundRect(macroRect, 18f * scale, 18f * scale, fillPaint)
        strokePaint.color = dangerColor
        strokePaint.strokeWidth = 2.5f * scale
        canvas.drawRoundRect(macroRect, 18f * scale, 18f * scale, strokePaint)

        textPaint.color = inkColor
        textPaint.textSize = 16f * scale * textScale
        textPaint.textAlign = Paint.Align.CENTER
        canvas.drawText("চাপ প্রয়োগ (Force ↓↑)", macroRect.centerX(), macroRect.centerY() + 6f * scale, textPaint)

        // Right 4x Microscopic Magnifier Loupe
        val loupeCx = rect.left + rect.width() * 0.72f
        val loupeCy = rect.top + rect.height() * 0.56f
        val loupeR = min(rect.width() * 0.22f, rect.height() * 0.36f)

        fillPaint.color = cardColor
        canvas.drawCircle(loupeCx, loupeCy, loupeR, fillPaint)

        // Microscopic shattered barrier shards inside loupe
        val shardBurst = (sin(timeSec * 2.5f) + 1f) * 0.5f
        for (i in 0 until 12) {
            val angle = (i * 30f) * (PI.toFloat() / 180f)
            val dist = (22f + shardBurst * 36f) * scale
            val sx = loupeCx + cos(angle) * dist
            val sy = loupeCy + sin(angle) * dist
            fillPaint.color = if (i % 2 == 0) successColor else hlColor
            canvas.drawCircle(sx, sy, 7f * scale, fillPaint)
        }

        strokePaint.color = hlColor
        strokePaint.strokeWidth = 4.5f * scale
        canvas.drawCircle(loupeCx, loupeCy, loupeR, strokePaint)

        if (showArrows) {
            strokePaint.color = accentColor
            strokePaint.strokeWidth = 2.2f * scale
            canvas.drawLine(macroRect.right, macroRect.centerY(), loupeCx - loupeR, loupeCy, strokePaint)
        }

        if (showCallouts) {
            val label = scene.calloutLabels.firstOrNull() ?: "4× Microscopic Loupe"
            textPaint.color = hlColor
            textPaint.textSize = 15f * scale * textScale
            textPaint.textAlign = Paint.Align.CENTER
            canvas.drawText(label, loupeCx, loupeCy + loupeR + 24f * scale, textPaint)
        }
    }

    private fun drawComparisonCardsScene(
        canvas: Canvas,
        rect: RectF,
        scale: Float,
        textScale: Float,
        scene: ProMotionScene,
        progress: Float,
        cardColor: Int,
        inkColor: Int,
        accentColor: Int,
        hlColor: Int,
        successColor: Int,
        dangerColor: Int
    ) {
        drawBracketHighlightedMultilineText(
            canvas = canvas,
            text = scene.heading,
            x = rect.left,
            y = rect.top + 32f * scale,
            maxWidth = rect.width(),
            fontSize = 26f * scale * textScale,
            inkColor = inkColor,
            hlColor = hlColor
        )

        val gap = 20f * scale
        val cardW = (rect.width() - gap) / 2f
        val topY = rect.top + 64f * scale

        val leftCard = RectF(rect.left, topY, rect.left + cardW, rect.bottom - 12f * scale)
        val rightCard = RectF(rect.left + cardW + gap, topY, rect.right, rect.bottom - 12f * scale)

        // Left Card (Danger / Comparison A)
        fillPaint.color = cardColor
        canvas.drawRoundRect(leftCard, 20f * scale, 20f * scale, fillPaint)
        strokePaint.color = dangerColor
        strokePaint.strokeWidth = 2.8f * scale
        canvas.drawRoundRect(leftCard, 20f * scale, 20f * scale, strokePaint)

        textPaint.color = dangerColor
        textPaint.textSize = 28f * scale
        textPaint.textAlign = Paint.Align.CENTER
        canvas.drawText("✕", leftCard.centerX(), leftCard.top + 56f * scale, textPaint)

        textPaint.color = inkColor
        textPaint.textSize = 18f * scale * textScale
        val labelA = scene.calloutLabels.getOrNull(0) ?: "তুলনা ১"
        canvas.drawText(labelA, leftCard.centerX(), leftCard.centerY() + 12f * scale, textPaint)

        val pillA = scene.statusPills.getOrNull(1) ?: "✕ ঝুঁকিপূর্ণ পদ্ধতি"
        textPaint.textSize = 14f * scale * textScale
        canvas.drawText(pillA, leftCard.centerX(), leftCard.bottom - 28f * scale, textPaint)

        // Right Card (Success / Comparison B)
        fillPaint.color = cardColor
        canvas.drawRoundRect(rightCard, 20f * scale, 20f * scale, fillPaint)
        strokePaint.color = successColor
        strokePaint.strokeWidth = 2.8f * scale
        canvas.drawRoundRect(rightCard, 20f * scale, 20f * scale, strokePaint)

        textPaint.color = successColor
        textPaint.textSize = 28f * scale
        canvas.drawText("✓", rightCard.centerX(), rightCard.top + 56f * scale, textPaint)

        textPaint.color = inkColor
        textPaint.textSize = 18f * scale * textScale
        val labelB = scene.calloutLabels.getOrNull(1) ?: "তুলনা ২"
        canvas.drawText(labelB, rightCard.centerX(), rightCard.centerY() + 12f * scale, textPaint)

        val pillB = scene.statusPills.getOrNull(0) ?: "✓ সঠিক ও নিরাপদ"
        textPaint.textSize = 14f * scale * textScale
        canvas.drawText(pillB, rightCard.centerX(), rightCard.bottom - 28f * scale, textPaint)
    }

    private fun drawProgressCounterScene(
        canvas: Canvas,
        rect: RectF,
        scale: Float,
        textScale: Float,
        scene: ProMotionScene,
        progress: Float,
        cardColor: Int,
        inkColor: Int,
        accentColor: Int,
        hlColor: Int,
        successColor: Int
    ) {
        val ease = easeOutCubic(progress)
        drawBracketHighlightedMultilineText(
            canvas = canvas,
            text = scene.heading,
            x = rect.left,
            y = rect.top + 32f * scale,
            maxWidth = rect.width(),
            fontSize = 26f * scale * textScale,
            inkColor = inkColor,
            hlColor = hlColor
        )

        // Left Circular Ring Gauge
        val ringCx = rect.left + rect.width() * 0.25f
        val ringCy = rect.top + rect.height() * 0.58f
        val ringR = min(rect.width() * 0.16f, rect.height() * 0.30f)
        val ringOval = RectF(ringCx - ringR, ringCy - ringR, ringCx + ringR, ringCy + ringR)

        strokePaint.color = Color.argb(50, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor))
        strokePaint.strokeWidth = 14f * scale
        canvas.drawArc(ringOval, 0f, 360f, false, strokePaint)

        strokePaint.color = hlColor
        canvas.drawArc(ringOval, -90f, 360f * (scene.counterTarget.coerceIn(1, 100) / 100f) * ease, false, strokePaint)

        val currentVal = (scene.counterTarget * ease).toInt()
        textPaint.color = inkColor
        textPaint.textSize = 32f * scale * textScale
        textPaint.textAlign = Paint.Align.CENTER
        canvas.drawText("$currentVal${scene.counterSuffix}", ringCx, ringCy + 11f * scale, textPaint)

        // Right Racing Progress Bars
        val barsLeft = rect.left + rect.width() * 0.48f
        val barsRight = rect.right - 16f * scale
        scene.calloutLabels.take(3).forEachIndexed { idx, label ->
            val barTop = rect.top + 88f * scale + idx * 72f * scale
            textPaint.color = inkColor
            textPaint.textSize = 15.5f * scale * textScale
            textPaint.textAlign = Paint.Align.LEFT
            canvas.drawText(label, barsLeft, barTop, textPaint)

            val trackRect = RectF(barsLeft, barTop + 10f * scale, barsRight, barTop + 32f * scale)
            fillPaint.color = cardColor
            canvas.drawRoundRect(trackRect, 11f * scale, 11f * scale, fillPaint)

            val fillRatio = ((1f - idx * 0.14f) * ease).coerceIn(0.1f, 1f)
            val fillRect = RectF(barsLeft, barTop + 10f * scale, barsLeft + trackRect.width() * fillRatio, barTop + 32f * scale)
            fillPaint.color = if (idx == 0) successColor else accentColor
            canvas.drawRoundRect(fillRect, 11f * scale, 11f * scale, fillPaint)
        }
    }

    private fun drawStatDashboardScene(
        canvas: Canvas,
        rect: RectF,
        scale: Float,
        textScale: Float,
        scene: ProMotionScene,
        progress: Float,
        cardColor: Int,
        inkColor: Int,
        accentColor: Int,
        hlColor: Int,
        successColor: Int,
        dangerColor: Int
    ) {
        val ease = easeOutCubic(progress)
        drawBracketHighlightedMultilineText(
            canvas = canvas,
            text = scene.heading,
            x = rect.left,
            y = rect.top + 32f * scale,
            maxWidth = rect.width(),
            fontSize = 26f * scale * textScale,
            inkColor = inkColor,
            hlColor = hlColor
        )

        val dashRect = RectF(rect.left, rect.top + 58f * scale, rect.right, rect.bottom - 10f * scale)
        fillPaint.color = cardColor
        canvas.drawRoundRect(dashRect, 20f * scale, 20f * scale, fillPaint)
        strokePaint.color = accentColor
        strokePaint.strokeWidth = 2f * scale
        canvas.drawRoundRect(dashRect, 20f * scale, 20f * scale, strokePaint)

        val items = scene.chartItems.take(4)
        if (items.isNotEmpty()) {
            val colW = (dashRect.width() - 64f * scale) / items.size
            val maxBarH = dashRect.height() * 0.56f
            val baseLineY = dashRect.bottom - 52f * scale

            items.forEachIndexed { idx, item ->
                val cx = dashRect.left + 32f * scale + colW * idx + colW * 0.5f
                val barW = min(68f * scale, colW * 0.55f)
                val barH = maxBarH * (item.value.coerceIn(5f, 100f) / 100f) * ease
                val barRect = RectF(cx - barW * 0.5f, baseLineY - barH, cx + barW * 0.5f, baseLineY)

                fillPaint.color = if (item.isPositive) (if (idx % 2 == 0) accentColor else successColor) else dangerColor
                canvas.drawRoundRect(barRect, 10f * scale, 10f * scale, fillPaint)

                textPaint.color = hlColor
                textPaint.textSize = 16f * scale * textScale
                textPaint.textAlign = Paint.Align.CENTER
                canvas.drawText("${(item.value * ease).toInt()}${item.unit}", cx, barRect.top - 10f * scale, textPaint)

                textPaint.color = inkColor
                textPaint.textSize = 14f * scale * textScale
                canvas.drawText(item.label, cx, baseLineY + 26f * scale, textPaint)
            }
        }
    }

    private fun drawDeviceGridScene(
        canvas: Canvas,
        rect: RectF,
        scale: Float,
        textScale: Float,
        scene: ProMotionScene,
        progress: Float,
        cardColor: Int,
        inkColor: Int,
        accentColor: Int,
        hlColor: Int,
        successColor: Int
    ) {
        drawBracketHighlightedMultilineText(
            canvas = canvas,
            text = scene.heading,
            x = rect.left,
            y = rect.top + 32f * scale,
            maxWidth = rect.width(),
            fontSize = 26f * scale * textScale,
            inkColor = inkColor,
            hlColor = hlColor
        )

        val labels = scene.calloutLabels.ifEmpty { listOf("Device 1", "Device 2", "Device 3", "Device 4") }
        val cols = min(4, max(2, labels.size))
        val gap = 16f * scale
        val cardW = (rect.width() - gap * (cols - 1)) / cols
        val topY = rect.top + 68f * scale

        labels.take(4).forEachIndexed { idx, label ->
            val cLeft = rect.left + idx * (cardW + gap)
            val cRect = RectF(cLeft, topY, cLeft + cardW, rect.bottom - 18f * scale)
            val isLit = progress * cols >= idx

            fillPaint.color = cardColor
            canvas.drawRoundRect(cRect, 18f * scale, 18f * scale, fillPaint)
            strokePaint.color = if (isLit) successColor else accentColor
            strokePaint.strokeWidth = if (isLit) 3f * scale else 1.5f * scale
            canvas.drawRoundRect(cRect, 18f * scale, 18f * scale, strokePaint)

            // Icon circle
            fillPaint.color = Color.argb(45, Color.red(hlColor), Color.green(hlColor), Color.blue(hlColor))
            canvas.drawCircle(cRect.centerX(), cRect.centerY() - 20f * scale, 30f * scale, fillPaint)

            textPaint.color = hlColor
            textPaint.textSize = 22f * scale
            textPaint.textAlign = Paint.Align.CENTER
            canvas.drawText("0${idx + 1}", cRect.centerX(), cRect.centerY() - 12f * scale, textPaint)

            textPaint.color = inkColor
            textPaint.textSize = 15.5f * scale * textScale
            canvas.drawText(label, cRect.centerX(), cRect.bottom - 34f * scale, textPaint)
        }
    }

    private fun drawHeroTitleScene(
        canvas: Canvas,
        rect: RectF,
        scale: Float,
        textScale: Float,
        scene: ProMotionScene,
        progress: Float,
        timeSec: Float,
        cardColor: Int,
        inkColor: Int,
        accentColor: Int,
        hlColor: Int
    ) {
        val heroCard = RectF(rect.left + rect.width() * 0.04f, rect.top + 18f * scale, rect.right - rect.width() * 0.04f, rect.bottom - 18f * scale)
        fillPaint.color = cardColor
        canvas.drawRoundRect(heroCard, 26f * scale, 26f * scale, fillPaint)
        strokePaint.color = hlColor
        strokePaint.strokeWidth = 2.5f * scale
        canvas.drawRoundRect(heroCard, 26f * scale, 26f * scale, strokePaint)

        drawBracketHighlightedMultilineText(
            canvas = canvas,
            text = scene.heading,
            x = heroCard.left + 32f * scale,
            y = heroCard.top + 78f * scale,
            maxWidth = heroCard.width() - 64f * scale,
            fontSize = 34f * scale * textScale,
            inkColor = inkColor,
            hlColor = hlColor
        )

        // Callout chips at bottom of hero card
        scene.calloutLabels.take(3).forEachIndexed { idx, chip ->
            val chipW = (heroCard.width() - 80f * scale) / 3f
            val chipLeft = heroCard.left + 24f * scale + idx * (chipW + 16f * scale)
            val chipRect = RectF(chipLeft, heroCard.bottom - 64f * scale, chipLeft + chipW, heroCard.bottom - 22f * scale)
            fillPaint.color = Color.argb(45, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor))
            canvas.drawRoundRect(chipRect, 12f * scale, 12f * scale, fillPaint)
            textPaint.color = accentColor
            textPaint.textSize = 14.5f * scale * textScale
            textPaint.textAlign = Paint.Align.CENTER
            canvas.drawText(chip, chipRect.centerX(), chipRect.centerY() + 5f * scale, textPaint)
        }
    }

    private fun drawImageShowcaseScene(
        canvas: Canvas,
        rect: RectF,
        scale: Float,
        textScale: Float,
        scene: ProMotionScene,
        progress: Float,
        cardColor: Int,
        inkColor: Int,
        accentColor: Int,
        hlColor: Int,
        bitmap: Bitmap?
    ) {
        drawBracketHighlightedMultilineText(
            canvas = canvas,
            text = scene.heading,
            x = rect.left,
            y = rect.top + 32f * scale,
            maxWidth = rect.width(),
            fontSize = 25f * scale * textScale,
            inkColor = inkColor,
            hlColor = hlColor
        )

        val frameRect = RectF(rect.left + rect.width() * 0.06f, rect.top + 58f * scale, rect.left + rect.width() * 0.62f, rect.bottom - 12f * scale)
        fillPaint.color = cardColor
        canvas.drawRoundRect(frameRect, 18f * scale, 18f * scale, fillPaint)
        strokePaint.color = accentColor
        strokePaint.strokeWidth = 2.5f * scale
        canvas.drawRoundRect(frameRect, 18f * scale, 18f * scale, strokePaint)

        if (bitmap != null && !bitmap.isRecycled) {
            val innerRect = RectF(frameRect.left + 10f * scale, frameRect.top + 10f * scale, frameRect.right - 10f * scale, frameRect.bottom - 10f * scale)
            canvas.drawBitmap(bitmap, null, innerRect, null)
        } else {
            textPaint.color = accentColor
            textPaint.textSize = 16f * scale * textScale
            textPaint.textAlign = Paint.Align.CENTER
            canvas.drawText("🖼️ ছবি টুল থেকে ${scene.imageSlotKey} দিন", frameRect.centerX(), frameRect.centerY() - 6f * scale, textPaint)
            textPaint.color = inkColor
            textPaint.textSize = 13f * scale
            canvas.drawText("(গ্যালারি ছবি / বইয়ের পাতা ফ্রেম)", frameRect.centerX(), frameRect.centerY() + 20f * scale, textPaint)
        }

        // Right Callout slots
        val rightX = rect.left + rect.width() * 0.66f
        scene.calloutLabels.take(3).forEachIndexed { idx, label ->
            val cTop = frameRect.top + idx * 70f * scale
            val cRect = RectF(rightX, cTop, rect.right, cTop + 52f * scale)
            fillPaint.color = cardColor
            canvas.drawRoundRect(cRect, 12f * scale, 12f * scale, fillPaint)
            strokePaint.color = hlColor
            strokePaint.strokeWidth = 1.8f * scale
            canvas.drawRoundRect(cRect, 12f * scale, 12f * scale, strokePaint)

            textPaint.color = inkColor
            textPaint.textSize = 14.5f * scale * textScale
            textPaint.textAlign = Paint.Align.CENTER
            canvas.drawText(label, cRect.centerX(), cRect.centerY() + 5f * scale, textPaint)
        }
    }

    private fun drawOutroCtaScene(
        canvas: Canvas,
        rect: RectF,
        scale: Float,
        textScale: Float,
        project: ProMotionProject,
        scene: ProMotionScene,
        progress: Float,
        timeSec: Float,
        cardColor: Int,
        inkColor: Int,
        accentColor: Int,
        hlColor: Int,
        successColor: Int
    ) {
        drawBracketHighlightedMultilineText(
            canvas = canvas,
            text = scene.heading,
            x = rect.left,
            y = rect.top + 32f * scale,
            maxWidth = rect.width(),
            fontSize = 26f * scale * textScale,
            inkColor = inkColor,
            hlColor = hlColor
        )

        // Golden-bordered Comment Input Box
        val commentRect = RectF(rect.left, rect.top + 56f * scale, rect.right, rect.top + 114f * scale)
        fillPaint.color = cardColor
        canvas.drawRoundRect(commentRect, 16f * scale, 16f * scale, fillPaint)
        strokePaint.color = hlColor
        strokePaint.strokeWidth = 2.5f * scale
        canvas.drawRoundRect(commentRect, 16f * scale, 16f * scale, strokePaint)

        textPaint.color = hlColor
        textPaint.textSize = 16.5f * scale * textScale
        textPaint.textAlign = Paint.Align.LEFT
        canvas.drawText(
            "💬 ${project.contactConfig.questionPrompt} ➔ ✈️",
            commentRect.left + 20f * scale,
            commentRect.centerY() + 6f * scale,
            textPaint
        )

        // 3 Social Cards (Facebook, Instagram, YouTube Subscribe)
        val socials = listOf(
            "Facebook — ✓ ফলো" to Color.parseColor("#3B82F6"),
            "Instagram — ✓ ফলো" to Color.parseColor("#EC4899"),
            "YouTube — ✓ সাবস্ক্রাইব 🔔" to Color.parseColor("#EF4444")
        )
        val gap = 14f * scale
        val sCardW = (rect.width() - gap * 2f) / 3f
        val sTop = commentRect.bottom + 18f * scale
        socials.forEachIndexed { idx, (label, sColor) ->
            val sLeft = rect.left + idx * (sCardW + gap)
            val sRect = RectF(sLeft, sTop, sLeft + sCardW, sTop + 62f * scale)
            fillPaint.color = cardColor
            canvas.drawRoundRect(sRect, 14f * scale, 14f * scale, fillPaint)
            strokePaint.color = sColor
            strokePaint.strokeWidth = 2.2f * scale
            canvas.drawRoundRect(sRect, 14f * scale, 14f * scale, strokePaint)

            textPaint.color = inkColor
            textPaint.textSize = 14.5f * scale * textScale
            textPaint.textAlign = Paint.Align.CENTER
            canvas.drawText(label, sRect.centerX(), sRect.centerY() + 5.5f * scale, textPaint)
        }

        // Contact Footer Card
        if (project.contactConfig.enabled) {
            val contactRect = RectF(rect.left, sTop + 78f * scale, rect.right, rect.bottom - 6f * scale)
            fillPaint.color = Color.argb(40, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor))
            canvas.drawRoundRect(contactRect, 14f * scale, 14f * scale, fillPaint)
            textPaint.color = inkColor
            textPaint.textSize = 14f * scale * textScale
            textPaint.textAlign = Paint.Align.CENTER
            val infoLine = "${project.contactConfig.brandName}  •  📞 ${project.contactConfig.phone}  •  🌐 ${project.contactConfig.website}"
            canvas.drawText(infoLine, contactRect.centerX(), contactRect.centerY() + 5f * scale, textPaint)
        }
    }

    private fun drawParticlesAndSticker(
        canvas: Canvas,
        width: Float,
        height: Float,
        scale: Float,
        scene: ProMotionScene,
        timeSec: Float,
        accentColor: Int,
        hlColor: Int
    ) {
        // Subtle floating ambient orbs
        fillPaint.color = Color.argb(35, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor))
        for (i in 0..5) {
            val px = (width * (0.12f + i * 0.16f) + sin(timeSec + i) * 18f * scale)
            val py = (height * (0.18f + (i % 3) * 0.25f) + cos(timeSec * 1.2f + i) * 14f * scale)
            canvas.drawCircle(px, py, (4f + (i % 3) * 2f) * scale, fillPaint)
        }

        // Top-right Sticker / Badge pill
        if (scene.stickerBadge.isNotBlank() || scene.stickerEmoji.isNotBlank()) {
            val badgeLabel = "${scene.stickerEmoji} ${scene.stickerBadge}".trim()
            textPaint.textSize = 14f * scale
            val bw = textPaint.measureText(badgeLabel) + 28f * scale
            val bRect = RectF(width * 0.95f - bw, height * 0.045f, width * 0.95f, height * 0.045f + 34f * scale)
            fillPaint.color = hlColor
            canvas.drawRoundRect(bRect, 17f * scale, 17f * scale, fillPaint)
            textPaint.color = Color.parseColor("#0B0F19")
            textPaint.textAlign = Paint.Align.CENTER
            canvas.drawText(badgeLabel, bRect.centerX(), bRect.centerY() + 5f * scale, textPaint)
        }
    }

    private fun drawBottomSubtitle(
        canvas: Canvas,
        width: Float,
        height: Float,
        scale: Float,
        text: String,
        style: SubtitleStyle,
        position: String,
        sizePercent: Int,
        inkColor: Int,
        hlColor: Int,
        accentColor: Int,
        progress: Float
    ) {
        val cleanText = SrtParser.stripBrackets(text)
        if (cleanText.isBlank()) return

        val fontScale = (sizePercent / 100f).coerceIn(0.6f, 1.5f)
        val fontSize = 20f * scale * fontScale
        textPaint.textSize = fontSize
        textPaint.textAlign = Paint.Align.CENTER

        val centerY = when (position) {
            "মাঝে" -> height * 0.52f
            "একটু উপরে" -> height * 0.82f
            else -> height * 0.90f
        }

        val textWidth = min(width * 0.88f, textPaint.measureText(cleanText) + 44f * scale)
        val pillH = fontSize * 2.1f
        val pillRect = RectF(
            (width - textWidth) * 0.5f,
            centerY - pillH * 0.5f,
            (width + textWidth) * 0.5f,
            centerY + pillH * 0.5f
        )

        when (style) {
            SubtitleStyle.PILL, SubtitleStyle.KARAOKE, SubtitleStyle.HIGHLIGHT -> {
                fillPaint.color = Color.argb(225, 11, 15, 25)
                canvas.drawRoundRect(pillRect, pillH * 0.5f, pillH * 0.5f, fillPaint)
                strokePaint.color = if (style == SubtitleStyle.KARAOKE) accentColor else hlColor
                strokePaint.strokeWidth = 2f * scale
                canvas.drawRoundRect(pillRect, pillH * 0.5f, pillH * 0.5f, strokePaint)
            }
            SubtitleStyle.CINEMA -> {
                fillPaint.color = Color.argb(210, 0, 0, 0)
                canvas.drawRect(0f, pillRect.top, width, pillRect.bottom, fillPaint)
            }
            SubtitleStyle.GLASS -> {
                fillPaint.color = Color.argb(175, 30, 41, 59)
                canvas.drawRoundRect(pillRect, 14f * scale, 14f * scale, fillPaint)
            }
            SubtitleStyle.NEON -> {
                fillPaint.color = Color.argb(220, 9, 19, 38)
                canvas.drawRoundRect(pillRect, 12f * scale, 12f * scale, fillPaint)
                strokePaint.color = Color.parseColor("#00F5D4")
                strokePaint.strokeWidth = 2.5f * scale
                canvas.drawRoundRect(pillRect, 12f * scale, 12f * scale, strokePaint)
            }
            SubtitleStyle.BOLD, SubtitleStyle.HORMOZI -> {
                fillPaint.color = Color.argb(200, 15, 23, 42)
                canvas.drawRoundRect(pillRect, 10f * scale, 10f * scale, fillPaint)
            }
        }

        drawBracketHighlightedCenteredLine(
            canvas = canvas,
            rawText = text,
            centerX = width * 0.5f,
            baselineY = centerY + fontSize * 0.35f,
            fontSize = fontSize,
            inkColor = inkColor,
            hlColor = hlColor
        )
    }

    private fun drawBracketHighlightedCenteredLine(
        canvas: Canvas,
        rawText: String,
        centerX: Float,
        baselineY: Float,
        fontSize: Float,
        inkColor: Int,
        hlColor: Int
    ) {
        val segments = parseBracketSegments(rawText)
        textPaint.textSize = fontSize
        textPaint.textAlign = Paint.Align.LEFT
        val totalW = segments.sumOf { textPaint.measureText(it.first).toDouble() }.toFloat()
        var curX = centerX - totalW * 0.5f
        for ((segText, isHighlighted) in segments) {
            textPaint.color = if (isHighlighted) hlColor else inkColor
            canvas.drawText(segText, curX, baselineY, textPaint)
            curX += textPaint.measureText(segText)
        }
    }

    private fun drawBracketHighlightedMultilineText(
        canvas: Canvas,
        text: String,
        x: Float,
        y: Float,
        maxWidth: Float,
        fontSize: Float,
        inkColor: Int,
        hlColor: Int
    ) {
        textPaint.textSize = fontSize
        textPaint.textAlign = Paint.Align.LEFT
        val segments = parseBracketSegments(text)
        var curX = x
        var curY = y
        val lineHeight = fontSize * 1.32f

        for ((segText, isHighlighted) in segments) {
            val words = segText.split(" ")
            for ((wIdx, word) in words.withIndex()) {
                val token = if (wIdx < words.lastIndex) "$word " else word
                val tokenW = textPaint.measureText(token)
                if (curX + tokenW > x + maxWidth && curX > x) {
                    curX = x
                    curY += lineHeight
                }
                textPaint.color = if (isHighlighted) hlColor else inkColor
                canvas.drawText(token, curX, curY, textPaint)
                curX += tokenW
            }
        }
    }

    fun parseBracketSegments(raw: String): List<Pair<String, Boolean>> {
        val result = mutableListOf<Pair<String, Boolean>>()
        val regex = Regex("""\[([^\]]+)]""")
        var lastIdx = 0
        for (match in regex.findAll(raw)) {
            if (match.range.first > lastIdx) {
                result.add(raw.substring(lastIdx, match.range.first) to false)
            }
            result.add(match.groupValues[1] to true)
            lastIdx = match.range.last + 1
        }
        if (lastIdx < raw.length) {
            result.add(raw.substring(lastIdx) to false)
        }
        return result.ifEmpty { listOf(raw to false) }
    }

    private fun easeOutCubic(x: Float): Float {
        val t = (1f - x.coerceIn(0f, 1f))
        return 1f - t * t * t
    }
}
