package com.example.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DemoProjects
import com.example.engine.CanvasVideoEngine
import com.example.model.BUILTIN_LOOKS
import com.example.model.SrtParser
import com.example.model.SubtitleStyle
import com.example.utils.GeminiPromptAndAiService
import com.example.utils.Mp4VideoExporter
import com.example.viewmodel.AiGenState
import com.example.viewmodel.ProMotionViewModel
import com.example.viewmodel.WizardType
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CreationWizardsModal(
    wizardType: WizardType,
    viewModel: ProMotionViewModel,
    aiState: AiGenState,
    onDismiss: () -> Unit
) {
    BackHandler { onDismiss() }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var selectedRatio by remember { mutableStateOf("16:9") }
    var selectedLookCategory by remember { mutableStateOf("সব") }
    var selectedLook by remember { mutableStateOf(BUILTIN_LOOKS[3]) } // Dual-Theme Master default
    var selectedLang by remember { mutableStateOf("বাংলা + English") }
    var isScriptMode by remember { mutableStateOf(false) }
    var topicInput by remember {
        mutableStateOf(
            if (wizardType == WizardType.SCIENCE_EXPLAINER) {
                "ডিজিটাল ইলেকট্রনিক্স অধ্যায় ১: অ্যানালগ বনাম ডিজিটাল সিগন্যাল, স্কয়ার ওয়েভ ও TTL লজিক লেভেল"
            } else {
                "ডেড ব্যাটারিতে কামড় বা চাপ দিলে টিভির রিমোট আবার কেন চলে? ভেতরের রাসায়নিক পেস্ট ও রেজিস্ট্যান্স এক্সপ্লেনার"
            }
        )
    }
    var selectedDuration by remember { mutableStateOf("Auto") }
    var zeroOverlapChecked by remember { mutableStateOf(true) }
    var pastedJsonText by remember { mutableStateOf("") }

    // Voice / SRT state
    var voiceModeFullMotion by remember { mutableStateOf(true) }
    var srtInputText by remember {
        mutableStateOf(
            """
1
00:00:00,000 --> 00:00:05,000
ডিজিটাল সিগন্যালের মাত্র [দুটি অবস্থা] থাকে — HIGH এবং LOW।

2
00:00:05,000 --> 00:00:11,000
অসিলোস্কোপে পালসের [Rise Time] এবং [Fall Time] পরিষ্কার দেখা যাচ্ছে।

3
00:00:11,000 --> 00:00:17,000
[2V থেকে 5V] হলো Logic 1 এবং মাঝের অংশ হলো [নিষিদ্ধ রেঞ্জ]!
""".trimIndent()
        )
    }
    var selectedSubStyle by remember { mutableStateOf(SubtitleStyle.PILL) }

    // Animated preview clock
    var previewTimeSec by remember { mutableFloatStateOf(1.2f) }
    LaunchedEffect(wizardType) {
        while (true) {
            delay(33L)
            previewTimeSec = (previewTimeSec + 0.033f) % 18f
        }
    }

    val parsedCues = remember(srtInputText) { SrtParser.parseSrt(srtInputText) }

    Surface(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing),
        color = Color(0xFF0B0F19)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // Top bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.testTag("wizard_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }
                Text(
                    text = when (wizardType) {
                        WizardType.SCRIPT_TO_MOTION -> "✨ Script থেকে Motion ভিডিও"
                        WizardType.VOICE_SRT_TO_MOTION -> "🎙️ Voice / SRT থেকে 100% Synced Motion"
                        WizardType.INSTANT_PASTE -> "⚡ শুধু Paste (JSON Auto-Fixer)"
                        WizardType.SCIENCE_EXPLAINER -> "🔬 Explainer ও বইয়ের পাতা স্টুডিও"
                        WizardType.THUMBNAIL_MAKER -> "🖼️ 16:9 YouTube Thumbnail মেকার"
                        WizardType.REMOTION_ZIP_TO_MP4 -> "📦 Remotion (.zip) ➔ MP4 কনভার্টার"
                        WizardType.NONE -> ""
                    },
                    style = MaterialTheme.typography.titleLarge,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            val remotionInspect by viewModel.remotionInspectResult.collectAsState()
            val customBitmaps by viewModel.customBitmaps.collectAsState()

            // Live Animated Look / Remotion Preview Canvas at Top
            val previewProject = remember(selectedLook, selectedRatio, wizardType, remotionInspect) {
                if (wizardType == WizardType.REMOTION_ZIP_TO_MP4 && remotionInspect != null) {
                    remotionInspect!!.instantConvertedProject
                } else {
                    DemoProjects.digitalElectronicsDemo.copy(
                        aspectRatio = selectedRatio,
                        lookId = selectedLook.id,
                        bgHex = selectedLook.bgHex,
                        bgSecondaryHex = selectedLook.bgSecondaryHex,
                        cardHex = selectedLook.cardHex,
                        inkHex = selectedLook.inkHex,
                        accentHex = selectedLook.accentHex,
                        hlHex = selectedLook.hlHex,
                        isDualTheme = selectedLook.isDualTheme
                    )
                }
            }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFF38BDF8).copy(alpha = 0.45f), RoundedCornerShape(16.dp)),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF131B2E))
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "🎬 লাইভ প্রিভিউ: ${selectedLook.name}",
                            color = Color(0xFFF59E0B),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${selectedRatio} • 30 FPS",
                            color = Color(0xFF38BDF8),
                            fontSize = 12.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(16f / 9f)
                            .clip(RoundedCornerShape(12.dp))
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            drawIntoCanvas { canvas ->
                                CanvasVideoEngine.renderFrame(
                                    canvas = canvas.nativeCanvas,
                                    width = size.width,
                                    height = size.height,
                                    project = previewProject,
                                    globalTimeSec = previewTimeSec,
                                    customImages = customBitmaps
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            when (wizardType) {
                WizardType.REMOTION_ZIP_TO_MP4 -> {
                    RemotionZipWizardSection(
                        viewModel = viewModel,
                        aiState = aiState
                    )
                }

                WizardType.INSTANT_PASTE -> {
                    InstantPasteSection(
                        pastedJsonText = pastedJsonText,
                        onTextChange = { pastedJsonText = it },
                        onPasteClipboard = {
                            pastedJsonText = GeminiPromptAndAiService.readFromClipboard(context)
                        },
                        onBuildVideo = {
                            viewModel.importPastedJson(pastedJsonText)
                        }
                    )
                }

                WizardType.THUMBNAIL_MAKER -> {
                    ThumbnailMakerSection(
                        viewModel = viewModel,
                        previewProject = previewProject,
                        previewTimeSec = previewTimeSec,
                        onTimeChange = { previewTimeSec = it },
                        onSavePng = {
                            scope.launch {
                                val file = Mp4VideoExporter.exportHighResThumbnailPng(
                                    context = context,
                                    project = previewProject,
                                    timeSec = previewTimeSec
                                )
                                Mp4VideoExporter.saveToDeviceDownloads(context, file, "image/png")
                                viewModel.showToast("🖼️ 1080p PNG Thumbnail ডাউনলোড ফোল্ডারে সেভ হয়েছে!")
                            }
                        }
                    )
                }

                WizardType.VOICE_SRT_TO_MOTION -> {
                    VoiceSrtWizardContent(
                        voiceModeFullMotion = voiceModeFullMotion,
                        onToggleVoiceMode = { voiceModeFullMotion = it },
                        srtInputText = srtInputText,
                        onSrtChange = { srtInputText = it },
                        parsedCueCount = parsedCues.size,
                        selectedRatio = selectedRatio,
                        onSelectRatio = { selectedRatio = it },
                        selectedLook = selectedLook,
                        onSelectLook = { selectedLook = it },
                        selectedSubStyle = selectedSubStyle,
                        onSelectSubStyle = { selectedSubStyle = it },
                        aiState = aiState,
                        onGenerateSrtViaGemini = {
                            viewModel.generateSrtWithGeminiAi(topicInput) { generatedSrt ->
                                srtInputText = generatedSrt
                            }
                        },
                        onCopySrtCommand = {
                            val cmd = GeminiPromptAndAiService.buildSrtTranscriptionPrompt()
                            GeminiPromptAndAiService.copyToClipboard(context, "SRT Prompt", cmd)
                            viewModel.showToast("📋 SRT প্রম্পট কপি হয়েছে! Gemini-তে অডিওসহ দিন।")
                        },
                        onAutoBuildWithGemini = {
                            viewModel.generateVideoWithGeminiAi(
                                topicOrScript = topicInput,
                                aspectRatio = selectedRatio,
                                lookId = selectedLook.id,
                                languageMode = selectedLang,
                                durationPreset = selectedDuration,
                                srtRaw = srtInputText
                            )
                        },
                        onCopyPromptAndOpenGemini = {
                            val prompt = GeminiPromptAndAiService.buildCopyPasteGeminiPrompt(
                                topicOrScript = topicInput,
                                aspectRatio = selectedRatio,
                                lookId = selectedLook.id,
                                languageMode = selectedLang,
                                durationPreset = selectedDuration,
                                srtRaw = srtInputText
                            )
                            GeminiPromptAndAiService.copyToClipboard(context, "ProMotion Prompt", prompt)
                            viewModel.showToast("📋 প্রম্পট কপি হয়েছে! Gemini-এর উত্তর নিচে Paste করুন।")
                            GeminiPromptAndAiService.openExternalGeminiApp(context)
                        },
                        pastedJsonText = pastedJsonText,
                        onPastedJsonChange = { pastedJsonText = it },
                        onBuildFromPastedJson = {
                            viewModel.importPastedJson(pastedJsonText)
                        }
                    )
                }

                else -> {
                    // SCRIPT_TO_MOTION and SCIENCE_EXPLAINER
                    // Step 1: Aspect Ratio
                    SectionHeader("১. মাপ (Aspect Ratio)")
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val ratios = listOf(
                            "9:16" to "Reels · Story",
                            "1:1" to "Post",
                            "4:5" to "Feed",
                            "16:9" to "YouTube HD"
                        )
                        ratios.forEach { (r, sub) ->
                            val selected = selectedRatio == r
                            Card(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { selectedRatio = r }
                                    .border(
                                        width = if (selected) 2.dp else 1.dp,
                                        color = if (selected) Color(0xFFF59E0B) else Color(0xFF334155),
                                        shape = RoundedCornerShape(12.dp)
                                    ),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (selected) Color(0xFF1E293B) else Color(0xFF131B2E)
                                )
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 10.dp, horizontal = 4.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        text = r,
                                        color = if (selected) Color(0xFFF59E0B) else Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                    Text(
                                        text = sub,
                                        color = Color(0xFF94A3B8),
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Step 2: Look Selection
                    SectionHeader("২. Look — ভিডিওর ধাঁচ (16+ Live-Preview Looks)")
                    val categories = listOf("সব", "⭐ নতুন", "🔬 সায়েন্স ও বই", "3D ও HUD", "গল্প", "Product", "Brand")
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        categories.forEach { cat ->
                            FilterChip(
                                selected = selectedLookCategory == cat,
                                onClick = { selectedLookCategory = cat },
                                label = { Text(cat, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color(0xFFF59E0B),
                                    selectedLabelColor = Color(0xFF0B0F19)
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    val filteredLooks = remember(selectedLookCategory) {
                        if (selectedLookCategory == "সব") BUILTIN_LOOKS
                        else BUILTIN_LOOKS.filter { it.category == selectedLookCategory }
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        filteredLooks.forEach { look ->
                            val isSel = selectedLook.id == look.id
                            Card(
                                modifier = Modifier
                                    .width(175.dp)
                                    .clickable { selectedLook = look }
                                    .border(
                                        width = if (isSel) 2.dp else 1.dp,
                                        color = if (isSel) Color(0xFFF59E0B) else Color(0xFF334155),
                                        shape = RoundedCornerShape(14.dp)
                                    ),
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF131B2E))
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(16.dp)
                                                .clip(CircleShape)
                                                .background( Color(CanvasVideoEngine.parseColorSafe(look.bgHex)))
                                                .border(1.dp, Color.White, CircleShape)
                                        )
                                        Box(
                                            modifier = Modifier
                                                .size(16.dp)
                                                .clip(CircleShape)
                                                .background(Color(CanvasVideoEngine.parseColorSafe(look.accentHex)))
                                        )
                                        Box(
                                            modifier = Modifier
                                                .size(16.dp)
                                                .clip(CircleShape)
                                                .background(Color(CanvasVideoEngine.parseColorSafe(look.hlHex)))
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = look.name,
                                        color = if (isSel) Color(0xFFF59E0B) else Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        maxLines = 1
                                    )
                                    Text(
                                        text = look.subtitleBn,
                                        color = Color(0xFF94A3B8),
                                        fontSize = 11.sp,
                                        maxLines = 2
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Step 3: Language
                    SectionHeader("৩. ভাষা (Language)")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("বাংলা + English", "শুদ্ধ বাংলা", "English").forEach { lang ->
                            FilterChip(
                                selected = selectedLang == lang,
                                onClick = { selectedLang = lang },
                                label = { Text(lang) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color(0xFF38BDF8),
                                    selectedLabelColor = Color(0xFF0B0F19)
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Step 4: Topic / Script & Duration
                    SectionHeader("৪. কী নিয়ে ভিডিও ও দৈর্ঘ্য")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = !isScriptMode,
                            onClick = { isScriptMode = false },
                            label = { Text("বিষয় / প্রম্পট লিখছি") }
                        )
                        FilterChip(
                            selected = isScriptMode,
                            onClick = { isScriptMode = true },
                            label = { Text("আমার পুরো Script আছে") }
                        )
                    }

                    OutlinedTextField(
                        value = topicInput,
                        onValueChange = { topicInput = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp)
                            .testTag("wizard_topic_input"),
                        label = {
                            Text(
                                if (isScriptMode) "আপনার পুরো ভিডিও স্ক্রিপ্ট এখানে লিখুন..."
                                else "ভিডিওর বিষয় বা অধ্যায়ের নাম লিখুন..."
                            )
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFFF59E0B),
                            unfocusedBorderColor = Color(0xFF334155),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        listOf("Auto", "15s", "30s", "60s", "3m", "5m+").forEach { dur ->
                            FilterChip(
                                selected = selectedDuration == dur,
                                onClick = { selectedDuration = dur },
                                label = { Text(dur) }
                            )
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Checkbox(
                            checked = zeroOverlapChecked,
                            onCheckedChange = { zeroOverlapChecked = it },
                            colors = CheckboxDefaults.colors(checkedColor = Color(0xFF10B981))
                        )
                        Text(
                            text = "আগে Scene Plan ও বিস্তারিত ডায়াগ্রাম — প্রতি সিনে সর্বোচ্চ ৩–৪টি লেবেল ও জিরো ওভারল্যাপ",
                            color = Color(0xFFE2E8F0),
                            fontSize = 13.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Step 5: Generate or Copy-Paste
                    SectionHeader("৫. ভিডিও তৈরি করুন (Dual Gemini Workflow)")

                    if (aiState is AiGenState.Loading) {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(24.dp),
                                    color = Color(0xFFF59E0B),
                                    strokeWidth = 2.5.dp
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = aiState.statusText,
                                    color = Color.White,
                                    fontSize = 14.sp
                                )
                            }
                        }
                    } else if (aiState is AiGenState.Error) {
                        Text(
                            text = "⚠️ ${aiState.message}",
                            color = Color(0xFFF87171),
                            fontSize = 13.sp,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                    }

                    // Button A: Direct In-App Gemini Generation (Firebase AI Logic)
                    Button(
                        onClick = {
                            viewModel.generateVideoWithGeminiAi(
                                topicOrScript = topicInput,
                                aspectRatio = selectedRatio,
                                lookId = selectedLook.id,
                                languageMode = selectedLang,
                                durationPreset = selectedDuration
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("auto_gemini_generate_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFF59E0B),
                            contentColor = Color(0xFF0B0F19)
                        )
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "✨ অ্যাপেই সরাসরি ভিডিও বানান (Auto Gemini)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Button B: 100% Free Copy-Paste Mode
                    OutlinedButton(
                        onClick = {
                            val prompt = GeminiPromptAndAiService.buildCopyPasteGeminiPrompt(
                                topicOrScript = topicInput,
                                aspectRatio = selectedRatio,
                                lookId = selectedLook.id,
                                languageMode = selectedLang,
                                durationPreset = selectedDuration
                            )
                            GeminiPromptAndAiService.copyToClipboard(context, "ProMotion Prompt", prompt)
                            viewModel.showToast("📋 প্রম্পট কপি হয়েছে! Gemini-তে Paste করে JSON আনুন।")
                            GeminiPromptAndAiService.openExternalGeminiApp(context)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("copy_prompt_open_gemini_button"),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, tint = Color(0xFF38BDF8))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "📋 Copy করে Gemini খুলুন ➔ (ফ্রি কপি-পেস্ট মোড)",
                            color = Color(0xFF38BDF8),
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Step 6: Paste JSON Box
                    InstantPasteSection(
                        pastedJsonText = pastedJsonText,
                        onTextChange = { pastedJsonText = it },
                        onPasteClipboard = {
                            pastedJsonText = GeminiPromptAndAiService.readFromClipboard(context)
                        },
                        onBuildVideo = {
                            viewModel.importPastedJson(pastedJsonText)
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
private fun SectionHeader(title: String) {
    Text(
        text = title,
        color = Color(0xFFF59E0B),
        fontWeight = FontWeight.Bold,
        fontSize = 15.sp,
        modifier = Modifier.padding(bottom = 8.dp)
    )
}

@Composable
private fun InstantPasteSection(
    pastedJsonText: String,
    onTextChange: (String) -> Unit,
    onPasteClipboard: () -> Unit,
    onBuildVideo: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF131B2E))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "৬. Gemini-এর JSON উত্তর এখানে Paste করুন",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                OutlinedButton(
                    onClick = onPasteClipboard,
                    modifier = Modifier.testTag("paste_clipboard_json_button")
                ) {
                    Icon(Icons.Default.ContentPaste, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Paste", fontSize = 12.sp)
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = pastedJsonText,
                onValueChange = onTextChange,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp)
                    .testTag("json_paste_textfield"),
                placeholder = { Text("{ \"specVersion\": \"ProMotion JSON Spec v5\", ... }") },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF38BDF8),
                    unfocusedBorderColor = Color(0xFF334155),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )
            )
            Spacer(modifier = Modifier.height(10.dp))
            Button(
                onClick = onBuildVideo,
                enabled = pastedJsonText.isNotBlank(),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("build_from_json_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF10B981),
                    contentColor = Color(0xFF0B0F19)
                )
            ) {
                Text("⚡ JSON অটো-ফিক্স ও ভিডিও চালু করুন", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun VoiceSrtWizardContent(
    voiceModeFullMotion: Boolean,
    onToggleVoiceMode: (Boolean) -> Unit,
    srtInputText: String,
    onSrtChange: (String) -> Unit,
    parsedCueCount: Int,
    selectedRatio: String,
    onSelectRatio: (String) -> Unit,
    selectedLook: com.example.model.LookPreset,
    onSelectLook: (com.example.model.LookPreset) -> Unit,
    selectedSubStyle: SubtitleStyle,
    onSelectSubStyle: (SubtitleStyle) -> Unit,
    aiState: AiGenState,
    onGenerateSrtViaGemini: () -> Unit,
    onCopySrtCommand: () -> Unit,
    onAutoBuildWithGemini: () -> Unit,
    onCopyPromptAndOpenGemini: () -> Unit,
    pastedJsonText: String,
    onPastedJsonChange: (String) -> Unit,
    onBuildFromPastedJson: () -> Unit
) {
    SectionHeader("১. Voice ফাইল (.mp3/.wav) ও ওয়েভফর্ম প্রিভিউ")
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF131B2E))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Mic, contentDescription = null, tint = Color(0xFFF59E0B))
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text("Voiceover_Track_BD.mp3", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("00:29 • স্টেরিও ভয়েসওভার রেডি", color = Color(0xFF10B981), fontSize = 12.sp)
                }
            }
            Icon(Icons.Default.GraphicEq, contentDescription = null, tint = Color(0xFF38BDF8))
        }
    }

    Spacer(modifier = Modifier.height(14.dp))

    SectionHeader("২. কী বানাবেন")
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FilterChip(
            selected = voiceModeFullMotion,
            onClick = { onToggleVoiceMode(true) },
            label = { Text("পুরো Motion ভিডিও") }
        )
        FilterChip(
            selected = !voiceModeFullMotion,
            onClick = { onToggleVoiceMode(false) },
            label = { Text("ভিডিও + চারপাশে Motion") }
        )
    }

    Spacer(modifier = Modifier.height(14.dp))

    SectionHeader("৩. কথার লেখা (সময়সহ SRT)")
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Button(
            onClick = onGenerateSrtViaGemini,
            modifier = Modifier.weight(1f),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF38BDF8), contentColor = Color(0xFF0B0F19))
        ) {
            Text("✨ Gemini দিয়ে ফ্রি SRT বানান", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        OutlinedButton(
            onClick = onCopySrtCommand,
            modifier = Modifier.weight(1f)
        ) {
            Text("📋 SRT প্রম্পট কপি", fontSize = 12.sp)
        }
    }

    Spacer(modifier = Modifier.height(8.dp))

    OutlinedTextField(
        value = srtInputText,
        onValueChange = onSrtChange,
        modifier = Modifier
            .fillMaxWidth()
            .height(135.dp)
            .testTag("srt_input_textfield"),
        label = { Text("সময়সহ .srt সাবটাইটেল টেক্সট") },
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Color(0xFF10B981),
            unfocusedBorderColor = Color(0xFF334155),
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White
        )
    )

    if (parsedCueCount > 0) {
        Spacer(modifier = Modifier.height(6.dp))
        Surface(
            color = Color(0xFF10B981).copy(alpha = 0.16f),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "✓ এই লাইন = SRT-এর লেখা, সময়সহ যাচাই করা হয়েছে (মোট $parsedCueCount টি কিউ)",
                    color = Color(0xFF10B981),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }

    Spacer(modifier = Modifier.height(14.dp))

    SectionHeader("৪. মাপ, Look ও Subtitle স্টাইল বাছুন")
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        SubtitleStyle.entries.take(4).forEach { st ->
            FilterChip(
                selected = selectedSubStyle == st,
                onClick = { onSelectSubStyle(st) },
                label = { Text(st.label) }
            )
        }
    }

    Spacer(modifier = Modifier.height(14.dp))

    SectionHeader("৫. ভয়েস-সিঙ্কড ভিডিও তৈরি করুন")
    if (aiState is AiGenState.Loading) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 8.dp)) {
            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color(0xFFF59E0B))
            Spacer(modifier = Modifier.width(10.dp))
            Text(aiState.statusText, color = Color.White, fontSize = 13.sp)
        }
    }
    Button(
        onClick = onAutoBuildWithGemini,
        modifier = Modifier
            .fillMaxWidth()
            .height(52.dp),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B), contentColor = Color(0xFF0B0F19))
    ) {
        Text("✨ সরাসরি তৈরি করুন (100% Voice-Synced)", fontWeight = FontWeight.Bold)
    }

    Spacer(modifier = Modifier.height(8.dp))

    OutlinedButton(
        onClick = onCopyPromptAndOpenGemini,
        modifier = Modifier
            .fillMaxWidth()
            .height(48.dp),
        shape = RoundedCornerShape(14.dp)
    ) {
        Text("📋 Copy করে Gemini খুলুন", color = Color(0xFF38BDF8))
    }

    Spacer(modifier = Modifier.height(14.dp))

    InstantPasteSection(
        pastedJsonText = pastedJsonText,
        onTextChange = onPastedJsonChange,
        onPasteClipboard = {},
        onBuildVideo = onBuildFromPastedJson
    )
}

@Composable
private fun ThumbnailMakerSection(
    viewModel: ProMotionViewModel,
    previewProject: com.example.model.ProMotionProject,
    previewTimeSec: Float,
    onTimeChange: (Float) -> Unit,
    onSavePng: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF131B2E))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "🖼️ YouTube 16:9 High-Res PNG Thumbnail",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "যেকোনো দৃশ্য বেছে 1920×1080 পিক্সেল স্বচ্ছ ও ঝকঝকে PNG ছবি ডাউনলোড করুন।",
                color = Color(0xFF94A3B8),
                fontSize = 13.sp
            )
            Spacer(modifier = Modifier.height(14.dp))
            Button(
                onClick = onSavePng,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("download_thumbnail_png_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B), contentColor = Color(0xFF0B0F19))
            ) {
                Icon(Icons.Default.Image, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("📥 16:9 HD Thumbnail নামান (.PNG)", fontWeight = FontWeight.Bold)
            }
        }
    }
}
