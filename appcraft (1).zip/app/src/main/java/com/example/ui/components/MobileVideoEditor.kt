package com.example.ui.components

import android.graphics.BitmapFactory
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.CanvasVideoEngine
import com.example.model.BUILTIN_LOOKS
import com.example.model.ProMotionJsonCodec
import com.example.model.SceneTemplate
import com.example.model.SubtitleStyle
import com.example.model.WaveformVariant
import com.example.utils.GeminiPromptAndAiService
import com.example.viewmodel.ProMotionViewModel
import kotlinx.coroutines.delay

data class EditorToolSpec(val index: Int, val icon: String, val label: String)

val EDITOR_TOOLS = listOf(
    EditorToolSpec(0, "⏱️", "টাইমলাইন"),
    EditorToolSpec(1, "Aa", "লেখা"),
    EditorToolSpec(2, "🎨", "রং"),
    EditorToolSpec(3, "📑", "লেয়ার"),
    EditorToolSpec(4, "🖼️", "ব্যাকগ্রাউন্ড"),
    EditorToolSpec(5, "✨", "থিম"),
    EditorToolSpec(6, "📷", "ছবি ও লোগো"),
    EditorToolSpec(7, "🎵", "মিউজিক ও ভয়েস"),
    EditorToolSpec(8, "💬", "Subtitle"),
    EditorToolSpec(9, "📊", "ডায়াগ্রাম ও Chart"),
    EditorToolSpec(10, "😊", "Sticker ও Badge"),
    EditorToolSpec(11, "📞", "যোগাযোগ"),
    EditorToolSpec(12, "🌐", "Translate"),
    EditorToolSpec(13, "{ }", "JSON কোড")
)

private val CURATED_SWATCHES = listOf(
    "#07222E", "#091326", "#0F172A", "#12100E", "#062825", "#140826",
    "#F3F7F8", "#FAF6F0", "#FFFFFF", "#10374A", "#1E293B", "#112240",
    "#38BDF8", "#00F5D4", "#60A5FA", "#F59E0B", "#FFD166", "#FB7185",
    "#10B981", "#34D399", "#EF4444", "#F472B6", "#C084FC", "#F8FAFC"
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MobileVideoEditor(
    viewModel: ProMotionViewModel,
    onCloseEditor: () -> Unit,
    onOpenExport: () -> Unit
) {
    BackHandler { onCloseEditor() }

    val context = LocalContext.current
    val project by viewModel.activeProject.collectAsState()
    val selectedSceneIdx by viewModel.selectedSceneIndex.collectAsState()
    val isPlaying by viewModel.isPlaying.collectAsState()
    val currentTimeSec by viewModel.currentTimeSec.collectAsState()
    val activeToolIdx by viewModel.activeEditorToolIndex.collectAsState()
    val undoStack by viewModel.undoStack.collectAsState()
    val redoStack by viewModel.redoStack.collectAsState()
    val customBitmaps by viewModel.customBitmaps.collectAsState()

    var pendingImageSlotKey by remember { mutableStateOf("img1") }

    // Zero-permission Android Photo Picker (compliant with Google Play policy)
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    val bmp = BitmapFactory.decodeStream(stream)
                    if (bmp != null) {
                        viewModel.setCustomBitmapForSlot(pendingImageSlotKey, bmp)
                    }
                }
            } catch (_: Exception) {}
        }
    }

    // 30 FPS Playback Loop
    LaunchedEffect(isPlaying, project.totalDurationSec) {
        while (isPlaying) {
            delay(33L)
            val nextT = currentTimeSec + 0.033f
            if (nextT >= project.totalDurationSec) {
                viewModel.seekTo(0f)
            } else {
                viewModel.seekTo(nextT)
            }
        }
    }

    val activeScene = project.scenes.getOrNull(selectedSceneIdx) ?: project.scenes.firstOrNull()

    Surface(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing),
        color = Color(0xFF0B0F19)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // 1. Top Editor Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF131B2E))
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    IconButton(
                        onClick = onCloseEditor,
                        modifier = Modifier.testTag("editor_back_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                    Text(
                        text = project.title,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        maxLines = 1
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { viewModel.undo() },
                        enabled = undoStack.isNotEmpty(),
                        modifier = Modifier.testTag("editor_undo_button")
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.Undo,
                            contentDescription = "Undo",
                            tint = if (undoStack.isNotEmpty()) Color.White else Color(0xFF475569)
                        )
                    }
                    IconButton(
                        onClick = { viewModel.redo() },
                        enabled = redoStack.isNotEmpty(),
                        modifier = Modifier.testTag("editor_redo_button")
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.Redo,
                            contentDescription = "Redo",
                            tint = if (redoStack.isNotEmpty()) Color.White else Color(0xFF475569)
                        )
                    }
                    Button(
                        onClick = onOpenExport,
                        modifier = Modifier
                            .height(38.dp)
                            .testTag("editor_export_button"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFF59E0B),
                            contentColor = Color(0xFF0B0F19)
                        )
                    ) {
                        Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Export", fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
                    }
                }
            }

            // 2. Center Live 30 FPS Canvas Preview Player
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp)
                    .aspectRatio(16f / 9f)
                    .clip(RoundedCornerShape(14.dp))
                    .border(1.5.dp, Color(0xFF334155), RoundedCornerShape(14.dp))
                    .testTag("editor_live_canvas")
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawIntoCanvas { canvas ->
                        CanvasVideoEngine.renderFrame(
                            canvas = canvas.nativeCanvas,
                            width = size.width,
                            height = size.height,
                            project = project,
                            globalTimeSec = currentTimeSec,
                            customImages = customBitmaps
                        )
                    }
                }
            }

            // Playback Scrubber & Controls
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.setPlaying(!isPlaying) },
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFF59E0B))
                        .testTag("editor_play_pause_button")
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (isPlaying) "Pause" else "Play",
                        tint = Color(0xFF0B0F19)
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "${formatShortTime(currentTimeSec)} / ${formatShortTime(project.totalDurationSec)}",
                    color = Color(0xFF38BDF8),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(8.dp))
                Slider(
                    value = currentTimeSec,
                    onValueChange = {
                        viewModel.setPlaying(false)
                        viewModel.seekTo(it)
                    },
                    valueRange = 0f..project.totalDurationSec.coerceAtLeast(1f),
                    modifier = Modifier.weight(1f),
                    colors = SliderDefaults.colors(
                        thumbColor = Color(0xFFF59E0B),
                        activeTrackColor = Color(0xFFF59E0B)
                    )
                )
            }

            // Horizontal Scene Pill Strip
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                project.scenes.forEachIndexed { idx, s ->
                    val isSel = idx == selectedSceneIdx
                    Surface(
                        color = if (isSel) Color(0xFFF59E0B) else Color(0xFF1E293B),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .clickable { viewModel.jumpToScene(idx) }
                            .testTag("scene_pill_$idx")
                    ) {
                        Text(
                            text = "${idx + 1}. ${s.template.id.take(10)} (${"%.1f".format(s.durationSec)}s)",
                            color = if (isSel) Color(0xFF0B0F19) else Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            // 3. Active Tool Control Panel
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF131B2E))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(14.dp)
                ) {
                    val toolSpec = EDITOR_TOOLS.getOrNull(activeToolIdx) ?: EDITOR_TOOLS[0]
                    Text(
                        text = "${toolSpec.icon} ${toolSpec.label}",
                        color = Color(0xFFF59E0B),
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    if (activeScene != null) {
                        when (activeToolIdx) {
                            0 -> {
                                // Tool 1: Timeline
                                Text(
                                    text = "সিন #${selectedSceneIdx + 1} দৈর্ঘ্য: ${"%.1f".format(activeScene.durationSec)} সেকেন্ড",
                                    color = Color.White,
                                    fontSize = 14.sp
                                )
                                Slider(
                                    value = activeScene.durationSec,
                                    onValueChange = { newDur ->
                                        viewModel.updateActiveScene { it.copy(durationSec = newDur) }
                                    },
                                    valueRange = 1.5f..30f,
                                    colors = SliderDefaults.colors(thumbColor = Color(0xFFF59E0B), activeTrackColor = Color(0xFFF59E0B))
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Button(
                                        onClick = { viewModel.addNewScene() },
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("add_scene_button"),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981), contentColor = Color(0xFF0B0F19))
                                    ) {
                                        Icon(Icons.Default.Add, contentDescription = null)
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("+ নতুন সিন যোগ করুন", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    }
                                    OutlinedButton(
                                        onClick = { viewModel.deleteActiveScene() },
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("delete_scene_button")
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = null, tint = Color(0xFFF87171))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("🗑️ সিন মুছুন", color = Color(0xFFF87171), fontSize = 12.sp)
                                    }
                                }
                            }

                            1 -> {
                                // Tool 2: Text & Fonts
                                Surface(
                                    color = Color(0xFFF59E0B).copy(alpha = 0.15f),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = "💡 টিপস: যেকোনো শব্দের দুই পাশে [ ] দিলে সেটি আলাদা হাইলাইট রঙে আসবে!",
                                        color = Color(0xFFF59E0B),
                                        fontSize = 12.sp,
                                        modifier = Modifier.padding(10.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                OutlinedTextField(
                                    value = activeScene.heading,
                                    onValueChange = { v -> viewModel.updateActiveScene { it.copy(heading = v) } },
                                    label = { Text("Heading (মূল শিরোনাম)") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                OutlinedTextField(
                                    value = activeScene.subtext,
                                    onValueChange = { v -> viewModel.updateActiveScene { it.copy(subtext = v) } },
                                    label = { Text("Subtext / Subtitle (নিচের লেখা)") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                OutlinedTextField(
                                    value = activeScene.chapterBadge,
                                    onValueChange = { v -> viewModel.updateActiveScene { it.copy(chapterBadge = v) } },
                                    label = { Text("Chapter Badge (অধ্যায় ব্যাজ)") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Text("ফন্ট নির্বাচন:", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                val fonts = listOf("Hind Siliguri", "Anek Bangla", "Baloo Da 2", "Noto Serif Bengali", "Tiro Bangla")
                                Row(
                                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    fonts.forEach { fn ->
                                        FilterChip(
                                            selected = project.fontName == fn,
                                            onClick = { viewModel.commitProjectEdit(project.copy(fontName = fn)) },
                                            label = { Text(fn, fontSize = 12.sp) }
                                        )
                                    }
                                }
                                Text("টেক্সট সাইজ স্কেল: ${project.textScalePercent}%", color = Color.White, fontSize = 13.sp)
                                Slider(
                                    value = project.textScalePercent.toFloat(),
                                    onValueChange = { v -> viewModel.commitProjectEdit(project.copy(textScalePercent = v.toInt()), syncToCloud = false) },
                                    valueRange = 70f..150f
                                )
                            }

                            2 -> {
                                // Tool 3: Colors
                                var selectedColorRole by remember { mutableStateOf("bgHex") }
                                val roles = listOf(
                                    "bgHex" to "Background (${project.bgHex})",
                                    "cardHex" to "Card (${project.cardHex})",
                                    "inkHex" to "Text Ink (${project.inkHex})",
                                    "accentHex" to "Primary Accent (${project.accentHex})",
                                    "hlHex" to "Highlight (${project.hlHex})",
                                    "successHex" to "Success (${project.successHex})",
                                    "dangerHex" to "Danger (${project.dangerHex})"
                                )
                                Row(
                                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    roles.forEach { (key, label) ->
                                        FilterChip(
                                            selected = selectedColorRole == key,
                                            onClick = { selectedColorRole = key },
                                            label = { Text(label, fontSize = 12.sp) }
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                Text("২৪টি কিউরেটেড স্টুডিও সোয়াচ (১ ট্যাপে পুরো ভিডিওতে আপডেট):", color = Color(0xFF94A3B8), fontSize = 12.sp)
                                Spacer(modifier = Modifier.height(8.dp))
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    CURATED_SWATCHES.forEach { hex ->
                                        Box(
                                            modifier = Modifier
                                                .size(36.dp)
                                                .clip(CircleShape)
                                                .background(Color(CanvasVideoEngine.parseColorSafe(hex)))
                                                .border(1.5.dp, Color.White, CircleShape)
                                                .clickable {
                                                    val updated = when (selectedColorRole) {
                                                        "bgHex" -> project.copy(bgHex = hex, isDualTheme = false)
                                                        "cardHex" -> project.copy(cardHex = hex)
                                                        "inkHex" -> project.copy(inkHex = hex)
                                                        "accentHex" -> project.copy(accentHex = hex)
                                                        "hlHex" -> project.copy(hlHex = hex)
                                                        "successHex" -> project.copy(successHex = hex)
                                                        else -> project.copy(dangerHex = hex)
                                                    }
                                                    viewModel.commitProjectEdit(updated)
                                                }
                                        )
                                    }
                                }
                            }

                            3 -> {
                                // Tool 4: Layers
                                activeScene.layers.forEachIndexed { lIdx, layer ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(Color(0xFF1E293B))
                                            .padding(horizontal = 10.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(layer.nameBn, color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f))
                                        Row {
                                            IconButton(
                                                onClick = {
                                                    viewModel.updateActiveScene { sc ->
                                                        val list = sc.layers.toMutableList()
                                                        list[lIdx] = layer.copy(visible = !layer.visible)
                                                        sc.copy(layers = list)
                                                    }
                                                }
                                            ) {
                                                Icon(
                                                    imageVector = if (layer.visible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                                    contentDescription = "Toggle Visibility",
                                                    tint = if (layer.visible) Color(0xFF10B981) else Color(0xFF64748B)
                                                )
                                            }
                                            IconButton(
                                                onClick = {
                                                    viewModel.updateActiveScene { sc ->
                                                        val list = sc.layers.toMutableList()
                                                        list[lIdx] = layer.copy(locked = !layer.locked)
                                                        sc.copy(layers = list)
                                                    }
                                                }
                                            ) {
                                                Icon(
                                                    imageVector = if (layer.locked) Icons.Default.Lock else Icons.Default.LockOpen,
                                                    contentDescription = "Lock Layer",
                                                    tint = if (layer.locked) Color(0xFFF59E0B) else Color(0xFF94A3B8)
                                                )
                                            }
                                            IconButton(
                                                onClick = {
                                                    if (lIdx > 0) {
                                                        viewModel.updateActiveScene { sc ->
                                                            val list = sc.layers.toMutableList()
                                                            val tmp = list[lIdx - 1]
                                                            list[lIdx - 1] = list[lIdx]
                                                            list[lIdx] = tmp
                                                            sc.copy(layers = list)
                                                        }
                                                    }
                                                }
                                            ) {
                                                Icon(Icons.Default.ArrowUpward, contentDescription = "Move Up", tint = Color.White)
                                            }
                                            IconButton(
                                                onClick = {
                                                    if (lIdx < activeScene.layers.lastIndex) {
                                                        viewModel.updateActiveScene { sc ->
                                                            val list = sc.layers.toMutableList()
                                                            val tmp = list[lIdx + 1]
                                                            list[lIdx + 1] = list[lIdx]
                                                            list[lIdx] = tmp
                                                            sc.copy(layers = list)
                                                        }
                                                    }
                                                }
                                            ) {
                                                Icon(Icons.Default.ArrowDownward, contentDescription = "Move Down", tint = Color.White)
                                            }
                                        }
                                    }
                                }
                            }

                            4 -> {
                                // Tool 5: Background Presets
                                val bgPresets = listOf(
                                    "ocean_rays" to "Ocean Teal Rays",
                                    "light_grid" to "Light Graph Grid",
                                    "glass_blur" to "Glass Blur",
                                    "aurora" to "Aurora Glow",
                                    "cyber_grid" to "Dark Cyber Grid",
                                    "golden_sunburst" to "Golden Sunburst",
                                    "warm_gradient" to "Warm Gradient"
                                )
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    bgPresets.forEach { (id, label) ->
                                        FilterChip(
                                            selected = project.bgPattern == id,
                                            onClick = {
                                                viewModel.commitProjectEdit(project.copy(bgPattern = id, isDualTheme = (id == "light_grid")))
                                            },
                                            label = { Text(label) }
                                        )
                                    }
                                }
                            }

                            5 -> {
                                // Tool 6: Theme / 16+ Master Looks
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Dual-Theme (Ocean + Grid অদলবদল)", color = Color.White, fontSize = 13.sp)
                                    Switch(
                                        checked = project.isDualTheme,
                                        onCheckedChange = { viewModel.commitProjectEdit(project.copy(isDualTheme = it)) }
                                    )
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    BUILTIN_LOOKS.forEach { look ->
                                        FilterChip(
                                            selected = project.lookId == look.id,
                                            onClick = { viewModel.applyLookPresetToProject(look) },
                                            label = { Text(look.name, fontSize = 12.sp) }
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                Button(
                                    onClick = { viewModel.saveCurrentThemeToCloud("${project.title} Look") },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B), contentColor = Color(0xFF0B0F19))
                                ) {
                                    Text("⭐ এই থিমটি ক্লাউডে সেভ করুন", fontWeight = FontWeight.Bold)
                                }
                            }

                            6 -> {
                                // Tool 7: Images & Logo
                                val slots = listOf("logo", "img1", "img2", "img3", "img4")
                                Text("ফোনের গ্যালারি থেকে ছবি বা বইয়ের পাতা বাছুন:", color = Color(0xFF94A3B8), fontSize = 12.sp)
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    slots.forEach { slot ->
                                        val hasImg = customBitmaps.containsKey(slot)
                                        Button(
                                            onClick = {
                                                pendingImageSlotKey = slot
                                                photoPickerLauncher.launch(
                                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                                )
                                            },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = if (hasImg) Color(0xFF10B981) else Color(0xFF1E293B),
                                                contentColor = Color.White
                                            )
                                        ) {
                                            Text(if (hasImg) "✓ $slot" else "📷 $slot বাছুন", fontSize = 12.sp)
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text("শুরুতে Logo Intro এবং শেষে Logo Outro", color = Color.White, fontSize = 13.sp)
                                    Switch(
                                        checked = project.logoOutro,
                                        onCheckedChange = { viewModel.commitProjectEdit(project.copy(logoIntro = it, logoOutro = it)) }
                                    )
                                }
                            }

                            7 -> {
                                // Tool 8: Audio Mixer
                                Text("🎙️ Voiceover ভলিউম: ${project.voiceVolumePercent}%", color = Color.White, fontSize = 13.sp)
                                Slider(
                                    value = project.voiceVolumePercent.toFloat(),
                                    onValueChange = { viewModel.commitProjectEdit(project.copy(voiceVolumePercent = it.toInt()), syncToCloud = false) },
                                    valueRange = 0f..100f
                                )
                                Text("🎵 Background Music ভলিউম (ডিফল্ট ১৮%): ${project.bgmVolumePercent}%", color = Color.White, fontSize = 13.sp)
                                Slider(
                                    value = project.bgmVolumePercent.toFloat(),
                                    onValueChange = { viewModel.commitProjectEdit(project.copy(bgmVolumePercent = it.toInt()), syncToCloud = false) },
                                    valueRange = 0f..100f
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf("ambient_science" to "Ambient Science", "soft_pulse" to "Soft Pulse", "cinema_warm" to "Cinema Warm").forEach { (id, name) ->
                                        FilterChip(
                                            selected = project.bgmTrackId == id,
                                            onClick = { viewModel.commitProjectEdit(project.copy(bgmTrackId = id)) },
                                            label = { Text(name, fontSize = 12.sp) }
                                        )
                                    }
                                }
                            }

                            8 -> {
                                // Tool 9: Subtitle
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("সাবটাইটেল দেখাবে (On / Off)", color = Color.White, fontSize = 13.sp)
                                    Switch(
                                        checked = project.subtitleEnabled,
                                        onCheckedChange = { viewModel.commitProjectEdit(project.copy(subtitleEnabled = it)) }
                                    )
                                }
                                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    SubtitleStyle.entries.forEach { st ->
                                        FilterChip(
                                            selected = project.subtitleStyle == st,
                                            onClick = { viewModel.commitProjectEdit(project.copy(subtitleStyle = st)) },
                                            label = { Text(st.id, fontSize = 12.sp) }
                                        )
                                    }
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf("নিচে", "একটু উপরে", "মাঝে").forEach { pos ->
                                        FilterChip(
                                            selected = project.subtitlePosition == pos,
                                            onClick = { viewModel.commitProjectEdit(project.copy(subtitlePosition = pos)) },
                                            label = { Text(pos, fontSize = 12.sp) }
                                        )
                                    }
                                }
                                Text("সাবটাইটেল সাইজ: ${project.subtitleSizePercent}%", color = Color.White, fontSize = 13.sp)
                                Slider(
                                    value = project.subtitleSizePercent.toFloat(),
                                    onValueChange = { viewModel.commitProjectEdit(project.copy(subtitleSizePercent = it.toInt()), syncToCloud = false) },
                                    valueRange = 60f..150f
                                )
                            }

                            9 -> {
                                // Tool 10: Diagram & Chart
                                Text("সিনের ডায়াগ্রাম টেমপ্লেট (১২টি বিল্ট-ইন টেমপ্লেট):", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    SceneTemplate.entries.forEach { tmpl ->
                                        FilterChip(
                                            selected = activeScene.template == tmpl,
                                            onClick = { viewModel.updateActiveScene { it.copy(template = tmpl) } },
                                            label = { Text(tmpl.labelBn, fontSize = 11.sp) }
                                        )
                                    }
                                }
                                if (activeScene.template == SceneTemplate.WAVEFORM_LAB) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text("ওয়েভফর্ম ধরন:", color = Color(0xFF38BDF8), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        WaveformVariant.entries.forEach { wv ->
                                            FilterChip(
                                                selected = activeScene.waveformVariant == wv,
                                                onClick = { viewModel.updateActiveScene { it.copy(waveformVariant = wv) } },
                                                label = { Text(wv.label, fontSize = 11.sp) }
                                            )
                                        }
                                    }
                                }
                            }

                            10 -> {
                                // Tool 11: Sticker & Badge
                                Text("স্টিকার ও ব্যাজ নির্বাচন:", color = Color.White, fontSize = 13.sp)
                                val badges = listOf("NEW", "SALE", "-50%", "LIVE", "FREE", "HOT", "✓ সঠিক", "✕ ভুল")
                                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    badges.forEach { b ->
                                        FilterChip(
                                            selected = activeScene.stickerBadge == b,
                                            onClick = { viewModel.updateActiveScene { it.copy(stickerBadge = b) } },
                                            label = { Text(b, fontSize = 12.sp) }
                                        )
                                    }
                                }
                                val emojis = listOf("🚀", "⚡", "🔬", "🏆", "🎯", "💡", "🔋", "📈")
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    emojis.forEach { em ->
                                        FilterChip(
                                            selected = activeScene.stickerEmoji == em,
                                            onClick = { viewModel.updateActiveScene { it.copy(stickerEmoji = em) } },
                                            label = { Text(em, fontSize = 16.sp) }
                                        )
                                    }
                                }
                            }

                            11 -> {
                                // Tool 12: Contact & Outro Card
                                val cc = project.contactConfig
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text("শেষ সিনে যোগাযোগের কার্ড দেখাবে", color = Color.White, fontSize = 13.sp)
                                    Switch(
                                        checked = cc.enabled,
                                        onCheckedChange = { viewModel.commitProjectEdit(project.copy(contactConfig = cc.copy(enabled = it))) }
                                    )
                                }
                                OutlinedTextField(
                                    value = cc.brandName,
                                    onValueChange = { viewModel.commitProjectEdit(project.copy(contactConfig = cc.copy(brandName = it)), syncToCloud = false) },
                                    label = { Text("ব্র্যান্ডের নাম") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                OutlinedTextField(
                                    value = cc.phone,
                                    onValueChange = { viewModel.commitProjectEdit(project.copy(contactConfig = cc.copy(phone = it)), syncToCloud = false) },
                                    label = { Text("ফোন / WhatsApp নম্বর") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                OutlinedTextField(
                                    value = cc.website,
                                    onValueChange = { viewModel.commitProjectEdit(project.copy(contactConfig = cc.copy(website = it)), syncToCloud = false) },
                                    label = { Text("ওয়েবসাইট") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }

                            12 -> {
                                // Tool 13: Translate
                                Text("১-ট্যাপে পুরো ভিডিও অনুবাদ করুন (Gemini AI):", color = Color.White, fontSize = 13.sp)
                                Spacer(modifier = Modifier.height(8.dp))
                                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf("English", "বাংলা", "हिन्दी", "العربية", "Español").forEach { lang ->
                                        Button(
                                            onClick = { viewModel.translateActiveProjectWithGeminiAi(lang) },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF38BDF8), contentColor = Color(0xFF0B0F19))
                                        ) {
                                            Text("🌐 $lang", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        }
                                    }
                                }
                            }

                            13 -> {
                                // Tool 14: Raw JSON Code
                                var rawJsonEdit by remember(project) {
                                    mutableStateOf(ProMotionJsonCodec.toJsonString(project, pretty = true))
                                }
                                OutlinedTextField(
                                    value = rawJsonEdit,
                                    onValueChange = { rawJsonEdit = it },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(140.dp),
                                    label = { Text("ProMotionProjectJSON v5") }
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(
                                        onClick = { viewModel.importPastedJson(rawJsonEdit) },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981), contentColor = Color(0xFF0B0F19))
                                    ) {
                                        Text("🔧 JSON অটো-ফিক্স ও আপডেট করুন", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    }
                                    OutlinedButton(
                                        onClick = {
                                            GeminiPromptAndAiService.copyToClipboard(context, "ProMotion JSON", rawJsonEdit)
                                            viewModel.showToast("📋 JSON কপি হয়েছে!")
                                        }
                                    ) {
                                        Text("📋 Copy JSON", fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 4. Bottom Scrollable 14-Tool Editor Dock
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF131B2E))
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                EDITOR_TOOLS.forEach { tool ->
                    val selected = activeToolIdx == tool.index
                    Surface(
                        color = if (selected) Color(0xFFF59E0B) else Color(0xFF1E293B),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .clickable { viewModel.selectEditorTool(tool.index) }
                            .testTag("editor_tool_${tool.index}")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(tool.icon, fontSize = 14.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = tool.label,
                                color = if (selected) Color(0xFF0B0F19) else Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun formatShortTime(sec: Float): String {
    val total = sec.toInt().coerceAtLeast(0)
    val m = total / 60
    val s = total % 60
    return "%d:%02d".format(m, s)
}
