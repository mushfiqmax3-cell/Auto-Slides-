package com.example.ui.components

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.MovieCreation
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.utils.GeminiPromptAndAiService
import com.example.utils.Mp4VideoExporter
import com.example.viewmodel.AiGenState
import com.example.viewmodel.ProMotionViewModel
import java.io.File
import kotlinx.coroutines.launch

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun RemotionZipWizardSection(
    viewModel: ProMotionViewModel,
    aiState: AiGenState
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val inspectResult by viewModel.remotionInspectResult.collectAsState()
    val customBitmaps by viewModel.customBitmaps.collectAsState()

    var selectedResolution by remember { mutableStateOf("1080p") }
    var isRenderingMp4 by remember { mutableStateOf(false) }
    var renderProgress by remember { mutableFloatStateOf(0f) }
    var renderedMp4File by remember { mutableStateOf<File?>(null) }
    var renderError by remember { mutableStateOf<String?>(null) }
    var showSourceCode by remember { mutableStateOf(false) }

    val zipPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            renderedMp4File = null
            renderError = null
            viewModel.loadRemotionZipUri(context, uri)
        }
    }

    // Step 1: Upload Remotion .zip or Load Sample
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFFF59E0B).copy(alpha = 0.6f), RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF131B2E))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.FolderZip,
                    contentDescription = null,
                    tint = Color(0xFFF59E0B),
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "১. Remotion প্রজেক্ট (.zip) আপলোড করুন",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    Text(
                        text = "আপনার রিমোশন জিপ ফাইল (.tsx, .ts, Composition, Sequence ও ইমেজসহ) সিলেক্ট করলে অ্যাপ সেটি পড়ে সরাসরি MP4 ভিডিওতে কনভার্ট করবে",
                        color = Color(0xFF94A3B8),
                        fontSize = 12.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Button(
                onClick = {
                    zipPickerLauncher.launch(
                        arrayOf(
                            "application/zip",
                            "application/x-zip-compressed",
                            "application/octet-stream",
                            "*/*"
                        )
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("pick_remotion_zip_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFF59E0B),
                    contentColor = Color(0xFF0B0F19)
                )
            ) {
                Icon(Icons.Default.FolderZip, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "📂 ফোন থেকে Remotion (.zip) ফাইল বাছুন",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 14.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedButton(
                onClick = {
                    renderedMp4File = null
                    renderError = null
                    viewModel.loadSampleRemotionZip()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .testTag("load_sample_remotion_zip_button"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(
                    Icons.Default.Science,
                    contentDescription = null,
                    tint = Color(0xFF38BDF8),
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "🧪 স্যাম্পল Remotion প্রজেক্ট (.zip) লোড করে টেস্ট করুন",
                    color = Color(0xFF38BDF8),
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
        }
    }

    if (aiState is AiGenState.Loading) {
        Spacer(modifier = Modifier.height(12.dp))
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CircularProgressIndicator(
                    modifier = Modifier.size(22.dp),
                    color = Color(0xFFF59E0B),
                    strokeWidth = 2.5.dp
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(text = aiState.statusText, color = Color.White, fontSize = 13.sp)
            }
        }
    } else if (aiState is AiGenState.Error) {
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "⚠️ ${aiState.message}",
            color = Color(0xFFF87171),
            fontSize = 13.sp
        )
    }

    val currentInspect = inspectResult
    if (currentInspect != null) {
        val convertedProject = currentInspect.instantConvertedProject

        Spacer(modifier = Modifier.height(16.dp))

        // Step 2: Detected Remotion Composition & Metadata Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0xFF10B981).copy(alpha = 0.5f), RoundedCornerShape(16.dp)),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF131B2E))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = Color(0xFF10B981),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "২. রিমোশন প্রজেক্ট বিশ্লেষণ সম্পন্ন",
                            color = Color(0xFF10B981),
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                    Surface(
                        color = Color(0xFF0B0F19),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "${convertedProject.scenes.size} Scenes",
                            color = Color(0xFFF59E0B),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "📦 ফাইল: ${currentInspect.zipFileName}",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "🎬 Composition ID: ${currentInspect.compositionIds.joinToString(", ")}",
                    color = Color(0xFF38BDF8),
                    fontSize = 13.sp
                )
                Text(
                    text = "📐 মাপ: ${currentInspect.detectedWidth}×${currentInspect.detectedHeight} (${convertedProject.aspectRatio}) • ${currentInspect.detectedFps} FPS • ${currentInspect.detectedDurationInFrames} Frames (${String.format("%.1f", convertedProject.totalDurationSec)}s)",
                    color = Color(0xFFE2E8F0),
                    fontSize = 12.sp
                )
                Text(
                    text = "📄 সোর্স ফাইল (${currentInspect.sourceFileNames.size}টি): ${currentInspect.sourceFileNames.take(6).joinToString(", ")}",
                    color = Color(0xFF94A3B8),
                    fontSize = 12.sp
                )
                if (currentInspect.extractedBitmaps.isNotEmpty()) {
                    Text(
                        text = "🖼️ জিপ থেকে লোড হওয়া ইমেজ অ্যাসেট: ${currentInspect.extractedBitmaps.keys.joinToString(", ")}",
                        color = Color(0xFFF59E0B),
                        fontSize = 12.sp
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { showSourceCode = !showSourceCode },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Code, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (showSourceCode) "কোড লুকান" else "Remotion কোড দেখুন",
                            fontSize = 12.sp
                        )
                    }
                    OutlinedButton(
                        onClick = { viewModel.openProjectInEditor(convertedProject) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("open_remotion_in_editor_button")
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color(0xFFF59E0B))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("এডিটরে কাস্টমাইজ", fontSize = 12.sp, color = Color(0xFFF59E0B))
                    }
                }

                if (showSourceCode && currentInspect.extractedSourceSummary.isNotBlank()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        color = Color(0xFF0B0F19),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = currentInspect.extractedSourceSummary.take(1800),
                            color = Color(0xFF38BDF8),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Step 3: Direct MP4 Render & Export Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.5.dp, Color(0xFFF59E0B), RoundedCornerShape(16.dp)),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF131B2E))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "৩. সরাসরি MP4 ভিডিওতে কনভার্ট ও ডাউনলোড",
                    color = Color(0xFFF59E0B),
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "রেজোলিউশন বেছে নিচের বাটনে চাপ দিলে রিমোশন প্রজেক্টটি ফোনেই H.264 `.mp4` ভিডিওতে রেন্ডার হবে:",
                    color = Color(0xFF94A3B8),
                    fontSize = 12.sp
                )

                Spacer(modifier = Modifier.height(10.dp))

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    listOf(
                        "720p" to "720p HD (দ্রুত)",
                        "1080p" to "1080p Full HD (সেরা)",
                        "2K" to "2K Ultra HD"
                    ).forEach { (resKey, label) ->
                        FilterChip(
                            selected = selectedResolution == resKey,
                            onClick = { if (!isRenderingMp4) selectedResolution = resKey },
                            label = { Text(label, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFFF59E0B),
                                selectedLabelColor = Color(0xFF0B0F19)
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (isRenderingMp4) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "🎬 Remotion ➔ MP4 ভিডিও তৈরি হচ্ছে (30 FPS H.264)...",
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "${(renderProgress * 100).toInt()}%",
                                color = Color(0xFFF59E0B),
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = { renderProgress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(10.dp)
                                .clip(RoundedCornerShape(5.dp)),
                            color = Color(0xFFF59E0B),
                            trackColor = Color(0xFF1E293B)
                        )
                    }
                } else {
                    Button(
                        onClick = {
                            isRenderingMp4 = true
                            renderProgress = 0f
                            renderError = null
                            scope.launch {
                                val res = Mp4VideoExporter.exportProjectToMp4(
                                    context = context,
                                    project = convertedProject,
                                    resPreset = selectedResolution,
                                    customImages = customBitmaps,
                                    onProgress = { pct -> renderProgress = pct / 100f }
                                )
                                isRenderingMp4 = false
                                res.onSuccess { info ->
                                    renderedMp4File = info.mp4File
                                    viewModel.showToast("🎉 Remotion প্রজেক্ট সফলভাবে MP4 ভিডিওতে কনভার্ট হয়েছে!")
                                }.onFailure { err ->
                                    renderError = err.localizedMessage ?: "MP4 কনভার্ট করতে সমস্যা হয়েছে"
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("convert_remotion_to_mp4_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF10B981),
                            contentColor = Color(0xFF0B0F19)
                        )
                    ) {
                        Icon(Icons.Default.MovieCreation, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "🎬 সরাসরি MP4 ভিডিওতে কনভার্ট করুন ($selectedResolution)",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 15.sp
                        )
                    }
                }

                renderError?.let { err ->
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "⚠️ $err", color = Color(0xFFF87171), fontSize = 12.sp)
                }

                renderedMp4File?.let { mp4 ->
                    Spacer(modifier = Modifier.height(14.dp))
                    Surface(
                        color = Color(0xFF10B981).copy(alpha = 0.15f),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "✓ MP4 ভিডিও প্রস্তুত: ${mp4.name} (${mp4.length() / 1024} KB)",
                                color = Color(0xFF10B981),
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = {
                                        val saved = Mp4VideoExporter.saveToDeviceDownloads(context, mp4, "video/mp4")
                                        if (saved.isSuccess) {
                                            viewModel.showToast("📥 ফোনের Downloads ফোল্ডারে MP4 সেভ হয়েছে!")
                                        } else {
                                            viewModel.showToast("⚠️ সেভ করতে সমস্যা: ${saved.exceptionOrNull()?.localizedMessage}")
                                        }
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(46.dp)
                                        .testTag("remotion_download_mp4_button"),
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFFF59E0B),
                                        contentColor = Color(0xFF0B0F19)
                                    )
                                ) {
                                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("📥 ডাউনলোড (.mp4)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }

                                OutlinedButton(
                                    onClick = {
                                        Mp4VideoExporter.shareExportedFile(context, mp4, "video/mp4")
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(46.dp)
                                        .testTag("remotion_share_mp4_button"),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("↗ শেয়ার করুন", color = Color(0xFF38BDF8), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Step 4: Optional AI Deep Transpile for Complex Custom JSX/TSX
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF131B2E))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "৪. জটিল Remotion কোডের জন্য AI ডিপ-ট্রান্সপাইলার (ঐচ্ছিক)",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "আপনার Remotion প্রজেক্টে যদি কাস্টম React কম্পোনেন্ট বা জটিল অ্যানিমেশন থাকে, তবে Gemini AI দিয়ে সেটিকে আরও নিখুঁত মোশন সিনে রূপান্তর করতে পারেন:",
                    color = Color(0xFF94A3B8),
                    fontSize = 12.sp
                )
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = { viewModel.transpileRemotionZipWithGeminiAi() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("ai_transpile_remotion_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF38BDF8),
                        contentColor = Color(0xFF0B0F19)
                    )
                ) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "✨ Gemini AI দিয়ে Remotion কোড ডিপ-ট্রান্সপাইল করুন",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedButton(
                    onClick = {
                        val prompt = GeminiPromptAndAiService.buildRemotionTranspilePrompt(currentInspect)
                        GeminiPromptAndAiService.copyToClipboard(context, "Remotion to ProMotion Prompt", prompt)
                        viewModel.showToast("📋 Remotion কোডসহ প্রম্পট কপি হয়েছে! Gemini অ্যাপে Paste করুন।")
                        GeminiPromptAndAiService.openExternalGeminiApp(context)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("📋 কোড কপি করে ফ্রি Gemini অ্যাপে খুলুন", color = Color(0xFF38BDF8), fontSize = 12.sp)
                }
            }
        }
    }
}
