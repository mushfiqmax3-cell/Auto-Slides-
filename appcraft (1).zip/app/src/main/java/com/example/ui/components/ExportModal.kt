package com.example.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.MovieCreation
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.utils.ExportResultInfo
import com.example.utils.Mp4VideoExporter
import com.example.viewmodel.ProMotionViewModel
import kotlinx.coroutines.launch

@Composable
fun ExportModal(
    viewModel: ProMotionViewModel,
    onDismiss: () -> Unit
) {
    BackHandler { onDismiss() }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val project by viewModel.activeProject.collectAsState()
    val customBitmaps by viewModel.customBitmaps.collectAsState()

    var selectedFormat by remember { mutableStateOf("MP4") }
    var selectedRes by remember { mutableStateOf("1080p") }
    var includeThumbnail by remember { mutableStateOf(true) }
    var includeSrt by remember { mutableStateOf(true) }
    var exportAllRatios by remember { mutableStateOf(false) }

    var isRendering by remember { mutableStateOf(false) }
    var renderProgress by remember { mutableIntStateOf(0) }
    var exportResult by remember { mutableStateOf<ExportResultInfo?>(null) }
    var exportError by remember { mutableStateOf<String?>(null) }

    Surface(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing),
        color = Color(0xFF0B0F19)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.testTag("export_back_button")
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Text(
                    text = "🎬 অন-ফোন MP4 ভিডিও এক্সপোর্ট স্টুডিও",
                    style = MaterialTheme.typography.titleLarge,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 1. Format Selection
            Text("১. ফরম্যাট বাছুন (Format)", color = Color(0xFFF59E0B), fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(
                    "MP4" to "🎬 MP4 Video",
                    "GIF" to "🎞️ GIF Animation",
                    "PNG" to "🖼️ PNG Sequence"
                ).forEach { (id, label) ->
                    FilterChip(
                        selected = selectedFormat == id,
                        onClick = { selectedFormat = id },
                        label = { Text(label, fontSize = 12.sp) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 2. Resolution Selection
            Text("২. রেজোলিউশন (Resolution)", color = Color(0xFFF59E0B), fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Spacer(modifier = Modifier.height(8.dp))
            val resolutions = listOf(
                "720p" to "720p — ছোট ফাইল ও দ্রুত (1280×720)",
                "1080p" to "1080p — YouTube / Facebook HD (1920×1080)",
                "2K" to "2K Ultra HD — (2560×1440)"
            )
            resolutions.forEach { (id, desc) ->
                val isSel = selectedRes == id
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clickable { selectedRes = id }
                        .border(
                            width = if (isSel) 2.dp else 1.dp,
                            color = if (isSel) Color(0xFFF59E0B) else Color(0xFF334155),
                            shape = RoundedCornerShape(12.dp)
                        ),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF131B2E))
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = desc,
                            color = if (isSel) Color(0xFFF59E0B) else Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 3. Extras Checkboxes
            Text("৩. অতিরিক্ত ফাইল (Extras)", color = Color(0xFFF59E0B), fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(
                    checked = includeThumbnail,
                    onCheckedChange = { includeThumbnail = it },
                    colors = CheckboxDefaults.colors(checkedColor = Color(0xFF10B981))
                )
                Text("Thumbnail (PNG) — ভিডিওর সেরা দৃশ্যের ছবি নামবে", color = Color.White, fontSize = 13.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(
                    checked = includeSrt,
                    onCheckedChange = { includeSrt = it },
                    colors = CheckboxDefaults.colors(checkedColor = Color(0xFF10B981))
                )
                Text("SRT Subtitle (.srt) — YouTube/Facebook-এ দেওয়ার জন্য কথার লেখা নামবে", color = Color.White, fontSize = 13.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(
                    checked = exportAllRatios,
                    onCheckedChange = { exportAllRatios = it },
                    colors = CheckboxDefaults.colors(checkedColor = Color(0xFF10B981))
                )
                Text("সব মাপে একসাথে (16:9, 9:16, 1:1)", color = Color.White, fontSize = 13.sp)
            }

            Spacer(modifier = Modifier.height(20.dp))

            // 4. Real-Time On-Phone Rendering Button
            Button(
                onClick = {
                    isRendering = true
                    renderProgress = 2
                    exportResult = null
                    exportError = null
                    scope.launch {
                        val res = Mp4VideoExporter.exportProjectToMp4(
                            context = context,
                            project = project,
                            resPreset = selectedRes,
                            includeThumbnail = includeThumbnail,
                            includeSrt = includeSrt,
                            customImages = customBitmaps,
                            onProgress = { pct -> renderProgress = pct }
                        )
                        isRendering = false
                        res.onSuccess { info ->
                            exportResult = info
                        }.onFailure { err ->
                            exportError = err.localizedMessage ?: "Export failed"
                        }
                    }
                },
                enabled = !isRendering,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("start_mp4_render_button"),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFF59E0B),
                    contentColor = Color(0xFF0B0F19)
                )
            ) {
                Icon(Icons.Default.MovieCreation, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isRendering) "🎬 ভিডিও রেন্ডার হচ্ছে ($renderProgress%)..." else "🎬 MP4 বানান (অফলাইন রেন্ডার)",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 16.sp
                )
            }

            if (isRendering) {
                Spacer(modifier = Modifier.height(14.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF131B2E))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        LinearProgressIndicator(
                            progress = { renderProgress / 100f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(10.dp),
                            color = Color(0xFF10B981),
                            trackColor = Color(0xFF1E293B)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "ফোনেই ভিডিও তৈরি হচ্ছে ($renderProgress%), ইন্টারনেট লাগে না — অ্যাপ খোলা রাখুন...",
                            color = Color(0xFF38BDF8),
                            fontSize = 13.sp
                        )
                    }
                }
            }

            if (exportError != null) {
                Spacer(modifier = Modifier.height(12.dp))
                Text("⚠️ $exportError", color = Color(0xFFF87171), fontSize = 13.sp)
            }

            // Completed Export Card
            exportResult?.let { info ->
                Spacer(modifier = Modifier.height(18.dp))
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(2.dp, Color(0xFF10B981), RoundedCornerShape(16.dp)),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0D2824))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF10B981))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "✓ 100% — MP4 তৈরি! (${info.mp4File.name}, ${info.resolutionLabel}, ${"%.2f".format(info.fileSizeMb)} MB)",
                                color = Color(0xFF10B981),
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Button(
                            onClick = {
                                val saved = Mp4VideoExporter.saveToDeviceDownloads(context, info.mp4File, "video/mp4")
                                info.thumbnailFile?.let { Mp4VideoExporter.saveToDeviceDownloads(context, it, "image/png") }
                                info.srtFile?.let { Mp4VideoExporter.saveToDeviceDownloads(context, it, "text/plain") }
                                if (saved.isSuccess) {
                                    viewModel.showToast("📥 ফোনের Downloads ফোল্ডারে MP4 সেভ হয়েছে!")
                                } else {
                                    viewModel.showToast("✓ ফাইল সেভ সম্পন্ন: ${info.mp4File.absolutePath}")
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("download_mp4_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981), contentColor = Color(0xFF0B0F19))
                        ) {
                            Icon(Icons.Default.FileDownload, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("📥 ফোনে ডাউনলোড করুন (.mp4)", fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedButton(
                            onClick = {
                                Mp4VideoExporter.shareExportedFile(context, info.mp4File, "video/mp4")
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("share_mp4_button"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, tint = Color(0xFF38BDF8))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("↗ পাঠান — WhatsApp · Gmail · Drive", color = Color(0xFF38BDF8), fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedButton(
                            onClick = {
                                viewModel.saveCurrentThemeToCloud("${project.title} Theme")
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("save_theme_from_export_button"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Star, contentDescription = null, tint = Color(0xFFF59E0B))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("⭐ এই ভিডিওর থিম \"রাখুন\" (পরের ভিডিও ১ চাপে এই চেহারায় হবে)", color = Color(0xFFF59E0B), fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}
