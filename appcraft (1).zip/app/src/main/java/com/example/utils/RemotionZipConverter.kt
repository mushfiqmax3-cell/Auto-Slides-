package com.example.utils

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import com.example.model.BUILTIN_LOOKS
import com.example.model.ProMotionProject
import com.example.model.ProMotionScene
import com.example.model.SceneTemplate
import com.example.model.SrtCue
import com.example.model.SrtParser
import com.example.model.SubtitleStyle
import com.example.model.WaveformVariant
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.util.zip.ZipInputStream
import kotlin.math.max
import kotlin.math.roundToInt

data class RemotionZipInspectResult(
    val zipFileName: String,
    val compositionIds: List<String>,
    val detectedWidth: Int,
    val detectedHeight: Int,
    val detectedFps: Int,
    val detectedDurationInFrames: Int,
    val detectedAspectRatio: String,
    val sourceFilesCount: Int,
    val sourceFileNames: List<String>,
    val extractedSourceSummary: String,
    val extractedSrtText: String,
    val extractedBitmaps: Map<String, Bitmap>,
    val instantConvertedProject: ProMotionProject
)

object RemotionZipConverter {

    private val CODE_EXTENSIONS = setOf("tsx", "ts", "jsx", "js", "json", "css", "md")
    private val IMAGE_EXTENSIONS = setOf("png", "jpg", "jpeg", "webp")

    suspend fun inspectAndParseRemotionZip(
        context: Context,
        uri: Uri
    ): Result<RemotionZipInspectResult> = withContext(Dispatchers.IO) {
        runCatching {
            val fileName = queryDisplayName(context, uri) ?: "remotion_project.zip"
            val sourceFiles = mutableListOf<Pair<String, String>>()
            val extractedImages = mutableMapOf<String, Bitmap>()
            var srtContent = ""
            var imgIndex = 1

            context.contentResolver.openInputStream(uri)?.use { rawStream ->
                ZipInputStream(rawStream).use { zis ->
                    var entry = zis.nextEntry
                    while (entry != null) {
                        val name = entry.name
                        if (!entry.isDirectory && !name.contains("node_modules/") && !name.contains(".git/")) {
                            val ext = name.substringAfterLast('.', "").lowercase()
                            if (ext == "srt") {
                                val bytes = readEntryBytes(zis, maxBytes = 256 * 1024)
                                srtContent = bytes.toString(Charsets.UTF_8)
                            } else if (ext in CODE_EXTENSIONS) {
                                val bytes = readEntryBytes(zis, maxBytes = 180 * 1024)
                                val text = bytes.toString(Charsets.UTF_8)
                                sourceFiles.add(name to text)
                            } else if (ext in IMAGE_EXTENSIONS && extractedImages.size < 5) {
                                val bytes = readEntryBytes(zis, maxBytes = 4 * 1024 * 1024)
                                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                                if (bmp != null) {
                                    val lowerName = name.lowercase()
                                    val key = if (lowerName.contains("logo") && !extractedImages.containsKey("logo")) {
                                        "logo"
                                    } else {
                                        val k = "img$imgIndex"
                                        imgIndex = (imgIndex % 4) + 1
                                        k
                                    }
                                    extractedImages[key] = bmp
                                }
                            }
                        }
                        zis.closeEntry()
                        entry = zis.nextEntry
                    }
                }
            } ?: throw IllegalStateException("জিপ ফাইলটি খোলা যায়নি।")

            if (sourceFiles.isEmpty() && extractedImages.isEmpty()) {
                throw IllegalStateException("জিপ ফাইলের ভেতরে কোনো Remotion (.tsx/.ts/.js/.json) ফাইল পাওয়া যায়নি।")
            }

            buildInspectResult(
                zipFileName = fileName,
                sourceFiles = sourceFiles,
                srtContent = srtContent,
                extractedImages = extractedImages
            )
        }
    }

    fun createSampleRemotionInspectResult(): RemotionZipInspectResult {
        val sampleRootTsx = """
import { Composition } from 'remotion';
import { MainExplainer } from './MainExplainer';

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="RemotionScienceExplainer"
      component={MainExplainer}
      durationInFrames={720}
      fps={30}
      width={1920}
      height={1080}
    />
  );
};
""".trimIndent()

        val sampleMainTsx = """
import { AbsoluteFill, Sequence, useCurrentFrame, interpolate } from 'remotion';

export const MainExplainer: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill style={{ backgroundColor: '#07222E' }}>
      <Sequence from={0} durationInFrames={180} name="Hook: Remotion থেকে সরাসরি [MP4 ভিডিও]">
        <h1>ফোনেই রিমোশন জিপ ফাইল থেকে [1080p MP4] রেন্ডার</h1>
        <p>কোনো পিসি বা ক্লাউড সার্ভার ছাড়াই [৩০ FPS] হার্ডওয়্যার এনকোডিং।</p>
      </Sequence>
      <Sequence from={180} durationInFrames={180} name="Waveform: সিগন্যাল ও [অসিলোস্কোপ ওয়েভফর্ম]">
        <h1>Remotion Sequence থেকে অটোমেটিক [Waveform Lab]</h1>
        <p>প্রতিটি ফ্রেম ও [টাইমলাইন সিকোয়েন্স] নিখুঁতভাবে ক্যানভাসে রূপান্তরিত হয়।</p>
      </Sequence>
      <Sequence from={360} durationInFrames={180} name="Stats: রেন্ডার স্পিড ও [পারফরম্যান্স]">
        <h1>[১০০% অফলাইন] H.264 হার্ডওয়্যার মিডিয়া কোডেক</h1>
        <p>আপনার রিমোশন কম্পোজিশনের মাপ, রঙ ও সাবটাইটেল [অক্ষুণ্ণ] থাকে।</p>
      </Sequence>
      <Sequence from={540} durationInFrames={180} name="Outro: ডাউনলোড ও [শেয়ার করুন]">
        <h1>এখনই আপনার রিমোশন জিপ ফাইল [MP4 ফরম্যাটে] সেভ করুন!</h1>
        <p>নিচের বাটনে ট্যাপ করে সরাসরি ফোনে ডাউনলোড বা শেয়ার করুন।</p>
      </Sequence>
    </AbsoluteFill>
  );
};
""".trimIndent()

        return buildInspectResult(
            zipFileName = "remotion-science-explainer.zip",
            sourceFiles = listOf(
                "src/Root.tsx" to sampleRootTsx,
                "src/MainExplainer.tsx" to sampleMainTsx,
                "package.json" to """{ "name": "remotion-science-explainer", "dependencies": { "remotion": "^4.0.0" } }"""
            ),
            srtContent = "",
            extractedImages = emptyMap()
        )
    }

    private fun buildInspectResult(
        zipFileName: String,
        sourceFiles: List<Pair<String, String>>,
        srtContent: String,
        extractedImages: Map<String, Bitmap>
    ): RemotionZipInspectResult {
        val allCode = sourceFiles.joinToString("\n\n") { (path, content) ->
            "// --- FILE: $path ---\n${content.take(6000)}"
        }

        // 1. Detect Composition metadata
        val compIds = Regex("""<Composition[^>]*\bid\s*=\s*["']([^"']+)["']""")
            .findAll(allCode)
            .map { it.groupValues[1] }
            .distinct()
            .toList()
            .ifEmpty { listOf(zipFileName.removeSuffix(".zip")) }

        val fps = Regex("""\bfps\s*[=:]\s*\{?\s*(\d{2,3})""")
            .find(allCode)?.groupValues?.get(1)?.toIntOrNull()?.coerceIn(15, 60) ?: 30

        val durationInFrames = Regex("""\bdurationInFrames\s*[=:]\s*\{?\s*(\d+)""")
            .findAll(allCode)
            .mapNotNull { it.groupValues[1].toIntOrNull() }
            .maxOrNull()?.coerceIn(60, 18000) ?: 600

        val width = Regex("""\bwidth\s*[=:]\s*\{?\s*(\d{3,4})""")
            .find(allCode)?.groupValues?.get(1)?.toIntOrNull() ?: 1920

        val height = Regex("""\bheight\s*[=:]\s*\{?\s*(\d{3,4})""")
            .find(allCode)?.groupValues?.get(1)?.toIntOrNull() ?: 1080

        val aspectRatio = when {
            height > width && (width.toFloat() / height.toFloat()) < 0.65f -> "9:16"
            width == height -> "1:1"
            height > width -> "4:5"
            else -> "16:9"
        }

        // 2. Detect colors if present in Remotion styles
        val hexColors = Regex("""#[0-9a-fA-F]{6}\b""")
            .findAll(allCode)
            .map { it.value.uppercase() }
            .distinct()
            .toList()

        val look = BUILTIN_LOOKS[3] // Dual-Theme Master fallback
        val bgHex = hexColors.firstOrNull { it.startsWith("#0") || it.startsWith("#1") } ?: look.bgHex

        // 3. Extract <Sequence> blocks or component scenes
        val scenes = extractScenesFromRemotionCode(
            allCode = allCode,
            sourceFiles = sourceFiles,
            fps = fps,
            totalDurationSec = (durationInFrames.toFloat() / fps.toFloat()).coerceIn(6f, 180f),
            hasExtractedImages = extractedImages.isNotEmpty()
        )

        val parsedSrt = if (srtContent.isNotBlank()) {
            SrtParser.parseSrt(srtContent)
        } else {
            var acc = 0f
            scenes.mapIndexed { idx, s ->
                val start = acc
                val end = acc + s.durationSec
                acc = end
                SrtCue(
                    index = idx + 1,
                    startSec = start,
                    endSec = end,
                    text = s.subtext.ifBlank { s.heading }
                )
            }
        }

        val projectTitle = compIds.firstOrNull()?.replace("-", " ")?.replace("_", " ")
            ?: zipFileName.removeSuffix(".zip")

        val convertedProject = ProMotionProject(
            id = "remotion_${System.currentTimeMillis()}",
            title = "Remotion: $projectTitle",
            aspectRatio = aspectRatio,
            lookId = look.id,
            bgHex = bgHex,
            bgSecondaryHex = look.bgSecondaryHex,
            cardHex = look.cardHex,
            inkHex = look.inkHex,
            accentHex = look.accentHex,
            hlHex = look.hlHex,
            isDualTheme = false,
            subtitleEnabled = true,
            subtitleStyle = SubtitleStyle.PILL,
            scenes = scenes,
            srtCues = parsedSrt
        )

        return RemotionZipInspectResult(
            zipFileName = zipFileName,
            compositionIds = compIds,
            detectedWidth = width,
            detectedHeight = height,
            detectedFps = fps,
            detectedDurationInFrames = durationInFrames,
            detectedAspectRatio = aspectRatio,
            sourceFilesCount = sourceFiles.size,
            sourceFileNames = sourceFiles.map { it.first.substringAfterLast('/') }.distinct().take(12),
            extractedSourceSummary = allCode.take(14000),
            extractedSrtText = srtContent,
            extractedBitmaps = extractedImages,
            instantConvertedProject = convertedProject
        )
    }

    private fun extractScenesFromRemotionCode(
        allCode: String,
        sourceFiles: List<Pair<String, String>>,
        fps: Int,
        totalDurationSec: Float,
        hasExtractedImages: Boolean
    ): List<ProMotionScene> {
        val scenes = mutableListOf<ProMotionScene>()

        // Match <Sequence ...> blocks if present
        val seqRegex = Regex("""<Sequence([^>]*)>([\s\S]*?)</Sequence>""")
        val seqMatches = seqRegex.findAll(allCode).toList()

        if (seqMatches.isNotEmpty()) {
            seqMatches.take(10).forEachIndexed { idx, match ->
                val attrs = match.groupValues[1]
                val inner = match.groupValues[2]
                val seqName = Regex("""\bname\s*=\s*["']([^"']+)["']""").find(attrs)?.groupValues?.get(1)
                val durFrames = Regex("""\bdurationInFrames\s*=\s*\{?\s*(\d+)""").find(attrs)?.groupValues?.get(1)?.toIntOrNull()
                val durSec = if (durFrames != null && fps > 0) {
                    (durFrames.toFloat() / fps.toFloat()).coerceIn(2.5f, 25f)
                } else {
                    (totalDurationSec / max(1, seqMatches.size)).coerceIn(3.5f, 12f)
                }

                val textNodes = extractReadableStrings(inner)
                val heading = textNodes.getOrNull(0)
                    ?: seqName
                    ?: "Remotion দৃশ্য [${idx + 1}]"
                val subtext = textNodes.getOrNull(1)
                    ?: seqName
                    ?: heading

                val template = inferSceneTemplate(heading + " " + inner, idx, seqMatches.size, hasExtractedImages)

                scenes.add(
                    ProMotionScene(
                        id = "rem_seq_${idx + 1}",
                        chapterNum = idx + 1,
                        chapterBadge = seqName?.substringBefore(':')?.take(28) ?: "Sequence ${idx + 1}",
                        heading = ensureBracketHighlight(heading),
                        subtext = ensureBracketHighlight(subtext),
                        durationSec = (durSec * 10f).roundToInt() / 10f,
                        template = template,
                        waveformVariant = WaveformVariant.NON_IDEAL_PULSE,
                        calloutLabels = textNodes.drop(2).take(3).ifEmpty {
                            listOf("FPS: $fps", "Sequence #${idx + 1}", "1080p Render")
                        },
                        statusPills = listOf("✓ Remotion Sequence #${idx + 1}", "✓ 30 FPS Hardware Sync"),
                        stickerBadge = "REMOTION",
                        stickerEmoji = "🎬"
                    )
                )
            }
        }

        if (scenes.isEmpty()) {
            // Fallback: build scenes from each .tsx/.jsx component file in the zip
            val componentFiles = sourceFiles.filter {
                val lower = it.first.lowercase()
                (lower.endsWith(".tsx") || lower.endsWith(".jsx") || lower.endsWith(".ts") || lower.endsWith(".js")) &&
                    !lower.endsWith("index.ts") && !lower.endsWith("index.tsx")
            }.ifEmpty { sourceFiles }

            val count = componentFiles.size.coerceIn(1, 8)
            val perSceneSec = (totalDurationSec / count).coerceIn(4f, 10f)

            componentFiles.take(8).forEachIndexed { idx, (filePath, code) ->
                val shortName = filePath.substringAfterLast('/').substringBeforeLast('.')
                val strings = extractReadableStrings(code)
                val heading = strings.getOrNull(0) ?: "Remotion কম্পোনেন্ট: [$shortName]"
                val subtext = strings.getOrNull(1) ?: "[$shortName] থেকে অ্যানিমেটেড দৃশ্য ও ভেক্টর গ্রাফিক্স।"
                val template = inferSceneTemplate(code, idx, count, hasExtractedImages)

                scenes.add(
                    ProMotionScene(
                        id = "rem_comp_${idx + 1}",
                        chapterNum = idx + 1,
                        chapterBadge = "Component • $shortName",
                        heading = ensureBracketHighlight(heading),
                        subtext = ensureBracketHighlight(subtext),
                        durationSec = (perSceneSec * 10f).roundToInt() / 10f,
                        template = template,
                        calloutLabels = strings.drop(2).take(3).ifEmpty {
                            listOf(shortName, "${fps} FPS", "MP4 Ready")
                        },
                        statusPills = listOf("✓ সোর্স: $shortName", "✓ Auto-Transpiled"),
                        stickerBadge = "REMOTION",
                        stickerEmoji = "📦"
                    )
                )
            }
        }

        return scenes
    }

    private fun extractReadableStrings(codeSnippet: String): List<String> {
        val results = mutableListOf<String>()
        // 1. JSX inner text: >Some text<
        val jsxTextRegex = Regex(""">([^<>{}\n\r]{4,110})<""")
        jsxTextRegex.findAll(codeSnippet).forEach { m ->
            val cleaned = m.groupValues[1].trim()
            if (cleaned.length >= 4 && !cleaned.startsWith("//") && !cleaned.contains("import ")) {
                results.add(cleaned)
            }
        }
        // 2. Quoted titles / headings / text props
        val propTextRegex = Regex("""(?:title|heading|subtitle|text|label|name)\s*[:=]\s*["']([^"'\n\r]{4,110})["']""", RegexOption.IGNORE_CASE)
        propTextRegex.findAll(codeSnippet).forEach { m ->
            val cleaned = m.groupValues[1].trim()
            if (cleaned.length >= 4) {
                results.add(cleaned)
            }
        }
        return results.distinct()
    }

    private fun ensureBracketHighlight(text: String): String {
        if (text.contains("[") && text.contains("]")) return text
        val words = text.trim().split(Regex("\\s+"))
        if (words.isEmpty()) return "[Remotion] দৃশ্য"
        return if (words.size >= 3) {
            val mid = words.size / 2
            words.mapIndexed { idx, w -> if (idx == mid) "[$w]" else w }.joinToString(" ")
        } else {
            "[${words.first()}] ${words.drop(1).joinToString(" ")}".trim()
        }
    }

    private fun inferSceneTemplate(
        codeOrText: String,
        index: Int,
        total: Int,
        hasExtractedImages: Boolean
    ): SceneTemplate {
        val lower = codeOrText.lowercase()
        return when {
            lower.contains("wave") || lower.contains("oscilloscope") || lower.contains("pulse") || lower.contains("signal") ->
                SceneTemplate.WAVEFORM_LAB
            lower.contains("logic") || lower.contains("ttl") || lower.contains("voltage") ->
                SceneTemplate.LOGIC_LEVEL_BAND
            lower.contains("battery") || lower.contains("cutaway") || lower.contains("xray") ->
                SceneTemplate.CUTAWAY_XRAY
            lower.contains("loupe") || lower.contains("magnif") || lower.contains("zoom") ->
                SceneTemplate.MAGNIFIER_LOUPE
            lower.contains("chart") || lower.contains("stat") || lower.contains("bar") || lower.contains("graph") ->
                SceneTemplate.STAT_DASHBOARD
            lower.contains("counter") || lower.contains("progress") || lower.contains("percent") ->
                SceneTemplate.PROGRESS_BARS_COUNTER
            lower.contains("compare") || lower.contains("vs") ->
                SceneTemplate.COMPARISON_CARDS
            hasExtractedImages && index == 1 ->
                SceneTemplate.IMAGE_SHOWCASE
            index == 0 ->
                SceneTemplate.HERO_TITLE
            index == total - 1 && total > 2 ->
                SceneTemplate.OUTRO_CTA
            else ->
                SceneTemplate.SPLIT_CARD
        }
    }

    private fun readEntryBytes(zis: ZipInputStream, maxBytes: Int): ByteArray {
        val buffer = ByteArrayOutputStream()
        val data = ByteArray(4096)
        var total = 0
        while (true) {
            val count = zis.read(data, 0, data.size)
            if (count == -1) break
            val toWrite = minOf(count, maxBytes - total)
            if (toWrite > 0) {
                buffer.write(data, 0, toWrite)
                total += toWrite
            }
            if (total >= maxBytes) break
        }
        return buffer.toByteArray()
    }

    private fun queryDisplayName(context: Context, uri: Uri): String? {
        return try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) cursor.getString(idx) else null
                } else null
            }
        } catch (_: Exception) {
            null
        }
    }
}
