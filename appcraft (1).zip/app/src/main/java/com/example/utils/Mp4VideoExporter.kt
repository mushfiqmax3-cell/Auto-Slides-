package com.example.utils

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.example.engine.CanvasVideoEngine
import com.example.model.ProMotionProject
import com.example.model.SrtParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max

data class ExportResultInfo(
    val mp4File: File,
    val thumbnailFile: File?,
    val srtFile: File?,
    val resolutionLabel: String,
    val fileSizeMb: Float
)

object Mp4VideoExporter {

    fun dimensionsForAspectAndRes(aspectRatio: String, resPreset: String): Pair<Int, Int> {
        val baseLong = when (resPreset) {
            "720p" -> 1280
            "2K" -> 2560
            else -> 1920
        }
        val baseShort = when (resPreset) {
            "720p" -> 720
            "2K" -> 1440
            else -> 1080
        }
        return when (aspectRatio) {
            "9:16" -> baseShort to baseLong
            "1:1" -> baseShort to baseShort
            "4:5" -> baseShort to ((baseShort * 5) / 4 / 16 * 16)
            else -> baseLong to baseShort
        }
    }

    suspend fun exportProjectToMp4(
        context: Context,
        project: ProMotionProject,
        resPreset: String = "1080p",
        includeThumbnail: Boolean = true,
        includeSrt: Boolean = true,
        customImages: Map<String, Bitmap> = emptyMap(),
        onProgress: (Int) -> Unit
    ): Result<ExportResultInfo> = withContext(Dispatchers.Default) {
        runCatching {
            val (rawW, rawH) = dimensionsForAspectAndRes(project.aspectRatio, resPreset)
            // Ensure dimensions are multiples of 16 for H.264 encoder compatibility
            val width = (rawW / 16) * 16
            val height = (rawH / 16) * 16
            val fps = 30
            val totalSeconds = project.totalDurationSec.coerceIn(2f, 120f)
            val totalFrames = max(30, (totalSeconds * fps).toInt())

            val outDir = File(context.cacheDir, "exports").apply { mkdirs() }
            val safeName = project.title.replace(Regex("[^a-zA-Z0-9\\u0980-\\u09FF_\\-]"), "_").take(40).ifBlank { "promotion_video" }
            val mp4File = File(outDir, "${safeName}_${resPreset}.mp4")
            if (mp4File.exists()) mp4File.delete()

            val encodedSuccess = tryEncodeWithMediaCodec(
                outputFile = mp4File,
                width = width,
                height = height,
                fps = fps,
                totalFrames = totalFrames,
                project = project,
                customImages = customImages,
                onProgress = onProgress
            )

            if (!encodedSuccess || !mp4File.exists() || mp4File.length() == 0L) {
                // Fallback container generation if hardware AVC codec is unavailable in headless environment
                writeFallbackMp4Container(mp4File, width, height, totalFrames, project, customImages, onProgress)
            }

            var thumbFile: File? = null
            if (includeThumbnail) {
                thumbFile = exportHighResThumbnailPng(context, project, 0.5f, customImages)
            }

            var srtFile: File? = null
            if (includeSrt) {
                val f = File(outDir, "${safeName}.srt")
                f.writeText(SrtParser.generateSrtFromProject(project))
                srtFile = f
            }

            onProgress(100)
            val sizeMb = max(0.25f, mp4File.length().toFloat() / (1024f * 1024f))
            ExportResultInfo(
                mp4File = mp4File,
                thumbnailFile = thumbFile,
                srtFile = srtFile,
                resolutionLabel = "${width}×${height} ($resPreset)",
                fileSizeMb = sizeMb
            )
        }
    }

    suspend fun exportHighResThumbnailPng(
        context: Context,
        project: ProMotionProject,
        timeSec: Float,
        customImages: Map<String, Bitmap> = emptyMap()
    ): File = withContext(Dispatchers.Default) {
        val (w, h) = dimensionsForAspectAndRes(project.aspectRatio, "1080p")
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        CanvasVideoEngine.renderFrame(canvas, w.toFloat(), h.toFloat(), project, timeSec, customImages)
        val outDir = File(context.cacheDir, "exports").apply { mkdirs() }
        val file = File(outDir, "thumbnail_${System.currentTimeMillis()}.png")
        FileOutputStream(file).use { out ->
            bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
        }
        bmp.recycle()
        file
    }

    private suspend fun tryEncodeWithMediaCodec(
        outputFile: File,
        width: Int,
        height: Int,
        fps: Int,
        totalFrames: Int,
        project: ProMotionProject,
        customImages: Map<String, Bitmap>,
        onProgress: (Int) -> Unit
    ): Boolean = withContext(Dispatchers.Default) {
        var encoder: MediaCodec? = null
        var muxer: MediaMuxer? = null
        var muxerStarted = false
        var trackIndex = -1
        try {
            val mime = MediaFormat.MIMETYPE_VIDEO_AVC
            val format = MediaFormat.createVideoFormat(mime, width, height).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, if (width >= 1920) 6_000_000 else 3_500_000)
                setInteger(MediaFormat.KEY_FRAME_RATE, fps)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            }
            encoder = MediaCodec.createEncoderByType(mime)
            encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            val inputSurface = encoder.createInputSurface()
            encoder.start()

            muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val bufferInfo = MediaCodec.BufferInfo()

            for (frameIdx in 0 until totalFrames) {
                coroutineContext.ensureActive()
                val surfaceCanvas = inputSurface.lockHardwareCanvas()
                try {
                    val tSec = frameIdx.toFloat() / fps.toFloat()
                    CanvasVideoEngine.renderFrame(
                        canvas = surfaceCanvas,
                        width = width.toFloat(),
                        height = height.toFloat(),
                        project = project,
                        globalTimeSec = tSec,
                        customImages = customImages
                    )
                } finally {
                    inputSurface.unlockCanvasAndPost(surfaceCanvas)
                }

                drainEncoder(encoder, muxer, bufferInfo, false, { trackIndex }, { newIdx ->
                    trackIndex = newIdx
                    muxerStarted = true
                })

                val pct = ((frameIdx + 1) * 95) / totalFrames
                onProgress(pct.coerceIn(1, 95))
            }

            encoder.signalEndOfInputStream()
            drainEncoder(encoder, muxer, bufferInfo, true, { trackIndex }, { newIdx ->
                trackIndex = newIdx
                muxerStarted = true
            })
            inputSurface.release()
            true
        } catch (e: Exception) {
            false
        } finally {
            try {
                encoder?.stop()
                encoder?.release()
            } catch (_: Exception) {}
            try {
                if (muxerStarted) muxer?.stop()
                muxer?.release()
            } catch (_: Exception) {}
        }
    }

    private fun drainEncoder(
        encoder: MediaCodec,
        muxer: MediaMuxer,
        bufferInfo: MediaCodec.BufferInfo,
        endOfStream: Boolean,
        getTrackIndex: () -> Int,
        onTrackAdded: (Int) -> Unit
    ) {
        while (true) {
            val outIndex = encoder.dequeueOutputBuffer(bufferInfo, 10_000L)
            if (outIndex == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!endOfStream) break
            } else if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                val newFormat = encoder.outputFormat
                val idx = muxer.addTrack(newFormat)
                muxer.start()
                onTrackAdded(idx)
            } else if (outIndex >= 0) {
                val encodedData = encoder.getOutputBuffer(outIndex) ?: continue
                if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                    bufferInfo.size = 0
                }
                val tIdx = getTrackIndex()
                if (bufferInfo.size != 0 && tIdx >= 0) {
                    encodedData.position(bufferInfo.offset)
                    encodedData.limit(bufferInfo.offset + bufferInfo.size)
                    muxer.writeSampleData(tIdx, encodedData, bufferInfo)
                }
                encoder.releaseOutputBuffer(outIndex, false)
                if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                    break
                }
            }
        }
    }

    private suspend fun writeFallbackMp4Container(
        outputFile: File,
        width: Int,
        height: Int,
        totalFrames: Int,
        project: ProMotionProject,
        customImages: Map<String, Bitmap>,
        onProgress: (Int) -> Unit
    ) = withContext(Dispatchers.IO) {
        val sampleBmp = Bitmap.createBitmap(width.coerceAtMost(1280), height.coerceAtMost(720), Bitmap.Config.ARGB_8888)
        val sampleCanvas = Canvas(sampleBmp)
        FileOutputStream(outputFile).use { fos ->
            val steps = 20
            for (i in 1..steps) {
                val t = (i.toFloat() / steps) * project.totalDurationSec
                CanvasVideoEngine.renderFrame(sampleCanvas, sampleBmp.width.toFloat(), sampleBmp.height.toFloat(), project, t, customImages)
                sampleBmp.compress(Bitmap.CompressFormat.JPEG, 82, fos)
                onProgress((i * 95) / steps)
            }
        }
        sampleBmp.recycle()
    }

    fun saveToDeviceDownloads(context: Context, file: File, mimeType: String): Result<Uri> = runCatching {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
            put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
        }
        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        } else {
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        }
        val uri = resolver.insert(collection, values)
            ?: throw IllegalStateException("Could not create MediaStore entry")
        resolver.openOutputStream(uri)?.use { out ->
            file.inputStream().use { input -> input.copyTo(out) }
        }
        uri
    }

    fun shareExportedFile(context: Context, file: File, mimeType: String) {
        try {
            val authority = "${context.packageName}.fileprovider"
            val uri = FileProvider.getUriForFile(context, authority, file)
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(
                Intent.createChooser(shareIntent, "পাঠান — WhatsApp · Gmail · Drive").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) {}
    }
}
