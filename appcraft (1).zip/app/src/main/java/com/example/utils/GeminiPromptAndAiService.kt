package com.example.utils

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import com.example.model.ProMotionJsonCodec
import com.example.model.ProMotionProject
import com.example.model.SrtCue
import com.example.model.SrtParser
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout

object GeminiPromptAndAiService {
    private const val TAG = "GeminiProMotionAI"

    val GEMINI_SKILL_SYSTEM_PROMPT_V5 = """
You are the "ProMotion Gemini Skill v5" Motion Graphics & Science Explainer Video Architect.
Always output ONLY valid raw JSON matching `ProMotionProjectJSON v5` with zero markdown code fences.
Rules:
1. Wrap 1-2 key words per heading and subtitle in `[brackets]` (e.g. "ডিজিটাল সিগন্যালের মাত্র [দুটি অবস্থা] থাকে") so the Canvas engine highlights them in gold/cyan.
2. Maximum 3 to 4 short `calloutLabels` per scene so there is zero text overlap.
3. Choose the best `template` per scene from:
   - "split_card" (Split typography + vector card)
   - "waveform_lab" (Oscilloscope waveform with `waveformVariant`: "square_wave", "pos_rect_wave", "neg_rect_wave", "digitized_staircase", "sine_vs_noise", "non_ideal_pulse")
   - "logic_level_band" (TTL Voltage tower: HIGH 2-5V, Forbidden 0.8-2V, LOW 0-0.8V)
   - "cutaway_xray" (Cross-section diagram with e- particle flow)
   - "magnifier_loupe" (Macro object + 4x microscopic zoom loupe)
   - "comparison_cards" (Side-by-side ✓ vs ✕ cards)
   - "progress_bars_counter" (Animated ring counter + racing bars)
   - "stat_dashboard" (Bar chart dashboard)
   - "device_grid" (4-card device showcase grid)
   - "hero_title" (Cinematic chapter title reveal)
   - "image_showcase" (Gallery image / textbook page frame)
   - "outro_cta" (Audience question comment box + social follow cards)
""".trimIndent()

    fun buildCopyPasteGeminiPrompt(
        topicOrScript: String,
        aspectRatio: String,
        lookId: String,
        languageMode: String,
        durationPreset: String,
        srtRaw: String = ""
    ): String {
        val srtSection = if (srtRaw.isNotBlank()) {
            "\nVoiceover SRT Timestamps (sync scenes and `srtCues` 100% to these timestamps):\n$srtRaw\n"
        } else {
            "\nTarget Duration: $durationPreset\n"
        }

        return """
$GEMINI_SKILL_SYSTEM_PROMPT_V5

User Request:
- Topic / Script: $topicOrScript
- Aspect Ratio: $aspectRatio
- Look ID: $lookId
- Language: $languageMode
$srtSection

Return a single JSON object with keys:
{
  "specVersion": "ProMotion JSON Spec v5",
  "id": "proj_custom",
  "title": "...",
  "aspectRatio": "$aspectRatio",
  "lookId": "$lookId",
  "languageMode": "$languageMode",
  "subtitleEnabled": true,
  "subtitleStyle": "Pill",
  "scenes": [
    {
      "id": "s1",
      "chapterNum": 1,
      "chapterBadge": "অধ্যায় ১",
      "heading": "... [হাইলাইট] ...",
      "subtext": "... [হাইলাইট] ...",
      "durationSec": 5.5,
      "template": "split_card",
      "waveformVariant": "square_wave",
      "calloutLabels": ["লেবেল ১", "লেবেল ২", "লেবেল ৩"],
      "statusPills": ["✓ পয়েন্ট ১", "✕ পয়েন্ট ২"],
      "counterTarget": 95,
      "counterSuffix": "%",
      "stickerBadge": "PRO",
      "stickerEmoji": "🔬"
    }
  ],
  "srtCues": [
    { "index": 1, "startSec": 0.0, "endSec": 5.5, "text": "..." }
  ]
}
""".trimIndent()
    }

    fun buildSrtTranscriptionPrompt(): String {
        return """
নিচের অডিও বা ভয়েস ফাইলটি মনোযোগ দিয়ে শুনে একদম নিখুঁত টাইমস্ট্যাম্পসহ স্ট্যান্ডার্ড `.srt` সাবটাইটেল ফরমেটে লিখে দাও।
প্রতিটি লাইনের মূল শব্দের দুই পাশে `[ ]` ব্র্যাকেট দাও যাতে ভিডিওতে সেই শব্দগুলো অটোমেটিক হাইলাইট হয়।
উদাহরণ:
1
00:00:00,000 --> 00:00:04,500
ডিজিটাল সিগন্যালের মাত্র [দুটি অবস্থা] থাকে — HIGH এবং LOW।
""".trimIndent()
    }

    fun copyToClipboard(context: Context, label: String, text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        clipboard?.setPrimaryClip(ClipData.newPlainText(label, text))
    }

    fun readFromClipboard(context: Context): String {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        val item = clipboard?.primaryClip?.getItemAt(0)
        return item?.text?.toString().orEmpty()
    }

    fun openExternalGeminiApp(context: Context) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://gemini.google.com/app")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {}
    }

    private val projectSchema by lazy {
        val sceneSchema = Schema.obj(
            properties = mapOf(
                "id" to Schema.string(),
                "chapterNum" to Schema.integer(),
                "chapterBadge" to Schema.string(),
                "heading" to Schema.string(),
                "subtext" to Schema.string(),
                "durationSec" to Schema.double(),
                "template" to Schema.enumeration(
                    listOf(
                        "split_card", "waveform_lab", "logic_level_band", "cutaway_xray",
                        "magnifier_loupe", "comparison_cards", "progress_bars_counter",
                        "stat_dashboard", "device_grid", "hero_title", "image_showcase", "outro_cta"
                    )
                ),
                "waveformVariant" to Schema.enumeration(
                    listOf(
                        "square_wave", "pos_rect_wave", "neg_rect_wave",
                        "digitized_staircase", "sine_vs_noise", "non_ideal_pulse"
                    )
                ),
                "calloutLabels" to Schema.array(Schema.string()),
                "statusPills" to Schema.array(Schema.string()),
                "counterTarget" to Schema.integer(),
                "counterSuffix" to Schema.string(),
                "stickerBadge" to Schema.string(),
                "stickerEmoji" to Schema.string()
            )
        )
        val cueSchema = Schema.obj(
            properties = mapOf(
                "index" to Schema.integer(),
                "startSec" to Schema.double(),
                "endSec" to Schema.double(),
                "text" to Schema.string()
            )
        )
        Schema.obj(
            properties = mapOf(
                "id" to Schema.string(),
                "title" to Schema.string(),
                "aspectRatio" to Schema.string(),
                "lookId" to Schema.string(),
                "languageMode" to Schema.string(),
                "subtitleStyle" to Schema.string(),
                "scenes" to Schema.array(sceneSchema),
                "srtCues" to Schema.array(cueSchema)
            )
        )
    }

    private val structuredModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = projectSchema
            }
        )
    }

    private val textModel by lazy {
        Firebase.ai.generativeModel("gemini-3.8-flash")
    }

    suspend fun generateProjectViaFirebaseAi(
        topicOrScript: String,
        aspectRatio: String,
        lookId: String,
        languageMode: String,
        durationPreset: String,
        srtRaw: String = ""
    ): Result<ProMotionProject> {
        return try {
            val prompt = buildCopyPasteGeminiPrompt(
                topicOrScript = topicOrScript,
                aspectRatio = aspectRatio,
                lookId = lookId,
                languageMode = languageMode,
                durationPreset = durationPreset,
                srtRaw = srtRaw
            )
            val response = withTimeout(60_000L) {
                structuredModel.generateContent(prompt)
            }
            val jsonText = response.text
                ?: return Result.failure(IllegalStateException("Gemini returned an empty response."))
            ProMotionJsonCodec.parseAndFixProjectJson(jsonText)
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "AI generation timed out", e)
            Result.failure(IllegalStateException("AI জেনারেশন ৬০ সেকেন্ডের বেশি সময় নিয়েছে। আবার চেষ্টা করুন।"))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Firebase AI generation failed", e)
            Result.failure(e)
        }
    }

    suspend fun generateSrtForTopicViaFirebaseAi(topicOrScript: String): Result<String> {
        return try {
            val prompt = """
${buildSrtTranscriptionPrompt()}

বিষয় বা স্ক্রিপ্ট:
$topicOrScript
""".trimIndent()
            val response = withTimeout(60_000L) {
                textModel.generateContent(prompt)
            }
            val text = response.text?.trim().orEmpty()
            if (text.isNotBlank()) {
                Result.success(text)
            } else {
                Result.failure(IllegalStateException("Empty SRT response from Gemini."))
            }
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "SRT generation timed out", e)
            Result.failure(IllegalStateException("SRT তৈরি করতে সময় বেশি লেগেছে। আবার চেষ্টা করুন।"))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "SRT generation failed", e)
            Result.failure(e)
        }
    }

    suspend fun translateProjectViaFirebaseAi(
        project: ProMotionProject,
        targetLanguage: String
    ): Result<ProMotionProject> {
        return try {
            val currentJson = ProMotionJsonCodec.toJsonString(project, pretty = false)
            val prompt = """
Translate all user-facing text fields (`title`, `chapterBadge`, `heading`, `subtext`, `calloutLabels`, `statusPills`, and `srtCues.text`) in the following ProMotionProject JSON into $targetLanguage.
Keep `[brackets]` around highlighted keywords intact! Keep all IDs, numbers, and template names unchanged.
Input JSON:
$currentJson
""".trimIndent()
            val response = withTimeout(60_000L) {
                structuredModel.generateContent(prompt)
            }
            val jsonText = response.text
                ?: return Result.failure(IllegalStateException("Empty translation response."))
            ProMotionJsonCodec.parseAndFixProjectJson(jsonText)
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Translation timed out", e)
            Result.failure(IllegalStateException("অনুবাদ করতে সময় বেশি লেগেছে। আবার চেষ্টা করুন।"))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Translation failed", e)
            Result.failure(e)
        }
    }

    fun buildRemotionTranspilePrompt(inspectResult: RemotionZipInspectResult): String {
        val ratio = inspectResult.detectedAspectRatio
        val durSec = inspectResult.instantConvertedProject.totalDurationSec
        return """
$GEMINI_SKILL_SYSTEM_PROMPT_V5

You are converting an uploaded Remotion (.zip) React/TypeScript video project into a native 30 FPS ProMotionProjectJSON v5 so it can be encoded directly to an .mp4 video on Android.
Uploaded Zip File: ${inspectResult.zipFileName}
Detected Composition(s): ${inspectResult.compositionIds.joinToString(", ")}
Resolution: ${inspectResult.detectedWidth}x${inspectResult.detectedHeight} ($ratio), FPS: ${inspectResult.detectedFps}, Total Frames: ${inspectResult.detectedDurationInFrames} (${String.format("%.1f", durSec)}s)

Extracted Remotion Source Code (.tsx / .ts / .json):
${inspectResult.extractedSourceSummary.take(10_000)}

Convert every Remotion <Composition> and <Sequence> into rich ProMotion scenes with exact durations, headings with [highlighted] keywords, subtext, calloutLabels, and appropriate templates (waveform_lab, logic_level_band, cutaway_xray, split_card, stat_dashboard, comparison_cards, progress_bars_counter, hero_title, image_showcase, outro_cta).
Return ONLY valid JSON matching ProMotionProjectJSON v5.
""".trimIndent()
    }

    suspend fun transpileRemotionSourceViaFirebaseAi(
        inspectResult: RemotionZipInspectResult
    ): Result<ProMotionProject> {
        return try {
            val prompt = buildRemotionTranspilePrompt(inspectResult)
            val response = withTimeout(60_000L) {
                structuredModel.generateContent(prompt)
            }
            val jsonText = response.text
                ?: return Result.failure(IllegalStateException("Empty AI response for Remotion transpilation."))
            ProMotionJsonCodec.parseAndFixProjectJson(jsonText)
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Remotion AI transpilation timed out", e)
            Result.failure(IllegalStateException("Remotion কোড কনভার্ট করতে সময় বেশি লেগেছে। ইনস্ট্যান্ট কনভার্টার ব্যবহার করুন।"))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Remotion AI transpilation failed", e)
            Result.failure(e)
        }
    }
}

