const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user: cannot read or create projects", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("projects").get());
});

test("Authenticated user: can create, read, update, and list own project", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const docRef = aliceDb.collection("users").doc(ALICE_UID).collection("projects").doc("proj_1");
  const now = new Date();
  await assertSucceeds(
    docRef.set({
      userId: ALICE_UID,
      title: "Digital Electronics Explainer",
      aspectRatio: "16:9",
      lookId: "deep_ocean",
      projectJson: "{\"version\":5}",
      durationSec: 32,
      createdAt: now,
      updatedAt: now,
    })
  );
  await assertSucceeds(docRef.get());
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("projects").where("userId", "==", ALICE_UID).get()
  );
  await assertSucceeds(
    docRef.update({
      title: "Updated Title",
      updatedAt: new Date(),
    })
  );
});

test("Cross-user isolation: Bob cannot read or modify Alice's project", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    const now = new Date();
    await context.firestore().collection("users").doc(ALICE_UID).collection("projects").doc("proj_alice").set({
      userId: ALICE_UID,
      title: "Alice Video",
      aspectRatio: "16:9",
      lookId: "deep_ocean",
      projectJson: "{\"version\":5}",
      durationSec: 25,
      createdAt: now,
      updatedAt: now,
    });
  });

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("projects").doc("proj_alice").get()
  );
});

test("Shadow update with ghost field fails", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const docRef = aliceDb.collection("users").doc(ALICE_UID).collection("projects").doc("proj_ghost");
  const now = new Date();
  await assertFails(
    docRef.set({
      userId: ALICE_UID,
      title: "Video",
      aspectRatio: "16:9",
      lookId: "deep_ocean",
      projectJson: "{}",
      durationSec: 15,
      isVerified: true,
      createdAt: now,
      updatedAt: now,
    })
  );
});
