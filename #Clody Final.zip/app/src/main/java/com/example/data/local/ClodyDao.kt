package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ClodyDao {

    // Folders
    @Query("SELECT * FROM folders WHERE parentId IS :parentId ORDER BY name ASC")
    fun observeFolders(parentId: Long?): Flow<List<FolderEntity>>

    @Query("SELECT * FROM folders ORDER BY name ASC")
    fun observeAllFolders(): Flow<List<FolderEntity>>

    @Query("SELECT * FROM folders ORDER BY id ASC")
    suspend fun getAllFoldersOnce(): List<FolderEntity>

    @Query("SELECT * FROM folders WHERE id = :id LIMIT 1")
    suspend fun getFolderById(id: Long): FolderEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFolder(folder: FolderEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFolders(folders: List<FolderEntity>)

    @Update
    suspend fun updateFolder(folder: FolderEntity)

    @Query("SELECT * FROM folders WHERE parentId IS :parentId ORDER BY name ASC")
    suspend fun getSubfoldersOnce(parentId: Long?): List<FolderEntity>

    @Query("UPDATE folders SET parentId = :newParentId WHERE id = :folderId")
    suspend fun moveFolderToParent(folderId: Long, newParentId: Long?)

    @Query("DELETE FROM folders WHERE id = :folderId")
    suspend fun deleteFolder(folderId: Long)

    @Query("DELETE FROM folders WHERE id IN (:folderIds)")
    suspend fun deleteFoldersByIds(folderIds: List<Long>)

    // Files (standard queries exclude Locked Vault items where isLockedVault = 1)
    @Query("SELECT * FROM files WHERE isDeleted = 0 AND isLockedVault = 0 ORDER BY createdAt DESC")
    fun observeActiveFiles(): Flow<List<FileEntity>>

    @Query("SELECT * FROM files WHERE isDeleted = 0 AND isLockedVault = 0 AND (mimeType LIKE 'image/%' OR mimeType LIKE 'video/%') ORDER BY createdAt DESC")
    fun observeGalleryMedia(): Flow<List<FileEntity>>

    @Query("SELECT * FROM files WHERE isDeleted = 0 AND isLockedVault = 0 AND folderId IS :folderId ORDER BY createdAt DESC")
    fun observeFilesInFolder(folderId: Long?): Flow<List<FileEntity>>

    /**
     * File Manager directory tree query: isolates root items uploaded via File Manager or explicitly
     * placed/moved into folders so Gallery timeline uploads (folderPath = 'Gallery') never clutter Root.
     */
    @Query(
        """
        SELECT * FROM files
        WHERE isDeleted = 0 AND isLockedVault = 0
          AND folderId IS :folderId
          AND (:folderId IS NOT NULL OR folderPath != 'Gallery')
        ORDER BY createdAt DESC
        """
    )
    fun observeFileManagerFilesInFolder(folderId: Long?): Flow<List<FileEntity>>

    @Query("SELECT * FROM files WHERE isDeleted = 0 AND isLockedVault = 0 AND folderId IS :folderId ORDER BY createdAt DESC")
    suspend fun getFilesInFolderOnce(folderId: Long?): List<FileEntity>

    @Query("SELECT * FROM files WHERE isDeleted = 0 AND isLockedVault = 1 ORDER BY createdAt DESC")
    fun observeLockedVaultFiles(): Flow<List<FileEntity>>

    @Query("SELECT * FROM files WHERE isDeleted = 0 AND isPinnedOffline = 1 ORDER BY createdAt DESC")
    fun observePinnedOfflineFiles(): Flow<List<FileEntity>>

    @Query("SELECT * FROM files WHERE isDeleted = 1 ORDER BY deletedAt DESC")
    fun observeDeletedFiles(): Flow<List<FileEntity>>

    @Query("SELECT * FROM files WHERE isDeleted = 0 AND isLockedVault = 0 AND sizeBytes >= :minBytes ORDER BY sizeBytes DESC")
    fun observeLargeFiles(minBytes: Long = 50L * 1024L * 1024L): Flow<List<FileEntity>>

    @Query("SELECT * FROM files WHERE isDeleted = 0 ORDER BY id ASC")
    suspend fun getAllActiveFilesOnce(): List<FileEntity>

    @Query("SELECT * FROM files ORDER BY id ASC")
    suspend fun getAllFilesOnceIncludingTrash(): List<FileEntity>

    @Query("SELECT * FROM files WHERE id = :id LIMIT 1")
    suspend fun getFileById(id: Long): FileEntity?

    @Query("SELECT * FROM files WHERE telegramMessageId = :messageId LIMIT 1")
    suspend fun getFileByMessageId(messageId: Int): FileEntity?

    @Query(
        """
        SELECT * FROM files
        WHERE (telegramAccessHash != 0 AND telegramAccessHash = :accessHash)
           OR (telegramMessageId != 0 AND telegramMessageId = :messageId)
        LIMIT 1
        """
    )
    suspend fun getFileByTelegramDocOrMsg(messageId: Int, accessHash: Long): FileEntity?

    @Query(
        """
        SELECT * FROM files
        WHERE isDeleted = 0 AND sha256 = :sha256 AND sha256 != '' AND telegramDocumentId != 0
        LIMIT 1
        """
    )
    suspend fun findActiveFileBySha256(sha256: String): FileEntity?

    @Query(
        """
        SELECT files.* FROM files
        JOIN files_fts ON files.id = files_fts.rowid
        WHERE files.isDeleted = 0 AND files.isLockedVault = 0 AND files_fts MATCH :ftsQuery
        ORDER BY files.createdAt DESC
        """
    )
    fun searchFilesFts(ftsQuery: String): Flow<List<FileEntity>>

    @Query(
        """
        SELECT * FROM files
        WHERE isDeleted = 0 AND isLockedVault = 0 AND (name LIKE '%' || :query || '%' OR extension LIKE '%' || :query || '%' OR folderPath LIKE '%' || :query || '%')
        ORDER BY createdAt DESC
        """
    )
    fun searchFilesLike(query: String): Flow<List<FileEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFile(file: FileEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFiles(files: List<FileEntity>)

    @Update
    suspend fun updateFile(file: FileEntity)

    @Query("UPDATE files SET isFavorite = :favorite WHERE id = :fileId")
    suspend fun setFileFavorite(fileId: Long, favorite: Boolean)

    @Query("UPDATE files SET isLockedVault = :locked WHERE id = :fileId")
    suspend fun setFileLockedVault(fileId: Long, locked: Boolean)

    @Query("UPDATE files SET isPinnedOffline = :pinned, pinnedOfflinePath = :pinnedPath WHERE id = :fileId")
    suspend fun setFilePinnedOffline(fileId: Long, pinned: Boolean, pinnedPath: String?)

    @Query("UPDATE files SET thumbnailPath = :thumbPath WHERE id = :fileId")
    suspend fun updateFileThumbnailPath(fileId: Long, thumbPath: String?)

    @Query("UPDATE files SET customThumbnailPath = :thumbPath WHERE id = :fileId")
    suspend fun updateCustomThumbnail(fileId: Long, thumbPath: String?)

    @Query("UPDATE files SET localCachePath = :cachePath WHERE id = :fileId")
    suspend fun updateLocalCachePath(fileId: Long, cachePath: String?)

    @Query("UPDATE files SET localCachePath = NULL WHERE isPinnedOffline = 0")
    suspend fun clearAllLocalCachePaths()

    @Query("UPDATE files SET createdAt = :createdAt WHERE id = :fileId")
    suspend fun updateFileCreatedAt(fileId: Long, createdAt: Long)

    @Query("UPDATE files SET folderId = :folderId, folderPath = :folderPath WHERE id IN (:fileIds)")
    suspend fun moveFilesToFolder(fileIds: List<Long>, folderId: Long?, folderPath: String)

    @Query("UPDATE files SET isDeleted = 1, deletedAt = :deletedAt WHERE id = :fileId")
    suspend fun softDeleteFile(fileId: Long, deletedAt: Long = System.currentTimeMillis())

    @Query("UPDATE files SET isDeleted = 1, deletedAt = :deletedAt, folderId = NULL WHERE id IN (:fileIds)")
    suspend fun softDeleteFiles(fileIds: List<Long>, deletedAt: Long = System.currentTimeMillis())

    @Query("UPDATE files SET isDeleted = 0, deletedAt = NULL WHERE id = :fileId")
    suspend fun restoreFile(fileId: Long)

    @Query("DELETE FROM files WHERE id = :fileId")
    suspend fun permanentlyDeleteFile(fileId: Long)

    @Query("DELETE FROM files WHERE id IN (:fileIds)")
    suspend fun permanentlyDeleteFiles(fileIds: List<Long>)

    @Query("DELETE FROM files WHERE isDeleted = 1 AND deletedAt < :cutoffMs")
    suspend fun purgeExpiredRecycleBin(cutoffMs: Long)

    @Query("SELECT COALESCE(SUM(sizeBytes), 0) FROM files WHERE isDeleted = 0")
    fun observeTotalCloudBytes(): Flow<Long>

    @Query("DELETE FROM files")
    suspend fun clearAllFiles()

    @Query("DELETE FROM folders")
    suspend fun clearAllFolders()

    @Query("INSERT INTO files_fts(files_fts) VALUES('optimize')")
    suspend fun optimizeFtsIndex()

    @Query("INSERT INTO files_fts(files_fts) VALUES('rebuild')")
    suspend fun rebuildFtsIndex()

    // Gallery Albums (strictly separate from File Folders)
    @Query("SELECT * FROM gallery_albums ORDER BY createdAt DESC")
    fun observeGalleryAlbums(): Flow<List<GalleryAlbumEntity>>

    @Query("SELECT * FROM gallery_albums ORDER BY id ASC")
    suspend fun getAllAlbumsOnce(): List<GalleryAlbumEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlbum(album: GalleryAlbumEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlbums(albums: List<GalleryAlbumEntity>)

    @Query("DELETE FROM gallery_albums WHERE id = :albumId")
    suspend fun deleteAlbum(albumId: Long)

    @Query("UPDATE files SET albumId = :albumId WHERE id = :fileId")
    suspend fun setFileAlbum(fileId: Long, albumId: Long?)

    @Query("UPDATE files SET albumId = NULL WHERE albumId = :albumId")
    suspend fun clearAlbumFromFiles(albumId: Long)

    @Query("DELETE FROM gallery_albums")
    suspend fun clearAllAlbums()

    @Query("SELECT * FROM files WHERE isDeleted = 0 AND isLockedVault = 0 AND isFavorite = 1 AND (mimeType LIKE 'image/%' OR mimeType LIKE 'video/%') ORDER BY createdAt DESC")
    fun observeFavoriteGalleryMedia(): Flow<List<FileEntity>>

    @Query("SELECT * FROM files WHERE isDeleted = 1 AND (mimeType LIKE 'image/%' OR mimeType LIKE 'video/%') ORDER BY deletedAt DESC")
    fun observeDeletedGalleryMedia(): Flow<List<FileEntity>>

    @Query("DELETE FROM files WHERE isDeleted = 1 AND (mimeType LIKE 'image/%' OR mimeType LIKE 'video/%')")
    suspend fun emptyGalleryTrash()

    @Query("SELECT * FROM files WHERE isDeleted = 0 AND isLockedVault = 0 AND albumId = :albumId AND (mimeType LIKE 'image/%' OR mimeType LIKE 'video/%') ORDER BY createdAt DESC")
    fun observeFilesInAlbum(albumId: Long): Flow<List<FileEntity>>

    // Upload Queue
    @Query("SELECT * FROM upload_tasks ORDER BY createdAt DESC")
    fun observeUploadTasks(): Flow<List<UploadTaskEntity>>

    @Query("SELECT * FROM upload_tasks WHERE status != 'CANCELLED' ORDER BY createdAt DESC")
    fun observeActiveUploadTasks(): Flow<List<UploadTaskEntity>>

    @Query("SELECT * FROM upload_tasks WHERE status IN ('QUEUED', 'UPLOADING') ORDER BY createdAt ASC LIMIT 1")
    suspend fun getNextPendingUpload(): UploadTaskEntity?

    @Query("SELECT * FROM upload_tasks WHERE status = 'QUEUED' ORDER BY createdAt ASC LIMIT :limit")
    suspend fun getPendingQueuedUploads(limit: Int = 3): List<UploadTaskEntity>

    @Query("SELECT COUNT(*) FROM upload_tasks WHERE status IN ('QUEUED', 'UPLOADING')")
    suspend fun countActiveUploads(): Int

    @Query("SELECT * FROM upload_tasks WHERE id = :id LIMIT 1")
    suspend fun getUploadTaskById(id: Long): UploadTaskEntity?

    @Query("SELECT * FROM upload_tasks WHERE fileName = :fileName AND sizeBytes = :sizeBytes ORDER BY createdAt DESC LIMIT 1")
    suspend fun getLatestUploadTaskByNameAndSize(fileName: String, sizeBytes: Long): UploadTaskEntity?

    @Query("SELECT * FROM upload_tasks WHERE fileName = :fileName ORDER BY createdAt DESC LIMIT 1")
    suspend fun getLatestUploadTaskByName(fileName: String): UploadTaskEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUploadTask(task: UploadTaskEntity): Long

    @Update
    suspend fun updateUploadTask(task: UploadTaskEntity)

    @Query("UPDATE upload_tasks SET status = :status, errorMessage = :error, pausedBySystem = 0 WHERE id = :taskId")
    suspend fun updateUploadStatus(taskId: Long, status: String, error: String? = null)

    @Query("UPDATE upload_tasks SET status = 'PAUSED', pausedBySystem = 0, speedBytesPerSec = 0, errorMessage = NULL WHERE id = :taskId")
    suspend fun pauseUploadByUser(taskId: Long)

    @Query("UPDATE upload_tasks SET status = 'PAUSED', pausedBySystem = 1, speedBytesPerSec = 0, errorMessage = :reason WHERE status = 'UPLOADING'")
    suspend fun pauseAllUploadingTasks(reason: String? = "Waiting for Wi-Fi")

    @Query("UPDATE upload_tasks SET status = 'PAUSED', pausedBySystem = 1, speedBytesPerSec = 0, errorMessage = :reason WHERE status IN ('UPLOADING', 'QUEUED')")
    suspend fun markActiveUploadsSystemPaused(reason: String? = "Paused on close")

    @Query("UPDATE upload_tasks SET status = 'QUEUED', pausedBySystem = 0, errorMessage = NULL WHERE (status = 'PAUSED' AND pausedBySystem = 1) OR status = 'UPLOADING'")
    suspend fun resumeAllPausedTasks(): Int

    @Query("UPDATE upload_tasks SET status = 'QUEUED', pausedBySystem = 0, errorMessage = NULL WHERE (status = 'PAUSED' AND pausedBySystem = 1) OR status = 'UPLOADING'")
    suspend fun resumeSystemPausedUploads(): Int

    @Query("SELECT * FROM upload_tasks WHERE status IN ('UPLOADING', 'QUEUED') OR (status = 'PAUSED' AND pausedBySystem = 1)")
    suspend fun getResumableOrActiveUploads(): List<UploadTaskEntity>

    @Query("UPDATE upload_tasks SET tdFileId = :tdFileId WHERE id = :taskId")
    suspend fun updateUploadTdFileId(taskId: Long, tdFileId: Int)

    @Query("UPDATE upload_tasks SET stagedFilePath = :path WHERE id = :taskId")
    suspend fun updateUploadStagedPath(taskId: Long, path: String?)

    @Query("UPDATE upload_tasks SET bytesUploaded = :bytes, speedBytesPerSec = :speed WHERE id = :taskId")
    suspend fun updateUploadProgress(taskId: Long, bytes: Long, speed: Long)

    @Query("DELETE FROM upload_tasks WHERE id = :taskId")
    suspend fun deleteUploadTaskById(taskId: Long)

    @Query("DELETE FROM upload_tasks WHERE status IN ('COMPLETED', 'CANCELLED')")
    suspend fun clearFinishedUploads()

    // Download Records
    @Query("SELECT * FROM download_records ORDER BY createdAt DESC")
    fun observeDownloadRecords(): Flow<List<DownloadRecordEntity>>

    @Query("SELECT * FROM download_records WHERE status IN ('DOWNLOADING', 'COMPLETED') ORDER BY createdAt DESC")
    fun observeActiveDownloadRecords(): Flow<List<DownloadRecordEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDownloadRecord(record: DownloadRecordEntity): Long

    @Update
    suspend fun updateDownloadRecord(record: DownloadRecordEntity)

    @Query("DELETE FROM download_records WHERE id = :recordId")
    suspend fun deleteDownloadRecordById(recordId: Long)

    @Query("DELETE FROM download_records WHERE status != 'DOWNLOADING'")
    suspend fun clearCompletedDownloads()
}
