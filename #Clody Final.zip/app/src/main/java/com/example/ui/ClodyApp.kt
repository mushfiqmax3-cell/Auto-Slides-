package com.example.ui

import android.Manifest
import android.app.DownloadManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.PlaybackNotificationNavigation
import com.example.data.local.FileEntity
import com.example.data.local.FolderEntity
import com.example.data.local.ThemeMode
import com.example.media.ClodyAudioPlayerScreen
import com.example.media.DocumentReaderScreen
import com.example.media.ImageViewerScreen
import com.example.media.YouTubeVideoPlayerScreen
import com.example.service.ClodyPlaybackController
import com.example.service.UploadCandidate
import com.example.ui.theme.ClodyMotion
import com.example.ui.theme.ClodyTheme

private sealed interface PendingFolderAction {
    data class MoveItems(val files: List<FileEntity>, val folders: List<FolderEntity>) : PendingFolderAction
    data class CopyFile(val file: FileEntity) : PendingFolderAction
}

@Composable
fun ClodyApp(
    viewModel: ClodyViewModel = viewModel(),
    notificationNavigation: PlaybackNotificationNavigation? = null,
    onConsumeNotificationNavigation: () -> Unit = {}
) {
    val context = LocalContext.current
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val connectionState by viewModel.connectionState.collectAsStateWithLifecycle()
    val authStep by viewModel.authStep.collectAsStateWithLifecycle()
    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
    val galleryMedia by viewModel.galleryMedia.collectAsStateWithLifecycle()
    val galleryAlbums by viewModel.galleryAlbums.collectAsStateWithLifecycle()
    val favoriteGalleryMedia by viewModel.favoriteGalleryMedia.collectAsStateWithLifecycle()
    val deletedGalleryMedia by viewModel.deletedGalleryMedia.collectAsStateWithLifecycle()
    val detectedLocalMedia by viewModel.detectedLocalMedia.collectAsStateWithLifecycle()
    val breadcrumbs by viewModel.breadcrumbs.collectAsStateWithLifecycle()
    val allFolders by viewModel.allFolders.collectAsStateWithLifecycle()
    val folderItemCounts by viewModel.folderItemCounts.collectAsStateWithLifecycle()
    val currentSubfolders by viewModel.currentSubfolders.collectAsStateWithLifecycle()
    val currentFolderFiles by viewModel.currentFolderFiles.collectAsStateWithLifecycle()
    val allActiveFiles by viewModel.allActiveFiles.collectAsStateWithLifecycle()
    val deletedFiles by viewModel.deletedFiles.collectAsStateWithLifecycle()
    val largeCloudFiles by viewModel.largeCloudFiles.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val searchCategory by viewModel.searchCategory.collectAsStateWithLifecycle()
    val searchResults by viewModel.searchResults.collectAsStateWithLifecycle()
    val deviceStorage by viewModel.deviceStorage.collectAsStateWithLifecycle()
    val totalCloudBytes by viewModel.totalCloudBytes.collectAsStateWithLifecycle()
    val streamCacheBytes by viewModel.streamCacheBytes.collectAsStateWithLifecycle()
    val localDirectoryItems by viewModel.localDirectoryItems.collectAsStateWithLifecycle()
    val currentLocalDir by viewModel.currentLocalDir.collectAsStateWithLifecycle()
    val largeLocalFiles by viewModel.largeLocalFiles.collectAsStateWithLifecycle()
    val installedApps by viewModel.installedApps.collectAsStateWithLifecycle()
    val duplicateGroups by viewModel.duplicateGroups.collectAsStateWithLifecycle()
    val uploadPreviewCandidates by viewModel.uploadPreviewCandidates.collectAsStateWithLifecycle()
    val showConnectSheet by viewModel.showConnectSheet.collectAsStateWithLifecycle()
    val authBusy by viewModel.authBusy.collectAsStateWithLifecycle()
    val authBusyLabel by viewModel.authBusyLabel.collectAsStateWithLifecycle()
    val authError by viewModel.authError.collectAsStateWithLifecycle()
    val snackbarMessage by viewModel.snackbarMessage.collectAsStateWithLifecycle()
    val activeVideoFile by viewModel.activeVideoFile.collectAsStateWithLifecycle()
    val activeImageFile by viewModel.activeImageFile.collectAsStateWithLifecycle()
    val activeAudioFile by viewModel.activeAudioFile.collectAsStateWithLifecycle()
    val activeDocumentFile by viewModel.activeDocumentFile.collectAsStateWithLifecycle()
    val binaryDownloadBanner by viewModel.binaryDownloadBanner.collectAsStateWithLifecycle()
    val completedAuthUploadIntent by viewModel.completedAuthUploadIntent.collectAsStateWithLifecycle()
    val shareCacheProgress by viewModel.shareCacheProgress.collectAsStateWithLifecycle()

    var selectedTab by remember { mutableStateOf(ClodyTab.GALLERY) }
    var showGalleryOrganizationHub by remember { mutableStateOf(false) }
    var actionMenuTarget by remember { mutableStateOf<FileEntity?>(null) }
    var albumAssignmentTarget by remember { mutableStateOf<FileEntity?>(null) }
    var pendingFolderAction by remember { mutableStateOf<PendingFolderAction?>(null) }
    var candidateAwaitingCustomThumb by remember { mutableStateOf<UploadCandidate?>(null) }
    var uploadedVideoAwaitingThumb by remember { mutableStateOf<FileEntity?>(null) }
    var showMediaPermissionRationale by remember { mutableStateOf(false) }
    var showAllFilesRationale by remember { mutableStateOf(false) }
    var showUploadSourceChoice by remember { mutableStateOf(false) }
    var pendingCompressUris by remember { mutableStateOf<List<Uri>>(emptyList()) }

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(snackbarMessage) {
        snackbarMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    LaunchedEffect(notificationNavigation) {
        val nav = notificationNavigation ?: return@LaunchedEffect
        viewModel.openPlayerFromNotification(nav.fileId, nav.isVideo)
        onConsumeNotificationNavigation()
    }

    val serviceActiveFile by ClodyPlaybackController.activeFile.collectAsStateWithLifecycle()
    val serviceActiveIsVideo by ClodyPlaybackController.activeIsVideo.collectAsStateWithLifecycle()
    LaunchedEffect(serviceActiveFile, serviceActiveIsVideo) {
        val sf = serviceActiveFile ?: return@LaunchedEffect
        if (serviceActiveIsVideo && activeVideoFile != null && activeVideoFile?.id != sf.id) {
            viewModel.openVideoPlayer(sf)
        } else if (!serviceActiveIsVideo && activeAudioFile != null && activeAudioFile?.id != sf.id) {
            viewModel.openAudioPlayer(sf)
        }
    }

    // Permission checks
    fun checkMediaPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        }
    }

    fun checkNotificationPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        } else true
    }

    var hasMediaPermission by remember { mutableStateOf(checkMediaPermission()) }
    var hasNotificationPermission by remember { mutableStateOf(checkNotificationPermission()) }

    LaunchedEffect(hasMediaPermission) {
        if (hasMediaPermission) {
            viewModel.refreshLocalMediaScan()
        }
    }

    // Launchers
    val mediaPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        hasMediaPermission = grants.values.all { it }
        if (hasMediaPermission) {
            viewModel.refreshLocalMediaScan()
        } else {
            viewModel.showMessage("Media permission denied — you can still use Photo Picker to upload")
        }
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasNotificationPermission = granted
    }

    val photoPickerMultiLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(maxItems = 25)
    ) { uris ->
        if (uris.isNotEmpty()) {
            viewModel.prepareUploadFromUris(uris)
        }
    }

    val anyFilePickerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) {
            viewModel.prepareUploadFromUris(uris)
        }
    }

    val customThumbForCandidateLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        val target = candidateAwaitingCustomThumb
        candidateAwaitingCustomThumb = null
        if (uri != null && target != null) {
            viewModel.setCustomThumbnailForCandidate(target.uri, uri)
        }
    }

    val changeThumbForUploadedLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        val target = uploadedVideoAwaitingThumb
        uploadedVideoAwaitingThumb = null
        if (uri != null && target != null) {
            viewModel.changeThumbnailForUploadedVideo(target.id, uri)
        }
    }

    val compressPickerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) pendingCompressUris = uris
    }

    val extractPickerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) viewModel.extractArchive(uri)
    }

    val safFolderSyncLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) viewModel.addSyncedFolder(uri)
    }

    LaunchedEffect(completedAuthUploadIntent) {
        when (completedAuthUploadIntent) {
            PendingUploadIntent.GALLERY_MEDIA -> {
                viewModel.consumeCompletedAuthUploadIntent()
                viewModel.setNextUploadOriginGallery(true)
                photoPickerMultiLauncher.launch(
                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)
                )
            }
            PendingUploadIntent.FOLDERS_CHOOSER -> {
                viewModel.consumeCompletedAuthUploadIntent()
                viewModel.setNextUploadOriginGallery(false)
                showUploadSourceChoice = true
            }
            else -> Unit
        }
    }

    fun launchGalleryUploadWithAuthGate() {
        viewModel.setNextUploadOriginGallery(true)
        viewModel.requireAuthForUpload(PendingUploadIntent.GALLERY_MEDIA) {
            photoPickerMultiLauncher.launch(
                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)
            )
        }
    }

    fun launchFoldersChooserWithAuthGate() {
        viewModel.setNextUploadOriginGallery(false)
        viewModel.requireAuthForUpload(PendingUploadIntent.FOLDERS_CHOOSER) {
            showUploadSourceChoice = true
        }
    }

    fun launchMediaPermissionRequest() {
        val perms = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_AUDIO
            )
        } else {
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        mediaPermissionLauncher.launch(perms)
    }

    fun launchAllFilesAccessSettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                data = Uri.parse("package:${context.packageName}")
            }
            runCatching { context.startActivity(intent) }
        }
    }

    val isDark = when (settings.themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }

    ClodyTheme(
        darkTheme = isDark,
        dynamicColor = settings.dynamicColors
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                snackbarHost = {
                    SnackbarHost(
                        hostState = snackbarHostState,
                        modifier = Modifier.padding(bottom = 90.dp)
                    )
                }
            ) { _ ->
                Box(modifier = Modifier.fillMaxSize()) {
                    AnimatedContent(
                        targetState = selectedTab,
                        transitionSpec = { ClodyMotion.gpuScreenTransition() },
                        label = "tab_gpu_transition"
                    ) { tab ->
                        when (tab) {
                            ClodyTab.GALLERY -> GalleryScreen(
                                mediaFiles = galleryMedia,
                                detectedLocalMedia = detectedLocalMedia,
                                hasMediaPermission = hasMediaPermission,
                                connectionState = connectionState,
                                batchSummaryFlow = viewModel.transferBatchSummary,
                                telegramClient = viewModel.telegramClient,
                                onRequestMediaPermission = { showMediaPermissionRationale = true },
                                onOpenUploadPicker = { launchGalleryUploadWithAuthGate() },
                                onOpenOrganizationHub = { showGalleryOrganizationHub = true },
                                onOpenTransfers = { selectedTab = ClodyTab.TRANSFERS },
                                onUploadDetectedLocal = {
                                    if (!hasNotificationPermission && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                        notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                    }
                                    viewModel.uploadDetectedLocalMedia()
                                },
                                onDismissDetectedLocal = { viewModel.dismissLocalBackupCard() },
                                onOpenPhoto = { viewModel.openImageViewer(it) },
                                onOpenVideo = { viewModel.openVideoPlayer(it) },
                                onOpenFileMenu = { actionMenuTarget = it },
                                onOpenConnectionSheet = { viewModel.openConnectSheet() },
                                onShareSelected = { viewModel.shareFilesViaPrivateCache(it) },
                                onDownloadSelected = { viewModel.downloadBatchToPublic(it) },
                                onMoveSelected = { files ->
                                    pendingFolderAction = PendingFolderAction.MoveItems(files, emptyList())
                                },
                                onDeleteSelected = { viewModel.deleteBatch(it) }
                            )

                            ClodyTab.FOLDERS -> FoldersScreen(
                                connectionState = connectionState,
                                breadcrumbs = breadcrumbs,
                                subfolders = currentSubfolders,
                                files = currentFolderFiles,
                                allActiveFiles = allActiveFiles,
                                folderItemCounts = folderItemCounts,
                                isGridView = settings.gridViewFolders,
                                showFileExtensions = settings.showFileExtensions,
                                sortOption = settings.sortOption,
                                onToggleGridView = { viewModel.setGridViewFolders(it) },
                                onChangeSort = { viewModel.setSortOption(it) },
                                onJumpToSearch = { selectedTab = ClodyTab.SEARCH },
                                onSyncCloud = { viewModel.syncFromTelegram() },
                                onOpenConnectionSheet = { viewModel.openConnectSheet() },
                                onOpenUploadPicker = { launchFoldersChooserWithAuthGate() },
                                onCreateFolder = { viewModel.createFolder(it) },
                                onOpenFolder = { viewModel.openFolder(it) },
                                onNavigateRoot = { viewModel.navigateToRootFolder() },
                                onNavigateBreadcrumb = { viewModel.navigateToBreadcrumb(it) },
                                onNavigateUp = { viewModel.navigateUpFolder() },
                                onOpenFile = { file -> viewModel.openCloudFile(file) },
                                onToggleFavorite = { viewModel.toggleFavorite(it) },
                                onOpenFileMenu = { actionMenuTarget = it },
                                onRenameFolder = { folder, name -> viewModel.renameFolder(folder, name) },
                                onMoveFolder = { folder ->
                                    pendingFolderAction = PendingFolderAction.MoveItems(emptyList(), listOf(folder))
                                },
                                onDownloadFolder = { folder ->
                                    viewModel.downloadBatchToPublic(emptyList(), includeFolderIds = listOf(folder.id))
                                },
                                onShareFolder = { folder ->
                                    viewModel.shareFilesViaPrivateCache(emptyList(), includeFolderIds = listOf(folder.id))
                                },
                                onDeleteFolder = { folder -> viewModel.deleteFolderRecursively(folder) },
                                onMoveFile = { file ->
                                    pendingFolderAction = PendingFolderAction.MoveItems(listOf(file), emptyList())
                                },
                                onCopyFile = { file ->
                                    pendingFolderAction = PendingFolderAction.CopyFile(file)
                                },
                                onDownloadFile = { file -> viewModel.downloadToPublicGallery(file) },
                                onShareFileItem = { file -> viewModel.shareFilesViaPrivateCache(listOf(file)) },
                                onRenameFileItem = { file, newName -> viewModel.renameFile(file, newName) },
                                onDeleteFileItem = { file -> viewModel.deleteFile(file) },
                                onBatchShare = { selectedFiles, selectedFolders ->
                                    viewModel.shareFilesViaPrivateCache(selectedFiles, selectedFolders.map { it.id })
                                },
                                onBatchDownload = { selectedFiles, selectedFolders ->
                                    viewModel.downloadBatchToPublic(selectedFiles, selectedFolders.map { it.id })
                                },
                                onBatchMove = { selectedFiles, selectedFolders ->
                                    pendingFolderAction = PendingFolderAction.MoveItems(selectedFiles, selectedFolders)
                                },
                                onBatchDelete = { selectedFiles, selectedFolders ->
                                    viewModel.deleteBatch(selectedFiles, selectedFolders)
                                }
                            )

                            ClodyTab.TRANSFERS -> TransfersScreen(
                                connectionState = connectionState,
                                batchSummaryFlow = viewModel.transferBatchSummary,
                                uploadTasksFlow = viewModel.uploadTasks,
                                downloadRecordsFlow = viewModel.downloadRecords,
                                downloadSpeedsFlow = viewModel.downloadSpeeds,
                                onOpenConnectionSheet = { viewModel.openConnectSheet() },
                                onOpenUploadPicker = { launchFoldersChooserWithAuthGate() },
                                onPauseUpload = { viewModel.pauseUpload(it) },
                                onResumeUpload = { viewModel.resumeUpload(it) },
                                onCancelUpload = { viewModel.cancelUpload(it) },
                                onCancelDownload = { viewModel.cancelDownload(it) }
                            )

                            ClodyTab.SEARCH -> SearchScreen(
                                query = searchQuery,
                                selectedCategory = searchCategory,
                                results = searchResults,
                                showFileExtensions = settings.showFileExtensions,
                                onQueryChange = { viewModel.updateSearchQuery(it) },
                                onSelectCategory = { viewModel.updateSearchCategory(it) },
                                onOpenFile = { file -> viewModel.openCloudFile(file) },
                                onOpenFileMenu = { actionMenuTarget = it },
                                onOpenUploadPicker = { launchFoldersChooserWithAuthGate() }
                            )

                            ClodyTab.TOOLS -> ToolsSettingsScreen(
                                settings = settings,
                                authStep = authStep,
                                userProfile = userProfile,
                                deviceStorage = deviceStorage,
                                totalCloudBytes = totalCloudBytes,
                                streamCacheBytes = streamCacheBytes,
                                hasAllFilesAccess = viewModel.deviceFileManager.hasAllFilesAccess(),
                                hasNotificationPermission = hasNotificationPermission,
                                localDirectoryItems = localDirectoryItems,
                                currentLocalDir = currentLocalDir,
                                largeLocalFiles = largeLocalFiles,
                                largeCloudFiles = largeCloudFiles,
                                duplicateGroups = duplicateGroups,
                                deletedFiles = deletedFiles,
                                installedApps = installedApps,
                                onRequestNotificationPermission = {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                        notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                    }
                                },
                                onRequestAllFilesAccess = { showAllFilesRationale = true },
                                onClearStreamCache = { viewModel.clearStreamCache() },
                                onSetZeroStorageMode = { viewModel.setZeroStorageMode(it) },
                                onSetAutoDeleteCacheOnExit = { viewModel.setAutoDeleteCacheOnExit(it) },
                                onSetThemeMode = { viewModel.setThemeMode(it) },
                                onSetDynamicColors = { viewModel.setDynamicColors(it) },
                                onSetShowHidden = { viewModel.setShowHiddenFiles(it) },
                                onSetShowExtensions = { viewModel.setShowFileExtensions(it) },
                                onSetUseRecycleBin = { viewModel.setUseRecycleBin(it) },
                                onSetConfirmDelete = { viewModel.setConfirmBeforeDeleting(it) },
                                onSetUploadWifiOnly = { viewModel.setUploadWifiOnly(it) },
                                onLoadLocalDirectory = { viewModel.loadLocalDirectory(it) },
                                onUploadLocalFile = { viewModel.uploadLocalFile(it) },
                                onScanLargeFiles = { viewModel.scanLargeLocalFiles() },
                                onScanDuplicates = { viewModel.scanDuplicates() },
                                onLoadInstalledApps = { viewModel.loadInstalledApps() },
                                onBackupApk = { viewModel.backupApkToCloud(it) },
                                onRestoreDeleted = { viewModel.restoreFile(it) },
                                onPermanentDelete = { viewModel.permanentlyDeleteFile(it) },
                                onOpenCompressPicker = { compressPickerLauncher.launch(arrayOf("*/*")) },
                                onOpenExtractPicker = {
                                    extractPickerLauncher.launch(
                                        arrayOf("application/zip", "application/x-tar", "application/x-7z-compressed", "*/*")
                                    )
                                },
                                onAssignFolderToSync = { safFolderSyncLauncher.launch(null) },
                                onRemoveSyncedFolder = { viewModel.removeSyncedFolder(it) },
                                onForceCloudIndexSync = { viewModel.forceCloudIndexSync() },
                                onRebuildIndex = { viewModel.rebuildFileIndex() },
                                onOptimizeFts = { viewModel.optimizeSearchIndex() },
                                onOpenConnectSheet = { viewModel.openConnectSheet() },
                                onLogout = { viewModel.logout() }
                            )
                        }
                    }

                    AnimatedVisibility(
                        visible = binaryDownloadBanner != null,
                        enter = fadeIn(),
                        exit = fadeOut(),
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .navigationBarsPadding()
                            .padding(bottom = 92.dp)
                    ) {
                        binaryDownloadBanner?.let { bannerState ->
                            BinaryDownloadBanner(
                                state = bannerState,
                                onOpenDeviceFileManager = {
                                    runCatching {
                                        context.startActivity(
                                            Intent(DownloadManager.ACTION_VIEW_DOWNLOADS).apply {
                                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                            }
                                        )
                                    }
                                },
                                onDismiss = { viewModel.dismissBinaryBanner() }
                            )
                        }
                    }

                    MorphingFloatingBottomBar(
                        selectedTab = selectedTab,
                        connectionState = connectionState,
                        onSelectTab = { selectedTab = it },
                        modifier = Modifier.align(Alignment.BottomCenter)
                    )
                }
            }

            // Gallery Organization & Search Hub Overlay (Favorites, Trash, Dedicated Albums)
            AnimatedVisibility(
                visible = showGalleryOrganizationHub,
                enter = fadeIn(ClodyMotion.crispTween(200)) +
                    slideInVertically(ClodyMotion.crispTween(220)) { it / 16 },
                exit = fadeOut(ClodyMotion.crispTween(160)) +
                    slideOutVertically(ClodyMotion.crispTween(180)) { it / 16 }
            ) {
                GalleryOrganizationScreen(
                    allMedia = galleryMedia,
                    albums = galleryAlbums,
                    favoriteMedia = favoriteGalleryMedia,
                    trashMedia = deletedGalleryMedia,
                    onCreateAlbum = { viewModel.createGalleryAlbum(it) },
                    onDeleteAlbum = { viewModel.deleteGalleryAlbum(it) },
                    onAssignToAlbum = { file, album -> viewModel.assignFileToAlbum(file, album) },
                    onRemoveFromAlbum = { viewModel.removeFileFromAlbum(it) },
                    onRestoreTrashItem = { viewModel.restoreFile(it) },
                    onPermanentDeleteItem = { viewModel.permanentlyDeleteFile(it) },
                    onEmptyTrash = { viewModel.emptyGalleryTrash() },
                    onOpenPhoto = { viewModel.openImageViewer(it) },
                    onOpenVideo = { viewModel.openVideoPlayer(it) },
                    onOpenFileMenu = { actionMenuTarget = it },
                    onBack = { showGalleryOrganizationHub = false }
                )
            }

            // Full-Screen Mixed-Media Pinch-to-Zoom & Horizontal Swipe Viewer Overlay
            activeImageFile?.let { img ->
                val activeList = if (galleryMedia.any { it.id == img.id }) galleryMedia else listOf(img)
                val activeIndex = activeList.indexOfFirst { it.id == img.id }.coerceAtLeast(0)
                ImageViewerScreen(
                    file = img,
                    mediaList = activeList,
                    initialIndex = activeIndex,
                    telegramClient = viewModel.telegramClient,
                    zeroStorageMode = settings.zeroStorageMode,
                    onDownloadToGallery = { viewModel.downloadToPublicGallery(it) },
                    onToggleFavorite = { viewModel.toggleFavorite(it) },
                    onAddToAlbum = { albumAssignmentTarget = it },
                    onShare = { file, cached -> viewModel.shareFile(file, cached) },
                    onDelete = {
                        viewModel.deleteFile(it)
                        viewModel.closeImageViewer()
                    },
                    onOpenVideo = { video -> viewModel.openVideoPlayer(video) },
                    onBack = { viewModel.closeImageViewer() },
                    onCacheMutated = { viewModel.refreshStorageMetrics() }
                )
            }

            // Full-Screen YouTube-Grade Video Player Overlay (rendered above pager so back preserves pager index)
            activeVideoFile?.let { video ->
                val videoPlaylist = galleryMedia.filter { it.isVideo }
                YouTubeVideoPlayerScreen(
                    file = video,
                    playlist = videoPlaylist,
                    telegramClient = viewModel.telegramClient,
                    zeroStorageMode = settings.zeroStorageMode,
                    onSelectVideo = { viewModel.openVideoPlayer(it) },
                    onDownloadToGallery = { viewModel.downloadToPublicGallery(it) },
                    onToggleFavorite = { viewModel.toggleFavorite(it) },
                    onAddToAlbum = { albumAssignmentTarget = it },
                    onBack = { viewModel.closeVideoPlayer() },
                    onCacheMutated = { viewModel.refreshStorageMetrics() }
                )
            }

            // Built-In Warm Monochrome Audio Player Overlay
            activeAudioFile?.let { audio ->
                ClodyAudioPlayerScreen(
                    file = audio,
                    telegramClient = viewModel.telegramClient,
                    zeroStorageMode = settings.zeroStorageMode,
                    onDownloadToDevice = { viewModel.downloadToPublicGallery(it) },
                    onBack = { viewModel.closeAudioPlayer() },
                    onCacheMutated = { viewModel.refreshStorageMetrics() }
                )
            }

            // Built-In Document Reader Suite Overlay (PDF, Word, Excel/CSV, Text/Code)
            activeDocumentFile?.let { doc ->
                DocumentReaderScreen(
                    file = doc,
                    telegramClient = viewModel.telegramClient,
                    zeroStorageMode = settings.zeroStorageMode,
                    onDownloadToDevice = { viewModel.downloadToPublicGallery(it) },
                    onBack = { viewModel.closeDocumentReader() },
                    onCacheMutated = { viewModel.refreshStorageMetrics() }
                )
            }
        }

        // Folders Dual-Mode Upload Chooser Sheet ("Gallery" vs "File Manager")
        if (showUploadSourceChoice) {
            FolderUploadChooserSheet(
                onPickGallery = {
                    photoPickerMultiLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)
                    )
                },
                onPickFileManager = {
                    anyFilePickerLauncher.launch(arrayOf("*/*"))
                },
                onDismiss = { showUploadSourceChoice = false }
            )
        }

        // Upload Preview Modal with Custom Video Thumbnail option
        if (uploadPreviewCandidates.isNotEmpty()) {
            UploadPreviewModalSheet(
                candidates = uploadPreviewCandidates,
                onPickCustomThumbnail = { candidate ->
                    candidateAwaitingCustomThumb = candidate
                    customThumbForCandidateLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                },
                onConfirmUpload = {
                    if (!hasNotificationPermission && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                    viewModel.confirmEnqueueUploads()
                },
                onDismiss = { viewModel.dismissUploadPreview() }
            )
        }

        // File 3-Dot Action Sheet (Add to Album, Move, Copy, Share, Change Thumbnail, Download, Favorite, Rename, Delete)
        actionMenuTarget?.let { target ->
            FileActionBottomSheet(
                file = target,
                confirmDelete = settings.confirmBeforeDeleting,
                onChangeThumbnail = { file ->
                    uploadedVideoAwaitingThumb = file
                    changeThumbForUploadedLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                },
                onAddToAlbum = if (target.isImage || target.isVideo) {
                    { file -> albumAssignmentTarget = file }
                } else null,
                onMoveToFolder = { file ->
                    pendingFolderAction = PendingFolderAction.MoveItems(listOf(file), emptyList())
                },
                onCopyFile = { file ->
                    pendingFolderAction = PendingFolderAction.CopyFile(file)
                },
                onShare = { file -> viewModel.shareFilesViaPrivateCache(listOf(file)) },
                onDownload = { viewModel.downloadToPublicGallery(it) },
                onToggleFavorite = { viewModel.toggleFavorite(it) },
                onRename = { f, name -> viewModel.renameFile(f, name) },
                onDelete = { viewModel.deleteFile(it) },
                onDismiss = { actionMenuTarget = null }
            )
        }

        // Folder Picker Dialog for Move / Copy
        pendingFolderAction?.let { action ->
            val excludedIds = when (action) {
                is PendingFolderAction.MoveItems -> action.folders.map { it.id }.toSet()
                is PendingFolderAction.CopyFile -> emptySet()
            }
            val title = when (action) {
                is PendingFolderAction.MoveItems -> {
                    val count = action.files.size + action.folders.size
                    "Move $count item(s) to Folder"
                }
                is PendingFolderAction.CopyFile -> "Copy \"${action.file.name}\" to Folder"
            }
            FolderPickerDialog(
                title = title,
                allFolders = allFolders,
                excludedFolderIds = excludedIds,
                onSelectDestination = { destFolderId ->
                    when (action) {
                        is PendingFolderAction.MoveItems -> {
                            if (action.files.isNotEmpty()) {
                                viewModel.moveFilesToFolder(action.files, destFolderId)
                            }
                            action.folders.forEach { folder ->
                                viewModel.moveFolderToParent(folder, destFolderId)
                            }
                        }
                        is PendingFolderAction.CopyFile -> {
                            viewModel.copyFileToFolder(action.file, destFolderId)
                        }
                    }
                },
                onDismiss = { pendingFolderAction = null }
            )
        }

        // Private Shared-Cache Download Progress Dialog
        shareCacheProgress?.let { progressState ->
            ShareCacheProgressDialog(state = progressState)
        }

        // Gallery Album Picker Sheet (accessible from Gallery grid, ImageViewer, or VideoPlayer)
        albumAssignmentTarget?.let { target ->
            AddToAlbumBottomSheet(
                file = target,
                albums = galleryAlbums,
                onSelectAlbum = { album -> viewModel.assignFileToAlbum(target, album) },
                onCreateAlbumAndAssign = { albumName -> viewModel.createGalleryAlbum(albumName, initialFile = target) },
                onRemoveFromAlbum = if (target.albumId != null) {
                    { viewModel.removeFileFromAlbum(target) }
                } else null,
                onDismiss = { albumAssignmentTarget = null }
            )
        }

        // On-Demand Telegram Connect Bottom Sheet
        if (showConnectSheet) {
            ConnectClodyBottomSheet(
                connectionState = connectionState,
                authStep = authStep,
                initialApiId = viewModel.secureStorage.getApiId()?.toString().orEmpty(),
                initialApiHash = viewModel.secureStorage.getApiHash().orEmpty(),
                initialPhone = viewModel.secureStorage.getPhoneNumber().orEmpty(),
                isBusy = authBusy,
                busyLabel = authBusyLabel,
                errorMessage = authError,
                onVerifyApi = { id, hash -> viewModel.verifyApiCredentials(id, hash) },
                onEditApi = { viewModel.editApiCredentials() },
                onSendCode = { phone -> viewModel.sendPhoneCode(phone) },
                onVerifyCode = { viewModel.verifyOtpCode(it) },
                onResendCode = { viewModel.resendOtpCode() },
                onVerifyPassword = { viewModel.verifyTwoFactorPassword(it) },
                onDismiss = { viewModel.dismissConnectSheet() }
            )
        }

        // Contextual Media Permission Rationale
        if (showMediaPermissionRationale) {
            AlertDialog(
                onDismissRequest = { showMediaPermissionRationale = false },
                title = { Text("Allow Media Access") },
                text = {
                    Text("Clody uses read-only media access to detect new photos and videos on your device for the Gallery auto-backup card.")
                },
                confirmButton = {
                    TextButton(onClick = {
                        showMediaPermissionRationale = false
                        launchMediaPermissionRequest()
                    }) { Text("Continue") }
                },
                dismissButton = {
                    TextButton(onClick = { showMediaPermissionRationale = false }) { Text("Not now") }
                }
            )
        }

        // Contextual All Files Access Rationale
        if (showAllFilesRationale) {
            AlertDialog(
                onDismissRequest = { showAllFilesRationale = false },
                title = { Text("All Files Access") },
                text = {
                    Text("Grant All Files Access in system settings to browse hidden folders, scan large files over 50 MB, and upload any file type directly.")
                },
                confirmButton = {
                    TextButton(onClick = {
                        showAllFilesRationale = false
                        launchAllFilesAccessSettings()
                    }) { Text("Open Settings") }
                },
                dismissButton = {
                    TextButton(onClick = { showAllFilesRationale = false }) { Text("Cancel") }
                }
            )
        }

        // Zip Archive Name Dialog
        if (pendingCompressUris.isNotEmpty()) {
            var archiveName by remember { mutableStateOf("clody_archive.zip") }
            AlertDialog(
                onDismissRequest = { pendingCompressUris = emptyList() },
                title = { Text("Compress ${pendingCompressUris.size} File(s)") },
                text = {
                    Column {
                        Text("Enter archive file name:")
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = archiveName,
                            onValueChange = { archiveName = it },
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp)
                        )
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val uris = pendingCompressUris
                        pendingCompressUris = emptyList()
                        viewModel.compressFiles(uris, archiveName)
                    }) { Text("Compress") }
                },
                dismissButton = {
                    TextButton(onClick = { pendingCompressUris = emptyList() }) { Text("Cancel") }
                }
            )
        }
    }
}
