package com.example.media

import android.app.Activity
import android.app.PictureInPictureParams
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.media.AudioManager
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.net.Uri
import android.os.Build
import android.util.Rational
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.displayCutoutPadding
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.BrightnessHigh
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ClosedCaption
import androidx.compose.material.icons.filled.CollectionsBookmark
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.HighQuality
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PictureInPictureAlt
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.FileProvider
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.example.data.local.ClodyDatabase
import com.example.data.local.FileEntity
import com.example.data.local.PlaybackCacheMode
import com.example.service.ClodyPlaybackController
import com.example.telegram.TelegramClientManager
import com.example.ui.formatFileSize
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.EmeraldConnected
import com.example.ui.theme.YouTubeCrimson
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import kotlin.math.abs
import kotlin.math.roundToInt

enum class VideoResizeFit(val label: String, val resizeMode: Int) {
    FIT("Fit", AspectRatioFrameLayout.RESIZE_MODE_FIT),
    ZOOM("Zoom", AspectRatioFrameLayout.RESIZE_MODE_ZOOM),
    STRETCH("Stretch", AspectRatioFrameLayout.RESIZE_MODE_FILL),
    NATIVE_100("100%", AspectRatioFrameLayout.RESIZE_MODE_FIT)
}

private enum class GestureAxisLock {
    NONE,
    HORIZONTAL_SEEK,
    VERTICAL_BRIGHTNESS,
    VERTICAL_VOLUME
}

private enum class VideoEqPreset(val label: String) {
    NORMAL("Normal"),
    BASS_BOOST("Bass Boost"),
    VOCAL("Vocal / Dialogue"),
    TREBLE_BOOST("Treble Boost"),
    CINEMA("Cinema")
}

private enum class VideoMoreSubSheet {
    MAIN,
    SPEED,
    QUALITY,
    SUBTITLES,
    AUDIO_TRACK,
    EQUALIZER,
    SLEEP_TIMER,
    AB_REPEAT,
    ASPECT_RATIO
}

private data class SelectableMediaTrack(
    val label: String,
    val groupIndex: Int,
    val trackIndex: Int,
    val isSelected: Boolean,
    val trackGroup: androidx.media3.common.TrackGroup
)

@kotlin.OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@OptIn(UnstableApi::class)
@Composable
fun YouTubeVideoPlayerScreen(
    file: FileEntity,
    playlist: List<FileEntity>,
    telegramClient: TelegramClientManager,
    zeroStorageMode: Boolean,
    onSelectVideo: (FileEntity) -> Unit,
    onDownloadToGallery: (FileEntity) -> Unit,
    onToggleFavorite: (FileEntity) -> Unit,
    onAddToAlbum: (FileEntity) -> Unit,
    onBack: () -> Unit,
    onDeleteVideo: ((FileEntity) -> Unit)? = null,
    onShareVideo: ((FileEntity, File?) -> Unit)? = null,
    onCacheMutated: () -> Unit = {}
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val configuration = LocalConfiguration.current
    val isLandscape = configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
    val scope = rememberCoroutineScope()

    var controlsVisible by remember { mutableStateOf(true) }
    var isLocked by remember { mutableStateOf(false) }
    var showUnlockPill by remember { mutableStateOf(false) }
    var showMoreSheet by remember { mutableStateOf(false) }
    var activeSubSheet by remember { mutableStateOf(VideoMoreSubSheet.MAIN) }
    var showFileInfoDialog by remember { mutableStateOf(false) }
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }

    var isPlaying by remember { mutableStateOf(true) }
    var isBuffering by remember { mutableStateOf(true) }
    var isEnded by remember { mutableStateOf(false) }
    var currentPositionMs by remember { mutableLongStateOf(0L) }
    var durationMs by remember { mutableLongStateOf(maxOf(file.durationMs, 1L)) }
    var bufferedPositionMs by remember { mutableLongStateOf(0L) }
    var videoWidth by remember { mutableIntStateOf(0) }
    var videoHeight by remember { mutableIntStateOf(0) }
    var videoAspectRatio by remember { mutableFloatStateOf(16f / 9f) }

    var playbackSpeed by remember { mutableFloatStateOf(1.0f) }
    var isTempBoost2x by remember { mutableStateOf(false) }
    var resizeFit by remember { mutableStateOf(VideoResizeFit.FIT) }
    var isLooping by remember { mutableStateOf(false) }
    var subtitlesEnabled by remember { mutableStateOf(true) }
    var forceDataSaverMode by remember { mutableStateOf<Boolean?>(null) }

    // Pinch-to-Zoom live scale (100%..400%), shown ONLY during active pinch and fades 800ms after release
    var pinchZoomScale by remember { mutableFloatStateOf(1.0f) }
    var isActivelyPinchZooming by remember { mutableStateOf(false) }
    var showZoomPill by remember { mutableStateOf(false) }
    var statusBannerText by remember { mutableStateOf<String?>(null) }

    // Horizontal Swipe-to-Seek live HUD preview (commits seek only when finger lifts)
    var isHorizontalSwipeSeeking by remember { mutableStateOf(false) }
    var swipeSeekTargetMs by remember { mutableLongStateOf(0L) }
    var swipeSeekDeltaMs by remember { mutableLongStateOf(0L) }

    // Double-tap seek feedback state
    var seekOverlaySide by remember { mutableStateOf<Int?>(null) } // -1 = left, 1 = right
    var seekAccumulatedSec by remember { mutableIntStateOf(0) }
    var lastSeekTapTime by remember { mutableLongStateOf(0L) }

    // Vertical swipe Brightness & Volume HUD
    val audioManager = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVolume = remember { maxOf(1, audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)) }
    var volumeLevel by remember {
        mutableFloatStateOf(audioManager.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxVolume)
    }
    var brightnessLevel by remember {
        mutableFloatStateOf(
            activity?.window?.attributes?.screenBrightness?.takeIf { it in 0f..1f } ?: 0.5f
        )
    }
    var activeSwipeHud by remember { mutableStateOf<String?>(null) } // "BRIGHTNESS" or "VOLUME"

    // Scrubber drag state
    var isScrubbing by remember { mutableStateOf(false) }
    var scrubPositionMs by remember { mutableLongStateOf(0L) }

    // Equalizer & Bass Boost state
    var audioSessionId by remember { mutableIntStateOf(C.AUDIO_SESSION_ID_UNSET) }
    var eqPreset by remember { mutableStateOf(VideoEqPreset.NORMAL) }
    var bassBoostStrength by remember { mutableFloatStateOf(0f) }

    // Sleep Timer & A-B Repeat state
    var sleepTimerRemainingSec by remember { mutableIntStateOf(0) }
    var sleepTimerEndOfVideo by remember { mutableStateOf(false) }
    var abRepeatA by remember { mutableStateOf<Long?>(null) }
    var abRepeatB by remember { mutableStateOf<Long?>(null) }

    // Track inspection from Media3
    var subtitleTracks by remember { mutableStateOf<List<SelectableMediaTrack>>(emptyList()) }
    var audioTracks by remember { mutableStateOf<List<SelectableMediaTrack>>(emptyList()) }

    val resolvedSource = remember(
        file.id,
        file.localSourceUri,
        file.isPinnedOffline,
        file.pinnedOfflinePath,
        file.localCachePath,
        zeroStorageMode
    ) {
        LocalFirstResolver.resolve(context, file, ignoreStreamCache = zeroStorageMode)
    }
    val origin = resolvedSource.origin

    // Phase 2 Network-aware Cellular vs Wi-Fi observation preserved intact
    var isCellularNetwork by remember {
        mutableStateOf(NetworkStreamingPolicy.isMeteredCellular(context))
    }
    DisposableEffect(context) {
        val unregister = NetworkStreamingPolicy.observeNetworkChanges(context) { cellularSaver ->
            isCellularNetwork = cellularSaver
        }
        onDispose { unregister() }
    }
    val isCellularDataSaver = forceDataSaverMode ?: isCellularNetwork

    var lastActiveFileId by remember { mutableLongStateOf(file.id) }
    val resumeAtMs = if (lastActiveFileId == file.id) currentPositionMs else 0L
    if (lastActiveFileId != file.id) {
        lastActiveFileId = file.id
        currentPositionMs = 0L
        abRepeatA = null
        abRepeatB = null
        pinchZoomScale = 1.0f
    }

    fun handleExplicitExit() {
        ClodyPlaybackController.stopAndCleanup(context)
        onBack()
    }

    val exoPlayer = remember(file.id, zeroStorageMode, playlist) {
        ClodyPlaybackController.ensurePlaybackSession(
            context = context,
            file = file,
            isVideo = true,
            playlist = playlist,
            telegramClient = telegramClient,
            zeroStorageMode = zeroStorageMode,
            isCellularDataSaver = isCellularDataSaver,
            subtitlesEnabled = subtitlesEnabled,
            onCacheMutated = onCacheMutated
        ).also { player ->
            if (resumeAtMs > 0L && player.currentPosition < 500L) {
                player.seekTo(resumeAtMs)
            }
        }
    }

    val trackSelector = remember(exoPlayer) {
        ClodyPlaybackController.trackSelector ?: DefaultTrackSelector(context)
    }

    LaunchedEffect(trackSelector, isCellularDataSaver, subtitlesEnabled) {
        val paramsBuilder = trackSelector.buildUponParameters()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, !subtitlesEnabled)
        if (isCellularDataSaver) {
            paramsBuilder
                .setMaxVideoSize(854, 480)
                .setMaxVideoBitrate(1_200_000)
        } else {
            paramsBuilder
                .clearVideoSizeConstraints()
                .setMaxVideoBitrate(Int.MAX_VALUE)
        }
        trackSelector.parameters = paramsBuilder.build()
    }

    fun refreshTracksList(tracks: Tracks) {
        val textList = mutableListOf<SelectableMediaTrack>()
        val audioList = mutableListOf<SelectableMediaTrack>()
        tracks.groups.forEachIndexed { gIdx, group ->
            for (tIdx in 0 until group.length) {
                val fmt = group.getTrackFormat(tIdx)
                val langLabel = fmt.language?.uppercase()?.takeIf { it.isNotBlank() && it != "UND" }
                val baseLabel = fmt.label?.takeIf { it.isNotBlank() }
                    ?: langLabel
                    ?: "Track ${tIdx + 1}"
                if (group.type == C.TRACK_TYPE_TEXT) {
                    textList += SelectableMediaTrack(
                        label = baseLabel,
                        groupIndex = gIdx,
                        trackIndex = tIdx,
                        isSelected = group.isTrackSelected(tIdx),
                        trackGroup = group.mediaTrackGroup
                    )
                } else if (group.type == C.TRACK_TYPE_AUDIO) {
                    val ch = if (fmt.channelCount > 0) " (${fmt.channelCount}ch)" else ""
                    audioList += SelectableMediaTrack(
                        label = "$baseLabel$ch",
                        groupIndex = gIdx,
                        trackIndex = tIdx,
                        isSelected = group.isTrackSelected(tIdx),
                        trackGroup = group.mediaTrackGroup
                    )
                }
            }
        }
        subtitleTracks = textList
        audioTracks = audioList
    }

    // Listen to ExoPlayer events
    DisposableEffect(exoPlayer) {
        audioSessionId = exoPlayer.audioSessionId
        isPlaying = exoPlayer.isPlaying || exoPlayer.playWhenReady
        isBuffering = exoPlayer.playbackState == Player.STATE_BUFFERING
        if (exoPlayer.duration > 0L) durationMs = exoPlayer.duration
        if (exoPlayer.videoSize.width > 0 && exoPlayer.videoSize.height > 0) {
            videoWidth = exoPlayer.videoSize.width
            videoHeight = exoPlayer.videoSize.height
            videoAspectRatio = (videoWidth.toFloat() / videoHeight.toFloat()).coerceIn(0.35f, 2.8f)
        }
        refreshTracksList(exoPlayer.currentTracks)
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                isBuffering = playbackState == Player.STATE_BUFFERING
                isEnded = playbackState == Player.STATE_ENDED
                if (exoPlayer.duration > 0L) {
                    durationMs = exoPlayer.duration
                }
                if (playbackState == Player.STATE_ENDED && sleepTimerEndOfVideo) {
                    sleepTimerEndOfVideo = false
                    exoPlayer.pause()
                    statusBannerText = "Sleep timer ended"
                }
            }

            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }

            override fun onVideoSizeChanged(videoSize: VideoSize) {
                if (videoSize.width > 0 && videoSize.height > 0) {
                    videoWidth = videoSize.width
                    videoHeight = videoSize.height
                    videoAspectRatio = (videoSize.width.toFloat() / videoSize.height.toFloat())
                        .coerceIn(0.35f, 2.8f)
                }
            }

            override fun onTracksChanged(tracks: Tracks) {
                refreshTracksList(tracks)
            }

            override fun onAudioSessionIdChanged(sessionId: Int) {
                audioSessionId = sessionId
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            // Preserve background playback & cached buffers on Home/Lock backgrounding;
            // explicit Close / Back / Swipe-Recents invokes ClodyPlaybackController.stopAndCleanup().
            exoPlayer.removeListener(listener)
        }
    }

    // Attach Equalizer & BassBoost safely to ExoPlayer's active audio session
    DisposableEffect(audioSessionId, eqPreset, bassBoostStrength) {
        var equalizer: Equalizer? = null
        var bassBoost: BassBoost? = null
        if (audioSessionId != C.AUDIO_SESSION_ID_UNSET && audioSessionId != 0) {
            runCatching {
                equalizer = Equalizer(0, audioSessionId).apply {
                    enabled = eqPreset != VideoEqPreset.NORMAL
                    val numBands = numberOfBands.toInt()
                    val minLevel = bandLevelRange[0]
                    val maxLevel = bandLevelRange[1]
                    for (band in 0 until numBands) {
                        val b = band.toShort()
                        val target = when (eqPreset) {
                            VideoEqPreset.NORMAL -> 0
                            VideoEqPreset.BASS_BOOST -> when (band) {
                                0 -> (maxLevel * 0.8f).toInt()
                                1 -> (maxLevel * 0.5f).toInt()
                                else -> 0
                            }
                            VideoEqPreset.VOCAL -> when {
                                band == 0 -> (minLevel * 0.35f).toInt()
                                band in 1..(numBands - 2) -> (maxLevel * 0.55f).toInt()
                                else -> (maxLevel * 0.2f).toInt()
                            }
                            VideoEqPreset.TREBLE_BOOST -> when {
                                band >= numBands - 2 -> (maxLevel * 0.75f).toInt()
                                else -> 0
                            }
                            VideoEqPreset.CINEMA -> when (band) {
                                0 -> (maxLevel * 0.65f).toInt()
                                numBands - 1 -> (maxLevel * 0.45f).toInt()
                                else -> (maxLevel * 0.2f).toInt()
                            }
                        }.coerceIn(minLevel.toInt(), maxLevel.toInt()).toShort()
                        setBandLevel(b, target)
                    }
                }
            }
            runCatching {
                bassBoost = BassBoost(0, audioSessionId).apply {
                    val effectiveStrength = when {
                        bassBoostStrength > 0f -> (bassBoostStrength * 1000f).roundToInt().coerceIn(0, 1000).toShort()
                        eqPreset == VideoEqPreset.BASS_BOOST -> 750.toShort()
                        else -> 0.toShort()
                    }
                    enabled = effectiveStrength > 0
                    if (strengthSupported && effectiveStrength > 0) {
                        setStrength(effectiveStrength)
                    }
                }
            }
        }
        onDispose {
            runCatching { equalizer?.release() }
            runCatching { bassBoost?.release() }
        }
    }

    // Apply playback speed & loop changes
    LaunchedEffect(playbackSpeed, isTempBoost2x) {
        val target = if (isTempBoost2x) 2.0f else playbackSpeed
        exoPlayer.playbackParameters = PlaybackParameters(target)
    }

    LaunchedEffect(isLooping) {
        exoPlayer.repeatMode = if (isLooping) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
    }

    // Sleep timer countdown
    LaunchedEffect(sleepTimerRemainingSec) {
        if (sleepTimerRemainingSec > 0) {
            delay(1000L)
            val next = sleepTimerRemainingSec - 1
            sleepTimerRemainingSec = next
            if (next == 0) {
                exoPlayer.pause()
                statusBannerText = "Sleep timer paused playback"
            }
        }
    }

    // Sync scrubber + enforce A-B Repeat segment loop
    LaunchedEffect(exoPlayer, controlsVisible, isPlaying, isScrubbing, isHorizontalSwipeSeeking, abRepeatA, abRepeatB) {
        while (isActive) {
            if (!isScrubbing && !isHorizontalSwipeSeeking) {
                val pos = exoPlayer.currentPosition.coerceAtLeast(0L)
                currentPositionMs = pos
                val a = abRepeatA
                val b = abRepeatB
                if (a != null && b != null && b > a + 300L && isPlaying && pos >= b) {
                    exoPlayer.seekTo(a)
                    currentPositionMs = a
                }
            }
            bufferedPositionMs = exoPlayer.bufferedPosition.coerceAtLeast(0L)
            if (exoPlayer.duration > 0L) durationMs = exoPlayer.duration
            if (controlsVisible && isPlaying && !isScrubbing && !isHorizontalSwipeSeeking) {
                withFrameNanos { }
            } else {
                delay(120L)
            }
        }
    }

    // Auto-hide HUD after 3 seconds while playing
    LaunchedEffect(controlsVisible, isPlaying, isScrubbing, showMoreSheet, isHorizontalSwipeSeeking) {
        if (controlsVisible && isPlaying && !isScrubbing && !showMoreSheet && !isHorizontalSwipeSeeking) {
            delay(3000L)
            controlsVisible = false
        }
    }

    // Auto-hide transient HUD pills
    LaunchedEffect(seekOverlaySide, seekAccumulatedSec) {
        if (seekOverlaySide != null) {
            delay(750L)
            seekOverlaySide = null
            seekAccumulatedSec = 0
        }
    }

    LaunchedEffect(activeSwipeHud, brightnessLevel, volumeLevel) {
        if (activeSwipeHud != null) {
            delay(900L)
            activeSwipeHud = null
        }
    }

    // Auto-fade Zoom % pill strictly 800ms after pinch fingers lift
    LaunchedEffect(isActivelyPinchZooming, pinchZoomScale) {
        if (isActivelyPinchZooming) {
            showZoomPill = true
        } else if (showZoomPill) {
            delay(800L)
            showZoomPill = false
        }
    }

    LaunchedEffect(statusBannerText) {
        if (statusBannerText != null) {
            delay(1500L)
            statusBannerText = null
        }
    }

    LaunchedEffect(showUnlockPill) {
        if (showUnlockPill) {
            delay(2000L)
            showUnlockPill = false
        }
    }

    // Manage system bars in landscape fullscreen
    DisposableEffect(isLandscape) {
        val window = activity?.window
        if (window != null) {
            val controller = WindowCompat.getInsetsController(window, window.decorView)
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            if (isLandscape) {
                controller.hide(WindowInsetsCompat.Type.systemBars())
            } else {
                controller.show(WindowInsetsCompat.Type.systemBars())
            }
        }
        onDispose {
            if (window != null) {
                WindowCompat.getInsetsController(window, window.decorView)
                    .show(WindowInsetsCompat.Type.systemBars())
            }
        }
    }

    // Restore portrait on exit
    DisposableEffect(Unit) {
        onDispose {
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    fun toggleFullscreen() {
        activity?.requestedOrientation = if (isLandscape) {
            ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        } else {
            ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
    }

    fun enterPipMode() {
        if (activity == null) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val aspect = if (videoWidth > 0 && videoHeight > 0) {
                Rational(videoWidth, videoHeight)
            } else {
                Rational(16, 9)
            }
            val result = runCatching {
                val params = PictureInPictureParams.Builder()
                    .setAspectRatio(aspect)
                    .build()
                activity.enterPictureInPictureMode(params)
            }
            if (result.isFailure) {
                statusBannerText = "PiP unavailable on this device"
            }
        } else {
            statusBannerText = "PiP requires Android 8.0+"
        }
    }

    fun triggerShare() {
        val readyFile = (resolvedSource as? ResolvedMediaSource.CloudStream)?.cachedOrPinnedFile
            ?.takeIf { it.exists() && it.length() > 0L }
            ?: (resolvedSource as? ResolvedMediaSource.LocalDevice)?.directFile
                ?.takeIf { it.exists() && it.length() > 0L }
            ?: file.localCachePath?.let { File(it) }?.takeIf { it.exists() && it.length() > 0L }

        if (onShareVideo != null) {
            onShareVideo.invoke(file, readyFile)
            return
        }

        scope.launch {
            statusBannerText = "Preparing video to share..."
            val shareUri: Uri? = when {
                readyFile != null -> runCatching {
                    FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", readyFile)
                }.getOrNull()
                resolvedSource is ResolvedMediaSource.LocalDevice -> resolvedSource.uri
                else -> runCatching {
                    val (loaded, _) = LocalFirstResolver.loadToReadableFile(
                        context = context,
                        telegramClient = telegramClient,
                        file = file,
                        cacheMode = if (zeroStorageMode) PlaybackCacheMode.NO_CACHE_MODE else PlaybackCacheMode.CACHE_MODE
                    )
                    FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", loaded)
                }.getOrNull()
            }
            if (shareUri != null) {
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = file.mimeType.ifBlank { "video/*" }
                    putExtra(Intent.EXTRA_STREAM, shareUri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                context.startActivity(Intent.createChooser(intent, "Share ${file.name}"))
            } else {
                statusBannerText = "Unable to prepare video for sharing"
            }
        }
    }

    fun triggerDelete() {
        if (onDeleteVideo != null) {
            onDeleteVideo.invoke(file)
            handleExplicitExit()
            return
        }
        scope.launch {
            ClodyDatabase.getInstance(context).clodyDao().softDeleteFile(file.id)
            handleExplicitExit()
        }
    }

    fun cycleAspectRatio() {
        val entries = VideoResizeFit.entries
        val next = entries[(resizeFit.ordinal + 1) % entries.size]
        resizeFit = next
        if (next == VideoResizeFit.NATIVE_100) {
            pinchZoomScale = 1.0f
        }
        statusBannerText = "Aspect: ${next.label}"
    }

    BackHandler {
        if (showMoreSheet) {
            showMoreSheet = false
        } else if (isLandscape) {
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        } else {
            handleExplicitExit()
        }
    }

    val currentIndex = remember(file.id, playlist) {
        playlist.indexOfFirst { it.id == file.id }
    }
    val hasPrev = currentIndex > 0
    val hasNext = currentIndex in 0 until (playlist.size - 1)
    val isVerticalVideo = videoHeight > videoWidth && videoWidth > 0
    val subtitleMeta = remember(file.sizeBytes, playlist.size, currentIndex) {
        buildString {
            append(formatFileSize(file.sizeBytes))
            if (playlist.size > 1 && currentIndex >= 0) {
                append(" • ${currentIndex + 1}/${playlist.size}")
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .testTag("youtube_video_player")
    ) {
        // Theater Layout: Full centered viewport for Landscape OR Vertical (9:16) Shorts videos,
        // and centered aspect-matched viewport for widescreen Portrait playback.
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            BoxWithConstraints(
                modifier = if (isLandscape || isVerticalVideo) {
                    Modifier.fillMaxSize()
                } else {
                    Modifier
                        .fillMaxWidth()
                        .aspectRatio(videoAspectRatio.coerceIn(0.45f, 2.6f))
                },
                contentAlignment = Alignment.Center
            ) {
                val viewportWidthPx = constraints.maxWidth.toFloat().coerceAtLeast(1f)
                val viewportHeightPx = constraints.maxHeight.toFloat().coerceAtLeast(1f)

                // Hardware-accelerated Media3 PlayerView with live pinch-zoom transform
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .clipToBounds()
                ) {
                    AndroidView(
                        factory = { ctx ->
                            PlayerView(ctx).apply {
                                layoutParams = FrameLayout.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                    ViewGroup.LayoutParams.MATCH_PARENT
                                )
                                useController = false
                                setShowBuffering(PlayerView.SHOW_BUFFERING_NEVER)
                                setKeepContentOnPlayerReset(true)
                                player = exoPlayer
                            }
                        },
                        update = { view ->
                            if (view.player !== exoPlayer) view.player = exoPlayer
                            view.resizeMode = resizeFit.resizeMode
                        },
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer(
                                scaleX = pinchZoomScale,
                                scaleY = pinchZoomScale
                            )
                    )
                }

                // Gesture Layer: Smart axis-locked Horizontal Swipe-to-Seek, Vertical Brightness/Volume,
                // Pinch-to-Zoom (100%..400%), Double-tap -10/+10, Long-press 2x speed, Single tap HUD toggle.
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(isLocked, durationMs, file.id) {
                            awaitEachGesture {
                                val firstDown = awaitFirstDown(requireUnconsumed = false)
                                var isMultiTouch = false
                                var axisLock = GestureAxisLock.NONE
                                val startX = firstDown.position.x
                                var cumulativeDx = 0f
                                val seekBaselineMs = exoPlayer.currentPosition.coerceAtLeast(0L)

                                while (true) {
                                    val event = awaitPointerEvent()
                                    val pressedCount = event.changes.count { it.pressed }

                                    if (pressedCount >= 2 && !isLocked) {
                                        isMultiTouch = true
                                        isHorizontalSwipeSeeking = false
                                        axisLock = GestureAxisLock.NONE
                                        val zoomDelta = event.calculateZoom()
                                        if (abs(zoomDelta - 1f) > 0.002f) {
                                            isActivelyPinchZooming = true
                                            showZoomPill = true
                                            pinchZoomScale = (pinchZoomScale * zoomDelta).coerceIn(1.0f, 4.0f)
                                            if (pinchZoomScale > 1.15f && resizeFit == VideoResizeFit.FIT) {
                                                resizeFit = VideoResizeFit.ZOOM
                                            } else if (pinchZoomScale <= 1.02f && zoomDelta < 1f && resizeFit == VideoResizeFit.ZOOM) {
                                                resizeFit = VideoResizeFit.FIT
                                            }
                                        }
                                        event.changes.forEach { it.consume() }
                                    } else if (pressedCount == 1 && !isMultiTouch && !isLocked) {
                                        val change = event.changes.first()
                                        val dx = change.position.x - change.previousPosition.x
                                        val dy = change.position.y - change.previousPosition.y

                                        if (axisLock == GestureAxisLock.NONE) {
                                            val totalDx = change.position.x - startX
                                            val totalDy = change.position.y - firstDown.position.y
                                            if (abs(totalDx) > 16f && abs(totalDx) > abs(totalDy) * 1.25f) {
                                                axisLock = GestureAxisLock.HORIZONTAL_SEEK
                                                isHorizontalSwipeSeeking = true
                                                swipeSeekTargetMs = seekBaselineMs
                                                swipeSeekDeltaMs = 0L
                                            } else if (abs(totalDy) > 16f && abs(totalDy) > abs(totalDx) * 1.25f) {
                                                axisLock = if (startX < viewportWidthPx * 0.5f) {
                                                    GestureAxisLock.VERTICAL_BRIGHTNESS
                                                } else {
                                                    GestureAxisLock.VERTICAL_VOLUME
                                                }
                                            }
                                        }

                                        if (change.pressed) {
                                            when (axisLock) {
                                                GestureAxisLock.HORIZONTAL_SEEK -> {
                                                    cumulativeDx += dx
                                                    val scrubSpanMs = maxOf(30_000f, minOf(180_000f, durationMs * 0.5f))
                                                    val deltaMs = ((cumulativeDx / viewportWidthPx) * scrubSpanMs).toLong()
                                                    val clamped = (seekBaselineMs + deltaMs).coerceIn(0L, maxOf(1L, durationMs))
                                                    swipeSeekDeltaMs = clamped - seekBaselineMs
                                                    swipeSeekTargetMs = clamped
                                                    currentPositionMs = clamped
                                                    change.consume()
                                                }
                                                GestureAxisLock.VERTICAL_BRIGHTNESS -> {
                                                    val deltaFrac = -dy / (viewportHeightPx * 0.72f)
                                                    brightnessLevel = (brightnessLevel + deltaFrac).coerceIn(0.05f, 1.0f)
                                                    activity?.window?.let { win ->
                                                        val lp = win.attributes
                                                        lp.screenBrightness = brightnessLevel
                                                        win.attributes = lp
                                                    }
                                                    activeSwipeHud = "BRIGHTNESS"
                                                    change.consume()
                                                }
                                                GestureAxisLock.VERTICAL_VOLUME -> {
                                                    val deltaFrac = -dy / (viewportHeightPx * 0.72f)
                                                    volumeLevel = (volumeLevel + deltaFrac).coerceIn(0f, 1f)
                                                    val targetVol = (volumeLevel * maxVolume).roundToInt().coerceIn(0, maxVolume)
                                                    audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, targetVol, 0)
                                                    activeSwipeHud = "VOLUME"
                                                    change.consume()
                                                }
                                                GestureAxisLock.NONE -> Unit
                                            }
                                        }
                                    }

                                    if (event.changes.none { it.pressed }) {
                                        if (isActivelyPinchZooming) {
                                            isActivelyPinchZooming = false
                                        }
                                        if (axisLock == GestureAxisLock.HORIZONTAL_SEEK && isHorizontalSwipeSeeking) {
                                            // Commit exoPlayer seek ONLY on finger lift so cloud streaming stays smooth
                                            val commitPos = swipeSeekTargetMs
                                            isHorizontalSwipeSeeking = false
                                            currentPositionMs = commitPos
                                            exoPlayer.seekTo(commitPos)
                                        }
                                        break
                                    }
                                }
                            }
                        }
                        .pointerInput(isLocked) {
                            detectTapGestures(
                                onTap = {
                                    if (isLocked) {
                                        showUnlockPill = !showUnlockPill
                                    } else {
                                        controlsVisible = !controlsVisible
                                    }
                                },
                                onDoubleTap = { offset ->
                                    if (isLocked) return@detectTapGestures
                                    val now = System.currentTimeMillis()
                                    val side = if (offset.x < size.width / 2f) -1 else 1
                                    val withinStreak = (now - lastSeekTapTime) < 1100L && seekOverlaySide == side
                                    lastSeekTapTime = now
                                    seekOverlaySide = side
                                    seekAccumulatedSec = if (withinStreak) seekAccumulatedSec + 10 else 10
                                    val targetPos = (exoPlayer.currentPosition + side * 10_000L)
                                        .coerceIn(0L, maxOf(1L, durationMs))
                                    exoPlayer.seekTo(targetPos)
                                    currentPositionMs = targetPos
                                },
                                onLongPress = {
                                    if (isLocked) return@detectTapGestures
                                    isTempBoost2x = true
                                },
                                onPress = {
                                    tryAwaitRelease()
                                    if (isTempBoost2x) {
                                        isTempBoost2x = false
                                    }
                                }
                            )
                        }
                )

                // Double-tap semi-circular ripple & -10s / +10s chevron overlay
                AnimatedVisibility(
                    visible = seekOverlaySide != null,
                    enter = fadeIn(tween(120)),
                    exit = fadeOut(tween(220)),
                    modifier = Modifier.fillMaxSize()
                ) {
                    val side = seekOverlaySide ?: 1
                    Box(modifier = Modifier.fillMaxSize()) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val r = size.height * 0.9f
                            val center = if (side < 0) Offset(-r * 0.2f, size.height / 2f) else Offset(size.width + r * 0.2f, size.height / 2f)
                            drawCircle(
                                color = Color.White.copy(alpha = 0.20f),
                                radius = r,
                                center = center
                            )
                        }
                        Column(
                            modifier = Modifier
                                .align(if (side < 0) Alignment.CenterStart else Alignment.CenterEnd)
                                .padding(horizontal = 36.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = if (side < 0) Icons.Default.FastRewind else Icons.Default.FastForward,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(34.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (side < 0) "-${seekAccumulatedSec}s" else "+${seekAccumulatedSec}s",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }
                    }
                }

                // Smooth Horizontal Swipe-to-Seek Pill near top: "04:15 (+00:25)" / "03:20 (-00:15)"
                AnimatedVisibility(
                    visible = isHorizontalSwipeSeeking,
                    enter = fadeIn(tween(80)),
                    exit = fadeOut(tween(160)),
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 64.dp)
                        .testTag("swipe_seek_pill")
                ) {
                    val sign = if (swipeSeekDeltaMs >= 0L) "+" else "-"
                    val absDelta = formatDuration(abs(swipeSeekDeltaMs))
                    Surface(
                        color = Color.Black.copy(alpha = 0.80f),
                        shape = RoundedCornerShape(22.dp)
                    ) {
                        Text(
                            text = "${formatDuration(swipeSeekTargetMs)} ($sign$absDelta)",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                        )
                    }
                }

                // Pinch-to-Zoom percentage pill positioned well above center (-72.dp), visible ONLY while pinching
                // and fading out 800ms after fingers release (never overlaps center Play/Pause button).
                AnimatedVisibility(
                    visible = showZoomPill,
                    enter = fadeIn(tween(100)),
                    exit = fadeOut(tween(220)),
                    modifier = Modifier
                        .align(Alignment.Center)
                        .offset(y = (-72).dp)
                        .testTag("pinch_zoom_pill")
                ) {
                    val zoomPct = (pinchZoomScale * 100f).roundToInt().coerceIn(100, 400)
                    Surface(
                        color = Color.Black.copy(alpha = 0.78f),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Text(
                            text = "$zoomPct%",
                            color = Color.White,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                        )
                    }
                }

                // 2.0x Long-Press Speed Floating Pill
                AnimatedVisibility(
                    visible = isTempBoost2x,
                    enter = fadeIn(tween(120)),
                    exit = fadeOut(tween(120)),
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 64.dp)
                ) {
                    Surface(
                        color = Color.Black.copy(alpha = 0.78f),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "2x Speed",
                                color = Color.White,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.Default.FastForward,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }

                // Transient Status Pill (Aspect / Sleep Timer / PiP info)
                AnimatedVisibility(
                    visible = statusBannerText != null && !isHorizontalSwipeSeeking && !isTempBoost2x,
                    enter = fadeIn(tween(120)),
                    exit = fadeOut(tween(200)),
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 64.dp)
                ) {
                    Surface(
                        color = Color.Black.copy(alpha = 0.78f),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Text(
                            text = statusBannerText.orEmpty(),
                            color = Color.White,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                        )
                    }
                }

                // Vertical Swipe Brightness / Volume HUD Slider
                AnimatedVisibility(
                    visible = activeSwipeHud != null,
                    enter = fadeIn(tween(100)),
                    exit = fadeOut(tween(200)),
                    modifier = Modifier
                        .align(if (activeSwipeHud == "BRIGHTNESS") Alignment.CenterStart else Alignment.CenterEnd)
                        .padding(horizontal = 24.dp)
                ) {
                    val level = if (activeSwipeHud == "BRIGHTNESS") brightnessLevel else volumeLevel
                    val icon = if (activeSwipeHud == "BRIGHTNESS") Icons.Default.BrightnessHigh else Icons.AutoMirrored.Filled.VolumeUp
                    Surface(
                        color = Color.Black.copy(alpha = 0.72f),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Box(
                                modifier = Modifier
                                    .width(5.dp)
                                    .height(92.dp)
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(Color.White.copy(alpha = 0.25f)),
                                contentAlignment = Alignment.BottomCenter
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .fillMaxHeight(level.coerceIn(0f, 1f))
                                        .background(Color.White)
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "${(level * 100).roundToInt()}%",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                // Buffering Spinner when HUD is hidden
                if (isBuffering && !controlsVisible && !isHorizontalSwipeSeeking) {
                    CircularProgressIndicator(
                        color = Color.White,
                        strokeWidth = 3.dp,
                        modifier = Modifier.size(44.dp)
                    )
                }

                // Center Transport & Scrubber inside video viewport in widescreen portrait;
                // full edge-to-edge HUD is rendered at the outer root Box when fullscreen/landscape/vertical.
                if (!isLandscape && !isVerticalVideo) {
                    AnimatedVisibility(
                        visible = controlsVisible && !isLocked,
                        enter = fadeIn(tween(180)),
                        exit = fadeOut(tween(220)),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        listOf(
                                            Color.Black.copy(alpha = 0.45f),
                                            Color.Black.copy(alpha = 0.20f),
                                            Color.Black.copy(alpha = 0.72f)
                                        )
                                    )
                                )
                        ) {
                            CenterTransportRow(
                                isPlaying = isPlaying,
                                isBuffering = isBuffering,
                                isEnded = isEnded,
                                hasPrev = hasPrev,
                                hasNext = hasNext,
                                onPrev = { if (hasPrev) onSelectVideo(playlist[currentIndex - 1]) },
                                onPlayPause = {
                                    ClodyPlaybackController.togglePlayPause(context)
                                },
                                onNext = { if (hasNext) onSelectVideo(playlist[currentIndex + 1]) },
                                modifier = Modifier.align(Alignment.Center)
                            )

                            BottomControlCluster(
                                currentPositionMs = if (isScrubbing) scrubPositionMs else currentPositionMs,
                                bufferedPositionMs = bufferedPositionMs,
                                durationMs = durationMs,
                                isScrubbing = isScrubbing,
                                isLocked = isLocked,
                                isLooping = isLooping,
                                resizeFit = resizeFit,
                                isLandscape = false,
                                abRepeatA = abRepeatA,
                                abRepeatB = abRepeatB,
                                sleepTimerSec = sleepTimerRemainingSec,
                                sleepEndOfVideo = sleepTimerEndOfVideo,
                                onScrubStart = { pos ->
                                    isScrubbing = true
                                    scrubPositionMs = pos
                                },
                                onScrubMove = { pos -> scrubPositionMs = pos },
                                onScrubEnd = { pos ->
                                    isScrubbing = false
                                    currentPositionMs = pos
                                    exoPlayer.seekTo(pos)
                                },
                                onToggleLock = {
                                    isLocked = true
                                    controlsVisible = false
                                    showUnlockPill = true
                                },
                                onToggleLoop = { isLooping = !isLooping },
                                onCycleAspect = { cycleAspectRatio() },
                                onRotateScreen = { toggleFullscreen() },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .align(Alignment.BottomCenter)
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }
        }

        // Full-Screen / Landscape / Vertical (9:16) HUD Overlay
        if (isLandscape || isVerticalVideo) {
            AnimatedVisibility(
                visible = controlsVisible && !isLocked,
                enter = fadeIn(tween(180)),
                exit = fadeOut(tween(220)),
                modifier = Modifier.fillMaxSize()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    Color.Black.copy(alpha = 0.70f),
                                    Color.Black.copy(alpha = 0.16f),
                                    Color.Black.copy(alpha = 0.78f)
                                )
                            )
                        )
                ) {
                    // Unified Top Bar
                    PlayerTopBar(
                        title = file.name,
                        subtitle = subtitleMeta,
                        subtitlesEnabled = subtitlesEnabled,
                        playbackSpeed = playbackSpeed,
                        origin = origin,
                        onBack = {
                            if (isLandscape) {
                                activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                            } else {
                                handleExplicitExit()
                            }
                        },
                        onCcClick = {
                            if (subtitleTracks.isEmpty()) {
                                subtitlesEnabled = !subtitlesEnabled
                                statusBannerText = if (subtitlesEnabled) "Captions Auto" else "Captions Off"
                            } else {
                                activeSubSheet = VideoMoreSubSheet.SUBTITLES
                                showMoreSheet = true
                            }
                        },
                        onSpeedClick = {
                            activeSubSheet = VideoMoreSubSheet.SPEED
                            showMoreSheet = true
                        },
                        onPipClick = { enterPipMode() },
                        onMoreClick = {
                            activeSubSheet = VideoMoreSubSheet.MAIN
                            showMoreSheet = true
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.TopCenter)
                            .statusBarsPadding()
                            .then(if (isLandscape) Modifier.displayCutoutPadding() else Modifier)
                    )

                    // Center Play/Pause + Prev/Next
                    CenterTransportRow(
                        isPlaying = isPlaying,
                        isBuffering = isBuffering,
                        isEnded = isEnded,
                        hasPrev = hasPrev,
                        hasNext = hasNext,
                        onPrev = { if (hasPrev) onSelectVideo(playlist[currentIndex - 1]) },
                        onPlayPause = {
                            ClodyPlaybackController.togglePlayPause(context)
                        },
                        onNext = { if (hasNext) onSelectVideo(playlist[currentIndex + 1]) },
                        modifier = Modifier.align(Alignment.Center)
                    )

                    // Bottom Control Bar with Safe Insets (Landscape navigationBarsPadding + displayCutoutPadding + bottom 20.dp)
                    BottomControlCluster(
                        currentPositionMs = if (isScrubbing) scrubPositionMs else currentPositionMs,
                        bufferedPositionMs = bufferedPositionMs,
                        durationMs = durationMs,
                        isScrubbing = isScrubbing,
                        isLocked = isLocked,
                        isLooping = isLooping,
                        resizeFit = resizeFit,
                        isLandscape = isLandscape,
                        abRepeatA = abRepeatA,
                        abRepeatB = abRepeatB,
                        sleepTimerSec = sleepTimerRemainingSec,
                        sleepEndOfVideo = sleepTimerEndOfVideo,
                        onScrubStart = { pos ->
                            isScrubbing = true
                            scrubPositionMs = pos
                        },
                        onScrubMove = { pos -> scrubPositionMs = pos },
                        onScrubEnd = { pos ->
                            isScrubbing = false
                            currentPositionMs = pos
                            exoPlayer.seekTo(pos)
                        },
                        onToggleLock = {
                            isLocked = true
                            controlsVisible = false
                            showUnlockPill = true
                        },
                        onToggleLoop = { isLooping = !isLooping },
                        onCycleAspect = { cycleAspectRatio() },
                        onRotateScreen = { toggleFullscreen() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.BottomCenter)
                            .navigationBarsPadding()
                            .then(
                                if (isLandscape) {
                                    Modifier.displayCutoutPadding().padding(horizontal = 16.dp).padding(bottom = 20.dp)
                                } else {
                                    Modifier.padding(horizontal = 14.dp, vertical = 12.dp)
                                }
                            )
                    )
                }
            }
        }

        // Portrait Widescreen Mode: Unified Top Bar & Bottom Quick-Action Pills outside the 16:9 viewport
        if (!isLandscape && !isVerticalVideo) {
            PlayerTopBar(
                title = file.name,
                subtitle = subtitleMeta,
                subtitlesEnabled = subtitlesEnabled,
                playbackSpeed = playbackSpeed,
                origin = origin,
                onBack = { handleExplicitExit() },
                onCcClick = {
                    if (subtitleTracks.isEmpty()) {
                        subtitlesEnabled = !subtitlesEnabled
                        statusBannerText = if (subtitlesEnabled) "Captions Auto" else "Captions Off"
                    } else {
                        activeSubSheet = VideoMoreSubSheet.SUBTITLES
                        showMoreSheet = true
                    }
                },
                onSpeedClick = {
                    activeSubSheet = VideoMoreSubSheet.SPEED
                    showMoreSheet = true
                },
                onPipClick = { enterPipMode() },
                onMoreClick = {
                    activeSubSheet = VideoMoreSubSheet.MAIN
                    showMoreSheet = true
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .statusBarsPadding()
            )

            // Quick-Action Bar below widescreen video in Portrait
            Surface(
                color = Color(0xFF141414),
                shape = RoundedCornerShape(28.dp),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 20.dp)
            ) {
                Row(
                    modifier = Modifier
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    DownloadOrSavedPill(
                        origin = origin,
                        onDownloadClick = { onDownloadToGallery(file) },
                        darkMode = true
                    )
                    QuickActionPill(
                        icon = if (file.isFavorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                        label = if (file.isFavorite) "Saved" else "Favorite",
                        tint = if (file.isFavorite) YouTubeCrimson else Color.White,
                        onClick = { onToggleFavorite(file) }
                    )
                    QuickActionPill(
                        icon = Icons.Default.CollectionsBookmark,
                        label = "Album",
                        onClick = { onAddToAlbum(file) }
                    )
                    QuickActionPill(
                        icon = Icons.Default.Share,
                        label = "Share",
                        onClick = { triggerShare() }
                    )
                }
            }
        }

        // Screen Locked Corner Unlock Button
        AnimatedVisibility(
            visible = isLocked && showUnlockPill,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .navigationBarsPadding()
                .then(if (isLandscape) Modifier.displayCutoutPadding() else Modifier)
                .padding(end = 20.dp, bottom = 24.dp)
                .testTag("player_unlock_pill")
        ) {
            Surface(
                color = Color.White,
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.clickable {
                    isLocked = false
                    showUnlockPill = false
                    controlsVisible = true
                }
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.LockOpen, contentDescription = "Unlock", tint = Color.Black, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Tap to Unlock", color = Color.Black, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                }
            }
        }
    }

    // Pro "More" Slide-Up Bottom Sheet (⋮)
    if (showMoreSheet) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(
            onDismissRequest = { showMoreSheet = false },
            sheetState = sheetState,
            containerColor = Color(0xFF1C1C1E),
            contentColor = Color.White
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 6.dp)
                    .navigationBarsPadding()
            ) {
                if (activeSubSheet != VideoMoreSubSheet.MAIN) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { activeSubSheet = VideoMoreSubSheet.MAIN }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                        }
                        Text(
                            text = when (activeSubSheet) {
                                VideoMoreSubSheet.SPEED -> "Playback Speed"
                                VideoMoreSubSheet.QUALITY -> "Streaming Quality"
                                VideoMoreSubSheet.SUBTITLES -> "Subtitles (CC)"
                                VideoMoreSubSheet.AUDIO_TRACK -> "Audio Track"
                                VideoMoreSubSheet.EQUALIZER -> "Equalizer & Boost"
                                VideoMoreSubSheet.SLEEP_TIMER -> "Sleep Timer"
                                VideoMoreSubSheet.AB_REPEAT -> "A-B Repeat Loop"
                                VideoMoreSubSheet.ASPECT_RATIO -> "Aspect Ratio"
                                VideoMoreSubSheet.MAIN -> "More Options"
                            },
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                } else {
                    Text(
                        text = "Player Controls & Tools",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                }

                when (activeSubSheet) {
                    VideoMoreSubSheet.MAIN -> {
                        val speedStr = if (abs(playbackSpeed - 1.0f) < 0.01f) "1.0x" else "${playbackSpeed}x"
                        val qualityStr = if (isCellularDataSaver) "Auto (Data Saver • 480p)" else "Auto (Wi-Fi: Max / Data: Saver)"
                        val ccStr = if (subtitlesEnabled) {
                            subtitleTracks.firstOrNull { it.isSelected }?.label ?: "On / Auto"
                        } else "Off"
                        val audioStr = audioTracks.firstOrNull { it.isSelected }?.label ?: "Default"
                        val sleepStr = when {
                            sleepTimerEndOfVideo -> "End of video"
                            sleepTimerRemainingSec > 0 -> "${(sleepTimerRemainingSec + 59) / 60}m left"
                            else -> "Off"
                        }
                        val abStr = when {
                            abRepeatA != null && abRepeatB != null -> "${formatDuration(abRepeatA!!)} -> ${formatDuration(abRepeatB!!)}"
                            abRepeatA != null -> "A: ${formatDuration(abRepeatA!!)}"
                            else -> "Off"
                        }

                        MoreSheetRow(
                            icon = Icons.Default.Speed,
                            title = "Playback speed",
                            value = speedStr,
                            onClick = { activeSubSheet = VideoMoreSubSheet.SPEED }
                        )
                        MoreSheetRow(
                            icon = Icons.Default.HighQuality,
                            title = "Quality",
                            value = qualityStr,
                            onClick = { activeSubSheet = VideoMoreSubSheet.QUALITY }
                        )
                        MoreSheetRow(
                            icon = Icons.Default.ClosedCaption,
                            title = "Subtitles",
                            value = ccStr,
                            onClick = { activeSubSheet = VideoMoreSubSheet.SUBTITLES }
                        )
                        MoreSheetRow(
                            icon = Icons.Default.Audiotrack,
                            title = "Audio track",
                            value = audioStr,
                            onClick = { activeSubSheet = VideoMoreSubSheet.AUDIO_TRACK }
                        )
                        MoreSheetRow(
                            icon = Icons.Default.GraphicEq,
                            title = "Equalizer & boost",
                            value = eqPreset.label,
                            onClick = { activeSubSheet = VideoMoreSubSheet.EQUALIZER }
                        )
                        MoreSheetRow(
                            icon = Icons.Default.Timer,
                            title = "Sleep timer",
                            value = sleepStr,
                            onClick = { activeSubSheet = VideoMoreSubSheet.SLEEP_TIMER }
                        )
                        MoreSheetRow(
                            icon = Icons.Default.Repeat,
                            title = "A-B repeat",
                            value = abStr,
                            onClick = { activeSubSheet = VideoMoreSubSheet.AB_REPEAT }
                        )
                        MoreSheetRow(
                            icon = Icons.Default.AspectRatio,
                            title = "Aspect ratio",
                            value = resizeFit.label,
                            onClick = { activeSubSheet = VideoMoreSubSheet.ASPECT_RATIO }
                        )
                        MoreSheetRow(
                            icon = Icons.Default.ScreenRotation,
                            title = "Rotate screen",
                            value = if (isLandscape) "Landscape" else "Portrait",
                            onClick = {
                                showMoreSheet = false
                                toggleFullscreen()
                            }
                        )
                        MoreSheetRow(
                            icon = Icons.Default.Info,
                            title = "File info",
                            value = formatFileSize(file.sizeBytes),
                            onClick = {
                                showMoreSheet = false
                                showFileInfoDialog = true
                            }
                        )
                        MoreSheetRow(
                            icon = if (origin == MediaPlaybackOrigin.LOCAL_DEVICE || origin == MediaPlaybackOrigin.PINNED_OFFLINE) {
                                Icons.Default.Check
                            } else {
                                Icons.Default.Download
                            },
                            title = "Save to phone",
                            value = if (origin == MediaPlaybackOrigin.LOCAL_DEVICE) "Saved ✓" else "100% Original Quality",
                            onClick = {
                                showMoreSheet = false
                                onDownloadToGallery(file)
                            }
                        )
                        MoreSheetRow(
                            icon = Icons.Default.Share,
                            title = "Share",
                            value = file.name,
                            onClick = {
                                showMoreSheet = false
                                triggerShare()
                            }
                        )
                        MoreSheetRow(
                            icon = Icons.Default.Delete,
                            title = "Delete",
                            value = "Move to Recycle Bin",
                            tint = CrimsonAlert,
                            onClick = {
                                showMoreSheet = false
                                showDeleteConfirmDialog = true
                            }
                        )
                    }

                    VideoMoreSubSheet.SPEED -> {
                        val speeds = listOf(0.25f, 0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f, 2.5f, 3.0f)
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            speeds.forEach { spd ->
                                val selected = abs(playbackSpeed - spd) < 0.01f
                                FilterChip(
                                    selected = selected,
                                    onClick = { playbackSpeed = spd },
                                    label = { Text(if (spd == 1.0f) "1.0x Normal" else "${spd}x") },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = Color.White,
                                        selectedLabelColor = Color.Black,
                                        containerColor = Color(0xFF2C2C2E),
                                        labelColor = Color.White
                                    )
                                )
                            }
                        }
                    }

                    VideoMoreSubSheet.QUALITY -> {
                        Text(
                            text = if (isCellularNetwork) {
                                "Active network: Mobile Data (Data Saver active: 480p max, low buffer)"
                            } else {
                                "Active network: Wi-Fi / Unmetered (Max Original Stream Quality)"
                            },
                            color = Color.White.copy(alpha = 0.75f),
                            fontSize = 13.sp,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )
                        val modes = listOf(
                            null to "Auto (Wi-Fi: Max / Data: Saver)",
                            false to "Always Max Quality",
                            true to "Always Data Saver (480p cap)"
                        )
                        modes.forEach { (overrideVal, label) ->
                            val selected = forceDataSaverMode == overrideVal
                            MoreSheetRow(
                                icon = if (selected) Icons.Default.Check else Icons.Default.HighQuality,
                                title = label,
                                value = if (selected) "Active" else "",
                                onClick = {
                                    forceDataSaverMode = overrideVal
                                    statusBannerText = label
                                }
                            )
                        }
                    }

                    VideoMoreSubSheet.SUBTITLES -> {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Enable Captions (CC)", fontWeight = FontWeight.SemiBold)
                            Switch(checked = subtitlesEnabled, onCheckedChange = { subtitlesEnabled = it })
                        }
                        if (subtitleTracks.isEmpty()) {
                            Text(
                                text = "No embedded subtitle tracks detected in this video stream.",
                                color = Color.White.copy(alpha = 0.65f),
                                fontSize = 13.sp,
                                modifier = Modifier.padding(vertical = 8.dp)
                            )
                        } else {
                            subtitleTracks.forEach { track ->
                                MoreSheetRow(
                                    icon = if (track.isSelected && subtitlesEnabled) Icons.Default.Check else Icons.Default.ClosedCaption,
                                    title = track.label,
                                    value = if (track.isSelected && subtitlesEnabled) "Selected" else "",
                                    onClick = {
                                        subtitlesEnabled = true
                                        trackSelector.parameters = trackSelector.buildUponParameters()
                                            .clearOverridesOfType(C.TRACK_TYPE_TEXT)
                                            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                                            .addOverride(TrackSelectionOverride(track.trackGroup, listOf(track.trackIndex)))
                                            .build()
                                    }
                                )
                            }
                        }
                    }

                    VideoMoreSubSheet.AUDIO_TRACK -> {
                        if (audioTracks.isEmpty()) {
                            Text(
                                text = "Single default audio stream.",
                                color = Color.White.copy(alpha = 0.65f),
                                fontSize = 13.sp,
                                modifier = Modifier.padding(vertical = 8.dp)
                            )
                        } else {
                            audioTracks.forEach { track ->
                                MoreSheetRow(
                                    icon = if (track.isSelected) Icons.Default.Check else Icons.Default.Audiotrack,
                                    title = track.label,
                                    value = if (track.isSelected) "Active" else "",
                                    onClick = {
                                        trackSelector.parameters = trackSelector.buildUponParameters()
                                            .clearOverridesOfType(C.TRACK_TYPE_AUDIO)
                                            .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, false)
                                            .addOverride(TrackSelectionOverride(track.trackGroup, listOf(track.trackIndex)))
                                            .build()
                                    }
                                )
                            }
                        }
                    }

                    VideoMoreSubSheet.EQUALIZER -> {
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            VideoEqPreset.entries.forEach { preset ->
                                FilterChip(
                                    selected = eqPreset == preset,
                                    onClick = { eqPreset = preset },
                                    label = { Text(preset.label) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = Color.White,
                                        selectedLabelColor = Color.Black,
                                        containerColor = Color(0xFF2C2C2E),
                                        labelColor = Color.White
                                    )
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(14.dp))
                        Text("Bass Boost (${(bassBoostStrength * 100).roundToInt()}%)", fontWeight = FontWeight.Medium)
                        Slider(
                            value = bassBoostStrength,
                            onValueChange = { bassBoostStrength = it },
                            colors = SliderDefaults.colors(
                                thumbColor = Color.White,
                                activeTrackColor = Color.White,
                                inactiveTrackColor = Color(0xFF3A3A3C)
                            )
                        )
                    }

                    VideoMoreSubSheet.SLEEP_TIMER -> {
                        val options = listOf(15, 30, 60)
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            options.forEach { mins ->
                                FilterChip(
                                    selected = !sleepTimerEndOfVideo && sleepTimerRemainingSec in ((mins - 1) * 60 + 1)..(mins * 60),
                                    onClick = {
                                        sleepTimerEndOfVideo = false
                                        sleepTimerRemainingSec = mins * 60
                                        statusBannerText = "Sleep timer set: ${mins}m"
                                    },
                                    label = { Text("${mins}m") },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = Color.White,
                                        selectedLabelColor = Color.Black,
                                        containerColor = Color(0xFF2C2C2E),
                                        labelColor = Color.White
                                    )
                                )
                            }
                            FilterChip(
                                selected = sleepTimerEndOfVideo,
                                onClick = {
                                    sleepTimerRemainingSec = 0
                                    sleepTimerEndOfVideo = true
                                    statusBannerText = "Sleep timer: End of video"
                                },
                                label = { Text("End of video") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color.White,
                                    selectedLabelColor = Color.Black,
                                    containerColor = Color(0xFF2C2C2E),
                                    labelColor = Color.White
                                )
                            )
                            FilterChip(
                                selected = !sleepTimerEndOfVideo && sleepTimerRemainingSec == 0,
                                onClick = {
                                    sleepTimerRemainingSec = 0
                                    sleepTimerEndOfVideo = false
                                    statusBannerText = "Sleep timer off"
                                },
                                label = { Text("Off") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color.White,
                                    selectedLabelColor = Color.Black,
                                    containerColor = Color(0xFF2C2C2E),
                                    labelColor = Color.White
                                )
                            )
                        }
                    }

                    VideoMoreSubSheet.AB_REPEAT -> {
                        Text(
                            text = "Loop a specific video segment cleanly between Point A and Point B.",
                            color = Color.White.copy(alpha = 0.7f),
                            fontSize = 13.sp,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = {
                                    val pos = exoPlayer.currentPosition.coerceAtLeast(0L)
                                    abRepeatA = pos
                                    if (abRepeatB != null && abRepeatB!! <= pos + 300L) {
                                        abRepeatB = null
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2C2C2E), contentColor = Color.White),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(abRepeatA?.let { "A: ${formatDuration(it)}" } ?: "Set A")
                            }
                            Button(
                                onClick = {
                                    val pos = exoPlayer.currentPosition.coerceAtLeast(0L)
                                    val startA = abRepeatA ?: 0L
                                    if (abRepeatA == null) abRepeatA = 0L
                                    if (pos > startA + 300L) {
                                        abRepeatB = pos
                                        exoPlayer.seekTo(startA)
                                    } else {
                                        statusBannerText = "Point B must be after Point A"
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2C2C2E), contentColor = Color.White),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(abRepeatB?.let { "B: ${formatDuration(it)}" } ?: "Set B")
                            }
                            OutlinedButton(
                                onClick = {
                                    abRepeatA = null
                                    abRepeatB = null
                                }
                            ) {
                                Text("Clear", color = Color.White)
                            }
                        }
                    }

                    VideoMoreSubSheet.ASPECT_RATIO -> {
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            VideoResizeFit.entries.forEach { fit ->
                                FilterChip(
                                    selected = resizeFit == fit,
                                    onClick = {
                                        resizeFit = fit
                                        if (fit == VideoResizeFit.NATIVE_100) {
                                            pinchZoomScale = 1.0f
                                        }
                                    },
                                    label = { Text(fit.label) },
                                    leadingIcon = if (resizeFit == fit) {
                                        { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                                    } else null,
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = Color.White,
                                        selectedLabelColor = Color.Black,
                                        containerColor = Color(0xFF2C2C2E),
                                        labelColor = Color.White
                                    )
                                )
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }

    if (showFileInfoDialog) {
        AlertDialog(
            onDismissRequest = { showFileInfoDialog = false },
            containerColor = Color(0xFF1C1C1E),
            titleContentColor = Color.White,
            textContentColor = Color.White.copy(alpha = 0.85f),
            title = { Text("File Details", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Name: ${file.name}")
                    Text("Size: ${formatFileSize(file.sizeBytes)}")
                    Text("Duration: ${formatDuration(durationMs)}")
                    if (videoWidth > 0 && videoHeight > 0) {
                        Text("Resolution: ${videoWidth}x${videoHeight}")
                    }
                    Text("Folder: ${file.folderPath}")
                    Text("Type: ${file.mimeType}")
                    Text("Source: ${origin.name.replace('_', ' ')}")
                }
            },
            confirmButton = {
                TextButton(onClick = { showFileInfoDialog = false }) {
                    Text("Close", color = Color.White)
                }
            }
        )
    }

    if (showDeleteConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = false },
            containerColor = Color(0xFF1C1C1E),
            titleContentColor = Color.White,
            textContentColor = Color.White.copy(alpha = 0.85f),
            title = { Text("Delete Video?", fontWeight = FontWeight.Bold) },
            text = { Text("Move \"${file.name}\" to Recycle Bin?") },
            confirmButton = {
                TextButton(onClick = {
                    showDeleteConfirmDialog = false
                    triggerDelete()
                }) {
                    Text("Delete", color = CrimsonAlert, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = false }) {
                    Text("Cancel", color = Color.White)
                }
            }
        )
    }
}

@Composable
private fun PlayerTopBar(
    title: String,
    subtitle: String,
    subtitlesEnabled: Boolean,
    playbackSpeed: Float,
    origin: MediaPlaybackOrigin,
    onBack: () -> Unit,
    onCcClick: () -> Unit,
    onSpeedClick: () -> Unit,
    onPipClick: () -> Unit,
    onMoreClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = onBack,
            modifier = Modifier.testTag("player_back_button")
        ) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
        }

        Column(modifier = Modifier.weight(1f).padding(end = 6.dp)) {
            Text(
                text = title,
                color = Color.White,
                fontWeight = FontWeight.SemiBold,
                fontSize = 15.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = subtitle,
                    color = Color.White.copy(alpha = 0.72f),
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (origin != MediaPlaybackOrigin.CLOUD_STREAM) {
                    Text(
                        text = "• Offline ✓",
                        color = EmeraldConnected,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        IconButton(
            onClick = onCcClick,
            modifier = Modifier.testTag("player_cc_button")
        ) {
            Icon(
                imageVector = Icons.Default.ClosedCaption,
                contentDescription = "Subtitles",
                tint = if (subtitlesEnabled) Color.White else Color.White.copy(alpha = 0.45f)
            )
        }

        Surface(
            color = Color.White.copy(alpha = 0.16f),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .clip(RoundedCornerShape(14.dp))
                .clickable(onClick = onSpeedClick)
                .testTag("player_speed_badge")
        ) {
            Text(
                text = if (abs(playbackSpeed - 1.0f) < 0.01f) "1x" else "${playbackSpeed}x",
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp)
            )
        }

        IconButton(
            onClick = onPipClick,
            modifier = Modifier.testTag("player_pip_button")
        ) {
            Icon(
                imageVector = Icons.Default.PictureInPictureAlt,
                contentDescription = "Picture in Picture",
                tint = Color.White
            )
        }

        IconButton(
            onClick = onMoreClick,
            modifier = Modifier.testTag("player_more_button")
        ) {
            Icon(
                imageVector = Icons.Default.MoreVert,
                contentDescription = "More options",
                tint = Color.White
            )
        }
    }
}

@Composable
private fun CenterTransportRow(
    isPlaying: Boolean,
    isBuffering: Boolean,
    isEnded: Boolean,
    hasPrev: Boolean,
    hasNext: Boolean,
    onPrev: () -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(28.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onPrev, enabled = hasPrev) {
            Icon(
                imageVector = Icons.Default.SkipPrevious,
                contentDescription = "Previous video",
                tint = if (hasPrev) Color.White else Color.White.copy(alpha = 0.35f),
                modifier = Modifier.size(34.dp)
            )
        }

        Box(
            modifier = Modifier
                .size(62.dp)
                .clip(CircleShape)
                .background(Color.Black.copy(alpha = 0.48f))
                .clickable(onClick = onPlayPause)
                .testTag("player_play_pause_button"),
            contentAlignment = Alignment.Center
        ) {
            if (isBuffering) {
                CircularProgressIndicator(
                    color = Color.White,
                    strokeWidth = 3.dp,
                    modifier = Modifier.size(34.dp)
                )
            } else {
                Icon(
                    imageVector = when {
                        isEnded -> Icons.Default.Replay
                        isPlaying -> Icons.Default.Pause
                        else -> Icons.Default.PlayArrow
                    },
                    contentDescription = if (isPlaying) "Pause" else "Play",
                    tint = Color.White,
                    modifier = Modifier.size(36.dp)
                )
            }
        }

        IconButton(onClick = onNext, enabled = hasNext) {
            Icon(
                imageVector = Icons.Default.SkipNext,
                contentDescription = "Next video",
                tint = if (hasNext) Color.White else Color.White.copy(alpha = 0.35f),
                modifier = Modifier.size(34.dp)
            )
        }
    }
}

@Composable
private fun BottomControlCluster(
    currentPositionMs: Long,
    bufferedPositionMs: Long,
    durationMs: Long,
    isScrubbing: Boolean,
    isLocked: Boolean,
    isLooping: Boolean,
    resizeFit: VideoResizeFit,
    isLandscape: Boolean,
    abRepeatA: Long?,
    abRepeatB: Long?,
    sleepTimerSec: Int,
    sleepEndOfVideo: Boolean,
    onScrubStart: (Long) -> Unit,
    onScrubMove: (Long) -> Unit,
    onScrubEnd: (Long) -> Unit,
    onToggleLock: () -> Unit,
    onToggleLoop: () -> Unit,
    onCycleAspect: () -> Unit,
    onRotateScreen: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "${formatDuration(currentPositionMs)} / ${formatDuration(durationMs)}",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
                if (abRepeatA != null && abRepeatB != null) {
                    Surface(
                        color = YouTubeCrimson.copy(alpha = 0.85f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(
                            text = "A-B",
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
                if (sleepTimerSec > 0 || sleepEndOfVideo) {
                    Surface(
                        color = Color.White.copy(alpha = 0.18f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(
                            text = if (sleepEndOfVideo) "Sleep: End" else "Sleep: ${formatDuration(sleepTimerSec * 1000L)}",
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                IconButton(
                    onClick = onToggleLock,
                    modifier = Modifier.size(40.dp).testTag("player_lock_button")
                ) {
                    Icon(
                        imageVector = if (isLocked) Icons.Default.LockOpen else Icons.Default.Lock,
                        contentDescription = "Lock screen",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
                IconButton(
                    onClick = onToggleLoop,
                    modifier = Modifier.size(40.dp).testTag("player_loop_button")
                ) {
                    Icon(
                        imageVector = if (isLooping) Icons.Default.RepeatOne else Icons.Default.Repeat,
                        contentDescription = "Loop video",
                        tint = if (isLooping) YouTubeCrimson else Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Surface(
                    color = Color.White.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .clickable(onClick = onCycleAspect)
                        .testTag("player_aspect_button")
                ) {
                    Text(
                        text = resizeFit.label,
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                    )
                }
                IconButton(
                    onClick = onRotateScreen,
                    modifier = Modifier.size(40.dp).testTag("player_fullscreen_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ScreenRotation,
                        contentDescription = if (isLandscape) "Rotate to portrait" else "Rotate to landscape",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        YouTubeTactileScrubber(
            currentPositionMs = currentPositionMs,
            bufferedPositionMs = bufferedPositionMs,
            durationMs = durationMs,
            isScrubbing = isScrubbing,
            abRepeatA = abRepeatA,
            abRepeatB = abRepeatB,
            onScrubStart = onScrubStart,
            onScrubMove = onScrubMove,
            onScrubEnd = onScrubEnd
        )
    }
}

@Composable
private fun MoreSheetRow(
    icon: ImageVector,
    title: String,
    value: String,
    tint: Color = Color.White,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = title, tint = tint.copy(alpha = 0.9f), modifier = Modifier.size(22.dp))
        Spacer(modifier = Modifier.width(14.dp))
        Text(
            text = title,
            color = tint,
            fontWeight = FontWeight.Medium,
            fontSize = 15.sp,
            modifier = Modifier.weight(1f)
        )
        if (value.isNotBlank()) {
            Text(
                text = value,
                color = Color.White.copy(alpha = 0.62f),
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(start = 8.dp)
            )
        }
    }
    HorizontalDivider(color = Color.White.copy(alpha = 0.08f))
}

@Composable
private fun QuickActionPill(
    icon: ImageVector,
    label: String,
    tint: Color = Color.White,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(label, color = tint, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun YouTubeTactileScrubber(
    currentPositionMs: Long,
    bufferedPositionMs: Long,
    durationMs: Long,
    isScrubbing: Boolean,
    abRepeatA: Long? = null,
    abRepeatB: Long? = null,
    onScrubStart: (Long) -> Unit,
    onScrubMove: (Long) -> Unit,
    onScrubEnd: (Long) -> Unit
) {
    val safeDuration = maxOf(1L, durationMs)
    val activeFraction = (currentPositionMs.toFloat() / safeDuration.toFloat()).coerceIn(0f, 1f)
    val bufferedFraction = (bufferedPositionMs.toFloat() / safeDuration.toFloat()).coerceIn(activeFraction, 1f)
    val thumbRadius by animateDpAsState(
        targetValue = if (isScrubbing) 10.dp else 6.dp,
        label = "scrubber_thumb"
    )
    val density = LocalDensity.current

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxWidth()
            .height(38.dp),
        contentAlignment = Alignment.Center
    ) {
        val widthPx = constraints.maxWidth.toFloat().coerceAtLeast(1f)

        // Floating live timestamp tooltip above finger while scrubbing
        if (isScrubbing) {
            val tooltipX = (activeFraction * widthPx - with(density) { 26.dp.toPx() })
                .coerceIn(0f, (widthPx - with(density) { 56.dp.toPx() }).coerceAtLeast(0f))
            Surface(
                color = Color(0xFF141414),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .offset { IntOffset(tooltipX.roundToInt(), -with(density) { 30.dp.roundToPx() }) }
            ) {
                Text(
                    text = formatDuration(currentPositionMs),
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }

        var dragTargetMs by remember { mutableLongStateOf(currentPositionMs) }
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(safeDuration) {
                    detectTapGestures { offset ->
                        val frac = (offset.x / widthPx).coerceIn(0f, 1f)
                        val target = (frac * safeDuration).toLong()
                        onScrubEnd(target)
                    }
                }
                .pointerInput(safeDuration) {
                    detectHorizontalDragGestures(
                        onDragStart = { offset ->
                            val frac = (offset.x / widthPx).coerceIn(0f, 1f)
                            dragTargetMs = (frac * safeDuration).toLong()
                            onScrubStart(dragTargetMs)
                        },
                        onHorizontalDrag = { change, _ ->
                            change.consume()
                            val frac = (change.position.x / widthPx).coerceIn(0f, 1f)
                            dragTargetMs = (frac * safeDuration).toLong()
                            onScrubMove(dragTargetMs)
                        },
                        onDragEnd = {
                            onScrubEnd(dragTargetMs)
                        },
                        onDragCancel = {
                            onScrubEnd(dragTargetMs)
                        }
                    )
                }
        ) {
            val cy = size.height / 2f
            val trackHeight = if (isScrubbing) 5.dp.toPx() else 3.5.dp.toPx()
            val top = cy - trackHeight / 2f

            // Background dark track
            drawRoundRect(
                color = Color.White.copy(alpha = 0.25f),
                topLeft = Offset(0f, top),
                size = Size(size.width, trackHeight),
                cornerRadius = CornerRadius(trackHeight / 2f)
            )
            // Buffered progress track (light gray)
            drawRoundRect(
                color = Color.White.copy(alpha = 0.55f),
                topLeft = Offset(0f, top),
                size = Size(size.width * bufferedFraction, trackHeight),
                cornerRadius = CornerRadius(trackHeight / 2f)
            )
            // Active fill (YouTube Crimson)
            drawRoundRect(
                color = YouTubeCrimson,
                topLeft = Offset(0f, top),
                size = Size(size.width * activeFraction, trackHeight),
                cornerRadius = CornerRadius(trackHeight / 2f)
            )
            // Optional A-B loop markers
            abRepeatA?.let { aPos ->
                val ax = (aPos.toFloat() / safeDuration.toFloat()).coerceIn(0f, 1f) * size.width
                drawCircle(color = Color.Yellow, radius = 4.dp.toPx(), center = Offset(ax, cy))
            }
            abRepeatB?.let { bPos ->
                val bx = (bPos.toFloat() / safeDuration.toFloat()).coerceIn(0f, 1f) * size.width
                drawCircle(color = Color.Cyan, radius = 4.dp.toPx(), center = Offset(bx, cy))
            }
            // Tactile scrubber dot
            drawCircle(
                color = YouTubeCrimson,
                radius = thumbRadius.toPx(),
                center = Offset(size.width * activeFraction, cy)
            )
        }
    }
}

fun formatDuration(ms: Long): String {
    val totalSec = (ms / 1000L).coerceAtLeast(0L)
    val hrs = totalSec / 3600L
    val mins = (totalSec % 3600L) / 60L
    val secs = totalSec % 60L
    return if (hrs > 0) {
        String.format("%d:%02d:%02d", hrs, mins, secs)
    } else {
        String.format("%02d:%02d", mins, secs)
    }
}
