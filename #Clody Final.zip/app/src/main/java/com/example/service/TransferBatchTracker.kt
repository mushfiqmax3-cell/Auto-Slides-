package com.example.service

import com.example.data.local.ClodyDao
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

typealias TransferBatchSummary = UploadBatchSummary

data class UploadBatchSummary(
    val totalCount: Int = 0,
    val completedCount: Int = 0,
    val currentFileName: String = "",
    val currentFileBytesSent: Long = 0L,
    val currentFileTotalBytes: Long = 0L,
    val speedBytesPerSec: Long = 0L,
    val activeParallelCount: Int = 0,
    val galleryActiveCount: Int = 0,
    val filesActiveCount: Int = 0,
    val isActive: Boolean = false,
    val isPausedForWifi: Boolean = false,
    val justCompleted: Boolean = false
) {
    val activeCount: Int
        get() = if (galleryActiveCount + filesActiveCount > 0) {
            galleryActiveCount + filesActiveCount
        } else if (isActive) {
            maxOf(activeParallelCount, totalCount - completedCount, 1)
        } else 0

    val totalBatchBytes: Long
        get() = currentFileTotalBytes

    val transferredBatchBytes: Long
        get() = currentFileBytesSent

    val combinedSpeedBytesPerSec: Long
        get() = speedBytesPerSec

    val overallFraction: Float
        get() {
            if (currentFileTotalBytes > 0L && (galleryActiveCount + filesActiveCount > 0 || totalCount <= 1)) {
                return (currentFileBytesSent.toFloat() / currentFileTotalBytes.toFloat()).coerceIn(0f, 1f)
            }
            if (totalCount <= 0) return 0f
            val currentFileFrac = if (currentFileTotalBytes > 0L) {
                (currentFileBytesSent.toFloat() / currentFileTotalBytes.toFloat()).coerceIn(0f, 1f)
            } else 0f
            return ((completedCount.toFloat() + currentFileFrac) / totalCount.toFloat()).coerceIn(0f, 1f)
        }

    val overallPercent: Int
        get() = (overallFraction * 100f).toInt().coerceIn(0, 100)
}

fun computeTransferBatchSummary(
    activeUploads: List<com.example.data.local.UploadTaskEntity>,
    activeDownloads: List<com.example.data.local.DownloadRecordEntity>,
    downloadSpeeds: Map<Long, Long>,
    completedBatchBytes: Long = 0L
): UploadBatchSummary {
    val activeCount = activeUploads.size + activeDownloads.size
    if (activeCount == 0) {
        return UploadBatchSummary()
    }
    val galleryCount = activeUploads.count { isGalleryMimeType(it.mimeType) } +
        activeDownloads.count { isGalleryMimeType(it.mimeType) }
    val filesCount = activeCount - galleryCount

    val totalBytes = completedBatchBytes +
        activeUploads.sumOf { it.sizeBytes.coerceAtLeast(0L) } +
        activeDownloads.sumOf { it.sizeBytes.coerceAtLeast(0L) }
    val transferredBytes = completedBatchBytes +
        activeUploads.sumOf { it.bytesUploaded.coerceIn(0L, it.sizeBytes.coerceAtLeast(0L)) } +
        activeDownloads.sumOf { it.progressBytes.coerceIn(0L, it.sizeBytes.coerceAtLeast(0L)) }
    val combinedSpeed = activeUploads.sumOf { it.speedBytesPerSec.coerceAtLeast(0L) } +
        activeDownloads.sumOf { (downloadSpeeds[it.id] ?: 0L).coerceAtLeast(0L) }

    val firstName = activeUploads.firstOrNull()?.fileName
        ?: activeDownloads.firstOrNull()?.fileName.orEmpty()

    return UploadBatchSummary(
        totalCount = activeCount,
        completedCount = 0,
        currentFileName = firstName,
        currentFileBytesSent = transferredBytes,
        currentFileTotalBytes = totalBytes,
        speedBytesPerSec = combinedSpeed,
        activeParallelCount = activeCount,
        galleryActiveCount = galleryCount,
        filesActiveCount = filesCount,
        isActive = true
    )
}

fun formatSpeed(bytesPerSec: Long): String {
    if (bytesPerSec <= 0L) return "0 KB/s"
    val kb = bytesPerSec / 1024.0
    if (kb < 1024.0) return String.format(Locale.US, "%.0f KB/s", kb)
    val mb = kb / 1024.0
    return String.format(Locale.US, "%.1f MB/s", mb)
}

fun isGalleryMimeType(mimeType: String): Boolean {
    return mimeType.startsWith("image/") || mimeType.startsWith("video/")
}

class TransferBatchTracker(
    @Suppress("UNUSED_PARAMETER") dao: ClodyDao? = null
) {
    val summary: StateFlow<UploadBatchSummary> get() = Companion.summary
    val batchSummary: StateFlow<TransferBatchSummary> get() = Companion.summary
    val downloadSpeeds: StateFlow<Map<Long, Long>> get() = Companion.downloadSpeeds
    val instantMatchEvents: SharedFlow<String> get() = Companion.instantMatchEvents

    fun updateDownloadSpeed(recordId: Long, speedBytesPerSec: Long) {
        Companion.updateDownloadSpeed(recordId, speedBytesPerSec)
    }

    fun clearDownloadSpeed(recordId: Long) {
        Companion.clearDownloadSpeed(recordId)
    }

    companion object {
        private val _summary = MutableStateFlow(UploadBatchSummary())
        val summary: StateFlow<UploadBatchSummary> = _summary.asStateFlow()

        private val _downloadSpeeds = MutableStateFlow<Map<Long, Long>>(emptyMap())
        val downloadSpeeds: StateFlow<Map<Long, Long>> = _downloadSpeeds.asStateFlow()

        private val _instantMatchEvents = MutableSharedFlow<String>(extraBufferCapacity = 16)
        val instantMatchEvents: SharedFlow<String> = _instantMatchEvents.asSharedFlow()

        fun updateDownloadSpeed(recordId: Long, speedBytesPerSec: Long) {
            _downloadSpeeds.value = _downloadSpeeds.value + (recordId to speedBytesPerSec)
        }

        fun clearDownloadSpeed(recordId: Long) {
            _downloadSpeeds.value = _downloadSpeeds.value - recordId
        }

        private data class ActiveItemProgress(
            val fileName: String,
            val bytesSent: Long,
            val totalBytes: Long,
            val speedBytesPerSec: Long
        )

        private val activeItems = ConcurrentHashMap<Long, ActiveItemProgress>()

        @Synchronized
        fun onBatchEnqueued(addedCount: Int, firstFileName: String) {
            if (addedCount <= 0) return
            val cur = _summary.value
            val baseTotal = if (cur.isActive) cur.totalCount + addedCount else addedCount
            val baseDone = if (cur.isActive) cur.completedCount else 0
            _summary.value = UploadBatchSummary(
                totalCount = baseTotal,
                completedCount = baseDone,
                currentFileName = cur.currentFileName.ifBlank { firstFileName },
                currentFileBytesSent = cur.currentFileBytesSent,
                currentFileTotalBytes = cur.currentFileTotalBytes,
                speedBytesPerSec = cur.speedBytesPerSec,
                activeParallelCount = activeItems.size.coerceAtLeast(1),
                isActive = true,
                isPausedForWifi = false,
                justCompleted = false
            )
        }

        @Synchronized
        fun onFileStarted(fileName: String, totalBytes: Long, pendingCountInDb: Int, taskId: Long = 0L) {
            if (taskId != 0L) {
                activeItems[taskId] = ActiveItemProgress(fileName, 0L, totalBytes, 0L)
            }
            val cur = _summary.value
            val total = maxOf(cur.totalCount, cur.completedCount + pendingCountInDb).coerceAtLeast(1)
            _summary.value = cur.copy(
                totalCount = total,
                currentFileName = fileName,
                currentFileBytesSent = 0L,
                currentFileTotalBytes = totalBytes,
                activeParallelCount = activeItems.size.coerceAtLeast(1),
                isActive = true,
                isPausedForWifi = false,
                justCompleted = false
            )
        }

        @Synchronized
        fun onFileProgress(
            fileName: String,
            bytesSent: Long,
            totalBytes: Long,
            speedBytesPerSec: Long,
            taskId: Long = 0L
        ) {
            if (taskId != 0L) {
                activeItems[taskId] = ActiveItemProgress(fileName, bytesSent, totalBytes, speedBytesPerSec)
            }
            val cur = _summary.value
            if (!cur.isActive) return

            val combinedSpeed = if (activeItems.isNotEmpty()) {
                activeItems.values.sumOf { it.speedBytesPerSec }
            } else {
                speedBytesPerSec
            }
            val combinedSent = if (activeItems.isNotEmpty()) {
                activeItems.values.sumOf { it.bytesSent }
            } else {
                bytesSent
            }
            val combinedTotal = if (activeItems.isNotEmpty()) {
                activeItems.values.sumOf { it.totalBytes }.coerceAtLeast(1L)
            } else {
                totalBytes
            }

            _summary.value = cur.copy(
                currentFileName = fileName,
                currentFileBytesSent = combinedSent,
                currentFileTotalBytes = combinedTotal,
                speedBytesPerSec = combinedSpeed,
                activeParallelCount = activeItems.size.coerceAtLeast(1),
                isPausedForWifi = false
            )
        }

        @Synchronized
        fun onFileCompleted(remainingInDb: Int, taskId: Long = 0L) {
            if (taskId != 0L) {
                activeItems.remove(taskId)
            }
            val cur = _summary.value
            val nextDone = cur.completedCount + 1
            val total = maxOf(cur.totalCount, nextDone + remainingInDb)
            if (remainingInDb <= 0 && activeItems.isEmpty()) {
                _summary.value = cur.copy(
                    totalCount = total,
                    completedCount = total,
                    currentFileBytesSent = cur.currentFileTotalBytes,
                    speedBytesPerSec = 0L,
                    activeParallelCount = 0,
                    isActive = false,
                    isPausedForWifi = false,
                    justCompleted = true
                )
            } else {
                _summary.value = cur.copy(
                    totalCount = total,
                    completedCount = nextDone,
                    currentFileBytesSent = 0L,
                    currentFileTotalBytes = 0L,
                    activeParallelCount = activeItems.size
                )
            }
        }

        @Synchronized
        fun setPausedForWifi(paused: Boolean) {
            val cur = _summary.value
            if (cur.isActive || paused) {
                _summary.value = cur.copy(
                    isPausedForWifi = paused,
                    speedBytesPerSec = if (paused) 0L else cur.speedBytesPerSec
                )
            }
        }

        fun notifyInstantCloudMatch(fileName: String) {
            _instantMatchEvents.tryEmit("Instant Cloud Match ✓ ($fileName)")
        }

        @Synchronized
        fun clearBanner() {
            activeItems.clear()
            _summary.value = UploadBatchSummary()
        }
    }
}
