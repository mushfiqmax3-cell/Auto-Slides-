package com.example.service

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import com.example.data.local.ClodyDao
import com.example.data.local.DownloadRecordEntity
import com.example.data.local.FileEntity
import com.example.data.local.UploadStatus
import com.example.data.local.UploadTaskEntity
import com.example.files.DeviceFileManager
import com.example.media.ClodyStreamCache
import com.example.media.LocalFirstResolver
import com.example.media.ThumbnailGenerator
import com.example.telegram.TelegramClientManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

data class UploadCandidate(
    val uri: Uri,
    val fileName: String,
    val mimeType: String,
    val sizeBytes: Long,
    val durationMs: Long,
    val extractedThumbnailPath: String?,
    val customThumbnailPath: String? = null,
    val originalDateMs: Long = System.currentTimeMillis()
) {
    val displayName: String
        get() = fileName
}

class TransferManager(
    private val context: Context,
    private val dao: ClodyDao,
    private val telegramClient: TelegramClientManager,
    private val settingsRepository: com.example.data.local.SettingsRepository? = null,
    private val transferBatchTracker: TransferBatchTracker? = null
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val activeDownloadJobs = ConcurrentHashMap<Long, Job>()
    private val deviceFileManager by lazy { DeviceFileManager(context) }
    private val originalDatesPrefs by lazy {
        context.getSharedPreferences("clody_orig_media_dates", Context.MODE_PRIVATE)
    }

    suspend fun prepareUploadCandidates(uris: List<Uri>): List<UploadCandidate> =
        withContext(Dispatchers.IO) {
            uris.mapIndexedNotNull { idx, uri ->
                val meta = resolveUriMetadata(uri, idx) ?: return@mapIndexedNotNull null
                val originalDateMs = deviceFileManager.extractOriginalMediaDateMs(uri)
                val thumbMeta = ThumbnailGenerator.generateForUri(
                    context = context,
                    uri = uri,
                    mimeType = meta.mimeType,
                    uniqueKey = "${meta.displayName}_${meta.sizeBytes}"
                )
                UploadCandidate(
                    uri = uri,
                    fileName = meta.displayName,
                    mimeType = meta.mimeType,
                    sizeBytes = meta.sizeBytes,
                    durationMs = thumbMeta.durationMs,
                    extractedThumbnailPath = thumbMeta.thumbnailPath,
                    originalDateMs = originalDateMs
                )
            }
        }

    suspend fun enqueueUploads(
        candidates: List<UploadCandidate>,
        folderId: Long?,
        folderPath: String,
        wifiOnly: Boolean? = null
    ) = withContext(Dispatchers.IO) {
        if (candidates.isEmpty()) return@withContext
        val effectiveWifiOnly = wifiOnly
            ?: runCatching { settingsRepository?.settingsFlow?.first()?.uploadWifiOnly }.getOrNull()
            ?: false
        val prefsEditor = originalDatesPrefs.edit()
        for (cand in candidates) {
            val uriStr = cand.uri.toString()
            if (cand.originalDateMs > 0L) {
                prefsEditor.putLong("uri_$uriStr", cand.originalDateMs)
                prefsEditor.putLong("ns_${cand.fileName}_${cand.sizeBytes}", cand.originalDateMs)
            }
            val task = UploadTaskEntity(
                fileName = cand.fileName,
                localUriString = uriStr,
                mimeType = cand.mimeType,
                sizeBytes = cand.sizeBytes,
                durationMs = cand.durationMs,
                folderId = folderId,
                folderPath = folderPath,
                extractedThumbnailPath = cand.extractedThumbnailPath,
                customThumbnailPath = cand.customThumbnailPath,
                status = UploadStatus.QUEUED.name,
                createdAt = cand.originalDateMs.takeIf { it > 0L } ?: System.currentTimeMillis()
            )
            dao.insertUploadTask(task)
        }
        prefsEditor.apply()
        TransferBatchTracker.onBatchEnqueued(
            addedCount = candidates.size,
            firstFileName = candidates.first().fileName
        )
        if (effectiveWifiOnly && !isWifiOrUnmeteredConnected()) {
            TransferBatchTracker.setPausedForWifi(true)
            dao.markActiveUploadsSystemPaused("Waiting for Wi-Fi")
            ClodyUploadWorker.enqueue(context, wifiOnly = true, replaceExisting = true)
        } else {
            TransferBatchTracker.setPausedForWifi(false)
            ClodyUploadService.start(context)
            ClodyUploadWorker.enqueue(context, wifiOnly = effectiveWifiOnly, replaceExisting = true)
        }
    }

    fun isWifiOrUnmeteredConnected(): Boolean {
        return runCatching {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
                ?: return false
            val net = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(net) ?: return false
            val hasInternet = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            val hasWifiOrEthernet = caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) ||
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
            hasInternet && hasWifiOrEthernet
        }.getOrDefault(false)
    }

    fun onUploadNetworkPolicyChanged(wifiOnly: Boolean) {
        scope.launch {
            if (ClodyUploadService.isRunning) {
                ClodyUploadService.notifyNetworkPolicyChanged(context)
            } else {
                val resumables = dao.getResumableOrActiveUploads()
                if (resumables.isNotEmpty()) {
                    if (wifiOnly && !isWifiOrUnmeteredConnected()) {
                        TransferBatchTracker.setPausedForWifi(true)
                        dao.markActiveUploadsSystemPaused("Waiting for Wi-Fi")
                        ClodyUploadWorker.enqueue(context, wifiOnly = true, replaceExisting = true)
                    } else {
                        TransferBatchTracker.setPausedForWifi(false)
                        dao.resumeSystemPausedUploads()
                        ClodyUploadService.start(context)
                        ClodyUploadWorker.enqueue(context, wifiOnly = wifiOnly, replaceExisting = true)
                    }
                }
            }
        }
    }

    suspend fun resumeInterruptedUploadsOnAppOpen() = withContext(Dispatchers.IO) {
        val resumables = dao.getResumableOrActiveUploads()
        if (resumables.isEmpty()) return@withContext
        val wifiOnly = runCatching { settingsRepository?.settingsFlow?.first()?.uploadWifiOnly }.getOrNull() ?: false
        if (wifiOnly && !isWifiOrUnmeteredConnected()) {
            TransferBatchTracker.onBatchEnqueued(
                addedCount = resumables.size,
                firstFileName = resumables.first().fileName
            )
            TransferBatchTracker.setPausedForWifi(true)
            dao.markActiveUploadsSystemPaused("Waiting for Wi-Fi")
            ClodyUploadWorker.enqueue(context, wifiOnly = true, replaceExisting = true)
        } else {
            TransferBatchTracker.setPausedForWifi(false)
            dao.resumeSystemPausedUploads()
            TransferBatchTracker.onBatchEnqueued(
                addedCount = resumables.size,
                firstFileName = resumables.first().fileName
            )
            ClodyUploadService.start(context)
            ClodyUploadWorker.enqueue(context, wifiOnly = wifiOnly, replaceExisting = true)
        }
    }

    /**
     * Looks up and consumes the recorded original device capture timestamp for an uploaded file
     * so Room preserves the exact MediaStore DATE_TAKEN / DATE_MODIFIED timestamp.
     */
    fun consumeRecordedOriginalDateMs(localUriString: String?, fileName: String, sizeBytes: Long): Long? {
        val uriKey = localUriString?.takeIf { it.isNotBlank() }?.let { "uri_$it" }
        val nsKey = "ns_${fileName}_${sizeBytes}"
        val matched = when {
            uriKey != null && originalDatesPrefs.contains(uriKey) -> originalDatesPrefs.getLong(uriKey, 0L)
            originalDatesPrefs.contains(nsKey) -> originalDatesPrefs.getLong(nsKey, 0L)
            else -> 0L
        }
        if (matched <= 0L) return null
        originalDatesPrefs.edit().apply {
            if (uriKey != null) remove(uriKey)
            remove(nsKey)
        }.apply()
        return matched
    }

    fun configureWifiAutoBackup(enabled: Boolean, onlyWhileCharging: Boolean) {
        ClodyUploadWorker.configureAutoBackupSchedule(
            context = context,
            enabled = enabled,
            onlyWhileCharging = onlyWhileCharging
        )
    }

    fun pauseUpload(taskId: Long) {
        scope.launch {
            val task = dao.getUploadTaskById(taskId)
            dao.pauseUploadByUser(taskId)
            if (task != null && task.tdFileId > 0) {
                telegramClient.cancelUploadFile(task.tdFileId)
            }
        }
    }

    fun resumeUpload(taskId: Long, wifiOnly: Boolean? = null) {
        scope.launch {
            val effectiveWifiOnly = wifiOnly
                ?: runCatching { settingsRepository?.settingsFlow?.first()?.uploadWifiOnly }.getOrNull()
                ?: false
            dao.updateUploadStatus(taskId, UploadStatus.QUEUED.name)
            if (effectiveWifiOnly && !isWifiOrUnmeteredConnected()) {
                TransferBatchTracker.setPausedForWifi(true)
                ClodyUploadWorker.enqueue(context, wifiOnly = true, replaceExisting = true)
            } else {
                TransferBatchTracker.setPausedForWifi(false)
                ClodyUploadService.start(context)
                ClodyUploadWorker.enqueue(context, wifiOnly = effectiveWifiOnly, replaceExisting = true)
            }
        }
    }

    fun cancelUpload(taskId: Long) {
        scope.launch {
            val existing = dao.getUploadTaskById(taskId)
            if (existing != null) {
                if (existing.tdFileId > 0) {
                    telegramClient.cancelUploadFile(existing.tdFileId)
                }
                existing.stagedFilePath?.let { p -> runCatching { File(p).delete() } }
            }
            dao.deleteUploadTaskById(taskId)
        }
    }

    fun cancelDownload(recordId: Long) {
        activeDownloadJobs.remove(recordId)?.cancel()
        transferBatchTracker?.clearDownloadSpeed(recordId)
        scope.launch {
            dao.deleteDownloadRecordById(recordId)
        }
    }

    fun exportToPublicStorage(
        file: FileEntity,
        onComplete: (Result<String>) -> Unit = {}
    ) {
        scope.launch {
            val res = downloadToPublicStorage(file)
            withContext(Dispatchers.Main) {
                onComplete(res)
            }
        }
    }

    /**
     * Explicit user-initiated download to public Android storage (MediaStore Images/Video/Downloads).
     * Always downloads the exact 100% Original Quality uncompressed file at max TDLib priority (32)
     * across both Wi-Fi and Mobile Data.
     */
    suspend fun downloadToPublicStorage(
        file: FileEntity,
        onProgress: (Float) -> Unit = {}
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val recordId = dao.insertDownloadRecord(
                DownloadRecordEntity(
                    fileId = file.id,
                    fileName = file.name,
                    sizeBytes = file.sizeBytes,
                    mimeType = file.mimeType,
                    status = "DOWNLOADING",
                    progressBytes = 0L
                )
            )

            val currentJob = kotlin.coroutines.coroutineContext[Job]
            if (currentJob != null) {
                activeDownloadJobs[recordId] = currentJob
            }
            val startMs = System.currentTimeMillis()
            val safeTempName = file.name.replace(Regex("[^a-zA-Z0-9._-]"), "_")
            val tempOut = File(context.cacheDir, "dl_${System.currentTimeMillis()}_$safeTempName")
            try {
                val pinnedCopy = file.pinnedOfflinePath?.let { File(it) }?.takeIf { it.exists() && it.length() > 0L }
                val cachedCopy = file.localCachePath?.let { File(it) }
                    ?.takeIf { it.exists() && !it.name.endsWith(".part") && it.length() >= file.sizeBytes && file.sizeBytes > 0L }

                if (pinnedCopy != null) {
                    pinnedCopy.copyTo(tempOut, overwrite = true)
                    onProgress(1f)
                } else if (cachedCopy != null) {
                    cachedCopy.copyTo(tempOut, overwrite = true)
                    onProgress(1f)
                } else {
                    val refBytes = hexToBytes(file.telegramFileReferenceHex)
                    var lastDbUpdateMs = 0L
                    var lastDbBytes = -1L

                    telegramClient.downloadOriginalFile(
                        documentId = file.telegramDocumentId,
                        accessHash = file.telegramAccessHash,
                        fileReference = refBytes,
                        expectedSizeBytes = file.sizeBytes,
                        destFile = tempOut,
                        onProgress = { downloadedBytes, totalBytes ->
                            val effectiveTotal = maxOf(totalBytes, file.sizeBytes, 1L)
                            val pct = (downloadedBytes.toFloat() / effectiveTotal.toFloat()).coerceIn(0f, 1f)
                            onProgress(pct)

                            val now = System.currentTimeMillis()
                            val elapsedSec = maxOf(0.1, (now - startMs) / 1000.0)
                            val speed = (downloadedBytes / elapsedSec).toLong()
                            transferBatchTracker?.updateDownloadSpeed(recordId, speed)

                            if (downloadedBytes != lastDbBytes && (now - lastDbUpdateMs >= 250L || downloadedBytes >= effectiveTotal)) {
                                lastDbUpdateMs = now
                                lastDbBytes = downloadedBytes
                                dao.updateDownloadRecord(
                                    DownloadRecordEntity(
                                        id = recordId,
                                        fileId = file.id,
                                        fileName = file.name,
                                        sizeBytes = effectiveTotal,
                                        mimeType = file.mimeType,
                                        status = "DOWNLOADING",
                                        progressBytes = downloadedBytes
                                    )
                                )
                            }
                        }
                    )
                }

                val savedLocation = saveFileToMediaStoreOrDownloads(tempOut, file.name, file.mimeType)
                val finalSize = maxOf(file.sizeBytes, tempOut.length())
                dao.updateDownloadRecord(
                    DownloadRecordEntity(
                        id = recordId,
                        fileId = file.id,
                        fileName = file.name,
                        sizeBytes = finalSize,
                        mimeType = file.mimeType,
                        publicPath = savedLocation,
                        status = "COMPLETED",
                        progressBytes = finalSize
                    )
                )
                savedLocation
            } catch (t: Throwable) {
                runCatching {
                    dao.updateDownloadRecord(
                        DownloadRecordEntity(
                            id = recordId,
                            fileId = file.id,
                            fileName = file.name,
                            sizeBytes = file.sizeBytes,
                            mimeType = file.mimeType,
                            status = "FAILED",
                            progressBytes = 0L
                        )
                    )
                }
                throw t
            } finally {
                activeDownloadJobs.remove(recordId)
                transferBatchTracker?.clearDownloadSpeed(recordId)
                tempOut.delete()
            }
        }
    }

    fun getSharedCacheDir(): File = File(context.cacheDir, "shared_cache").apply { mkdirs() }

    fun clearSharedCache(): Long {
        var freed = 0L
        getSharedCacheDir().listFiles()?.forEach { file ->
            val len = file.length()
            if (file.deleteRecursively()) {
                freed += len
            }
        }
        return freed
    }

    /**
     * Downloads or copies one or more selected files in parallel (priority = 32) strictly into
     * `cacheDir/shared_cache` for FileProvider sharing—NEVER writing to public Pictures/Downloads.
     */
    suspend fun prepareFilesInSharedCache(
        files: List<FileEntity>,
        onProgress: (completedCount: Int, totalCount: Int, currentName: String) -> Unit = { _, _, _ -> }
    ): Result<List<File>> = withContext(Dispatchers.IO) {
        runCatching {
            val distinctFiles = files.distinctBy { it.id }
            if (distinctFiles.isEmpty()) return@runCatching emptyList()

            val sharedDir = getSharedCacheDir()
            val semaphore = Semaphore(3)
            val completedCounter = AtomicInteger(0)
            val total = distinctFiles.size
            onProgress(0, total, distinctFiles.first().name)

            val prepared = coroutineScope {
                distinctFiles.map { file ->
                    async(Dispatchers.IO) {
                        semaphore.withPermit {
                            val safeName = file.name.replace(Regex("[^a-zA-Z0-9._-]"), "_")
                            val destFile = File(sharedDir, "${file.id}_$safeName")
                            if (destFile.exists() && (file.sizeBytes <= 0L || destFile.length() >= file.sizeBytes)) {
                                val done = completedCounter.incrementAndGet()
                                onProgress(done, total, file.name)
                                return@withPermit destFile
                            }

                            val pinned = file.pinnedOfflinePath?.let(::File)?.takeIf { it.exists() && it.length() > 0L }
                            val streamCached = file.localCachePath?.let(::File)
                                ?.takeIf { it.exists() && !it.name.endsWith(".part") && (file.sizeBytes <= 0L || it.length() >= file.sizeBytes) }
                                ?: ClodyStreamCache.getCachedVideoFile(context, file)
                                    .takeIf { ClodyStreamCache.isFullyCached(context, file) }

                            when {
                                pinned != null -> {
                                    pinned.copyTo(destFile, overwrite = true)
                                }
                                streamCached != null -> {
                                    streamCached.copyTo(destFile, overwrite = true)
                                }
                                else -> {
                                    var copiedFromLocal = false
                                    val localUriStr = file.localSourceUri
                                    if (!localUriStr.isNullOrBlank()) {
                                        val parsed = runCatching { Uri.parse(localUriStr) }.getOrNull()
                                        if (parsed != null && LocalFirstResolver.canReadLocalUri(context, parsed)) {
                                            context.contentResolver.openInputStream(parsed)?.use { input ->
                                                FileOutputStream(destFile).use { out -> input.copyTo(out) }
                                            }
                                            copiedFromLocal = destFile.exists() && destFile.length() > 0L
                                        }
                                    }
                                    if (!copiedFromLocal) {
                                        check(file.telegramDocumentId != 0L) {
                                            "Cloud file reference missing for ${file.name}"
                                        }
                                        val refBytes = hexToBytes(file.telegramFileReferenceHex)
                                        telegramClient.downloadOriginalFile(
                                            documentId = file.telegramDocumentId,
                                            accessHash = file.telegramAccessHash,
                                            fileReference = refBytes,
                                            expectedSizeBytes = file.sizeBytes,
                                            destFile = destFile
                                        )
                                    }
                                }
                            }

                            val done = completedCounter.incrementAndGet()
                            onProgress(done, total, file.name)
                            destFile
                        }
                    }
                }.awaitAll()
            }
            prepared.filter { it.exists() && it.length() > 0L }
        }
    }

    private fun saveFileToMediaStoreOrDownloads(sourceFile: File, displayName: String, mimeType: String): String {
        val resolver = context.contentResolver
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val (collection, relativePath) = when {
                mimeType.startsWith("image/") ->
                    MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) to "${Environment.DIRECTORY_PICTURES}/Clody"
                mimeType.startsWith("video/") ->
                    MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) to "${Environment.DIRECTORY_MOVIES}/Clody"
                else ->
                    MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) to "${Environment.DIRECTORY_DOWNLOADS}/Clody"
            }

            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, displayName)
                put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }

            val itemUri = resolver.insert(collection, values)
            if (itemUri != null) {
                resolver.openOutputStream(itemUri)?.use { out ->
                    sourceFile.inputStream().use { input -> input.copyTo(out) }
                }
                values.clear()
                values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                resolver.update(itemUri, values, null, null)
                runCatching {
                    val publicBase = Environment.getExternalStoragePublicDirectory(relativePath.substringBefore('/'))
                    val probableFile = File(publicBase, "Clody/$displayName")
                    if (probableFile.exists()) {
                        MediaScannerConnection.scanFile(context, arrayOf(probableFile.absolutePath), arrayOf(mimeType), null)
                    }
                }
                return "$relativePath/$displayName"
            }
        }

        val fallbackDir = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            "Clody"
        ).apply { mkdirs() }
        val target = File(fallbackDir, displayName)
        sourceFile.copyTo(target, overwrite = true)
        MediaScannerConnection.scanFile(context, arrayOf(target.absolutePath), arrayOf(mimeType), null)
        return target.absolutePath
    }

    private data class UriMeta(val displayName: String, val sizeBytes: Long, val mimeType: String)

    private fun resolveUriMetadata(uri: Uri, fallbackIdx: Int): UriMeta? {
        if (uri.scheme == "file") {
            val f = File(uri.path ?: return null)
            if (!f.exists()) return null
            val ext = f.extension.lowercase()
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
            return UriMeta(f.name, f.length(), mime)
        }

        var name = "file_${System.currentTimeMillis()}_$fallbackIdx"
        var size = 0L
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
            if (cursor.moveToFirst()) {
                if (nameIdx >= 0) cursor.getString(nameIdx)?.let { name = it }
                if (sizeIdx >= 0 && !cursor.isNull(sizeIdx)) size = cursor.getLong(sizeIdx)
            }
        }
        if (size <= 0L) {
            runCatching {
                context.contentResolver.openAssetFileDescriptor(uri, "r")?.use { afd ->
                    if (afd.length > 0L) size = afd.length
                }
            }
        }
        val ext = name.substringAfterLast('.', "").lowercase()
        val mime = context.contentResolver.getType(uri)
            ?: MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
            ?: "application/octet-stream"
        return UriMeta(name, size, mime)
    }

    private fun hexToBytes(hex: String): ByteArray {
        if (hex.isEmpty() || hex.length % 2 != 0) return ByteArray(0)
        return ByteArray(hex.length / 2) { i ->
            hex.substring(i * 2, i * 2 + 2).toInt(16).toByte()
        }
    }
}
