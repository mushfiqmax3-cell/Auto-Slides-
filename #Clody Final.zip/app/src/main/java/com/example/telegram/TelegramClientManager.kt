package com.example.telegram

import android.content.Context
import android.os.Build
import com.example.data.local.ClodyDao
import com.example.data.local.FileEntity
import com.example.data.local.FolderEntity
import com.example.data.local.GalleryAlbumEntity
import com.example.data.local.SecureStorage
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import org.drinkless.tdlib.Client
import org.drinkless.tdlib.TdApi
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

sealed interface TelegramConnectionState {
    data class Disconnected(val reason: String? = null) : TelegramConnectionState
    data class Connecting(val dcId: Int) : TelegramConnectionState
    data class Connected(val dcId: Int, val userDisplayName: String?) : TelegramConnectionState
}

sealed interface TelegramAuthStep {
    data object VerifyApiCredentials : TelegramAuthStep
    data class EnterPhoneNumber(val apiId: Int, val apiHash: String) : TelegramAuthStep
    data class AwaitingOtp(val phoneNumber: String, val phoneCodeHash: String) : TelegramAuthStep
    data class AwaitingPassword(val hint: String) : TelegramAuthStep
    data class Authorized(val displayName: String, val phoneNumber: String) : TelegramAuthStep
}

enum class VerifyOtpOutcome {
    AUTHORIZED,
    NEEDS_TWO_FACTOR
}

data class TelegramUserProfile(
    val userId: Long,
    val firstName: String,
    val lastName: String,
    val username: String?,
    val phoneNumber: String?,
    val avatarPath: String? = null
) {
    val fullName: String
        get() = listOf(firstName, lastName).filter { it.isNotBlank() }.joinToString(" ")
            .ifBlank { phoneNumber?.takeIf { it.isNotBlank() } ?: "Telegram User" }

    val handleOrPhone: String
        get() = when {
            !username.isNullOrBlank() -> "@$username"
            !phoneNumber.isNullOrBlank() -> phoneNumber
            else -> "Telegram Cloud"
        }

    val initials: String
        get() {
            val f = firstName.firstOrNull()?.uppercaseChar()
            val l = lastName.firstOrNull()?.uppercaseChar()
            return when {
                f != null && l != null -> "$f$l"
                f != null -> "$f"
                else -> "TG"
            }
        }
}

data class TelegramUploadedDocument(
    val messageId: Int,
    val documentId: Long,
    val accessHash: Long,
    val fileReference: ByteArray,
    val dcId: Int,
    val mimeType: String,
    val sizeBytes: Long,
    val miniThumbnailBase64: String? = null
)

@Serializable
data class CloudIndexSnapshot(
    val version: Int = 2,
    val updatedAt: Long = System.currentTimeMillis(),
    val folders: List<FolderEntity> = emptyList(),
    val albums: List<GalleryAlbumEntity> = emptyList(),
    val files: List<FileEntity> = emptyList()
)

class TelegramTdException(
    val code: Int,
    val rawMessage: String,
    val userMessage: String
) : Exception(userMessage)

class TelegramClientManager(
    private val context: Context,
    private val secureStorage: SecureStorage,
    private val dao: ClodyDao
) {
    companion object {
        const val STANDARD_MAX_FILE_BYTES: Long = 2_000L * 1024L * 1024L // 2 GB (4000 parts of 512 KB)
        const val PREMIUM_MAX_FILE_BYTES: Long = 4_000L * 1024L * 1024L // 4 GB (8000 parts of 512 KB)
        const val DEFAULT_CHUNK_SIZE: Int = 512 * 1024 // 512 KB streaming chunk size

        fun formatTdError(error: TdApi.Error): String {
            val raw = error.message?.trim().orEmpty()
            return when {
                raw.equals("API_ID_INVALID", ignoreCase = true) ->
                    "API_ID_INVALID: Your Telegram API ID or API Hash was rejected by Telegram."
                raw.equals("API_HASH_INVALID", ignoreCase = true) ->
                    "API_HASH_INVALID: Your 32-character Telegram API Hash is invalid."
                raw.equals("PHONE_NUMBER_INVALID", ignoreCase = true) ->
                    "PHONE_NUMBER_INVALID: Enter a valid phone number in international format (e.g. +8801...)."
                raw.equals("PHONE_NUMBER_BANNED", ignoreCase = true) ->
                    "PHONE_NUMBER_BANNED: This phone number is restricted by Telegram."
                raw.equals("PHONE_CODE_INVALID", ignoreCase = true) ->
                    "PHONE_CODE_INVALID: The verification code you entered is incorrect."
                raw.equals("PHONE_CODE_EXPIRED", ignoreCase = true) ->
                    "PHONE_CODE_EXPIRED: The verification code has expired. Tap Resend Code."
                raw.equals("PASSWORD_HASH_INVALID", ignoreCase = true) ->
                    "PASSWORD_HASH_INVALID: Incorrect 2FA cloud password."
                raw.startsWith("FLOOD_WAIT_", ignoreCase = true) -> {
                    val secs = raw.substringAfter("FLOOD_WAIT_").filter(Char::isDigit).toIntOrNull()
                    if (secs != null) {
                        "FLOOD_WAIT_$secs: Too many attempts. Please wait $secs seconds before trying again."
                    } else {
                        "$raw: Too many attempts. Please wait before trying again."
                    }
                }
                raw.startsWith("CHANNELS_TOO_MUCH", ignoreCase = true) ->
                    "CHANNELS_TOO_MUCH: Channel limit reached; using Saved Messages as fallback."
                raw.isNotBlank() ->
                    if (error.code > 0 && !raw.contains("code ${error.code}")) "$raw (code ${error.code})" else raw
                else -> "Telegram error (code ${error.code})"
            }
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val sessionMutex = Mutex()
    private val indexSyncMutex = Mutex()
    private val clientLock = Any()
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    @Volatile
    private var tdClient: Client? = null

    @Volatile
    private var isPremiumAccount: Boolean = false

    private val _tdAuthorizationState = MutableStateFlow<TdApi.AuthorizationState?>(null)
    private val fileProgressListeners = ConcurrentHashMap<Int, (TdApi.File) -> Unit>()
    private val pendingMessageSends = ConcurrentHashMap<Long, CompletableDeferred<TdApi.Message>>()
    private val remoteToLocalFileIdCache = ConcurrentHashMap<String, Int>()
    private val accessHashToLocalFileIdCache = ConcurrentHashMap<Long, Int>()
    private val thumbnailSemaphore = Semaphore(3)
    private val miniThumbnailBytesCache = ConcurrentHashMap<Long, ByteArray>()
    private val thumbnailFileIdCache = ConcurrentHashMap<Long, Int>()
    private var pendingParameterInit: CompletableDeferred<Unit>? = null

    private val _connectionState = MutableStateFlow<TelegramConnectionState>(
        TelegramConnectionState.Disconnected(null)
    )
    val connectionState: StateFlow<TelegramConnectionState> = _connectionState.asStateFlow()

    private val _authStep = MutableStateFlow<TelegramAuthStep>(
        if (secureStorage.isLoggedIn()) {
            TelegramAuthStep.Authorized(
                displayName = secureStorage.getUserDisplayName() ?: "Telegram User",
                phoneNumber = secureStorage.getPhoneNumber() ?: ""
            )
        } else {
            TelegramAuthStep.VerifyApiCredentials
        }
    )
    val authStep: StateFlow<TelegramAuthStep> = _authStep.asStateFlow()

    private val _userProfile = MutableStateFlow<TelegramUserProfile?>(
        if (secureStorage.isLoggedIn()) {
            TelegramUserProfile(
                userId = secureStorage.getUserId(),
                firstName = secureStorage.getFirstName().ifBlank { secureStorage.getUserDisplayName().orEmpty() },
                lastName = secureStorage.getLastName(),
                username = secureStorage.getUsername(),
                phoneNumber = secureStorage.getPhoneNumber(),
                avatarPath = secureStorage.getAvatarPath()
            )
        } else null
    )
    val userProfile: StateFlow<TelegramUserProfile?> = _userProfile.asStateFlow()

    private var pendingPhone: String = secureStorage.getPhoneNumber().orEmpty()

    private val updateHandler = Client.ResultHandler { obj ->
        when (obj) {
            is TdApi.UpdateAuthorizationState -> handleAuthorizationState(obj.authorizationState)
            is TdApi.UpdateConnectionState -> handleConnectionState(obj.state)
            is TdApi.UpdateFile -> handleFileUpdate(obj.file)
            is TdApi.UpdateMessageSendSucceeded -> {
                pendingMessageSends.remove(obj.oldMessageId)?.complete(obj.message)
            }
            is TdApi.UpdateMessageSendFailed -> {
                val err = obj.error ?: TdApi.Error(500, "Message send failed")
                pendingMessageSends.remove(obj.oldMessageId)?.completeExceptionally(
                    TelegramTdException(err.code, err.message.orEmpty(), formatTdError(err))
                )
            }
            is TdApi.UpdateNewMessage -> {
                // Keep internal file cache updated if new document arrives in storage channel
                val msg = obj.message
                val docFile = extractTdFileFromMessage(msg)
                if (docFile != null && !docFile.remote?.id.isNullOrBlank() && docFile.id != 0) {
                    remoteToLocalFileIdCache[docFile.remote.id] = docFile.id
                }
            }
        }
    }

    init {
        if (secureStorage.isLoggedIn() && secureStorage.getApiId() != null) {
            scope.launch { runCatching { reconnectIfAuthorized() } }
        }
    }

    private fun getOrCreateTdClient(): Client {
        synchronized(clientLock) {
            val existing = tdClient
            if (existing != null) return existing
            Client.setLogMessageHandler(1, null)
            val created = Client.create(
                updateHandler,
                { _ -> },
                { _ -> }
            )
            created.send(TdApi.SetLogVerbosityLevel(1), null)
            tdClient = created
            return created
        }
    }

    private fun buildTdlibParameters(apiId: Int, apiHash: String): TdApi.SetTdlibParameters {
        val dbDir = File(context.filesDir, "tdlib_db").apply { mkdirs() }.absolutePath
        val filesDir = File(context.filesDir, "tdlib_files").apply { mkdirs() }.absolutePath
        val lang = Locale.getDefault().language.ifBlank { "en" }
        val model = "${Build.MANUFACTURER} ${Build.MODEL}".trim().ifBlank { "Android Device" }
        val sysVer = "Android ${Build.VERSION.RELEASE ?: "14"}"

        return TdApi.SetTdlibParameters(
            /* useTestDc = */ false,
            /* databaseDirectory = */ dbDir,
            /* filesDirectory = */ filesDir,
            /* databaseEncryptionKey = */ ByteArray(0),
            /* useFileDatabase = */ true,
            /* useChatInfoDatabase = */ true,
            /* useMessageDatabase = */ true,
            /* useSecretChats = */ false,
            /* apiId = */ apiId,
            /* apiHash = */ apiHash,
            /* systemLanguageCode = */ lang,
            /* deviceModel = */ model,
            /* systemVersion = */ sysVer,
            /* applicationVersion = */ "1.0.0"
        )
    }

    private fun handleAuthorizationState(state: TdApi.AuthorizationState?) {
        if (state == null) return
        _tdAuthorizationState.value = state

        when (state) {
            is TdApi.AuthorizationStateWaitTdlibParameters -> {
                val apiId = secureStorage.getApiId()
                val apiHash = secureStorage.getApiHash()
                if (apiId != null && apiId > 0 && !apiHash.isNullOrBlank()) {
                    val params = buildTdlibParameters(apiId, apiHash)
                    tdClient?.send(params) { result ->
                        if (result is TdApi.Error) {
                            val ex = TelegramTdException(result.code, result.message.orEmpty(), formatTdError(result))
                            pendingParameterInit?.completeExceptionally(ex)
                            _connectionState.value = TelegramConnectionState.Disconnected(ex.userMessage)
                        } else {
                            pendingParameterInit?.complete(Unit)
                        }
                    }
                }
            }

            is TdApi.AuthorizationStateWaitPhoneNumber -> {
                pendingParameterInit?.complete(Unit)
                val apiId = secureStorage.getApiId() ?: 0
                val apiHash = secureStorage.getApiHash().orEmpty()
                _connectionState.value = TelegramConnectionState.Connected(
                    dcId = secureStorage.getActiveDc(),
                    userDisplayName = null
                )
                if (apiId > 0 && apiHash.isNotBlank()) {
                    _authStep.value = TelegramAuthStep.EnterPhoneNumber(apiId, apiHash)
                } else {
                    _authStep.value = TelegramAuthStep.VerifyApiCredentials
                }
            }

            is TdApi.AuthorizationStateWaitCode -> {
                pendingParameterInit?.complete(Unit)
                val phone = state.codeInfo?.phoneNumber?.takeIf { it.isNotBlank() }
                    ?.let { if (it.startsWith("+")) it else "+$it" }
                    ?: pendingPhone.ifBlank { secureStorage.getPhoneNumber().orEmpty() }
                pendingPhone = phone
                _authStep.value = TelegramAuthStep.AwaitingOtp(phone, "tdlib_code_session")
            }

            is TdApi.AuthorizationStateWaitPassword -> {
                pendingParameterInit?.complete(Unit)
                _authStep.value = TelegramAuthStep.AwaitingPassword(state.passwordHint.orEmpty())
            }

            is TdApi.AuthorizationStateReady -> {
                pendingParameterInit?.complete(Unit)
                secureStorage.setLoggedIn(true)
                val displayName = secureStorage.getUserDisplayName() ?: "Telegram User"
                val phone = secureStorage.getPhoneNumber().orEmpty()
                _connectionState.value = TelegramConnectionState.Connected(
                    dcId = secureStorage.getActiveDc(),
                    userDisplayName = displayName
                )
                _authStep.value = TelegramAuthStep.Authorized(displayName, phone)
                scope.launch {
                    runCatching { fetchCurrentUserProfileInternal() }
                    runCatching { ensureStorageChannelInternal() }
                }
            }

            is TdApi.AuthorizationStateLoggingOut,
            is TdApi.AuthorizationStateClosing -> {
                _connectionState.value = TelegramConnectionState.Disconnected(null)
            }

            is TdApi.AuthorizationStateClosed -> {
                synchronized(clientLock) {
                    tdClient = null
                }
                if (!secureStorage.isLoggedIn()) {
                    _connectionState.value = TelegramConnectionState.Disconnected(null)
                    _authStep.value = TelegramAuthStep.VerifyApiCredentials
                }
            }
        }
    }

    private fun handleConnectionState(state: TdApi.ConnectionState?) {
        val dc = secureStorage.getActiveDc()
        when (state) {
            is TdApi.ConnectionStateWaitingForNetwork,
            is TdApi.ConnectionStateConnectingToProxy,
            is TdApi.ConnectionStateConnecting,
            is TdApi.ConnectionStateUpdating -> {
                _connectionState.value = TelegramConnectionState.Connecting(dc)
            }
            is TdApi.ConnectionStateReady -> {
                _connectionState.value = TelegramConnectionState.Connected(
                    dcId = dc,
                    userDisplayName = secureStorage.getUserDisplayName()
                )
            }
        }
    }

    private fun handleFileUpdate(file: TdApi.File?) {
        if (file == null) return
        if (!file.remote?.id.isNullOrBlank() && file.id != 0) {
            remoteToLocalFileIdCache[file.remote.id] = file.id
        }
        fileProgressListeners[file.id]?.invoke(file)
    }

    private suspend fun <T : TdApi.Object> sendTdQuery(query: TdApi.Function<T>): T =
        suspendCancellableCoroutine { cont ->
            val client = getOrCreateTdClient()
            client.send(query) { result ->
                if (!cont.isActive) return@send
                when (result) {
                    is TdApi.Error -> {
                        cont.resumeWithException(
                            TelegramTdException(
                                code = result.code,
                                rawMessage = result.message.orEmpty(),
                                userMessage = formatTdError(result)
                            )
                        )
                    }
                    else -> {
                        @Suppress("UNCHECKED_CAST")
                        val typed = result as? T
                        if (typed != null) {
                            cont.resume(typed)
                        } else {
                            cont.resumeWithException(
                                IllegalStateException(
                                    "Unexpected TDLib response type: ${result?.javaClass?.simpleName}"
                                )
                            )
                        }
                    }
                }
            }
        }

    suspend fun reconnectIfAuthorized(): Result<Unit> = sessionMutex.withLock {
        val apiId = secureStorage.getApiId()
            ?: return Result.failure(IllegalStateException("Missing API ID"))
        val apiHash = secureStorage.getApiHash()
            ?: return Result.failure(IllegalStateException("Missing API Hash"))
        if (!secureStorage.isLoggedIn()) {
            return Result.failure(IllegalStateException("Not logged in"))
        }

        return runCatching {
            withContext(Dispatchers.IO) {
                _connectionState.value = TelegramConnectionState.Connecting(secureStorage.getActiveDc())
                val state = sendTdQuery(TdApi.GetAuthorizationState())
                handleAuthorizationState(state)
                if (state is TdApi.AuthorizationStateWaitTdlibParameters) {
                    sendTdQuery(buildTdlibParameters(apiId, apiHash))
                }
                ensureStorageChannelInternal()
                runCatching { fetchCurrentUserProfileInternal() }
                Unit
            }
        }.onFailure { err ->
            _connectionState.value = TelegramConnectionState.Disconnected(err.message ?: "Connection failed")
        }
    }

    /**
     * Step 1: Validate API ID (positive integer) and API Hash (32 hex chars),
     * save them in SecureStorage, and initialize TDLib via SetTdlibParameters.
     */
    suspend fun verifyApiCredentials(
        apiId: Int,
        apiHash: String,
        onProgressLabel: (String) -> Unit = {}
    ): Result<Unit> = sessionMutex.withLock {
        val cleanHash = apiHash.trim()
        if (apiId <= 0) {
            return Result.failure(IllegalArgumentException("API ID must be a positive integer"))
        }
        if (!cleanHash.matches(Regex("^[0-9a-fA-F]{32}$"))) {
            return Result.failure(IllegalArgumentException("API Hash must be a 32-character hexadecimal string"))
        }

        pendingPhone = ""
        secureStorage.clearAll()
        secureStorage.saveApiCredentials(apiId, cleanHash)
        secureStorage.saveActiveDc(2)

        return runCatching {
            withContext(Dispatchers.IO) {
                _connectionState.value = TelegramConnectionState.Connecting(2)
                onProgressLabel("Connecting to Telegram...")

                val initDeferred = CompletableDeferred<Unit>()
                pendingParameterInit = initDeferred

                val client = getOrCreateTdClient()
                onProgressLabel("Verifying API...")

                val currentState = sendTdQuery(TdApi.GetAuthorizationState())
                if (currentState is TdApi.AuthorizationStateWaitTdlibParameters) {
                    sendTdQuery(buildTdlibParameters(apiId, cleanHash))
                }

                withTimeout(25_000L) {
                    initDeferred.await()
                }

                _connectionState.value = TelegramConnectionState.Connected(2, null)
                if (_authStep.value !is TelegramAuthStep.Authorized) {
                    _authStep.value = TelegramAuthStep.EnterPhoneNumber(apiId, cleanHash)
                }
            }
        }.onFailure { err ->
            pendingParameterInit = null
            _connectionState.value = TelegramConnectionState.Disconnected(err.message ?: "Connection failed")
        }
    }

    fun editApiCredentials() {
        pendingPhone = ""
        _authStep.value = TelegramAuthStep.VerifyApiCredentials
    }

    /**
     * Step 2: Send phone number via TDLib SetAuthenticationPhoneNumber.
     * TDLib natively handles DC migrations, TCP obfuscation, and rate limits.
     */
    suspend fun sendPhoneCode(phoneNumber: String): Result<String> = sessionMutex.withLock {
        val currentStep = _authStep.value as? TelegramAuthStep.EnterPhoneNumber
        val apiId = currentStep?.apiId ?: secureStorage.getApiId()
            ?: return Result.failure(IllegalStateException("Verify your API credentials first"))
        val apiHash = currentStep?.apiHash ?: secureStorage.getApiHash()
            ?: return Result.failure(IllegalStateException("Verify your API credentials first"))

        val raw = phoneNumber.trim()
        val normalizedPhone = "+" + raw.removePrefix("+").filter(Char::isDigit)
        if (!raw.startsWith("+") || normalizedPhone.length < 8) {
            return Result.failure(
                IllegalArgumentException("Enter full phone number with country code (e.g. +880...)")
            )
        }

        pendingPhone = normalizedPhone
        secureStorage.saveApiCredentials(apiId, apiHash)
        secureStorage.savePhoneNumber(normalizedPhone)

        return runCatching {
            withContext(Dispatchers.IO) {
                val authState = sendTdQuery(TdApi.GetAuthorizationState())
                if (authState is TdApi.AuthorizationStateWaitTdlibParameters) {
                    sendTdQuery(buildTdlibParameters(apiId, apiHash))
                }

                val settings = TdApi.PhoneNumberAuthenticationSettings(
                    /* allowFlashCall = */ false,
                    /* allowMissedCall = */ false,
                    /* isCurrentPhoneNumber = */ false,
                    /* hasUnknownPhoneNumber = */ false,
                    /* allowSmsRetrieverApi = */ false,
                    /* firebaseAuthenticationSettings = */ null,
                    /* authenticationTokens = */ emptyArray()
                )
                sendTdQuery(TdApi.SetAuthenticationPhoneNumber(normalizedPhone, settings))
                _authStep.value = TelegramAuthStep.AwaitingOtp(normalizedPhone, "tdlib_code_session")
                "tdlib_code_session"
            }
        }
    }

    /**
     * Step 3a: Resend authentication code via TDLib ResendAuthenticationCode.
     */
    suspend fun resendOtpCode(): Result<String> = sessionMutex.withLock {
        if (pendingPhone.isBlank()) {
            return Result.failure(IllegalStateException("No pending verification request"))
        }
        return runCatching {
            withContext(Dispatchers.IO) {
                sendTdQuery(TdApi.ResendAuthenticationCode(TdApi.ResendCodeReasonUserRequest()))
                _authStep.value = TelegramAuthStep.AwaitingOtp(pendingPhone, "tdlib_code_session")
                "tdlib_code_session"
            }
        }
    }

    /**
     * Step 3b: Verify OTP code via TDLib CheckAuthenticationCode.
     * Smoothly transitions to AwaitingPassword if 2FA Cloud Password is enabled on the account.
     */
    suspend fun verifyOtpCode(code: String): Result<VerifyOtpOutcome> = sessionMutex.withLock {
        val cleanCode = code.trim()
        if (cleanCode.isEmpty()) {
            return Result.failure(IllegalArgumentException("Enter the verification code"))
        }

        return runCatching {
            withContext(Dispatchers.IO) {
                sendTdQuery(TdApi.CheckAuthenticationCode(cleanCode))
                val updatedState = sendTdQuery(TdApi.GetAuthorizationState())
                handleAuthorizationState(updatedState)

                when (updatedState) {
                    is TdApi.AuthorizationStateWaitPassword -> {
                        _authStep.value = TelegramAuthStep.AwaitingPassword(updatedState.passwordHint.orEmpty())
                        VerifyOtpOutcome.NEEDS_TWO_FACTOR
                    }
                    else -> {
                        completeTdAuthorization()
                        VerifyOtpOutcome.AUTHORIZED
                    }
                }
            }
        }
    }

    /**
     * Step 3c: Verify 2FA Cloud Password via TDLib CheckAuthenticationPassword.
     */
    suspend fun verifyTwoFactorPassword(password: String): Result<Unit> = sessionMutex.withLock {
        if (password.isEmpty()) {
            return Result.failure(IllegalArgumentException("Enter your 2FA password"))
        }

        return runCatching {
            withContext(Dispatchers.IO) {
                sendTdQuery(TdApi.CheckAuthenticationPassword(password))
                completeTdAuthorization()
            }
        }
    }

    private suspend fun completeTdAuthorization() {
        secureStorage.setLoggedIn(true)
        val profile = runCatching { fetchCurrentUserProfileInternal() }.getOrNull()
        val displayName = profile?.fullName
            ?: secureStorage.getUserDisplayName()?.takeIf { it.isNotBlank() }
            ?: pendingPhone.ifBlank { "Telegram User" }
        val phone = profile?.phoneNumber ?: pendingPhone.ifBlank { secureStorage.getPhoneNumber().orEmpty() }

        _connectionState.value = TelegramConnectionState.Connected(
            dcId = secureStorage.getActiveDc(),
            userDisplayName = displayName
        )
        _authStep.value = TelegramAuthStep.Authorized(displayName, phone)
        runCatching { ensureStorageChannelInternal() }
    }

    /**
     * Fetches the authenticated user's profile via TDLib GetMe.
     */
    suspend fun fetchCurrentUserProfile(): Result<TelegramUserProfile?> = runCatching {
        withContext(Dispatchers.IO) { fetchCurrentUserProfileInternal() }
    }

    private suspend fun fetchCurrentUserProfileInternal(): TelegramUserProfile? {
        if (!secureStorage.isLoggedIn()) return null
        val user = sendTdQuery(TdApi.GetMe())
        isPremiumAccount = user.isPremium

        val activeUsername = user.usernames?.activeUsernames?.firstOrNull()?.takeIf { it.isNotBlank() }
            ?: user.usernames?.editableUsername?.takeIf { it.isNotBlank() }
        val formattedPhone = user.phoneNumber?.takeIf { it.isNotBlank() }?.let {
            if (it.startsWith("+")) it else "+$it"
        } ?: secureStorage.getPhoneNumber()

        var avatarLocalPath: String? = secureStorage.getAvatarPath()
        val smallPhotoFile = user.profilePhoto?.small
        if (smallPhotoFile != null && smallPhotoFile.id != 0) {
            runCatching {
                val downloaded = sendTdQuery(
                    TdApi.DownloadFile(smallPhotoFile.id, 16, 0L, 0L, true)
                )
                val path = downloaded.local?.path
                if (!path.isNullOrBlank() && File(path).exists()) {
                    avatarLocalPath = path
                }
            }
        }

        val profile = TelegramUserProfile(
            userId = user.id,
            firstName = user.firstName.orEmpty(),
            lastName = user.lastName.orEmpty(),
            username = activeUsername,
            phoneNumber = formattedPhone,
            avatarPath = avatarLocalPath
        )

        secureStorage.saveUserProfileDetails(
            userId = profile.userId,
            firstName = profile.firstName,
            lastName = profile.lastName,
            username = profile.username,
            phone = profile.phoneNumber,
            avatarPath = profile.avatarPath
        )
        _userProfile.value = profile
        _authStep.value = TelegramAuthStep.Authorized(
            displayName = profile.fullName,
            phoneNumber = profile.phoneNumber.orEmpty()
        )
        _connectionState.value = TelegramConnectionState.Connected(
            dcId = secureStorage.getActiveDc(),
            userDisplayName = profile.fullName
        )
        return profile
    }

    /**
     * Finds or creates private "Clody Cloud Storage" channel using TDLib;
     * falls back to Saved Messages (CreatePrivateChat with self) if channel creation is restricted.
     */
    suspend fun ensureStorageChannel(): Result<Pair<Long, Long>> = sessionMutex.withLock {
        runCatching { ensureStorageChannelInternal() }
    }

    private suspend fun ensureStorageChannelInternal(): Pair<Long, Long> {
        val existingChatId = secureStorage.getStorageChannelId()
        val existingHash = secureStorage.getStorageChannelAccessHash()
        if (existingChatId != 0L) {
            val verified = runCatching { sendTdQuery(TdApi.GetChat(existingChatId)) }.getOrNull()
            if (verified != null) {
                return existingChatId to existingHash
            }
        }

        // 1. Search existing chats for "Clody Cloud Storage"
        val foundChatId = runCatching { findClodyChannelInChats() }.getOrNull()
        if (foundChatId != null && foundChatId != 0L) {
            secureStorage.saveStorageChannel(foundChatId, 1L, isSelfChat = false)
            return foundChatId to 1L
        }

        // 2. Create private channel "Clody Cloud Storage" via CreateNewSupergroupChat(isChannel = true)
        val createdChat = runCatching {
            sendTdQuery(
                TdApi.CreateNewSupergroupChat(
                    /* title = */ "Clody Cloud Storage",
                    /* isForum = */ false,
                    /* isChannel = */ true,
                    /* description = */ "Private cloud storage managed by Clody",
                    /* location = */ null,
                    /* messageAutoDeleteTime = */ 0,
                    /* forImport = */ false
                )
            )
        }.getOrNull()

        if (createdChat != null && createdChat.id != 0L) {
            secureStorage.saveStorageChannel(createdChat.id, 1L, isSelfChat = false)
            return createdChat.id to 1L
        }

        // 3. Fallback to Saved Messages (private chat with self)
        val selfChatId = runCatching {
            val me = sendTdQuery(TdApi.GetMe())
            val selfChat = sendTdQuery(TdApi.CreatePrivateChat(me.id, false))
            selfChat.id
        }.getOrDefault(-1L)

        secureStorage.saveStorageChannel(selfChatId, 0L, isSelfChat = true)
        return selfChatId to 0L
    }

    private suspend fun findClodyChannelInChats(): Long? {
        runCatching { sendTdQuery(TdApi.LoadChats(TdApi.ChatListMain(), 50)) }
        val chats = sendTdQuery(TdApi.GetChats(TdApi.ChatListMain(), 50))
        for (chatId in chats.chatIds ?: LongArray(0)) {
            val chat = runCatching { sendTdQuery(TdApi.GetChat(chatId)) }.getOrNull() ?: continue
            if (chat.title == "Clody Cloud Storage") {
                return chat.id
            }
        }
        return null
    }

    /**
     * Uploads a local file to the private Telegram storage channel.
     * Supports resumable preliminary uploads (`PreliminaryUploadFile`) with exact byte-offset recovery
     * and live progress updates, completing cleanly via `SendMessage`.
     */
    suspend fun uploadFile(
        file: File,
        fileName: String,
        mimeType: String,
        thumbnailFile: File?,
        isVideo: Boolean,
        durationSec: Double,
        resumeTdFileId: Int = 0,
        initialBytesUploaded: Long = 0L,
        onTdFileIdAssigned: suspend (Int) -> Unit = {},
        onProgress: suspend (bytesSent: Long, speedBytesPerSec: Long) -> Unit
    ): Result<TelegramUploadedDocument> = runCatching {
        withContext(Dispatchers.IO) {
            val totalBytes = file.length()
            val maxAllowed = if (isPremiumAccount) PREMIUM_MAX_FILE_BYTES else STANDARD_MAX_FILE_BYTES
            if (totalBytes > maxAllowed) {
                val limitGb = if (isPremiumAccount) "4 GB" else "2 GB"
                throw IllegalArgumentException(
                    "File size exceeds Telegram's $limitGb limit for your account."
                )
            }

            val (chatId, _) = ensureStorageChannelInternal()
            val startTime = System.currentTimeMillis()
            val isIndexSnapshot = fileName == "clody_index.json"

            val inputThumb = if (thumbnailFile != null && thumbnailFile.exists() && thumbnailFile.length() > 0L) {
                TdApi.InputThumbnail(TdApi.InputFileLocal(thumbnailFile.absolutePath), 320, 320)
            } else null

            val captionText = if (isIndexSnapshot) {
                "Clody Cloud Index Snapshot"
            } else {
                val taskMeta = runCatching {
                    dao.getLatestUploadTaskByNameAndSize(fileName, totalBytes)
                        ?: dao.getLatestUploadTaskByName(fileName)
                }.getOrNull()
                val folderTag = (taskMeta?.folderPath ?: "Cloud")
                    .replace("|", "/")
                    .replace("]", ")")
                    .ifBlank { "Cloud" }
                val isGallery = mimeType.startsWith("image/") || mimeType.startsWith("video/")
                val dateMs = taskMeta?.createdAt ?: System.currentTimeMillis()
                "Clody Cloud Backup: $fileName\n[CLODY_META|folder=$folderTag|gallery=$isGallery|date=$dateMs|fav=false]"
            }
            val caption = TdApi.FormattedText(captionText, emptyArray())

            // Resumable preliminary upload path for regular user files so byte offsets survive app close / Wi-Fi drop
            var inputFileForMessage: TdApi.InputFile = TdApi.InputFileLocal(file.absolutePath)
            var prelimFileId = 0

            if (!isIndexSnapshot) {
                val fileType = if (isVideo) TdApi.FileTypeVideo() else TdApi.FileTypeDocument()
                val prelimFile = if (resumeTdFileId > 0) {
                    runCatching {
                        sendTdQuery(TdApi.PreliminaryUploadFile(TdApi.InputFileId(resumeTdFileId), fileType, 32))
                    }.getOrNull()
                } else {
                    null
                } ?: runCatching {
                    sendTdQuery(TdApi.PreliminaryUploadFile(TdApi.InputFileLocal(file.absolutePath), fileType, 32))
                }.getOrNull()

                if (prelimFile != null && prelimFile.id != 0) {
                    prelimFileId = prelimFile.id
                    runCatching { onTdFileIdAssigned(prelimFileId) }

                    val uploadDone = CompletableDeferred<TdApi.File>()
                    val initialOffset = maxOf(prelimFile.remote?.uploadedSize ?: 0L, initialBytesUploaded)
                    if (initialOffset > 0L) {
                        runCatching { onProgress(minOf(initialOffset, totalBytes), 0L) }
                    }

                    if (prelimFile.remote?.isUploadingCompleted == true) {
                        uploadDone.complete(prelimFile)
                    } else {
                        fileProgressListeners[prelimFileId] = { updatedFile ->
                            val rawUploaded = updatedFile.remote?.uploadedSize ?: 0L
                            val uploaded = maxOf(rawUploaded, initialOffset)
                            val elapsedSec = maxOf(0.1, (System.currentTimeMillis() - startTime) / 1000.0)
                            val deltaBytes = (uploaded - initialOffset).coerceAtLeast(0L)
                            val speed = if (deltaBytes > 0L) (deltaBytes / elapsedSec).toLong() else (uploaded / elapsedSec).toLong()
                            scope.launch {
                                runCatching { onProgress(minOf(uploaded, totalBytes), speed) }
                            }
                            if (updatedFile.remote?.isUploadingCompleted == true) {
                                uploadDone.complete(updatedFile)
                            }
                        }

                        try {
                            while (!uploadDone.isCompleted) {
                                val ready = kotlinx.coroutines.withTimeoutOrNull(2500L) { uploadDone.await() }
                                if (ready != null) break
                                val poller = runCatching { sendTdQuery(TdApi.GetFile(prelimFileId)) }.getOrNull()
                                if (poller != null) {
                                    val uploaded = maxOf(poller.remote?.uploadedSize ?: 0L, initialOffset)
                                    val elapsedSec = maxOf(0.1, (System.currentTimeMillis() - startTime) / 1000.0)
                                    val deltaBytes = (uploaded - initialOffset).coerceAtLeast(0L)
                                    val speed = if (deltaBytes > 0L) (deltaBytes / elapsedSec).toLong() else 0L
                                    runCatching { onProgress(minOf(uploaded, totalBytes), speed) }
                                    if (poller.remote?.isUploadingCompleted == true) {
                                        uploadDone.complete(poller)
                                        break
                                    }
                                    if (poller.remote?.isUploadingActive == false && poller.remote?.isUploadingCompleted == false) {
                                        // Re-kick preliminary upload if TDLib stalled without throwing
                                        runCatching {
                                            sendTdQuery(TdApi.PreliminaryUploadFile(TdApi.InputFileId(prelimFileId), fileType, 32))
                                        }
                                    }
                                }
                            }
                        } catch (t: Throwable) {
                            fileProgressListeners.remove(prelimFileId)
                            if (t is kotlinx.coroutines.CancellationException) {
                                kotlinx.coroutines.withContext(kotlinx.coroutines.NonCancellable) {
                                    runCatching { cancelUploadFile(prelimFileId) }
                                }
                            }
                            throw t
                        } finally {
                            fileProgressListeners.remove(prelimFileId)
                        }
                    }

                    inputFileForMessage = TdApi.InputFileId(prelimFileId)
                }
            }

            val content: TdApi.InputMessageContent = if (isVideo) {
                TdApi.InputMessageVideo(
                    /* video = */ inputFileForMessage,
                    /* thumbnail = */ inputThumb,
                    /* cover = */ null,
                    /* startTimestamp = */ 0,
                    /* addedStickerFileIds = */ IntArray(0),
                    /* duration = */ durationSec.toInt(),
                    /* width = */ 1280,
                    /* height = */ 720,
                    /* supportsStreaming = */ true,
                    /* caption = */ caption,
                    /* showCaptionAboveMedia = */ false,
                    /* selfDestructType = */ null,
                    /* hasSpoiler = */ false
                )
            } else {
                TdApi.InputMessageDocument(
                    /* document = */ inputFileForMessage,
                    /* thumbnail = */ inputThumb,
                    /* disableContentTypeDetection = */ false,
                    /* caption = */ caption
                )
            }

            val sendDeferred = CompletableDeferred<TdApi.Message>()
            val provisionalMsg = sendTdQuery(
                TdApi.SendMessage(
                    /* chatId = */ chatId,
                    /* topicId = */ null,
                    /* replyTo = */ null,
                    /* options = */ TdApi.MessageSendOptions(),
                    /* replyMarkup = */ null,
                    /* inputMessageContent = */ content
                )
            )

            val provisionalFile = extractTdFileFromMessage(provisionalMsg)
            val trackedFileId = provisionalFile?.id ?: prelimFileId
            if (trackedFileId != 0) {
                runCatching { onTdFileIdAssigned(trackedFileId) }
            }

            if (provisionalMsg.sendingState is TdApi.MessageSendingStatePending) {
                pendingMessageSends[provisionalMsg.id] = sendDeferred
            } else {
                sendDeferred.complete(provisionalMsg)
            }

            if (trackedFileId != 0) {
                fileProgressListeners[trackedFileId] = { updatedFile ->
                    val uploaded = maxOf(updatedFile.remote?.uploadedSize ?: 0L, initialBytesUploaded)
                    val elapsedSec = maxOf(0.1, (System.currentTimeMillis() - startTime) / 1000.0)
                    val speed = (uploaded / elapsedSec).toLong()
                    scope.launch {
                        runCatching { onProgress(minOf(uploaded, totalBytes), speed) }
                    }
                }
            }

            val finalMessage = try {
                sendDeferred.await()
            } finally {
                pendingMessageSends.remove(provisionalMsg.id)
                if (trackedFileId != 0) {
                    fileProgressListeners.remove(trackedFileId)
                }
            }

            val elapsedSec = maxOf(0.1, (System.currentTimeMillis() - startTime) / 1000.0)
            val finalSpeed = (totalBytes / elapsedSec).toLong()
            onProgress(totalBytes, finalSpeed)

            val finalTdFile = extractTdFileFromMessage(finalMessage) ?: provisionalFile
            val tdFileId = finalTdFile?.id ?: trackedFileId
            val remoteIdStr = finalTdFile?.remote?.id.orEmpty()
            if (remoteIdStr.isNotBlank() && tdFileId != 0) {
                remoteToLocalFileIdCache[remoteIdStr] = tdFileId
            }

            val normalizedMsgId = ((finalMessage.id ushr 20).toInt()).let {
                if (it > 0) it else (finalMessage.id and 0x7FFFFFFFL).toInt().coerceAtLeast(1)
            }
            val nonZeroDocId = when {
                tdFileId != 0 -> tdFileId.toLong()
                remoteIdStr.isNotBlank() -> remoteIdStr.hashCode().toLong().let { if (it == 0L) 1L else it }
                else -> normalizedMsgId.toLong()
            }

            TelegramUploadedDocument(
                messageId = normalizedMsgId,
                documentId = nonZeroDocId,
                accessHash = finalMessage.id,
                fileReference = remoteIdStr.toByteArray(Charsets.UTF_8),
                dcId = secureStorage.getActiveDc(),
                mimeType = mimeType,
                sizeBytes = if ((finalTdFile?.size ?: 0L) > 0L) finalTdFile!!.size else totalBytes
            )
        }
    }

    suspend fun cancelUploadFile(tdFileId: Int) {
        if (tdFileId <= 0 || tdClient == null) return
        withContext(Dispatchers.IO) {
            runCatching {
                sendTdQuery(TdApi.CancelPreliminaryUploadFile(tdFileId))
            }
        }
    }

    private suspend fun resolveTdFileId(
        documentId: Long,
        accessHash: Long,
        fileReference: ByteArray
    ): Int {
        val remoteId = if (fileReference.isNotEmpty()) {
            runCatching { String(fileReference, Charsets.UTF_8).trim() }.getOrDefault("")
        } else ""

        var tdFileId = if (remoteId.isNotBlank()) {
            remoteToLocalFileIdCache[remoteId] ?: 0
        } else 0

        if (tdFileId == 0 && accessHash != 0L) {
            tdFileId = accessHashToLocalFileIdCache[accessHash] ?: 0
        }

        if (tdFileId == 0 && remoteId.isNotBlank()) {
            val remoteFile = runCatching {
                sendTdQuery(TdApi.GetRemoteFile(remoteId, null))
            }.getOrNull()
            if (remoteFile != null && remoteFile.id != 0) {
                tdFileId = remoteFile.id
                remoteToLocalFileIdCache[remoteId] = tdFileId
            }
        }

        if (tdFileId == 0 && accessHash != 0L) {
            val chatId = secureStorage.getStorageChannelId()
            if (chatId != 0L) {
                val msg = runCatching {
                    sendTdQuery(TdApi.GetMessage(chatId, accessHash))
                }.getOrNull()
                val msgFile = extractTdFileFromMessage(msg)
                if (msgFile != null && msgFile.id != 0) {
                    tdFileId = msgFile.id
                    accessHashToLocalFileIdCache[accessHash] = tdFileId
                    val msgRemoteId = msgFile.remote?.id.orEmpty()
                    if (msgRemoteId.isNotBlank()) {
                        remoteToLocalFileIdCache[msgRemoteId] = tdFileId
                    }
                }
            }
        }

        if (tdFileId == 0 && documentId > 0L && documentId <= Int.MAX_VALUE) {
            tdFileId = documentId.toInt()
        }

        if (tdFileId != 0 && accessHash != 0L) {
            accessHashToLocalFileIdCache[accessHash] = tdFileId
        }
        return tdFileId
    }

    /**
     * Progressive byte-range chunk download using TDLib DownloadFile + ReadFilePart.
     * Preserves 512 KB sliding-window streaming for Media3 video/audio players with capped RAM.
     */
    suspend fun downloadChunk(
        dcId: Int,
        documentId: Long,
        accessHash: Long,
        fileReference: ByteArray,
        offset: Long,
        limit: Int
    ): ByteArray = withContext(Dispatchers.IO) {
        if (limit <= 0 || offset < 0L) return@withContext ByteArray(0)

        val tdFileId = resolveTdFileId(documentId, accessHash, fileReference)
        if (tdFileId == 0) {
            throw IllegalStateException("Unable to resolve TDLib file ID for cloud stream")
        }

        val downloadedFile = sendTdQuery(
            TdApi.DownloadFile(
                /* fileId = */ tdFileId,
                /* priority = */ 32,
                /* offset = */ offset,
                /* limit = */ limit.toLong(),
                /* synchronous = */ true
            )
        )

        val knownSize = downloadedFile.size
        if (knownSize > 0L && offset >= knownSize) {
            return@withContext ByteArray(0)
        }
        val effectiveLimit = if (knownSize > 0L) {
            minOf(limit.toLong(), knownSize - offset).coerceAtLeast(0L)
        } else {
            limit.toLong()
        }
        if (effectiveLimit <= 0L) return@withContext ByteArray(0)

        val part = runCatching {
            sendTdQuery(TdApi.ReadFilePart(tdFileId, offset, effectiveLimit))
        }.getOrNull()

        if (part?.data != null && part.data.isNotEmpty()) {
            return@withContext part.data
        }

        // Fallback: read ONLY the requested slice directly from TDLib's local file path
        val localPath = downloadedFile.local?.path
        if (!localPath.isNullOrBlank()) {
            val localFile = File(localPath)
            if (localFile.exists() && localFile.length() > offset) {
                RandomAccessFile(localFile, "r").use { raf ->
                    val available = minOf(effectiveLimit, raf.length() - offset).toInt()
                    if (available > 0) {
                        val buffer = ByteArray(available)
                        raf.seek(offset)
                        val read = raf.read(buffer)
                        if (read > 0) {
                            return@withContext if (read == buffer.size) buffer else buffer.copyOf(read)
                        }
                    }
                }
            }
        }

        ByteArray(0)
    }

    /**
     * Explicit user download helper running at max TDLib priority (32) with native multi-connection
     * engine (`offset = 0, limit = 0, synchronous = false`), always preserving 100% Original Quality
     * regardless of Wi-Fi or Mobile Data connection.
     */
    suspend fun downloadOriginalFile(
        documentId: Long,
        accessHash: Long,
        fileReference: ByteArray,
        expectedSizeBytes: Long,
        destFile: File,
        onProgress: suspend (downloadedBytes: Long, totalBytes: Long) -> Unit = { _, _ -> }
    ): File = withContext(Dispatchers.IO) {
        val tdFileId = resolveTdFileId(documentId, accessHash, fileReference)
        if (tdFileId == 0) {
            throw IllegalStateException("Unable to resolve TDLib file ID for original-quality download")
        }

        val completedDeferred = CompletableDeferred<File>()
        fileProgressListeners[tdFileId] = { updatedFile ->
            val local = updatedFile.local
            val total = maxOf(updatedFile.size, expectedSizeBytes, 1L)
            val downloaded = (local?.downloadedSize ?: 0L).coerceAtLeast(0L)
            scope.launch {
                runCatching { onProgress(minOf(downloaded, total), total) }
            }
            val localPath = local?.path
            if (local?.isDownloadingCompleted == true && !localPath.isNullOrBlank()) {
                val f = File(localPath)
                if (f.exists() && f.length() > 0L) {
                    completedDeferred.complete(f)
                }
            }
        }

        val tdSourceFile: File = try {
            val initialFile = sendTdQuery(
                TdApi.DownloadFile(
                    /* fileId = */ tdFileId,
                    /* priority = */ 32,
                    /* offset = */ 0L,
                    /* limit = */ 0L,
                    /* synchronous = */ false
                )
            )

            val initTotal = maxOf(initialFile.size, expectedSizeBytes, 1L)
            val initDownloaded = (initialFile.local?.downloadedSize ?: 0L).coerceAtLeast(0L)
            if (initDownloaded > 0L) {
                runCatching { onProgress(minOf(initDownloaded, initTotal), initTotal) }
            }

            val initialPath = initialFile.local?.path
            if (initialFile.local?.isDownloadingCompleted == true && !initialPath.isNullOrBlank()) {
                val existing = File(initialPath)
                if (existing.exists() && existing.length() > 0L) {
                    completedDeferred.complete(existing)
                }
            }

            var inactivePolls = 0
            while (!completedDeferred.isCompleted) {
                val awaited = kotlinx.coroutines.withTimeoutOrNull(3_000L) {
                    completedDeferred.await()
                }
                if (awaited != null) break

                val latest = runCatching { sendTdQuery(TdApi.GetFile(tdFileId)) }.getOrNull()
                if (latest != null) {
                    val total = maxOf(latest.size, expectedSizeBytes, 1L)
                    val downloaded = (latest.local?.downloadedSize ?: 0L).coerceAtLeast(0L)
                    runCatching { onProgress(minOf(downloaded, total), total) }
                    val latestPath = latest.local?.path
                    if (latest.local?.isDownloadingCompleted == true && !latestPath.isNullOrBlank()) {
                        val ready = File(latestPath)
                        if (ready.exists() && ready.length() > 0L) {
                            completedDeferred.complete(ready)
                            break
                        }
                    }
                    if (latest.local?.isDownloadingActive == false) {
                        inactivePolls++
                        if (inactivePolls >= 2) {
                            // Re-kick download at max priority before failing on sustained disconnect
                            runCatching {
                                sendTdQuery(TdApi.DownloadFile(tdFileId, 32, 0L, 0L, false))
                            }
                        }
                        if (inactivePolls >= 5) {
                            throw IllegalStateException("Telegram download paused or lost connection")
                        }
                    } else {
                        inactivePolls = 0
                    }
                }
            }

            completedDeferred.await()
        } finally {
            fileProgressListeners.remove(tdFileId)
        }

        // Stream-copy 100% original uncompressed bytes into destination using a 64 KB buffer
        destFile.parentFile?.mkdirs()
        val tempDest = File(destFile.parentFile, "${destFile.name}.part")
        try {
            tdSourceFile.inputStream().use { input ->
                FileOutputStream(tempDest).use { output ->
                    input.copyTo(output, bufferSize = 64 * 1024)
                    output.flush()
                }
            }
            if (destFile.exists()) destFile.delete()
            if (!tempDest.renameTo(destFile)) {
                tempDest.copyTo(destFile, overwrite = true)
                tempDest.delete()
            }
        } catch (t: Throwable) {
            tempDest.delete()
            throw t
        }

        val finalLen = destFile.length().coerceAtLeast(expectedSizeBytes)
        runCatching { onProgress(finalLen, maxOf(finalLen, 1L)) }
        destFile
    }

    /**
     * Pushes clody_index.json to the private Telegram storage channel so folder, album, favorite,
     * and trash trees sync permanently across devices, pinning the new snapshot and unpinning/deleting the previous one.
     */
    suspend fun pushCloudIndexSnapshot(): Result<Unit> = runCatching {
        withContext(Dispatchers.IO) {
            if (!secureStorage.isLoggedIn()) return@withContext
            indexSyncMutex.withLock {
                val (chatId, _) = ensureStorageChannelInternal()
                val folders = dao.getAllFoldersOnce()
                val albums = dao.getAllAlbumsOnce()
                val files = dao.getAllFilesOnceIncludingTrash()
                val snapshot = CloudIndexSnapshot(
                    version = 2,
                    updatedAt = System.currentTimeMillis(),
                    folders = folders,
                    albums = albums,
                    files = files
                )
                val jsonText = json.encodeToString(snapshot)
                val indexFile = File(context.cacheDir, "clody_index.json").apply {
                    writeText(jsonText, Charsets.UTF_8)
                }

                val prevTdMsgId = secureStorage.getIndexTdMessageId()

                val uploaded = uploadFile(
                    file = indexFile,
                    fileName = "clody_index.json",
                    mimeType = "application/json",
                    thumbnailFile = null,
                    isVideo = false,
                    durationSec = 0.0,
                    onProgress = { _, _ -> }
                ).getOrThrow()

                if (uploaded.messageId > 0) {
                    secureStorage.saveIndexMessageId(uploaded.messageId)
                }
                if (uploaded.accessHash != 0L) {
                    secureStorage.saveIndexTdMessageId(uploaded.accessHash)
                }

                if (chatId != 0L && uploaded.accessHash != 0L) {
                    runCatching {
                        sendTdQuery(
                            TdApi.PinChatMessage(
                                /* chatId = */ chatId,
                                /* messageId = */ uploaded.accessHash,
                                /* disableNotification = */ true,
                                /* onlyForSelf = */ false
                            )
                        )
                    }

                    if (prevTdMsgId != 0L && prevTdMsgId != uploaded.accessHash) {
                        runCatching {
                            sendTdQuery(TdApi.UnpinChatMessage(chatId, prevTdMsgId))
                        }
                        runCatching {
                            sendTdQuery(TdApi.DeleteMessages(chatId, longArrayOf(prevTdMsgId), true))
                        }
                    }
                }
            }
        }
    }

    /**
     * Fetches the pinned clody_index.json (or channel history fallback + [CLODY_META|...] captions)
     * and restores/merges the complete folder tree, albums, favorites, and file mappings cleanly.
     */
    suspend fun syncFromTelegramChannel(): Result<Int> = runCatching {
        withContext(Dispatchers.IO) {
            if (!secureStorage.isLoggedIn()) return@withContext 0
            indexSyncMutex.withLock {
                val (chatId, _) = ensureStorageChannelInternal()

                val pinnedMsg = runCatching {
                    sendTdQuery(TdApi.GetChatPinnedMessage(chatId))
                }.getOrNull()

                val pinnedIndexDoc = pinnedMsg?.let { extractNamedDocumentFromMessage(it) }
                    ?.takeIf { it.first == "clody_index.json" }
                    ?.second

                if (pinnedMsg != null && pinnedIndexDoc != null) {
                    secureStorage.saveIndexTdMessageId(pinnedMsg.id)
                }

                val history = runCatching {
                    sendTdQuery(
                        TdApi.GetChatHistory(
                            /* chatId = */ chatId,
                            /* fromMessageId = */ 0L,
                            /* offset = */ 0,
                            /* limit = */ 100,
                            /* onlyLocal = */ false
                        )
                    )
                }.getOrNull()

                val historyMessages = history?.messages?.toList().orEmpty()
                val historyDocs = historyMessages.mapNotNull { msg ->
                    extractNamedDocumentFromMessage(msg)?.let { (name, doc) ->
                        Triple(msg, name, doc)
                    }
                }

                val targetIndexDoc = pinnedIndexDoc
                    ?: historyDocs.firstOrNull { it.second == "clody_index.json" }?.third

                var restored = 0
                val existingFolders = dao.getAllFoldersOnce().toMutableList()
                val existingAlbums = dao.getAllAlbumsOnce().toMutableList()

                if (targetIndexDoc != null) {
                    val tempIndexFile = File(context.cacheDir, "clody_index_restore.json").apply {
                        if (exists()) delete()
                    }
                    val rawJsonBytes: ByteArray? = runCatching {
                        downloadOriginalFile(
                            documentId = targetIndexDoc.documentId,
                            accessHash = targetIndexDoc.accessHash,
                            fileReference = targetIndexDoc.fileReference,
                            expectedSizeBytes = targetIndexDoc.sizeBytes,
                            destFile = tempIndexFile
                        )
                        tempIndexFile.readBytes()
                    }.getOrNull() ?: runCatching {
                        downloadChunk(
                            dcId = targetIndexDoc.dcId,
                            documentId = targetIndexDoc.documentId,
                            accessHash = targetIndexDoc.accessHash,
                            fileReference = targetIndexDoc.fileReference,
                            offset = 0L,
                            limit = maxOf(DEFAULT_CHUNK_SIZE, targetIndexDoc.sizeBytes.toInt())
                        )
                    }.getOrNull()

                    runCatching { tempIndexFile.delete() }

                    if (rawJsonBytes != null && rawJsonBytes.isNotEmpty()) {
                        runCatching {
                            val snapshot = json.decodeFromString<CloudIndexSnapshot>(
                                String(rawJsonBytes, Charsets.UTF_8)
                            )

                            // 1. Topologically restore folders and build oldId -> localId mapping
                            val folderIdMap = mutableMapOf<Long, Long>()
                            val remainingFolders = snapshot.folders.toMutableList()
                            var guard = 0
                            while (remainingFolders.isNotEmpty() && guard <= snapshot.folders.size + 1) {
                                guard++
                                var progressed = false
                                val iter = remainingFolders.iterator()
                                while (iter.hasNext()) {
                                    val cf = iter.next()
                                    val canResolveParent = cf.parentId == null || folderIdMap.containsKey(cf.parentId)
                                    if (!canResolveParent && guard <= snapshot.folders.size) continue

                                    val mappedParentId = cf.parentId?.let { folderIdMap[it] }
                                    val match = existingFolders.firstOrNull {
                                        it.name == cf.name && it.parentId == mappedParentId
                                    }
                                    if (match != null) {
                                        folderIdMap[cf.id] = match.id
                                    } else {
                                        val insertedId = dao.insertFolder(
                                            cf.copy(id = 0, parentId = mappedParentId)
                                        )
                                        val inserted = cf.copy(id = insertedId, parentId = mappedParentId)
                                        existingFolders += inserted
                                        folderIdMap[cf.id] = insertedId
                                        restored++
                                    }
                                    iter.remove()
                                    progressed = true
                                }
                                if (!progressed && remainingFolders.isNotEmpty()) {
                                    val cf = remainingFolders.removeAt(0)
                                    val match = existingFolders.firstOrNull { it.name == cf.name && it.parentId == null }
                                    if (match != null) {
                                        folderIdMap[cf.id] = match.id
                                    } else {
                                        val insertedId = dao.insertFolder(cf.copy(id = 0, parentId = null))
                                        existingFolders += cf.copy(id = insertedId, parentId = null)
                                        folderIdMap[cf.id] = insertedId
                                        restored++
                                    }
                                }
                            }

                            // 2. Restore albums and build oldAlbumId -> localAlbumId mapping
                            val albumIdMap = mutableMapOf<Long, Long>()
                            for (ca in snapshot.albums) {
                                val match = existingAlbums.firstOrNull {
                                    it.name.equals(ca.name, ignoreCase = true)
                                }
                                if (match != null) {
                                    albumIdMap[ca.id] = match.id
                                } else {
                                    val insertedId = dao.insertAlbum(
                                        ca.copy(id = 0, coverThumbnailPath = null)
                                    )
                                    existingAlbums += ca.copy(id = insertedId, coverThumbnailPath = null)
                                    albumIdMap[ca.id] = insertedId
                                    restored++
                                }
                            }

                            // 3. Merge/restore all FileEntity entries preserving hierarchy, favorites, albums & trash state
                            for (cf in snapshot.files) {
                                val mappedFolderId = cf.folderId?.let { folderIdMap[it] }
                                val mappedAlbumId = cf.albumId?.let { albumIdMap[it] }
                                val existing = dao.getFileByTelegramDocOrMsg(
                                    cf.telegramMessageId,
                                    cf.telegramAccessHash
                                ) ?: cf.sha256.takeIf { it.isNotBlank() }?.let {
                                    dao.findActiveFileBySha256(it)
                                }

                                if (existing == null) {
                                    dao.insertFile(
                                        cf.copy(
                                            id = 0,
                                            folderId = mappedFolderId,
                                            albumId = mappedAlbumId,
                                            localCachePath = null,
                                            thumbnailPath = null,
                                            pinnedOfflinePath = null,
                                            isPinnedOffline = false
                                        )
                                    )
                                    restored++
                                } else {
                                    val merged = existing.copy(
                                        folderId = mappedFolderId ?: existing.folderId,
                                        folderPath = cf.folderPath.ifBlank { existing.folderPath },
                                        albumId = mappedAlbumId ?: existing.albumId,
                                        isFavorite = cf.isFavorite || existing.isFavorite,
                                        isDeleted = cf.isDeleted,
                                        deletedAt = cf.deletedAt
                                    )
                                    if (merged != existing) {
                                        dao.updateFile(merged)
                                    }
                                }
                            }
                        }
                    }
                }

                // 4. Fallback caption metadata recovery for any uploaded channel files missing from index
                for ((msg, fileName, doc) in historyDocs) {
                    if (fileName == "clody_index.json" || fileName.isBlank()) continue
                    val alreadyExists = dao.getFileByTelegramDocOrMsg(doc.messageId, doc.accessHash) != null
                    if (alreadyExists) continue

                    val captionText = extractCaptionTextFromMessage(msg)
                    val meta = parseClodyMetaCaption(captionText)
                    val folderPath = meta?.folderPath?.ifBlank { "Cloud" } ?: "Cloud"
                    val resolvedFolderId = ensureFolderHierarchy(folderPath, existingFolders)
                    val ext = fileName.substringAfterLast('.', "").lowercase()
                    val refHex = doc.fileReference.joinToString("") { "%02x".format(it) }

                    dao.insertFile(
                        FileEntity(
                            name = fileName,
                            extension = ext,
                            sizeBytes = doc.sizeBytes,
                            mimeType = doc.mimeType.ifBlank { "application/octet-stream" },
                            folderId = resolvedFolderId,
                            folderPath = folderPath,
                            telegramMessageId = doc.messageId,
                            telegramDocumentId = doc.documentId,
                            telegramAccessHash = doc.accessHash,
                            telegramFileReferenceHex = refHex,
                            telegramDcId = doc.dcId,
                            isFavorite = meta?.isFavorite ?: false,
                            createdAt = meta?.createdAt ?: (msg.date.toLong() * 1000L)
                        )
                    )
                    restored++
                }

                if (restored > 0) {
                    runCatching { dao.rebuildFtsIndex() }
                }
                restored
            }
        }
    }

    private suspend fun ensureFolderHierarchy(
        folderPath: String,
        existingFolders: MutableList<FolderEntity>
    ): Long? {
        val parts = folderPath.split("/")
            .map { it.trim() }
            .filter { it.isNotEmpty() && !it.equals("Cloud", ignoreCase = true) }
        if (parts.isEmpty()) return null
        var parentId: Long? = null
        for (segment in parts) {
            val match = existingFolders.firstOrNull { it.name == segment && it.parentId == parentId }
            parentId = if (match != null) {
                match.id
            } else {
                val newFolder = FolderEntity(name = segment, parentId = parentId)
                val newId = dao.insertFolder(newFolder)
                existingFolders += newFolder.copy(id = newId)
                newId
            }
        }
        return parentId
    }

    private data class ParsedClodyMeta(
        val folderPath: String,
        val isGallery: Boolean,
        val createdAt: Long,
        val isFavorite: Boolean
    )

    private fun extractCaptionTextFromMessage(msg: TdApi.Message): String {
        return when (val content = msg.content) {
            is TdApi.MessageDocument -> content.caption?.text.orEmpty()
            is TdApi.MessageVideo -> content.caption?.text.orEmpty()
            is TdApi.MessageAudio -> content.caption?.text.orEmpty()
            is TdApi.MessagePhoto -> content.caption?.text.orEmpty()
            else -> ""
        }
    }

    private fun parseClodyMetaCaption(caption: String): ParsedClodyMeta? {
        val start = caption.indexOf("[CLODY_META|")
        if (start < 0) return null
        val end = caption.indexOf(']', startIndex = start)
        if (end < 0) return null
        val payload = caption.substring(start + "[CLODY_META|".length, end)
        val map = payload.split('|')
            .mapNotNull { token ->
                val idx = token.indexOf('=')
                if (idx > 0) token.substring(0, idx) to token.substring(idx + 1) else null
            }
            .toMap()
        return ParsedClodyMeta(
            folderPath = map["folder"].orEmpty().ifBlank { "Cloud" },
            isGallery = map["gallery"]?.toBooleanStrictOrNull() ?: false,
            createdAt = map["date"]?.toLongOrNull() ?: System.currentTimeMillis(),
            isFavorite = map["fav"]?.toBooleanStrictOrNull() ?: false
        )
    }

    suspend fun logout(): Result<Unit> = sessionMutex.withLock {
        runCatching {
            withContext(Dispatchers.IO) {
                runCatching {
                    if (tdClient != null) {
                        sendTdQuery(TdApi.LogOut())
                    }
                }
                synchronized(clientLock) {
                    tdClient = null
                }
                fileProgressListeners.clear()
                pendingMessageSends.clear()
                remoteToLocalFileIdCache.clear()
                secureStorage.clearSessionOnly()
                _userProfile.value = null
                _connectionState.value = TelegramConnectionState.Disconnected(null)
                _authStep.value = TelegramAuthStep.VerifyApiCredentials
            }
        }
    }

    private fun extractTdFileFromMessage(msg: TdApi.Message?): TdApi.File? {
        if (msg == null) return null
        return when (val content = msg.content) {
            is TdApi.MessageDocument -> content.document?.document
            is TdApi.MessageVideo -> content.video?.video
            is TdApi.MessageAudio -> content.audio?.audio
            is TdApi.MessageAnimation -> content.animation?.animation
            is TdApi.MessagePhoto -> content.photo?.sizes
                ?.maxByOrNull { it.width.toLong() * it.height.toLong() }
                ?.photo
            else -> null
        }
    }

    private fun extractNamedDocumentFromMessage(msg: TdApi.Message): Pair<String, TelegramUploadedDocument>? {
        val content = msg.content
        val fileName: String
        val mimeType: String
        val tdFile: TdApi.File?

        when (content) {
            is TdApi.MessageDocument -> {
                val doc = content.document ?: return null
                fileName = doc.fileName.orEmpty()
                mimeType = doc.mimeType.orEmpty()
                tdFile = doc.document
            }
            is TdApi.MessageVideo -> {
                val vid = content.video ?: return null
                fileName = vid.fileName.orEmpty()
                mimeType = vid.mimeType.orEmpty()
                tdFile = vid.video
            }
            is TdApi.MessageAudio -> {
                val aud = content.audio ?: return null
                fileName = aud.fileName.orEmpty()
                mimeType = aud.mimeType.orEmpty()
                tdFile = aud.audio
            }
            else -> return null
        }

        if (tdFile == null) return null
        val remoteId = tdFile.remote?.id.orEmpty()
        if (remoteId.isNotBlank() && tdFile.id != 0) {
            remoteToLocalFileIdCache[remoteId] = tdFile.id
        }

        val normalizedMsgId = ((msg.id ushr 20).toInt()).let {
            if (it > 0) it else (msg.id and 0x7FFFFFFFL).toInt().coerceAtLeast(1)
        }
        val docId = if (tdFile.id != 0) tdFile.id.toLong() else normalizedMsgId.toLong()

        return fileName to TelegramUploadedDocument(
            messageId = normalizedMsgId,
            documentId = docId,
            accessHash = msg.id,
            fileReference = remoteId.toByteArray(Charsets.UTF_8),
            dcId = secureStorage.getActiveDc(),
            mimeType = mimeType,
            sizeBytes = tdFile.size
        )
    }

    /**
     * Fetches embedded TDLib minithumbnail bytes (zero file-download cost) for instant placeholder rendering.
     */
    suspend fun getCachedOrFetchMinithumbnail(file: FileEntity): ByteArray? = withContext(Dispatchers.IO) {
        val messageId = file.telegramAccessHash
        if (messageId == 0L || !secureStorage.isLoggedIn()) return@withContext null
        miniThumbnailBytesCache[messageId]?.let { return@withContext it }

        val chatId = secureStorage.getStorageChannelId()
        if (chatId == 0L || tdClient == null) return@withContext null

        val msg = runCatching {
            sendTdQuery(TdApi.GetMessage(chatId, messageId))
        }.getOrNull() ?: return@withContext null

        extractThumbnailTdFileFromMessage(msg)?.let { thumbFile ->
            if (thumbFile.id != 0) {
                thumbnailFileIdCache[messageId] = thumbFile.id
            }
        }
        val miniBytes = extractMinithumbnailBytesFromMessage(msg)
        if (miniBytes != null && miniBytes.isNotEmpty()) {
            miniThumbnailBytesCache[messageId] = miniBytes
            return@withContext miniBytes
        }
        null
    }

    /**
     * Downloads a media thumbnail gated by a strict Semaphore(3) concurrency limit to prevent
     * Telegram FLOOD_WAIT rate limits, and stores it permanently in [targetFile] under filesDir/thumbnails.
     */
    suspend fun downloadThumbnailWithSemaphore(file: FileEntity, targetFile: File): File? =
        withContext(Dispatchers.IO) {
            if (targetFile.exists() && targetFile.length() > 0L) {
                return@withContext targetFile
            }
            val messageId = file.telegramAccessHash
            if (messageId == 0L || !secureStorage.isLoggedIn() || tdClient == null) {
                return@withContext null
            }

            thumbnailSemaphore.withPermit {
                if (targetFile.exists() && targetFile.length() > 0L) {
                    return@withPermit targetFile
                }

                val chatId = secureStorage.getStorageChannelId()
                if (chatId == 0L) return@withPermit null

                var thumbTdFileId = thumbnailFileIdCache[messageId] ?: 0
                if (thumbTdFileId == 0) {
                    val msg = runCatching {
                        sendTdQuery(TdApi.GetMessage(chatId, messageId))
                    }.getOrNull() ?: return@withPermit null

                    extractMinithumbnailBytesFromMessage(msg)?.takeIf { it.isNotEmpty() }?.let {
                        miniThumbnailBytesCache[messageId] = it
                    }

                    val thumbFile = extractThumbnailTdFileFromMessage(msg)
                    if (thumbFile != null && thumbFile.id != 0) {
                        thumbTdFileId = thumbFile.id
                        thumbnailFileIdCache[messageId] = thumbTdFileId
                    }
                }

                if (thumbTdFileId == 0) return@withPermit null

                val downloaded = runCatching {
                    sendTdQuery(
                        TdApi.DownloadFile(
                            /* fileId = */ thumbTdFileId,
                            /* priority = */ 8,
                            /* offset = */ 0L,
                            /* limit = */ 0L,
                            /* synchronous = */ true
                        )
                    )
                }.getOrNull() ?: return@withPermit null

                val sourcePath = downloaded.local?.path
                if (sourcePath.isNullOrBlank()) return@withPermit null
                val sourceFile = File(sourcePath)
                if (!sourceFile.exists() || sourceFile.length() <= 0L) return@withPermit null

                runCatching {
                    targetFile.parentFile?.mkdirs()
                    val tempFile = File(targetFile.parentFile, "${targetFile.name}.tmp")
                    sourceFile.inputStream().use { input ->
                        FileOutputStream(tempFile).use { output ->
                            input.copyTo(output)
                        }
                    }
                    if (!tempFile.renameTo(targetFile)) {
                        tempFile.copyTo(targetFile, overwrite = true)
                        tempFile.delete()
                    }
                }.getOrNull() ?: return@withPermit null

                targetFile.takeIf { it.exists() && it.length() > 0L }
            }
        }

    /**
     * Immediately removes TDLib's downloaded temporary file for [file] via `TdApi.CancelDownloadFile`
     * + `TdApi.DeleteFile(fileId)` so Zero-Storage Mode guarantees 0.0 MB stream cache.
     */
    suspend fun deleteTdFileCache(file: FileEntity) {
        if (tdClient == null) return
        if (file.telegramDocumentId == 0L && file.telegramAccessHash == 0L && file.telegramFileReferenceHex.isBlank()) {
            return
        }
        withContext(Dispatchers.IO) {
            val refHex = file.telegramFileReferenceHex
            val refBytes = if (refHex.isNotEmpty() && refHex.length % 2 == 0) {
                ByteArray(refHex.length / 2) { i ->
                    refHex.substring(i * 2, i * 2 + 2).toInt(16).toByte()
                }
            } else ByteArray(0)
            val tdFileId = runCatching {
                resolveTdFileId(file.telegramDocumentId, file.telegramAccessHash, refBytes)
            }.getOrDefault(0)
            if (tdFileId != 0 && tdFileId !in thumbnailFileIdCache.values) {
                runCatching { sendTdQuery(TdApi.CancelDownloadFile(tdFileId, false)) }
                runCatching { sendTdQuery(TdApi.DeleteFile(tdFileId)) }
            }
        }
    }

    /**
     * Clears all TDLib-cached temporary streamed media files while strictly preserving
     * TDLib auth/database (`tdlib_db` / `td.binlog`), `clody_index.json`, and thumbnails (`thumbnailFileIdCache`).
     */
    suspend fun clearAllTdMediaTempFiles() {
        if (tdClient == null) return
        withContext(Dispatchers.IO) {
            val thumbIds = thumbnailFileIdCache.values.toSet()
            val candidateIds = (accessHashToLocalFileIdCache.values + remoteToLocalFileIdCache.values)
                .filter { it != 0 && it !in thumbIds }
                .distinct()
            for (tdFileId in candidateIds) {
                runCatching { sendTdQuery(TdApi.CancelDownloadFile(tdFileId, false)) }
                runCatching { sendTdQuery(TdApi.DeleteFile(tdFileId)) }
            }
        }
    }

    internal fun extractMinithumbnailBytesFromMessage(msg: TdApi.Message): ByteArray? {
        return when (val content = msg.content) {
            is TdApi.MessageVideo -> content.video?.minithumbnail?.data
            is TdApi.MessageAudio -> content.audio?.albumCoverMinithumbnail?.data
            is TdApi.MessageDocument -> content.document?.minithumbnail?.data
            is TdApi.MessagePhoto -> content.photo?.minithumbnail?.data
            is TdApi.MessageAnimation -> content.animation?.minithumbnail?.data
            else -> null
        }
    }

    internal fun extractThumbnailTdFileFromMessage(msg: TdApi.Message): TdApi.File? {
        return when (val content = msg.content) {
            is TdApi.MessageVideo -> content.video?.thumbnail?.file
            is TdApi.MessageAudio -> content.audio?.albumCoverThumbnail?.file
            is TdApi.MessageDocument -> content.document?.thumbnail?.file
            is TdApi.MessagePhoto -> {
                val sizes = content.photo?.sizes
                sizes?.firstOrNull { it.type == "m" }?.photo
                    ?: sizes?.firstOrNull { it.type == "s" }?.photo
                    ?: sizes?.firstOrNull()?.photo
            }
            is TdApi.MessageAnimation -> content.animation?.thumbnail?.file
            else -> null
        }
    }
}
