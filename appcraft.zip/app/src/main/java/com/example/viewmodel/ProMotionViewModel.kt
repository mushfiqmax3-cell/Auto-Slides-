package com.example.viewmodel

import android.graphics.Bitmap
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.DemoProjects
import com.example.data.ProMotionRepository
import com.example.model.BUILTIN_LOOKS
import com.example.model.ChartDataPoint
import com.example.model.ContactOutroConfig
import com.example.model.LookPreset
import com.example.model.ProMotionJsonCodec
import com.example.model.ProMotionProject
import com.example.model.ProMotionScene
import com.example.model.SavedThemeDoc
import com.example.model.SceneTemplate
import com.example.model.SubtitleStyle
import com.example.model.VideoProjectDoc
import com.example.model.WaveformVariant
import android.content.Context
import android.net.Uri
import com.example.utils.GeminiPromptAndAiService
import com.example.utils.RemotionZipConverter
import com.example.utils.RemotionZipInspectResult
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class StudioTab(val labelBn: String) {
    HOME("হোম"),
    PROJECTS("প্রজেক্ট"),
    THEMES("থিম"),
    TOOLS("টুল"),
    SETTINGS("সেটিংস")
}

enum class WizardType {
    NONE,
    SCRIPT_TO_MOTION,
    VOICE_SRT_TO_MOTION,
    INSTANT_PASTE,
    SCIENCE_EXPLAINER,
    THUMBNAIL_MAKER,
    REMOTION_ZIP_TO_MP4
}

sealed interface AiGenState {
    data object Idle : AiGenState
    data class Loading(val statusText: String) : AiGenState
    data class Error(val message: String) : AiGenState
}

class ProMotionViewModel(
    private val repository: ProMotionRepository,
    val currentUserId: String
) : ViewModel() {

    private val _selectedTab = MutableStateFlow(StudioTab.HOME)
    val selectedTab: StateFlow<StudioTab> = _selectedTab.asStateFlow()

    private val _isDarkStudio = MutableStateFlow(true)
    val isDarkStudio: StateFlow<Boolean> = _isDarkStudio.asStateFlow()

    private val _appLanguageMode = MutableStateFlow("বাংলা + English")
    val appLanguageMode: StateFlow<String> = _appLanguageMode.asStateFlow()

    private val _activeWizard = MutableStateFlow(WizardType.NONE)
    val activeWizard: StateFlow<WizardType> = _activeWizard.asStateFlow()

    private val _isEditorOpen = MutableStateFlow(false)
    val isEditorOpen: StateFlow<Boolean> = _isEditorOpen.asStateFlow()

    private val _isExportModalOpen = MutableStateFlow(false)
    val isExportModalOpen: StateFlow<Boolean> = _isExportModalOpen.asStateFlow()

    private val _activeProject = MutableStateFlow(DemoProjects.digitalElectronicsDemo)
    val activeProject: StateFlow<ProMotionProject> = _activeProject.asStateFlow()

    private val _selectedSceneIndex = MutableStateFlow(0)
    val selectedSceneIndex: StateFlow<Int> = _selectedSceneIndex.asStateFlow()

    private val _isPlaying = MutableStateFlow(true)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentTimeSec = MutableStateFlow(0f)
    val currentTimeSec: StateFlow<Float> = _currentTimeSec.asStateFlow()

    private val _activeEditorToolIndex = MutableStateFlow(0)
    val activeEditorToolIndex: StateFlow<Int> = _activeEditorToolIndex.asStateFlow()

    private val _undoStack = MutableStateFlow<List<ProMotionProject>>(emptyList())
    val undoStack: StateFlow<List<ProMotionProject>> = _undoStack.asStateFlow()

    private val _redoStack = MutableStateFlow<List<ProMotionProject>>(emptyList())
    val redoStack: StateFlow<List<ProMotionProject>> = _redoStack.asStateFlow()

    private val _customBitmaps = MutableStateFlow<Map<String, Bitmap>>(emptyMap())
    val customBitmaps: StateFlow<Map<String, Bitmap>> = _customBitmaps.asStateFlow()

    private val _remotionInspectResult = MutableStateFlow<RemotionZipInspectResult?>(null)
    val remotionInspectResult: StateFlow<RemotionZipInspectResult?> = _remotionInspectResult.asStateFlow()

    private val _aiState = MutableStateFlow<AiGenState>(AiGenState.Idle)
    val aiState: StateFlow<AiGenState> = _aiState.asStateFlow()

    private val _statusToast = MutableStateFlow<String?>(null)
    val statusToast: StateFlow<String?> = _statusToast.asStateFlow()

    // Cloud projects combined with the 3 pre-loaded demo projects
    val cloudProjectsState: StateFlow<List<ProMotionProject>> = repository.observeProjects()
        .map<List<VideoProjectDoc>, List<ProMotionProject>> { docs ->
            val parsedCloud = docs.mapNotNull { doc ->
                ProMotionJsonCodec.parseAndFixProjectJson(doc.projectJson).getOrNull()?.copy(
                    id = doc.id,
                    title = doc.title
                )
            }
            val cloudIds = parsedCloud.map { it.id }.toSet()
            val demosNotOverridden = DemoProjects.allDemos.filter { it.id !in cloudIds }
            parsedCloud + demosNotOverridden
        }
        .catch { error ->
            val firestoreError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            Log.w("ProMotionVM", "Error observing cloud projects, showing demos", firestoreError ?: error)
            emit(DemoProjects.allDemos)
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = DemoProjects.allDemos
        )

    val savedCustomThemes: StateFlow<List<SavedThemeDoc>> = repository.observeThemes()
        .catch { error ->
            val firestoreError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            Log.w("ProMotionVM", "Error observing custom themes", firestoreError ?: error)
            emit(emptyList())
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = emptyList()
        )

    fun selectTab(tab: StudioTab) {
        _selectedTab.value = tab
    }

    fun toggleStudioTheme() {
        _isDarkStudio.value = !_isDarkStudio.value
    }

    fun cycleLanguageMode() {
        val modes = listOf("বাংলা + English", "শুদ্ধ বাংলা", "English")
        val nextIdx = (modes.indexOf(_appLanguageMode.value) + 1) % modes.size
        _appLanguageMode.value = modes[nextIdx]
    }

    fun openWizard(wizard: WizardType) {
        _aiState.value = AiGenState.Idle
        _activeWizard.value = wizard
    }

    fun closeWizard() {
        _activeWizard.value = WizardType.NONE
        _aiState.value = AiGenState.Idle
    }

    fun openProjectInEditor(project: ProMotionProject) {
        _activeProject.value = project
        _selectedSceneIndex.value = 0
        _currentTimeSec.value = 0f
        _isPlaying.value = true
        _undoStack.value = emptyList()
        _redoStack.value = emptyList()
        _activeWizard.value = WizardType.NONE
        _isEditorOpen.value = true
    }

    fun closeEditor() {
        _isPlaying.value = false
        _isEditorOpen.value = false
    }

    fun setExportModalOpen(open: Boolean) {
        if (open) _isPlaying.value = false
        _isExportModalOpen.value = open
    }

    fun selectEditorTool(index: Int) {
        _activeEditorToolIndex.value = index
    }

    fun setPlaying(playing: Boolean) {
        _isPlaying.value = playing
    }

    fun seekTo(timeSec: Float) {
        val clamped = timeSec.coerceIn(0f, _activeProject.value.totalDurationSec)
        _currentTimeSec.value = clamped
        var acc = 0f
        _activeProject.value.scenes.forEachIndexed { idx, scene ->
            if (clamped <= acc + scene.durationSec || idx == _activeProject.value.scenes.lastIndex) {
                _selectedSceneIndex.value = idx
                return
            }
            acc += scene.durationSec
        }
    }

    fun jumpToScene(sceneIndex: Int) {
        val scenes = _activeProject.value.scenes
        if (sceneIndex !in scenes.indices) return
        _selectedSceneIndex.value = sceneIndex
        val startSec = scenes.take(sceneIndex).sumOf { it.durationSec.toDouble() }.toFloat()
        _currentTimeSec.value = startSec + 0.05f
    }

    fun commitProjectEdit(updated: ProMotionProject, syncToCloud: Boolean = true) {
        val current = _activeProject.value
        _undoStack.value = (_undoStack.value + current).takeLast(30)
        _redoStack.value = emptyList()
        _activeProject.value = updated
        if (syncToCloud) {
            viewModelScope.launch {
                repository.saveProject(updated)
            }
        }
    }

    fun undo() {
        val stack = _undoStack.value
        if (stack.isEmpty()) return
        val previous = stack.last()
        _undoStack.value = stack.dropLast(1)
        _redoStack.value = (_redoStack.value + _activeProject.value).takeLast(30)
        _activeProject.value = previous
    }

    fun redo() {
        val stack = _redoStack.value
        if (stack.isEmpty()) return
        val next = stack.last()
        _redoStack.value = stack.dropLast(1)
        _undoStack.value = (_undoStack.value + _activeProject.value).takeLast(30)
        _activeProject.value = next
    }

    fun updateActiveScene(transform: (ProMotionScene) -> ProMotionScene) {
        val proj = _activeProject.value
        val idx = _selectedSceneIndex.value.coerceIn(0, (proj.scenes.size - 1).coerceAtLeast(0))
        if (proj.scenes.isEmpty()) return
        val updatedScenes = proj.scenes.toMutableList()
        updatedScenes[idx] = transform(updatedScenes[idx])
        commitProjectEdit(proj.copy(scenes = updatedScenes))
    }

    fun addNewScene() {
        val proj = _activeProject.value
        val nextNum = proj.scenes.size + 1
        val newScene = ProMotionScene(
            id = "s_${System.currentTimeMillis()}",
            chapterNum = nextNum,
            chapterBadge = "দৃশ্য $nextNum",
            heading = "নতুন দৃশ্য [$nextNum] — মূল বার্তা",
            subtext = "এখানে আপনার নতুন দৃশ্যের [বিস্তারিত তথ্য] লিখুন।",
            durationSec = 5.0f,
            template = SceneTemplate.SPLIT_CARD
        )
        val updated = proj.copy(scenes = proj.scenes + newScene)
        commitProjectEdit(updated)
        jumpToScene(updated.scenes.lastIndex)
        showToast("✓ নতুন সিন যোগ হয়েছে!")
    }

    fun deleteActiveScene() {
        val proj = _activeProject.value
        if (proj.scenes.size <= 1) {
            showToast("ভিডিওতে অন্তত ১টি সিন থাকতে হবে!")
            return
        }
        val idx = _selectedSceneIndex.value
        val updatedScenes = proj.scenes.filterIndexed { i, _ -> i != idx }
            .mapIndexed { newIdx, s -> s.copy(chapterNum = newIdx + 1) }
        _selectedSceneIndex.value = (idx - 1).coerceAtLeast(0)
        commitProjectEdit(proj.copy(scenes = updatedScenes))
        showToast("🗑️ সিন মুছে ফেলা হয়েছে")
    }

    fun applyLookPresetToProject(look: LookPreset) {
        val proj = _activeProject.value
        commitProjectEdit(
            proj.copy(
                lookId = look.id,
                bgHex = look.bgHex,
                bgSecondaryHex = look.bgSecondaryHex,
                cardHex = look.cardHex,
                inkHex = look.inkHex,
                accentHex = look.accentHex,
                hlHex = look.hlHex,
                successHex = look.successHex,
                dangerHex = look.dangerHex,
                bgPattern = look.bgPattern,
                isDualTheme = look.isDualTheme
            )
        )
        showToast("✨ '${look.name}' থিম পুরো ভিডিওতে প্রয়োগ হয়েছে!")
    }

    fun saveCurrentThemeToCloud(customName: String) {
        val proj = _activeProject.value
        viewModelScope.launch {
            val res = repository.saveCustomTheme(
                name = customName.ifBlank { "${proj.title} Theme" },
                bgHex = proj.bgHex,
                cardHex = proj.cardHex,
                inkHex = proj.inkHex,
                accentHex = proj.accentHex,
                hlHex = proj.hlHex
            )
            if (res.isSuccess) {
                showToast("⭐ থিমটি ক্লাউডে সেভ হয়েছে!")
            } else {
                showToast("থিম সেভ করতে সমস্যা: ${res.exceptionOrNull()?.localizedMessage}")
            }
        }
    }

    fun duplicateProject(project: ProMotionProject) {
        val copyProj = project.copy(
            id = "proj_${System.currentTimeMillis()}",
            title = "${project.title} (Copy)"
        )
        viewModelScope.launch {
            repository.saveProject(copyProj)
            showToast("✓ প্রজেক্ট ডুপ্লিকেট হয়েছে!")
        }
    }

    fun deleteProject(projectId: String) {
        viewModelScope.launch {
            repository.deleteProject(projectId)
            showToast("🗑️ প্রজেক্ট মুছে ফেলা হয়েছে")
        }
    }

    fun setCustomBitmapForSlot(slotKey: String, bitmap: Bitmap) {
        _customBitmaps.value = _customBitmaps.value + (slotKey to bitmap)
        showToast("🖼️ '$slotKey' স্লটে ছবি যুক্ত হয়েছে!")
    }

    fun generateVideoWithGeminiAi(
        topicOrScript: String,
        aspectRatio: String,
        lookId: String,
        languageMode: String,
        durationPreset: String,
        srtRaw: String = ""
    ) {
        if (topicOrScript.isBlank() && srtRaw.isBlank()) {
            _aiState.value = AiGenState.Error("অনুগ্রহ করে ভিডিওর বিষয়, স্ক্রিপ্ট বা SRT লিখুন।")
            return
        }
        viewModelScope.launch {
            _aiState.value = AiGenState.Loading("✨ Gemini AI দিয়ে মোশন সিন ও ডায়াগ্রাম তৈরি হচ্ছে...")
            val result = GeminiPromptAndAiService.generateProjectViaFirebaseAi(
                topicOrScript = topicOrScript.ifBlank { "Voiceover Synced Explainer Video" },
                aspectRatio = aspectRatio,
                lookId = lookId,
                languageMode = languageMode,
                durationPreset = durationPreset,
                srtRaw = srtRaw
            )
            result.onSuccess { generatedProject ->
                val look = BUILTIN_LOOKS.firstOrNull { it.id == lookId } ?: BUILTIN_LOOKS[3]
                val styled = generatedProject.copy(
                    id = "proj_${System.currentTimeMillis()}",
                    aspectRatio = aspectRatio,
                    lookId = look.id,
                    bgHex = look.bgHex,
                    bgSecondaryHex = look.bgSecondaryHex,
                    cardHex = look.cardHex,
                    inkHex = look.inkHex,
                    accentHex = look.accentHex,
                    hlHex = look.hlHex,
                    isDualTheme = look.isDualTheme
                )
                repository.saveProject(styled)
                _aiState.value = AiGenState.Idle
                openProjectInEditor(styled)
                showToast("✨ Gemini সফলভাবে ভিডিও স্টোরিবোর্ড তৈরি করেছে!")
            }.onFailure { err ->
                _aiState.value = AiGenState.Error(err.localizedMessage ?: "AI জেনারেশন ব্যর্থ হয়েছে।")
            }
        }
    }

    fun generateSrtWithGeminiAi(topicOrScript: String, onSrtGenerated: (String) -> Unit) {
        viewModelScope.launch {
            _aiState.value = AiGenState.Loading("🎙️ Gemini দিয়ে টাইমস্ট্যাম্পসহ .srt তৈরি হচ্ছে...")
            val res = GeminiPromptAndAiService.generateSrtForTopicViaFirebaseAi(
                topicOrScript.ifBlank { "ডিজিটাল ইলেকট্রনিক্স ও সিগন্যাল এক্সপ্লেনার" }
            )
            res.onSuccess { srtText ->
                _aiState.value = AiGenState.Idle
                onSrtGenerated(srtText)
                showToast("✓ টাইমস্ট্যাম্পসহ SRT তৈরি হয়েছে!")
            }.onFailure { err ->
                _aiState.value = AiGenState.Error(err.localizedMessage ?: "SRT তৈরি ব্যর্থ হয়েছে।")
            }
        }
    }

    fun translateActiveProjectWithGeminiAi(targetLanguage: String) {
        val proj = _activeProject.value
        viewModelScope.launch {
            showToast("🌐 '$targetLanguage' ভাষায় অনুবাদ হচ্ছে...")
            val res = GeminiPromptAndAiService.translateProjectViaFirebaseAi(proj, targetLanguage)
            res.onSuccess { translated ->
                commitProjectEdit(
                    proj.copy(
                        title = translated.title,
                        languageMode = targetLanguage,
                        scenes = translated.scenes,
                        srtCues = translated.srtCues
                    )
                )
                showToast("✓ পুরো ভিডিও '$targetLanguage'-এ অনুবাদ সম্পন্ন!")
            }.onFailure { err ->
                showToast("অনুবাদ ব্যর্থ: ${err.localizedMessage}")
            }
        }
    }

    fun importPastedJson(rawJson: String): Boolean {
        val result = ProMotionJsonCodec.parseAndFixProjectJson(rawJson)
        return if (result.isSuccess) {
            val proj = result.getOrThrow().copy(id = "proj_${System.currentTimeMillis()}")
            viewModelScope.launch { repository.saveProject(proj) }
            openProjectInEditor(proj)
            showToast("⚡ JSON সফলভাবে লোড ও অটো-ফিক্স হয়েছে!")
            true
        } else {
            showToast("❌ JSON ফরম্যাট সঠিক নয়: ${result.exceptionOrNull()?.localizedMessage}")
            false
        }
    }

    fun loadRemotionZipUri(context: Context, uri: Uri) {
        viewModelScope.launch {
            _aiState.value = AiGenState.Loading("📦 Remotion (.zip) প্রজেক্ট ফাইল ও অ্যাসেট পড়া হচ্ছে...")
            val result = withContext(Dispatchers.IO) {
                RemotionZipConverter.inspectAndParseRemotionZip(context, uri)
            }
            result.onSuccess { inspect ->
                _remotionInspectResult.value = inspect
                if (inspect.extractedBitmaps.isNotEmpty()) {
                    _customBitmaps.value = _customBitmaps.value + inspect.extractedBitmaps
                }
                _activeProject.value = inspect.instantConvertedProject
                repository.saveProject(inspect.instantConvertedProject)
                _aiState.value = AiGenState.Idle
                showToast("✓ '${inspect.zipFileName}' লোড হয়েছে (${inspect.instantConvertedProject.scenes.size}টি সিন প্রস্তুত)!")
            }.onFailure { err ->
                _aiState.value = AiGenState.Error(err.localizedMessage ?: "Remotion .zip পড়া যায়নি")
            }
        }
    }

    fun loadSampleRemotionZip() {
        val sample = RemotionZipConverter.createSampleRemotionInspectResult()
        _remotionInspectResult.value = sample
        _activeProject.value = sample.instantConvertedProject
        viewModelScope.launch {
            repository.saveProject(sample.instantConvertedProject)
        }
        showToast("🧪 স্যাম্পল Remotion (.zip) প্রজেক্ট লোড হয়েছে! এখনই MP4 এক্সপোর্ট করতে পারেন।")
    }

    fun transpileRemotionZipWithGeminiAi() {
        val inspect = _remotionInspectResult.value ?: return
        viewModelScope.launch {
            _aiState.value = AiGenState.Loading("✨ Gemini AI দিয়ে Remotion (.tsx) কোড ডিপ-ট্রান্সপাইল হচ্ছে...")
            val res = GeminiPromptAndAiService.transpileRemotionSourceViaFirebaseAi(inspect)
            res.onSuccess { aiProject ->
                val updated = aiProject.copy(
                    id = inspect.instantConvertedProject.id,
                    title = aiProject.title.ifBlank { inspect.instantConvertedProject.title }
                )
                _remotionInspectResult.value = inspect.copy(instantConvertedProject = updated)
                _activeProject.value = updated
                repository.saveProject(updated)
                _aiState.value = AiGenState.Idle
                showToast("✨ Gemini AI সফলভাবে Remotion কোডকে মোশন সিনে রূপান্তর করেছে!")
            }.onFailure { err ->
                _aiState.value = AiGenState.Error(err.localizedMessage ?: "AI ট্রান্সপাইল ব্যর্থ হয়েছে, ইনস্ট্যান্ট প্রজেক্ট প্রস্তুত আছে।")
            }
        }
    }

    fun showToast(message: String) {
        _statusToast.value = message
    }

    fun clearToast() {
        _statusToast.value = null
    }
}
