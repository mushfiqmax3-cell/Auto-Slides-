package com.example.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.CanvasVideoEngine
import com.example.model.BUILTIN_LOOKS
import com.example.model.ProMotionProject
import com.example.ui.components.CreationWizardsModal
import com.example.ui.components.ExportModal
import com.example.ui.components.MobileVideoEditor
import com.example.utils.GeminiPromptAndAiService
import com.example.viewmodel.ProMotionViewModel
import com.example.viewmodel.StudioTab
import com.example.viewmodel.WizardType

@Composable
fun StudioMainScreen(
    viewModel: ProMotionViewModel,
    onSignOut: () -> Unit
) {
    val selectedTab by viewModel.selectedTab.collectAsState()
    val isDarkStudio by viewModel.isDarkStudio.collectAsState()
    val appLanguageMode by viewModel.appLanguageMode.collectAsState()
    val activeWizard by viewModel.activeWizard.collectAsState()
    val isEditorOpen by viewModel.isEditorOpen.collectAsState()
    val isExportModalOpen by viewModel.isExportModalOpen.collectAsState()
    val aiState by viewModel.aiState.collectAsState()
    val projects by viewModel.cloudProjectsState.collectAsState()
    val savedThemes by viewModel.savedCustomThemes.collectAsState()
    val statusToast by viewModel.statusToast.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(statusToast) {
        statusToast?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearToast()
        }
    }

    if (isExportModalOpen) {
        ExportModal(
            viewModel = viewModel,
            onDismiss = { viewModel.setExportModalOpen(false) }
        )
        return
    }

    if (isEditorOpen) {
        MobileVideoEditor(
            viewModel = viewModel,
            onCloseEditor = { viewModel.closeEditor() },
            onOpenExport = { viewModel.setExportModalOpen(true) }
        )
        return
    }

    if (activeWizard != WizardType.NONE) {
        CreationWizardsModal(
            wizardType = activeWizard,
            viewModel = viewModel,
            aiState = aiState,
            onDismiss = { viewModel.closeWizard() }
        )
        return
    }

    val bgColor = if (isDarkStudio) Color(0xFF0B0F19) else Color(0xFFF3F7F8)
    val cardBg = if (isDarkStudio) Color(0xFF131B2E) else Color.White
    val textInk = if (isDarkStudio) Color.White else Color(0xFF0F172A)

    Scaffold(
        containerColor = bgColor,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            StudioTopHeaderBar(
                isDarkStudio = isDarkStudio,
                languageMode = appLanguageMode,
                onToggleTheme = { viewModel.toggleStudioTheme() },
                onRefresh = { viewModel.showToast("↻ সব প্রজেক্ট ও থিম সিঙ্ক করা হয়েছে") },
                onCycleLanguage = { viewModel.cycleLanguageMode() }
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = if (isDarkStudio) Color(0xFF131B2E) else Color.White,
                modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                val tabItems = listOf(
                    Triple(StudioTab.HOME, Icons.Default.Home, "হোম"),
                    Triple(StudioTab.PROJECTS, Icons.Default.Movie, "প্রজেক্ট"),
                    Triple(StudioTab.THEMES, Icons.Default.Palette, "থিম"),
                    Triple(StudioTab.TOOLS, Icons.Default.Build, "টুল"),
                    Triple(StudioTab.SETTINGS, Icons.Default.Settings, "সেটিংস")
                )
                tabItems.forEach { (tab, icon, label) ->
                    NavigationBarItem(
                        selected = selectedTab == tab,
                        onClick = { viewModel.selectTab(tab) },
                        icon = { Icon(icon, contentDescription = label) },
                        label = { Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}"),
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF0B0F19),
                            selectedTextColor = Color(0xFFF59E0B),
                            indicatorColor = Color(0xFFF59E0B),
                            unselectedIconColor = Color(0xFF94A3B8),
                            unselectedTextColor = Color(0xFF94A3B8)
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            when (selectedTab) {
                StudioTab.HOME -> HomeTabContent(
                    projects = projects,
                    cardBg = cardBg,
                    textInk = textInk,
                    onOpenWizard = { viewModel.openWizard(it) },
                    onOpenProject = { viewModel.openProjectInEditor(it) },
                    onDuplicateProject = { viewModel.duplicateProject(it) },
                    onDeleteProject = { viewModel.deleteProject(it.id) }
                )

                StudioTab.PROJECTS -> ProjectsTabContent(
                    projects = projects,
                    cardBg = cardBg,
                    textInk = textInk,
                    onNewVideo = { viewModel.openWizard(WizardType.SCRIPT_TO_MOTION) },
                    onOpenProject = { viewModel.openProjectInEditor(it) },
                    onDuplicateProject = { viewModel.duplicateProject(it) },
                    onDeleteProject = { viewModel.deleteProject(it.id) }
                )

                StudioTab.THEMES -> ThemesTabContent(
                    savedThemes = savedThemes,
                    cardBg = cardBg,
                    textInk = textInk,
                    onApplyLookAndOpen = { look ->
                        viewModel.applyLookPresetToProject(look)
                        viewModel.openProjectInEditor(viewModel.activeProject.value)
                    }
                )

                StudioTab.TOOLS -> PowerToolsTabContent(
                    cardBg = cardBg,
                    textInk = textInk,
                    onOpenWizard = { viewModel.openWizard(it) },
                    onOpenWaveformLab = {
                        viewModel.openProjectInEditor(projects.first())
                        viewModel.selectEditorTool(9)
                    }
                )

                StudioTab.SETTINGS -> SettingsAndSkillTabContent(
                    cardBg = cardBg,
                    textInk = textInk,
                    userId = viewModel.currentUserId,
                    onCopySkillPrompt = { ctx ->
                        GeminiPromptAndAiService.copyToClipboard(
                            ctx,
                            "ProMotion Gemini Skill v5",
                            GeminiPromptAndAiService.GEMINI_SKILL_SYSTEM_PROMPT_V5
                        )
                        viewModel.showToast("📋 ProMotion Gemini Skill v5 কপি হয়েছে!")
                    },
                    onSignOut = onSignOut
                )
            }
        }
    }
}

@Composable
private fun StudioTopHeaderBar(
    isDarkStudio: Boolean,
    languageMode: String,
    onToggleTheme: () -> Unit,
    onRefresh: () -> Unit,
    onCycleLanguage: () -> Unit
) {
    Surface(
        color = if (isDarkStudio) Color(0xFF131B2E) else Color.White,
        shadowElevation = 4.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .windowInsetsPadding(WindowInsets.statusBars)
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Left: [PM] + প্রোমোশন + PRO + ● Active • v2.0
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(Color(0xFFF59E0B), Color(0xFFD97706))
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "PM",
                        color = Color(0xFF0B0F19),
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 13.sp
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "প্রোমোশন",
                            color = if (isDarkStudio) Color.White else Color(0xFF0F172A),
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            color = Color(0xFFF59E0B),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "PRO",
                                color = Color(0xFF0B0F19),
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 10.sp,
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                            )
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF10B981))
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Active • v2.0",
                            color = Color(0xFF10B981),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            // Right: Theme toggle, Refresh, Language pill
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onToggleTheme,
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("header_theme_toggle")
                ) {
                    Icon(
                        imageVector = if (isDarkStudio) Icons.Default.LightMode else Icons.Default.DarkMode,
                        contentDescription = "Toggle Theme",
                        tint = Color(0xFFF59E0B),
                        modifier = Modifier.size(20.dp)
                    )
                }
                IconButton(
                    onClick = onRefresh,
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("header_refresh_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Refresh",
                        tint = Color(0xFF38BDF8),
                        modifier = Modifier.size(20.dp)
                    )
                }
                Surface(
                    color = Color(0xFF1E293B),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .clickable { onCycleLanguage() }
                        .testTag("header_language_pill")
                ) {
                    Text(
                        text = languageMode,
                        color = Color(0xFF38BDF8),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun HomeTabContent(
    projects: List<ProMotionProject>,
    cardBg: Color,
    textInk: Color,
    onOpenWizard: (WizardType) -> Unit,
    onOpenProject: (ProMotionProject) -> Unit,
    onDuplicateProject: (ProMotionProject) -> Unit,
    onDeleteProject: (ProMotionProject) -> Unit
) {
    // 1. Primary Hero CTA Button
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(60.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(
                Brush.horizontalGradient(
                    listOf(Color(0xFFF59E0B), Color(0xFFD97706))
                )
            )
            .clickable { onOpenWizard(WizardType.SCRIPT_TO_MOTION) }
            .testTag("hero_create_video_button"),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier.padding(horizontal = 12.dp)
        ) {
            Icon(Icons.Default.AddCircle, contentDescription = null, tint = Color(0xFF0B0F19))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "+ নতুন ভিডিও বানান (Look বাছুন, Gemini-কে বলুন)",
                color = Color(0xFF0B0F19),
                fontWeight = FontWeight.ExtraBold,
                fontSize = 14.sp
            )
        }
    }

    Spacer(modifier = Modifier.height(18.dp))

    // 2. কী ধরনের ভিডিও? — 5 Creation Mode Grid Cards
    Text(
        text = "কী ধরনের ভিডিও?",
        color = Color(0xFFF59E0B),
        fontWeight = FontWeight.Bold,
        fontSize = 16.sp
    )
    Spacer(modifier = Modifier.height(10.dp))

    val creationCards = listOf(
        Triple(
            WizardType.SCRIPT_TO_MOTION,
            "✨ Script থেকে Motion",
            "লেখা বা বিষয় দিলে পুরো motion ভিডিও"
        ),
        Triple(
            WizardType.VOICE_SRT_TO_MOTION,
            "🎙️ Voice / ভিডিও থেকে Motion",
            "কথার সাথে মিলিয়ে 100% Voice-Synced Motion"
        ),
        Triple(
            WizardType.INSTANT_PASTE,
            "⚡ শুধু Paste",
            "Gemini-এর বানানো JSON সরাসরি বসান"
        ),
        Triple(
            WizardType.SCIENCE_EXPLAINER,
            "🔬 Explainer ও বইয়ের পাতা",
            "বিজ্ঞান, পলিটেকনিক, ডায়াগ্রাম ও ওয়েভফর্ম এক্সপ্লেনার"
        ),
        Triple(
            WizardType.THUMBNAIL_MAKER,
            "🖼️ Thumbnail",
            "ভিডিও থেকে 16:9 YouTube-এর ছবি"
        ),
        Triple(
            WizardType.REMOTION_ZIP_TO_MP4,
            "📦 Remotion (.zip) ➔ MP4",
            "রিমোশন জিপ ফাইল আপলোড করে সরাসরি MP4 ভিডিওতে কনভার্ট"
        )
    )

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        creationCards.chunked(2).forEach { rowCards ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                rowCards.forEach { (wType, title, desc) ->
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onOpenWizard(wType) }
                            .border(1.dp, Color(0xFF334155), RoundedCornerShape(16.dp))
                            .testTag("mode_card_${wType.name.lowercase()}"),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = cardBg)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = title,
                                color = textInk,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = desc,
                                color = Color(0xFF94A3B8),
                                fontSize = 12.sp,
                                lineHeight = 16.sp
                            )
                        }
                    }
                }
                if (rowCards.size == 1) {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
        }
    }

    Spacer(modifier = Modifier.height(22.dp))

    // 3. আমার ভিডিও (My Recent Videos Section)
    Text(
        text = "আমার ভিডিও (${projects.size})",
        color = Color(0xFFF59E0B),
        fontWeight = FontWeight.Bold,
        fontSize = 16.sp
    )
    Spacer(modifier = Modifier.height(10.dp))

    projects.forEachIndexed { idx, proj ->
        ProjectItemCard(
            project = proj,
            cardBg = cardBg,
            textInk = textInk,
            tagSuffix = "$idx",
            onOpen = { onOpenProject(proj) },
            onDuplicate = { onDuplicateProject(proj) },
            onDelete = { onDeleteProject(proj) }
        )
        Spacer(modifier = Modifier.height(12.dp))
    }
}

@Composable
private fun ProjectItemCard(
    project: ProMotionProject,
    cardBg: Color,
    textInk: Color,
    tagSuffix: String,
    onOpen: () -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFF334155), RoundedCornerShape(16.dp))
            .clickable { onOpen() }
            .testTag("project_card_$tagSuffix"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = cardBg)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Live Mini Canvas Thumbnail
                Box(
                    modifier = Modifier
                        .width(116.dp)
                        .aspectRatio(16f / 9f)
                        .clip(RoundedCornerShape(10.dp))
                        .border(1.dp, Color(0xFF38BDF8).copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        drawIntoCanvas { canvas ->
                            CanvasVideoEngine.renderFrame(
                                canvas = canvas.nativeCanvas,
                                width = size.width,
                                height = size.height,
                                project = project,
                                globalTimeSec = 1.0f
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = project.title,
                        color = textInk,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        maxLines = 2
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${project.aspectRatio} • ${project.scenes.size} সিন • ${project.totalDurationSec.toInt()}s • আজ",
                        color = Color(0xFF38BDF8),
                        fontSize = 12.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onOpen,
                    modifier = Modifier
                        .weight(1f)
                        .height(38.dp)
                        .testTag("open_project_btn_$tagSuffix"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFF59E0B),
                        contentColor = Color(0xFF0B0F19)
                    )
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("খুলুন", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
                OutlinedButton(
                    onClick = onDuplicate,
                    modifier = Modifier
                        .height(38.dp)
                        .testTag("duplicate_project_btn_$tagSuffix"),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color(0xFF38BDF8))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("ডুপ্লিকেট", fontSize = 12.sp, color = Color(0xFF38BDF8))
                }
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier
                        .size(38.dp)
                        .testTag("delete_project_btn_$tagSuffix")
                ) {
                    Icon(Icons.Default.Delete, contentDescription = "মুছুন", tint = Color(0xFFF87171))
                }
            }
        }
    }
}

@Composable
private fun ProjectsTabContent(
    projects: List<ProMotionProject>,
    cardBg: Color,
    textInk: Color,
    onNewVideo: () -> Unit,
    onOpenProject: (ProMotionProject) -> Unit,
    onDuplicateProject: (ProMotionProject) -> Unit,
    onDeleteProject: (ProMotionProject) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("🎬 সেভ করা প্রজেক্টসমূহ (${projects.size})", color = Color(0xFFF59E0B), fontWeight = FontWeight.Bold, fontSize = 17.sp)
        Button(
            onClick = onNewVideo,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B), contentColor = Color(0xFF0B0F19))
        ) {
            Text("+ নতুন প্রজেক্ট", fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
    }
    Spacer(modifier = Modifier.height(12.dp))
    projects.forEachIndexed { idx, proj ->
        ProjectItemCard(
            project = proj,
            cardBg = cardBg,
            textInk = textInk,
            tagSuffix = "tab_$idx",
            onOpen = { onOpenProject(proj) },
            onDuplicate = { onDuplicateProject(proj) },
            onDelete = { onDeleteProject(proj) }
        )
        Spacer(modifier = Modifier.height(12.dp))
    }
}

@Composable
private fun ThemesTabContent(
    savedThemes: List<com.example.model.SavedThemeDoc>,
    cardBg: Color,
    textInk: Color,
    onApplyLookAndOpen: (com.example.model.LookPreset) -> Unit
) {
    Text("🎨 ১৬+ মাস্টার লুক ও থিম স্টুডিও", color = Color(0xFFF59E0B), fontWeight = FontWeight.Bold, fontSize = 17.sp)
    Spacer(modifier = Modifier.height(6.dp))
    Text("যেকোনো থিমে ট্যাপ করলে বর্তমান ভিডিওটি সেই চেহারায় রূপান্তরিত হবে:", color = Color(0xFF94A3B8), fontSize = 13.sp)
    Spacer(modifier = Modifier.height(12.dp))

    BUILTIN_LOOKS.forEach { look ->
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 5.dp)
                .clickable { onApplyLookAndOpen(look) }
                .border(1.dp, Color(0xFF334155), RoundedCornerShape(14.dp)),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = cardBg)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(look.name, color = textInk, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text("${look.category} • ${look.subtitleBn}", color = Color(0xFF94A3B8), fontSize = 12.sp)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(look.bgHex, look.cardHex, look.accentHex, look.hlHex).forEach { hex ->
                        Box(
                            modifier = Modifier
                                .size(22.dp)
                                .clip(CircleShape)
                                .background(Color(CanvasVideoEngine.parseColorSafe(hex)))
                                .border(1.dp, Color.White, CircleShape)
                        )
                    }
                }
            }
        }
    }

    if (savedThemes.isNotEmpty()) {
        Spacer(modifier = Modifier.height(16.dp))
        Text("⭐ আপনার সেভ করা কাস্টম থিম (${savedThemes.size})", color = Color(0xFF38BDF8), fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Spacer(modifier = Modifier.height(8.dp))
        savedThemes.forEach { st ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                colors = CardDefaults.cardColors(containerColor = cardBg)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(st.name, color = textInk, fontWeight = FontWeight.Bold)
                    Text(st.accentHex, color = Color(0xFFF59E0B), fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun PowerToolsTabContent(
    cardBg: Color,
    textInk: Color,
    onOpenWizard: (WizardType) -> Unit,
    onOpenWaveformLab: () -> Unit
) {
    Text("🛠️ প্রোমোশন পাওয়ার টুলস (Power Tools)", color = Color(0xFFF59E0B), fontWeight = FontWeight.Bold, fontSize = 17.sp)
    Spacer(modifier = Modifier.height(12.dp))

    val tools = listOf(
        Triple("📦 Remotion (.zip) থেকে MP4 ভিডিও কনভার্টার", "রিমোশন প্রজেক্টের জিপ ফাইল আপলোড করে সরাসরি ফোনেই .mp4 ভিডিও তৈরি করুন") { onOpenWizard(WizardType.REMOTION_ZIP_TO_MP4) },
        Triple("🎙️ ফ্রি SRT জেনারেটর ও সিঙ্কার", "ভয়েস বা স্ক্রিপ্ট থেকে টাইমস্ট্যাম্পসহ .srt তৈরি করুন") { onOpenWizard(WizardType.VOICE_SRT_TO_MOTION) },
        Triple("⚡ JSON কোড অটো-ফিক্সার", "Gemini থেকে কপি করা JSON ভ্যালিডেট ও রান করুন") { onOpenWizard(WizardType.INSTANT_PASTE) },
        Triple("📈 ডিজিটাল ওয়েভফর্ম ও লজিক ল্যাব", "Square Wave, Rise/Fall Time ও TTL লজিক লেভেল সিমুলেটর") { onOpenWaveformLab() },
        Triple("🖼️ 16:9 YouTube Thumbnail মেকার", "যেকোনো দৃশ্য থেকে 1080p PNG থাম্বনেইল ডাউনলোড করুন") { onOpenWizard(WizardType.THUMBNAIL_MAKER) }
    )

    tools.forEach { (title, desc, action) ->
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp)
                .clickable { action() }
                .border(1.dp, Color(0xFF334155), RoundedCornerShape(16.dp)),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = cardBg)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(title, color = textInk, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Text(desc, color = Color(0xFF94A3B8), fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun SettingsAndSkillTabContent(
    cardBg: Color,
    textInk: Color,
    userId: String,
    onCopySkillPrompt: (android.content.Context) -> Unit,
    onSignOut: () -> Unit
) {
    val context = LocalContext.current
    Text("⚙️ সেটিংস ও Gemini Skill v5", color = Color(0xFFF59E0B), fontWeight = FontWeight.Bold, fontSize = 17.sp)
    Spacer(modifier = Modifier.height(12.dp))

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = cardBg)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "🤖 ProMotion Gemini System Skill v5",
                color = textInk,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "এই সিস্টেম প্রম্পটটি কপি করে আপনার ফ্রি Gemini অ্যাপে দিলে Gemini সবসময় ১০০% সঠিক ProMotionProjectJSON v5 তৈরি করবে:",
                color = Color(0xFF94A3B8),
                fontSize = 12.sp
            )
            Spacer(modifier = Modifier.height(10.dp))
            Surface(
                color = Color(0xFF0B0F19),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = GeminiPromptAndAiService.GEMINI_SKILL_SYSTEM_PROMPT_V5,
                    color = Color(0xFF38BDF8),
                    fontSize = 11.sp,
                    modifier = Modifier.padding(12.dp)
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Button(
                onClick = { onCopySkillPrompt(context) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("copy_gemini_skill_button"),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B), contentColor = Color(0xFF0B0F19))
            ) {
                Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("📋 ProMotion Gemini Skill v5 কপি করুন", fontWeight = FontWeight.Bold)
            }
        }
    }

    Spacer(modifier = Modifier.height(16.dp))

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = cardBg)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("☁️ ক্লাউড অ্যাকাউন্ট ও সিঙ্ক", color = textInk, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text("User UID: ${userId.take(12)}...", color = Color(0xFF10B981), fontSize = 12.sp)
            Spacer(modifier = Modifier.height(12.dp))
            OutlinedButton(
                onClick = onSignOut,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("sign_out_button")
            ) {
                Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null, tint = Color(0xFFF87171))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Sign Out", color = Color(0xFFF87171), fontWeight = FontWeight.Bold)
            }
        }
    }
}
