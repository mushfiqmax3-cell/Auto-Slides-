"use client";

import type { EditTarget } from "@/lib/renderer";
import type {
  LayerOverride,
  OverridesMap,
  Project,
  ProjectSnapshot,
  Slide,
} from "@/lib/types";
import { uid } from "@/lib/types";
import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";

export type WizardStep = 1 | 2 | 3;

export type ContentMode = "mcq" | "notes" | "mixed";

interface StoreState {
  step: WizardStep;
  project: Project;
  overrides: OverridesMap;
  activeIndex: number;
  selectedLayerId: string | null;
  cloudId: string | null;
  cloudTitle: string;
  contentMode: ContentMode;

  setContentMode: (m: ContentMode) => void;
  setStep: (s: WizardStep) => void;
  patchProject: (patch: Partial<Project>) => void;
  setSlides: (slides: Slide[]) => void;
  updateSlide: (id: string, patch: Partial<Slide>) => void;
  removeSlide: (id: string) => void;
  moveSlide: (id: string, dir: -1 | 1) => void;
  setActiveIndex: (i: number) => void;
  selectLayer: (id: string | null) => void;
  setOverride: (entryKey: string, layerId: string, patch: LayerOverride) => void;
  clearOverride: (entryKey: string, layerId: string) => void;
  resetEntryOverrides: (entryKey: string) => void;
  applyEdit: (target: EditTarget, value: string, slideId?: string) => void;
  loadSnapshot: (snap: ProjectSnapshot) => void;
  snapshot: () => ProjectSnapshot;
  setCloudRef: (id: string | null, title: string) => void;
  resetProject: () => void;
}

export const DEFAULT_PROJECT: Project = {
  title: "বাংলাদেশের ইতিহাস — অধ্যায় ১",
  subtitle: "",
  backgroundImage: undefined,
  backgroundOpacity: 0.4,
  coverImage: undefined,
  brandLeft: { enabled: false, type: "text", text: "আমার একাডেমি", image: undefined },
  brandRight: { enabled: false, type: "text", text: "AutoSlides", image: undefined },
  themeId: "midnight",
  accent: "",
  secondary: "",
  optionStyle: "soft",
  showAnswers: true,
  includeCover: true,
  includeClosing: true,
  slides: [],
};

export const DEMO_TEXT = `১। বাংলাদেশের জাতীয় সংগীতের রচয়িতা কে?
ক) রবীন্দ্রনাথ ঠাকুর
খ) কাজী নজরুল ইসলাম
গ) দ্বিজেন্দ্রলাল রায়
ঘ) অতুল প্রসাদ সেন
উত্তর: ক
ব্যাখ্যা: আমার সোনার বাংলা গানটি রচনা করেন রবীন্দ্রনাথ ঠাকুর।

২। বাংলাদেশের মুক্তিযুদ্ধ কত সালে সংঘটিত হয়?
ক) ১৯৬৯ সালে
খ) ১৯৭০ সালে
গ) ১৯৭১ সালে
ঘ) ১৯৭২ সালে
উত্তর: গ

# ভাষা আন্দোলন (১৯৫২)
- ২১শে ফেব্রুয়ারি বাংলা ভাষার জন্য আত্মত্যাগের দিন
- সালাম, বরকত, রফিক, জব্বার শাহাদত বরণ করেন
- ১৯৯৯ সালে ইউনেস্কো একুশে ফেব্রুয়ারিকে আন্তর্জাতিক মাতৃভাষা দিবস ঘোষণা করে
- ঢাকা মেডিকেল কলেজ এলাকায় প্রথম শহীদ মিনার নির্মিত হয়

৩। বাংলাদেশের জাতীয় ফুল কোনটি?
ক) গোলাপ
খ) শাপলা
গ) গাঁদা
ঘ) পদ্ম
উত্তর: খ

৪। সুন্দরবন কোন জেলায় অবস্থিত?
ক) কক্সবাজার
খ) খুলনা ও সাতক্ষীরা
গ) বরগুনা
ঘ) পটুয়াখালী
উত্তর: খ

# মুক্তিযুদ্ধের গুরুত্বপূর্ণ তারিখ
- ৭ই মার্চ: বঙ্গবন্ধুর ঐতিহাসিক ভাষণ
- ২৬শে মার্চ: স্বাধীনতা ঘোষণা
- ১৬ই ডিসেম্বর: বিজয় দিবস`;

// safe localStorage (quota overflows should not crash the app)
const safeStorage = {
  getItem: (name: string) => {
    try {
      return localStorage.getItem(name);
    } catch {
      return null;
    }
  },
  setItem: (name: string, value: string) => {
    try {
      localStorage.setItem(name, value);
    } catch {
      /* storage full — ignore */
    }
  },
  removeItem: (name: string) => {
    try {
      localStorage.removeItem(name);
    } catch {
      /* noop */
    }
  },
};

export const useSlideStore = create<StoreState>()(
  persist(
    (set, get) => ({
      step: 1,
      project: DEFAULT_PROJECT,
      overrides: {},
      activeIndex: 0,
      selectedLayerId: null,
      cloudId: null,
      cloudTitle: "",
      contentMode: "mixed",

      setContentMode: (contentMode) => set({ contentMode }),
      setStep: (step) => set({ step }),
      patchProject: (patch) => set((s) => ({ project: { ...s.project, ...patch } })),
      setSlides: (slides) =>
        set((s) => ({ project: { ...s.project, slides }, activeIndex: 0, selectedLayerId: null })),
      updateSlide: (id, patch) =>
        set((s) => ({
          project: {
            ...s.project,
            slides: s.project.slides.map((sl) =>
              sl.id === id ? ({ ...sl, ...patch } as Slide) : sl,
            ),
          },
        })),
      removeSlide: (id) =>
        set((s) => ({
          project: { ...s.project, slides: s.project.slides.filter((sl) => sl.id !== id) },
          selectedLayerId: null,
        })),
      moveSlide: (id, dir) =>
        set((s) => {
          const slides = [...s.project.slides];
          const i = slides.findIndex((sl) => sl.id === id);
          const j = i + dir;
          if (i < 0 || j < 0 || j >= slides.length) return s;
          [slides[i], slides[j]] = [slides[j], slides[i]];
          return { project: { ...s.project, slides } };
        }),
      setActiveIndex: (activeIndex) => set({ activeIndex, selectedLayerId: null }),
      selectLayer: (selectedLayerId) => set({ selectedLayerId }),
      setOverride: (entryKey, layerId, patch) =>
        set((s) => ({
          overrides: {
            ...s.overrides,
            [entryKey]: { ...(s.overrides[entryKey] ?? {}), [layerId]: { ...(s.overrides[entryKey]?.[layerId] ?? {}), ...patch } },
          },
        })),
      clearOverride: (entryKey, layerId) =>
        set((s) => {
          const next = { ...s.overrides };
          if (next[entryKey]) {
            next[entryKey] = { ...next[entryKey] };
            delete next[entryKey][layerId];
          }
          return { overrides: next };
        }),
      resetEntryOverrides: (entryKey) =>
        set((s) => {
          const next = { ...s.overrides };
          delete next[entryKey];
          return { overrides: next, selectedLayerId: null };
        }),
      applyEdit: (target, value) =>
        set((s) => {
          const project = { ...s.project };
          if (target.type === "projectTitle") project.title = value;
          else if (target.type === "projectSubtitle") project.subtitle = value;
          else {
            project.slides = project.slides.map((sl) => {
              if (sl.id !== (target as { slideId?: string }).slideId) return sl;
              if (target.type === "slideQuestion" && sl.type === "mcq")
                return { ...sl, question: value };
              if (target.type === "slideOption" && sl.type === "mcq") {
                const options = [...sl.options];
                options[target.index] = value;
                return { ...sl, options };
              }
              if (target.type === "slideHeading" && sl.type === "note") return { ...sl, heading: value };
              if (target.type === "slideBody" && sl.type === "note")
                return { ...sl, lines: value.split("\n").map((l) => l.trim()).filter(Boolean) };
              return sl;
            });
          }
          return { project };
        }),
      snapshot: () => ({ version: 1, project: get().project, overrides: get().overrides }),
      loadSnapshot: (snap) =>
        set({
          project: { ...DEFAULT_PROJECT, ...snap.project },
          overrides: snap.overrides ?? {},
          activeIndex: 0,
          selectedLayerId: null,
          step: 3,
        }),
      setCloudRef: (cloudId, cloudTitle) => set({ cloudId, cloudTitle }),
      resetProject: () =>
        set({
          project: { ...DEFAULT_PROJECT, title: "", slides: [] },
          overrides: {},
          activeIndex: 0,
          selectedLayerId: null,
          step: 1,
          cloudId: null,
          cloudTitle: "",
        }),
    }),
    {
      name: "autoslides-v1",
      storage: createJSONStorage(() => safeStorage),
      partialize: (s) => ({
        project: s.project,
        overrides: s.overrides,
        cloudId: s.cloudId,
        cloudTitle: s.cloudTitle,
        contentMode: s.contentMode,
      }),
    },
  ),
);
