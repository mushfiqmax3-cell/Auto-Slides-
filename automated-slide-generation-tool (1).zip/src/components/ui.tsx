"use client";

import { ImagePlus, Trash2 } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { useRef } from "react";
import type { ChangeEvent, ReactNode } from "react";

export function cn(...parts: Array<string | false | null | undefined>): string {
  return parts.filter(Boolean).join(" ");
}

export function Card({ className, children }: { className?: string; children: ReactNode }) {
  return (
    <section
      className={cn(
        "rounded-2xl border border-white/[0.08] bg-white/[0.035] p-5 shadow-[0_18px_50px_-30px_rgba(0,0,0,0.9)] backdrop-blur-sm",
        className,
      )}
    >
      {children}
    </section>
  );
}

export function SectionTitle({
  icon: Icon,
  title,
  desc,
}: {
  icon: LucideIcon;
  title: string;
  desc?: string;
}) {
  return (
    <div className="mb-4 flex items-start gap-3">
      <div className="grid size-9 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-indigo-500/25 to-fuchsia-500/20 text-indigo-300 ring-1 ring-indigo-400/25">
        <Icon className="size-4.5" strokeWidth={2.2} />
      </div>
      <div>
        <h3 className="text-[15px] font-bold tracking-tight text-white">{title}</h3>
        {desc ? <p className="mt-0.5 text-[12.5px] leading-relaxed text-neutral-400">{desc}</p> : null}
      </div>
    </div>
  );
}

export function Field({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 flex items-baseline justify-between text-[13px] font-semibold text-neutral-300">
        {label}
        {hint ? <span className="text-[11px] font-normal text-neutral-500">{hint}</span> : null}
      </span>
      {children}
    </label>
  );
}

export function TextInput(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      {...props}
      className={cn(
        "w-full rounded-xl border border-white/10 bg-black/30 px-3.5 py-2.5 text-sm text-neutral-100 outline-none transition",
        "placeholder:text-neutral-600 focus:border-indigo-400/60 focus:ring-2 focus:ring-indigo-500/25",
        props.className,
      )}
    />
  );
}

export function TextArea(props: React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <textarea
      {...props}
      className={cn(
        "w-full rounded-xl border border-white/10 bg-black/30 px-3.5 py-3 text-[13px] leading-relaxed text-neutral-100 outline-none transition",
        "placeholder:text-neutral-600 focus:border-indigo-400/60 focus:ring-2 focus:ring-indigo-500/25",
        props.className,
      )}
    />
  );
}

export function Toggle({
  checked,
  onChange,
  label,
  small,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  label: string;
  small?: boolean;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      className="group flex w-full items-center justify-between gap-3 py-1.5 text-left"
    >
      <span className={cn("font-medium text-neutral-300", small ? "text-[12.5px]" : "text-[13px]")}>{label}</span>
      <span
        className={cn(
          "relative h-6 w-11 shrink-0 rounded-full transition-colors duration-200",
          checked ? "bg-indigo-500" : "bg-white/12",
        )}
      >
        <span
          className={cn(
            "absolute top-0.5 size-5 rounded-full bg-white shadow transition-all duration-200",
            checked ? "left-[22px]" : "left-0.5",
          )}
        />
      </span>
    </button>
  );
}

export function Segmented<T extends string>({
  options,
  value,
  onChange,
}: {
  options: Array<{ value: T; label: string; icon?: LucideIcon }>;
  value: T;
  onChange: (v: T) => void;
}) {
  return (
    <div className="flex rounded-xl border border-white/10 bg-black/30 p-1">
      {options.map((opt) => {
        const Icon = opt.icon;
        const active = value === opt.value;
        return (
          <button
            key={opt.value}
            type="button"
            onClick={() => onChange(opt.value)}
            className={cn(
              "flex flex-1 items-center justify-center gap-1.5 rounded-lg px-2.5 py-1.5 text-[12.5px] font-semibold transition",
              active
                ? "bg-gradient-to-r from-indigo-500 to-violet-500 text-white shadow-lg shadow-indigo-950/50"
                : "text-neutral-400 hover:text-neutral-200",
            )}
          >
            {Icon ? <Icon className="size-3.5" /> : null}
            {opt.label}
          </button>
        );
      })}
    </div>
  );
}

export function ImageUploader({
  label,
  value,
  onChange,
  hint,
  compact,
}: {
  label: string;
  value?: string;
  onChange: (dataUrl?: string) => void;
  hint?: string;
  compact?: boolean;
}) {
  const inputRef = useRef<HTMLInputElement>(null);

  const read = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    if (file.size > 6 * 1024 * 1024) {
      alert("ছবির সাইজ ৬ MB-এর কম হতে হবে।");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => onChange(String(reader.result));
    reader.readAsDataURL(file);
  };

  return (
    <div>
      <input ref={inputRef} type="file" accept="image/*" className="hidden" onChange={read} />
      {value ? (
        <div
          className={cn(
            "group relative overflow-hidden rounded-xl border border-white/10",
            compact ? "h-20" : "aspect-video",
          )}
        >
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={value} alt={label} className="size-full object-cover" />
          <div className="absolute inset-0 flex items-center justify-center gap-2 bg-black/60 opacity-0 backdrop-blur-[2px] transition group-hover:opacity-100">
            <button
              type="button"
              onClick={() => inputRef.current?.click()}
              className="rounded-lg bg-white/15 px-3 py-1.5 text-xs font-semibold text-white transition hover:bg-white/25"
            >
              পরিবর্তন
            </button>
            <button
              type="button"
              onClick={() => onChange(undefined)}
              className="grid size-8 place-items-center rounded-lg bg-rose-500/25 text-rose-200 transition hover:bg-rose-500/40"
              aria-label="Remove image"
            >
              <Trash2 className="size-4" />
            </button>
          </div>
        </div>
      ) : (
        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          className={cn(
            "flex w-full flex-col items-center justify-center gap-2 rounded-xl border border-dashed border-white/15 text-neutral-500 transition",
            "hover:border-indigo-400/50 hover:bg-indigo-500/[0.06] hover:text-indigo-300",
            compact ? "h-20" : "aspect-video",
          )}
        >
          <ImagePlus className={compact ? "size-4" : "size-6"} strokeWidth={1.8} />
          <span className="text-xs font-medium">{label}</span>
          {hint && !compact ? <span className="text-[10.5px] text-neutral-600">{hint}</span> : null}
        </button>
      )}
    </div>
  );
}

export function ColorInput({
  label,
  value,
  onChange,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
}) {
  return (
    <div className="flex items-center gap-2.5 rounded-xl border border-white/10 bg-black/30 px-3 py-2">
      <div className="relative size-7 shrink-0 overflow-hidden rounded-lg ring-1 ring-white/20" style={{ backgroundColor: value || "#6366f1" }}>
        <input
          type="color"
          value={value || "#6366f1"}
          onChange={(e) => onChange(e.target.value)}
          className="absolute inset-0 size-full cursor-pointer opacity-0"
          aria-label={label}
        />
      </div>
      <div className="min-w-0">
        <p className="text-[11px] font-semibold text-neutral-300">{label}</p>
        <input
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder ?? "#6366f1"}
          spellCheck={false}
          className="w-full bg-transparent font-mono text-[11px] uppercase text-neutral-500 outline-none placeholder:normal-case placeholder:text-neutral-700"
        />
      </div>
    </div>
  );
}
