"use client";

import { toBn } from "@/lib/bengali";
import { entryStats } from "@/lib/exports";
import { ensureFonts, ensureImages, projectImageSrcs } from "@/lib/images";
import { drawEntry, SLIDE_H, SLIDE_W } from "@/lib/renderer";
import type { SlideEntry } from "@/lib/types";
import { buildEntries, entryKey } from "@/lib/types";
import { useSlideStore } from "@/store/useSlideStore";
import { Plus, Trash2 } from "lucide-react";
import { useEffect, useMemo, useRef } from "react";

function Thumb({
  entry,
  index,
  total,
  mcqNo,
  noteNo,
  active,
  onSelect,
  onRemove,
}: {
  entry: SlideEntry;
  index: number;
  total: number;
  mcqNo: number;
  noteNo: number;
  active: boolean;
  onSelect: () => void;
  onRemove?: () => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const project = useSlideStore((s) => s.project);
  const overrides = useSlideStore((s) => s.overrides);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      await ensureImages(projectImageSrcs(project));
      await ensureFonts();
      if (cancelled) return;
      const W = 256;
      canvas.width = W;
      canvas.height = (W * SLIDE_H) / SLIDE_W;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;
      ctx.scale(W / SLIDE_W, W / SLIDE_W);
      drawEntry(ctx, project, entry, {
        index,
        total,
        mcqNo,
        noteNo,
        overrides: overrides[entryKey(entry)] ?? {},
      });
    })();
    return () => {
      cancelled = true;
    };
  }, [project, entry, index, total, mcqNo, noteNo, overrides]);

  const label =
    entry.kind === "cover" ? "কভার" : entry.kind === "closing" ? "শেষ" : entry.slide.type === "mcq" ? `প্রশ্ন ${toBn(mcqNo)}` : `নোট ${toBn(noteNo)}`;

  return (
    <div className="group relative w-[104px] shrink-0 sm:w-[128px]">
      <button
        onClick={onSelect}
        className={`block w-full overflow-hidden rounded-lg transition ${
          active ? "ring-2 ring-indigo-400 ring-offset-2 ring-offset-neutral-950" : "opacity-70 ring-1 ring-white/12 hover:opacity-100 hover:ring-indigo-400/50"
        }`}
      >
        <canvas ref={canvasRef} className="block w-full" />
      </button>
      <div className="mt-1 flex items-center justify-between px-0.5">
        <span className={`text-[10px] font-bold ${active ? "text-indigo-300" : "text-neutral-500"}`}>
          {toBn(index + 1)} · {label}
        </span>
        {onRemove ? (
          <button
            onClick={onRemove}
            className="grid size-4 place-items-center rounded text-neutral-600 opacity-0 transition group-hover:opacity-100 hover:bg-rose-500/20 hover:text-rose-300"
            aria-label="Remove slide"
          >
            <Trash2 className="size-3" />
          </button>
        ) : null}
      </div>
    </div>
  );
}

export default function SlideNavigator() {
  const project = useSlideStore((s) => s.project);
  const activeIndex = useSlideStore((s) => s.activeIndex);
  const setActiveIndex = useSlideStore((s) => s.setActiveIndex);
  const removeSlide = useSlideStore((s) => s.removeSlide);
  const setStep = useSlideStore((s) => s.setStep);

  const entries = useMemo(() => buildEntries(project), [project]);
  const stats = entryStats(entries);
  const active = useSlideStore((s) => s.activeIndex);

  return (
    <div className="flex items-start gap-3 overflow-x-auto pb-2 pr-1" style={{ scrollbarWidth: "thin" }}>
      {entries.map((entry, i) => (
        <Thumb
          key={entryKey(entry) + i}
          entry={entry}
          index={i}
          total={entries.length}
          mcqNo={stats[i].mcqNo}
          noteNo={stats[i].noteNo}
          active={active === i}
          onSelect={() => setActiveIndex(i)}
          onRemove={
            entry.kind === "slide"
              ? () => {
                  if (entry.kind !== "slide") return;
                  removeSlide(entry.slide.id);
                  if (activeIndex >= i) setActiveIndex(Math.max(0, i - 1));
                }
              : undefined
          }
        />
      ))}
      <button
        onClick={() => setStep(2)}
        className="grid h-[68px] w-[104px] shrink-0 place-items-center rounded-lg border border-dashed border-white/15 text-neutral-500 transition hover:border-indigo-400/50 hover:text-indigo-300 sm:h-[86px] sm:w-[128px]"
        title="ধাপ ২-এ গিয়ে আরও স্লাইড জেনারেট করুন"
      >
        <Plus className="size-5" />
      </button>
    </div>
  );
}
