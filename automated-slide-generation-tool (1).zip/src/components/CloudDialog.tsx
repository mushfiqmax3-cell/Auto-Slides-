"use client";

import { parseProjectJson } from "@/lib/exports";
import { useSlideStore } from "@/store/useSlideStore";
import { Cloud, CloudUpload, FolderOpen, Loader2, Trash2, X } from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";

interface CloudRow {
  id: string;
  title: string;
  updatedAt: string;
}

export default function CloudDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [rows, setRows] = useState<CloudRow[]>([]);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const cloudId = useSlideStore((s) => s.cloudId);
  const cloudTitle = useSlideStore((s) => s.cloudTitle);
  const project = useSlideStore((s) => s.project);
  const snapshot = useSlideStore((s) => s.snapshot);
  const loadSnapshot = useSlideStore((s) => s.loadSnapshot);
  const setCloudRef = useSlideStore((s) => s.setCloudRef);

  const refresh = useCallback(async () => {
    try {
      const res = await fetch("/api/projects", { cache: "no-store" });
      const data = await res.json();
      if (res.ok) setRows(data.projects ?? []);
      else setError(data.error ?? "লোড ব্যর্ণ হয়েছে");
    } catch {
      setError("সার্ভারে সংযোগ করা যায়নি");
    }
  }, []);

  useEffect(() => {
    if (open) {
      setError(null);
      void refresh();
    }
  }, [open, refresh]);

  const save = async (asNew: boolean) => {
    setBusy("save");
    setError(null);
    try {
      const res = await fetch("/api/projects", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: asNew ? undefined : cloudId ?? undefined,
          title: project.title || "শিরোনামহীন উপস্থাপনা",
          data: snapshot(),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "সেভ ব্যর্ণ হয়েছে");
      setCloudRef(data.id, project.title);
      await refresh();
    } catch (e) {
      setError(e instanceof Error ? e.message : "সেভ ব্যর্ণ হয়েছে");
    } finally {
      setBusy(null);
    }
  };

  const load = async (id: string, title: string) => {
    setBusy(id);
    setError(null);
    try {
      const res = await fetch(`/api/projects/${id}`, { cache: "no-store" });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "লোড ব্যর্ণ হয়েছে");
      const snap = parseProjectJson(JSON.stringify(data.data));
      if (!snap) throw new Error("প্রজেক্ট ফরম্যাট অবৈধ");
      loadSnapshot(snap);
      setCloudRef(id, title);
      onClose();
    } catch (e) {
      setError(e instanceof Error ? e.message : "লোড ব্যর্ণ হয়েছে");
    } finally {
      setBusy(null);
    }
  };

  const remove = async (id: string) => {
    setBusy(id);
    setError(null);
    try {
      await fetch(`/api/projects/${id}`, { method: "DELETE" });
      if (cloudId === id) setCloudRef(null, "");
      await refresh();
    } finally {
      setBusy(null);
    }
  };

  const importFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      const snap = parseProjectJson(String(reader.result));
      if (snap) {
        loadSnapshot(snap);
        setCloudRef(null, "");
        onClose();
      } else setError("JSON ফাইলটি বৈধ প্রজেক্ট নয়");
    };
    reader.readAsText(file);
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-lg overflow-hidden rounded-2xl border border-white/10 bg-neutral-950 shadow-2xl">
        <div className="flex items-center justify-between border-b border-white/[0.07] px-5 py-4">
          <div className="flex items-center gap-2.5">
            <span className="grid size-8 place-items-center rounded-lg bg-indigo-500/20 text-indigo-300">
              <Cloud className="size-4" />
            </span>
            <div>
              <h2 className="text-sm font-bold text-white">ক্লাউড প্রজেক্ট</h2>
              <p className="text-[11px] text-neutral-500">সার্ভারে সেভ ও লোড করুন</p>
            </div>
          </div>
          <button onClick={onClose} className="grid size-8 place-items-center rounded-lg text-neutral-500 transition hover:bg-white/10 hover:text-white" aria-label="Close">
            <X className="size-4" />
          </button>
        </div>

        <div className="max-h-[60vh] overflow-y-auto p-5">
          <div className="flex gap-2">
            <button
              onClick={() => save(false)}
              disabled={busy !== null}
              className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-indigo-500 to-violet-500 px-3 py-2.5 text-[12.5px] font-bold text-white transition hover:brightness-110 disabled:opacity-50"
            >
              {busy === "save" ? <Loader2 className="size-4 animate-spin" /> : <CloudUpload className="size-4" />}
              {cloudId ? `"${cloudTitle.slice(0, 14)}…" আপডেট করুন` : "ক্লাউডে সেভ করুন"}
            </button>
            {cloudId ? (
              <button
                onClick={() => save(true)}
                disabled={busy !== null}
                className="rounded-xl border border-white/12 px-3 py-2.5 text-[12.5px] font-semibold text-neutral-300 transition hover:bg-white/10 disabled:opacity-50"
              >
                নতুন হিসেবে
              </button>
            ) : null}
            <button
              onClick={() => fileRef.current?.click()}
              className="flex items-center gap-2 rounded-xl border border-white/12 px-3 py-2.5 text-[12.5px] font-semibold text-neutral-300 transition hover:bg-white/10"
            >
              <FolderOpen className="size-4" />
              JSON
            </button>
            <input
              ref={fileRef}
              type="file"
              accept="application/json"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                e.target.value = "";
                if (f) importFile(f);
              }}
            />
          </div>

          {error ? (
            <p className="mt-3 rounded-lg border border-rose-500/30 bg-rose-500/10 px-3 py-2 text-xs text-rose-300">{error}</p>
          ) : null}

          <div className="mt-4 space-y-2">
            {rows.length === 0 ? (
              <p className="rounded-xl border border-dashed border-white/10 px-4 py-8 text-center text-xs text-neutral-500">
                এখনও কোনো ক্লাউড প্রজেক্ট নেই — উপরের বোতামে সেভ করুন।
              </p>
            ) : (
              rows.map((row) => (
                <div
                  key={row.id}
                  className={`flex items-center gap-3 rounded-xl border px-3.5 py-3 transition ${
                    row.id === cloudId ? "border-indigo-400/40 bg-indigo-500/[0.08]" : "border-white/[0.08] bg-white/[0.03] hover:bg-white/[0.05]"
                  }`}
                >
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[13px] font-semibold text-neutral-100">{row.title}</p>
                    <p className="text-[11px] text-neutral-500">
                      {new Date(row.updatedAt).toLocaleString("bn-BD", { dateStyle: "medium", timeStyle: "short" })}
                      {row.id === cloudId ? " · বর্তমান" : ""}
                    </p>
                  </div>
                  <button
                    onClick={() => load(row.id, row.title)}
                    disabled={busy !== null}
                    className="rounded-lg bg-indigo-500/20 px-3 py-1.5 text-xs font-bold text-indigo-200 transition hover:bg-indigo-500/35 disabled:opacity-50"
                  >
                    {busy === row.id ? <Loader2 className="size-3.5 animate-spin" /> : "লোড"}
                  </button>
                  <button
                    onClick={() => remove(row.id)}
                    disabled={busy !== null}
                    className="grid size-8 place-items-center rounded-lg text-neutral-600 transition hover:bg-rose-500/15 hover:text-rose-300"
                    aria-label="Delete"
                  >
                    <Trash2 className="size-3.5" />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
