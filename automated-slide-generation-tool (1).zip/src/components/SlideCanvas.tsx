"use client";

import { ensureFonts, ensureImages, projectImageSrcs } from "@/lib/images";
import type { Layer } from "@/lib/renderer";
import { drawEntry, SLIDE_H, SLIDE_W } from "@/lib/renderer";
import type { SlideEntry } from "@/lib/types";
import { entryKey } from "@/lib/types";
import { useSlideStore } from "@/store/useSlideStore";
import { useCallback, useEffect, useRef, useState } from "react";

export interface CanvasStats {
  index: number;
  mcqNo: number;
  noteNo: number;
  total: number;
}

interface Props {
  entry: SlideEntry;
  stats: CanvasStats;
  onLayers?: (layers: Layer[]) => void;
  onEditStart?: (layer: Layer, cssRect: DOMRect) => void;
}

/** Interactive 16:9 slide canvas with hit-testing, drag-to-move and dbl-click editing. */
export default function SlideCanvas({ entry, stats, onLayers, onEditStart }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const layersRef = useRef<Layer[]>([]);
  const dragRef = useRef<{ id: string; sx: number; sy: number; bdx: number; bdy: number } | null>(null);
  const [cssW, setCssW] = useState(0);

  const project = useSlideStore((s) => s.project);
  const overrides = useSlideStore((s) => s.overrides);
  const selectedLayerId = useSlideStore((s) => s.selectedLayerId);
  const selectLayer = useSlideStore((s) => s.selectLayer);
  const setOverride = useSlideStore((s) => s.setOverride);

  const eKey = entryKey(entry);
  const entryOverrides = overrides[eKey] ?? {};

  const redraw = useCallback(async () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const parent = wrapRef.current;
    const width = parent?.clientWidth ?? 800;
    const dpr = Math.min(2.5, window.devicePixelRatio || 1);
    const px = Math.round(width * dpr);
    if (canvas.width !== px) {
      canvas.width = px;
      canvas.height = Math.round((px * SLIDE_H) / SLIDE_W);
    }
    await ensureImages(projectImageSrcs(project));
    await ensureFonts();
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.save();
    ctx.scale(canvas.width / SLIDE_W, canvas.width / SLIDE_W);
    const layers = drawEntry(ctx, project, entry, {
      index: stats.index,
      total: stats.total,
      mcqNo: stats.mcqNo,
      noteNo: stats.noteNo,
      selectedId: selectedLayerId,
      overrides: entryOverrides,
    });
    ctx.restore();
    layersRef.current = layers;
    onLayers?.(layers);
  }, [project, entry, stats.index, stats.total, stats.mcqNo, stats.noteNo, selectedLayerId, entryOverrides, onLayers]);

  useEffect(() => {
    void redraw();
  }, [redraw]);

  useEffect(() => {
    const parent = wrapRef.current;
    if (!parent) return;
    const ro = new ResizeObserver(() => {
      setCssW(parent.clientWidth);
      void redraw();
    });
    ro.observe(parent);
    return () => ro.disconnect();
  }, [redraw]);
  void cssW;

  const toVirtual = (e: React.PointerEvent) => {
    const rect = canvasRef.current!.getBoundingClientRect();
    return {
      x: ((e.clientX - rect.left) / rect.width) * SLIDE_W,
      y: ((e.clientY - rect.top) / rect.height) * SLIDE_H,
      rect,
    };
  };

  const hit = (x: number, y: number): Layer | null => {
    const layers = layersRef.current;
    for (let i = layers.length - 1; i >= 0; i--) {
      const l = layers[i];
      if (!l.visible || !l.selectable) continue;
      if (x >= l.x - 6 && x <= l.x + l.w + 6 && y >= l.y - 6 && y <= l.y + l.h + 6) return l;
    }
    return null;
  };

  const onPointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const { x, y } = toVirtual(e);
    const layer = hit(x, y);
    if (layer) {
      selectLayer(layer.id);
      const o = entryOverrides[layer.id] ?? {};
      dragRef.current = { id: layer.id, sx: x, sy: y, bdx: o.dx ?? 0, bdy: o.dy ?? 0 };
      (e.target as HTMLCanvasElement).setPointerCapture(e.pointerId);
    } else {
      selectLayer(null);
    }
  };

  const onPointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const { x, y } = toVirtual(e);
    const drag = dragRef.current;
    if (drag) {
      const dx = Math.round(drag.bdx + (x - drag.sx));
      const dy = Math.round(drag.bdy + (y - drag.sy));
      setOverride(eKey, drag.id, { dx, dy });
    } else {
      canvasRef.current!.style.cursor = hit(x, y) ? "move" : "default";
    }
  };

  const onPointerUp = (e: React.PointerEvent<HTMLCanvasElement>) => {
    dragRef.current = null;
    (e.target as HTMLCanvasElement).releasePointerCapture(e.pointerId);
  };

  const onDoubleClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const rect = canvasRef.current!.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * SLIDE_W;
    const y = ((e.clientY - rect.top) / rect.height) * SLIDE_H;
    const layer = hit(x, y);
    if (layer?.editable && onEditStart) {
      const scale = rect.width / SLIDE_W;
      onEditStart(
        layer,
        new DOMRect(rect.left + layer.x * scale, rect.top + layer.y * scale, layer.w * scale, layer.h * scale),
      );
    }
  };

  return (
    <div ref={wrapRef} className="relative w-full" style={{ aspectRatio: "16 / 9" }}>
      <canvas
        ref={canvasRef}
        className="absolute inset-0 size-full rounded-xl shadow-[0_30px_90px_-30px_rgba(0,0,0,0.9)] ring-1 ring-white/15"
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onDoubleClick={onDoubleClick}
      />
    </div>
  );
}
