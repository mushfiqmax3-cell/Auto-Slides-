"use client";

import {
  exportPngZip,
  exportProjectJson,
  exportPptx,
  parseProjectJson,
} from "@/lib/exports";
import type { Layer } from "@/lib/renderer";
import { buildEntries, entryKey } from "@/lib/types";
import { entryStats } from "@/lib/exports";
import CloudDialog from "@/components/CloudDialog";
import SlideCanvas from "@/components/SlideCanvas";
import SlideNavigator from "@/components/SlideNavigator";
import { useSlideStore } from "@/store/useSlideStore";
import {
  AlignCenter,
  AlignLeft,
  AlignRight,
  ArrowLeft,
  Bold,
  Check,
  Cloud,
  Eraser,
  EyeOff,
  FileDown,
  FileText,
  FolderOpen,
  ImageDown,
  Loader2,
  LocateFixed,
  Minus,
  MousePointerClick,
  Plus,
  Save,
  Type,
  X,
} from "lucide-react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";

interface Editing {
  layerId: string;
  target: NonNullable<Layer["editable"]>;
  value: string;
  rect: DOMRect;
  fontSize: number;
  bold: boolean;
  align: "left" | "center" | "right";
}

function ToolButton({
  onClick,
  title,
  active,
  disabled,
  children,
}: {
  onClick: () => void;
  title: string;
  active?: boolean;
  disabled?: boolean;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      title={title}
      disabled={disabled}
      className={`grid size-8 place-items-center rounded-lg transition disabled:opacity-30 ${
        active ? "bg-indigo-500/30 text-indigo-100 ring-1 ring-indigo-400/50" : "text-neutral-400 hover:bg-white/[0.07] hover:text-white"
      }`}
    >
      {children}
    </button>
  );
}

export default function StepEditor() {
  const project = useSlideStore((s) => s.project);
  const overrides = useSlideStore((s) => s.overrides);
  const activeIndex = useSlideStore((s) => s.activeIndex);
  const setActiveIndex = useSlideStore((s) => s.setActiveIndex);
  const selectedLayerId = useSlideStore((s) => s.selectedLayerId);
  const selectLayer = useSlideStore((s) => s.selectLayer);
  const setOverride = useSlideStore((s) => s.setOverride);
  const clearOverride = useSlideStore((s) => s.clearOverride);
  const resetEntryOverrides = useSlideStore((s) => s.resetEntryOverrides);
  const applyEdit = useSlideStore((s) => s.applyEdit);
  const patchProject = useSlideStore((s) => s.patchProject);
  const snapshot = useSlideStore((s) => s.snapshot);
  const loadSnapshot = useSlideStore((s) => s.loadSnapshot);
  const setStep = useSlideStore((s) => s.setStep);
  const hasSlides = project.slides.length > 0;

  const [layers, setLayers] = useState<Layer[]>([]);
  const [editing, setEditing] = useState<Editing | null>(null);
  const [busy, setBusy] = useState<"pptx" | "png" | null>(null);
  const [pngPct, setPngPct] = useState(0);
  const [cloudOpen, setCloudOpen] = useState(false);
  const jsonRef = useRef<HTMLInputElement>(null);

  const entries = useMemo(() => buildEntries(project), [project]);
  const stats = entryStats(entries);
  const clampedIndex = Math.min(activeIndex, Math.max(0, entries.length - 1));
  const entry = entries[clampedIndex];
  const eKey = entry ? entryKey(entry) : "";
  const entryOverrides = overrides[eKey] ?? {};
  const selectedLayer = layers.find((l) => l.id === selectedLayerId && l.visible) ?? null;

  // keep canvas callback stable-ish
  const onLayers = useCallback((ls: Layer[]) => setLayers(ls), []);

  // keyboard navigation
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (editing) return;
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") return;
      if (e.key === "ArrowRight") setActiveIndex(Math.min(entries.length - 1, clampedIndex + 1));
      if (e.key === "ArrowLeft") setActiveIndex(Math.max(0, clampedIndex - 1));
      if (e.key === "Escape") selectLayer(null);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [editing, entries.length, clampedIndex, setActiveIndex, selectLayer]);

  // --- export handlers
  const doPptx = async () => {
    setBusy("pptx");
    try {
      await exportPptx(project, overrides);
    } finally {
      setBusy(null);
    }
  };
  const doPng = async () => {
    setBusy("png");
    setPngPct(0);
    try {
      await exportPngZip(project, overrides, setPngPct);
    } finally {
      setBusy(null);
    }
  };
  const doJson = () => exportProjectJson(snapshot(), project.title);
  const importJson = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      const snap = parseProjectJson(String(reader.result));
      if (snap) loadSnapshot(snap);
      else alert("JSON ফাইলটি বৈধ AutoSlides প্রজেক্ট নয়");
    };
    reader.readAsText(file);
  };

  if (!hasSlides || !entry) {
    return (
      <div className="mx-auto max-w-md rounded-2xl border border-dashed border-white/15 bg-white/[0.02] px-8 py-14 text-center">
        <Type className="mx-auto size-8 text-neutral-600" />
        <h2 className="mt-4 text-lg font-bold text-white">এখনও কোনো স্লাইড নেই</h2>
        <p className="mt-1.5 text-[13px] leading-relaxed text-neutral-500">
          ধাপ ২-এ গিয়ে MCQ বা নোট পেস্ট করে স্লাইড জেনারেট করুন — অথবা ডেমো ডেটা দিয়ে শুরু করুন।
        </p>
        <button
          onClick={() => setStep(2)}
          className="mt-5 rounded-xl bg-gradient-to-r from-indigo-500 to-violet-500 px-5 py-2.5 text-sm font-bold text-white transition hover:brightness-110"
        >
          কন্টেন্ট জেনারেটে যান
        </button>
      </div>
    );
  }

  const isTextual = selectedLayer && selectedLayer.kind !== "image";
  const fs = Math.round(selectedLayer?.fontSize ?? 0);

  return (
    <div className="space-y-4">
      <SlideNavigator />

      {/* toolbar */}
      <div className="flex min-h-12 flex-wrap items-center gap-1.5 rounded-2xl border border-white/[0.08] bg-white/[0.035] px-3 py-2 backdrop-blur-sm">
        {selectedLayer ? (
          <>
            <span className="mr-1 flex max-w-40 items-center gap-1.5 truncate rounded-lg bg-indigo-500/15 px-2.5 py-1.5 text-[11.5px] font-bold text-indigo-200 ring-1 ring-indigo-400/30">
              <MousePointerClick className="size-3.5 shrink-0" />
              <span className="truncate">{selectedLayer.label}</span>
            </span>
            <span className="mx-1 h-6 w-px bg-white/10" />
            {isTextual ? (
              <>
                <ToolButton title="ফন্ট ছোট করুন" disabled={fs <= 8} onClick={() => setOverride(eKey, selectedLayer.id, { fontSize: Math.max(8, fs - 2) })}>
                  <Minus className="size-3.5" />
                </ToolButton>
                <span className="w-14 text-center font-mono text-[11.5px] font-bold text-neutral-300">{fs}px</span>
                <ToolButton title="ফন্ট বড় করুন" disabled={fs >= 160} onClick={() => setOverride(eKey, selectedLayer.id, { fontSize: Math.min(160, fs + 2) })}>
                  <Plus className="size-3.5" />
                </ToolButton>
                <ToolButton
                  title="বোল্ড"
                  active={selectedLayer.bold ?? false}
                  onClick={() => setOverride(eKey, selectedLayer.id, { bold: !(selectedLayer.bold ?? false) })}
                >
                  <Bold className="size-3.5" />
                </ToolButton>
                <span className="relative mx-0.5 grid size-8 place-items-center overflow-hidden rounded-lg ring-1 ring-white/15" title="টেক্সট কালার">
                  <span className="absolute inset-1.5 rounded" style={{ backgroundColor: selectedLayer.color ?? "#94a3b8" }} />
                  <input
                    type="color"
                    aria-label="Text color"
                    value={selectedLayer.color ?? "#94a3b8"}
                    onChange={(e) => setOverride(eKey, selectedLayer.id, { color: e.target.value })}
                    className="absolute inset-0 size-full cursor-pointer opacity-0"
                  />
                </span>
                {(["left", "center", "right"] as const).map((a) => (
                  <ToolButton
                    key={a}
                    title={`অ্যালাইন ${a}`}
                    active={(selectedLayer.align ?? "left") === a}
                    onClick={() => setOverride(eKey, selectedLayer.id, { align: a })}
                  >
                    {a === "left" ? <AlignLeft className="size-3.5" /> : a === "center" ? <AlignCenter className="size-3.5" /> : <AlignRight className="size-3.5" />}
                  </ToolButton>
                ))}
                <span className="mx-1 h-6 w-px bg-white/10" />
              </>
            ) : null}
            <ToolButton title="পজিশন রিসেট" onClick={() => setOverride(eKey, selectedLayer.id, { dx: 0, dy: 0 })}>
              <LocateFixed className="size-3.5" />
            </ToolButton>
            <ToolButton
              title="লেয়ার ডিলিট (লুকান)"
              onClick={() => {
                setOverride(eKey, selectedLayer.id, { hidden: true });
                selectLayer(null);
              }}
            >
              <EyeOff className="size-3.5" />
            </ToolButton>
            <ToolButton title="লেয়ারের সব পরিবর্তন মুছুন" onClick={() => clearOverride(eKey, selectedLayer.id)}>
              <Eraser className="size-3.5" />
            </ToolButton>
            <span className="mx-1 h-6 w-px bg-white/10" />
            <ToolButton title="সিলেকশন বাতিল (Esc)" onClick={() => selectLayer(null)}>
              <X className="size-3.5" />
            </ToolButton>
            <p className="ml-auto hidden text-[11px] text-neutral-500 lg:block">ড্র্যাগ করে সরান · ডাবল-ক্লিকে টেক্সট এডিট</p>
          </>
        ) : (
          <>
            <p className="flex items-center gap-2 px-1 text-[12px] font-medium text-neutral-400">
              <MousePointerClick className="size-4 text-indigo-300" />
              স্লাইডের যেকোনো টেক্সট/উপাদানে ক্লিক করে সিলেক্ট করুন — ড্র্যাগে সরান, ডাবল-ক্লিকে এডিট করুন
            </p>
            <div className="ml-auto flex items-center gap-1.5">
              <button
                onClick={() => patchProject({ showAnswers: !project.showAnswers })}
                className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-[11.5px] font-bold transition ${
                  project.showAnswers ? "bg-emerald-500/15 text-emerald-300 ring-1 ring-emerald-400/30" : "text-neutral-400 hover:bg-white/[0.07]"
                }`}
              >
                <Check className="size-3.5" />
                উত্তর {project.showAnswers ? "দেখাচ্ছে" : "লুকানো"}
              </button>
              <button
                onClick={() => resetEntryOverrides(eKey)}
                className="flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-[11.5px] font-bold text-neutral-400 transition hover:bg-white/[0.07] hover:text-white"
              >
                <Eraser className="size-3.5" />
                এই স্লাইড রিসেট
              </button>
              <span className="text-[11px] font-semibold text-neutral-600">
                {clampedIndex + 1}/{entries.length}
              </span>
            </div>
          </>
        )}
      </div>

      {/* canvas stage */}
      <div className="mx-auto w-full max-w-[1100px]">
        <SlideCanvas
          entry={entry}
          stats={{ index: clampedIndex, total: entries.length, mcqNo: stats[clampedIndex].mcqNo, noteNo: stats[clampedIndex].noteNo }}
          onLayers={onLayers}
          onEditStart={(layer, rect) => {
            if (!layer.editable) return;
            setEditing({
              layerId: layer.id,
              target: layer.editable,
              value: layer.text ?? "",
              rect,
              fontSize: layer.fontSize ?? 28,
              bold: layer.bold ?? false,
              align: layer.align ?? "left",
            });
          }}
        />
      </div>

      {/* export dock */}
      <div className="mx-auto flex w-full max-w-[1100px] flex-wrap items-center gap-2 rounded-2xl border border-white/[0.08] bg-white/[0.035] p-3">
        <button
          onClick={doPptx}
          disabled={busy !== null}
          className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-indigo-500 via-violet-500 to-fuchsia-500 px-4 py-2.5 text-[12.5px] font-extrabold text-white shadow-lg shadow-indigo-950/40 transition hover:brightness-110 disabled:opacity-50"
        >
          {busy === "pptx" ? <Loader2 className="size-4 animate-spin" /> : <FileDown className="size-4" />}
          PPTX ডাউনলোড
        </button>
        <div className="relative">
          <button
            onClick={doPng}
            disabled={busy !== null}
            className="flex items-center gap-2 rounded-xl border border-white/12 bg-white/[0.05] px-4 py-2.5 text-[12.5px] font-bold text-neutral-200 transition hover:border-indigo-400/40 hover:text-indigo-200 disabled:opacity-50"
          >
            {busy === "png" ? <Loader2 className="size-4 animate-spin" /> : <ImageDown className="size-4" />}
            PNG ZIP {busy === "png" ? `${Math.round(pngPct)}%` : "(1920×1080)"}
          </button>
          {busy === "png" ? (
            <span className="absolute inset-x-2 -bottom-1 h-0.5 overflow-hidden rounded-full bg-white/10">
              <span className="block h-full bg-indigo-400 transition-all" style={{ width: `${pngPct}%` }} />
            </span>
          ) : null}
        </div>
        <button
          onClick={doJson}
          className="flex items-center gap-2 rounded-xl border border-white/12 bg-white/[0.05] px-4 py-2.5 text-[12.5px] font-bold text-neutral-200 transition hover:border-indigo-400/40 hover:text-indigo-200"
        >
          <Save className="size-4" />
          প্রজেক্ট JSON
        </button>
        <button
          onClick={() => jsonRef.current?.click()}
          className="flex items-center gap-2 rounded-xl border border-white/12 bg-white/[0.05] px-4 py-2.5 text-[12.5px] font-bold text-neutral-200 transition hover:border-indigo-400/40 hover:text-indigo-200"
        >
          <FolderOpen className="size-4" />
          JSON খুলুন
        </button>
        <input
          ref={jsonRef}
          type="file"
          accept="application/json"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            e.target.value = "";
            if (f) importJson(f);
          }}
        />
        <button
          onClick={() => setCloudOpen(true)}
          className="flex items-center gap-2 rounded-xl border border-white/12 bg-white/[0.05] px-4 py-2.5 text-[12.5px] font-bold text-neutral-200 transition hover:border-indigo-400/40 hover:text-indigo-200"
        >
          <Cloud className="size-4" />
          ক্লাউড
        </button>

        <div className="ml-auto flex items-center gap-1.5">
          <button
            onClick={() => setStep(2)}
            className="flex items-center gap-1.5 rounded-xl border border-white/12 px-3.5 py-2.5 text-[12px] font-semibold text-neutral-400 transition hover:bg-white/[0.06] hover:text-neutral-200"
          >
            <ArrowLeft className="size-3.5" />
            কন্টেন্ট
          </button>
          <button
            onClick={() => setStep(1)}
            className="flex items-center gap-1.5 rounded-xl border border-white/12 px-3.5 py-2.5 text-[12px] font-semibold text-neutral-400 transition hover:bg-white/[0.06] hover:text-neutral-200"
          >
            <FileText className="size-3.5" />
            তথ্য
          </button>
        </div>
      </div>

      {/* inline text editor overlay */}
      {editing ? (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setEditing(null)} />
          <textarea
            autoFocus
            value={editing.value}
            onChange={(e) => setEditing({ ...editing, value: e.target.value })}
            onBlur={() => {
              applyEdit(editing.target, editing.value.trim());
              setEditing(null);
            }}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                applyEdit(editing.target, editing.value.trim());
                setEditing(null);
              }
              if (e.key === "Escape") setEditing(null);
            }}
            rows={3}
            className="fixed z-50 resize-none rounded-lg bg-neutral-950/95 p-2 text-white shadow-2xl outline-none ring-2 ring-indigo-400"
            style={{
              left: editing.rect.left,
              top: editing.rect.top,
              width: Math.max(editing.rect.width, 160),
              minHeight: Math.max(editing.rect.height + 16, 48),
              fontSize: `${Math.max(13, editing.fontSize * (editing.rect.width / 1280))}px`,
              fontWeight: editing.bold ? 700 : 500,
              textAlign: editing.align,
              fontFamily: `"Hind Siliguri", sans-serif`,
            }}
          />
        </>
      ) : null}

      <CloudDialog open={cloudOpen} onClose={() => setCloudOpen(false)} />
      {/* unused overrides reference guard */}
      <span className="hidden">{JSON.stringify(Object.keys(entryOverrides))}</span>
    </div>
  );
}
