"use client";

import { useSlideStore } from "@/store/useSlideStore";
import type { WizardStep } from "@/store/useSlideStore";
import { Cloud, Info, Layers3, MonitorPlay, RotateCcw, Wand2 } from "lucide-react";
import { useState } from "react";
import CloudDialog from "@/components/CloudDialog";
import StepBranding from "@/components/StepBranding";
import StepContent from "@/components/StepContent";
import StepEditor from "@/components/StepEditor";

const STEPS: Array<{ n: WizardStep; label: string; sub: string; icon: typeof Info }> = [
  { n: 1, label: "তথ্য ও ব্র্যান্ডিং", sub: "Information", icon: Info },
  { n: 2, label: "কন্টেন্ট ও থিম", sub: "Generate", icon: Wand2 },
  { n: 3, label: "এডিটর ও এক্সপোর্ট", sub: "Editor", icon: MonitorPlay },
];

export default function AppShell() {
  const step = useSlideStore((s) => s.step);
  const setStep = useSlideStore((s) => s.setStep);
  const hasSlides = useSlideStore((s) => s.project.slides.length > 0);
  const resetProject = useSlideStore((s) => s.resetProject);
  const [cloudOpen, setCloudOpen] = useState(false);

  const canVisit = (n: WizardStep) => (n === 3 ? hasSlides : true);

  return (
    <div className="flex min-h-dvh flex-col">
      {/* top navigation */}
      <header className="sticky top-0 z-40 border-b border-white/[0.07] bg-neutral-950/85 backdrop-blur-xl">
        <div className="mx-auto flex max-w-[1400px] items-center gap-3 px-4 py-3 sm:px-6">
          <div className="flex items-center gap-2.5">
            <span className="grid size-9 place-items-center rounded-xl bg-gradient-to-br from-indigo-500 via-violet-500 to-fuchsia-500 shadow-lg shadow-indigo-950/60">
              <Layers3 className="size-4.5 text-white" strokeWidth={2.4} />
            </span>
            <div className="leading-tight">
              <p className="text-[15px] font-extrabold tracking-tight text-white">
                Auto<span className="bg-gradient-to-r from-indigo-300 to-fuchsia-300 bg-clip-text text-transparent">Slides</span>
              </p>
              <p className="text-[10.5px] font-medium text-neutral-500">স্মার্ট স্লাইড জেনারেটর</p>
            </div>
          </div>

          {/* stepper */}
          <nav className="mx-auto hidden items-center gap-1 md:flex">
            {STEPS.map((s, i) => {
              const Icon = s.icon;
              const active = step === s.n;
              const done = step > s.n;
              const allowed = canVisit(s.n);
              return (
                <div key={s.n} className="flex items-center">
                  {i > 0 ? <span className="mx-2 h-px w-7 bg-white/12" /> : null}
                  <button
                    onClick={() => allowed && setStep(s.n)}
                    disabled={!allowed}
                    className={`group flex items-center gap-2.5 rounded-xl px-3 py-1.5 text-left transition ${
                      active ? "bg-white/[0.07] ring-1 ring-indigo-400/40" : allowed ? "hover:bg-white/[0.05]" : "cursor-not-allowed opacity-40"
                    }`}
                  >
                    <span
                      className={`grid size-7 place-items-center rounded-lg text-[11px] font-extrabold transition ${
                        active
                          ? "bg-gradient-to-br from-indigo-500 to-violet-500 text-white"
                          : done
                            ? "bg-emerald-500/20 text-emerald-300"
                            : "bg-white/[0.07] text-neutral-400"
                      }`}
                    >
                      <Icon className="size-3.5" />
                    </span>
                    <span>
                      <span className={`block text-[12px] font-bold leading-tight ${active ? "text-white" : "text-neutral-300"}`}>{s.label}</span>
                      <span className="block text-[9.5px] font-medium uppercase tracking-[0.14em] text-neutral-600">{s.sub}</span>
                    </span>
                  </button>
                </div>
              );
            })}
          </nav>

          <div className="ml-auto flex items-center gap-2 md:ml-0">
            <button
              onClick={() => setCloudOpen(true)}
              className="flex items-center gap-1.5 rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2 text-[12px] font-semibold text-neutral-300 transition hover:border-indigo-400/40 hover:text-indigo-200"
            >
              <Cloud className="size-3.5" />
              <span className="hidden sm:inline">ক্লাউড</span>
            </button>
            <button
              onClick={() => {
                if (confirm("সব কিছু মুছে নতুন প্রজেক্ট শুরু করবেন?")) resetProject();
              }}
              className="flex items-center gap-1.5 rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2 text-[12px] font-semibold text-neutral-400 transition hover:border-rose-400/40 hover:text-rose-300"
            >
              <RotateCcw className="size-3.5" />
              <span className="hidden sm:inline">রিসেট</span>
            </button>
          </div>
        </div>

        {/* mobile stepper */}
        <div className="mx-auto flex max-w-[1400px] gap-1.5 px-4 pb-3 md:hidden">
          {STEPS.map((s) => (
            <button
              key={s.n}
              onClick={() => canVisit(s.n) && setStep(s.n)}
              className={`flex flex-1 items-center justify-center gap-1.5 rounded-lg py-1.5 text-[11px] font-bold transition ${
                step === s.n ? "bg-indigo-500/20 text-indigo-200 ring-1 ring-indigo-400/40" : "text-neutral-500"
              }`}
            >
              <s.icon className="size-3" />
              {s.label}
            </button>
          ))}
        </div>
      </header>

      <main className="mx-auto w-full max-w-[1400px] flex-1 px-4 py-6 sm:px-6">
        {step === 1 ? <StepBranding /> : step === 2 ? <StepContent /> : <StepEditor />}
      </main>

      <footer className="border-t border-white/[0.06] py-4">
        <p className="text-center text-[11px] text-neutral-600">
          AutoSlides — বাংলা MCQ ও লেকচার নোট থেকে সেকেন্ডেই প্রেজেন্টেশন · PPTX / PNG / JSON এক্সপোর্ট
        </p>
      </footer>

      <CloudDialog open={cloudOpen} onClose={() => setCloudOpen(false)} />
    </div>
  );
}
