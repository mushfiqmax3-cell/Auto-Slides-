"use client";

import { Card, Field, ImageUploader, SectionTitle, Segmented, TextInput, Toggle } from "@/components/ui";
import { useSlideStore } from "@/store/useSlideStore";
import { ArrowRight, BadgeCheck, Image as ImageIcon, LayoutPanelTop, Type, Wallpaper } from "lucide-react";

export default function StepBranding() {
  const project = useSlideStore((s) => s.project);
  const patchProject = useSlideStore((s) => s.patchProject);
  const setStep = useSlideStore((s) => s.setStep);

  const setBrand = (side: "brandLeft" | "brandRight", patch: Partial<typeof project.brandLeft>) =>
    patchProject({ [side]: { ...project[side], ...patch } } as Partial<typeof project>);

  return (
    <div className="grid gap-5 lg:grid-cols-[1.5fr_1fr]">
      {/* left column */}
      <div className="space-y-5">
        <Card>
          <SectionTitle icon={Type} title="প্রেজেন্টেশন তথ্য" desc="শিরোনাম সব স্লাইডে এবং কভারে ব্যবহৃত হবে" />
          <div className="space-y-4">
            <Field label="প্রেজেন্টেশন টাইটেল" hint="প্রয়োজনীয়">
              <TextInput
                value={project.title}
                onChange={(e) => patchProject({ title: e.target.value })}
                placeholder="যেমন: বাংলাদেশের ইতিহাস — অধ্যায় ১"
              />
            </Field>
            <Field label="সাবটাইটেল" hint="ঐচ্ছিক">
              <TextInput
                value={project.subtitle}
                onChange={(e) => patchProject({ subtitle: e.target.value })}
                placeholder="যেমন: পঞ্চম শ্রেণি · সাধারণ জ্ঞান সিরিজ"
              />
            </Field>
          </div>
        </Card>

        <Card>
          <SectionTitle icon={Wallpaper} title="ব্যাকগ্রাউন্ড ইমেজ" desc="সব স্লাইডে গ্রেডিয়েন্টের উপরে প্রয়োগ হবে" />
          <div className="grid gap-4 sm:grid-cols-[1.4fr_1fr]">
            <ImageUploader
              label="ব্যাকগ্রাউন্ড ছবি আপলোড করুন"
              hint="JPG/PNG · সর্বোচ্চ ৬MB · লাইব্রেরি হিসেবে পুনঃব্যবহারযোগ্য"
              value={project.backgroundImage}
              onChange={(v) => patchProject({ backgroundImage: v })}
            />
            <div className="flex flex-col justify-center gap-3 rounded-xl border border-white/[0.07] bg-black/20 p-4">
              <div className="flex items-center justify-between text-[12px] font-semibold text-neutral-300">
                <span>ছবির তীব্রতা</span>
                <span className="font-mono text-indigo-300">{Math.round(project.backgroundOpacity * 100)}%</span>
              </div>
              <input
                type="range"
                min={5}
                max={100}
                value={Math.round(project.backgroundOpacity * 100)}
                onChange={(e) => patchProject({ backgroundOpacity: Number(e.target.value) / 100 })}
                className="w-full accent-indigo-500"
                disabled={!project.backgroundImage}
              />
              <p className="text-[11px] leading-relaxed text-neutral-500">
                কম তীব্রতায় টেক্সট বেশি পড়তে সুবিধা হয়। ছবি না দিলে শুধু থিম গ্রেডিয়েন্ট থাকবে।
              </p>
            </div>
          </div>
        </Card>

        <Card>
          <SectionTitle icon={ImageIcon} title="কভার থাম্বনেইল" desc="১৬:৯ রেশিও অপ্টিমাইজড — শুধু কভার স্লাইডে দেখাবে" />
          <ImageUploader
            label="কভার থাম্বনেইল আপলোড করুন (1280×720 আদর্শ)"
            hint="ঐচ্ছিক — কভার স্লাইডের নিচে বড় প্রিভিউ হিসেবে বসবে"
            value={project.coverImage}
            onChange={(v) => patchProject({ coverImage: v })}
          />
        </Card>
      </div>

      {/* right column */}
      <div className="space-y-5">
        <Card>
          <SectionTitle icon={BadgeCheck} title="ব্র্যান্ডিং" desc="লোগো বামে, ওয়াটারমার্ক ডানে — প্রতিটি স্লাইডে" />
          {(["brandLeft", "brandRight"] as const).map((side) => {
            const b = project[side];
            const label = side === "brandLeft" ? "বাম লোগো" : "ডান ওয়াটারমার্ক";
            return (
              <div key={side} className="mb-4 rounded-xl border border-white/[0.07] bg-black/20 p-3.5 last:mb-0">
                <Toggle checked={b.enabled} onChange={(v) => setBrand(side, { enabled: v })} label={`${label} চালু করুন`} />
                {b.enabled ? (
                  <div className="mt-2.5 space-y-2.5 border-t border-white/[0.06] pt-3">
                    <Segmented
                      options={[
                        { value: "text", label: "টেক্সট" },
                        { value: "image", label: "ইমেজ" },
                      ]}
                      value={b.type}
                      onChange={(v) => setBrand(side, { type: v })}
                    />
                    {b.type === "text" ? (
                      <TextInput
                        value={b.text}
                        onChange={(e) => setBrand(side, { text: e.target.value })}
                        placeholder={side === "brandLeft" ? "আপনার প্রতিষ্ঠানের নাম" : "ওয়াটারমার্ক টেক্সট"}
                      />
                    ) : (
                      <ImageUploader
                        compact
                        label="লোগো ইমেজ (স্বচ্ছ PNG ভালো)"
                        value={b.image}
                        onChange={(v) => setBrand(side, { image: v })}
                      />
                    )}
                  </div>
                ) : null}
              </div>
            );
          })}
        </Card>

        <Card>
          <SectionTitle icon={LayoutPanelTop} title="স্লাইড স্ট্রাকচার" desc="কভার ও সমাপনী স্লাইড স্বয়ংক্রিয়ভাবে তৈরি হয়" />
          <Toggle
            checked={project.includeCover}
            onChange={(v) => patchProject({ includeCover: v })}
            label="কভার স্লাইড যোগ করুন"
          />
          <Toggle
            checked={project.includeClosing}
            onChange={(v) => patchProject({ includeClosing: v })}
            label="সমাপনী ধন্যবাদ স্লাইড যোগ করুন"
          />
        </Card>

        <button
          onClick={() => setStep(2)}
          disabled={!project.title.trim()}
          className="group flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-indigo-500 via-violet-500 to-fuchsia-500 px-5 py-3.5 text-sm font-extrabold text-white shadow-xl shadow-indigo-950/50 transition hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-40"
        >
          পরবর্তী: কন্টেন্ট জেনারেট করুন
          <ArrowRight className="size-4 transition-transform group-hover:translate-x-0.5" />
        </button>
        {!project.title.trim() ? (
          <p className="-mt-2 text-center text-[11px] text-neutral-500">এগিয়ে যেতে একটি টাইটেল লিখুন</p>
        ) : null}
      </div>
    </div>
  );
}
