"use client";

import { toBn } from "@/lib/bengali";
import { parseContent } from "@/lib/parser";
import { getTheme, hexA, THEMES } from "@/lib/themes";
import type { Slide } from "@/lib/types";
import { uid } from "@/lib/types";
import { Card, ColorInput, Field, SectionTitle, Segmented, TextArea, Toggle } from "@/components/ui";
import { DEMO_TEXT, useSlideStore } from "@/store/useSlideStore";
import {
  ArrowLeft,
  ArrowRight,
  Check,
  FileQuestion,
  FileText,
  FileUp,
  Layers,
  ListChecks,
  NotebookText,
  Palette,
  Sparkles,
  Trash2,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";

const PLACEHOLDER = `এখানে প্রশ্ন পেস্ট করুন…

১। বাংলাদেশের জাতীয় ফুল কোনটি?
ক) গোলাপ
খ) শাপলা
গ) গাঁদা
ঘ) পদ্ম
উত্তর: খ

# লেকচার নোট শিরোনাম
- প্রথম পয়েন্ট
- দ্বিতীয় পয়েন্ট`;

export default function StepContent() {
  const project = useSlideStore((s) => s.project);
  const patchProject = useSlideStore((s) => s.patchProject);
  const setSlides = useSlideStore((s) => s.setSlides);
  const contentMode = useSlideStore((s) => s.contentMode);
  const setContentMode = useSlideStore((s) => s.setContentMode);
  const setStep = useSlideStore((s) => s.setStep);
  const slideCount = project.slides.length;

  const [raw, setRaw] = useState("");
  const [stats, setStats] = useState<{ mcq: number; notes: number; fmt: string } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const live = useMemo(() => (raw.trim() ? parseContent(raw) : null), [raw]);

  useEffect(() => {
    if (live) setError(null);
  }, [live]);

  const readFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      setRaw(String(reader.result));
      setStats(null);
    };
    reader.readAsText(file);
  };

  const generate = () => {
    const parsed = parseContent(raw);
    let slides = parsed.slides;
    if (contentMode === "mcq") slides = slides.filter((s) => s.type === "mcq");
    if (contentMode === "notes") slides = slides.filter((s) => s.type === "note");
    if (slides.length === 0) {
      setError(
        contentMode === "mcq"
          ? "কোনো MCQ পাওয়া যায়নি — ফরম্যাট দেখে আবার চেষ্টা করুন।"
          : contentMode === "notes"
            ? "কোনো নোট পাওয়া যায়নি — `# শিরোনাম` ও `- পয়েন্ট` ফরম্যাট ব্যবহার করুন।"
            : "কন্টেন্ট পার্স করা যায়নি — নমুনা ফরম্যাট অনুসরণ করুন।",
      );
      return;
    }
    const withIds: Slide[] = slides.map((s) => ({ ...s, id: uid() }) as Slide);
    setSlides(withIds);
    setStats({
      mcq: withIds.filter((s) => s.type === "mcq").length,
      notes: withIds.filter((s) => s.type === "note").length,
      fmt: parsed.detectedFormat,
    });
    setStep(3);
  };

  const theme = getTheme(project.themeId);
  const accent = project.accent || theme.accent;
  const secondary = project.secondary || theme.secondary;

  return (
    <div className="grid gap-5 lg:grid-cols-[1.35fr_1fr]">
      {/* left: content source */}
      <div className="space-y-5">
        <Card>
          <SectionTitle
            icon={ListChecks}
            title="স্লাইডের ধরন"
            desc="কোন ধরনের স্লাইড তৈরি হবে তা বেছে নিন"
          />
          <div className="grid grid-cols-3 gap-2">
            {(
              [
                { v: "mcq", label: "MCQ কুইজ", icon: FileQuestion },
                { v: "notes", label: "নর্মাল / নোট", icon: NotebookText },
                { v: "mixed", label: "মিক্সড", icon: Layers },
              ] as const
            ).map(({ v, label, icon: Icon }) => (
              <button
                key={v}
                onClick={() => setContentMode(v)}
                className={`flex flex-col items-center gap-2 rounded-xl border px-3 py-3.5 transition ${
                  contentMode === v
                    ? "border-indigo-400/60 bg-indigo-500/[0.12] text-indigo-100 ring-2 ring-indigo-500/25"
                    : "border-white/[0.08] bg-black/20 text-neutral-400 hover:border-white/20 hover:text-neutral-200"
                }`}
              >
                <Icon className="size-5" strokeWidth={2} />
                <span className="text-[12px] font-bold">{label}</span>
              </button>
            ))}
          </div>
        </Card>

        <Card>
          <SectionTitle
            icon={FileText}
            title="প্রশ্ন / নোট ইনপুট"
            desc={`স্মার্ট অটো-পার্সার বাংলা ও ইংরেজি ফরম্যাট বোঝে — "উত্তর: ক", "Ans: B", ✓ চিহ্ন, # হেডিং, - বুলেট, CSV ও JSON`}
          />
          <div className="mb-3 flex flex-wrap items-center gap-2">
            <button
              onClick={() => fileRef.current?.click()}
              className="flex items-center gap-1.5 rounded-lg border border-white/12 bg-white/[0.04] px-3 py-1.5 text-[11.5px] font-semibold text-neutral-300 transition hover:border-indigo-400/40 hover:text-indigo-200"
            >
              <FileUp className="size-3.5" />
              TXT / CSV / JSON ফাইল
            </button>
            <input
              ref={fileRef}
              type="file"
              accept=".txt,.csv,.json,text/plain,text/csv,application/json"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                e.target.value = "";
                if (f) readFile(f);
              }}
            />
            <button
              onClick={() => setRaw(DEMO_TEXT)}
              className="flex items-center gap-1.5 rounded-lg border border-fuchsia-400/25 bg-fuchsia-500/[0.08] px-3 py-1.5 text-[11.5px] font-semibold text-fuchsia-200 transition hover:bg-fuchsia-500/15"
            >
              <Sparkles className="size-3.5" />
              ডেমো ডেটা লোড করুন
            </button>
            {raw ? (
              <button
                onClick={() => {
                  setRaw("");
                  setStats(null);
                }}
                className="ml-auto flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-[11.5px] font-semibold text-neutral-500 transition hover:text-rose-300"
              >
                <Trash2 className="size-3.5" />
                মুছুন
              </button>
            ) : null}
          </div>

          <TextArea
            value={raw}
            onChange={(e) => setRaw(e.target.value)}
            placeholder={PLACEHOLDER}
            rows={13}
            className="font-mono"
            spellCheck={false}
          />

          {/* live parse feedback */}
          <div className="mt-3 flex flex-wrap items-center gap-2 text-[11.5px]">
            {live && (live.mcqCount > 0 || live.noteCount > 0) ? (
              <>
                <span className="flex items-center gap-1 rounded-full bg-emerald-500/10 px-2.5 py-1 font-semibold text-emerald-300 ring-1 ring-emerald-500/30">
                  <Check className="size-3" /> {toBn(live.mcqCount)}টি MCQ
                </span>
                <span className="flex items-center gap-1 rounded-full bg-sky-500/10 px-2.5 py-1 font-semibold text-sky-300 ring-1 ring-sky-500/30">
                  <Check className="size-3" /> {toBn(live.noteCount)}টি নোট
                </span>
                <span className="rounded-full bg-white/[0.06] px-2.5 py-1 font-semibold uppercase text-neutral-400 ring-1 ring-white/10">
                  {live.detectedFormat} ফরম্যাট
                </span>
              </>
            ) : raw.trim() ? (
              <span className="text-neutral-500">পার্স হচ্ছে… ফরম্যাট মিলছে না</span>
            ) : (
              <span className="text-neutral-600">লাইভ প্রিভিউ: টাইপ করলেই পার্স ফলাফল দেখাবে</span>
            )}
            {stats ? (
              <span className="ml-auto font-semibold text-indigo-300">
                সর্বশেষ জেনারেট: {toBn(stats.mcq)} MCQ + {toBn(stats.notes)} নোট
              </span>
            ) : null}
          </div>

          {error ? (
            <p className="mt-3 rounded-lg border border-rose-500/30 bg-rose-500/10 px-3 py-2 text-xs text-rose-300">{error}</p>
          ) : null}

          <button
            onClick={generate}
            disabled={!raw.trim()}
            className="group mt-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-indigo-500 via-violet-500 to-fuchsia-500 px-5 py-3.5 text-sm font-extrabold text-white shadow-xl shadow-indigo-950/50 transition hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-40"
          >
            <Sparkles className="size-4" />
            স্লাইড জেনারেট করুন ও এডিটরে যান
            <ArrowRight className="size-4 transition-transform group-hover:translate-x-0.5" />
          </button>
          {slideCount > 0 ? (
            <button
              onClick={() => setStep(3)}
              className="mt-2 w-full rounded-xl border border-white/12 py-2.5 text-[12.5px] font-semibold text-neutral-300 transition hover:bg-white/[0.06]"
            >
              অথবা বিদ্যমান {toBn(slideCount)}টি স্লাইডের এডিটরে ফিরে যান
            </button>
          ) : null}
        </Card>
      </div>

      {/* right: theme & styling */}
      <div className="space-y-5">
        <Card>
          <SectionTitle icon={Palette} title="থিম প্রিসেট" desc="ডার্ক প্রিমিয়াম প্যালেট — এক ক্লিকে প্রয়োগ" />
          <div className="grid grid-cols-2 gap-2.5">
            {THEMES.map((t) => {
              const active = project.themeId === t.id;
              return (
                <button
                  key={t.id}
                  onClick={() => patchProject({ themeId: t.id, accent: "", secondary: "" })}
                  className={`group relative overflow-hidden rounded-xl border p-2.5 text-left transition ${
                    active ? "border-white/40 ring-2 ring-white/20" : "border-white/10 hover:border-white/25"
                  }`}
                  style={{ background: `linear-gradient(135deg, ${t.bgFrom}, ${t.bgTo})` }}
                >
                  <div className="flex items-center gap-1.5">
                    <span className="size-3.5 rounded-full ring-2 ring-white/20" style={{ backgroundColor: t.accent }} />
                    <span className="size-3.5 rounded-full ring-2 ring-white/20" style={{ backgroundColor: t.correct }} />
                    {active ? (
                      <span className="ml-auto grid size-5 place-items-center rounded-full bg-white text-neutral-900">
                        <Check className="size-3" strokeWidth={3} />
                      </span>
                    ) : null}
                  </div>
                  <p className="mt-2 text-[11px] font-bold leading-tight text-white/90">{t.name}</p>
                  {/* mini option preview */}
                  <div className="mt-2 flex items-center gap-1.5 rounded-md px-2 py-1.5" style={{ background: t.card, border: `1px solid ${t.stroke}` }}>
                    <span className="grid size-4 place-items-center rounded text-[9px] font-bold" style={{ background: hexA(t.accent, 0.3), color: t.secondary }}>
                      ক
                    </span>
                    <span className="h-1.5 w-10 rounded-full" style={{ background: hexA(t.text, 0.35) }} />
                  </div>
                </button>
              );
            })}
          </div>
        </Card>

        <Card>
          <SectionTitle icon={Palette} title="কাস্টম অ্যাকসেন্ট" desc="খালি রাখলে থিমের ডিফল্ট রঙ ব্যবহৃত হবে" />
          <div className="grid grid-cols-2 gap-2.5">
            <ColorInput label="প্রাইমারি অ্যাকসেন্ট" value={project.accent} onChange={(v) => patchProject({ accent: v })} placeholder={theme.accent} />
            <ColorInput label="সেকেন্ডারি অ্যাকসেন্ট" value={project.secondary} onChange={(v) => patchProject({ secondary: v })} placeholder={theme.secondary} />
          </div>
        </Card>

        <Card>
          <SectionTitle icon={NotebookText} title="অপশন স্টাইল" desc={`"ক খ গ ঘ" ব্যাজের লুক বেছে নিন`} />
          <Segmented
            options={[
              { value: "soft", label: "সফট" },
              { value: "outline", label: "আউটলাইন" },
              { value: "solid", label: "সলিড" },
            ]}
            value={project.optionStyle}
            onChange={(v) => patchProject({ optionStyle: v })}
          />
          {/* live preview chip */}
          <div
            className="mt-3 rounded-xl p-3"
            style={{ background: `linear-gradient(135deg, ${theme.bgFrom}, ${theme.bgTo})` }}
          >
            <div
              className="flex items-center gap-2.5 rounded-xl px-3 py-2.5"
              style={
                project.optionStyle === "soft"
                  ? { background: theme.card, border: `1px solid ${theme.stroke}` }
                  : project.optionStyle === "outline"
                    ? { border: `1.5px solid ${hexA(accent, 0.55)}` }
                    : { background: `linear-gradient(120deg, ${accent}, ${secondary})` }
              }
            >
              <span
                className="grid size-7 shrink-0 place-items-center rounded-lg text-xs font-bold"
                style={
                  project.optionStyle === "solid"
                    ? { background: "rgba(11,16,32,.85)", color: "#fff" }
                    : { background: hexA(accent, 0.2), color: secondary }
                }
              >
                ক
              </span>
              <span className="text-[12px] font-semibold" style={{ color: project.optionStyle === "solid" ? "#fff" : theme.text }}>
                উদাহরণ অপশন
              </span>
              {project.showAnswers ? (
                <span className="ml-auto grid size-5 place-items-center rounded-full text-[10px]" style={{ background: theme.correct, color: "#05210f" }}>
                  <Check className="size-3" strokeWidth={3} />
                </span>
              ) : null}
            </div>
          </div>
          <div className="mt-3 border-t border-white/[0.06] pt-3">
            <Toggle
              checked={project.showAnswers}
              onChange={(v) => patchProject({ showAnswers: v })}
              label="সঠিক উত্তর হাইলাইট করুন"
              small
            />
          </div>
        </Card>

        <button
          onClick={() => setStep(1)}
          className="flex items-center gap-2 rounded-xl border border-white/12 px-4 py-2.5 text-[12.5px] font-semibold text-neutral-400 transition hover:bg-white/[0.06] hover:text-neutral-200"
        >
          <ArrowLeft className="size-4" />
          আগের ধাপ: তথ্য ও ব্র্যান্ডিং
        </button>
      </div>
    </div>
  );
}
