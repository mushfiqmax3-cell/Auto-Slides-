import { db } from "@/db";
import { projects } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await ctx.params;
    const [row] = await db
      .select({ id: projects.id, title: projects.title, data: projects.data, updatedAt: projects.updatedAt })
      .from(projects)
      .where(eq(projects.id, id))
      .limit(1);
    if (!row) return Response.json({ error: "প্রজেক্ট পাওয়া যায়নি" }, { status: 404 });
    return Response.json(row);
  } catch (e) {
    return Response.json(
      { error: e instanceof Error ? e.message : "Failed to load project" },
      { status: 500 },
    );
  }
}

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await ctx.params;
    await db.delete(projects).where(eq(projects.id, id));
    return Response.json({ ok: true });
  } catch (e) {
    return Response.json(
      { error: e instanceof Error ? e.message : "Failed to delete project" },
      { status: 500 },
    );
  }
}
