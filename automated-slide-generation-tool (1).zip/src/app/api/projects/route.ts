import { db } from "@/db";
import { projects } from "@/db/schema";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const rows = await db
      .select({ id: projects.id, title: projects.title, updatedAt: projects.updatedAt })
      .from(projects)
      .orderBy(desc(projects.updatedAt))
      .limit(100);
    return Response.json({ projects: rows });
  } catch (e) {
    return Response.json(
      { error: e instanceof Error ? e.message : "Failed to list projects" },
      { status: 500 },
    );
  }
}

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as { id?: string; title?: string; data?: unknown };
    const title = (body.title ?? "").toString().slice(0, 300) || "শিরোনামহীন উপস্থাপনা";
    if (!body.data || typeof body.data !== "object") {
      return Response.json({ error: "Missing project data" }, { status: 400 });
    }
    const [row] = await db
      .insert(projects)
      .values({
        ...(body.id ? { id: body.id } : {}),
        title,
        data: body.data,
        updatedAt: new Date(),
      })
      .onConflictDoUpdate({
        target: projects.id,
        set: { title, data: body.data, updatedAt: new Date() },
      })
      .returning({ id: projects.id });
    return Response.json({ id: row.id, title });
  } catch (e) {
    return Response.json(
      { error: e instanceof Error ? e.message : "Failed to save project" },
      { status: 500 },
    );
  }
}
