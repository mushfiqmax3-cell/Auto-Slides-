// Shared domain types for the Auto Slides studio.

export type SlideKind = "mcq" | "note";

export interface MCQSlide {
  id: string;
  type: "mcq";
  question: string;
  options: string[];
  /** -1 when the correct answer is unknown */
  answerIndex: number;
  explanation?: string;
}

export interface NoteSlide {
  id: string;
  type: "note";
  heading: string;
  lines: string[];
}

export type Slide = MCQSlide | NoteSlide;

/** Virtual slides derived from project settings (cover / closing are generated). */
export type SlideEntry = { kind: "cover" } | { kind: "slide"; slide: Slide } | { kind: "closing" };

export interface BrandingSide {
  enabled: boolean;
  type: "text" | "image";
  text: string;
  image?: string; // data URL
}

export interface Project {
  title: string;
  subtitle: string;
  backgroundImage?: string; // data URL
  backgroundOpacity: number; // 0..1 image visibility over the gradient
  coverImage?: string; // data URL (16:9 thumbnail)
  brandLeft: BrandingSide;
  brandRight: BrandingSide;
  themeId: string;
  accent: string;
  secondary: string;
  optionStyle: "soft" | "outline" | "solid";
  showAnswers: boolean;
  includeCover: boolean;
  includeClosing: boolean;
  slides: Slide[];
}

/** Per-layer visual overrides applied on top of the automatic layout. */
export interface LayerOverride {
  dx?: number;
  dy?: number;
  /** absolute font size in virtual px when set */
  fontSize?: number;
  bold?: boolean;
  color?: string;
  align?: "left" | "center" | "right";
  hidden?: boolean;
}

export type OverridesMap = Record<string, Record<string, LayerOverride>>;

export interface ThemePreset {
  id: string;
  name: string;
  bgFrom: string;
  bgTo: string;
  accent: string;
  secondary: string;
  card: string;
  stroke: string;
  text: string;
  muted: string;
  correct: string;
}

export interface ProjectSnapshot {
  version: 1;
  project: Project;
  overrides: OverridesMap;
}

/** Build the ordered list of renderable slide entries for a project. */
export function buildEntries(project: Project): SlideEntry[] {
  const entries: SlideEntry[] = [];
  if (project.includeCover) entries.push({ kind: "cover" });
  for (const slide of project.slides) entries.push({ kind: "slide", slide });
  if (project.includeClosing) entries.push({ kind: "closing" });
  return entries;
}

/** Stable id for a slide entry (used to key overrides). */
export function entryKey(entry: SlideEntry): string {
  if (entry.kind === "cover") return "__cover__";
  if (entry.kind === "closing") return "__closing__";
  return entry.slide.id;
}

export function uid(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  return `id-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}
