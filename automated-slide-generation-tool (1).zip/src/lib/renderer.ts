// Canvas slide renderer. All geometry is computed in virtual 1280x720 units,
// so the same code powers the editor canvas, thumbnails and hi-res PNG export.

import { optionBadge, toBn } from "@/lib/bengali";
import { getCachedImage } from "@/lib/images";
import { getTheme, hexA } from "@/lib/themes";
import type {
  LayerOverride,
  MCQSlide,
  NoteSlide,
  Project,
  SlideEntry,
  ThemePreset,
} from "@/lib/types";
import { entryKey } from "@/lib/types";

export const SLIDE_W = 1280;
export const SLIDE_H = 720;
export const FONT = `"Hind Siliguri", "Noto Sans Bengali", "Segoe UI", system-ui, sans-serif`;

export type Align = "left" | "center" | "right";

export type EditTarget =
  | { type: "projectTitle" }
  | { type: "projectSubtitle" }
  | { type: "slideQuestion"; slideId: string }
  | { type: "slideOption"; slideId: string; index: number }
  | { type: "slideHeading"; slideId: string }
  | { type: "slideBody"; slideId: string };

export interface Layer {
  id: string;
  label: string;
  selectable: boolean;
  visible: boolean;
  kind: "text" | "image" | "paint";
  editable?: EditTarget;
  x: number;
  y: number;
  w: number;
  h: number;
  // resolved text props (after overrides)
  fontSize?: number;
  bold?: boolean;
  color?: string;
  align?: Align;
  text?: string;
  draw: (ctx: CanvasRenderingContext2D) => void;
}

export interface RenderOpts {
  index: number;
  total: number;
  mcqNo: number;
  noteNo: number;
  selectedId?: string | null;
  overrides?: Record<string, LayerOverride>;
}

// ------------------------------------------------------------ measure helpers

let measureCanvas: HTMLCanvasElement | null = null;
function metrics(): CanvasRenderingContext2D {
  if (!measureCanvas) measureCanvas = document.createElement("canvas");
  const ctx = measureCanvas.getContext("2d");
  if (!ctx) throw new Error("2d context unavailable");
  return ctx;
}

export function fontFor(size: number, bold: boolean): string {
  return `${bold ? 700 : 500} ${size}px ${FONT}`;
}

/** Word-wrap text into lines that fit maxWidth at the given font. */
export function wrapLines(
  text: string,
  maxWidth: number,
  size: number,
  bold: boolean,
): string[] {
  const ctx = metrics();
  ctx.font = fontFor(size, bold);
  const out: string[] = [];
  for (const para of text.split("\n")) {
    const words = para.split(/\s+/).filter(Boolean);
    if (words.length === 0) {
      out.push("");
      continue;
    }
    let line = words[0];
    for (let i = 1; i < words.length; i++) {
      const trial = `${line} ${words[i]}`;
      if (ctx.measureText(trial).width <= maxWidth) line = trial;
      else {
        out.push(line);
        line = words[i];
      }
    }
    out.push(line);
  }
  return out;
}

/** Shrink font until the text fits maxLines or min size is reached. */
function fitText(
  text: string,
  baseSize: number,
  minSize: number,
  maxWidth: number,
  maxLines: number,
  bold: boolean,
): { size: number; lines: string[] } {
  let size = baseSize;
  let lines = wrapLines(text, maxWidth, size, bold);
  while (lines.length > maxLines && size > minSize) {
    size -= 2;
    lines = wrapLines(text, maxWidth, size, bold);
  }
  return { size, lines: lines.slice(0, maxLines) };
}

// -------------------------------------------------------------- paint helpers

export function roundedRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
): void {
  const rr = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.arcTo(x + w, y, x + w, y + h, rr);
  ctx.arcTo(x + w, y + h, x, y + h, rr);
  ctx.arcTo(x, y + h, x, y, rr);
  ctx.arcTo(x, y, x + w, y, rr);
  ctx.closePath();
}

function alignX(align: Align, x: number, w: number): [number, CanvasTextAlign] {
  if (align === "center") return [x + w / 2, "center"];
  if (align === "right") return [x + w, "right"];
  return [x, "left"];
}

function paintLines(
  ctx: CanvasRenderingContext2D,
  layer: { x: number; y: number; w: number; fontSize: number; bold: boolean; color: string; align: Align },
  lines: string[],
  lineHeight = 1.32,
): void {
  const { x, y, w, fontSize, bold, color, align } = layer;
  const ctxAlign: CanvasTextAlign = align === "center" ? "center" : align === "right" ? "right" : "left";
  const tx = align === "center" ? x + w / 2 : align === "right" ? x + w : x;
  ctx.font = fontFor(fontSize, bold);
  ctx.fillStyle = color;
  ctx.textAlign = ctxAlign;
  ctx.textBaseline = "top";
  lines.forEach((ln, i) => ctx.fillText(ln, tx, y + i * fontSize * lineHeight));
  ctx.textAlign = "left";
}

function drawImageCover(
  ctx: CanvasRenderingContext2D,
  img: HTMLImageElement,
  x: number,
  y: number,
  w: number,
  h: number,
  radius = 0,
): void {
  const imgRatio = img.width / img.height;
  const boxRatio = w / h;
  let sw = img.width;
  let sh = img.height;
  let sx = 0;
  let sy = 0;
  if (imgRatio > boxRatio) {
    sw = img.height * boxRatio;
    sx = (img.width - sw) / 2;
  } else {
    sh = img.width / boxRatio;
    sy = (img.height - sh) / 2;
  }
  ctx.save();
  if (radius > 0) {
    roundedRect(ctx, x, y, w, h, radius);
    ctx.clip();
  }
  ctx.drawImage(img, sx, sy, sw, sh, x, y, w, h);
  ctx.restore();
}

// ------------------------------------------------------------------ layers

interface Ctx {
  project: Project;
  theme: ThemePreset;
  ovr: Record<string, LayerOverride>;
  layers: Layer[];
}

function applyOverride(c: Ctx, base: Layer): Layer {
  const o = c.ovr[base.id];
  if (!o) return base;
  const next = { ...base };
  next.x += o.dx ?? 0;
  next.y += o.dy ?? 0;
  if (o.fontSize) next.fontSize = o.fontSize;
  if (o.bold !== undefined) next.bold = o.bold;
  if (o.color) next.color = o.color;
  if (o.align) next.align = o.align;
  if (o.hidden) next.visible = false;
  return next;
}

function push(c: Ctx, layer: Layer): Layer {
  const resolved = applyOverride(c, layer);
  c.layers.push(resolved);
  return resolved;
}

function brandLayers(c: Ctx): void {
  const { project, theme } = c;
  // left logo
  if (project.brandLeft.enabled) {
    const b = project.brandLeft;
    const base: Layer = {
      id: "brand-left",
      label: "Left logo",
      selectable: true,
      visible: true,
      kind: b.type === "image" && b.image ? "image" : "text",
      x: 56,
      y: 34,
      w: b.type === "image" ? 170 : 300,
      h: 46,
      draw: (ctx) => {
        const img = b.type === "image" ? getCachedImage(b.image) : null;
        if (img) {
          const ratio = img.height / img.width;
          const w = 170;
          const h = Math.min(46, w * ratio);
          drawImageCover(ctx, img, 56, 34, w, h, 8);
        } else {
          const text = b.text || "লোগো";
          const { size, lines } = fitText(text, 26, 16, 340, 1, true);
          roundedRect(ctx, 52, 30, ctx.measureText(lines[0] ?? text).width + 44, 54, 14);
          ctx.fillStyle = hexA(theme.accent, 0.16);
          ctx.fill();
          ctx.strokeStyle = hexA(theme.accent, 0.45);
          ctx.lineWidth = 1.5;
          ctx.stroke();
          paintLines(ctx, { x: 74, y: 44, w: 340, fontSize: size, bold: true, color: theme.text, align: "left" }, [lines[0] ?? text]);
        }
      },
    };
    push(c, base);
  }
  // right watermark
  if (project.brandRight.enabled) {
    const b = project.brandRight;
    const base: Layer = {
      id: "brand-right",
      label: "Right watermark",
      selectable: true,
      visible: true,
      kind: b.type === "image" && b.image ? "image" : "text",
      x: SLIDE_W - 356,
      y: 34,
      w: 300,
      h: 44,
      draw: (ctx) => {
        const img = b.type === "image" ? getCachedImage(b.image) : null;
        ctx.save();
        ctx.globalAlpha = 0.6;
        if (img) {
          const ratio = img.height / img.width;
          const w = 170;
          const h = Math.min(44, w * ratio);
          drawImageCover(ctx, img, SLIDE_W - 56 - w, 34, w, h, 8);
        } else {
          const text = b.text || "ওয়াটারমার্ক";
          const { size, lines } = fitText(text, 22, 14, 300, 1, true);
          paintLines(ctx, { x: SLIDE_W - 356, y: 42, w: 300, fontSize: size, bold: true, color: theme.muted, align: "right" }, [lines[0] ?? text]);
        }
        ctx.restore();
      },
    };
    push(c, base);
  }
}

function coverLayers(c: Ctx): void {
  const { project, theme } = c;
  const hasThumb = Boolean(project.coverImage);

  push(c, {
    id: "cover-kicker",
    label: "Cover kicker",
    selectable: true,
    visible: true,
    kind: "text",
    x: SLIDE_W / 2 - 250,
    y: hasThumb ? 148 : 210,
    w: 500,
    h: 40,
    draw: (ctx) => {
      const text = "স্বয়ংক্রিয় স্লাইড প্রেজেন্টেশন";
      ctx.font = fontFor(20, true);
      const tw = ctx.measureText(text).width;
      const bw = tw + 46;
      const bx = SLIDE_W / 2 - bw / 2;
      roundedRect(ctx, bx, 142 + (hasThumb ? 6 : 68), bw, 42, 21);
      ctx.fillStyle = hexA(theme.accent, 0.14);
      ctx.fill();
      ctx.strokeStyle = hexA(theme.accent, 0.5);
      ctx.lineWidth = 1.5;
      ctx.stroke();
      paintLines(ctx, { x: bx, y: 152 + (hasThumb ? 6 : 68), w: bw, fontSize: 20, bold: true, color: theme.secondary, align: "center" }, [text]);
    },
  });

  const titleY = hasThumb ? 208 : 286;
  const titleFit = fitText(project.title || "শিরোনামহীন উপস্থাপনা", 72, 34, 1040, 2, true);
  push(c, {
    id: "cover-title",
    label: "Cover title",
    selectable: true,
    editable: { type: "projectTitle" },
    visible: true,
    kind: "text",
    x: SLIDE_W / 2 - 520,
    y: titleY,
    w: 1040,
    h: titleFit.size * 1.32 * titleFit.lines.length,
    fontSize: titleFit.size,
    bold: true,
    color: theme.text,
    align: "center",
    text: project.title,
    draw: (ctx) => {
      const l = c.layers.find((ll) => ll.id === "cover-title")!;
      const size = l.fontSize ?? titleFit.size;
      const lines = wrapLines(project.title || "শিরোনামহীন উপস্থাপনা", l.w, size, l.bold ?? true).slice(0, 3);
      paintLines(ctx, { x: l.x, y: l.y, w: l.w, fontSize: size, bold: l.bold ?? true, color: l.color ?? theme.text, align: l.align ?? "center" }, lines);
      // gradient accent bar under the title
      const barW = Math.min(220, l.w / 3);
      const barY = l.y + lines.length * size * 1.32 + 22;
      const grad = ctx.createLinearGradient(SLIDE_W / 2 - barW / 2, 0, SLIDE_W / 2 + barW / 2, 0);
      grad.addColorStop(0, theme.accent);
      grad.addColorStop(1, theme.secondary);
      roundedRect(ctx, SLIDE_W / 2 - barW / 2, barY, barW, 8, 4);
      ctx.fillStyle = grad;
      ctx.fill();
    },
  });

  const subFit = fitText(project.subtitle || "", 28, 18, 900, 2, false);
  const subY = titleY + titleFit.size * 1.32 * titleFit.lines.length + 46;
  if (project.subtitle) {
    push(c, {
      id: "cover-subtitle",
      label: "Cover subtitle",
      selectable: true,
      editable: { type: "projectSubtitle" },
      visible: true,
      kind: "text",
      x: SLIDE_W / 2 - 450,
      y: subY,
      w: 900,
      h: subFit.size * 1.32 * subFit.lines.length,
      fontSize: subFit.size,
      bold: false,
      color: theme.muted,
      align: "center",
      text: project.subtitle,
      draw: (ctx) => {
        const l = c.layers.find((ll) => ll.id === "cover-subtitle")!;
        const size = l.fontSize ?? subFit.size;
        const lines = wrapLines(project.subtitle, l.w, size, l.bold ?? false).slice(0, 2);
        paintLines(ctx, { x: l.x, y: l.y, w: l.w, fontSize: size, bold: l.bold ?? false, color: l.color ?? theme.muted, align: l.align ?? "center" }, lines);
      },
    });
  }

  if (hasThumb) {
    const img = getCachedImage(project.coverImage);
    const w = 560;
    const h = 315;
    const x = SLIDE_W / 2 - w / 2;
    const y = Math.min(subY + (project.subtitle ? 42 : 10), SLIDE_H - 64 - h);
    if (img) {
      push(c, {
        id: "cover-image",
        label: "Cover thumbnail",
        selectable: true,
        visible: true,
        kind: "image",
        x,
        y,
        w,
        h,
        draw: (ctx) => {
          const l = c.layers.find((ll) => ll.id === "cover-image")!;
          ctx.save();
          ctx.shadowColor = hexA(theme.accent, 0.45);
          ctx.shadowBlur = 42;
          ctx.shadowOffsetY = 14;
          roundedRect(ctx, l.x, l.y, l.w, l.h, 22);
          ctx.fillStyle = theme.bgFrom;
          ctx.fill();
          ctx.restore();
          drawImageCover(ctx, img, l.x, l.y, l.w, l.h, 22);
          roundedRect(ctx, l.x, l.y, l.w, l.h, 22);
          ctx.strokeStyle = hexA(theme.accent, 0.55);
          ctx.lineWidth = 2;
          ctx.stroke();
        },
      });
    }
  }
}

function chip(
  c: Ctx,
  id: string,
  label: string,
  text: string,
  opts?: { alignRight?: boolean },
): void {
  push(c, {
    id,
    label,
    selectable: true,
    visible: true,
    kind: "paint",
    x: opts?.alignRight ? SLIDE_W - 56 - 190 : 56,
    y: 96,
    w: 190,
    h: 46,
    draw: (ctx) => {
      const l = c.layers.find((ll) => ll.id === id)!;
      ctx.font = fontFor(21, true);
      const tw = ctx.measureText(text).width;
      const bw = tw + 52;
      const bx = opts?.alignRight ? SLIDE_W - 56 - bw : 56;
      roundedRect(ctx, bx + (l.x - (opts?.alignRight ? SLIDE_W - 56 - 190 : 56)), l.y, bw, 46, 23);
      ctx.fillStyle = hexA(c.theme.accent, 0.14);
      ctx.fill();
      ctx.strokeStyle = hexA(c.theme.accent, 0.55);
      ctx.lineWidth = 1.5;
      ctx.stroke();
      const xOff = l.x - (opts?.alignRight ? SLIDE_W - 56 - 190 : 56);
      paintLines(ctx, { x: bx + xOff, y: l.y + 11, w: bw, fontSize: 21, bold: true, color: c.theme.secondary, align: "center" }, [text]);
    },
  });
}

function mcqLayers(c: Ctx, slide: MCQSlide, mcqNo: number): void {
  const { theme, project } = c;
  chip(c, "chip", "Question number chip", `প্রশ্ন ${toBn(mcqNo)}`);

  // ---- question
  const qFit = fitText(slide.question, 46, 26, 1040, 3, true);
  push(c, {
    id: "question",
    label: "Question text",
    selectable: true,
    editable: { type: "slideQuestion", slideId: slide.id },
    visible: true,
    kind: "text",
    x: 96,
    y: 164,
    w: 1040,
    h: qFit.size * 1.34 * qFit.lines.length,
    fontSize: qFit.size,
    bold: true,
    color: theme.text,
    align: "left",
    text: slide.question,
    draw: (ctx) => {
      const l = c.layers.find((ll) => ll.id === "question")!;
      const size = l.fontSize ?? qFit.size;
      const bold = l.bold ?? true;
      const color = l.color ?? theme.text;
      const lines = wrapLines(slide.question, l.w, size, bold).slice(0, 3);
      roundedRect(ctx, 60, l.y + 2, 10, Math.max(34, lines.length * size * 1.34 - 10), 5);
      ctx.fillStyle = hexA(theme.accent, 0.9);
      ctx.fill();
      paintLines(ctx, { x: l.x, y: l.y, w: l.w, fontSize: size, bold, color, align: l.align ?? "left" }, lines, 1.34);
    },
  });

  const qLayer = c.layers.find((l) => l.id === "question")!;
  const optTop = qLayer.y + qLayer.h + 30;
  const regionBottom = slide.explanation && project.showAnswers ? 626 : 646;

  // ---- options layout with adaptive columns + auto-fit
  const opts = slide.options.slice(0, 6);
  const answerKnown = slide.answerIndex >= 0;
  const baseSize = 28;
  const tryLayout = (cols: 1 | 2, fs: number) => {
    const gap = 22;
    const cw = (SLIDE_W - 96 * 2 - gap * (cols - 1)) / cols;
    const rows: { idx: number; lines: string[]; h: number }[][] = [];
    let y = optTop;
    for (let r = 0; r < Math.ceil(opts.length / cols); r++) {
      const row: { idx: number; lines: string[]; h: number }[] = [];
      let rowH = 0;
      for (let cc = 0; cc < cols; cc++) {
        const idx = r * cols + cc;
        if (idx >= opts.length) break;
        const lines = wrapLines(opts[idx], cw - 92, fs, false).slice(0, 3);
        const h = Math.max(58, lines.length * fs * 1.3 + 18);
        row.push({ idx, lines, h });
        rowH = Math.max(rowH, h);
      }
      rows.push(row.map((cell) => ({ ...cell, h: rowH })));
      y += rowH + 16;
    }
    return { rows, totalH: y - optTop, cw };
  };
  let cols: 1 | 2 = 2;
  let fs = baseSize;
  let layout = tryLayout(cols, fs);
  const shortEnough = opts.every((o) => o.length <= 28);
  if (!shortEnough) {
    cols = 1;
    layout = tryLayout(cols, fs);
  }
  while (optTop + layout.totalH > regionBottom && fs > 17) {
    fs -= 2;
    layout = tryLayout(cols, fs);
  }

  layout.rows.forEach((row, r) => {
    row.forEach((cell, cc) => {
      const idx = cell.idx;
      const gap = 22;
      const x = 96 + cc * (layout.cw + gap);
      const y =
        optTop +
        layout.rows.slice(0, r).reduce((acc, rr) => acc + (rr[0]?.h ?? 0) + 16, 0);
      const isCorrect = answerKnown && idx === slide.answerIndex;
      const showCorrect = isCorrect && project.showAnswers;
      push(c, {
        id: `option-${idx}`,
        label: `Option ${optionBadge(idx)}`,
        selectable: true,
        editable: { type: "slideOption", slideId: slide.id, index: idx },
        visible: true,
        kind: "paint",
        x,
        y,
        w: layout.cw,
        h: cell.h,
        fontSize: fs,
        align: "left",
        draw: (ctx) => {
          const l = c.layers.find((ll) => ll.id === `option-${idx}`)!;
          const size = l.fontSize ?? fs;
          const color = showCorrect
            ? theme.correct
            : (l.color ?? (project.optionStyle === "solid" ? "#0b1020" : theme.text));
          const style = showCorrect ? "correct" : project.optionStyle;

          if (style === "soft") {
            roundedRect(ctx, l.x, l.y, l.w, l.h, 16);
            ctx.fillStyle = theme.card;
            ctx.fill();
            ctx.strokeStyle = theme.stroke;
            ctx.lineWidth = 1.5;
            ctx.stroke();
          } else if (style === "outline") {
            roundedRect(ctx, l.x, l.y, l.w, l.h, 16);
            ctx.fillStyle = "transparent";
            ctx.fill();
            ctx.strokeStyle = hexA(theme.accent, 0.5);
            ctx.lineWidth = 2;
            ctx.stroke();
          } else if (style === "solid") {
            roundedRect(ctx, l.x, l.y, l.w, l.h, 16);
            const grad = ctx.createLinearGradient(l.x, l.y, l.x + l.w, l.y + l.h);
            grad.addColorStop(0, hexA(theme.accent, 0.95));
            grad.addColorStop(1, hexA(theme.secondary, 0.95));
            ctx.fillStyle = grad;
            ctx.fill();
          } else {
            roundedRect(ctx, l.x, l.y, l.w, l.h, 16);
            ctx.fillStyle = hexA(theme.correct, 0.16);
            ctx.fill();
            ctx.strokeStyle = theme.correct;
            ctx.lineWidth = 2.2;
            ctx.stroke();
          }

          // badge
          const bs = 46;
          const bx = l.x + 22;
          const by = l.y + l.h / 2 - bs / 2;
          roundedRect(ctx, bx, by, bs, bs, 14);
          if (style === "solid") {
            ctx.fillStyle = "rgba(11, 16, 32, 0.85)";
            ctx.fill();
          } else if (style === "correct") {
            ctx.fillStyle = theme.correct;
            ctx.fill();
          } else {
            ctx.fillStyle = hexA(theme.accent, 0.18);
            ctx.fill();
            ctx.strokeStyle = hexA(theme.accent, 0.55);
            ctx.lineWidth = 1.5;
            ctx.stroke();
          }
          paintLines(
            ctx,
            {
              x: bx,
              y: by + (size >= 22 ? 9 : 11),
              w: bs,
              fontSize: Math.max(18, size - 4),
              bold: true,
              color: style === "correct" ? "#05210f" : style === "solid" ? theme.text : l.color ?? theme.secondary,
              align: "center",
            },
            [optionBadge(idx)],
          );

          // option text
          const lines = wrapLines(opts[idx], l.w - 92, size, l.bold ?? false).slice(0, 3);
          const blockH = lines.length * size * 1.3;
          paintLines(
            ctx,
            {
              x: l.x + 84,
              y: l.y + l.h / 2 - blockH / 2 + 2,
              w: l.w - 92,
              fontSize: size,
              bold: l.bold ?? false,
              color,
              align: l.align ?? "left",
            },
            lines,
            1.3,
          );

          // correctness check
          if (style === "correct") {
            const cx = l.x + l.w - 34;
            const cy = l.y + l.h / 2;
            ctx.beginPath();
            ctx.arc(cx, cy, 15, 0, Math.PI * 2);
            ctx.fillStyle = theme.correct;
            ctx.fill();
            ctx.strokeStyle = "#05210f";
            ctx.lineWidth = 3;
            ctx.lineCap = "round";
            ctx.beginPath();
            ctx.moveTo(cx - 6, cy + 1);
            ctx.lineTo(cx - 1.5, cy + 5.5);
            ctx.lineTo(cx + 7, cy - 5);
            ctx.stroke();
            ctx.lineCap = "butt";
          }
        },
      });
    });
  });

  // ---- answer pill + explanation
  if (project.showAnswers && answerKnown) {
    push(c, {
      id: "answer-pill",
      label: "Correct answer pill",
      selectable: true,
      visible: true,
      kind: "paint",
      x: 96,
      y: 656,
      w: 320,
      h: 42,
      draw: (ctx) => {
        const l = c.layers.find((ll) => ll.id === "answer-pill")!;
        const text = `সঠিক উত্তর: ${optionBadge(slide.answerIndex)}`;
        ctx.font = fontFor(21, true);
        const bw = ctx.measureText(text).width + 44;
        roundedRect(ctx, l.x, l.y, bw, 40, 20);
        ctx.fillStyle = hexA(theme.correct, 0.16);
        ctx.fill();
        ctx.strokeStyle = hexA(theme.correct, 0.65);
        ctx.lineWidth = 1.6;
        ctx.stroke();
        paintLines(ctx, { x: l.x, y: l.y + 8.5, w: bw, fontSize: 21, bold: true, color: theme.correct, align: "center" }, [text]);
      },
    });
  }
  if (project.showAnswers && slide.explanation) {
    push(c, {
      id: "explanation",
      label: "Explanation",
      selectable: true,
      visible: true,
      kind: "text",
      x: 430,
      y: 660,
      w: 754,
      h: 34,
      fontSize: 20,
      bold: false,
      color: theme.muted,
      align: "right",
      text: slide.explanation,
      draw: (ctx) => {
        const l = c.layers.find((ll) => ll.id === "explanation")!;
        const size = l.fontSize ?? 20;
        const lines = wrapLines(`ব্যাখ্যা: ${slide.explanation}`, l.w, size, l.bold ?? false).slice(0, 1);
        paintLines(ctx, { x: l.x, y: l.y + 4, w: l.w, fontSize: size, bold: l.bold ?? false, color: l.color ?? theme.muted, align: l.align ?? "right" }, lines);
      },
    });
  }
}

function noteLayers(c: Ctx, slide: NoteSlide, noteNo: number): void {
  const { theme } = c;
  chip(c, "chip", "Note number chip", `নোট ${toBn(noteNo)}`);

  const hFit = fitText(slide.heading, 46, 26, 1100, 2, true);
  push(c, {
    id: "heading",
    label: "Note heading",
    selectable: true,
    editable: { type: "slideHeading", slideId: slide.id },
    visible: true,
    kind: "text",
    x: 90,
    y: 166,
    w: 1100,
    h: hFit.size * 1.32 * hFit.lines.length,
    fontSize: hFit.size,
    bold: true,
    color: theme.text,
    align: "left",
    text: slide.heading,
    draw: (ctx) => {
      const l = c.layers.find((ll) => ll.id === "heading")!;
      const size = l.fontSize ?? hFit.size;
      const lines = wrapLines(slide.heading, l.w, size, l.bold ?? true).slice(0, 2);
      paintLines(ctx, { x: l.x, y: l.y, w: l.w, fontSize: size, bold: l.bold ?? true, color: l.color ?? theme.text, align: l.align ?? "left" }, lines);
      const dy = l.y + lines.length * size * 1.32 + 16;
      const grad = ctx.createLinearGradient(l.x, 0, l.x + 320, 0);
      grad.addColorStop(0, theme.accent);
      grad.addColorStop(1, "transparent");
      roundedRect(ctx, l.x, dy, 320, 6, 3);
      ctx.fillStyle = grad;
      ctx.fill();
    },
  });

  const hLayer = c.layers.find((l) => l.id === "heading")!;
  const bodyTop = hLayer.y + hLayer.h + 52;
  const bodyText = slide.lines.filter(Boolean).join("\n");
  const fitSize = (size: number) => {
    let lh = 0;
    for (const ln of slide.lines.filter(Boolean)) {
      const lines = wrapLines(ln, 1010, size, false);
      lh += Math.min(lines.length, 3) * size * 1.42 + 18;
    }
    return lh;
  };
  let fs = 30;
  while (bodyTop + fitSize(fs) > 664 && fs > 19) fs -= 2;

  push(c, {
    id: "body",
    label: "Note body",
    selectable: true,
    editable: { type: "slideBody", slideId: slide.id },
    visible: true,
    kind: "text",
    x: 90,
    y: bodyTop,
    w: 1100,
    h: Math.max(60, fitSize(fs)),
    fontSize: fs,
    bold: false,
    color: theme.text,
    align: "left",
    text: bodyText,
    draw: (ctx) => {
      const l = c.layers.find((ll) => ll.id === "body")!;
      const size = l.fontSize ?? fs;
      let y = l.y;
      for (const ln of slide.lines.filter(Boolean)) {
        const lines = wrapLines(ln, l.w - 60, size, l.bold ?? false).slice(0, 3);
        // marker
        ctx.beginPath();
        ctx.arc(l.x + 12, y + size * 0.62, 7, 0, Math.PI * 2);
        ctx.fillStyle = hexA(theme.accent, 0.85);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(l.x + 12, y + size * 0.62, 11, 0, Math.PI * 2);
        ctx.strokeStyle = hexA(theme.accent, 0.35);
        ctx.lineWidth = 2;
        ctx.stroke();
        paintLines(
          ctx,
          { x: l.x + 42, y, w: l.w - 60, fontSize: size, bold: l.bold ?? false, color: l.color ?? hexA(theme.text === "#f8fafc" ? "#e2e8f0" : theme.text, 0.92), align: l.align ?? "left" },
          lines,
          1.42,
        );
        y += lines.length * size * 1.42 + 18;
      }
    },
  });
}

function closingLayers(c: Ctx): void {
  const { theme, project } = c;
  push(c, {
    id: "end-kicker",
    label: "Closing kicker",
    selectable: true,
    visible: true,
    kind: "text",
    x: SLIDE_W / 2 - 400,
    y: 236,
    w: 800,
    h: 34,
    fontSize: 24,
    bold: true,
    color: theme.secondary,
    align: "center",
    draw: (ctx) => {
      const l = c.layers.find((ll) => ll.id === "end-kicker")!;
      paintLines(ctx, { x: l.x, y: l.y, w: l.w, fontSize: l.fontSize ?? 24, bold: l.bold ?? true, color: l.color ?? theme.secondary, align: l.align ?? "center" }, [project.title]);
    },
  });
  push(c, {
    id: "end-title",
    label: "Closing title",
    selectable: true,
    visible: true,
    kind: "text",
    x: SLIDE_W / 2 - 500,
    y: 300,
    w: 1000,
    h: 130,
    fontSize: 104,
    bold: true,
    color: theme.text,
    align: "center",
    draw: (ctx) => {
      const l = c.layers.find((ll) => ll.id === "end-title")!;
      const size = l.fontSize ?? 104;
      ctx.font = fontFor(size, true);
      ctx.textAlign = "center";
      ctx.textBaseline = "top";
      const grad = ctx.createLinearGradient(l.x, 0, l.x + l.w, 0);
      grad.addColorStop(0, theme.accent);
      grad.addColorStop(1, theme.secondary);
      ctx.fillStyle = l.color ?? grad;
      ctx.fillText("ধন্যবাদ!", l.x + l.w / 2, l.y);
      ctx.textAlign = "left";
    },
  });
  push(c, {
    id: "end-sub",
    label: "Closing subtitle",
    selectable: true,
    visible: true,
    kind: "text",
    x: SLIDE_W / 2 - 450,
    y: 452,
    w: 900,
    h: 40,
    fontSize: 28,
    bold: false,
    color: theme.muted,
    align: "center",
    draw: (ctx) => {
      const l = c.layers.find((ll) => ll.id === "end-sub")!;
      paintLines(ctx, { x: l.x, y: l.y, w: l.w, fontSize: l.fontSize ?? 28, bold: l.bold ?? false, color: l.color ?? theme.muted, align: l.align ?? "center" }, ["আলোচনা সমাপ্ত — কোনো প্রশ্ন থাকলে জিজ্ঞাসা করুন"]);
    },
  });
}

// -------------------------------------------------------------- entry point

function paintBackground(
  ctx: CanvasRenderingContext2D,
  project: Project,
  theme: ThemePreset,
): void {
  const grad = ctx.createLinearGradient(0, 0, SLIDE_W, SLIDE_H);
  grad.addColorStop(0, theme.bgFrom);
  grad.addColorStop(1, theme.bgTo);
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, SLIDE_W, SLIDE_H);

  const bg = getCachedImage(project.backgroundImage);
  if (bg) {
    ctx.save();
    ctx.globalAlpha = Math.min(1, Math.max(0.05, project.backgroundOpacity));
    drawImageCover(ctx, bg, 0, 0, SLIDE_W, SLIDE_H, 0);
    ctx.restore();
    ctx.save();
    ctx.globalAlpha = 0.82;
    const veil = ctx.createLinearGradient(0, 0, 0, SLIDE_H);
    veil.addColorStop(0, hexA(theme.bgFrom, 0.55));
    veil.addColorStop(1, hexA(theme.bgTo, 0.92));
    ctx.fillStyle = veil;
    ctx.fillRect(0, 0, SLIDE_W, SLIDE_H);
    ctx.restore();
  }

  // ambient glows
  const glow = (x: number, y: number, r: number, color: string) => {
    const g = ctx.createRadialGradient(x, y, 0, x, y, r);
    g.addColorStop(0, color);
    g.addColorStop(1, "transparent");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, SLIDE_W, SLIDE_H);
  };
  glow(SLIDE_W * 0.88, SLIDE_H * 0.08, 420, hexA(theme.accent, 0.22));
  glow(SLIDE_W * 0.06, SLIDE_H * 0.95, 460, hexA(theme.secondary, 0.16));
}

function paintFooter(
  ctx: CanvasRenderingContext2D,
  theme: ThemePreset,
  opts: RenderOpts,
): void {
  // progress bar
  const w = SLIDE_W;
  const pct = opts.total <= 1 ? 1 : (opts.index + 1) / opts.total;
  ctx.fillStyle = hexA(theme.text, 0.08);
  ctx.fillRect(0, SLIDE_H - 6, w, 6);
  const grad = ctx.createLinearGradient(0, 0, w * pct, 0);
  grad.addColorStop(0, theme.accent);
  grad.addColorStop(1, theme.secondary);
  ctx.fillStyle = grad;
  ctx.fillRect(0, SLIDE_H - 6, w * pct, 6);

  // slide counter
  ctx.font = fontFor(18, true);
  ctx.fillStyle = hexA(theme.text, 0.42);
  ctx.textAlign = "right";
  ctx.textBaseline = "alphabetic";
  ctx.fillText(`${toBn(opts.index + 1)} / ${toBn(opts.total)}`, SLIDE_W - 40, SLIDE_H - 22);
  ctx.textAlign = "left";
}

export function drawEntry(
  ctx: CanvasRenderingContext2D,
  project: Project,
  entry: SlideEntry,
  opts: RenderOpts,
): Layer[] {
  const theme = getTheme(project.themeId);
  const c: Ctx = {
    project,
    theme: { ...theme, accent: project.accent || theme.accent, secondary: project.secondary || theme.secondary },
    ovr: opts.overrides ?? {},
    layers: [],
  };

  ctx.save();
  paintBackground(ctx, project, c.theme);

  brandLayers(c);
  if (entry.kind === "cover") coverLayers(c);
  else if (entry.kind === "closing") closingLayers(c);
  else if (entry.slide.type === "mcq") mcqLayers(c, entry.slide, opts.mcqNo);
  else noteLayers(c, entry.slide, opts.noteNo);

  for (const layer of c.layers) {
    if (!layer.visible) continue;
    layer.draw(ctx);
  }

  paintFooter(ctx, c.theme, opts);

  if (opts.selectedId) {
    const sel = c.layers.find((l) => l.id === opts.selectedId && l.visible);
    if (sel) {
      ctx.save();
      ctx.setLineDash([7, 6]);
      ctx.strokeStyle = hexA(c.theme.accent, 0.9);
      ctx.lineWidth = 2;
      roundedRect(ctx, sel.x - 8, sel.y - 8, sel.w + 16, sel.h + 16, 12);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = c.theme.accent;
      for (const [hx, hy] of [
        [sel.x - 8, sel.y - 8],
        [sel.x + sel.w + 8, sel.y - 8],
        [sel.x - 8, sel.y + sel.h + 8],
        [sel.x + sel.w + 8, sel.y + sel.h + 8],
      ]) {
        ctx.beginPath();
        ctx.arc(hx, hy, 5, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    }
  }
  ctx.restore();
  return c.layers;
}

/** Compute layers without painting (for hit-testing before first paint). */
export function buildLayers(
  project: Project,
  entry: SlideEntry,
  overrides: Record<string, LayerOverride>,
): Layer[] {
  const canvas = document.createElement("canvas");
  const ctx = canvas.getContext("2d")!;
  return drawEntry(ctx, project, entry, { index: 0, total: 1, mcqNo: 1, noteNo: 1, overrides });
}

export { entryKey };
