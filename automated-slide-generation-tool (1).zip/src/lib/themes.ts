import type { ThemePreset } from "@/lib/types";

export const THEMES: ThemePreset[] = [
  {
    id: "midnight",
    name: "Midnight Indigo",
    bgFrom: "#0b1120",
    bgTo: "#1e1b4b",
    accent: "#6366f1",
    secondary: "#a78bfa",
    card: "rgba(148, 163, 184, 0.10)",
    stroke: "rgba(148, 163, 184, 0.22)",
    text: "#f8fafc",
    muted: "#94a3b8",
    correct: "#22c55e",
  },
  {
    id: "emerald",
    name: "Emerald Noir",
    bgFrom: "#031716",
    bgTo: "#052e2b",
    accent: "#10b981",
    secondary: "#34d399",
    card: "rgba(45, 212, 191, 0.08)",
    stroke: "rgba(94, 234, 212, 0.20)",
    text: "#f0fdfa",
    muted: "#7dd3c8",
    correct: "#4ade80",
  },
  {
    id: "crimson",
    name: "Crimson Dusk",
    bgFrom: "#14060a",
    bgTo: "#3b0a18",
    accent: "#f43f5e",
    secondary: "#fb923c",
    card: "rgba(251, 113, 133, 0.08)",
    stroke: "rgba(251, 113, 133, 0.22)",
    text: "#fff1f2",
    muted: "#fda4af",
    correct: "#34d399",
  },
  {
    id: "ocean",
    name: "Ocean Ink",
    bgFrom: "#020617",
    bgTo: "#082f49",
    accent: "#0ea5e9",
    secondary: "#22d3ee",
    card: "rgba(56, 189, 248, 0.08)",
    stroke: "rgba(56, 189, 248, 0.22)",
    text: "#f0f9ff",
    muted: "#7dd3fc",
    correct: "#4ade80",
  },
  {
    id: "amber",
    name: "Amber Slate",
    bgFrom: "#0c0a09",
    bgTo: "#292018",
    accent: "#f59e0b",
    secondary: "#fbbf24",
    card: "rgba(251, 191, 36, 0.08)",
    stroke: "rgba(251, 191, 36, 0.20)",
    text: "#fffbeb",
    muted: "#fcd34d",
    correct: "#22c55e",
  },
  {
    id: "violet",
    name: "Violet Nebula",
    bgFrom: "#10051f",
    bgTo: "#2e1065",
    accent: "#8b5cf6",
    secondary: "#e879f9",
    card: "rgba(167, 139, 250, 0.10)",
    stroke: "rgba(167, 139, 250, 0.24)",
    text: "#f5f3ff",
    muted: "#c4b5fd",
    correct: "#4ade80",
  },
];

export function getTheme(id: string): ThemePreset {
  return THEMES.find((t) => t.id === id) ?? THEMES[0];
}

/** Convert a hex color to an rgba() string with the given alpha. */
export function hexA(hex: string, alpha: number): string {
  const clean = hex.replace("#", "");
  const full = clean.length === 3 ? clean.split("").map((c) => c + c).join("") : clean;
  const num = parseInt(full, 16);
  const r = (num >> 16) & 255;
  const g = (num >> 8) & 255;
  const b = num & 255;
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}
