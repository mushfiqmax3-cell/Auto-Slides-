// Bengali locale helpers used across parsing, rendering and exports.

export const BN_DIGITS = ["০", "১", "২", "৩", "৪", "৫", "৬", "৭", "৮", "৯"];

export const BN_OPTION_LETTERS = [
  "ক",
  "খ",
  "গ",
  "ঘ",
  "ঙ",
  "চ",
  "ছ",
  "জ",
  "ঝ",
  "ট",
];

/** Convert ASCII digits inside any string/number into Bengali digits. */
export function toBn(value: string | number): string {
  return String(value).replace(/[0-9]/g, (d) => BN_DIGITS[Number(d)]);
}

/** Convert Bengali digits to ASCII digits. */
export function fromBn(value: string): string {
  return value.replace(/[০-৯]/g, (d) => String(BN_DIGITS.indexOf(d)));
}

/** Index of a Bengali option letter (ক -> 0, খ -> 1 ...) or -1. */
export function bnLetterIndex(letter: string): number {
  return BN_OPTION_LETTERS.indexOf(letter.trim());
}

/** Badge letter for an option index. */
export function optionBadge(index: number): string {
  return BN_OPTION_LETTERS[index] ?? String(index + 1);
}
