// Client-side image cache for canvas rendering + font readiness helpers.

const cache = new Map<string, HTMLImageElement>();
const pending = new Map<string, Promise<HTMLImageElement>>();

export function getCachedImage(src?: string): HTMLImageElement | null {
  if (!src) return null;
  return cache.get(src) ?? null;
}

/** Ensure every src is decoded and cached. Safe to call repeatedly. */
export async function ensureImages(srcs: Array<string | undefined>): Promise<void> {
  if (typeof window === "undefined") return;
  const jobs = srcs
    .filter((s): s is string => Boolean(s))
    .map((src) => {
      if (cache.has(src)) return Promise.resolve();
      if (!pending.has(src)) {
        pending.set(
          src,
          new Promise<HTMLImageElement>((resolve, reject) => {
            const img = new Image();
            img.onload = () => {
              cache.set(src, img);
              resolve(img);
            };
            img.onerror = () => reject(new Error("image failed to load"));
            img.src = src;
          }).finally(() => pending.delete(src)),
        );
      }
      return pending.get(src)!.then(() => undefined);
    });
  await Promise.allSettled(jobs);
}

/** All raster sources referenced by a project. */
export function projectImageSrcs(p: {
  backgroundImage?: string;
  coverImage?: string;
  brandLeft: { image?: string };
  brandRight: { image?: string };
}): Array<string | undefined> {
  return [p.backgroundImage, p.coverImage, p.brandLeft.image, p.brandRight.image];
}

/** Wait for the Bengali + display webfonts so canvas text metrics are correct. */
export async function ensureFonts(): Promise<void> {
  if (typeof document === "undefined" || !document.fonts) return;
  try {
    await Promise.all([
      document.fonts.load('400 32px "Hind Siliguri"'),
      document.fonts.load('700 40px "Hind Siliguri"'),
      document.fonts.load('600 28px "Hind Siliguri"'),
      document.fonts.load('800 60px "Plus Jakarta Sans"'),
    ]);
    await document.fonts.ready;
  } catch {
    // font loading is best-effort; system fallbacks will be used
  }
}
