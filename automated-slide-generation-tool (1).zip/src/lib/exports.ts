// Export engines: PPTX (PptxGenJS), high-res PNG zip (canvas renderer) and
// project JSON download. All run fully client-side.

import { optionBadge, toBn } from "@/lib/bengali";
import { ensureFonts, ensureImages, projectImageSrcs } from "@/lib/images";
import { drawEntry, SLIDE_H, SLIDE_W } from "@/lib/renderer";
import { getTheme, hexA } from "@/lib/themes";
import type { OverridesMap, Project, ProjectSnapshot, SlideEntry } from "@/lib/types";
import { buildEntries, entryKey } from "@/lib/types";

const IN = 96; // virtual units per inch (1280x720 -> 13.333in x 7.5in)
const u = (v: number) => v / IN;
const hex = (c: string) => c.replace("#", "").toUpperCase();
const FONT_FACE = "Hind Siliguri";

/** Per-entry sequence numbers (question n / note n). */
export function entryStats(entries: SlideEntry[]) {
  let mcq = 0;
  let note = 0;
  return entries.map((entry) => {
    if (entry.kind === "slide" && entry.slide.type === "mcq") mcq += 1;
    if (entry.kind === "slide" && entry.slide.type === "note") note += 1;
    return { mcqNo: mcq, noteNo: note };
  });
}

function triggerDownload(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

export function slugify(name: string): string {
  const base = name.trim().replace(/[^\p{L}\p{N}]+/gu, "-").replace(/^-+|-+$/g, "");
  return base || "slides";
}

// ------------------------------------------------------------------ PPTX

export async function exportPptx(project: Project, overrides: OverridesMap): Promise<void> {
  const { default: PptxGenJS } = await import("pptxgenjs");
  const pptx = new PptxGenJS();
  pptx.defineLayout({ name: "WIDESCREEN", width: 13.333, height: 7.5 });
  pptx.layout = "WIDESCREEN";
  pptx.title = project.title || "AutoSlides Presentation";
  pptx.author = "AutoSlides";

  const theme = {
    ...getTheme(project.themeId),
    accent: project.accent || getTheme(project.themeId).accent,
    secondary: project.secondary || getTheme(project.themeId).secondary,
  };
  const entries = buildEntries(project);
  const stats = entryStats(entries);
  void overrides; // PPTX is generated from canonical layout; canvas overrides are preview-only.

  interface PptxSlideLike {
    addText(text: unknown, opts?: unknown): unknown;
    addShape(name: string, opts?: unknown): unknown;
    addImage(opts: unknown): unknown;
    background?: { color?: string };
  }

  const addCommon = (slide: PptxSlideLike, index: number) => {
    // background
    if (project.backgroundImage) {
      slide.addImage({
        data: project.backgroundImage,
        x: 0,
        y: 0,
        w: u(SLIDE_W),
        h: u(SLIDE_H),
        sizing: { type: "cover", w: u(SLIDE_W), h: u(SLIDE_H) },
      });
      slide.addShape("rect", {
        x: 0,
        y: 0,
        w: u(SLIDE_W),
        h: u(SLIDE_H),
        fill: { color: hex(theme.bgFrom), transparency: 35 },
        line: { type: "none" },
      });
    } else {
      slide.background = { color: hex(theme.bgFrom) };
      slide.addShape("rect", {
        x: u(SLIDE_W * 0.62),
        y: 0,
        w: u(SLIDE_W * 0.38),
        h: u(SLIDE_H),
        fill: { color: hex(theme.bgTo), transparency: 8 },
        line: { type: "none" },
      });
    }
    // progress bar
    slide.addShape("rect", {
      x: 0,
      y: u(SLIDE_H - 6),
      w: u(SLIDE_W),
      h: u(6),
      fill: { color: hex(theme.accent), transparency: 78 },
      line: { type: "none" },
    });
    slide.addShape("rect", {
      x: 0,
      y: u(SLIDE_H - 6),
      w: u(SLIDE_W * ((index + 1) / entries.length)),
      h: u(6),
      fill: { color: hex(theme.accent) },
      line: { type: "none" },
    });
    slide.addText(`${toBn(index + 1)} / ${toBn(entries.length)}`, {
      x: u(SLIDE_W - 240),
      y: u(SLIDE_H - 46),
      w: u(200),
      h: u(28),
      fontFace: FONT_FACE,
      fontSize: 10,
      bold: true,
      color: hex(theme.muted),
      align: "right",
    });
    // branding
    if (project.brandLeft.enabled) {
      if (project.brandLeft.type === "image" && project.brandLeft.image) {
        slide.addImage({ data: project.brandLeft.image, x: u(56), y: u(34), w: u(150), h: u(44), sizing: { type: "contain", w: u(150), h: u(44) } });
      } else {
        slide.addText(project.brandLeft.text || "লোগো", {
          x: u(52),
          y: u(30),
          w: u(340),
          h: u(54),
          fontFace: FONT_FACE,
          fontSize: 14,
          bold: true,
          color: hex(theme.text),
          align: "center",
          valign: "middle",
          fill: { color: hex(theme.accent), transparency: 84 },
          line: { color: hex(theme.accent), transparency: 55, width: 1 },
          shape: "roundRect",
          rectRadius: u(12),
        });
      }
    }
    if (project.brandRight.enabled) {
      if (project.brandRight.type === "image" && project.brandRight.image) {
        slide.addImage({ data: project.brandRight.image, x: u(SLIDE_W - 226), y: u(34), w: u(170), h: u(44), sizing: { type: "contain", w: u(170), h: u(44) } });
      } else {
        slide.addText(project.brandRight.text || "ওয়াটারমার্ক", {
          x: u(SLIDE_W - 356),
          y: u(36),
          w: u(300),
          h: u(40),
          fontFace: FONT_FACE,
          fontSize: 12,
          bold: true,
          color: hex(theme.muted),
          align: "right",
          transparency: 40,
        });
      }
    }
  };

  entries.forEach((entry, index) => {
    const slide = pptx.addSlide();
    addCommon(slide, index);
    const { mcqNo, noteNo } = stats[index];

    if (entry.kind === "cover") {
      slide.addText("স্বয়ংক্রিয় স্লাইড প্রেজেন্টেশন", {
        x: u(390),
        y: u(148),
        w: u(500),
        h: u(42),
        fontFace: FONT_FACE,
        fontSize: 12,
        bold: true,
        color: hex(theme.secondary),
        align: "center",
        valign: "middle",
        shape: "roundRect",
        rectRadius: u(21),
        fill: { color: hex(theme.accent), transparency: 86 },
        line: { color: hex(theme.accent), transparency: 50, width: 1 },
      });
      slide.addText(project.title || "শিরোনামহীন উপস্থাপনা", {
        x: u(120),
        y: u(208),
        w: u(1040),
        h: u(170),
        fontFace: FONT_FACE,
        fontSize: 34,
        bold: true,
        color: hex(theme.text),
        align: "center",
        valign: "top",
      });
      if (project.subtitle) {
        slide.addText(project.subtitle, {
          x: u(190),
          y: u(392),
          w: u(900),
          h: u(70),
          fontFace: FONT_FACE,
          fontSize: 15,
          color: hex(theme.muted),
          align: "center",
          valign: "top",
        });
      }
      if (project.coverImage) {
        slide.addImage({
          data: project.coverImage,
          x: u(SLIDE_W / 2 - 280),
          y: u(SLIDE_H - 64 - 315),
          w: u(560),
          h: u(315),
          sizing: { type: "cover", w: u(560), h: u(315) },
        });
      }
      return;
    }

    if (entry.kind === "closing") {
      slide.addText(project.title, {
        x: u(240),
        y: u(236),
        w: u(800),
        h: u(40),
        fontFace: FONT_FACE,
        fontSize: 14,
        bold: true,
        color: hex(theme.secondary),
        align: "center",
      });
      slide.addText("ধন্যবাদ!", {
        x: u(140),
        y: u(298),
        w: u(1000),
        h: u(140),
        fontFace: FONT_FACE,
        fontSize: 66,
        bold: true,
        color: hex(theme.accent),
        align: "center",
      });
      slide.addText("আলোচনা সমাপ্ত — কোনো প্রশ্ন থাকলে জিজ্ঞাসা করুন", {
        x: u(190),
        y: u(452),
        w: u(900),
        h: u(44),
        fontFace: FONT_FACE,
        fontSize: 16,
        color: hex(theme.muted),
        align: "center",
      });
      return;
    }

    if (entry.slide.type === "note") {
      const note = entry.slide;
      slide.addText(`নোট ${toBn(noteNo)}`, {
        x: u(56),
        y: u(96),
        w: u(190),
        h: u(46),
        fontFace: FONT_FACE,
        fontSize: 12,
        bold: true,
        color: hex(theme.secondary),
        align: "center",
        valign: "middle",
        shape: "roundRect",
        rectRadius: u(23),
        fill: { color: hex(theme.accent), transparency: 86 },
        line: { color: hex(theme.accent), transparency: 45, width: 1 },
      });
      slide.addText(note.heading, {
        x: u(90),
        y: u(166),
        w: u(1100),
        h: u(96),
        fontFace: FONT_FACE,
        fontSize: 26,
        bold: true,
        color: hex(theme.text),
        valign: "top",
      });
      const bullets = note.lines.filter(Boolean).slice(0, 14);
      slide.addText(
        bullets.map((ln) => ({
          text: ln,
          options: { bullet: { code: "2022", indent: 14 }, breakLine: true, paraSpaceAfter: 8 },
        })),
        {
          x: u(100),
          y: u(280),
          w: u(1080),
          h: u(370),
          fontFace: FONT_FACE,
          fontSize: 16,
          color: hex(theme.text),
          valign: "top",
          lineSpacingMultiple: 1.25,
        },
      );
      return;
    }

    // ---- MCQ slide
    const mcq = entry.slide;
    slide.addText(`প্রশ্ন ${toBn(mcqNo)}`, {
      x: u(56),
      y: u(96),
      w: u(190),
      h: u(46),
      fontFace: FONT_FACE,
      fontSize: 12,
      bold: true,
      color: hex(theme.secondary),
      align: "center",
      valign: "middle",
      shape: "roundRect",
      rectRadius: u(23),
      fill: { color: hex(theme.accent), transparency: 86 },
      line: { color: hex(theme.accent), transparency: 45, width: 1 },
    });
    slide.addText(mcq.question, {
      x: u(96),
      y: u(164),
      w: u(1040),
      h: u(120),
      fontFace: FONT_FACE,
      fontSize: 20,
      bold: true,
      color: hex(theme.text),
      valign: "top",
    });
    slide.addShape("roundRect", {
      x: u(60),
      y: u(166),
      w: u(10),
      h: u(70),
      fill: { color: hex(theme.accent) },
      line: { type: "none" },
      rectRadius: u(5),
    });

    const opts = mcq.options.slice(0, 6);
    const cols = opts.every((o) => o.length <= 28) ? 2 : 1;
    const gap = 22;
    const cw = (SLIDE_W - 96 * 2 - gap * (cols - 1)) / cols;
    const rowH = cols === 2 ? 92 : 74;
    const top = 310;
    opts.forEach((opt, i) => {
      const r = Math.floor(i / cols);
      const cc = i % cols;
      const x = 96 + cc * (cw + gap);
      const y = top + r * (rowH + 16);
      const isCorrect = project.showAnswers && mcq.answerIndex === i;
      const style = isCorrect ? "correct" : project.optionStyle;
      const fill =
        style === "soft"
          ? { color: hex(theme.bgTo), transparency: 55 }
          : style === "outline"
            ? { color: hex(theme.bgFrom), transparency: 100 }
            : style === "solid"
              ? { color: hex(theme.accent), transparency: 5 }
              : { color: hex(theme.correct), transparency: 84 };
      const line =
        style === "outline"
          ? { color: hex(theme.accent), width: 1.5, transparency: 45 }
          : style === "correct"
            ? { color: hex(theme.correct), width: 1.75 }
            : { color: hex(theme.accent), width: 1, transparency: 70 };
      slide.addShape("roundRect", {
        x: u(x),
        y: u(y),
        w: u(cw),
        h: u(rowH),
        rectRadius: u(14),
        fill,
        line,
      });
      slide.addText(optionBadge(i), {
        x: u(x + 22),
        y: u(y + rowH / 2 - 23),
        w: u(46),
        h: u(46),
        fontFace: FONT_FACE,
        fontSize: 13,
        bold: true,
        align: "center",
        valign: "middle",
        color: style === "correct" ? "05210F" : style === "solid" ? "FFFFFF" : hex(theme.secondary),
        shape: "roundRect",
        rectRadius: u(12),
        fill:
          style === "correct"
            ? { color: hex(theme.correct) }
            : style === "solid"
              ? { color: "0B1020", transparency: 15 }
              : { color: hex(theme.accent), transparency: 82 },
      });
      slide.addText(opt, {
        x: u(x + 84),
        y: u(y),
        w: u(cw - 96),
        h: u(rowH),
        fontFace: FONT_FACE,
        fontSize: 14,
        color: isCorrect
          ? hex(theme.correct)
          : style === "solid"
            ? "F8FAFC"
            : hex(theme.text),
        bold: isCorrect,
        valign: "middle",
      });
    });

    if (project.showAnswers && mcq.answerIndex >= 0) {
      slide.addText(`সঠিক উত্তর: ${optionBadge(mcq.answerIndex)}`, {
        x: u(96),
        y: u(658),
        w: u(320),
        h: u(40),
        fontFace: FONT_FACE,
        fontSize: 12,
        bold: true,
        color: hex(theme.correct),
        align: "center",
        valign: "middle",
        shape: "roundRect",
        rectRadius: u(20),
        fill: { color: hex(theme.correct), transparency: 84 },
        line: { color: hex(theme.correct), transparency: 35, width: 1 },
      });
    }
  });

  await pptx.writeFile({ fileName: `${slugify(project.title)}.pptx` });
}

// ------------------------------------------------------------------- PNG

export async function exportPngZip(
  project: Project,
  overrides: OverridesMap,
  onProgress?: (pct: number) => void,
): Promise<void> {
  await ensureImages(projectImageSrcs(project));
  await ensureFonts();
  const { default: JSZip } = await import("jszip");
  const zip = new JSZip();
  const entries = buildEntries(project);
  const stats = entryStats(entries);
  const scale = 1920 / SLIDE_W;

  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i];
    const canvas = document.createElement("canvas");
    canvas.width = SLIDE_W * scale;
    canvas.height = SLIDE_H * scale;
    const ctx = canvas.getContext("2d")!;
    ctx.scale(scale, scale);
    drawEntry(ctx, project, entry, {
      index: i,
      total: entries.length,
      mcqNo: stats[i].mcqNo,
      noteNo: stats[i].noteNo,
      overrides: overrides[entryKey(entry)] ?? {},
    });
    const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, "image/png"));
    if (blob) zip.file(`slide-${String(i + 1).padStart(2, "0")}.png`, blob);
    onProgress?.(((i + 1) / (entries.length + 1)) * 100);
  }
  const out = await zip.generateAsync({ type: "blob" });
  onProgress?.(100);
  triggerDownload(out, `${slugify(project.title)}-slides.zip`);
}

// ------------------------------------------------------------------ JSON

export function exportProjectJson(snapshot: ProjectSnapshot, title: string): void {
  const blob = new Blob([JSON.stringify(snapshot, null, 2)], { type: "application/json" });
  triggerDownload(blob, `${slugify(title)}.autoslides.json`);
}

export function parseProjectJson(text: string): ProjectSnapshot | null {
  try {
    const data = JSON.parse(text) as ProjectSnapshot;
    if (data && data.project && Array.isArray(data.project.slides)) {
      return { version: 1, project: data.project, overrides: data.overrides ?? {} };
    }
    return null;
  } catch {
    return null;
  }
}

export { hexA };
