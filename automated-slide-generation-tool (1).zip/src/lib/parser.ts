// Content parsing: turns pasted plain text, CSV or JSON into structured slides.
// Understands Bengali ("১। প্রশ্ন?", "ক) ...", "উত্তর: ক") and English formats.

import { bnLetterIndex, fromBn } from "@/lib/bengali";
import type { MCQSlide, NoteSlide, Slide } from "@/lib/types";

export interface ParsedContent {
  slides: Array<Omit<Slide, "id">>;
  mcqCount: number;
  noteCount: number;
  detectedFormat: "plain" | "json" | "csv";
}

const BN_OPT_RE = /^\s*\(?([কখগঘঙচছজঝট])\)?[.\):\-–]\s*(.+)$/u;
const EN_OPT_RE = /^\s*\(?([A-Ea-e])\)?[.\):]\s+(.+)$/;
const QNUM_RE = /^\s*(\d{1,3}|[০-৯]{1,3})\s*[.\):\u002D–।ঁ৷]\s*(.+)$/u;
const ANSWER_RE = /^\s*(উত্তর|উত্তরঃ|উঃ|সঠিক উত্তর|ans(?:wer)?|correct answer|answer)\s*[:\-–.\)]?\s*(.+)$/i;
const EXPLAIN_RE = /^\s*(ব্যাখ্যা|ব্যাখ্যঃ|explanation|note)\s*[:\-–]?\s*(.+)$/i;
const HEADING_RE = /^\s*#{1,3}\s+(.+)$/;
const BULLET_RE = /^\s*[\-\*•–▪◦]\s+(.+)$/;

function stripCorrectMark(text: string): { text: string; marked: boolean } {
  const t = text.trim();
  if (t.startsWith("✓") || t.startsWith("✔")) return { text: t.slice(1).trim(), marked: true };
  if (t.endsWith("✓") || t.endsWith("✔")) return { text: t.slice(0, -1).trim(), marked: true };
  const star = t.match(/^(.*?)\s*\(\s*সঠিক\s*\)$/);
  if (star) return { text: star[1], marked: true };
  return { text: t, marked: false };
}

/** Resolve an answer token ("ক", "b", "2", "২", or option text) to an index. */
function resolveAnswer(token: string, options: string[]): number {
  const t = token.trim();
  if (!t) return -1;
  const bnIdx = bnLetterIndex(t.replace(/[\)\.\:]/g, ""));
  if (bnIdx >= 0 && bnIdx < options.length) return bnIdx;
  const en = t.match(/^\(?([A-Ja-j])[\)\.\:]?$/);
  if (en) {
    const idx = en[1].toLowerCase().charCodeAt(0) - 97;
    return idx < options.length ? idx : -1;
  }
  const num = t.match(/^(\d+|[০-৯]+)$/);
  if (num) {
    const idx = parseInt(fromBn(num[1]), 10) - 1;
    return idx >= 0 && idx < options.length ? idx : -1;
  }
  const byText = options.findIndex((o) => o.replace(/\s+/g, "") === t.replace(/\s+/g, ""));
  return byText;
}

function isOptionLine(line: string): boolean {
  return BN_OPT_RE.test(line) || EN_OPT_RE.test(line);
}

function looksLikeQuestionStart(lines: string[], i: number): boolean {
  if (!QNUM_RE.test(lines[i])) return false;
  for (let j = i + 1; j < Math.min(i + 5, lines.length); j++) {
    if (isOptionLine(lines[j])) return true;
    if (lines[j].trim() === "") break;
  }
  return false;
}

export function parseContent(raw: string): ParsedContent {
  const text = raw.trim();
  if (!text) return { slides: [], mcqCount: 0, noteCount: 0, detectedFormat: "plain" };
  if (text.startsWith("[") || text.startsWith("{")) return parseJSON(text);
  const firstLine = text.split(/\r?\n/).find((l) => l.trim()) ?? "";
  if (/question/i.test(firstLine) && firstLine.includes(",")) return parseCSV(text);
  return parsePlain(text);
}

// ---------------------------------------------------------------- plain text

interface MCQDraft {
  question: string;
  options: string[];
  answerIndex: number;
  explanation?: string;
  marked: number;
}

function parsePlain(text: string): ParsedContent {
  const lines = text.split(/\r?\n/);
  const slides: Array<Omit<Slide, "id">> = [];
  let draft: MCQDraft | null = null;
  let note: { heading: string; lines: string[] } | null = null;
  let pendingQuestion: string | null = null;

  const flushDraft = () => {
    if (draft && draft.question && draft.options.length >= 2) {
      const { marked, ...rest } = draft;
      slides.push({ type: "mcq", ...rest, answerIndex: rest.answerIndex } as Omit<MCQSlide, "id">);
    }
    draft = null;
  };
  const flushNote = () => {
    if (note && (note.heading || note.lines.length)) {
      slides.push({
        type: "note",
        heading: note.heading || "লেকচার নোট",
        lines: note.lines.filter(Boolean),
      } as Omit<NoteSlide, "id">);
    }
    note = null;
  };

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const trimmed = line.trim();

    if (trimmed === "") {
      if (draft && draft.options.length >= 2 && pendingQuestion === null) flushDraft();
      continue;
    }

    const heading = trimmed.match(HEADING_RE);
    if (heading) {
      flushDraft();
      flushNote();
      note = { heading: heading[1].trim(), lines: [] };
      continue;
    }

    const bullet = trimmed.match(BULLET_RE);
    if (bullet && !draft) {
      if (note) note.lines.push(bullet[1].trim());
      else note = { heading: "লেকচার নোট", lines: [bullet[1].trim()] };
      continue;
    }

    const answer = trimmed.match(ANSWER_RE);
    if (answer && draft) {
      draft.answerIndex = resolveAnswer(answer[2], draft.options);
      continue;
    }

    const explanation = trimmed.match(EXPLAIN_RE);
    if (explanation && draft) {
      draft.explanation = explanation[2].trim();
      continue;
    }

    const optBn = trimmed.match(BN_OPT_RE);
    const optEn = trimmed.match(EN_OPT_RE);
    if (optBn || optEn) {
      const body = (optBn ? optBn[2] : optEn![2]).trim();
      const { text: clean, marked } = stripCorrectMark(body);
      if (!draft) {
        draft = {
          question: pendingQuestion ?? "প্রশ্ন",
          options: [],
          answerIndex: -1,
          marked: -1,
        };
        pendingQuestion = null;
      }
      draft.options.push(clean);
      if (marked) draft.answerIndex = draft.options.length - 1;
      continue;
    }

    if (looksLikeQuestionStart(lines, i)) {
      flushDraft();
      if (note) flushNote();
      const q = trimmed.match(QNUM_RE)!;
      draft = { question: q[2].trim(), options: [], answerIndex: -1, marked: -1 };
      continue;
    }

    // A bare sentence followed by option lines → treat as the question text.
    if (!draft && isOptionLine(lines[i + 1] ?? "")) {
      if (note) flushNote();
      draft = { question: trimmed, options: [], answerIndex: -1, marked: -1 };
      continue;
    }

    if (note && !draft) {
      note.lines.push(trimmed);
      continue;
    }
    pendingQuestion = trimmed;
  }

  flushDraft();
  flushNote();

  return {
    slides,
    mcqCount: slides.filter((s) => s.type === "mcq").length,
    noteCount: slides.filter((s) => s.type === "note").length,
    detectedFormat: "plain",
  };
}

// ---------------------------------------------------------------------- JSON

function parseJSON(text: string): ParsedContent {
  try {
    const data = JSON.parse(text);
    const items: unknown[] = Array.isArray(data) ? data : [data];
    const slides: Array<Omit<Slide, "id">> = [];
    for (const item of items) {
      if (!item || typeof item !== "object") continue;
      const obj = item as Record<string, unknown>;
      const options = Array.isArray(obj.options) ? obj.options.map(String).slice(0, 10) : [];
      if (obj.question && options.length >= 2) {
        let answerIndex = -1;
        const ans = obj.answer ?? obj.answerIndex ?? obj.correct;
        if (typeof ans === "number") answerIndex = ans;
        else if (typeof ans === "string") answerIndex = resolveAnswer(ans, options);
        slides.push({
          type: "mcq",
          question: String(obj.question),
          options,
          answerIndex,
          explanation: obj.explanation ? String(obj.explanation) : undefined,
        } as Omit<MCQSlide, "id">);
      } else if (obj.heading || obj.title) {
        const listRaw: unknown = obj.lines ?? obj.bullets ?? obj.body;
        const lines = Array.isArray(listRaw)
          ? listRaw.map(String)
          : typeof obj.body === "string"
            ? String(obj.body).split("\n")
            : [];
        slides.push({
          type: "note",
          heading: String(obj.heading ?? obj.title),
          lines,
        } as Omit<NoteSlide, "id">);
      }
    }
    return {
      slides,
      mcqCount: slides.filter((s) => s.type === "mcq").length,
      noteCount: slides.filter((s) => s.type === "note").length,
      detectedFormat: "json",
    };
  } catch {
    return { slides: [], mcqCount: 0, noteCount: 0, detectedFormat: "json" };
  }
}

// ----------------------------------------------------------------------- CSV

function parseCSVLine(line: string): string[] {
  const cells: string[] = [];
  let cur = "";
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      if (inQuotes && line[i + 1] === '"') {
        cur += '"';
        i++;
      } else inQuotes = !inQuotes;
    } else if (ch === "," && !inQuotes) {
      cells.push(cur);
      cur = "";
    } else cur += ch;
  }
  cells.push(cur);
  return cells.map((c) => c.trim());
}

function parseCSV(text: string): ParsedContent {
  const lines = text.split(/\r?\n/).filter((l) => l.trim());
  if (lines.length === 0) return { slides: [], mcqCount: 0, noteCount: 0, detectedFormat: "csv" };
  const header = parseCSVLine(lines[0]).map((h) => h.toLowerCase());
  const hasHeader = header.some((h) => h.includes("question"));
  const dataLines = hasHeader ? lines.slice(1) : lines;
  const optCols = header
    .map((h, i) => ({ h, i }))
    .filter(({ h }) => /opt|option|[a-d]$/.test(h))
    .map(({ i }) => i);
  const ansCol = header.findIndex((h) => /ans|correct/.test(h));

  const slides: Array<Omit<Slide, "id">> = [];
  for (const line of dataLines) {
    const cells = parseCSVLine(line);
    const question = cells[0];
    const optionCells = optCols.length >= 2 ? optCols.map((i) => cells[i]) : cells.slice(1, 5);
    const options = optionCells.filter(Boolean).slice(0, 10);
    if (!question || options.length < 2) continue;
    const ansToken = ansCol >= 0 ? cells[ansCol] : cells[1 + options.length];
    slides.push({
      type: "mcq",
      question,
      options,
      answerIndex: ansToken ? resolveAnswer(ansToken, options) : -1,
    } as Omit<MCQSlide, "id">);
  }
  return {
    slides,
    mcqCount: slides.length,
    noteCount: 0,
    detectedFormat: "csv",
  };
}
