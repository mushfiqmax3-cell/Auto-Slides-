package com.example

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.MutableContextWrapper
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.net.Uri
import android.os.Build
import android.os.Message
import android.print.PrintAttributes
import android.print.PrintManager
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.RenderProcessGoneDetail
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.compose.runtime.Immutable
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import com.example.data.BookmarkEntity
import com.example.data.BrowserDatabase
import com.example.data.BrowserPreferences
import com.example.data.BrowserRepository
import com.example.data.BrowserSettings
import com.example.data.DownloadEntity
import com.example.data.DownloadStatus
import com.example.data.FrameRateMode
import com.example.data.HistoryEntity
import com.example.data.HomepageMode
import com.example.data.InstalledWebAppEntity
import com.example.data.SearchEngine
import com.example.data.ThemeMode
import java.io.ByteArrayInputStream
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

@Immutable
data class BrowserTabModel(
    val id: Int,
    val slotTitle: String,
    val pageTitle: String = "Google AI Studio",
    val url: String = WebViewManager.DEFAULT_HOME_URL,
    val favicon: Bitmap? = null,
    val thumbnail: Bitmap? = null,
    val isDesktopMode: Boolean = false,
    val isIncognito: Boolean = false,
    val canGoBack: Boolean = false,
    val canGoForward: Boolean = false,
    val isSslSecure: Boolean = true,
    val lastKeepAlivePulseMs: Long = System.currentTimeMillis()
)

data class OAuthPopupSession(
    val id: Long = System.currentTimeMillis(),
    val parentTabId: Int,
    val url: String = "https://accounts.google.com/",
    val title: String = "Sign in with Google",
    val isLoading: Boolean = true,
    val progress: Int = 15,
    val popupWebView: WebView
)

data class FindInPageState(
    val isVisible: Boolean = false,
    val query: String = "",
    val activeMatchIndex: Int = 0,
    val totalMatches: Int = 0
)

data class WebContextMenuTarget(
    val linkUrl: String? = null,
    val imageUrl: String? = null,
    val title: String = ""
)

/**
 * Custom WebView subclass engineered to bypass Chromium's WindowVisibility and PageVisibility
 * background throttling. Always reports View.VISIBLE to the internal Blink compositor even when
 * the app is minimized or the display is turned off.
 */
@SuppressLint("ViewConstructor")
class UnthrottledWebView(context: Context) : WebView(context) {

    var allowExplicitDestroy: Boolean = false
    var onUserTap: (() -> Unit)? = null

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent?): Boolean {
        if (event?.actionMasked == MotionEvent.ACTION_UP) {
            onUserTap?.invoke()
        }
        return super.onTouchEvent(event)
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(View.VISIBLE)
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, View.VISIBLE)
    }

    override fun onPause() {
        if (allowExplicitDestroy) {
            super.onPause()
        }
    }

    override fun pauseTimers() {
        if (allowExplicitDestroy) {
            super.pauseTimers()
        }
    }
}

class WebViewManager(private val appContext: Context) {

    private val contextWrappers = LinkedHashMap<Int, MutableContextWrapper>()
    private val webViews = LinkedHashMap<Int, UnthrottledWebView>()
    private var currentActivity: Activity? = null

    val repository = BrowserRepository(BrowserDatabase.getInstance(appContext))
    val preferences = BrowserPreferences(appContext)
    private val ioScope = kotlinx.coroutines.CoroutineScope(
        kotlinx.coroutines.SupervisorJob() + Dispatchers.IO
    )
    private val mainScope = kotlinx.coroutines.CoroutineScope(
        kotlinx.coroutines.SupervisorJob() + Dispatchers.Main
    )

    @Volatile
    var currentSettings: BrowserSettings = BrowserSettings()
        private set

    // Single persistent FrameLayout hosting all active WebViews simultaneously
    val persistentContainer: FrameLayout = FrameLayout(appContext).apply {
        layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        keepScreenOn = true
    }

    private val _tabsState = MutableStateFlow<List<BrowserTabModel>>(emptyList())
    val tabsState: StateFlow<List<BrowserTabModel>> = _tabsState.asStateFlow()

    private val _activeTabId = MutableStateFlow(1)
    val activeTabId: StateFlow<Int> = _activeTabId.asStateFlow()

    private val tabProgressMap = LinkedHashMap<Int, Int>()
    private val tabLoadingMap = LinkedHashMap<Int, Boolean>()
    private val tabUserMediaUnlocked = ConcurrentHashMap<Int, Boolean>()
    private val tabInitialUrlLoaded = ConcurrentHashMap<Int, Boolean>()

    private val _activeTabProgress = MutableStateFlow(0)
    val activeTabProgress: StateFlow<Int> = _activeTabProgress.asStateFlow()

    private val _activeTabIsLoading = MutableStateFlow(false)
    val activeTabIsLoading: StateFlow<Boolean> = _activeTabIsLoading.asStateFlow()

    private val _oauthPopupState = MutableStateFlow<OAuthPopupSession?>(null)
    val oauthPopupState: StateFlow<OAuthPopupSession?> = _oauthPopupState.asStateFlow()

    private val _pendingDownload = MutableStateFlow<PendingDownloadRequest?>(null)
    val pendingDownload: StateFlow<PendingDownloadRequest?> = _pendingDownload.asStateFlow()

    private val _findInPageState = MutableStateFlow(FindInPageState())
    val findInPageState: StateFlow<FindInPageState> = _findInPageState.asStateFlow()

    private val _contextMenuTarget = MutableStateFlow<WebContextMenuTarget?>(null)
    val contextMenuTarget: StateFlow<WebContextMenuTarget?> = _contextMenuTarget.asStateFlow()

    private val _isGoogleSignedIn = MutableStateFlow(false)
    val isGoogleSignedIn: StateFlow<Boolean> = _isGoogleSignedIn.asStateFlow()

    // File Chooser & WebRTC/Geolocation Permission bridges connected to MainActivity
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var activeFileChooserSession: ChromeFileChooserSession? = null
    var onLaunchFileChooser: ((Intent) -> Boolean)? = null

    var onRequestRuntimePermissions: ((Array<String>, (Boolean) -> Unit) -> Unit)? = null

    private var nextTabId = 1

    private val downloadBridge = StudioDownloadBridge(appContext) { fileName, url, mimeType, uriStr, sizeBytes, folderLabel ->
        ioScope.launch {
            repository.insertDownload(
                DownloadEntity(
                    systemDownloadId = -1L,
                    fileName = fileName,
                    url = url,
                    mimeType = mimeType,
                    localUri = uriStr,
                    status = DownloadStatus.SUCCESSFUL,
                    totalBytes = sizeBytes,
                    downloadedBytes = sizeBytes,
                    saveFolderLabel = folderLabel
                )
            )
        }
    }

    init {
        configureGlobalCookieManager()
        ioScope.launch {
            repository.ensureStarterBookmarks()
            preferences.settingsFlow.collectLatest { latest ->
                currentSettings = latest
                PwaWebViewPool.setKeepAliveEnabled(latest.keepPwasAliveInRam, appContext)
                mainScope.launch {
                    applySettingsToAllWebViews(latest)
                }
            }
        }
        initializeDefaultFiveTabs()
        refreshGoogleSignInStatus()
    }

    private fun configureGlobalCookieManager() {
        ioScope.launch {
            try {
                val cookieManager = CookieManager.getInstance()
                cookieManager.setAcceptCookie(true)
                cookieManager.flush()
            } catch (_: Exception) {
            }
        }
    }

    fun refreshGoogleSignInStatus() {
        ioScope.launch {
            try {
                val cookieManager = CookieManager.getInstance()
                val accountsCookies = cookieManager.getCookie("https://accounts.google.com").orEmpty()
                val googleCookies = cookieManager.getCookie("https://www.google.com").orEmpty()
                val combined = "$accountsCookies;$googleCookies"
                val signedIn = combined.contains("SID=") ||
                    combined.contains("HSID=") ||
                    combined.contains("SAPISID=") ||
                    combined.contains("__Secure-1PSID=")
                _isGoogleSignedIn.value = signedIn
            } catch (_: Exception) {
                _isGoogleSignedIn.value = false
            }
        }
    }

    fun initializeDefaultFiveTabs() {
        if (webViews.isNotEmpty()) return
        val initialTabs = mutableListOf<BrowserTabModel>()
        for (i in 1..DEFAULT_TAB_COUNT) {
            val tabId = nextTabId++
            val slotTitle = "Studio $i"
            val tabModel = BrowserTabModel(
                id = tabId,
                slotTitle = slotTitle,
                pageTitle = "$slotTitle • AI Studio",
                url = DEFAULT_HOME_URL
            )
            initialTabs.add(tabModel)
            tabProgressMap[tabId] = 0
            tabLoadingMap[tabId] = true
        }
        _tabsState.value = initialTabs
        _activeTabId.value = initialTabs.first().id

        initialTabs.forEachIndexed { index, tab ->
            val webView = createConfiguredWebView(
                tabId = tab.id,
                isDesktop = tab.isDesktopMode,
                isIncognito = tab.isIncognito
            )
            webViews[tab.id] = webView
            persistentContainer.addView(
                webView,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            )
            if (index == 0) {
                tabInitialUrlLoaded[tab.id] = true
                webView.loadUrl(tab.url)
            } else {
                // Stagger background tab loads so Tab 1 SurfaceSyncGroup completes cleanly before background SPAs hydrate
                mainScope.launch {
                    delay(index * 700L)
                    if (webViews[tab.id] === webView && tabInitialUrlLoaded[tab.id] != true) {
                        tabInitialUrlLoaded[tab.id] = true
                        webView.loadUrl(tab.url)
                    }
                }
            }
        }

        applyZeroReloadVisibilityStack(_activeTabId.value)
    }

    fun attachActivity(activity: Activity) {
        currentActivity = activity
        contextWrappers.values.forEach { wrapper ->
            wrapper.baseContext = activity
        }
        webViews.values.forEach { webView ->
            webView.onResume()
            webView.resumeTimers()
        }
        refreshGoogleSignInStatus()
    }

    fun detachActivity(activity: Activity) {
        if (currentActivity === activity) {
            currentActivity = null
            contextWrappers.values.forEach { wrapper ->
                wrapper.baseContext = appContext
            }
        }
        flushCookiesNow()
    }

    fun selectTab(tabId: Int) {
        val targetWebView = webViews[tabId] ?: return
        _activeTabId.value = tabId
        _activeTabProgress.value = tabProgressMap[tabId] ?: 0
        _activeTabIsLoading.value = tabLoadingMap[tabId] ?: false
        if (tabInitialUrlLoaded[tabId] != true) {
            val pendingUrl = _tabsState.value.find { it.id == tabId }?.url
            if (!pendingUrl.isNullOrBlank() && pendingUrl != NEW_TAB_URL) {
                tabInitialUrlLoaded[tabId] = true
                targetWebView.loadUrl(pendingUrl)
            }
        }
        clearFindInPage()
        applyZeroReloadVisibilityStack(tabId)
    }

    fun switchTabByDelta(delta: Int) {
        val list = _tabsState.value
        if (list.size <= 1) return
        val currentIdx = list.indexOfFirst { it.id == _activeTabId.value }
        if (currentIdx == -1) return
        val targetIdx = (currentIdx + delta).coerceIn(0, list.lastIndex)
        if (targetIdx != currentIdx) {
            selectTab(list[targetIdx].id)
        }
    }

    private fun applyZeroReloadVisibilityStack(activeId: Int) {
        val topChildIndex = persistentContainer.childCount - 1
        val topChild = if (topChildIndex >= 0) persistentContainer.getChildAt(topChildIndex) else null

        webViews.forEach { (id, webView) ->
            if (webView.visibility != View.VISIBLE) {
                webView.visibility = View.VISIBLE
            }
            if (webView.layerType != View.LAYER_TYPE_NONE) {
                webView.setLayerType(View.LAYER_TYPE_NONE, null)
            }
            val isActive = (id == activeId)
            if (isActive) {
                if (webView.alpha != 1.0f) webView.alpha = 1.0f
                if (webView.translationX != 0f) webView.translationX = 0f
                if (webView.translationZ != 10f) webView.translationZ = 10f
                webView.isFocusable = true
                webView.isFocusableInTouchMode = true
                if (topChild !== webView) {
                    webView.bringToFront()
                }
                webView.requestFocus()
                if (tabInitialUrlLoaded[id] == true) {
                    injectAntiThrottleJavaScript(webView, isActiveTab = true)
                }
            } else {
                val wasVisible = webView.alpha > 0f
                // alpha = 0f skips HWUI RenderThread layer syncing for offscreen WebViews while keeping View.VISIBLE
                if (webView.alpha != 0f) webView.alpha = 0f
                if (webView.translationX != 10_000f) webView.translationX = 10_000f
                if (webView.translationZ != 0f) webView.translationZ = 0f
                if (wasVisible && tabInitialUrlLoaded[id] == true) {
                    try {
                        webView.evaluateJavascript(PAUSE_VIDEO_ONLY_JS, null)
                    } catch (_: Exception) {
                    }
                }
            }
        }
    }

    fun openNewTab(
        initialUrl: String = NEW_TAB_URL,
        isIncognito: Boolean = false
    ): Boolean {
        val currentList = _tabsState.value
        if (currentList.size >= MAX_TAB_COUNT) {
            Toast.makeText(
                currentActivity ?: appContext,
                "Maximum $MAX_TAB_COUNT open tabs reached",
                Toast.LENGTH_SHORT
            ).show()
            return false
        }
        val tabId = nextTabId++
        val label = if (isIncognito) "Incognito" else "Tab $tabId"
        val title = if (initialUrl == NEW_TAB_URL) {
            if (isIncognito) "Incognito Tab" else "New Tab"
        } else {
            label
        }

        val newTab = BrowserTabModel(
            id = tabId,
            slotTitle = label,
            pageTitle = title,
            url = initialUrl,
            isIncognito = isIncognito
        )
        tabProgressMap[tabId] = 0
        tabLoadingMap[tabId] = initialUrl != NEW_TAB_URL

        val webView = createConfiguredWebView(
            tabId = tabId,
            isDesktop = false,
            isIncognito = isIncognito
        )
        webViews[tabId] = webView
        persistentContainer.addView(
            webView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        _tabsState.update { it + newTab }
        selectTab(tabId)
        if (initialUrl != NEW_TAB_URL && tabInitialUrlLoaded[tabId] != true) {
            tabInitialUrlLoaded[tabId] = true
            webView.loadUrl(initialUrl)
        }
        BrowserService.startKeepAliveService(appContext, _tabsState.value.size)
        return true
    }

    fun addNewStudioTab(): Boolean = openNewTab(initialUrl = DEFAULT_HOME_URL, isIncognito = false)

    /**
     * Reuses an already-open live tab matching the target URL (zero reload) when launched from
     * a Home Screen Website Shortcut; opens a new tab only if not already loaded.
     */
    fun focusOrOpenTab(rawUrl: String) {
        val target = normalizeUrlOrSearchQuery(rawUrl).trimEnd('/')
        val existing = _tabsState.value.find { tab ->
            !tab.isIncognito && tab.url.trimEnd('/').equals(target, ignoreCase = true)
        }
        if (existing != null) {
            selectTab(existing.id)
            return
        }
        val opened = openNewTab(initialUrl = normalizeUrlOrSearchQuery(rawUrl), isIncognito = false)
        if (!opened) {
            loadUrlInActiveTab(rawUrl)
        }
    }

    fun closeTab(tabId: Int) {
        val currentList = _tabsState.value
        if (currentList.size <= 1) {
            // Reset last remaining tab to New Tab Start Page instead of leaving zero tabs
            loadUrlInTab(tabId, NEW_TAB_URL)
            return
        }

        val closingIndex = currentList.indexOfFirst { it.id == tabId }
        if (closingIndex == -1) return

        val removedWebView = webViews.remove(tabId)
        contextWrappers.remove(tabId)
        tabProgressMap.remove(tabId)
        tabLoadingMap.remove(tabId)
        tabInitialUrlLoaded.remove(tabId)
        tabUserMediaUnlocked.remove(tabId)

        if (removedWebView != null) {
            try {
                removedWebView.allowExplicitDestroy = true
                persistentContainer.removeView(removedWebView)
                removedWebView.stopLoading()
                removedWebView.destroy()
            } catch (_: Exception) {
            }
        }

        val updatedList = currentList.filterNot { it.id == tabId }
        _tabsState.value = updatedList

        if (_activeTabId.value == tabId) {
            val nextTab = updatedList.getOrNull(closingIndex) ?: updatedList.last()
            selectTab(nextTab.id)
        }
        BrowserService.startKeepAliveService(appContext, updatedList.size)
    }

    fun resetToDefaultFiveTabs() {
        closeOAuthPopup()
        webViews.values.forEach { webView ->
            try {
                webView.allowExplicitDestroy = true
                persistentContainer.removeView(webView)
                webView.stopLoading()
                webView.destroy()
            } catch (_: Exception) {
            }
        }
        webViews.clear()
        contextWrappers.clear()
        tabProgressMap.clear()
        tabLoadingMap.clear()
        tabInitialUrlLoaded.clear()
        tabUserMediaUnlocked.clear()
        nextTabId = 1
        initializeDefaultFiveTabs()
        BrowserService.startKeepAliveService(appContext, _tabsState.value.size)
        Toast.makeText(
            currentActivity ?: appContext,
            "Restored 5 Google AI Studio tabs",
            Toast.LENGTH_SHORT
        ).show()
    }

    fun loadUrlInActiveTab(rawInput: String) {
        loadUrlInTab(_activeTabId.value, rawInput)
    }

    fun loadUrlInTab(tabId: Int, rawInput: String) {
        val webView = webViews[tabId] ?: return
        tabInitialUrlLoaded[tabId] = true
        val trimmed = rawInput.trim()
        if (trimmed == NEW_TAB_URL) {
            webView.stopLoading()
            updateTabLoadingProgress(tabId, 100, isLoading = false)
            updateTabModel(tabId) {
                it.copy(
                    url = NEW_TAB_URL,
                    pageTitle = if (it.isIncognito) "Incognito Tab" else "New Tab",
                    isSslSecure = true
                )
            }
            return
        }
        val formattedUrl = normalizeUrlOrSearchQuery(trimmed)
        updateTabModel(tabId) {
            it.copy(
                url = formattedUrl,
                isSslSecure = formattedUrl.startsWith("https://")
            )
        }
        webView.loadUrl(formattedUrl)
    }

    fun normalizeUrlOrSearchQuery(input: String): String {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) return currentSettings.homepageMode.homeUrl
        if (trimmed == NEW_TAB_URL || trimmed.startsWith("about:")) return trimmed
        if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) {
            return trimmed
        }
        val looksLikeDomain = trimmed.contains(".") && !trimmed.contains(" ")
        return if (looksLikeDomain) {
            "https://$trimmed"
        } else {
            currentSettings.searchEngine.buildSearchUrl(trimmed)
        }
    }

    fun reloadOrStopActiveTab() {
        val activeId = _activeTabId.value
        val activeTab = _tabsState.value.find { it.id == activeId } ?: return
        if (activeTab.url == NEW_TAB_URL) return
        val webView = webViews[activeId] ?: return
        val isLoading = tabLoadingMap[activeId] == true
        if (isLoading) {
            webView.stopLoading()
            updateTabLoadingProgress(activeId, 100, isLoading = false)
        } else {
            webView.reload()
        }
    }

    fun goBackInActiveTab(): Boolean {
        val activeId = _activeTabId.value
        val activeTab = _tabsState.value.find { it.id == activeId } ?: return false
        if (activeTab.url == NEW_TAB_URL) return false
        val webView = webViews[activeId] ?: return false
        return if (webView.canGoBack()) {
            webView.goBack()
            true
        } else {
            false
        }
    }

    fun goForwardInActiveTab(): Boolean {
        val activeId = _activeTabId.value
        val webView = webViews[activeId] ?: return false
        return if (webView.canGoForward()) {
            webView.goForward()
            true
        } else {
            false
        }
    }

    fun goHomeInActiveTab() {
        loadUrlInActiveTab(currentSettings.homepageMode.homeUrl)
    }

    fun openGoogleSignIn() {
        loadUrlInActiveTab("https://accounts.google.com/ServiceLogin?continue=https://aistudio.google.com/")
    }

    fun openGoogleAccountManager() {
        loadUrlInActiveTab("https://myaccount.google.com/")
    }

    fun signOutGoogleAccounts() {
        loadUrlInActiveTab("https://accounts.google.com/Logout")
    }

    fun toggleDesktopModeForActiveTab() {
        val activeId = _activeTabId.value
        val webView = webViews[activeId] ?: return
        val currentTab = _tabsState.value.find { it.id == activeId } ?: return
        val newDesktopState = !currentTab.isDesktopMode

        applySanitizedUserAgent(webView.settings, newDesktopState)
        webView.settings.useWideViewPort = true
        webView.settings.loadWithOverviewMode = true

        updateTabModel(activeId) { it.copy(isDesktopMode = newDesktopState) }
        if (currentTab.url != NEW_TAB_URL) {
            webView.reload()
        }
    }

    // --- Downloads ---

    private fun currentDownloadDestination(): DownloadDestination {
        return DownloadDestination(
            preset = DownloadFolderPreset.fromId(currentSettings.downloadFolderPreset),
            customTreeUri = currentSettings.customDownloadTreeUri,
            customFolderLabel = currentSettings.customDownloadFolderLabel
        )
    }

    fun triggerDirectDownload(url: String, mimeType: String? = null) {
        val activeTab = _tabsState.value.find { it.id == _activeTabId.value }
        val ua = if (activeTab?.isDesktopMode == true) DESKTOP_CHROME_USER_AGENT else MOBILE_CHROME_USER_AGENT
        val guessedMime = mimeType ?: "application/octet-stream"
        val suggestedName = DownloadHelper.guessName(
            url = url,
            contentDisposition = null,
            mimeType = guessedMime,
            registeredBlobName = downloadBridge.getRegisteredBlobName(url)
        )
        val destination = currentDownloadDestination()
        val req = PendingDownloadRequest(
            url = url,
            userAgent = ua,
            contentDisposition = "",
            mimeType = guessedMime,
            contentLength = -1L,
            suggestedFileName = suggestedName,
            defaultDestination = destination
        )
        if (currentSettings.askBeforeDownload) {
            _pendingDownload.value = req
        } else {
            executeDownloadRequest(req, suggestedName, destination)
        }
    }

    fun confirmPendingDownload(
        customFileName: String,
        destination: DownloadDestination = currentDownloadDestination()
    ) {
        val req = _pendingDownload.value ?: return
        _pendingDownload.value = null
        ioScope.launch {
            preferences.setDownloadDestination(
                preset = destination.preset.name,
                customTreeUri = destination.customTreeUri,
                customFolderLabel = destination.customFolderLabel
            )
        }
        executeDownloadRequest(
            req = req,
            finalFileName = customFileName.ifBlank { req.suggestedFileName },
            destination = destination
        )
    }

    fun dismissPendingDownload() {
        _pendingDownload.value = null
    }

    private fun executeDownloadRequest(
        req: PendingDownloadRequest,
        finalFileName: String,
        destination: DownloadDestination = currentDownloadDestination()
    ) {
        val url = req.url
        val folderLabel = destination.displayLabel()
        if (url.startsWith("blob:") || url.startsWith("data:")) {
            val activeWebView = webViews[_activeTabId.value]
            if (activeWebView != null) {
                val script = DownloadHelper.buildBlobOrDataExtractionScript(
                    blobOrDataUrl = url,
                    suggestedName = finalFileName,
                    mimeType = req.mimeType,
                    destination = destination
                )
                activeWebView.evaluateJavascript(script, null)
                Toast.makeText(
                    currentActivity ?: appContext,
                    "Saving $finalFileName to $folderLabel...",
                    Toast.LENGTH_SHORT
                ).show()
            }
            return
        }

        ioScope.launch {
            try {
                DownloadHelper.enqueueDownloadWithDestination(
                    context = appContext,
                    repository = repository,
                    url = url,
                    fileName = finalFileName,
                    mimeType = req.mimeType,
                    userAgent = req.userAgent,
                    destination = destination
                )
                mainScope.launch {
                    Toast.makeText(
                        currentActivity ?: appContext,
                        "Downloading $finalFileName to $folderLabel...",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            } catch (_: Exception) {
                mainScope.launch {
                    try {
                        val external = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        (currentActivity ?: appContext).startActivity(external)
                    } catch (_: Exception) {
                    }
                }
            }
        }
    }

    // --- Find in Page ---

    fun showFindInPage() {
        _findInPageState.update { it.copy(isVisible = true) }
    }

    fun updateFindQuery(query: String) {
        _findInPageState.update { it.copy(query = query) }
        val webView = webViews[_activeTabId.value] ?: return
        if (query.isBlank()) {
            webView.clearMatches()
            _findInPageState.update { it.copy(activeMatchIndex = 0, totalMatches = 0) }
        } else {
            webView.findAllAsync(query)
        }
    }

    fun findNextMatch(forward: Boolean) {
        webViews[_activeTabId.value]?.findNext(forward)
    }

    fun clearFindInPage() {
        webViews[_activeTabId.value]?.clearMatches()
        _findInPageState.value = FindInPageState()
    }

    // --- Print / Save as PDF ---

    fun printActivePage() {
        val activity = currentActivity ?: return
        val activeId = _activeTabId.value
        val activeTab = _tabsState.value.find { it.id == activeId } ?: return
        if (activeTab.url == NEW_TAB_URL) {
            Toast.makeText(activity, "Open a webpage first to print or save as PDF", Toast.LENGTH_SHORT).show()
            return
        }
        val webView = webViews[activeId] ?: return
        try {
            val printManager = activity.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return
            val jobName = "${activeTab.pageTitle.take(40)} - Flowra"
            val adapter = webView.createPrintDocumentAdapter(jobName)
            printManager.print(jobName, adapter, PrintAttributes.Builder().build())
        } catch (_: Exception) {
            Toast.makeText(activity, "Unable to open Print/PDF dialog", Toast.LENGTH_SHORT).show()
        }
    }

    // --- Context Menu ---

    fun dismissContextMenu() {
        _contextMenuTarget.value = null
    }

    // --- Thumbnails for Chrome Tab Grid Switcher ---

    fun captureTabThumbnails() {
        val activeId = _activeTabId.value
        val activeWebView = webViews[activeId] ?: return
        val activeTab = _tabsState.value.find { it.id == activeId } ?: return
        if (activeTab.url == NEW_TAB_URL || activeWebView.width <= 0 || activeWebView.height <= 0) return

        // Defer thumbnail draw past the Dialog's SurfaceSyncGroup window transition frame
        activeWebView.post {
            try {
                if (activeWebView.width <= 0 || activeWebView.height <= 0) return@post
                val targetW = (activeWebView.width / 4).coerceIn(140, 260)
                val targetH = (activeWebView.height / 4).coerceIn(180, 360)
                val bmp = Bitmap.createBitmap(targetW, targetH, Bitmap.Config.RGB_565)
                val canvas = Canvas(bmp)
                val scaleX = targetW.toFloat() / activeWebView.width.toFloat()
                val scaleY = targetH.toFloat() / activeWebView.height.toFloat()
                canvas.scale(scaleX, scaleY)
                activeWebView.draw(canvas)
                updateTabModel(activeId) { it.copy(thumbnail = bmp) }
            } catch (_: Exception) {
            }
        }
    }

    // --- Clearing Data ---

    fun clearCacheKeepLogin() {
        webViews.values.forEach { webView ->
            webView.clearCache(true)
            webView.clearFormData()
        }
        Toast.makeText(
            currentActivity ?: appContext,
            "Cleared WebView cache (logins preserved)",
            Toast.LENGTH_SHORT
        ).show()
    }

    fun clearAllCacheAndCookies() {
        try {
            val cookieManager = CookieManager.getInstance()
            cookieManager.removeAllCookies {
                cookieManager.flush()
                mainScope.launch { refreshGoogleSignInStatus() }
            }
            WebStorage.getInstance().deleteAllData()
            webViews.values.forEach { webView ->
                webView.clearCache(true)
                webView.clearHistory()
                webView.clearFormData()
                webView.reload()
            }
            Toast.makeText(
                currentActivity ?: appContext,
                "Cleared cache, cookies, and site storage",
                Toast.LENGTH_SHORT
            ).show()
        } catch (_: Exception) {
        }
    }

    fun clearBrowsingData(clearHistory: Boolean, clearCache: Boolean, clearCookies: Boolean) {
        if (clearHistory) {
            ioScope.launch { repository.clearHistory() }
            webViews.values.forEach { it.clearHistory() }
        }
        if (clearCache) {
            webViews.values.forEach {
                it.clearCache(true)
                it.clearFormData()
            }
        }
        if (clearCookies) {
            val cookieManager = CookieManager.getInstance()
            cookieManager.removeAllCookies {
                cookieManager.flush()
                mainScope.launch { refreshGoogleSignInStatus() }
            }
            WebStorage.getInstance().deleteAllData()
        }
        Toast.makeText(currentActivity ?: appContext, "Browsing data cleared", Toast.LENGTH_SHORT).show()
    }

    fun flushCookiesNow() {
        ioScope.launch {
            try {
                CookieManager.getInstance().flush()
                refreshGoogleSignInStatus()
            } catch (_: Exception) {
            }
        }
    }

    fun pulseBackgroundKeepAlive() {
        val activeId = _activeTabId.value
        val snapshot = webViews.entries.toList()
        mainScope.launch {
            snapshot.forEachIndexed { index, (tabId, webView) ->
                if (webViews[tabId] !== webView) return@forEachIndexed
                try {
                    if (webView.visibility != View.VISIBLE) {
                        webView.visibility = View.VISIBLE
                    }
                    webView.resumeTimers()
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        webView.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false)
                    }
                    // Stagger JS state check across frames so the 16.6ms 60fps UI budget stays untouched
                    if (tabId != activeId && tabInitialUrlLoaded[tabId] == true) {
                        webView.evaluateJavascript("window.__studioTabIsActive=false;", null)
                    }
                } catch (_: Exception) {
                }
                if (index < snapshot.lastIndex) {
                    delay(80L)
                }
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun applySettingsToAllWebViews(settings: BrowserSettings) {
        webViews.values.forEach { webView ->
            if (webView.settings.javaScriptEnabled != settings.javaScriptEnabled) {
                webView.settings.javaScriptEnabled = settings.javaScriptEnabled
            }
            if (webView.settings.textZoom != settings.textZoomPercent) {
                webView.settings.textZoom = settings.textZoomPercent
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                webView.settings.isAlgorithmicDarkeningAllowed = settings.darkWebPages
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    private fun createConfiguredWebView(
        tabId: Int,
        isDesktop: Boolean,
        isIncognito: Boolean
    ): UnthrottledWebView {
        val contextWrapper = MutableContextWrapper(currentActivity ?: appContext)
        contextWrappers[tabId] = contextWrapper

        val webView = UnthrottledWebView(contextWrapper).apply {
            setLayerType(View.LAYER_TYPE_NONE, null)
            isFocusable = true
            isFocusableInTouchMode = true
            keepScreenOn = true
            isNestedScrollingEnabled = true
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
            scrollBarStyle = View.SCROLLBARS_INSIDE_OVERLAY
            isVerticalScrollBarEnabled = true
            onUserTap = {
                if (tabId == _activeTabId.value) {
                    tabUserMediaUnlocked[tabId] = true
                    try {
                        evaluateJavascript("window.__studioUserMediaUnlocked = true;", null)
                    } catch (_: Exception) {
                    }
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false)
                importantForAutofill = if (isIncognito) {
                    View.IMPORTANT_FOR_AUTOFILL_NO
                } else {
                    View.IMPORTANT_FOR_AUTOFILL_YES
                }
            }
        }

        configureWebSettings(webView, isDesktop = isDesktop, isIncognito = isIncognito)
        webView.addJavascriptInterface(downloadBridge, "StudioDownloadBridge")
        attachDownloadListener(webView, tabId)

        webView.setFindListener { activeMatchOrdinal, numberOfMatches, _ ->
            _findInPageState.update {
                it.copy(
                    activeMatchIndex = if (numberOfMatches > 0) activeMatchOrdinal + 1 else 0,
                    totalMatches = numberOfMatches
                )
            }
        }

        webView.setOnLongClickListener { view ->
            val wv = view as? WebView ?: return@setOnLongClickListener false
            val hit = wv.hitTestResult
            val extra = hit.extra
            if (!extra.isNullOrBlank()) {
                when (hit.type) {
                    WebView.HitTestResult.SRC_ANCHOR_TYPE,
                    WebView.HitTestResult.EMAIL_TYPE -> {
                        _contextMenuTarget.value = WebContextMenuTarget(
                            linkUrl = extra,
                            title = extra
                        )
                        return@setOnLongClickListener true
                    }
                    WebView.HitTestResult.IMAGE_TYPE -> {
                        _contextMenuTarget.value = WebContextMenuTarget(
                            imageUrl = extra,
                            title = extra
                        )
                        return@setOnLongClickListener true
                    }
                    WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE -> {
                        _contextMenuTarget.value = WebContextMenuTarget(
                            linkUrl = extra,
                            imageUrl = extra,
                            title = extra
                        )
                        return@setOnLongClickListener true
                    }
                }
            }
            false
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? {
                val host = request.url?.host?.lowercase() ?: ""
                if (currentSettings.adBlockEnabled) {
                    if (AD_BLOCK_DOMAINS.any { host == it || host.endsWith(".$it") }) {
                        return WebResourceResponse(
                            "text/plain",
                            "UTF-8",
                            204,
                            "Blocked",
                            emptyMap(),
                            ByteArrayInputStream(ByteArray(0))
                        )
                    }
                }

                // Prevent Chromium from allocating scarce hardware MediaCodec video decoders
                // in background tabs or for unrequested autoplay/preload promo videos at startup.
                if (isVideoMediaRequest(request)) {
                    val isBackgroundTab = tabId != _activeTabId.value
                    val isUserUnlocked = tabUserMediaUnlocked[tabId] == true
                    val allowDedicatedActiveVideo = !isBackgroundTab && isDedicatedVideoHost(host)
                    if (isBackgroundTab || (!isUserUnlocked && !allowDedicatedActiveVideo)) {
                        return WebResourceResponse(
                            "text/plain",
                            "UTF-8",
                            204,
                            "Deferred Video",
                            emptyMap(),
                            ByteArrayInputStream(ByteArray(0))
                        )
                    }
                }
                return super.shouldInterceptRequest(view, request)
            }

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                val uri = request.url ?: return false
                val scheme = uri.scheme?.lowercase() ?: return false

                if (scheme == "http" || scheme == "https") {
                    return false
                }

                return try {
                    val externalIntent = Intent(Intent.ACTION_VIEW, uri).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    (currentActivity ?: appContext).startActivity(externalIntent)
                    true
                } catch (_: Exception) {
                    true
                }
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                val safeUrl = url ?: DEFAULT_HOME_URL
                tabInitialUrlLoaded[tabId] = true
                val host = try { Uri.parse(safeUrl).host?.lowercase().orEmpty() } catch (_: Exception) { "" }
                tabUserMediaUnlocked[tabId] = isDedicatedVideoHost(host) && tabId == _activeTabId.value
                updateTabLoadingProgress(tabId, 12, isLoading = true)
                updateTabModel(tabId) { current ->
                    current.copy(
                        url = safeUrl,
                        isSslSecure = safeUrl.startsWith("https://"),
                        canGoBack = view.canGoBack(),
                        canGoForward = view.canGoForward()
                    )
                }
                injectAntiThrottleJavaScript(view, isActiveTab = (tabId == _activeTabId.value))
            }

            override fun onPageCommitVisible(view: WebView, url: String?) {
                super.onPageCommitVisible(view, url)
                injectAntiThrottleJavaScript(view, isActiveTab = (tabId == _activeTabId.value))
            }

            override fun onPageFinished(view: WebView, url: String?) {
                super.onPageFinished(view, url)
                val safeUrl = url ?: view.url ?: DEFAULT_HOME_URL
                val resolvedTitle = view.title?.takeIf { it.isNotBlank() }
                updateTabLoadingProgress(tabId, 100, isLoading = false)
                updateTabModel(tabId) { current ->
                    current.copy(
                        url = safeUrl,
                        pageTitle = resolvedTitle ?: current.pageTitle,
                        isSslSecure = safeUrl.startsWith("https://"),
                        canGoBack = view.canGoBack(),
                        canGoForward = view.canGoForward()
                    )
                }
                if (!isIncognito && safeUrl.startsWith("http")) {
                    ioScope.launch {
                        repository.recordHistory(
                            title = resolvedTitle ?: safeUrl,
                            url = safeUrl
                        )
                    }
                }
                injectAntiThrottleJavaScript(view, isActiveTab = (tabId == _activeTabId.value))
                flushCookiesNow()
            }

            override fun doUpdateVisitedHistory(view: WebView, url: String?, isReload: Boolean) {
                super.doUpdateVisitedHistory(view, url, isReload)
                val safeUrl = url ?: view.url ?: return
                updateTabModel(tabId) { current ->
                    current.copy(
                        url = safeUrl,
                        isSslSecure = safeUrl.startsWith("https://"),
                        canGoBack = view.canGoBack(),
                        canGoForward = view.canGoForward()
                    )
                }
            }

            override fun onRenderProcessGone(
                view: WebView?,
                detail: RenderProcessGoneDetail?
            ): Boolean {
                recoverTabAfterRendererCrash(tabId, view)
                return true
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                super.onProgressChanged(view, newProgress)
                val isStillLoading = newProgress < 100
                updateTabLoadingProgress(tabId, newProgress, isStillLoading)
            }

            override fun onReceivedTitle(view: WebView, title: String?) {
                super.onReceivedTitle(view, title)
                if (!title.isNullOrBlank()) {
                    updateTabModel(tabId) { it.copy(pageTitle = title) }
                }
            }

            override fun onReceivedIcon(view: WebView, icon: Bitmap?) {
                super.onReceivedIcon(view, icon)
                if (icon != null) {
                    updateTabModel(tabId) { it.copy(favicon = icon) }
                }
            }

            override fun onCreateWindow(
                view: WebView,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: Message?
            ): Boolean {
                val transport = resultMsg?.obj as? WebView.WebViewTransport ?: return false
                val popupContext = MutableContextWrapper(currentActivity ?: appContext)
                val popupWebView = UnthrottledWebView(popupContext).apply {
                    setLayerType(View.LAYER_TYPE_NONE, null)
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }

                val parentDesktopMode = _tabsState.value.find { it.id == tabId }?.isDesktopMode == true
                configureWebSettings(popupWebView, isDesktop = parentDesktopMode, isIncognito = isIncognito)
                popupWebView.addJavascriptInterface(downloadBridge, "StudioDownloadBridge")

                popupWebView.webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(
                        popupView: WebView,
                        request: WebResourceRequest
                    ): Boolean {
                        val uri = request.url ?: return false
                        val scheme = uri.scheme?.lowercase() ?: return false
                        return !(scheme == "http" || scheme == "https")
                    }

                    override fun onPageStarted(popupView: WebView, url: String?, favicon: Bitmap?) {
                        super.onPageStarted(popupView, url, favicon)
                        _oauthPopupState.update { current ->
                            current?.copy(
                                url = url ?: current.url,
                                isLoading = true
                            )
                        }
                    }

                    override fun onPageFinished(popupView: WebView, url: String?) {
                        super.onPageFinished(popupView, url)
                        flushCookiesNow()
                        _oauthPopupState.update { current ->
                            current?.copy(
                                url = url ?: popupView.url ?: current.url,
                                title = popupView.title?.takeIf { it.isNotBlank() } ?: current.title,
                                isLoading = false,
                                progress = 100
                            )
                        }
                    }

                    override fun onRenderProcessGone(
                        view: WebView?,
                        detail: RenderProcessGoneDetail?
                    ): Boolean {
                        closeOAuthPopup()
                        return true
                    }
                }

                popupWebView.webChromeClient = object : WebChromeClient() {
                    override fun onProgressChanged(popupView: WebView, newProgress: Int) {
                        super.onProgressChanged(popupView, newProgress)
                        _oauthPopupState.update { current ->
                            current?.copy(
                                progress = newProgress,
                                isLoading = newProgress < 100
                            )
                        }
                    }

                    override fun onReceivedTitle(popupView: WebView, title: String?) {
                        super.onReceivedTitle(popupView, title)
                        if (!title.isNullOrBlank()) {
                            _oauthPopupState.update { current ->
                                current?.copy(title = title)
                            }
                        }
                    }

                    override fun onCloseWindow(window: WebView?) {
                        super.onCloseWindow(window)
                        flushCookiesNow()
                        closeOAuthPopup()
                        injectAntiThrottleJavaScript(view)
                    }

                    override fun onShowFileChooser(
                        webView: WebView,
                        filePathCallback: ValueCallback<Array<Uri>>,
                        fileChooserParams: FileChooserParams
                    ): Boolean {
                        return handleShowFileChooser(filePathCallback, fileChooserParams)
                    }

                    override fun onPermissionRequest(request: PermissionRequest?) {
                        if (request == null) return
                        handleWebPermissionRequest(request)
                    }

                    override fun onGeolocationPermissionsShowPrompt(
                        origin: String?,
                        callback: GeolocationPermissions.Callback?
                    ) {
                        DeviceAccessHelper.handleGeolocationPermissionRequest(
                            context = appContext,
                            origin = origin,
                            callback = callback,
                            onRequestRuntimePermissions = onRequestRuntimePermissions
                        )
                    }
                }

                _oauthPopupState.value = OAuthPopupSession(
                    parentTabId = tabId,
                    popupWebView = popupWebView
                )

                transport.webView = popupWebView
                resultMsg.sendToTarget()
                return true
            }

            override fun onCloseWindow(window: WebView?) {
                super.onCloseWindow(window)
                flushCookiesNow()
                closeOAuthPopup()
            }

            override fun onShowFileChooser(
                webView: WebView,
                filePathCallback: ValueCallback<Array<Uri>>,
                fileChooserParams: FileChooserParams
            ): Boolean {
                return handleShowFileChooser(filePathCallback, fileChooserParams)
            }

            override fun onPermissionRequest(request: PermissionRequest?) {
                if (request == null) return
                handleWebPermissionRequest(request)
            }

            override fun onGeolocationPermissionsShowPrompt(
                origin: String?,
                callback: GeolocationPermissions.Callback?
            ) {
                DeviceAccessHelper.handleGeolocationPermissionRequest(
                    context = appContext,
                    origin = origin,
                    callback = callback,
                    onRequestRuntimePermissions = onRequestRuntimePermissions
                )
            }
        }

        return webView
    }

    private fun recoverTabAfterRendererCrash(tabId: Int, crashedView: WebView?) {
        val tabModel = _tabsState.value.find { it.id == tabId } ?: return
        try {
            (crashedView as? UnthrottledWebView)?.allowExplicitDestroy = true
            if (crashedView != null) {
                persistentContainer.removeView(crashedView)
                crashedView.destroy()
            }
        } catch (_: Exception) {
        }
        val replacement = createConfiguredWebView(
            tabId = tabId,
            isDesktop = tabModel.isDesktopMode,
            isIncognito = tabModel.isIncognito
        )
        webViews[tabId] = replacement
        persistentContainer.addView(
            replacement,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        applyZeroReloadVisibilityStack(_activeTabId.value)
        if (tabModel.url.isNotBlank() && tabModel.url != NEW_TAB_URL) {
            tabInitialUrlLoaded[tabId] = true
            replacement.loadUrl(tabModel.url)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebSettings(
        webView: WebView,
        isDesktop: Boolean,
        isIncognito: Boolean
    ) {
        val cookieManager = CookieManager.getInstance()
        cookieManager.setAcceptCookie(true)
        cookieManager.setAcceptThirdPartyCookies(webView, true)

        webView.settings.apply {
            javaScriptEnabled = currentSettings.javaScriptEnabled
            domStorageEnabled = true
            databaseEnabled = true
            javaScriptCanOpenWindowsAutomatically = true
            setSupportMultipleWindows(true)

            allowFileAccess = true
            allowContentAccess = true
            setGeolocationEnabled(true)
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            cacheMode = if (isIncognito) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
            textZoom = currentSettings.textZoomPercent

            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            mediaPlaybackRequiresUserGesture = true

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                safeBrowsingEnabled = false
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                isAlgorithmicDarkeningAllowed = currentSettings.darkWebPages
            }
            try {
                if (WebViewFeature.isFeatureSupported(WebViewFeature.OFF_SCREEN_PRERASTER)) {
                    WebSettingsCompat.setOffscreenPreRaster(this, true)
                }
            } catch (_: Exception) {
            }

            applySanitizedUserAgent(this, isDesktop)
        }
    }

    private fun applySanitizedUserAgent(settings: WebSettings, isDesktop: Boolean) {
        settings.userAgentString = if (isDesktop) {
            DESKTOP_CHROME_USER_AGENT
        } else {
            MOBILE_CHROME_USER_AGENT
        }
    }

    private fun injectAntiThrottleJavaScript(webView: WebView, isActiveTab: Boolean = true) {
        try {
            val stateJs = "window.__studioTabIsActive = $isActiveTab;"
            webView.evaluateJavascript("$stateJs\n$PAGE_VISIBILITY_OVERRIDE_JS", null)
        } catch (_: Exception) {
        }
    }

    private fun isDedicatedVideoHost(host: String): Boolean {
        return DEDICATED_VIDEO_HOSTS.any { host == it || host.endsWith(".$it") }
    }

    private fun isVideoMediaRequest(request: WebResourceRequest): Boolean {
        val headers = request.requestHeaders
        val fetchDest = headers?.get("Sec-Fetch-Dest") ?: headers?.get("sec-fetch-dest")
        if (fetchDest.equals("video", ignoreCase = true)) return true

        val accept = headers?.get("Accept") ?: headers?.get("accept") ?: ""
        if (accept.startsWith("video/", ignoreCase = true)) return true

        val path = request.url?.path?.lowercase() ?: ""
        return VIDEO_EXTENSIONS.any { ext -> path.endsWith(ext) }
    }

    private fun handleShowFileChooser(
        callback: ValueCallback<Array<Uri>>,
        fileChooserParams: WebChromeClient.FileChooserParams
    ): Boolean {
        filePathCallback?.onReceiveValue(null)
        filePathCallback = callback

        val launcher = onLaunchFileChooser
        if (launcher == null) {
            filePathCallback?.onReceiveValue(null)
            filePathCallback = null
            return false
        }

        val launchNow = {
            val session = DeviceAccessHelper.createChromeFileChooserSession(
                context = currentActivity ?: appContext,
                fileChooserParams = fileChooserParams
            )
            activeFileChooserSession = session
            val launched = launcher.invoke(session.chooserIntent)
            if (!launched) {
                activeFileChooserSession = null
                filePathCallback?.onReceiveValue(null)
                filePathCallback = null
            }
        }

        val missingCapturePerms = DeviceAccessHelper.getMissingCapturePermissions(appContext)
        val permRequester = onRequestRuntimePermissions
        if (missingCapturePerms.isNotEmpty() && permRequester != null) {
            permRequester(missingCapturePerms) { _ ->
                launchNow()
            }
        } else {
            launchNow()
        }
        return true
    }

    fun onFileChooserResult(resultCode: Int, data: Intent?) {
        val callback = filePathCallback ?: return
        val session = activeFileChooserSession
        filePathCallback = null
        activeFileChooserSession = null

        val uris = DeviceAccessHelper.resolveFileChooserResult(
            context = currentActivity ?: appContext,
            resultCode = resultCode,
            data = data,
            session = session
        )
        callback.onReceiveValue(uris)
    }

    private fun handleWebPermissionRequest(request: PermissionRequest) {
        DeviceAccessHelper.handleWebPermissionRequest(
            context = appContext,
            request = request,
            onRequestRuntimePermissions = onRequestRuntimePermissions
        )
    }

    private fun attachDownloadListener(webView: WebView, tabId: Int) {
        webView.setDownloadListener(
            DownloadListener { url, userAgent, contentDisposition, mimeType, contentLength ->
                if (url.isNullOrBlank()) return@DownloadListener
                val safeMime = mimeType ?: "application/octet-stream"
                val suggestedName = DownloadHelper.guessName(
                    url = url,
                    contentDisposition = contentDisposition,
                    mimeType = safeMime,
                    registeredBlobName = downloadBridge.getRegisteredBlobName(url)
                )
                val destination = currentDownloadDestination()
                val req = PendingDownloadRequest(
                    url = url,
                    userAgent = userAgent ?: MOBILE_CHROME_USER_AGENT,
                    contentDisposition = contentDisposition ?: "",
                    mimeType = safeMime,
                    contentLength = contentLength,
                    suggestedFileName = suggestedName,
                    defaultDestination = destination
                )
                if (currentSettings.askBeforeDownload && tabId == _activeTabId.value) {
                    _pendingDownload.value = req
                } else {
                    executeDownloadRequest(req, suggestedName, destination)
                }
            }
        )
    }

    fun closeOAuthPopup() {
        val session = _oauthPopupState.value ?: return
        _oauthPopupState.value = null
        try {
            val popupView = session.popupWebView
            (popupView.parent as? ViewGroup)?.removeView(popupView)
            if (popupView is UnthrottledWebView) {
                popupView.allowExplicitDestroy = true
            }
            popupView.stopLoading()
            popupView.destroy()
        } catch (_: Exception) {
        }
        flushCookiesNow()
    }

    private fun updateTabLoadingProgress(tabId: Int, progress: Int, isLoading: Boolean) {
        tabProgressMap[tabId] = progress.coerceIn(0, 100)
        tabLoadingMap[tabId] = isLoading
        if (_activeTabId.value == tabId) {
            _activeTabProgress.value = progress.coerceIn(0, 100)
            _activeTabIsLoading.value = isLoading
        }
    }

    private inline fun updateTabModel(
        tabId: Int,
        crossinline transform: (BrowserTabModel) -> BrowserTabModel
    ) {
        _tabsState.update { currentList ->
            currentList.map { tab ->
                if (tab.id == tabId) transform(tab) else tab
            }
        }
    }

    companion object {
        const val DEFAULT_HOME_URL = "https://aistudio.google.com/"
        const val NEW_TAB_URL = "about:newtab"
        const val DEFAULT_TAB_COUNT = 5
        const val MAX_TAB_COUNT = 12

        const val MOBILE_CHROME_USER_AGENT =
            "Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"

        const val DESKTOP_CHROME_USER_AGENT =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"

        private val AD_BLOCK_DOMAINS = setOf(
            "doubleclick.net",
            "googlesyndication.com",
            "googleadservices.com",
            "adservice.google.com",
            "ads.pubmatic.com",
            "adnxs.com",
            "taboola.com",
            "outbrain.com",
            "criteo.com",
            "scorecardresearch.com"
        )

        private val VIDEO_EXTENSIONS = listOf(
            ".mp4", ".webm", ".m4v", ".mov", ".ogv", ".3gp", ".mkv", ".m3u8", ".mpd"
        )

        private val DEDICATED_VIDEO_HOSTS = setOf(
            "youtube.com",
            "m.youtube.com",
            "googlevideo.com",
            "vimeo.com",
            "twitch.tv",
            "dailymotion.com"
        )

        private val PAUSE_VIDEO_ONLY_JS = """
            (function() {
                try {
                    window.__studioTabIsActive = false;
                    var videos = document.getElementsByTagName('video');
                    for (var i = 0; i < videos.length; i++) {
                        try {
                            videos[i].autoplay = false;
                            videos[i].preload = 'none';
                            if (!videos[i].paused) videos[i].pause();
                        } catch (e1) {}
                    }
                } catch (e) {}
            })();
        """.trimIndent()

        internal val PAGE_VISIBILITY_OVERRIDE_JS = """
            (function() {
                try {
                    if (!window.__studioBrowserAntiThrottleInstalled) {
                        window.__studioBrowserAntiThrottleInstalled = true;
                        Object.defineProperty(document, 'visibilityState', {
                            get: () => 'visible',
                            configurable: true
                        });
                        Object.defineProperty(document, 'webkitVisibilityState', {
                            get: () => 'visible',
                            configurable: true
                        });
                        Object.defineProperty(document, 'hidden', {
                            get: () => false,
                            configurable: true
                        });
                        Object.defineProperty(document, 'webkitHidden', {
                            get: () => false,
                            configurable: true
                        });
                        try {
                            Object.defineProperty(navigator, 'webdriver', {
                                get: () => false,
                                configurable: true
                            });
                        } catch (e2) {}

                        function sanitizeVideoElement(v) {
                            if (!v || v.tagName !== 'VIDEO') return;
                            var isBackground = (window.__studioTabIsActive === false);
                            var isAutoMutedPromo = (v.autoplay || v.hasAttribute('autoplay')) && !window.__studioUserMediaUnlocked;
                            if (isBackground || isAutoMutedPromo) {
                                try {
                                    v.autoplay = false;
                                    v.removeAttribute('autoplay');
                                    v.preload = 'none';
                                    if (!v.paused) v.pause();
                                } catch (e3) {}
                            }
                        }

                        window.addEventListener('visibilitychange', function(e) {
                            if (document.visibilityState !== 'visible') {
                                e.stopImmediatePropagation();
                            }
                        }, true);
                        window.addEventListener('webkitvisibilitychange', function(e) {
                            e.stopImmediatePropagation();
                        }, true);
                        window.addEventListener('loadstart', function(e) {
                            if (e && e.target && e.target.tagName === 'VIDEO') {
                                sanitizeVideoElement(e.target);
                            }
                        }, true);

                        var origPlay = HTMLMediaElement.prototype.play;
                        HTMLMediaElement.prototype.play = function() {
                            if (this && this.tagName === 'VIDEO') {
                                if (window.__studioTabIsActive === false) {
                                    return Promise.resolve();
                                }
                                if (!window.__studioUserMediaUnlocked && this.muted) {
                                    this.preload = 'none';
                                    return Promise.resolve();
                                }
                            }
                            return origPlay.apply(this, arguments);
                        };

                        // Preserve Blob URLs for 3 minutes so URL.revokeObjectURL() called immediately
                        // after a.click() never invalidates a Blob before the user confirms the download dialog.
                        window.__flowraBlobStore = window.__flowraBlobStore || {};
                        if (window.URL && window.URL.createObjectURL) {
                            var origCreateObjUrl = window.URL.createObjectURL.bind(window.URL);
                            var origRevokeObjUrl = window.URL.revokeObjectURL ? window.URL.revokeObjectURL.bind(window.URL) : null;
                            window.URL.createObjectURL = function(obj) {
                                var generatedUrl = origCreateObjUrl(obj);
                                try {
                                    if (obj instanceof Blob) {
                                        window.__flowraBlobStore[generatedUrl] = obj;
                                        setTimeout(function() {
                                            delete window.__flowraBlobStore[generatedUrl];
                                        }, 180000);
                                    }
                                } catch (eBlob) {}
                                return generatedUrl;
                            };
                            if (origRevokeObjUrl) {
                                window.URL.revokeObjectURL = function(url) {
                                    setTimeout(function() {
                                        try {
                                            delete window.__flowraBlobStore[url];
                                            origRevokeObjUrl(url);
                                        } catch (eRev) {}
                                    }, 180000);
                                };
                            }
                        }

                        window.addEventListener('click', function(e) {
                            try {
                                var el = e.target;
                                while (el && el.tagName !== 'A') {
                                    el = el.parentElement;
                                }
                                if (el && el.href && el.href.indexOf('blob:') === 0) {
                                    var dlName = el.getAttribute('download');
                                    if (dlName && window.StudioDownloadBridge && window.StudioDownloadBridge.registerBlobSuggestedName) {
                                        window.StudioDownloadBridge.registerBlobSuggestedName(el.href, dlName);
                                    }
                                }
                            } catch (eClick) {}
                        }, true);
                    }
                    var existingVideos = document.getElementsByTagName('video');
                    for (var i = 0; i < existingVideos.length; i++) {
                        var v = existingVideos[i];
                        if (window.__studioTabIsActive === false || ((v.autoplay || v.hasAttribute('autoplay')) && !window.__studioUserMediaUnlocked)) {
                            try {
                                v.autoplay = false;
                                v.preload = 'none';
                                if (!v.paused) v.pause();
                            } catch (e4) {}
                        }
                    }
                } catch (e) {}
            })();
        """.trimIndent()

        @Volatile
        private var INSTANCE: WebViewManager? = null

        fun getInstance(context: Context): WebViewManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: WebViewManager(context.applicationContext).also { INSTANCE = it }
            }
        }

        fun getInstanceIfCreated(): WebViewManager? = INSTANCE
    }
}

class BrowserViewModel(val webViewManager: WebViewManager) : ViewModel() {

    private val repo = webViewManager.repository
    private val prefs = webViewManager.preferences

    val settings: StateFlow<BrowserSettings> = prefs.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), BrowserSettings())

    val bookmarks: StateFlow<List<BookmarkEntity>> = repo.allBookmarks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val speedDialBookmarks: StateFlow<List<BookmarkEntity>> = repo.speedDialBookmarks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val history: StateFlow<List<HistoryEntity>> = repo.allHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val downloads: StateFlow<List<DownloadEntity>> = repo.allDownloads
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val installedWebApps: StateFlow<List<InstalledWebAppEntity>> = repo.allWebApps
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val isActiveTabBookmarked: StateFlow<Boolean> = combine(
        webViewManager.tabsState,
        webViewManager.activeTabId,
        bookmarks
    ) { tabs, activeId, allBookmarks ->
        val activeUrl = tabs.find { it.id == activeId }?.url ?: ""
        allBookmarks.any { it.url == activeUrl }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    init {
        // Sync DownloadManager progress ONLY when at least one download is active (zero idle polling)
        viewModelScope.launch(Dispatchers.IO) {
            downloads
                .map { list ->
                    list.any {
                        it.status == DownloadStatus.RUNNING ||
                            it.status == DownloadStatus.PENDING ||
                            it.status == DownloadStatus.PAUSED
                    }
                }
                .distinctUntilChanged()
                .collectLatest { hasActiveDownloads ->
                    while (hasActiveDownloads && isActive) {
                        try {
                            DownloadHelper.syncActiveDownloads(
                                context = webViewManager.persistentContainer.context,
                                repository = repo
                            )
                        } catch (_: Exception) {
                        }
                        delay(1500L)
                    }
                }
        }
    }

    fun toggleBookmarkForActiveTab() {
        val activeId = webViewManager.activeTabId.value
        val activeTab = webViewManager.tabsState.value.find { it.id == activeId } ?: return
        if (activeTab.url == WebViewManager.NEW_TAB_URL) return
        viewModelScope.launch(Dispatchers.IO) {
            repo.toggleBookmark(activeTab.pageTitle, activeTab.url)
        }
    }

    fun addBookmark(title: String, url: String, isSpeedDial: Boolean = false) {
        viewModelScope.launch(Dispatchers.IO) {
            repo.addOrUpdateBookmark(
                BookmarkEntity(
                    title = title.ifBlank { url },
                    url = webViewManager.normalizeUrlOrSearchQuery(url),
                    isSpeedDial = isSpeedDial
                )
            )
        }
    }

    fun updateBookmark(id: Long, title: String, url: String, isSpeedDial: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            repo.updateBookmarkFields(
                id = id,
                title = title,
                url = webViewManager.normalizeUrlOrSearchQuery(url),
                isSpeedDial = isSpeedDial
            )
        }
    }

    fun toggleBookmarkSpeedDial(bookmark: BookmarkEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repo.setBookmarkSpeedDial(bookmark.id, !bookmark.isSpeedDial)
        }
    }

    fun deleteBookmark(id: Long) {
        viewModelScope.launch(Dispatchers.IO) { repo.deleteBookmark(id) }
    }

    fun deleteHistoryItem(id: Long) {
        viewModelScope.launch(Dispatchers.IO) { repo.deleteHistoryItem(id) }
    }

    fun clearHistory() {
        viewModelScope.launch(Dispatchers.IO) { repo.clearHistory() }
    }

    fun deleteDownloadRecord(id: Long) {
        viewModelScope.launch(Dispatchers.IO) { repo.deleteDownload(id) }
    }

    fun clearFinishedDownloads() {
        viewModelScope.launch(Dispatchers.IO) { repo.clearFinishedDownloads() }
    }

    fun extractDownloadedZip(context: Context, download: DownloadEntity) {
        DownloadHelper.extractDownloadedZip(context, repo, download)
    }

    fun extractExternalZipUri(context: Context, zipUri: Uri) {
        val fakeEntity = DownloadEntity(
            systemDownloadId = -1L,
            fileName = zipUri.lastPathSegment?.substringAfterLast('/')?.ifBlank { "archive.zip" } ?: "archive.zip",
            url = zipUri.toString(),
            mimeType = "application/zip",
            localUri = zipUri.toString(),
            status = DownloadStatus.SUCCESSFUL,
            saveFolderLabel = "/Downloads"
        )
        DownloadHelper.extractDownloadedZip(context, repo, fakeEntity)
    }

    fun createInstalledWebApp(
        context: Context,
        name: String,
        url: String,
        isStandalonePwa: Boolean,
        isolatedProfile: Boolean,
        badgeColorHex: Long,
        badgeTag: String,
        favicon: Bitmap?,
        launchImmediately: Boolean
    ) {
        val pwaId = PwaShortcutHelper.generateUniquePwaId()
        val normalizedUrl = webViewManager.normalizeUrlOrSearchQuery(url)
        val profileName = if (isolatedProfile) "pwa_profile_$pwaId" else "Default"
        val entity = InstalledWebAppEntity(
            pwaId = pwaId,
            name = name.trim().ifBlank { "Web App" },
            url = normalizedUrl,
            isStandalonePwa = isStandalonePwa,
            isolatedProfile = isolatedProfile,
            profileName = profileName,
            badgeColorHex = badgeColorHex,
            badgeTag = badgeTag.trim().take(3)
        )
        viewModelScope.launch(Dispatchers.IO) {
            repo.insertWebApp(entity)
        }
        val pinned = PwaShortcutHelper.pinToHomeScreen(context, entity, favicon)
        Toast.makeText(
            context,
            if (pinned) "Adding \"${entity.name}\" to Home Screen" else "Saved \"${entity.name}\" to Installed PWAs",
            Toast.LENGTH_SHORT
        ).show()
        if (launchImmediately) {
            PwaShortcutHelper.launchWebApp(context, entity)
        }
    }

    fun hibernatePwaSession(context: Context, pwaId: String) {
        PwaWebViewPool.removeAndDestroySession(pwaId, context)
    }

    fun deleteInstalledWebApp(app: InstalledWebAppEntity) {
        PwaWebViewPool.removeAndDestroySession(app.pwaId)
        if (app.isolatedProfile) {
            PwaShortcutHelper.deleteIsolatedProfile(app.profileName)
        }
        viewModelScope.launch(Dispatchers.IO) {
            repo.deleteWebApp(app.pwaId)
        }
    }

    fun updateSearchEngine(engine: SearchEngine) {
        viewModelScope.launch { prefs.setSearchEngine(engine) }
    }

    fun updateThemeMode(mode: ThemeMode) {
        viewModelScope.launch { prefs.setThemeMode(mode) }
    }

    fun updateHomepageMode(mode: HomepageMode) {
        viewModelScope.launch { prefs.setHomepageMode(mode) }
    }

    fun updateFrameRateMode(mode: FrameRateMode) {
        viewModelScope.launch { prefs.setFrameRateMode(mode) }
    }

    fun updateAskBeforeDownload(ask: Boolean) {
        viewModelScope.launch { prefs.setAskBeforeDownload(ask) }
    }

    fun updateDownloadDestination(
        preset: String,
        customTreeUri: String? = null,
        customFolderLabel: String? = null
    ) {
        viewModelScope.launch {
            prefs.setDownloadDestination(preset, customTreeUri, customFolderLabel)
        }
    }

    fun updateKeepPwasAliveInRam(enabled: Boolean) {
        PwaWebViewPool.setKeepAliveEnabled(enabled, webViewManager.persistentContainer.context)
        viewModelScope.launch { prefs.setKeepPwasAliveInRam(enabled) }
    }

    fun updateShowTabStrip(show: Boolean) {
        viewModelScope.launch { prefs.setShowTabStrip(show) }
    }

    fun updateAdBlockEnabled(enabled: Boolean) {
        viewModelScope.launch { prefs.setAdBlockEnabled(enabled) }
    }

    fun updateJavaScriptEnabled(enabled: Boolean) {
        viewModelScope.launch { prefs.setJavaScriptEnabled(enabled) }
    }

    fun updateDarkWebPages(enabled: Boolean) {
        viewModelScope.launch { prefs.setDarkWebPages(enabled) }
    }

    fun updateTextZoomPercent(zoom: Int) {
        viewModelScope.launch { prefs.setTextZoomPercent(zoom) }
    }

    class Factory(private val context: Context) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return BrowserViewModel(WebViewManager.getInstance(context)) as T
        }
    }
}
