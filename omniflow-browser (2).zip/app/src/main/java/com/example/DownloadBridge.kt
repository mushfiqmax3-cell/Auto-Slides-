package com.example

import android.app.DownloadManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.util.Base64
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.MimeTypeMap
import android.webkit.URLUtil
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.BrowserRepository
import com.example.data.DownloadEntity
import com.example.data.DownloadStatus
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class DownloadFolderPreset(
    val displayName: String,
    val relativeDisplayPath: String,
    val publicDirType: String,
    val subFolder: String? = null
) {
    DOWNLOADS("Downloads", "/Downloads", Environment.DIRECTORY_DOWNLOADS, null),
    STUDIO_DOWNLOADS("Downloads / Flowra", "/Downloads/Flowra", Environment.DIRECTORY_DOWNLOADS, "Flowra"),
    DOCUMENTS("Documents", "/Documents", Environment.DIRECTORY_DOCUMENTS, null),
    PICTURES("Pictures", "/Pictures", Environment.DIRECTORY_PICTURES, null),
    MUSIC("Music", "/Music", Environment.DIRECTORY_MUSIC, null),
    MOVIES("Movies", "/Movies", Environment.DIRECTORY_MOVIES, null),
    CUSTOM_SAF("Custom Folder", "Custom folder", Environment.DIRECTORY_DOWNLOADS, null);

    companion object {
        fun fromId(id: String?): DownloadFolderPreset {
            return entries.find { it.name == id } ?: DOWNLOADS
        }
    }
}

data class DownloadDestination(
    val preset: DownloadFolderPreset = DownloadFolderPreset.DOWNLOADS,
    val customTreeUri: String = "",
    val customFolderLabel: String = ""
) {
    fun displayLabel(): String {
        return if (preset == DownloadFolderPreset.CUSTOM_SAF && customFolderLabel.isNotBlank()) {
            customFolderLabel
        } else {
            preset.relativeDisplayPath
        }
    }
}

data class PendingDownloadRequest(
    val url: String,
    val userAgent: String,
    val contentDisposition: String,
    val mimeType: String,
    val contentLength: Long,
    val suggestedFileName: String,
    val defaultDestination: DownloadDestination = DownloadDestination()
)

private data class ActiveBlobTransfer(
    val transferId: String,
    val tempFile: File,
    val fileName: String,
    val mimeType: String,
    val destination: DownloadDestination
)

class StudioDownloadBridge(
    private val context: Context,
    private val onBase64Saved: (
        fileName: String,
        url: String,
        mimeType: String,
        uriString: String,
        sizeBytes: Long,
        saveFolderLabel: String
    ) -> Unit
) {
    private val activeTransfers = ConcurrentHashMap<String, ActiveBlobTransfer>()
    private val cachedBlobNames = ConcurrentHashMap<String, String>()

    @JavascriptInterface
    fun registerBlobSuggestedName(blobUrl: String, downloadAttrName: String) {
        if (blobUrl.isNotBlank() && downloadAttrName.isNotBlank()) {
            cachedBlobNames[blobUrl] = downloadAttrName.trim()
        }
    }

    fun getRegisteredBlobName(blobUrl: String): String? = cachedBlobNames[blobUrl]

    @JavascriptInterface
    fun startBlobTransfer(
        transferId: String,
        fileName: String,
        mimeType: String,
        presetName: String,
        customTreeUri: String,
        customFolderLabel: String
    ) {
        try {
            val safeMime = mimeType.ifBlank { "application/octet-stream" }
            val safeName = sanitizeFileName(
                fileName.ifBlank { "download_${System.currentTimeMillis()}" },
                safeMime
            )
            val dir = File(context.cacheDir, "blob_transfers").apply { mkdirs() }
            val tempFile = File(dir, "blob_${transferId.replace(Regex("[^a-zA-Z0-9_-]"), "")}.tmp")
            if (tempFile.exists()) tempFile.delete()
            val destination = DownloadDestination(
                preset = DownloadFolderPreset.fromId(presetName),
                customTreeUri = customTreeUri,
                customFolderLabel = customFolderLabel
            )
            activeTransfers[transferId] = ActiveBlobTransfer(
                transferId = transferId,
                tempFile = tempFile,
                fileName = safeName,
                mimeType = safeMime,
                destination = destination
            )
        } catch (_: Exception) {
        }
    }

    @JavascriptInterface
    fun appendBlobChunk(transferId: String, base64Chunk: String) {
        val session = activeTransfers[transferId] ?: return
        try {
            val cleanBase64 = if (base64Chunk.contains("base64,")) {
                base64Chunk.substringAfter("base64,")
            } else {
                base64Chunk
            }
            if (cleanBase64.isEmpty()) return
            val bytes = Base64.decode(cleanBase64, Base64.DEFAULT)
            FileOutputStream(session.tempFile, true).use { out ->
                out.write(bytes)
            }
        } catch (_: Exception) {
        }
    }

    @JavascriptInterface
    fun finishBlobTransfer(transferId: String, sourceUrl: String) {
        val session = activeTransfers.remove(transferId) ?: return
        CoroutineScope(Dispatchers.IO).launch {
            try {
                if (!session.tempFile.exists() || session.tempFile.length() == 0L) return@launch
                val rawBytes = session.tempFile.readBytes()
                session.tempFile.delete()
                finalizeAndSaveDownloadedBytes(
                    rawBytes = rawBytes,
                    safeName = session.fileName,
                    safeMime = session.mimeType,
                    sourceUrl = sourceUrl,
                    destination = session.destination
                )
            } catch (e: Exception) {
                session.tempFile.delete()
                withContext(Dispatchers.Main) {
                    Toast.makeText(context, "Download failed: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    @JavascriptInterface
    fun saveBase64Data(base64DataUrl: String, fileName: String, mimeType: String) {
        saveBase64DataToDestination(
            base64DataUrl = base64DataUrl,
            fileName = fileName,
            mimeType = mimeType,
            presetName = DownloadFolderPreset.DOWNLOADS.name,
            customTreeUri = "",
            customFolderLabel = ""
        )
    }

    @JavascriptInterface
    fun saveBase64DataToDestination(
        base64DataUrl: String,
        fileName: String,
        mimeType: String,
        presetName: String,
        customTreeUri: String,
        customFolderLabel: String
    ) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val safeMime = mimeType.ifBlank {
                    extractMimeFromDataUrl(base64DataUrl) ?: "application/octet-stream"
                }
                val safeName = sanitizeFileName(
                    fileName.ifBlank { "download_${System.currentTimeMillis()}" },
                    safeMime
                )
                val base64Part = if (base64DataUrl.contains("base64,")) {
                    base64DataUrl.substringAfter("base64,", "")
                } else {
                    base64DataUrl
                }
                if (base64Part.isEmpty()) return@launch
                val rawBytes = Base64.decode(base64Part, Base64.DEFAULT)

                val destination = DownloadDestination(
                    preset = DownloadFolderPreset.fromId(presetName),
                    customTreeUri = customTreeUri,
                    customFolderLabel = customFolderLabel
                )
                finalizeAndSaveDownloadedBytes(
                    rawBytes = rawBytes,
                    safeName = safeName,
                    safeMime = safeMime,
                    sourceUrl = base64DataUrl.take(96),
                    destination = destination
                )
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(context, "Download failed: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private suspend fun finalizeAndSaveDownloadedBytes(
        rawBytes: ByteArray,
        safeName: String,
        safeMime: String,
        sourceUrl: String,
        destination: DownloadDestination
    ) {
        val isZip = safeName.endsWith(".zip", ignoreCase = true) ||
            safeMime.contains("zip", ignoreCase = true)
        val finalBytes = if (isZip) {
            ZipArchiveHelper.normalizeZipBytes(rawBytes)
        } else {
            rawBytes
        }

        val savedUri = writeBytesToDestination(context, safeName, safeMime, finalBytes, destination)
        val folderLabel = destination.displayLabel()
        if (savedUri != null) {
            onBase64Saved(
                safeName,
                sourceUrl,
                safeMime,
                savedUri.toString(),
                finalBytes.size.toLong(),
                folderLabel
            )

            // If this .zip contains an .apk (like VoiceTypePro-Release-APK.zip -> app-debug.apk),
            // automatically extract the inner files directly into the same Download folder!
            var autoExtractedApkName: String? = null
            var simulatedApkWarning = false
            if (isZip) {
                val summary = ZipArchiveHelper.extractZipBytesToDestination(
                    context = context,
                    zipBytes = finalBytes,
                    destination = destination
                )
                simulatedApkWarning = summary.containsSimulatedApk
                for (extracted in summary.extractedFiles) {
                    onBase64Saved(
                        extracted.fileName,
                        "extracted://${safeName}/${extracted.fileName}",
                        extracted.mimeType,
                        extracted.savedUri.toString(),
                        extracted.sizeBytes,
                        folderLabel
                    )
                    if (extracted.fileName.endsWith(".apk", ignoreCase = true)) {
                        autoExtractedApkName = extracted.fileName
                    }
                }
            }

            withContext(Dispatchers.Main) {
                val msg = when {
                    simulatedApkWarning ->
                        "Saved & extracted $safeName in $folderLabel (Note: inner APK is a web demo placeholder, not a compiled binary)"
                    autoExtractedApkName != null ->
                        "Saved $safeName & auto-extracted $autoExtractedApkName to $folderLabel"
                    else ->
                        "Saved $safeName in $folderLabel"
                }
                Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun extractMimeFromDataUrl(dataUrl: String): String? {
        if (!dataUrl.startsWith("data:")) return null
        val header = dataUrl.substringAfter("data:").substringBefore(";")
        return header.takeIf { it.contains("/") }
    }
}

fun sanitizeFileName(rawName: String, mimeType: String): String {
    val clean = rawName
        .replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001F]"), "_")
        .trim()
        .trimStart('.')
        .ifBlank { "download_${System.currentTimeMillis()}" }

    val hasValidExt = clean.contains(".") && !clean.endsWith(".")
    if (hasValidExt) return clean

    val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mimeType)
    return if (!ext.isNullOrBlank()) "$clean.$ext" else clean
}

fun formatSafTreeLabel(treeUri: Uri): String {
    return try {
        val docId = DocumentsContract.getTreeDocumentId(treeUri)
        val normalized = when {
            docId.startsWith("primary:", ignoreCase = true) -> {
                val rel = docId.substringAfter(":").trim('/')
                if (rel.isEmpty()) "/Internal Storage" else "/$rel"
            }
            docId.contains(":") -> {
                val vol = docId.substringBefore(":")
                val rel = docId.substringAfter(":").trim('/')
                if (rel.isEmpty()) "/$vol" else "/$vol/$rel"
            }
            else -> "/$docId"
        }
        normalized
    } catch (_: Exception) {
        treeUri.lastPathSegment ?: "Selected Folder"
    }
}

fun writeBytesToDownloads(
    context: Context,
    fileName: String,
    mimeType: String,
    bytes: ByteArray
): Uri? = writeBytesToDestination(context, fileName, mimeType, bytes, DownloadDestination())

fun writeBytesToDestination(
    context: Context,
    fileName: String,
    mimeType: String,
    bytes: ByteArray,
    destination: DownloadDestination
): Uri? {
    // 1. Custom SAF Folder selected via ACTION_OPEN_DOCUMENT_TREE
    if (destination.preset == DownloadFolderPreset.CUSTOM_SAF && destination.customTreeUri.isNotBlank()) {
        try {
            val treeUri = Uri.parse(destination.customTreeUri)
            val parentDocUri = DocumentsContract.buildDocumentUriUsingTree(
                treeUri,
                DocumentsContract.getTreeDocumentId(treeUri)
            )
            val createdUri = DocumentsContract.createDocument(
                context.contentResolver,
                parentDocUri,
                mimeType.ifBlank { "application/octet-stream" },
                fileName
            )
            if (createdUri != null) {
                context.contentResolver.openOutputStream(createdUri)?.use { it.write(bytes) }
                return createdUri
            }
        } catch (_: Exception) {
            // Fall through to MediaStore Downloads if SAF permission was revoked
        }
    }

    // 2. Standard Scoped Storage public directories (zero-permission on Android 10+)
    return writeStreamToMediaStore(
        context = context,
        fileName = fileName,
        mimeType = mimeType,
        preset = destination.preset,
        inputStream = bytes.inputStream(),
        onProgress = null
    )
}

private fun writeStreamToMediaStore(
    context: Context,
    fileName: String,
    mimeType: String,
    preset: DownloadFolderPreset,
    inputStream: InputStream,
    onProgress: ((bytesWritten: Long) -> Unit)?
): Uri? {
    val safeMime = mimeType.ifBlank { "application/octet-stream" }
    val relPath = buildString {
        append(preset.publicDirType)
        if (!preset.subFolder.isNullOrBlank()) {
            append("/")
            append(preset.subFolder)
        }
    }

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        val collectionUri = when (preset) {
            DownloadFolderPreset.PICTURES -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            DownloadFolderPreset.MUSIC -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            DownloadFolderPreset.MOVIES -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            DownloadFolderPreset.DOCUMENTS -> MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            else -> MediaStore.Downloads.EXTERNAL_CONTENT_URI
        }
        val effectiveMime = if (preset == DownloadFolderPreset.DOCUMENTS && !safeMime.startsWith("text/") && safeMime != "application/pdf") {
            "application/octet-stream"
        } else {
            safeMime
        }

        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
            put(MediaStore.MediaColumns.MIME_TYPE, effectiveMime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, relPath)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }

        val resolver = context.contentResolver
        val insertedUri = try {
            resolver.insert(collectionUri, values)
        } catch (_: Exception) {
            val fallbackValues = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, safeMime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, fallbackValues)
        } ?: return null

        resolver.openOutputStream(insertedUri)?.use { out ->
            copyStreamWithProgress(inputStream, out, onProgress)
        }
        values.clear()
        values.put(MediaStore.MediaColumns.IS_PENDING, 0)
        resolver.update(insertedUri, values, null, null)
        return insertedUri
    } else {
        @Suppress("DEPRECATION")
        val baseDir = Environment.getExternalStoragePublicDirectory(preset.publicDirType)
        val targetDir = if (!preset.subFolder.isNullOrBlank()) File(baseDir, preset.subFolder) else baseDir
        if (!targetDir.exists()) targetDir.mkdirs()
        val file = File(targetDir, fileName)
        FileOutputStream(file).use { out ->
            copyStreamWithProgress(inputStream, out, onProgress)
        }
        return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    }
}

private fun copyStreamWithProgress(
    input: InputStream,
    output: java.io.OutputStream,
    onProgress: ((Long) -> Unit)?
) {
    val buffer = ByteArray(16 * 1024)
    var total = 0L
    var lastReported = 0L
    while (true) {
        val read = input.read(buffer)
        if (read <= 0) break
        output.write(buffer, 0, read)
        total += read
        if (onProgress != null && total - lastReported >= 128 * 1024L) {
            lastReported = total
            onProgress(total)
        }
    }
    output.flush()
    onProgress?.invoke(total)
}

object DownloadHelper {

    /**
     * Streams blob: or data: URLs in 512 KB binary chunks via StudioDownloadBridge so large
     * .zip and .apk files (e.g. 18MB - 200MB) never hit WebView JNI Base64 string limits,
     * and reads from window.__flowraBlobStore if the page already called URL.revokeObjectURL().
     */
    fun buildBlobOrDataExtractionScript(
        blobOrDataUrl: String,
        suggestedName: String,
        mimeType: String,
        destination: DownloadDestination = DownloadDestination()
    ): String {
        val escapedUrl = blobOrDataUrl.replace("\\", "\\\\").replace("'", "\\'")
        val escapedName = suggestedName.replace("\\", "\\\\").replace("'", "\\'")
        val escapedMime = mimeType.replace("\\", "\\\\").replace("'", "\\'")
        val escapedPreset = destination.preset.name.replace("'", "\\'")
        val escapedTree = destination.customTreeUri.replace("\\", "\\\\").replace("'", "\\'")
        val escapedLabel = destination.customFolderLabel.replace("\\", "\\\\").replace("'", "\\'")
        return """
            (function() {
                try {
                    var targetUrl = '$escapedUrl';
                    var fallbackName = '$escapedName';
                    var fallbackMime = '$escapedMime';
                    var presetName = '$escapedPreset';
                    var customTree = '$escapedTree';
                    var customLabel = '$escapedLabel';

                    if (targetUrl.indexOf('data:') === 0) {
                        if (window.StudioDownloadBridge && window.StudioDownloadBridge.saveBase64DataToDestination) {
                            window.StudioDownloadBridge.saveBase64DataToDestination(
                                targetUrl, fallbackName, fallbackMime, presetName, customTree, customLabel
                            );
                        }
                        return;
                    }

                    var cachedBlob = (window.__flowraBlobStore && window.__flowraBlobStore[targetUrl]) || null;
                    var blobPromise = cachedBlob
                        ? Promise.resolve(cachedBlob)
                        : fetch(targetUrl).then(function(res) { return res.blob(); });

                    blobPromise.then(function(blob) {
                        if (!blob || !window.StudioDownloadBridge) return;
                        var effectiveMime = blob.type || fallbackMime || 'application/octet-stream';
                        var transferId = 'tr_' + Date.now() + '_' + Math.floor(Math.random() * 100000);
                        if (!window.StudioDownloadBridge.startBlobTransfer) {
                            var r = new FileReader();
                            r.onloadend = function() {
                                if (r.result) {
                                    window.StudioDownloadBridge.saveBase64DataToDestination(
                                        r.result, fallbackName, effectiveMime, presetName, customTree, customLabel
                                    );
                                }
                            };
                            r.readAsDataURL(blob);
                            return;
                        }

                        window.StudioDownloadBridge.startBlobTransfer(
                            transferId, fallbackName, effectiveMime, presetName, customTree, customLabel
                        );
                        var chunkSize = 512 * 1024;
                        var offset = 0;

                        function sendNextChunk() {
                            if (offset >= blob.size) {
                                window.StudioDownloadBridge.finishBlobTransfer(transferId, targetUrl);
                                return;
                            }
                            var slice = blob.slice(offset, Math.min(offset + chunkSize, blob.size));
                            offset += chunkSize;
                            var reader = new FileReader();
                            reader.onloadend = function() {
                                if (reader.result) {
                                    window.StudioDownloadBridge.appendBlobChunk(transferId, reader.result);
                                    sendNextChunk();
                                }
                            };
                            reader.readAsDataURL(slice);
                        }
                        sendNextChunk();
                    }).catch(function(err) {
                        console.error('Flowra blob download error:', err);
                    });
                } catch (e) {}
            })();
        """.trimIndent()
    }

    suspend fun enqueueHttpDownload(
        context: Context,
        repository: BrowserRepository,
        url: String,
        fileName: String,
        mimeType: String,
        userAgent: String
    ): Long = enqueueDownloadWithDestination(
        context = context,
        repository = repository,
        url = url,
        fileName = fileName,
        mimeType = mimeType,
        userAgent = userAgent,
        destination = DownloadDestination()
    )

    suspend fun enqueueDownloadWithDestination(
        context: Context,
        repository: BrowserRepository,
        url: String,
        fileName: String,
        mimeType: String,
        userAgent: String,
        destination: DownloadDestination
    ): Long {
        val safeMime = mimeType.ifBlank { "application/octet-stream" }
        val finalName = sanitizeFileName(fileName, safeMime)
        val folderLabel = destination.displayLabel()
        val isZipOrApk = finalName.endsWith(".zip", ignoreCase = true) ||
            finalName.endsWith(".apk", ignoreCase = true) ||
            safeMime.contains("zip", ignoreCase = true)

        // Route .zip, .apk, and custom SAF folders through our authenticated stream engine
        // so cookies/redirects are preserved and .zip files are normalized & auto-extracted!
        if (isZipOrApk || (destination.preset == DownloadFolderPreset.CUSTOM_SAF && destination.customTreeUri.isNotBlank())) {
            return streamHttpDownloadToSafOrMediaStore(
                context = context,
                repository = repository,
                url = url,
                finalName = finalName,
                safeMime = safeMime,
                userAgent = userAgent,
                destination = destination,
                folderLabel = folderLabel
            )
        }

        val subPath = if (!destination.preset.subFolder.isNullOrBlank()) {
            "${destination.preset.subFolder}/$finalName"
        } else {
            finalName
        }

        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as? DownloadManager
        if (dm != null) {
            try {
                if (!destination.preset.subFolder.isNullOrBlank()) {
                    @Suppress("DEPRECATION")
                    val targetSubDir = File(
                        Environment.getExternalStoragePublicDirectory(destination.preset.publicDirType),
                        destination.preset.subFolder
                    )
                    if (!targetSubDir.exists()) targetSubDir.mkdirs()
                }
                val request = DownloadManager.Request(Uri.parse(url)).apply {
                    setMimeType(safeMime)
                    val cookies = CookieManager.getInstance().getCookie(url)
                    if (!cookies.isNullOrBlank()) {
                        addRequestHeader("cookie", cookies)
                    }
                    addRequestHeader("User-Agent", userAgent)
                    setTitle(finalName)
                    setDescription("Saving to $folderLabel")
                    setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    setDestinationInExternalPublicDir(destination.preset.publicDirType, subPath)
                }

                val systemId = dm.enqueue(request)
                repository.insertDownload(
                    DownloadEntity(
                        systemDownloadId = systemId,
                        fileName = finalName,
                        url = url,
                        mimeType = safeMime,
                        status = DownloadStatus.RUNNING,
                        saveFolderLabel = folderLabel
                    )
                )
                return systemId
            } catch (_: Exception) {
            }
        }

        return streamHttpDownloadToSafOrMediaStore(
            context = context,
            repository = repository,
            url = url,
            finalName = finalName,
            safeMime = safeMime,
            userAgent = userAgent,
            destination = destination,
            folderLabel = folderLabel
        )
    }

    private suspend fun streamHttpDownloadToSafOrMediaStore(
        context: Context,
        repository: BrowserRepository,
        url: String,
        finalName: String,
        safeMime: String,
        userAgent: String,
        destination: DownloadDestination,
        folderLabel: String
    ): Long {
        val rowId = repository.insertDownload(
            DownloadEntity(
                systemDownloadId = -1L,
                fileName = finalName,
                url = url,
                mimeType = safeMime,
                status = DownloadStatus.RUNNING,
                saveFolderLabel = folderLabel
            )
        )
        return withContext(Dispatchers.IO) {
            var connection: HttpURLConnection? = null
            val tempDir = File(context.cacheDir, "http_downloads").apply { mkdirs() }
            val tempFile = File(tempDir, "dl_${rowId}_${System.currentTimeMillis()}.tmp")
            try {
                connection = openFollowedHttpConnection(url, userAgent)
                val totalLength = connection.contentLengthLong
                val effectiveMime = connection.contentType?.substringBefore(";")?.trim()?.ifBlank { safeMime } ?: safeMime
                val existingEntity = DownloadEntity(
                    id = rowId,
                    systemDownloadId = -1L,
                    fileName = finalName,
                    url = url,
                    mimeType = effectiveMime,
                    status = DownloadStatus.RUNNING,
                    totalBytes = totalLength,
                    saveFolderLabel = folderLabel
                )
                repository.updateDownload(existingEntity)

                var finalBytes = 0L
                connection.inputStream.use { input ->
                    FileOutputStream(tempFile).use { tempOut ->
                        copyStreamWithProgress(input, tempOut) { written ->
                            finalBytes = written
                            CoroutineScope(Dispatchers.IO).launch {
                                repository.updateDownloadProgress(rowId, written)
                            }
                        }
                    }
                }

                val isZip = finalName.endsWith(".zip", ignoreCase = true) ||
                    effectiveMime.contains("zip", ignoreCase = true)

                // If it's a .zip file under 64 MB, normalize its headers so Vivo/OEM File Managers never fail on it
                if (isZip && tempFile.exists() && tempFile.length() in 1L..(64L * 1024L * 1024L)) {
                    try {
                        val rawBytes = tempFile.readBytes()
                        val normalized = ZipArchiveHelper.normalizeZipBytes(rawBytes)
                        tempFile.writeBytes(normalized)
                        finalBytes = normalized.size.toLong()
                    } catch (_: Exception) {
                    }
                }

                var savedUri: Uri? = null
                FileInputStream(tempFile).use { fileIn ->
                    if (destination.preset == DownloadFolderPreset.CUSTOM_SAF && destination.customTreeUri.isNotBlank()) {
                        val treeUri = Uri.parse(destination.customTreeUri)
                        val parentDocUri = DocumentsContract.buildDocumentUriUsingTree(
                            treeUri,
                            DocumentsContract.getTreeDocumentId(treeUri)
                        )
                        val docUri = DocumentsContract.createDocument(
                            context.contentResolver,
                            parentDocUri,
                            effectiveMime,
                            finalName
                        )
                        if (docUri != null) {
                            context.contentResolver.openOutputStream(docUri)?.use { out ->
                                copyStreamWithProgress(fileIn, out, null)
                            }
                            savedUri = docUri
                        }
                    }

                    if (savedUri == null) {
                        savedUri = writeStreamToMediaStore(
                            context = context,
                            fileName = finalName,
                            mimeType = effectiveMime,
                            preset = destination.preset,
                            inputStream = fileIn,
                            onProgress = null
                        )
                    }
                }

                repository.updateDownload(
                    existingEntity.copy(
                        localUri = savedUri?.toString() ?: "",
                        status = if (savedUri != null) DownloadStatus.SUCCESSFUL else DownloadStatus.FAILED,
                        totalBytes = if (totalLength > 0) totalLength else finalBytes,
                        downloadedBytes = finalBytes
                    )
                )

                // Auto-extract inner .apk files when downloading a .zip
                if (isZip && tempFile.exists() && tempFile.length() in 1L..(64L * 1024L * 1024L)) {
                    try {
                        val summary = ZipArchiveHelper.extractZipBytesToDestination(
                            context = context,
                            zipBytes = tempFile.readBytes(),
                            destination = destination
                        )
                        for (extracted in summary.extractedFiles) {
                            repository.insertDownload(
                                DownloadEntity(
                                    systemDownloadId = -1L,
                                    fileName = extracted.fileName,
                                    url = "extracted://${finalName}/${extracted.fileName}",
                                    mimeType = extracted.mimeType,
                                    localUri = extracted.savedUri.toString(),
                                    status = DownloadStatus.SUCCESSFUL,
                                    totalBytes = extracted.sizeBytes,
                                    downloadedBytes = extracted.sizeBytes,
                                    saveFolderLabel = folderLabel
                                )
                            )
                        }
                    } catch (_: Exception) {
                    }
                }

                rowId
            } catch (_: Exception) {
                repository.updateDownload(
                    DownloadEntity(
                        id = rowId,
                        systemDownloadId = -1L,
                        fileName = finalName,
                        url = url,
                        mimeType = safeMime,
                        status = DownloadStatus.FAILED,
                        saveFolderLabel = folderLabel
                    )
                )
                -1L
            } finally {
                tempFile.delete()
                connection?.disconnect()
            }
        }
    }

    private fun openFollowedHttpConnection(rawUrl: String, userAgent: String): HttpURLConnection {
        var currentUrl = rawUrl
        var redirects = 0
        while (redirects < 5) {
            val conn = (URL(currentUrl).openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = false
                connectTimeout = 20_000
                readTimeout = 60_000
                setRequestProperty("User-Agent", userAgent)
                setRequestProperty("Accept-Encoding", "identity")
                val cookies = try {
                    CookieManager.getInstance().getCookie(currentUrl)
                } catch (_: Exception) {
                    null
                }
                if (!cookies.isNullOrBlank()) {
                    setRequestProperty("Cookie", cookies)
                }
            }
            val code = conn.responseCode
            if (code in 300..399) {
                val location = conn.getHeaderField("Location")
                conn.disconnect()
                if (location.isNullOrBlank()) break
                currentUrl = URL(URL(currentUrl), location).toString()
                redirects++
            } else {
                return conn
            }
        }
        return (URL(currentUrl).openConnection() as HttpURLConnection).apply {
            setRequestProperty("User-Agent", userAgent)
            setRequestProperty("Accept-Encoding", "identity")
        }
    }

    suspend fun syncActiveDownloads(context: Context, repository: BrowserRepository) {
        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as? DownloadManager ?: return
        val activeList = repository.getActiveDownloads()
        for (item in activeList) {
            if (item.systemDownloadId <= 0L) continue
            val query = DownloadManager.Query().setFilterById(item.systemDownloadId)
            dm.query(query)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val statusIdx = cursor.getColumnIndex(DownloadManager.COLUMN_STATUS)
                    val totalIdx = cursor.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
                    val downloadedIdx = cursor.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
                    val localUriIdx = cursor.getColumnIndex(DownloadManager.COLUMN_LOCAL_URI)

                    val sysStatus = if (statusIdx >= 0) cursor.getInt(statusIdx) else DownloadManager.STATUS_RUNNING
                    val totalBytes = if (totalIdx >= 0) cursor.getLong(totalIdx) else item.totalBytes
                    val downloadedBytes = if (downloadedIdx >= 0) cursor.getLong(downloadedIdx) else item.downloadedBytes
                    val rawLocalUri = if (localUriIdx >= 0) cursor.getString(localUriIdx) ?: "" else ""

                    val newStatus = when (sysStatus) {
                        DownloadManager.STATUS_PENDING -> DownloadStatus.PENDING
                        DownloadManager.STATUS_RUNNING -> DownloadStatus.RUNNING
                        DownloadManager.STATUS_PAUSED -> DownloadStatus.PAUSED
                        DownloadManager.STATUS_SUCCESSFUL -> DownloadStatus.SUCCESSFUL
                        DownloadManager.STATUS_FAILED -> DownloadStatus.FAILED
                        else -> item.status
                    }

                    val contentUri = if (newStatus == DownloadStatus.SUCCESSFUL) {
                        try {
                            dm.getUriForDownloadedFile(item.systemDownloadId)?.toString() ?: rawLocalUri
                        } catch (_: Exception) {
                            rawLocalUri
                        }
                    } else {
                        rawLocalUri
                    }

                    repository.updateDownload(
                        item.copy(
                            status = newStatus,
                            totalBytes = totalBytes,
                            downloadedBytes = downloadedBytes,
                            localUri = contentUri.ifBlank { item.localUri }
                        )
                    )
                }
            }
        }
    }

    /**
     * Extracts a downloaded .zip archive directly using Flowra's built-in ZipArchiveHelper
     * and inserts all extracted files (such as app-debug.apk) into the Downloads list.
     */
    fun extractDownloadedZip(
        context: Context,
        repository: BrowserRepository,
        download: DownloadEntity
    ) {
        val uri = resolveShareableUri(context, download)
        if (uri == null) {
            Toast.makeText(context, "ZIP file not found on storage", Toast.LENGTH_SHORT).show()
            return
        }
        CoroutineScope(Dispatchers.IO).launch {
            val summary = ZipArchiveHelper.extractZipFromUri(
                context = context,
                zipUri = uri,
                destination = DownloadDestination(DownloadFolderPreset.DOWNLOADS)
            )
            if (summary.extractedFiles.isEmpty()) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(
                        context,
                        "Could not find extractable entries in ${download.fileName}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
                return@launch
            }

            val folderLabel = download.saveFolderLabel.ifBlank { "/Downloads" }
            for (item in summary.extractedFiles) {
                repository.insertDownload(
                    DownloadEntity(
                        systemDownloadId = -1L,
                        fileName = item.fileName,
                        url = "extracted://${download.fileName}/${item.fileName}",
                        mimeType = item.mimeType,
                        localUri = item.savedUri.toString(),
                        status = DownloadStatus.SUCCESSFUL,
                        totalBytes = item.sizeBytes,
                        downloadedBytes = item.sizeBytes,
                        saveFolderLabel = folderLabel
                    )
                )
            }

            withContext(Dispatchers.Main) {
                val names = summary.extractedFiles.joinToString(", ") { it.fileName }
                val message = if (summary.containsSimulatedApk) {
                    "Extracted $names to $folderLabel (Note: inner APK is a web demo placeholder, not a compiled binary)"
                } else {
                    "Extracted ${summary.extractedFiles.size} file(s) ($names) to $folderLabel"
                }
                Toast.makeText(context, message, Toast.LENGTH_LONG).show()
            }
        }
    }

    fun openDownloadedFile(context: Context, download: DownloadEntity, repository: BrowserRepository? = null) {
        val uri = resolveShareableUri(context, download)
        if (uri == null) {
            Toast.makeText(context, "File not available yet", Toast.LENGTH_SHORT).show()
            return
        }
        // If user taps a .zip file and repository is provided, also auto-extract it in Flowra
        if (download.fileName.endsWith(".zip", ignoreCase = true) && repository != null) {
            extractDownloadedZip(context, repository, download)
            return
        }

        val resolvedMime = when {
            download.fileName.endsWith(".apk", ignoreCase = true) -> "application/vnd.android.package-archive"
            download.fileName.endsWith(".zip", ignoreCase = true) -> "application/zip"
            download.mimeType.isNotBlank() && download.mimeType != "application/octet-stream" -> download.mimeType
            else -> ZipArchiveHelper.guessMimeForFileName(download.fileName)
        }
        try {
            val viewIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, resolvedMime)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(viewIntent, "Open ${download.fileName}"))
        } catch (_: Exception) {
            Toast.makeText(context, "No app found to open ${download.fileName}", Toast.LENGTH_SHORT).show()
        }
    }

    fun shareDownloadedFile(context: Context, download: DownloadEntity) {
        val uri = resolveShareableUri(context, download)
        if (uri == null) {
            Toast.makeText(context, "File cannot be shared yet", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = download.mimeType.ifBlank { "*/*" }
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(shareIntent, "Share ${download.fileName}"))
        } catch (_: Exception) {
            Toast.makeText(context, "Unable to share file", Toast.LENGTH_SHORT).show()
        }
    }

    private fun resolveShareableUri(context: Context, download: DownloadEntity): Uri? {
        if (download.systemDownloadId > 0L) {
            val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as? DownloadManager
            val dmUri = try {
                dm?.getUriForDownloadedFile(download.systemDownloadId)
            } catch (_: Exception) {
                null
            }
            if (dmUri != null) return dmUri
        }
        if (download.localUri.isNotBlank()) {
            val parsed = Uri.parse(download.localUri)
            if (parsed.scheme == "content") return parsed
            if (parsed.scheme == "file" && parsed.path != null) {
                return try {
                    FileProvider.getUriForFile(
                        context,
                        "${context.packageName}.fileprovider",
                        File(parsed.path!!)
                    )
                } catch (_: Exception) {
                    null
                }
            }
        }
        return null
    }

    fun formatBytes(bytes: Long): String {
        if (bytes < 0L) return "Unknown size"
        if (bytes < 1024L) return "$bytes B"
        val kb = bytes / 1024.0
        if (kb < 1024.0) return String.format(Locale.US, "%.1f KB", kb)
        val mb = kb / 1024.0
        if (mb < 1024.0) return String.format(Locale.US, "%.1f MB", mb)
        val gb = mb / 1024.0
        return String.format(Locale.US, "%.2f GB", gb)
    }

    fun guessName(
        url: String,
        contentDisposition: String?,
        mimeType: String?,
        registeredBlobName: String? = null
    ): String {
        if (!registeredBlobName.isNullOrBlank()) {
            return sanitizeFileName(registeredBlobName, mimeType ?: "application/octet-stream")
        }
        if (url.startsWith("blob:") || url.startsWith("data:")) {
            val dispName = contentDisposition
                ?.substringAfter("filename=", "")
                ?.trim('"', ' ', ';')
                ?.takeIf { it.isNotBlank() }
            if (dispName != null) return sanitizeFileName(dispName, mimeType ?: "application/octet-stream")
            return sanitizeFileName("studio_export_${System.currentTimeMillis()}", mimeType ?: "application/octet-stream")
        }
        return URLUtil.guessFileName(url, contentDisposition, mimeType)
    }
}
