package com.example

/**
 * One stored Gemini API key together with the single model it uses when racing.
 *
 * @param isExhausted true when the key's quota is used up; exhausted keys are skipped by the race.
 * @param selectedModel model id (no "models/" prefix) fetched from this key's `models.list`; editable later.
 */
data class ApiKeyEntry(
    val id: String,
    val displayName: String,
    val keyValue: String,
    val isExhausted: Boolean = false,
    val selectedModel: String = Prefs.DEFAULT_MODEL_NAME
)
