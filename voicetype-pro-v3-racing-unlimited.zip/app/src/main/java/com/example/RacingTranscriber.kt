package com.example

import android.util.Base64
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.Callback
import okhttp3.Dispatcher
import okhttp3.OkHttpClient
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * "Racing" transcription engine.
 *
 * For one recording it fires ALL (unlimited) Gemini requests concurrently
 * - one per non-exhausted API key, each paired with that key's own selected model - and returns the FIRST
 * successful transcript. As soon as a winner is known every other in-flight request is cancelled,
 * both at the coroutine level and at the OkHttp [Call] level, so the socket is closed immediately.
 *
 * - HTTP 429 / quota errors mark the owning key as exhausted via [ApiKeyRepository.markKeyExhausted].
 * - If every racer fails, the failure is mapped onto the existing [TranscriptionException] types so the
 *   caller's current error handling keeps working unchanged.
 * - The public signature of [transcribeAudio] matches [GeminiTranscriber.transcribeAudio].
 */
object RacingTranscriber {

    /** One parallel request: an API key together with that key's selected model. */
    data class Combination(val keyValue: String, val modelId: String)

    private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()

    private const val ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/models"

    /**
     * Dedicated client for racing: same timeouts / connection pool as the shared client, but with a
     * dispatcher that has no practical concurrency cap (OkHttp's default is 5 per host, which would
     * silently queue extra racers instead of running them concurrently).
     */
    private val raceClient: OkHttpClient by lazy {
        val dispatcher = Dispatcher().apply {
            maxRequests = Int.MAX_VALUE
            maxRequestsPerHost = Int.MAX_VALUE
        }
        GeminiTranscriber.okHttpClient.newBuilder().dispatcher(dispatcher).build()
    }

    /** Rotates the starting key (kept for ordering variety; no limit is applied any more). */
    private val rotation = AtomicInteger(0)

    private class Race {
        val calls: MutableSet<Call> = ConcurrentHashMap.newKeySet()

        @Volatile
        var stopped = false

        @Volatile
        var cancelledByUser = false

        /** Cancels every in-flight HTTP call of this race right now. */
        fun cancelCalls() {
            stopped = true
            for (call in calls.toList()) {
                try {
                    call.cancel()
                } catch (_: Exception) {
                }
            }
        }
    }

    private sealed class Outcome {
        class Success(val response: TranscriptionResponse) : Outcome()
        class Failure(val error: TranscriptionException) : Outcome()
    }

    private class RaceResult(val winner: TranscriptionResponse?, val failures: List<TranscriptionException>)

    private val activeRaces: MutableSet<Race> = ConcurrentHashMap.newKeySet()

    /**
     * Cancels the running race (if any) at HTTP level. Used by the ✕ button / service shutdown.
     * The suspended [transcribeAudio] call then ends with a [CancellationException], never with a
     * misleading "no internet" failure.
     */
    fun cancelActiveRequest() {
        for (race in activeRaces.toList()) {
            race.cancelledByUser = true
            race.cancelCalls()
        }
    }

    // ---------------------------------------------------------------------------------------
    // Combination selection (pure, unit-tested)
    // ---------------------------------------------------------------------------------------

    /**
     * Picks every (key, selectedModel) pair (unlimited by default; [limit] is optional) from the non-exhausted [entries] (all entries when
     * every key is exhausted - last-resort retry, same rule as [ApiKeyRepository.getUsableKeyValues]).
     * [startOffset] rotates the key order so load spreads over all keys when there are more than [limit].
     */
    internal fun selectCombinations(
        entries: List<ApiKeyEntry>,
        startOffset: Int = 0,
        limit: Int = Int.MAX_VALUE
    ): List<Combination> {
        val pool = entries.filter { !it.isExhausted }.ifEmpty { entries }
        if (pool.isEmpty() || limit <= 0) return emptyList()

        val shift = Math.floorMod(startOffset, pool.size)
        val rotated = pool.drop(shift) + pool.take(shift)
        return rotated.take(limit).map { Combination(it.keyValue, it.selectedModel) }
    }

    private fun buildCombinations(fallbackApiKey: String, configuredModel: String): List<Combination> {
        // Makes sure the repository is loaded (no-op when it already is).
        Prefs.getApiKeys()
        val fromRepository = selectCombinations(ApiKeyRepository.getAll(), rotation.getAndIncrement())
        if (fromRepository.isNotEmpty()) return fromRepository

        // No stored entries: fall back to the single key / model handed in by the caller.
        val key = fallbackApiKey.trim()
        if (key.isEmpty()) return emptyList()
        val model = configuredModel.trim().ifEmpty { Prefs.DEFAULT_MODEL_NAME }
        return listOf(Combination(key, model))
    }

    // ---------------------------------------------------------------------------------------
    // Public API
    // ---------------------------------------------------------------------------------------

    /**
     * Transcribes [audioFile] by racing all active key x model combinations.
     * Always deletes [audioFile] in the finally block (success, failure, or cancellation).
     */
    suspend fun transcribeAudio(
        audioFile: File,
        apiKey: String,
        configuredModel: String = Prefs.DEFAULT_MODEL_NAME,
        appPackage: String? = null
    ): Result<TranscriptionResponse> = withContext(Dispatchers.IO) {
        try {
            val combinations = buildCombinations(apiKey, configuredModel)
            if (combinations.isEmpty()) {
                return@withContext Result.failure(TranscriptionException.InvalidApiKey())
            }
            if (!audioFile.exists() || audioFile.length() <= 44L) {
                return@withContext Result.failure(TranscriptionException.EmptyResult())
            }
            val audioBytes = FileInputStream(audioFile).use { it.readBytes() }
            if (audioBytes.size <= 44) {
                return@withContext Result.failure(TranscriptionException.EmptyResult())
            }

            val mimeType = GeminiTranscriber.detectAudioMimeType(audioFile, audioBytes)
            val base64Audio = Base64.encodeToString(audioBytes, Base64.NO_WRAP)
            // Encoded once; every racer shares the same byte array (no per-request copy).
            val body = GeminiTranscriber.buildTranscriptionJson(
                base64Audio,
                mimeType,
                GeminiTranscriber.buildPrompt(appPackage)
            ).toByteArray(Charsets.UTF_8)

            val first = race(combinations, body)
            first.winner?.let { return@withContext Result.success(it) }

            // Every selected model answered "404": retry once with the built-in fallback model,
            // one request per distinct key (keeps the old single-key behaviour).
            val allModelNotFound = first.failures.isNotEmpty() &&
                first.failures.all { it is TranscriptionException.ModelNotFound }
            if (allModelNotFound && combinations.none { it.modelId == Prefs.FALLBACK_MODEL_NAME }) {
                val fallbackCombos = combinations
                    .distinctBy { it.keyValue }
                    .map { it.copy(modelId = Prefs.FALLBACK_MODEL_NAME) }
                val second = race(fallbackCombos, body)
                second.winner?.let {
                    return@withContext Result.success(it.copy(usedFallbackModel = true))
                }
                return@withContext Result.failure(pickError(first.failures + second.failures))
            }

            Result.failure(pickError(first.failures))
        } catch (e: CancellationException) {
            throw e
        } catch (e: UnknownHostException) {
            Result.failure(TranscriptionException.NoInternet())
        } catch (e: SocketTimeoutException) {
            Result.failure(TranscriptionException.ApiError("Connection timed out. Please try again."))
        } catch (e: IOException) {
            Result.failure(TranscriptionException.NoInternet())
        } catch (e: Exception) {
            Result.failure(TranscriptionException.ApiError(e.localizedMessage ?: "Transcription failed."))
        } finally {
            try {
                if (audioFile.exists()) audioFile.delete()
            } catch (_: Exception) {
            }
        }
    }

    /**
     * Chooses the most useful error when every racer failed. Lower rank wins: an empty transcript
     * (the audio WAS processed) beats server / quota / key problems, and "no internet" only wins when
     * nothing else happened.
     */
    internal fun pickError(failures: List<TranscriptionException>): TranscriptionException {
        if (failures.isEmpty()) return TranscriptionException.QuotaExceeded()
        return failures.minByOrNull { rank(it) } ?: failures.first()
    }

    private fun rank(e: TranscriptionException): Int = when (e) {
        is TranscriptionException.EmptyResult -> 0
        is TranscriptionException.ServiceUnavailable -> 1
        is TranscriptionException.QuotaExceeded -> 2
        is TranscriptionException.InvalidApiKey -> 3
        is TranscriptionException.ApiError -> 4
        is TranscriptionException.ModelNotFound -> 5
        is TranscriptionException.NoInternet -> 6
    }

    // ---------------------------------------------------------------------------------------
    // The race
    // ---------------------------------------------------------------------------------------

    /**
     * Launches one coroutine per combination and returns as soon as the first one produces a
     * non-empty transcript; all others are cancelled immediately. When nobody wins, the collected
     * failures are returned. Every racer reports exactly one [Outcome] (or is cancelled), so the
     * collection loop can never hang.
     */
    private suspend fun race(combinations: List<Combination>, body: ByteArray): RaceResult = coroutineScope {
        val race = Race()
        activeRaces.add(race)
        val outcomes = Channel<Outcome>(Channel.UNLIMITED)
        try {
            val jobs: List<Job> = combinations.map { combination ->
                launch(Dispatchers.IO) {
                    outcomes.trySend(runRacer(race, combination, body))
                }
            }

            val failures = ArrayList<TranscriptionException>()
            repeat(combinations.size) {
                when (val outcome = outcomes.receive()) {
                    is Outcome.Success -> {
                        // Winner: kill every other in-flight request right away (HTTP level first).
                        race.cancelCalls()
                        jobs.forEach { it.cancel() }
                        return@coroutineScope RaceResult(outcome.response, emptyList())
                    }
                    is Outcome.Failure -> failures.add(outcome.error)
                }
            }
            if (race.cancelledByUser) throw CancellationException("Transcription cancelled by user")
            RaceResult(null, failures)
        } finally {
            race.cancelCalls() // no-op when already stopped; guarantees nothing outlives the race
            activeRaces.remove(race)
            outcomes.close()
        }
    }

    private suspend fun runRacer(race: Race, combination: Combination, body: ByteArray): Outcome {
        val request = Request.Builder()
            .url("$ENDPOINT/${combination.modelId}:generateContent?key=${combination.keyValue}")
            .post(body.toRequestBody(JSON_MEDIA_TYPE))
            .build()
        val call = raceClient.newCall(request)
        race.calls.add(call)
        if (race.stopped) call.cancel() // the race was decided while this call was being built

        return try {
            val (code, responseBody) = awaitResponse(call)
            interpret(combination, code, responseBody)
        } catch (e: CancellationException) {
            throw e
        } catch (e: UnknownHostException) {
            Outcome.Failure(TranscriptionException.NoInternet())
        } catch (e: SocketTimeoutException) {
            Outcome.Failure(TranscriptionException.ApiError("Connection timed out. Please try again."))
        } catch (e: IOException) {
            if (call.isCanceled()) {
                Outcome.Failure(TranscriptionException.ApiError("Request cancelled."))
            } else {
                Outcome.Failure(TranscriptionException.NoInternet())
            }
        } catch (e: Exception) {
            Outcome.Failure(TranscriptionException.ApiError(e.localizedMessage ?: "Transcription failed."))
        } finally {
            race.calls.remove(call)
        }
    }

    /** Suspends until the response arrives; cancelling the coroutine cancels the HTTP call itself. */
    private suspend fun awaitResponse(call: Call): Pair<Int, String> =
        suspendCancellableCoroutine { cont ->
            cont.invokeOnCancellation {
                try {
                    call.cancel()
                } catch (_: Exception) {
                }
            }
            call.enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    if (cont.isActive) cont.resumeWithException(e)
                }

                override fun onResponse(call: Call, response: Response) {
                    try {
                        response.use { r ->
                            val text = r.body?.string().orEmpty()
                            if (cont.isActive) cont.resume(r.code to text)
                        }
                    } catch (e: IOException) {
                        if (cont.isActive) cont.resumeWithException(e)
                    }
                }
            })
        }

    /** Maps an HTTP response onto an [Outcome]; marks the key exhausted on 429 / quota errors. */
    private fun interpret(combination: Combination, code: Int, responseBody: String): Outcome {
        if (code in 200..299) {
            val text = GeminiTranscriber.cleanExtractedTranscript(
                GeminiTranscriber.extractCandidatesText(responseBody)
            )
            return if (text.isEmpty()) {
                Outcome.Failure(TranscriptionException.EmptyResult())
            } else {
                Outcome.Success(
                    TranscriptionResponse(
                        text = text,
                        modelUsed = combination.modelId,
                        usedFallbackModel = false
                    )
                )
            }
        }

        val lower = responseBody.lowercase()
        return when {
            code == 404 -> Outcome.Failure(TranscriptionException.ModelNotFound(combination.modelId))

            code == 429 -> {
                markExhausted(combination)
                Outcome.Failure(TranscriptionException.QuotaExceeded())
            }

            code == 503 -> Outcome.Failure(TranscriptionException.ServiceUnavailable())

            code == 400 || code == 401 || code == 403 -> when {
                code == 401 || code == 403 ||
                    lower.contains("api_key_invalid") ||
                    lower.contains("api key not valid") ||
                    lower.contains("invalid api key") ->
                    Outcome.Failure(TranscriptionException.InvalidApiKey())

                lower.contains("not found") || lower.contains("is not found for api version") ->
                    Outcome.Failure(TranscriptionException.ModelNotFound(combination.modelId))

                else -> Outcome.Failure(
                    TranscriptionException.ApiError(
                        GeminiTranscriber.parseErrorMessage(responseBody) ?: "Request error ($code)."
                    )
                )
            }

            lower.contains("resource_exhausted") || lower.contains("rate limit") || lower.contains("quota") -> {
                markExhausted(combination)
                Outcome.Failure(TranscriptionException.QuotaExceeded())
            }

            else -> Outcome.Failure(
                TranscriptionException.ApiError(
                    GeminiTranscriber.parseErrorMessage(responseBody) ?: "Server error ($code)."
                )
            )
        }
    }

    private fun markExhausted(combination: Combination) {
        try {
            ApiKeyRepository.markKeyExhausted(combination.keyValue)
        } catch (_: Exception) {
            // Persisting the flag must never break the race.
        }
    }
}
