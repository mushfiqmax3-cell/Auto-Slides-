package com.example

import android.content.Context
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.StatusAmber
import com.example.ui.theme.StatusRed

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val entries by ApiKeyRepository.entriesFlow.collectAsState()
    val syncWithKeyboard by Prefs.syncKeyboardFlow.collectAsState()

    var showAddDialog by rememberSaveable { mutableStateOf(false) }
    var expandedId by rememberSaveable { mutableStateOf<String?>(null) }

    val activeCount = ApiKeyRepository.activeCombinationCount(entries)
    val overLimit = false // racing is unlimited: every active key + model runs concurrently

    // The transcription service still reads one global model; keep it aligned with the first usable key.
    LaunchedEffect(entries) { syncPrimaryModel(context, entries) }

    if (showAddDialog) {
        AddKeyDialog(
            onDismiss = { showAddDialog = false },
            onAdd = { name, key, model ->
                val added = ApiKeyRepository.add(key, name, model)
                if (added != null) {
                    expandedId = added.id
                    showAddDialog = false
                }
                added != null
            }
        )
    }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .widthIn(max = 600.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = MaterialTheme.colorScheme.onBackground
                    )
                }
                Text(
                    text = "Settings (সেটিংস)",
                    color = MaterialTheme.colorScheme.onBackground,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Gemini API Keys (এপিআই কী)",
                    color = MaterialTheme.colorScheme.onBackground,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium
                )
                Button(
                    onClick = { showAddDialog = true },
                    modifier = Modifier.testTag("add_key_button")
                ) {
                    Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add Key")
                }
            }

            if (entries.isEmpty()) {
                Text(
                    text = "No API key yet. Tap Add Key to paste one (কোনো কী নেই)",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 13.sp
                )
            } else {
                Text(
                    text = "Active Key + Model pairs: $activeCount",
                    color = if (overLimit) StatusAmber else MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            if (overLimit) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(
                        imageVector = Icons.Filled.Warning,
                        contentDescription = "Warning",
                        tint = StatusAmber,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Warning: $activeCount active keys exceed the limit of " +
                            "${ApiKeyRepository.MAX_CONCURRENT_CALLS} concurrent calls. " +
                            "Extra calls may hit rate limits. Mark some keys as " +
                            "exhausted or delete them (সীমা পেরিয়ে গেছে)",
                        color = StatusAmber,
                        fontSize = 13.sp,
                        modifier = Modifier.testTag("concurrency_warning")
                    )
                }
            }

            entries.forEach { entry ->
                ApiKeyCard(
                    entry = entry,
                    expanded = expandedId == entry.id,
                    onToggleExpand = { expandedId = if (expandedId == entry.id) null else entry.id },
                    onDeleted = { if (expandedId == entry.id) expandedId = null }
                )
            }

            Text(
                text = "Each key races with its own selected model. Exhausted keys are skipped " +
                    "(প্রতিটি কী নিজের সিলেক্ট করা মডেল দিয়ে রেস করবে)",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 12.sp
            )

            if (entries.any { it.isExhausted }) {
                TextButton(onClick = { ApiKeyRepository.resetAllExhausted() }) {
                    Text("Reset all exhausted keys (সব কী আবার চালু করুন)")
                }
            }

            Spacer(modifier = Modifier.height(4.dp))
            HorizontalDivider()
            Spacer(modifier = Modifier.height(4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Sync with Keyboard (কীবোর্ডের সাথে সিঙ্ক)",
                        color = MaterialTheme.colorScheme.onBackground,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "Show the floating mic only while a text field is focused. Requires the Accessibility service.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 13.sp
                    )
                }
                Switch(
                    checked = syncWithKeyboard,
                    onCheckedChange = { Prefs.saveSyncWithKeyboard(context, it) },
                    modifier = Modifier.testTag("sync_keyboard_switch")
                )
            }
        }
    }
}

@Composable
private fun ApiKeyCard(
    entry: ApiKeyEntry,
    expanded: Boolean,
    onToggleExpand: () -> Unit,
    onDeleted: () -> Unit
) {
    var nameInput by remember(entry.id) { mutableStateOf(entry.displayName) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("api_key_row"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onToggleExpand),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = entry.displayName,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = maskApiKey(entry.keyValue),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 12.sp
                    )
                    Text(
                        text = entry.selectedModel +
                            if (entry.isExhausted) " • Exhausted (কোটা শেষ)" else "",
                        color = if (entry.isExhausted) StatusRed else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 12.sp
                    )
                }
                Icon(
                    imageVector = if (expanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                    contentDescription = if (expanded) "Collapse" else "Expand",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (expanded) {
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = nameInput,
                    onValueChange = {
                        nameInput = it
                        if (it.isNotBlank()) ApiKeyRepository.rename(entry.id, it)
                    },
                    label = { Text("Name (নাম)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                ModelPicker(
                    apiKey = entry.keyValue,
                    selected = entry.selectedModel,
                    autoLoad = true,
                    onSelect = { ApiKeyRepository.updateModel(entry.id, it) }
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Mark as exhausted (কোটা শেষ)",
                        color = MaterialTheme.colorScheme.onSurface,
                        fontSize = 14.sp,
                        modifier = Modifier.weight(1f)
                    )
                    Switch(
                        checked = entry.isExhausted,
                        onCheckedChange = { ApiKeyRepository.setExhausted(entry.id, it) }
                    )
                }
                TextButton(
                    onClick = {
                        ApiKeyRepository.delete(entry.id)
                        onDeleted()
                    }
                ) {
                    Icon(Icons.Filled.Delete, contentDescription = null, tint = StatusRed)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Delete key", color = StatusRed)
                }
            }
        }
    }
}

/**
 * Dropdown of the models the given key can use (`GET /v1beta/models?key=...`, filtered to
 * `generateContent`). The currently selected model is always listed, even if loading fails.
 */
@Composable
private fun ModelPicker(
    apiKey: String,
    selected: String,
    autoLoad: Boolean,
    onSelect: (String) -> Unit
) {
    val scope = rememberCoroutineScope()
    var models by remember(apiKey) { mutableStateOf<List<String>>(emptyList()) }
    var loading by remember(apiKey) { mutableStateOf(false) }
    var error by remember(apiKey) { mutableStateOf<String?>(null) }
    var open by remember { mutableStateOf(false) }

    fun load() {
        if (apiKey.isBlank() || loading) return
        loading = true
        error = null
        scope.launch {
            GeminiTranscriber.fetchAvailableModels(apiKey)
                .onSuccess { models = it }
                .onFailure { error = it.message ?: "Could not load models." }
            loading = false
        }
    }

    LaunchedEffect(apiKey, autoLoad) { if (autoLoad) load() }

    val options = (listOf(selected) + models).filter { it.isNotBlank() }.distinct()

    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(
            text = "Model (মডেল)",
            color = MaterialTheme.colorScheme.onSurface,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium
        )
        Box {
            OutlinedTextField(
                value = selected,
                onValueChange = {},
                readOnly = true,
                singleLine = true,
                label = { Text("Selected model") },
                trailingIcon = {
                    if (loading) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    } else {
                        Icon(
                            if (open) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                            contentDescription = "Choose model"
                        )
                    }
                },
                modifier = Modifier.fillMaxWidth().testTag("model_dropdown")
            )
            // Transparent click-catcher over the read-only field.
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .clickable(enabled = !loading) {
                        if (models.isEmpty()) load()
                        open = true
                    }
            )
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                options.forEach { id ->
                    DropdownMenuItem(
                        text = { Text(id, fontSize = 14.sp) },
                        onClick = {
                            onSelect(id)
                            open = false
                        }
                    )
                }
            }
        }
        TextButton(onClick = { load() }, enabled = !loading && apiKey.isNotBlank()) {
            Text(if (models.isEmpty()) "Load models (মডেল লোড করুন)" else "Reload models (${models.size})")
        }
        error?.let { Text(text = it, color = StatusRed, fontSize = 12.sp) }
    }
}

@Composable
private fun AddKeyDialog(
    onDismiss: () -> Unit,
    onAdd: (name: String, key: String, model: String) -> Boolean
) {
    var name by rememberSaveable { mutableStateOf("") }
    var key by rememberSaveable { mutableStateOf("") }
    var model by rememberSaveable { mutableStateOf(Prefs.DEFAULT_MODEL_NAME) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add API Key") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Name (optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = key,
                    onValueChange = {
                        key = it
                        error = null
                    },
                    label = { Text("Paste Gemini API key") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("api_key_field")
                )
                ModelPicker(
                    apiKey = key.trim(),
                    selected = model,
                    autoLoad = false,
                    onSelect = { model = it }
                )
                error?.let { Text(text = it, color = StatusRed, fontSize = 12.sp) }
            }
        },
        confirmButton = {
            TextButton(
                enabled = key.isNotBlank() && model.isNotBlank(),
                onClick = {
                    if (!onAdd(name, key, model)) {
                        error = "Key already exists or is invalid (কী আগে থেকেই আছে)"
                    }
                }
            ) { Text("Add") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

private fun syncPrimaryModel(context: Context, entries: List<ApiKeyEntry>) {
    val source = entries.firstOrNull { !it.isExhausted } ?: entries.firstOrNull() ?: return
    if (Prefs.getModelName(context) != source.selectedModel) {
        Prefs.saveModelName(context, source.selectedModel)
    }
}

/** `AIzaSy...4xK9` style mask: first 6 and last 4 characters only. */
internal fun maskApiKey(key: String): String =
    if (key.length <= 12) "••••••" else key.take(6) + "..." + key.takeLast(4)
