package com.example

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RacingTranscriberTest {

    private val flash = "gemini-1.5-flash"
    private val lite = "gemini-3.5-flash-lite"

    private fun entry(id: String, model: String, exhausted: Boolean = false) = ApiKeyEntry(
        id = id,
        displayName = id,
        keyValue = "key-$id",
        isExhausted = exhausted,
        selectedModel = model
    )

    @Test
    fun skipsExhaustedKeys() {
        val result = RacingTranscriber.selectCombinations(
            listOf(entry("a", flash, exhausted = true), entry("b", flash))
        )
        assertEquals(listOf(RacingTranscriber.Combination("key-b", flash)), result)
    }

    @Test
    fun allExhaustedFallsBackToEveryKey() {
        val result = RacingTranscriber.selectCombinations(
            listOf(entry("a", flash, true), entry("b", lite, true))
        )
        assertEquals(2, result.size)
    }

    @Test
    fun eachKeyIsPairedWithItsOwnModel() {
        val result = RacingTranscriber.selectCombinations(listOf(entry("a", flash), entry("b", lite)))
        assertEquals(
            listOf(
                RacingTranscriber.Combination("key-a", flash),
                RacingTranscriber.Combination("key-b", lite)
            ),
            result
        )
    }

    @Test
    fun isUnlimited() {
        val entries = (1..8).map { entry("k$it", flash) }
        assertEquals(8, RacingTranscriber.selectCombinations(entries).size)
    }

    @Test
    fun rotationShiftsStartingKeyWhenOverLimit() {
        val entries = (1..6).map { entry("k$it", flash) }
        val first = RacingTranscriber.selectCombinations(entries, startOffset = 0).map { it.keyValue }
        val shifted = RacingTranscriber.selectCombinations(entries, startOffset = 3).map { it.keyValue }
        assertEquals(6, first.size)
        assertEquals(6, shifted.size)
        assertEquals(first.toSet(), shifted.toSet())
    }

    @Test
    fun emptyInputGivesEmptyList() {
        assertTrue(RacingTranscriber.selectCombinations(emptyList()).isEmpty())
    }

    @Test
    fun pickErrorPrefersEmptyResultThenServerProblems() {
        val e = RacingTranscriber.pickError(
            listOf(
                TranscriptionException.NoInternet(),
                TranscriptionException.QuotaExceeded(),
                TranscriptionException.EmptyResult()
            )
        )
        assertTrue(e is TranscriptionException.EmptyResult)

        val q = RacingTranscriber.pickError(
            listOf(TranscriptionException.NoInternet(), TranscriptionException.QuotaExceeded())
        )
        assertTrue(q is TranscriptionException.QuotaExceeded)
    }
}
