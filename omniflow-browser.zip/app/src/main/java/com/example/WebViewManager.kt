package com.example

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.MutableContextWrapper
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Looper
import android.os.Message
import android.os.Parcel
import android.print.PrintAttributes
import android.print.PrintManager
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.RenderProcessGoneDetail
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.compose.runtime.Immutable
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.webkit.ServiceWorkerControllerCompat
import androidx.webkit.UserAgentMetadata
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import com.example.data.BookmarkEntity
import com.example.data.BrowserDatabase
import com.example.data.BrowserPreferences
import com.example.data.BrowserRepository
import com.example.data.BrowserSettings
import com.example.data.DownloadEntity
import com.example.data.DownloadStatus
import com.example.data.FrameRateMode
import com.example.data.HistoryEntity
import com.example.data.HomepageMode
import com.example.data.InstalledWebAppEntity
import com.example.data.SavedTabEntity
import com.example.data.SearchEngine
import com.example.data.ThemeMode
import java.io.ByteArrayInputStream
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

@Immutable
data class BrowserTabModel(
    val id: Int,
    val slotTitle: String,
    val pageTitle: String = "New Tab",
    val url: String = WebViewManager.NEW_TAB_URL,
    val favicon: Bitmap? = null,
    val thumbnail: Bitmap? = null,
    val isDesktopMode: Boolean = false,
    val isIncognito: Boolean = false,
    val canGoBack: Boolean = false,
    val canGoForward: Boolean = false,
    val isSslSecure: Boolean = true,
    val lastKeepAlivePulseMs: Long = System.currentTimeMillis()
)

data class OAuthPopupSession(
    val id: Long = System.currentTimeMillis(),
    val parentTabId: Int,
    val url: String = "https://accounts.google.com/",
    val title: String = "Sign in with Google",
    val isLoading: Boolean = true,
    val progress: Int = 15,
    val popupWebView: WebView
)

data class FindInPageState(
    val isVisible: Boolean = false,
    val query: String = "",
    val activeMatchIndex: Int = 0,
    val totalMatches: Int = 0
)

data class WebContextMenuTarget(
    val linkUrl: String? = null,
    val imageUrl: String? = null,
    val title: String = ""
)

/**
 * Custom WebView subclass engineered to bypass Chromium's WindowVisibility and PageVisibility
 * background throttling. Always reports View.VISIBLE to the internal Blink compositor even when
 * the app is minimized or the display is turned off.
 */
@SuppressLint("ViewConstructor")
class UnthrottledWebView(context: Context) : WebView(context) {

    var allowExplicitDestroy: Boolean = false
    var onUserTap: (() -> Unit)? = null

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent?): Boolean {
        if (event?.actionMasked == MotionEvent.ACTION_UP) {
            onUserTap?.invoke()
        }
        return super.onTouchEvent(event)
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(View.VISIBLE)
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, View.VISIBLE)
    }

    override fun onPause() {
        if (allowExplicitDestroy) {
            super.onPause()
        }
    }

    override fun pauseTimers() {
        if (allowExplicitDestroy) {
            super.pauseTimers()
        }
    }
}

class WebViewManager(private val appContext: Context) {

    private val contextWrappers = LinkedHashMap<Int, MutableContextWrapper>()
    private val webViews = LinkedHashMap<Int, UnthrottledWebView>()
    internal var currentActivity: Activity? = null

    val repository = BrowserRepository(BrowserDatabase.getInstance(appContext))
    val preferences = BrowserPreferences(appContext)
    private val ioScope = kotlinx.coroutines.CoroutineScope(
        kotlinx.coroutines.SupervisorJob() + Dispatchers.IO
    )
    private val mainScope = kotlinx.coroutines.CoroutineScope(
        kotlinx.coroutines.SupervisorJob() + Dispatchers.Main
    )

    @Volatile
    var currentSettings: BrowserSettings = BrowserSettings()
        private set

    // Single persistent FrameLayout hosting all active WebViews simultaneously
    val persistentContainer: FrameLayout = FrameLayout(appContext).apply {
        layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        keepScreenOn = true
    }

    private val _tabsState = MutableStateFlow<List<BrowserTabModel>>(emptyList())
    val tabsState: StateFlow<List<BrowserTabModel>> = _tabsState.asStateFlow()

    private val _activeTabId = MutableStateFlow(1)
    val activeTabId: StateFlow<Int> = _activeTabId.asStateFlow()

    private val tabProgressMap = LinkedHashMap<Int, Int>()
    private val tabLoadingMap = LinkedHashMap<Int, Boolean>()
    private val tabUserMediaUnlocked = ConcurrentHashMap<Int, Boolean>()
    private val tabInitialUrlLoaded = ConcurrentHashMap<Int, Boolean>()

    private val _activeTabProgress = MutableStateFlow(0)
    val activeTabProgress: StateFlow<Int> = _activeTabProgress.asStateFlow()

    private val _activeTabIsLoading = MutableStateFlow(false)
    val activeTabIsLoading: StateFlow<Boolean> = _activeTabIsLoading.asStateFlow()

    private val _oauthPopupState = MutableStateFlow<OAuthPopupSession?>(null)
    val oauthPopupState: StateFlow<OAuthPopupSession?> = _oauthPopupState.asStateFlow()

    private val _pendingDownload = MutableStateFlow<PendingDownloadRequest?>(null)
    val pendingDownload: StateFlow<PendingDownloadRequest?> = _pendingDownload.asStateFlow()

    private val _findInPageState = MutableStateFlow(FindInPageState())
    val findInPageState: StateFlow<FindInPageState> = _findInPageState.asStateFlow()

    private val _contextMenuTarget = MutableStateFlow<WebContextMenuTarget?>(null)
    val contextMenuTarget: StateFlow<WebContextMenuTarget?> = _contextMenuTarget.asStateFlow()

    private val _isGoogleSignedIn = MutableStateFlow(false)
    val isGoogleSignedIn: StateFlow<Boolean> = _isGoogleSignedIn.asStateFlow()

    private val _openDownloadsSheetRequested = MutableStateFlow(false)
    val openDownloadsSheetRequested: StateFlow<Boolean> = _openDownloadsSheetRequested.asStateFlow()

    private val _recentlyClosedTabs = MutableStateFlow<List<BrowserTabModel>>(emptyList())
    val recentlyClosedTabs: StateFlow<List<BrowserTabModel>> = _recentlyClosedTabs.asStateFlow()

    private val _aiStudioPermissionErrorDetected = MutableStateFlow(false)
    val aiStudioPermissionErrorDetected: StateFlow<Boolean> = _aiStudioPermissionErrorDetected.asStateFlow()

    private val sessionPrefs = appContext.getSharedPreferences(TAB_SESSION_PREFS_NAME, Context.MODE_PRIVATE)
    private val bundleDir: File by lazy {
        File(appContext.filesDir, "webview_tab_bundles").apply { mkdirs() }
    }

    fun requestOpenDownloadsSheet() {
        _openDownloadsSheetRequested.value = true
    }

    fun consumeOpenDownloadsSheetRequest() {
        _openDownloadsSheetRequested.value = false
    }

    fun dismissAiStudioPermissionBanner() {
        _aiStudioPermissionErrorDetected.value = false
    }

    // File Chooser & WebRTC/Geolocation Permission bridges connected to MainActivity
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var activeFileChooserSession: ChromeFileChooserSession? = null
    var onLaunchFileChooser: ((Intent) -> Boolean)? = null

    var onRequestRuntimePermissions: ((Array<String>, (Boolean) -> Unit) -> Unit)? = null

    private var nextTabId = 1

    private val downloadBridge: StudioDownloadBridge = StudioDownloadBridge(
        context = appContext,
        repository = repository,
        onPendingDownloadFromJs = { url, suggestedName, mimeType, contentLength, pageUrl ->
            mainScope.launch {
                val activeId = _activeTabId.value
                val activeTab = _tabsState.value.find { it.id == activeId }
                val ua = if (activeTab?.isDesktopMode == true) {
                    getSanitizedDesktopUserAgent(appContext)
                } else {
                    getSanitizedMobileUserAgent(appContext)
                }
                val destination = currentDownloadDestination()
                val req = PendingDownloadRequest(
                    url = url,
                    userAgent = ua,
                    contentDisposition = "",
                    mimeType = mimeType,
                    contentLength = contentLength,
                    suggestedFileName = suggestedName,
                    defaultDestination = destination,
                    refererUrl = pageUrl.ifBlank { activeTab?.url.orEmpty() },
                    sourceTabId = activeId
                )
                if (currentSettings.askBeforeDownload) {
                    _pendingDownload.value = req
                } else {
                    executeDownloadRequest(req, suggestedName, destination)
                }
            }
        },
        onUpgradePendingDownload = { url, upgradedFileName, upgradedMimeType, contentLength ->
            mainScope.launch {
                _pendingDownload.update { current ->
                    if (current != null && current.url == url) {
                        current.copy(
                            suggestedFileName = upgradedFileName.ifBlank { current.suggestedFileName },
                            mimeType = upgradedMimeType.ifBlank { current.mimeType },
                            contentLength = if (contentLength > 0L) contentLength else current.contentLength
                        )
                    } else {
                        current
                    }
                }
            }
        },
        onAiStudioPermissionError = { hasError ->
            mainScope.launch {
                _aiStudioPermissionErrorDetected.value = hasError
            }
        },
        onBase64Saved = { fileName, url, mimeType, uriStr, sizeBytes, folderLabel ->
            ioScope.launch {
                repository.insertDownload(
                    DownloadEntity(
                        systemDownloadId = -1L,
                        fileName = fileName,
                        url = url,
                        mimeType = mimeType,
                        localUri = uriStr,
                        status = DownloadStatus.SUCCESSFUL,
                        totalBytes = sizeBytes,
                        downloadedBytes = sizeBytes,
                        saveFolderLabel = folderLabel
                    )
                )
            }
        }
    )

    init {
        prepareCleanVariationsState(appContext)
        configureGlobalCookieManager()
        cleanupStaleGoogleBundlesOnce()
        initializeOrRestoreTabs()
        ioScope.launch {
            repository.ensureStarterBookmarks()
            // If SharedPreferences had no saved tabs on cold boot, check Room SQLite saved_tabs as backup
            if (!sessionPrefs.contains(KEY_SAVED_TABS_JSON)) {
                val roomSaved = try {
                    repository.getSavedTabs()
                } catch (_: Exception) {
                    emptyList()
                }
                if (roomSaved.isNotEmpty()) {
                    mainScope.launch {
                        val currentTabs = _tabsState.value
                        if (currentTabs.size == 1 && currentTabs.first().url == NEW_TAB_URL) {
                            restoreTabsFromRoomEntities(roomSaved)
                        }
                    }
                }
            }
            preferences.settingsFlow.collectLatest { latest ->
                currentSettings = latest
                PwaWebViewPool.setKeepAliveEnabled(latest.keepPwasAliveInRam, appContext)
                mainScope.launch {
                    applySettingsToAllWebViews(latest)
                }
            }
        }
        refreshGoogleSignInStatus()
    }

    private fun cleanupStaleGoogleBundlesOnce() {
        try {
            if (!sessionPrefs.getBoolean(KEY_PURGED_STALE_BUNDLES_V4, false)) {
                bundleDir.listFiles()?.forEach { file ->
                    try {
                        file.delete()
                    } catch (_: Exception) {
                    }
                }
                sessionPrefs.edit()
                    .putBoolean(KEY_PURGED_STALE_BUNDLES_V2, true)
                    .putBoolean(KEY_PURGED_STALE_BUNDLES_V4, true)
                    .apply()
            }
        } catch (_: Exception) {
        }
    }

    private fun configureGlobalCookieManager() {
        try {
            val cookieManager = CookieManager.getInstance()
            cookieManager.setAcceptCookie(true)
        } catch (_: Throwable) {
        }
        try {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.SERVICE_WORKER_BASIC_USAGE)) {
                val swSettings = ServiceWorkerControllerCompat.getInstance().serviceWorkerWebSettings
                if (WebViewFeature.isFeatureSupported(WebViewFeature.SERVICE_WORKER_CONTENT_ACCESS)) {
                    swSettings.allowContentAccess = true
                }
                if (WebViewFeature.isFeatureSupported(WebViewFeature.SERVICE_WORKER_FILE_ACCESS)) {
                    swSettings.allowFileAccess = true
                }
                if (WebViewFeature.isFeatureSupported(WebViewFeature.SERVICE_WORKER_BLOCK_NETWORK_LOADS)) {
                    swSettings.blockNetworkLoads = false
                }
            }
        } catch (_: Throwable) {
        }
        ioScope.launch {
            try {
                CookieManager.getInstance().flush()
            } catch (_: Throwable) {
            }
        }
    }

    fun refreshGoogleSignInStatus() {
        ioScope.launch {
            try {
                val cookieManager = CookieManager.getInstance()
                val accountsCookies = cookieManager.getCookie("https://accounts.google.com").orEmpty()
                val googleCookies = cookieManager.getCookie("https://www.google.com").orEmpty()
                val combined = "$accountsCookies;$googleCookies"
                val signedIn = combined.contains("SID=") ||
                    combined.contains("HSID=") ||
                    combined.contains("SAPISID=") ||
                    combined.contains("__Secure-1PSID=")
                _isGoogleSignedIn.value = signedIn
            } catch (_: Exception) {
                _isGoogleSignedIn.value = false
            }
        }
    }

    /**
     * Restores the user's previously open tabs from persistent storage so closing the browser
     * from the background never deletes open tabs. If no tabs were saved yet, starts cleanly
     * with 1 single New Tab (`about:newtab` Start Page) instead of forcing 5 AI Studio tabs.
     */
    fun initializeOrRestoreTabs() {
        if (webViews.isNotEmpty()) return
        restoreRecentlyClosedTabsFromPrefs()

        val savedTabsJson = sessionPrefs.getString(KEY_SAVED_TABS_JSON, null)
        val savedActiveId = sessionPrefs.getInt(KEY_ACTIVE_TAB_ID, -1)
        val restoredTabs = parseSavedTabsJson(savedTabsJson)

        val initialTabs = if (restoredTabs.isNotEmpty()) {
            val maxId = restoredTabs.maxOf { it.id }
            nextTabId = maxOf(sessionPrefs.getInt(KEY_NEXT_TAB_ID, maxId + 1), maxId + 1)
            restoredTabs
        } else {
            val tabId = nextTabId++
            listOf(
                BrowserTabModel(
                    id = tabId,
                    slotTitle = "Tab 1",
                    pageTitle = "New Tab",
                    url = NEW_TAB_URL
                )
            )
        }

        val targetActiveId = if (initialTabs.any { it.id == savedActiveId }) {
            savedActiveId
        } else {
            initialTabs.first().id
        }

        _tabsState.value = initialTabs
        _activeTabId.value = targetActiveId

        val needsOneTimeCacheRefresh = !sessionPrefs.getBoolean(KEY_CLEANED_HTTP_CACHE_V4, false)

        initialTabs.forEach { tab ->
            tabProgressMap[tab.id] = if (tab.url == NEW_TAB_URL) 100 else 0
            tabLoadingMap[tab.id] = tab.url != NEW_TAB_URL
            val webView = createConfiguredWebView(
                tabId = tab.id,
                isDesktop = tab.isDesktopMode,
                isIncognito = tab.isIncognito
            )
            webViews[tab.id] = webView
            persistentContainer.addView(
                webView,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            )
        }

        if (needsOneTimeCacheRefresh) {
            try {
                webViews[targetActiveId]?.clearCache(true)
            } catch (_: Throwable) {
            }
            sessionPrefs.edit().putBoolean(KEY_CLEANED_HTTP_CACHE_V4, true).apply()
        }

        // Load active tab immediately, and stagger background tabs like Chrome/Brave so
        // the active tab completes its Google OAuth / RotateCookies handshake cleanly first
        // before background tabs connect and stay live in the background.
        var bgIndex = 0
        initialTabs.forEach { tab ->
            val webView = webViews[tab.id] ?: return@forEach
            if (tab.url == NEW_TAB_URL) {
                tabInitialUrlLoaded[tab.id] = true
            } else if (tab.id == targetActiveId) {
                tabInitialUrlLoaded[tab.id] = true
                if (!restoreWebViewBundleIfPresent(tab.id, webView, tab.url)) {
                    webView.loadUrl(tab.url)
                }
            } else {
                bgIndex++
                val delayMs = if (isDynamicAuthSpaUrl(tab.url)) {
                    bgIndex * 2400L
                } else {
                    bgIndex * 600L
                }
                mainScope.launch {
                    delay(delayMs)
                    if (webViews[tab.id] === webView && tabInitialUrlLoaded[tab.id] != true) {
                        tabInitialUrlLoaded[tab.id] = true
                        if (!restoreWebViewBundleIfPresent(tab.id, webView, tab.url)) {
                            webView.loadUrl(tab.url)
                        }
                    }
                }
            }
        }

        applyZeroReloadVisibilityStack(targetActiveId)
        persistSessionStateSync(commitImmediately = false, saveWebViewBundles = false)
    }

    private fun restoreTabsFromRoomEntities(entities: List<SavedTabEntity>) {
        if (entities.isEmpty()) return
        webViews.values.forEach { webView ->
            try {
                webView.allowExplicitDestroy = true
                persistentContainer.removeView(webView)
                webView.stopLoading()
                webView.destroy()
            } catch (_: Exception) {
            }
        }
        webViews.clear()
        contextWrappers.clear()
        tabProgressMap.clear()
        tabLoadingMap.clear()
        tabInitialUrlLoaded.clear()
        tabUserMediaUnlocked.clear()

        val restored = entities.map { entity ->
            BrowserTabModel(
                id = entity.tabId,
                slotTitle = entity.slotTitle.ifBlank { "Tab ${entity.tabId}" },
                pageTitle = entity.pageTitle.ifBlank { "New Tab" },
                url = entity.url.ifBlank { NEW_TAB_URL },
                isDesktopMode = entity.isDesktopMode,
                isSslSecure = entity.url.startsWith("https://") || entity.url == NEW_TAB_URL
            )
        }
        val maxId = restored.maxOf { it.id }
        nextTabId = maxId + 1
        val activeId = entities.firstOrNull { it.isActive }?.tabId ?: restored.first().id

        _tabsState.value = restored
        _activeTabId.value = activeId

        restored.forEach { tab ->
            tabProgressMap[tab.id] = if (tab.url == NEW_TAB_URL) 100 else 0
            tabLoadingMap[tab.id] = tab.url != NEW_TAB_URL
            val webView = createConfiguredWebView(
                tabId = tab.id,
                isDesktop = tab.isDesktopMode,
                isIncognito = false
            )
            webViews[tab.id] = webView
            persistentContainer.addView(
                webView,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            )
            if (tab.url != NEW_TAB_URL) {
                tabInitialUrlLoaded[tab.id] = true
                if (!restoreWebViewBundleIfPresent(tab.id, webView, tab.url)) {
                    webView.loadUrl(tab.url)
                }
            } else {
                tabInitialUrlLoaded[tab.id] = true
            }
        }
        applyZeroReloadVisibilityStack(activeId)
        persistSessionStateSync(commitImmediately = true, saveWebViewBundles = false)
    }

    fun initializeDefaultFiveTabs() {
        if (webViews.isNotEmpty()) return
        val initialTabs = mutableListOf<BrowserTabModel>()
        for (i in 1..5) {
            val tabId = nextTabId++
            val slotTitle = "Studio $i"
            val tabModel = BrowserTabModel(
                id = tabId,
                slotTitle = slotTitle,
                pageTitle = "$slotTitle • AI Studio",
                url = DEFAULT_HOME_URL
            )
            initialTabs.add(tabModel)
            tabProgressMap[tabId] = 0
            tabLoadingMap[tabId] = true
        }
        _tabsState.value = initialTabs
        _activeTabId.value = initialTabs.first().id

        initialTabs.forEachIndexed { index, tab ->
            val webView = createConfiguredWebView(
                tabId = tab.id,
                isDesktop = tab.isDesktopMode,
                isIncognito = tab.isIncognito
            )
            webViews[tab.id] = webView
            persistentContainer.addView(
                webView,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            )
            if (index == 0) {
                tabInitialUrlLoaded[tab.id] = true
                webView.loadUrl(tab.url)
            } else {
                mainScope.launch {
                    delay(index * 700L)
                    if (webViews[tab.id] === webView && tabInitialUrlLoaded[tab.id] != true) {
                        tabInitialUrlLoaded[tab.id] = true
                        webView.loadUrl(tab.url)
                    }
                }
            }
        }

        applyZeroReloadVisibilityStack(_activeTabId.value)
        persistSessionStateSync(commitImmediately = true, saveWebViewBundles = false)
    }

    fun attachActivity(activity: Activity) {
        currentActivity = activity
        contextWrappers.values.forEach { wrapper ->
            wrapper.baseContext = activity
        }
        webViews.values.forEach { webView ->
            webView.onResume()
            webView.resumeTimers()
        }
        val activePopup = _oauthPopupState.value?.popupWebView
        if (activePopup != null) {
            try {
                (activePopup.context as? MutableContextWrapper)?.baseContext = activity
                activePopup.onResume()
                activePopup.resumeTimers()
                activePopup.evaluateJavascript(
                    "try { window.dispatchEvent(new Event('focus')); window.dispatchEvent(new Event('online')); } catch(e) {}",
                    null
                )
            } catch (_: Exception) {
            }
        }
        val activeWebView = webViews[_activeTabId.value]
        if (activeWebView != null) {
            try {
                activeWebView.evaluateJavascript(
                    "try { window.dispatchEvent(new Event('focus')); window.dispatchEvent(new Event('online')); } catch(e) {}",
                    null
                )
            } catch (_: Exception) {
            }
        }
        refreshGoogleSignInStatus()
    }

    fun detachActivity(activity: Activity) {
        if (currentActivity === activity) {
            currentActivity = null
            contextWrappers.values.forEach { wrapper ->
                wrapper.baseContext = appContext
            }
            val activePopup = _oauthPopupState.value?.popupWebView
            if (activePopup != null) {
                (activePopup.context as? MutableContextWrapper)?.baseContext = appContext
            }
        }
        flushCookiesNow()
    }

    fun selectTab(tabId: Int) {
        val targetWebView = webViews[tabId] ?: return
        _activeTabId.value = tabId
        _activeTabProgress.value = tabProgressMap[tabId] ?: 0
        _activeTabIsLoading.value = tabLoadingMap[tabId] ?: false
        if (tabInitialUrlLoaded[tabId] != true) {
            val pendingUrl = _tabsState.value.find { it.id == tabId }?.url
            if (!pendingUrl.isNullOrBlank() && pendingUrl != NEW_TAB_URL) {
                tabInitialUrlLoaded[tabId] = true
                targetWebView.loadUrl(pendingUrl)
            }
        }
        clearFindInPage()
        applyZeroReloadVisibilityStack(tabId)
        persistSessionStateSync(commitImmediately = false, saveWebViewBundles = false)
    }

    fun switchTabByDelta(delta: Int) {
        val list = _tabsState.value
        if (list.size <= 1) return
        val currentIdx = list.indexOfFirst { it.id == _activeTabId.value }
        if (currentIdx == -1) return
        val targetIdx = (currentIdx + delta).coerceIn(0, list.lastIndex)
        if (targetIdx != currentIdx) {
            selectTab(list[targetIdx].id)
        }
    }

    private fun applyZeroReloadVisibilityStack(activeId: Int) {
        val topChildIndex = persistentContainer.childCount - 1
        val topChild = if (topChildIndex >= 0) persistentContainer.getChildAt(topChildIndex) else null

        webViews.forEach { (id, webView) ->
            if (webView.visibility != View.VISIBLE) {
                webView.visibility = View.VISIBLE
            }
            if (webView.layerType != View.LAYER_TYPE_NONE) {
                webView.setLayerType(View.LAYER_TYPE_NONE, null)
            }
            val isActive = (id == activeId)
            if (isActive) {
                if (webView.alpha != 1.0f) webView.alpha = 1.0f
                if (webView.translationX != 0f) webView.translationX = 0f
                if (webView.translationZ != 10f) webView.translationZ = 10f
                webView.isFocusable = true
                webView.isFocusableInTouchMode = true
                if (topChild !== webView) {
                    webView.bringToFront()
                }
                webView.requestFocus()
                if (tabInitialUrlLoaded[id] == true) {
                    try {
                        webView.evaluateJavascript("window.__studioTabIsActive = true;", null)
                    } catch (_: Exception) {
                    }
                }
            } else {
                val wasVisible = webView.alpha > 0f
                // alpha = 0f skips HWUI RenderThread layer syncing for offscreen WebViews while keeping View.VISIBLE
                if (webView.alpha != 0f) webView.alpha = 0f
                if (webView.translationX != 10_000f) webView.translationX = 10_000f
                if (webView.translationZ != 0f) webView.translationZ = 0f
                if (wasVisible && tabInitialUrlLoaded[id] == true) {
                    try {
                        webView.evaluateJavascript(PAUSE_VIDEO_ONLY_JS, null)
                    } catch (_: Exception) {
                    }
                }
            }
        }
    }

    fun openNewTab(
        initialUrl: String = NEW_TAB_URL,
        isIncognito: Boolean = false
    ): Boolean {
        val currentList = _tabsState.value
        if (currentList.size >= MAX_TAB_COUNT) {
            Toast.makeText(
                currentActivity ?: appContext,
                "Maximum $MAX_TAB_COUNT open tabs reached",
                Toast.LENGTH_SHORT
            ).show()
            return false
        }
        val tabId = nextTabId++
        val label = if (isIncognito) "Incognito" else "Tab $tabId"
        val title = if (initialUrl == NEW_TAB_URL) {
            if (isIncognito) "Incognito Tab" else "New Tab"
        } else {
            label
        }

        val newTab = BrowserTabModel(
            id = tabId,
            slotTitle = label,
            pageTitle = title,
            url = initialUrl,
            isIncognito = isIncognito
        )
        tabProgressMap[tabId] = 0
        tabLoadingMap[tabId] = initialUrl != NEW_TAB_URL

        val webView = createConfiguredWebView(
            tabId = tabId,
            isDesktop = false,
            isIncognito = isIncognito
        )
        webViews[tabId] = webView
        persistentContainer.addView(
            webView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        _tabsState.update { it + newTab }
        selectTab(tabId)
        if (initialUrl != NEW_TAB_URL) {
            tabInitialUrlLoaded[tabId] = true
            webView.loadUrl(initialUrl)
            if (!isIncognito && initialUrl.startsWith("http")) {
                ioScope.launch {
                    repository.recordHistory(title = title, url = initialUrl)
                }
            }
        } else {
            tabInitialUrlLoaded[tabId] = true
        }
        persistSessionStateSync(commitImmediately = true, saveWebViewBundles = false)
        BrowserService.startKeepAliveService(appContext, _tabsState.value.size)
        return true
    }

    fun addNewStudioTab(): Boolean = openNewTab(initialUrl = DEFAULT_HOME_URL, isIncognito = false)

    /**
     * Reuses an already-open live tab matching the target URL (zero reload) when launched from
     * a Home Screen Website Shortcut; opens a new tab only if not already loaded.
     */
    fun focusOrOpenTab(rawUrl: String) {
        val target = normalizeUrlOrSearchQuery(rawUrl).trimEnd('/')
        val existing = _tabsState.value.find { tab ->
            !tab.isIncognito && tab.url.trimEnd('/').equals(target, ignoreCase = true)
        }
        if (existing != null) {
            selectTab(existing.id)
            return
        }
        val opened = openNewTab(initialUrl = normalizeUrlOrSearchQuery(rawUrl), isIncognito = false)
        if (!opened) {
            loadUrlInActiveTab(rawUrl)
        }
    }

    fun closeTab(tabId: Int) {
        val currentList = _tabsState.value
        val closingTab = currentList.find { it.id == tabId } ?: return
        if (!closingTab.isIncognito && closingTab.url != NEW_TAB_URL) {
            pushRecentlyClosedTab(closingTab)
        }
        deleteWebViewBundleFromDisk(tabId)

        if (currentList.size <= 1) {
            // Reset last remaining tab to New Tab Start Page instead of leaving zero tabs
            loadUrlInTab(tabId, NEW_TAB_URL)
            persistSessionStateSync(commitImmediately = true, saveWebViewBundles = false)
            return
        }

        val closingIndex = currentList.indexOfFirst { it.id == tabId }
        if (closingIndex == -1) return

        val removedWebView = webViews.remove(tabId)
        contextWrappers.remove(tabId)
        tabProgressMap.remove(tabId)
        tabLoadingMap.remove(tabId)
        tabInitialUrlLoaded.remove(tabId)
        tabUserMediaUnlocked.remove(tabId)

        if (removedWebView != null) {
            try {
                removedWebView.allowExplicitDestroy = true
                persistentContainer.removeView(removedWebView)
                removedWebView.stopLoading()
                removedWebView.destroy()
            } catch (_: Exception) {
            }
        }

        val updatedList = currentList.filterNot { it.id == tabId }
        _tabsState.value = updatedList

        if (_activeTabId.value == tabId) {
            val nextTab = updatedList.getOrNull(closingIndex) ?: updatedList.last()
            selectTab(nextTab.id)
        }
        persistSessionStateSync(commitImmediately = true, saveWebViewBundles = false)
        BrowserService.startKeepAliveService(appContext, updatedList.size)
    }

    fun reopenLastClosedTab(): Boolean {
        val lastClosed = _recentlyClosedTabs.value.firstOrNull() ?: return false
        _recentlyClosedTabs.update { it.drop(1) }
        saveRecentlyClosedTabsToPrefs()
        return openNewTab(initialUrl = lastClosed.url, isIncognito = false)
    }

    fun closeAllTabsAndResetToStartPage() {
        closeOAuthPopup()
        val currentList = _tabsState.value
        currentList.forEach { tab ->
            if (!tab.isIncognito && tab.url != NEW_TAB_URL) {
                pushRecentlyClosedTab(tab)
            }
            deleteWebViewBundleFromDisk(tab.id)
        }
        webViews.values.forEach { webView ->
            try {
                webView.allowExplicitDestroy = true
                persistentContainer.removeView(webView)
                webView.stopLoading()
                webView.destroy()
            } catch (_: Exception) {
            }
        }
        webViews.clear()
        contextWrappers.clear()
        tabProgressMap.clear()
        tabLoadingMap.clear()
        tabInitialUrlLoaded.clear()
        tabUserMediaUnlocked.clear()
        nextTabId = 1

        val tabId = nextTabId++
        val startTab = BrowserTabModel(
            id = tabId,
            slotTitle = "Tab 1",
            pageTitle = "New Tab",
            url = NEW_TAB_URL
        )
        tabProgressMap[tabId] = 100
        tabLoadingMap[tabId] = false
        tabInitialUrlLoaded[tabId] = true
        val webView = createConfiguredWebView(tabId = tabId, isDesktop = false, isIncognito = false)
        webViews[tabId] = webView
        persistentContainer.addView(
            webView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        _tabsState.value = listOf(startTab)
        _activeTabId.value = tabId
        applyZeroReloadVisibilityStack(tabId)
        persistSessionStateSync(commitImmediately = true, saveWebViewBundles = false)
        BrowserService.startKeepAliveService(appContext, 1)
    }

    fun resetToDefaultFiveTabs() {
        closeOAuthPopup()
        webViews.values.forEach { webView ->
            try {
                webView.allowExplicitDestroy = true
                persistentContainer.removeView(webView)
                webView.stopLoading()
                webView.destroy()
            } catch (_: Exception) {
            }
        }
        webViews.clear()
        contextWrappers.clear()
        tabProgressMap.clear()
        tabLoadingMap.clear()
        tabInitialUrlLoaded.clear()
        tabUserMediaUnlocked.clear()
        nextTabId = 1
        initializeDefaultFiveTabs()
        BrowserService.startKeepAliveService(appContext, _tabsState.value.size)
    }

    fun loadUrlInActiveTab(rawInput: String) {
        loadUrlInTab(_activeTabId.value, rawInput)
    }

    fun loadUrlInTab(tabId: Int, rawInput: String) {
        val webView = webViews[tabId] ?: return
        tabInitialUrlLoaded[tabId] = true
        val trimmed = rawInput.trim()
        if (trimmed == NEW_TAB_URL) {
            webView.stopLoading()
            updateTabLoadingProgress(tabId, 100, isLoading = false)
            updateTabModel(tabId) {
                it.copy(
                    url = NEW_TAB_URL,
                    pageTitle = if (it.isIncognito) "Incognito Tab" else "New Tab",
                    isSslSecure = true
                )
            }
            deleteWebViewBundleFromDisk(tabId)
            persistSessionStateSync(commitImmediately = true, saveWebViewBundles = false)
            return
        }
        val formattedUrl = normalizeUrlOrSearchQuery(trimmed)
        val tabSnapshot = _tabsState.value.find { it.id == tabId }
        updateTabModel(tabId) {
            it.copy(
                url = formattedUrl,
                pageTitle = if (it.pageTitle == "New Tab" || it.pageTitle.isBlank()) formattedUrl else it.pageTitle,
                isSslSecure = formattedUrl.startsWith("https://")
            )
        }
        if (tabSnapshot?.isIncognito != true && formattedUrl.startsWith("http")) {
            ioScope.launch {
                repository.recordHistory(title = formattedUrl, url = formattedUrl)
            }
        }
        persistSessionStateSync(commitImmediately = true, saveWebViewBundles = false)
        webView.loadUrl(formattedUrl)
    }

    fun normalizeUrlOrSearchQuery(input: String): String {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) return currentSettings.homepageMode.homeUrl
        if (trimmed == NEW_TAB_URL || trimmed.startsWith("about:")) return trimmed
        if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) {
            return trimmed
        }
        val looksLikeDomain = trimmed.contains(".") && !trimmed.contains(" ")
        return if (looksLikeDomain) {
            "https://$trimmed"
        } else {
            currentSettings.searchEngine.buildSearchUrl(trimmed)
        }
    }

    fun reloadOrStopActiveTab() {
        val activeId = _activeTabId.value
        val activeTab = _tabsState.value.find { it.id == activeId } ?: return
        if (activeTab.url == NEW_TAB_URL) return
        val webView = webViews[activeId] ?: return
        val isLoading = tabLoadingMap[activeId] == true
        if (isLoading) {
            webView.stopLoading()
            updateTabLoadingProgress(activeId, 100, isLoading = false)
        } else {
            webView.reload()
        }
    }

    fun goBackInActiveTab(): Boolean {
        val activeId = _activeTabId.value
        val activeTab = _tabsState.value.find { it.id == activeId } ?: return false
        if (activeTab.url == NEW_TAB_URL) return false
        val webView = webViews[activeId] ?: return false
        return if (webView.canGoBack()) {
            webView.goBack()
            true
        } else {
            false
        }
    }

    fun goForwardInActiveTab(): Boolean {
        val activeId = _activeTabId.value
        val webView = webViews[activeId] ?: return false
        return if (webView.canGoForward()) {
            webView.goForward()
            true
        } else {
            false
        }
    }

    fun goHomeInActiveTab() {
        loadUrlInActiveTab(currentSettings.homepageMode.homeUrl)
    }

    fun openGoogleSignIn() {
        loadUrlInActiveTab("https://accounts.google.com/ServiceLogin?continue=https://aistudio.google.com/")
    }

    fun reSyncGoogleAuthForActiveTab() {
        _aiStudioPermissionErrorDetected.value = false
        val activeId = _activeTabId.value
        val activeWebView = webViews[activeId]
        val activeUrl = _tabsState.value.find { it.id == activeId }?.url
            ?.takeIf { it.startsWith("https://") }
            ?: DEFAULT_HOME_URL
        try {
            activeWebView?.clearCache(true)
            activeWebView?.evaluateJavascript(
                "try { window.sessionStorage.clear(); window.localStorage.removeItem('__flowra_aistudio_clean_v2'); } catch(e) {}",
                null
            )
            CookieManager.getInstance().flush()
        } catch (_: Throwable) {
        }
        val encodedContinue = Uri.encode(activeUrl)
        loadUrlInActiveTab("https://accounts.google.com/AccountChooser?continue=$encodedContinue")
    }

    fun openAiStudioApiKeys() {
        _aiStudioPermissionErrorDetected.value = false
        openNewTab("https://aistudio.google.com/app/apikey", isIncognito = false)
    }

    fun startNewAiStudioPrompt() {
        _aiStudioPermissionErrorDetected.value = false
        loadUrlInActiveTab("https://aistudio.google.com/prompts/new_chat")
    }

    fun openGoogleAccountManager() {
        loadUrlInActiveTab("https://myaccount.google.com/")
    }

    fun signOutGoogleAccounts() {
        loadUrlInActiveTab("https://accounts.google.com/Logout")
    }

    fun toggleDesktopModeForActiveTab() {
        val activeId = _activeTabId.value
        val webView = webViews[activeId] ?: return
        val currentTab = _tabsState.value.find { it.id == activeId } ?: return
        val newDesktopState = !currentTab.isDesktopMode

        applySanitizedUserAgent(webView.settings, newDesktopState)
        webView.settings.useWideViewPort = true
        webView.settings.loadWithOverviewMode = true

        updateTabModel(activeId) { it.copy(isDesktopMode = newDesktopState) }
        persistSessionStateSync(commitImmediately = true, saveWebViewBundles = false)
        if (currentTab.url != NEW_TAB_URL) {
            webView.reload()
        }
    }

    // --- Downloads ---

    private fun currentDownloadDestination(): DownloadDestination {
        return DownloadDestination(
            preset = DownloadFolderPreset.fromId(currentSettings.downloadFolderPreset),
            customTreeUri = currentSettings.customDownloadTreeUri,
            customFolderLabel = currentSettings.customDownloadFolderLabel
        )
    }

    fun triggerDirectDownload(url: String, mimeType: String? = null) {
        val activeId = _activeTabId.value
        val activeTab = _tabsState.value.find { it.id == activeId }
        val ua = if (activeTab?.isDesktopMode == true) {
            getSanitizedDesktopUserAgent(appContext)
        } else {
            getSanitizedMobileUserAgent(appContext)
        }
        val blobMeta = downloadBridge.getRegisteredBlobMetadata(url)
        val rawMime = mimeType ?: blobMeta?.mimeType?.takeIf { it.isNotBlank() } ?: "application/octet-stream"
        val suggestedName = DownloadHelper.guessName(
            url = url,
            contentDisposition = null,
            mimeType = rawMime,
            registeredBlobName = downloadBridge.getRegisteredBlobName(url),
            registeredBlobMeta = blobMeta,
            refererUrl = activeTab?.url
        )
        val resolvedMime = resolveAccurateMimeType(suggestedName, rawMime, blobMeta?.magicHex)
        val destination = currentDownloadDestination()
        val req = PendingDownloadRequest(
            url = url,
            userAgent = ua,
            contentDisposition = "",
            mimeType = resolvedMime,
            contentLength = blobMeta?.sizeBytes ?: -1L,
            suggestedFileName = suggestedName,
            defaultDestination = destination,
            refererUrl = activeTab?.url.orEmpty(),
            sourceTabId = activeId
        )
        if ((url.startsWith("blob:") || url.startsWith("data:")) && !downloadBridge.hasStagedOrActiveBlob(url)) {
            val wv = webViews[activeId]
            if (wv != null) {
                val preStageScript = DownloadHelper.buildBlobOrDataExtractionScript(
                    blobOrDataUrl = url,
                    suggestedName = suggestedName,
                    mimeType = resolvedMime,
                    destination = destination,
                    preStageOnly = true
                )
                wv.evaluateJavascript(preStageScript, null)
            }
        }
        if (currentSettings.askBeforeDownload) {
            _pendingDownload.value = req
        } else {
            executeDownloadRequest(req, suggestedName, destination)
        }
    }

    fun confirmPendingDownload(
        customFileName: String,
        destination: DownloadDestination = currentDownloadDestination()
    ) {
        val req = _pendingDownload.value ?: return
        _pendingDownload.value = null
        // Request POST_NOTIFICATIONS on Android 13+ if not yet granted so status bar progress is shown
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            !DeviceAccessHelper.isNotificationsGranted(appContext)
        ) {
            onRequestRuntimePermissions?.invoke(arrayOf(Manifest.permission.POST_NOTIFICATIONS)) {}
        }
        ioScope.launch {
            preferences.setDownloadDestination(
                preset = destination.preset.name,
                customTreeUri = destination.customTreeUri,
                customFolderLabel = destination.customFolderLabel
            )
        }
        executeDownloadRequest(
            req = req,
            finalFileName = customFileName.ifBlank { req.suggestedFileName },
            destination = destination
        )
    }

    fun dismissPendingDownload() {
        val req = _pendingDownload.value
        _pendingDownload.value = null
        if (req != null && (req.url.startsWith("blob:") || req.url.startsWith("data:"))) {
            downloadBridge.discardPreStagedBlob(req.url)
        }
    }

    private fun executeDownloadRequest(
        req: PendingDownloadRequest,
        finalFileName: String,
        destination: DownloadDestination = currentDownloadDestination()
    ) {
        val url = req.url
        val folderLabel = destination.displayLabel()
        if (url.startsWith("blob:") || url.startsWith("data:")) {
            val targetWebView = webViews[req.sourceTabId] ?: webViews[_activeTabId.value]
            downloadBridge.confirmStagedOrExecuteBlobDownload(
                blobOrDataUrl = url,
                customFileName = finalFileName,
                mimeType = req.mimeType,
                destination = destination,
                fallbackWebView = targetWebView
            )
            Toast.makeText(
                currentActivity ?: appContext,
                "Downloading $finalFileName to $folderLabel...",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        DownloadHelper.launchBackgroundHttpDownload(
            context = appContext,
            repository = repository,
            url = url,
            fileName = finalFileName,
            mimeType = req.mimeType,
            userAgent = req.userAgent,
            destination = destination,
            refererUrl = req.refererUrl
        )
        mainScope.launch {
            Toast.makeText(
                currentActivity ?: appContext,
                "Downloading $finalFileName in background ($folderLabel)...",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    // --- Find in Page ---

    fun showFindInPage() {
        _findInPageState.update { it.copy(isVisible = true) }
    }

    fun updateFindQuery(query: String) {
        _findInPageState.update { it.copy(query = query) }
        val webView = webViews[_activeTabId.value] ?: return
        if (query.isBlank()) {
            webView.clearMatches()
            _findInPageState.update { it.copy(activeMatchIndex = 0, totalMatches = 0) }
        } else {
            webView.findAllAsync(query)
        }
    }

    fun findNextMatch(forward: Boolean) {
        webViews[_activeTabId.value]?.findNext(forward)
    }

    fun clearFindInPage() {
        webViews[_activeTabId.value]?.clearMatches()
        _findInPageState.value = FindInPageState()
    }

    // --- Print / Save as PDF ---

    fun printActivePage() {
        val activity = currentActivity ?: return
        val activeId = _activeTabId.value
        val activeTab = _tabsState.value.find { it.id == activeId } ?: return
        if (activeTab.url == NEW_TAB_URL) {
            Toast.makeText(activity, "Open a webpage first to print or save as PDF", Toast.LENGTH_SHORT).show()
            return
        }
        val webView = webViews[activeId] ?: return
        try {
            val printManager = activity.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return
            val jobName = "${activeTab.pageTitle.take(40)} - Flowra"
            val adapter = webView.createPrintDocumentAdapter(jobName)
            printManager.print(jobName, adapter, PrintAttributes.Builder().build())
        } catch (_: Exception) {
            Toast.makeText(activity, "Unable to open Print/PDF dialog", Toast.LENGTH_SHORT).show()
        }
    }

    // --- Context Menu ---

    fun dismissContextMenu() {
        _contextMenuTarget.value = null
    }

    // --- Thumbnails for Chrome Tab Grid Switcher ---

    fun captureTabThumbnails() {
        val activeId = _activeTabId.value
        val activeWebView = webViews[activeId] ?: return
        val activeTab = _tabsState.value.find { it.id == activeId } ?: return
        if (activeTab.url == NEW_TAB_URL || activeWebView.width <= 0 || activeWebView.height <= 0) return

        // Defer thumbnail draw past the Dialog's SurfaceSyncGroup window transition frame
        activeWebView.post {
            try {
                if (activeWebView.width <= 0 || activeWebView.height <= 0) return@post
                val targetW = (activeWebView.width / 4).coerceIn(140, 260)
                val targetH = (activeWebView.height / 4).coerceIn(180, 360)
                val bmp = Bitmap.createBitmap(targetW, targetH, Bitmap.Config.RGB_565)
                val canvas = Canvas(bmp)
                val scaleX = targetW.toFloat() / activeWebView.width.toFloat()
                val scaleY = targetH.toFloat() / activeWebView.height.toFloat()
                canvas.scale(scaleX, scaleY)
                activeWebView.draw(canvas)
                updateTabModel(activeId) { it.copy(thumbnail = bmp) }
            } catch (_: Exception) {
            }
        }
    }

    // --- Clearing Data ---

    fun clearCacheKeepLogin() {
        webViews.values.forEach { webView ->
            webView.clearCache(true)
            webView.clearFormData()
        }
        Toast.makeText(
            currentActivity ?: appContext,
            "Cleared WebView cache (logins preserved)",
            Toast.LENGTH_SHORT
        ).show()
    }

    fun clearAllCacheAndCookies() {
        try {
            val cookieManager = CookieManager.getInstance()
            cookieManager.removeAllCookies {
                cookieManager.flush()
                mainScope.launch { refreshGoogleSignInStatus() }
            }
            WebStorage.getInstance().deleteAllData()
            webViews.values.forEach { webView ->
                webView.clearCache(true)
                webView.clearHistory()
                webView.clearFormData()
                webView.reload()
            }
            Toast.makeText(
                currentActivity ?: appContext,
                "Cleared cache, cookies, and site storage",
                Toast.LENGTH_SHORT
            ).show()
        } catch (_: Exception) {
        }
    }

    fun clearBrowsingData(clearHistory: Boolean, clearCache: Boolean, clearCookies: Boolean) {
        if (clearHistory) {
            ioScope.launch { repository.clearHistory() }
            webViews.values.forEach { it.clearHistory() }
        }
        if (clearCache) {
            webViews.values.forEach {
                it.clearCache(true)
                it.clearFormData()
            }
        }
        if (clearCookies) {
            val cookieManager = CookieManager.getInstance()
            cookieManager.removeAllCookies {
                cookieManager.flush()
                mainScope.launch { refreshGoogleSignInStatus() }
            }
            WebStorage.getInstance().deleteAllData()
        }
        Toast.makeText(currentActivity ?: appContext, "Browsing data cleared", Toast.LENGTH_SHORT).show()
    }

    fun flushCookiesNow() {
        persistSessionStateSync(commitImmediately = true, saveWebViewBundles = true)
        ioScope.launch {
            try {
                CookieManager.getInstance().flush()
                refreshGoogleSignInStatus()
            } catch (_: Exception) {
            }
        }
    }

    /**
     * Synchronously saves all open non-incognito tabs, active tab selection, and WebView
     * navigation state bundles so even if the user swipes the browser away from Recents,
     * every open tab and its history are restored on next launch.
     */
    fun persistSessionStateSync(
        commitImmediately: Boolean = false,
        saveWebViewBundles: Boolean = false
    ) {
        try {
            val allTabs = _tabsState.value
            val persistableTabs = allTabs.filter { !it.isIncognito }
            val currentActiveId = _activeTabId.value
            val effectiveActiveId = if (persistableTabs.any { it.id == currentActiveId }) {
                currentActiveId
            } else {
                persistableTabs.firstOrNull()?.id ?: 1
            }

            val jsonArray = JSONArray()
            val roomEntities = mutableListOf<SavedTabEntity>()
            val now = System.currentTimeMillis()

            if (persistableTabs.isEmpty()) {
                val fallbackObj = JSONObject().apply {
                    put("id", 1)
                    put("slotTitle", "Tab 1")
                    put("pageTitle", "New Tab")
                    put("url", NEW_TAB_URL)
                    put("isDesktopMode", false)
                    put("isActive", true)
                }
                jsonArray.put(fallbackObj)
                roomEntities.add(
                    SavedTabEntity(
                        tabId = 1,
                        slotTitle = "Tab 1",
                        pageTitle = "New Tab",
                        url = NEW_TAB_URL,
                        isDesktopMode = false,
                        isActive = true,
                        sortOrder = 0,
                        updatedAt = now
                    )
                )
            } else {
                persistableTabs.forEachIndexed { index, tab ->
                    val isTabActive = (tab.id == effectiveActiveId)
                    val obj = JSONObject().apply {
                        put("id", tab.id)
                        put("slotTitle", tab.slotTitle)
                        put("pageTitle", tab.pageTitle)
                        put("url", tab.url)
                        put("isDesktopMode", tab.isDesktopMode)
                        put("isActive", isTabActive)
                    }
                    jsonArray.put(obj)
                    roomEntities.add(
                        SavedTabEntity(
                            tabId = tab.id,
                            slotTitle = tab.slotTitle,
                            pageTitle = tab.pageTitle,
                            url = tab.url,
                            isDesktopMode = tab.isDesktopMode,
                            isActive = isTabActive,
                            sortOrder = index,
                            updatedAt = now
                        )
                    )
                }
            }

            val editor = sessionPrefs.edit()
                .putString(KEY_SAVED_TABS_JSON, jsonArray.toString())
                .putInt(KEY_ACTIVE_TAB_ID, effectiveActiveId)
                .putInt(KEY_NEXT_TAB_ID, nextTabId)

            if (commitImmediately) {
                editor.commit()
            } else {
                editor.apply()
            }

            ioScope.launch {
                try {
                    repository.replaceSavedTabs(roomEntities)
                } catch (_: Exception) {
                }
            }

            if (saveWebViewBundles && Looper.myLooper() == Looper.getMainLooper()) {
                persistableTabs.forEach { tab ->
                    if (tab.url != NEW_TAB_URL) {
                        val wv = webViews[tab.id]
                        if (wv != null) {
                            saveWebViewBundleToDisk(tab.id, wv)
                        }
                    }
                }
            }
        } catch (_: Exception) {
        }
    }

    private fun unwrapIntermediateGoogleSignInUrl(rawUrl: String): String {
        if (!rawUrl.startsWith("https://accounts.google.com/", ignoreCase = true)) {
            return rawUrl
        }
        return try {
            val uri = Uri.parse(rawUrl)
            val continueParam = uri.getQueryParameter("continue")
                ?: uri.getQueryParameter("followup")
            if (!continueParam.isNullOrBlank() &&
                (continueParam.startsWith("https://") || continueParam.startsWith("http://"))
            ) {
                continueParam
            } else {
                rawUrl
            }
        } catch (_: Exception) {
            rawUrl
        }
    }

    private fun parseSavedTabsJson(jsonStr: String?): List<BrowserTabModel> {
        if (jsonStr.isNullOrBlank()) return emptyList()
        return try {
            val arr = JSONArray(jsonStr)
            val result = mutableListOf<BrowserTabModel>()
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val id = obj.optInt("id", i + 1)
                val rawUrl = obj.optString("url", NEW_TAB_URL).ifBlank { NEW_TAB_URL }
                val url = unwrapIntermediateGoogleSignInUrl(rawUrl)
                val slotTitle = obj.optString("slotTitle", "Tab $id").ifBlank { "Tab $id" }
                val pageTitle = obj.optString(
                    "pageTitle",
                    if (url == NEW_TAB_URL) "New Tab" else url
                ).ifBlank { if (url == NEW_TAB_URL) "New Tab" else url }
                val isDesktopMode = obj.optBoolean("isDesktopMode", false)
                result.add(
                    BrowserTabModel(
                        id = id,
                        slotTitle = slotTitle,
                        pageTitle = pageTitle,
                        url = url,
                        isDesktopMode = isDesktopMode,
                        isIncognito = false,
                        isSslSecure = url.startsWith("https://") || url == NEW_TAB_URL
                    )
                )
            }
            result
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun pushRecentlyClosedTab(tab: BrowserTabModel) {
        if (tab.isIncognito || tab.url == NEW_TAB_URL || tab.url.isBlank()) return
        _recentlyClosedTabs.update { existing ->
            val filtered = existing.filterNot { it.url == tab.url }
            (listOf(tab) + filtered).take(20)
        }
        saveRecentlyClosedTabsToPrefs()
    }

    private fun saveRecentlyClosedTabsToPrefs() {
        try {
            val arr = JSONArray()
            _recentlyClosedTabs.value.forEach { tab ->
                val obj = JSONObject().apply {
                    put("id", tab.id)
                    put("slotTitle", tab.slotTitle)
                    put("pageTitle", tab.pageTitle)
                    put("url", tab.url)
                    put("isDesktopMode", tab.isDesktopMode)
                }
                arr.put(obj)
            }
            sessionPrefs.edit().putString(KEY_RECENTLY_CLOSED_JSON, arr.toString()).apply()
        } catch (_: Exception) {
        }
    }

    private fun restoreRecentlyClosedTabsFromPrefs() {
        try {
            val raw = sessionPrefs.getString(KEY_RECENTLY_CLOSED_JSON, null)
            _recentlyClosedTabs.value = parseSavedTabsJson(raw)
        } catch (_: Exception) {
        }
    }

    private fun isDynamicAuthSpaUrl(url: String?): Boolean {
        if (url.isNullOrBlank()) return false
        val lower = url.lowercase()
        return lower.contains("google.com") ||
            lower.contains("aistudio") ||
            lower.contains("makersuite") ||
            lower.contains("googleapis.com")
    }

    private fun saveWebViewBundleToDisk(tabId: Int, webView: WebView) {
        try {
            val currentUrl = webView.url
            if (isDynamicAuthSpaUrl(currentUrl)) {
                deleteWebViewBundleFromDisk(tabId)
                return
            }
            val bundle = Bundle()
            val state = webView.saveState(bundle)
            if (state == null || bundle.isEmpty) return
            val parcel = Parcel.obtain()
            val bytes = try {
                bundle.writeToParcel(parcel, 0)
                parcel.marshall()
            } finally {
                parcel.recycle()
            }
            if (bytes.isNotEmpty() && bytes.size <= 2 * 1024 * 1024) {
                ioScope.launch {
                    try {
                        File(bundleDir, "tab_$tabId.bundle").writeBytes(bytes)
                    } catch (_: Exception) {
                    }
                }
            }
        } catch (_: Throwable) {
        }
    }

    private fun restoreWebViewBundleIfPresent(tabId: Int, webView: WebView, fallbackUrl: String): Boolean {
        if (isDynamicAuthSpaUrl(fallbackUrl)) {
            deleteWebViewBundleFromDisk(tabId)
            return false
        }
        return try {
            val file = File(bundleDir, "tab_$tabId.bundle")
            if (!file.exists() || file.length() <= 0L || file.length() > 2 * 1024 * 1024L) {
                return false
            }
            val bytes = file.readBytes()
            val parcel = Parcel.obtain()
            val bundle = try {
                parcel.unmarshall(bytes, 0, bytes.size)
                parcel.setDataPosition(0)
                Bundle.CREATOR.createFromParcel(parcel)
            } finally {
                parcel.recycle()
            }
            if (bundle.isEmpty) return false
            val restoredList = webView.restoreState(bundle)
            if (restoredList != null && restoredList.size > 0) {
                if (webView.url.isNullOrBlank() && fallbackUrl != NEW_TAB_URL) {
                    webView.loadUrl(fallbackUrl)
                }
                true
            } else {
                false
            }
        } catch (_: Throwable) {
            false
        }
    }

    private fun deleteWebViewBundleFromDisk(tabId: Int) {
        ioScope.launch {
            try {
                File(bundleDir, "tab_$tabId.bundle").delete()
            } catch (_: Exception) {
            }
        }
    }

    fun pulseBackgroundKeepAlive() {
        val activeId = _activeTabId.value
        val snapshot = webViews.entries.toList()
        mainScope.launch {
            snapshot.forEachIndexed { index, (tabId, webView) ->
                if (webViews[tabId] !== webView) return@forEachIndexed
                try {
                    if (webView.visibility != View.VISIBLE) {
                        webView.visibility = View.VISIBLE
                    }
                    webView.resumeTimers()
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        webView.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false)
                    }
                    // Stagger JS state check across frames so the 16.6ms 60fps UI budget stays untouched
                    if (tabId != activeId && tabInitialUrlLoaded[tabId] == true) {
                        webView.evaluateJavascript("window.__studioTabIsActive=false;", null)
                    }
                } catch (_: Exception) {
                }
                if (index < snapshot.lastIndex) {
                    delay(80L)
                }
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun applySettingsToAllWebViews(settings: BrowserSettings) {
        webViews.values.forEach { webView ->
            if (webView.settings.javaScriptEnabled != settings.javaScriptEnabled) {
                webView.settings.javaScriptEnabled = settings.javaScriptEnabled
            }
            if (webView.settings.textZoom != settings.textZoomPercent) {
                webView.settings.textZoom = settings.textZoomPercent
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                webView.settings.isAlgorithmicDarkeningAllowed = settings.darkWebPages
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    private fun createConfiguredWebView(
        tabId: Int,
        isDesktop: Boolean,
        isIncognito: Boolean
    ): UnthrottledWebView {
        val contextWrapper = MutableContextWrapper(currentActivity ?: appContext)
        contextWrappers[tabId] = contextWrapper

        val webView = UnthrottledWebView(contextWrapper).apply {
            setLayerType(View.LAYER_TYPE_NONE, null)
            isFocusable = true
            isFocusableInTouchMode = true
            keepScreenOn = true
            isNestedScrollingEnabled = true
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
            scrollBarStyle = View.SCROLLBARS_INSIDE_OVERLAY
            isVerticalScrollBarEnabled = true
            onUserTap = {
                if (tabId == _activeTabId.value) {
                    tabUserMediaUnlocked[tabId] = true
                    try {
                        evaluateJavascript("window.__studioUserMediaUnlocked = true;", null)
                    } catch (_: Exception) {
                    }
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false)
                importantForAutofill = if (isIncognito) {
                    View.IMPORTANT_FOR_AUTOFILL_NO
                } else {
                    View.IMPORTANT_FOR_AUTOFILL_YES
                }
            }
        }

        configureWebSettings(webView, isDesktop = isDesktop, isIncognito = isIncognito)
        webView.addJavascriptInterface(downloadBridge, "StudioDownloadBridge")
        installDocumentStartScriptIfSupported(webView)
        attachDownloadListener(webView, tabId)

        webView.setFindListener { activeMatchOrdinal, numberOfMatches, _ ->
            _findInPageState.update {
                it.copy(
                    activeMatchIndex = if (numberOfMatches > 0) activeMatchOrdinal + 1 else 0,
                    totalMatches = numberOfMatches
                )
            }
        }

        webView.setOnLongClickListener { view ->
            val wv = view as? WebView ?: return@setOnLongClickListener false
            val hit = wv.hitTestResult
            val extra = hit.extra
            if (!extra.isNullOrBlank()) {
                when (hit.type) {
                    WebView.HitTestResult.SRC_ANCHOR_TYPE,
                    WebView.HitTestResult.EMAIL_TYPE -> {
                        _contextMenuTarget.value = WebContextMenuTarget(
                            linkUrl = extra,
                            title = extra
                        )
                        return@setOnLongClickListener true
                    }
                    WebView.HitTestResult.IMAGE_TYPE -> {
                        _contextMenuTarget.value = WebContextMenuTarget(
                            imageUrl = extra,
                            title = extra
                        )
                        return@setOnLongClickListener true
                    }
                    WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE -> {
                        _contextMenuTarget.value = WebContextMenuTarget(
                            linkUrl = extra,
                            imageUrl = extra,
                            title = extra
                        )
                        return@setOnLongClickListener true
                    }
                }
            }
            false
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? {
                val host = request.url?.host?.lowercase() ?: ""
                val referer = (request.requestHeaders?.get("Referer")
                    ?: request.requestHeaders?.get("referer")).orEmpty()
                val refererHost = try { Uri.parse(referer).host?.lowercase().orEmpty() } catch (_: Exception) { "" }
                val isGoogleWorkspaceFlow = isGoogleTrustedOriginHost(host) || isGoogleTrustedOriginHost(refererHost)
                if (isGoogleWorkspaceFlow) {
                    return null
                }
                if (currentSettings.adBlockEnabled) {
                    if (AD_BLOCK_DOMAINS.any { host == it || host.endsWith(".$it") }) {
                        return WebResourceResponse(
                            "text/plain",
                            "UTF-8",
                            204,
                            "Blocked",
                            emptyMap(),
                            ByteArrayInputStream(ByteArray(0))
                        )
                    }
                }

                // Prevent Chromium from allocating scarce hardware MediaCodec video decoders
                // in background tabs or for unrequested autoplay/preload promo videos at startup.
                if (isVideoMediaRequest(request)) {
                    val isBackgroundTab = tabId != _activeTabId.value
                    val isUserUnlocked = tabUserMediaUnlocked[tabId] == true
                    val allowDedicatedActiveVideo = !isBackgroundTab && isDedicatedVideoHost(host)
                    if (isBackgroundTab || (!isUserUnlocked && !allowDedicatedActiveVideo)) {
                        return WebResourceResponse(
                            "text/plain",
                            "UTF-8",
                            204,
                            "Deferred Video",
                            emptyMap(),
                            ByteArrayInputStream(ByteArray(0))
                        )
                    }
                }
                return super.shouldInterceptRequest(view, request)
            }

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                val uri = request.url ?: return false
                val scheme = uri.scheme?.lowercase() ?: return false

                if (scheme == "http" || scheme == "https") {
                    return false
                }

                if (scheme == "intent") {
                    return try {
                        val parsedIntent = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME)
                        val fallbackUrl = parsedIntent.getStringExtra("browser_fallback_url")
                        if (!fallbackUrl.isNullOrBlank() && (fallbackUrl.startsWith("https://") || fallbackUrl.startsWith("http://"))) {
                            view.loadUrl(fallbackUrl)
                            true
                        } else {
                            parsedIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            (currentActivity ?: appContext).startActivity(parsedIntent)
                            true
                        }
                    } catch (_: Exception) {
                        true
                    }
                }

                return try {
                    val externalIntent = Intent(Intent.ACTION_VIEW, uri).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    (currentActivity ?: appContext).startActivity(externalIntent)
                    true
                } catch (_: Exception) {
                    true
                }
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                val safeUrl = url ?: return
                tabInitialUrlLoaded[tabId] = true
                val host = try { Uri.parse(safeUrl).host?.lowercase().orEmpty() } catch (_: Exception) { "" }
                tabUserMediaUnlocked[tabId] = isDedicatedVideoHost(host) && tabId == _activeTabId.value
                updateTabLoadingProgress(tabId, 12, isLoading = true)
                updateTabModel(tabId) { current ->
                    current.copy(
                        url = safeUrl,
                        isSslSecure = safeUrl.startsWith("https://"),
                        canGoBack = view.canGoBack(),
                        canGoForward = view.canGoForward()
                    )
                }
                if (!isIncognito && safeUrl.startsWith("http")) {
                    val currentTitle = view.title?.takeIf { it.isNotBlank() } ?: safeUrl
                    ioScope.launch {
                        repository.recordHistory(title = currentTitle, url = safeUrl)
                    }
                }
                persistSessionStateSync(commitImmediately = false, saveWebViewBundles = false)
                injectAntiThrottleJavaScript(view, isActiveTab = (tabId == _activeTabId.value))
            }

            override fun onPageCommitVisible(view: WebView, url: String?) {
                super.onPageCommitVisible(view, url)
                injectAntiThrottleJavaScript(view, isActiveTab = (tabId == _activeTabId.value))
            }

            override fun onPageFinished(view: WebView, url: String?) {
                super.onPageFinished(view, url)
                val safeUrl = url ?: view.url ?: return
                val resolvedTitle = view.title?.takeIf { it.isNotBlank() }
                updateTabLoadingProgress(tabId, 100, isLoading = false)
                updateTabModel(tabId) { current ->
                    current.copy(
                        url = safeUrl,
                        pageTitle = resolvedTitle ?: current.pageTitle,
                        isSslSecure = safeUrl.startsWith("https://"),
                        canGoBack = view.canGoBack(),
                        canGoForward = view.canGoForward()
                    )
                }
                if (!isIncognito && safeUrl.startsWith("http")) {
                    ioScope.launch {
                        repository.recordHistory(
                            title = resolvedTitle ?: safeUrl,
                            url = safeUrl
                        )
                    }
                }
                injectAntiThrottleJavaScript(view, isActiveTab = (tabId == _activeTabId.value))
                flushCookiesNow()
            }

            override fun doUpdateVisitedHistory(view: WebView, url: String?, isReload: Boolean) {
                super.doUpdateVisitedHistory(view, url, isReload)
                val safeUrl = url ?: view.url ?: return
                val resolvedTitle = view.title?.takeIf { t -> t.isNotBlank() }
                if (_activeTabId.value == tabId) {
                    _aiStudioPermissionErrorDetected.value = false
                }
                updateTabModel(tabId) { current ->
                    current.copy(
                        url = safeUrl,
                        pageTitle = resolvedTitle ?: current.pageTitle,
                        isSslSecure = safeUrl.startsWith("https://"),
                        canGoBack = view.canGoBack(),
                        canGoForward = view.canGoForward()
                    )
                }
                if (!isIncognito && safeUrl.startsWith("http")) {
                    ioScope.launch {
                        repository.recordHistory(
                            title = resolvedTitle ?: safeUrl,
                            url = safeUrl
                        )
                    }
                }
                if (safeUrl.contains("google.com", ignoreCase = true)) {
                    flushCookiesNow()
                }
                persistSessionStateSync(commitImmediately = false, saveWebViewBundles = false)
            }

            override fun onRenderProcessGone(
                view: WebView?,
                detail: RenderProcessGoneDetail?
            ): Boolean {
                recoverTabAfterRendererCrash(tabId, view)
                return true
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                super.onProgressChanged(view, newProgress)
                val isStillLoading = newProgress < 100
                updateTabLoadingProgress(tabId, newProgress, isStillLoading)
            }

            override fun onReceivedTitle(view: WebView, title: String?) {
                super.onReceivedTitle(view, title)
                if (!title.isNullOrBlank()) {
                    var currentUrl = ""
                    updateTabModel(tabId) {
                        currentUrl = it.url
                        it.copy(pageTitle = title)
                    }
                    if (!isIncognito && currentUrl.startsWith("http")) {
                        ioScope.launch {
                            repository.recordHistory(title = title, url = currentUrl)
                        }
                    }
                    persistSessionStateSync(commitImmediately = false, saveWebViewBundles = false)
                }
            }

            override fun onReceivedIcon(view: WebView, icon: Bitmap?) {
                super.onReceivedIcon(view, icon)
                if (icon != null) {
                    updateTabModel(tabId) { it.copy(favicon = icon) }
                }
            }

            override fun onCreateWindow(
                view: WebView,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: Message?
            ): Boolean {
                val transport = resultMsg?.obj as? WebView.WebViewTransport ?: return false
                val popupContext = MutableContextWrapper(currentActivity ?: appContext)
                val popupWebView = UnthrottledWebView(popupContext).apply {
                    setLayerType(View.LAYER_TYPE_NONE, null)
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
                var popupClosed = false

                val parentDesktopMode = _tabsState.value.find { it.id == tabId }?.isDesktopMode == true
                configureWebSettings(popupWebView, isDesktop = parentDesktopMode, isIncognito = isIncognito)
                popupWebView.addJavascriptInterface(downloadBridge, "StudioDownloadBridge")
                installDocumentStartScriptIfSupported(popupWebView)
                attachDownloadListener(popupWebView, tabId, isPopupWindow = true)

                popupWebView.webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(
                        popupView: WebView,
                        request: WebResourceRequest
                    ): Boolean {
                        val uri = request.url ?: return false
                        val scheme = uri.scheme?.lowercase() ?: return false
                        if (scheme == "blob" || scheme == "data") {
                            triggerDirectDownload(uri.toString())
                            popupClosed = true
                            closeOAuthPopup(popupView)
                            return true
                        }
                        if (scheme == "intent") {
                            return try {
                                val parsedIntent = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME)
                                val fallbackUrl = parsedIntent.getStringExtra("browser_fallback_url")
                                if (!fallbackUrl.isNullOrBlank() && (fallbackUrl.startsWith("https://") || fallbackUrl.startsWith("http://"))) {
                                    popupView.loadUrl(fallbackUrl)
                                    true
                                } else {
                                    parsedIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    (currentActivity ?: appContext).startActivity(parsedIntent)
                                    true
                                }
                            } catch (_: Exception) {
                                true
                            }
                        }
                        return !(scheme == "http" || scheme == "https")
                    }

                    override fun onPageStarted(popupView: WebView, url: String?, favicon: Bitmap?) {
                        super.onPageStarted(popupView, url, favicon)
                        injectAntiThrottleJavaScript(popupView, isActiveTab = true)
                        _oauthPopupState.update { current ->
                            current?.copy(
                                url = url ?: current.url,
                                isLoading = true
                            )
                        }
                    }

                    override fun doUpdateVisitedHistory(popupView: WebView, url: String?, isReload: Boolean) {
                        super.doUpdateVisitedHistory(popupView, url, isReload)
                        flushCookiesNow()
                        _oauthPopupState.update { current ->
                            current?.copy(url = url ?: popupView.url ?: current.url)
                        }
                    }

                    override fun onPageFinished(popupView: WebView, url: String?) {
                        super.onPageFinished(popupView, url)
                        injectAntiThrottleJavaScript(popupView, isActiveTab = true)
                        flushCookiesNow()
                        _oauthPopupState.update { current ->
                            current?.copy(
                                url = url ?: popupView.url ?: current.url,
                                title = popupView.title?.takeIf { it.isNotBlank() } ?: current.title,
                                isLoading = false,
                                progress = 100
                            )
                        }
                    }

                    override fun onRenderProcessGone(
                        view: WebView?,
                        detail: RenderProcessGoneDetail?
                    ): Boolean {
                        popupClosed = true
                        closeOAuthPopup(view)
                        return true
                    }
                }

                popupWebView.webChromeClient = object : WebChromeClient() {
                    override fun onProgressChanged(popupView: WebView, newProgress: Int) {
                        super.onProgressChanged(popupView, newProgress)
                        _oauthPopupState.update { current ->
                            current?.copy(
                                progress = newProgress,
                                isLoading = newProgress < 100
                            )
                        }
                    }

                    override fun onReceivedTitle(popupView: WebView, title: String?) {
                        super.onReceivedTitle(popupView, title)
                        if (!title.isNullOrBlank()) {
                            _oauthPopupState.update { current ->
                                current?.copy(title = title)
                            }
                        }
                    }

                    override fun onCloseWindow(window: WebView?) {
                        super.onCloseWindow(window)
                        popupClosed = true
                        flushCookiesNow()
                        closeOAuthPopup(window ?: popupWebView)
                    }

                    override fun onShowFileChooser(
                        webView: WebView,
                        filePathCallback: ValueCallback<Array<Uri>>,
                        fileChooserParams: FileChooserParams
                    ): Boolean {
                        return handleShowFileChooser(filePathCallback, fileChooserParams)
                    }

                    override fun onPermissionRequest(request: PermissionRequest?) {
                        if (request == null) return
                        handleWebPermissionRequest(request)
                    }

                    override fun onGeolocationPermissionsShowPrompt(
                        origin: String?,
                        callback: GeolocationPermissions.Callback?
                    ) {
                        DeviceAccessHelper.handleGeolocationPermissionRequest(
                            context = appContext,
                            origin = origin,
                            callback = callback,
                            onRequestRuntimePermissions = onRequestRuntimePermissions
                        )
                    }
                }

                _oauthPopupState.value = OAuthPopupSession(
                    parentTabId = tabId,
                    popupWebView = popupWebView
                )

                transport.webView = popupWebView
                resultMsg.sendToTarget()
                return true
            }

            override fun onCloseWindow(window: WebView?) {
                super.onCloseWindow(window)
                flushCookiesNow()
                closeOAuthPopup(window)
            }

            override fun onShowFileChooser(
                webView: WebView,
                filePathCallback: ValueCallback<Array<Uri>>,
                fileChooserParams: FileChooserParams
            ): Boolean {
                return handleShowFileChooser(filePathCallback, fileChooserParams)
            }

            override fun onPermissionRequest(request: PermissionRequest?) {
                if (request == null) return
                handleWebPermissionRequest(request)
            }

            override fun onGeolocationPermissionsShowPrompt(
                origin: String?,
                callback: GeolocationPermissions.Callback?
            ) {
                DeviceAccessHelper.handleGeolocationPermissionRequest(
                    context = appContext,
                    origin = origin,
                    callback = callback,
                    onRequestRuntimePermissions = onRequestRuntimePermissions
                )
            }
        }

        return webView
    }

    private fun recoverTabAfterRendererCrash(tabId: Int, crashedView: WebView?) {
        val tabModel = _tabsState.value.find { it.id == tabId } ?: return
        try {
            (crashedView as? UnthrottledWebView)?.allowExplicitDestroy = true
            if (crashedView != null) {
                persistentContainer.removeView(crashedView)
                crashedView.destroy()
            }
        } catch (_: Exception) {
        }
        val replacement = createConfiguredWebView(
            tabId = tabId,
            isDesktop = tabModel.isDesktopMode,
            isIncognito = tabModel.isIncognito
        )
        webViews[tabId] = replacement
        persistentContainer.addView(
            replacement,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        applyZeroReloadVisibilityStack(_activeTabId.value)
        if (tabModel.url.isNotBlank() && tabModel.url != NEW_TAB_URL) {
            tabInitialUrlLoaded[tabId] = true
            replacement.loadUrl(tabModel.url)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebSettings(
        webView: WebView,
        isDesktop: Boolean,
        isIncognito: Boolean
    ) {
        val cookieManager = CookieManager.getInstance()
        cookieManager.setAcceptCookie(true)
        cookieManager.setAcceptThirdPartyCookies(webView, true)

        webView.settings.apply {
            javaScriptEnabled = currentSettings.javaScriptEnabled
            domStorageEnabled = true
            databaseEnabled = true
            javaScriptCanOpenWindowsAutomatically = true
            setSupportMultipleWindows(true)

            allowFileAccess = true
            allowContentAccess = true
            setGeolocationEnabled(true)
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            cacheMode = if (isIncognito) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
            textZoom = currentSettings.textZoomPercent

            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            mediaPlaybackRequiresUserGesture = true

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                safeBrowsingEnabled = false
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                isAlgorithmicDarkeningAllowed = currentSettings.darkWebPages
            }
            try {
                if (WebViewFeature.isFeatureSupported(WebViewFeature.OFF_SCREEN_PRERASTER)) {
                    WebSettingsCompat.setOffscreenPreRaster(this, true)
                }
            } catch (_: Exception) {
            }

            applySanitizedUserAgent(this, isDesktop)
        }
    }

    private fun applySanitizedUserAgent(settings: WebSettings, isDesktop: Boolean) {
        applyChromeUserAgentAndMetadata(appContext, settings, isDesktop)
    }

    private fun installDocumentStartScriptIfSupported(webView: WebView) {
        try {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
                WebViewCompat.addDocumentStartJavaScript(
                    webView,
                    PAGE_VISIBILITY_OVERRIDE_JS,
                    setOf("*")
                )
            }
        } catch (_: Exception) {
        }
    }

    private fun injectAntiThrottleJavaScript(webView: WebView, isActiveTab: Boolean = true) {
        try {
            val stateJs = "window.__studioTabIsActive = $isActiveTab;"
            webView.evaluateJavascript("$stateJs\n$PAGE_VISIBILITY_OVERRIDE_JS", null)
        } catch (_: Exception) {
        }
    }

    private fun isDedicatedVideoHost(host: String): Boolean {
        return DEDICATED_VIDEO_HOSTS.any { host == it || host.endsWith(".$it") }
    }

    private fun isGoogleTrustedOriginHost(host: String): Boolean {
        if (host.isBlank()) return false
        return host == "google.com" ||
            host.endsWith(".google.com") ||
            host == "googleapis.com" ||
            host.endsWith(".googleapis.com") ||
            host == "gstatic.com" ||
            host.endsWith(".gstatic.com") ||
            host == "googleusercontent.com" ||
            host.endsWith(".googleusercontent.com") ||
            host == "usercontent.goog" ||
            host.endsWith(".usercontent.goog") ||
            host == "1e100.net" ||
            host.endsWith(".1e100.net") ||
            host == "ggpht.com" ||
            host.endsWith(".ggpht.com") ||
            host == "gvt1.com" ||
            host.endsWith(".gvt1.com") ||
            host == "gvt2.com" ||
            host.endsWith(".gvt2.com") ||
            host == "withgoogle.com" ||
            host.endsWith(".withgoogle.com") ||
            host == "youtube.com" ||
            host.endsWith(".youtube.com")
    }

    private fun isVideoMediaRequest(request: WebResourceRequest): Boolean {
        val headers = request.requestHeaders
        val fetchDest = headers?.get("Sec-Fetch-Dest") ?: headers?.get("sec-fetch-dest")
        if (fetchDest.equals("video", ignoreCase = true)) return true

        val accept = headers?.get("Accept") ?: headers?.get("accept") ?: ""
        if (accept.startsWith("video/", ignoreCase = true)) return true

        val path = request.url?.path?.lowercase() ?: ""
        return VIDEO_EXTENSIONS.any { ext -> path.endsWith(ext) }
    }

    private fun handleShowFileChooser(
        callback: ValueCallback<Array<Uri>>,
        fileChooserParams: WebChromeClient.FileChooserParams
    ): Boolean {
        filePathCallback?.onReceiveValue(null)
        filePathCallback = callback

        val launcher = onLaunchFileChooser
        if (launcher == null) {
            filePathCallback?.onReceiveValue(null)
            filePathCallback = null
            return false
        }

        val launchNow = {
            val session = DeviceAccessHelper.createChromeFileChooserSession(
                context = currentActivity ?: appContext,
                fileChooserParams = fileChooserParams
            )
            activeFileChooserSession = session
            val launched = launcher.invoke(session.chooserIntent)
            if (!launched) {
                activeFileChooserSession = null
                filePathCallback?.onReceiveValue(null)
                filePathCallback = null
            }
        }

        val missingCapturePerms = DeviceAccessHelper.getOnDemandCapturePermissionsForFileChooser(
            context = appContext,
            fileChooserParams = fileChooserParams
        )
        val permRequester = onRequestRuntimePermissions
        if (missingCapturePerms.isNotEmpty() && permRequester != null) {
            permRequester(missingCapturePerms) { _ ->
                launchNow()
            }
        } else {
            launchNow()
        }
        return true
    }

    fun onFileChooserResult(resultCode: Int, data: Intent?) {
        val callback = filePathCallback ?: return
        val session = activeFileChooserSession
        filePathCallback = null
        activeFileChooserSession = null

        val uris = DeviceAccessHelper.resolveFileChooserResult(
            context = currentActivity ?: appContext,
            resultCode = resultCode,
            data = data,
            session = session
        )
        callback.onReceiveValue(uris)
    }

    private fun handleWebPermissionRequest(request: PermissionRequest) {
        DeviceAccessHelper.handleWebPermissionRequest(
            context = appContext,
            request = request,
            onRequestRuntimePermissions = onRequestRuntimePermissions
        )
    }

    private fun attachDownloadListener(
        webView: WebView,
        tabId: Int,
        isPopupWindow: Boolean = false
    ) {
        webView.setDownloadListener(
            DownloadListener { url, userAgent, contentDisposition, mimeType, contentLength ->
                if (url.isNullOrBlank()) return@DownloadListener
                downloadBridge.markDownloadListenerClaimed(url)
                val referer = webView.url?.takeIf { it.isNotBlank() }
                    ?: _tabsState.value.find { it.id == tabId }?.url.orEmpty()
                val blobMeta = downloadBridge.getRegisteredBlobMetadata(url)
                val rawMime = when {
                    !blobMeta?.mimeType.isNullOrBlank() &&
                        !blobMeta!!.mimeType.equals("text/plain", ignoreCase = true) &&
                        !blobMeta.mimeType.equals("application/octet-stream", ignoreCase = true) ->
                        blobMeta.mimeType
                    else -> mimeType ?: "application/octet-stream"
                }
                val suggestedName = DownloadHelper.guessName(
                    url = url,
                    contentDisposition = contentDisposition,
                    mimeType = rawMime,
                    registeredBlobName = downloadBridge.getRegisteredBlobName(url),
                    registeredBlobMeta = blobMeta,
                    refererUrl = referer
                )
                val resolvedMime = resolveAccurateMimeType(
                    fileName = suggestedName,
                    rawMimeType = rawMime,
                    magicHex = blobMeta?.magicHex
                )
                val destination = currentDownloadDestination()
                val effectiveLength = if (contentLength > 0L) {
                    contentLength
                } else {
                    blobMeta?.sizeBytes ?: -1L
                }
                val req = PendingDownloadRequest(
                    url = url,
                    userAgent = userAgent ?: getSanitizedMobileUserAgent(appContext),
                    contentDisposition = contentDisposition ?: "",
                    mimeType = resolvedMime,
                    contentLength = effectiveLength,
                    suggestedFileName = suggestedName,
                    defaultDestination = destination,
                    refererUrl = referer,
                    sourceTabId = tabId
                )

                // Immediately pre-stage blob: or data: URLs to native temp storage at t=0
                // BEFORE URL.revokeObjectURL() can invalidate the Blob while the user views the dialog!
                if ((url.startsWith("blob:") || url.startsWith("data:")) &&
                    !downloadBridge.hasStagedOrActiveBlob(url)
                ) {
                    val preStageScript = DownloadHelper.buildBlobOrDataExtractionScript(
                        blobOrDataUrl = url,
                        suggestedName = suggestedName,
                        mimeType = resolvedMime,
                        destination = destination,
                        preStageOnly = true
                    )
                    webView.evaluateJavascript(preStageScript, null)
                }

                if (isPopupWindow) {
                    closeOAuthPopup(webView)
                }

                if (currentSettings.askBeforeDownload) {
                    _pendingDownload.value = req
                } else {
                    executeDownloadRequest(req, suggestedName, destination)
                }
            }
        )
    }

    fun closeOAuthPopup(targetPopupView: WebView? = null) {
        val session = _oauthPopupState.value
        val popupView = targetPopupView ?: session?.popupWebView ?: return
        if (session == null || session.popupWebView === popupView) {
            _oauthPopupState.value = null
        }
        flushCookiesNow()
        // Wait 800ms before calling stopLoading()/destroy() so any in-flight
        // `window.opener.postMessage(oauthToken, ...)` from Google's OAuth2 / Drive popup
        // is guaranteed to reach the parent `aistudio.google.com` frame before Blink teardown!
        mainScope.launch {
            delay(800L)
            try {
                (popupView.parent as? ViewGroup)?.removeView(popupView)
                if (popupView is UnthrottledWebView) {
                    popupView.allowExplicitDestroy = true
                }
                popupView.stopLoading()
                popupView.destroy()
            } catch (_: Exception) {
            }
        }
    }

    private fun updateTabLoadingProgress(tabId: Int, progress: Int, isLoading: Boolean) {
        tabProgressMap[tabId] = progress.coerceIn(0, 100)
        tabLoadingMap[tabId] = isLoading
        if (_activeTabId.value == tabId) {
            _activeTabProgress.value = progress.coerceIn(0, 100)
            _activeTabIsLoading.value = isLoading
        }
    }

    private inline fun updateTabModel(
        tabId: Int,
        crossinline transform: (BrowserTabModel) -> BrowserTabModel
    ) {
        _tabsState.update { currentList ->
            currentList.map { tab ->
                if (tab.id == tabId) transform(tab) else tab
            }
        }
    }

    companion object {
        const val DEFAULT_HOME_URL = "https://aistudio.google.com/"
        const val NEW_TAB_URL = "about:newtab"
        const val DEFAULT_TAB_COUNT = 1
        const val MAX_TAB_COUNT = 50
        private const val TAB_SESSION_PREFS_NAME = "flowra_open_tabs_session"
        private const val KEY_SAVED_TABS_JSON = "saved_tabs_json"
        private const val KEY_ACTIVE_TAB_ID = "active_tab_id"
        private const val KEY_NEXT_TAB_ID = "next_tab_id"
        private const val KEY_RECENTLY_CLOSED_JSON = "recently_closed_tabs_json"
        private const val KEY_PURGED_STALE_BUNDLES_V2 = "purged_stale_bundles_v2"
        private const val KEY_PURGED_STALE_BUNDLES_V4 = "purged_stale_bundles_v4"
        private const val KEY_CLEANED_HTTP_CACHE_V4 = "cleaned_http_cache_v4"

        const val MOBILE_CHROME_USER_AGENT =
            "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"

        const val DESKTOP_CHROME_USER_AGENT =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"

        @Volatile
        private var cachedChromeFullVersion: String? = null

        @Volatile
        private var cachedSanitizedMobileUa: String? = null

        @Volatile
        private var cachedSanitizedDesktopUa: String? = null

        /**
         * Removes any corrupt/unsigned Chromium Finch `variations_seed` / `variations_seed_new`
         * files from `app_webview/` and updates `variations_stamp` before WebView provider
         * startup so `variations_seed_loader.cc(37)] Seed missing signature` is never triggered.
         */
        fun prepareCleanVariationsState(context: Context) {
            try {
                val appCtx = context.applicationContext ?: context
                val webviewDir = appCtx.getDir("webview", Context.MODE_PRIVATE)
                val seedFile = File(webviewDir, "variations_seed")
                val newSeedFile = File(webviewDir, "variations_seed_new")
                val stampFile = File(webviewDir, "variations_stamp")
                if (seedFile.exists()) {
                    seedFile.delete()
                }
                if (newSeedFile.exists()) {
                    newSeedFile.delete()
                }
                if (!stampFile.exists()) {
                    stampFile.createNewFile()
                }
                stampFile.setLastModified(System.currentTimeMillis())
            } catch (_: Throwable) {
            }
        }

        private fun resolveDeviceChromeFullVersion(context: Context): String {
            cachedChromeFullVersion?.let { return it }
            val resolved = try {
                val raw = WebSettings.getDefaultUserAgent(context).orEmpty()
                val match = Regex("Chrome/([0-9]+\\.[0-9]+\\.[0-9]+\\.[0-9]+)").find(raw)?.groupValues?.getOrNull(1)
                if (!match.isNullOrBlank()) match else "131.0.0.0"
            } catch (_: Throwable) {
                "131.0.0.0"
            }
            cachedChromeFullVersion = resolved
            return resolved
        }

        /**
         * Returns the official Chrome/Brave Android Reduced User-Agent (`Linux; Android 10; K`)
         * using the device's real Chromium engine version so:
         * 1) `Sec-CH-UA` and `User-Agent` versions match 100% (preventing AI Studio BotGuard / WAA rejections), and
         * 2) `accounts.google.com` 2-Step Verification always sends the verification prompt/code to the phone.
         */
        fun getSanitizedMobileUserAgent(context: Context): String {
            cachedSanitizedMobileUa?.let { return it }
            val fullVer = resolveDeviceChromeFullVersion(context)
            val resolved = "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/$fullVer Mobile Safari/537.36"
            cachedSanitizedMobileUa = resolved
            return resolved
        }

        /**
         * Derives a Desktop Chrome User-Agent whose Chrome/<version> matches the device's actual
         * Chromium engine version so Sec-CH-UA Client Hints and User-Agent never conflict.
         */
        fun getSanitizedDesktopUserAgent(context: Context): String {
            cachedSanitizedDesktopUa?.let { return it }
            val fullVer = resolveDeviceChromeFullVersion(context)
            val resolved = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/$fullVer Safari/537.36"
            cachedSanitizedDesktopUa = resolved
            return resolved
        }

        /**
         * Configures both the HTTP User-Agent string AND Chromium's native C++ `Sec-CH-UA`
         * (`UserAgentMetadata`) so the WebView identifies as genuine `"Google Chrome"` / `"Chromium"`
         * instead of `"Android WebView"`, without any JavaScript `Object.defineProperty` tampering.
         */
        fun applyChromeUserAgentAndMetadata(
            context: Context,
            settings: WebSettings,
            isDesktop: Boolean
        ) {
            val fullVer = resolveDeviceChromeFullVersion(context)
            val majorVer = fullVer.substringBefore('.').ifBlank { "131" }
            settings.userAgentString = if (isDesktop) {
                getSanitizedDesktopUserAgent(context)
            } else {
                getSanitizedMobileUserAgent(context)
            }
            try {
                if (WebViewFeature.isFeatureSupported(WebViewFeature.USER_AGENT_METADATA)) {
                    val brands = listOf(
                        UserAgentMetadata.BrandVersion.Builder()
                            .setBrand("Not_A Brand")
                            .setMajorVersion("24")
                            .setFullVersion("24.0.0.0")
                            .build(),
                        UserAgentMetadata.BrandVersion.Builder()
                            .setBrand("Chromium")
                            .setMajorVersion(majorVer)
                            .setFullVersion(fullVer)
                            .build(),
                        UserAgentMetadata.BrandVersion.Builder()
                            .setBrand("Google Chrome")
                            .setMajorVersion(majorVer)
                            .setFullVersion(fullVer)
                            .build()
                    )
                    val metadata = UserAgentMetadata.Builder()
                        .setBrandVersionList(brands)
                        .setFullVersion(fullVer)
                        .setPlatform(if (isDesktop) "Linux" else "Android")
                        .setPlatformVersion(if (isDesktop) "6.5.0" else "14.0.0")
                        .setArchitecture(if (isDesktop) "x86" else "")
                        .setBitness(if (isDesktop) 64 else UserAgentMetadata.BITNESS_DEFAULT)
                        .setModel("")
                        .setMobile(!isDesktop)
                        .setWow64(false)
                        .build()
                    WebSettingsCompat.setUserAgentMetadata(settings, metadata)
                }
            } catch (_: Throwable) {
            }
        }

        private val AD_BLOCK_DOMAINS = setOf(
            "doubleclick.net",
            "googlesyndication.com",
            "googleadservices.com",
            "adservice.google.com",
            "ads.pubmatic.com",
            "adnxs.com",
            "taboola.com",
            "outbrain.com",
            "criteo.com",
            "scorecardresearch.com"
        )

        private val VIDEO_EXTENSIONS = listOf(
            ".mp4", ".webm", ".m4v", ".mov", ".ogv", ".3gp", ".mkv", ".m3u8", ".mpd"
        )

        private val DEDICATED_VIDEO_HOSTS = setOf(
            "youtube.com",
            "m.youtube.com",
            "googlevideo.com",
            "vimeo.com",
            "twitch.tv",
            "dailymotion.com"
        )

        private val PAUSE_VIDEO_ONLY_JS = """
            (function() {
                try {
                    window.__studioTabIsActive = false;
                    var videos = document.getElementsByTagName('video');
                    for (var i = 0; i < videos.length; i++) {
                        try {
                            videos[i].autoplay = false;
                            videos[i].preload = 'none';
                            if (!videos[i].paused) videos[i].pause();
                        } catch (e1) {}
                    }
                } catch (e) {}
            })();
        """.trimIndent()

        internal val PAGE_VISIBILITY_OVERRIDE_JS = """
            (function() {
                try {
                    var host = (window.location && window.location.hostname) ? window.location.hostname.toLowerCase() : '';
                    if (!window.__studioBrowserAntiThrottleInstalled) {
                        window.__studioBrowserAntiThrottleInstalled = true;

                        // On accounts.google.com, disable broken WebView Passkey / WebAuthn local challenge
                        // so Google Sign-In always sends the 2-Step Verification code / Google Prompt notification
                        // directly to the phone instead of hanging on navigator.credentials.get({ publicKey }).
                        if (host === 'accounts.google.com' || host.endsWith('.accounts.google.com')) {
                            try {
                                if (window.PublicKeyCredential) {
                                    window.PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable = function() {
                                        return Promise.resolve(false);
                                    };
                                    window.PublicKeyCredential.isConditionalMediationAvailable = function() {
                                        return Promise.resolve(false);
                                    };
                                }
                                if (navigator.credentials && navigator.credentials.get) {
                                    var origCredGet = navigator.credentials.get.bind(navigator.credentials);
                                    navigator.credentials.get = function(options) {
                                        if (options && options.publicKey) {
                                            return Promise.reject(new DOMException('Passkey not supported in WebView; using Google Prompt', 'NotSupportedError'));
                                        }
                                        return origCredGet(options);
                                    };
                                }
                            } catch (ePk) {}
                        }

                        function sanitizeVideoElement(v) {
                            if (!v || v.tagName !== 'VIDEO') return;
                            var isBackground = (window.__studioTabIsActive === false);
                            var isAutoMutedPromo = (v.autoplay || v.hasAttribute('autoplay')) && !window.__studioUserMediaUnlocked;
                            if (isBackground || isAutoMutedPromo) {
                                try {
                                    v.autoplay = false;
                                    v.removeAttribute('autoplay');
                                    v.preload = 'none';
                                    if (!v.paused) v.pause();
                                } catch (e3) {}
                            }
                        }

                        window.addEventListener('visibilitychange', function(e) {
                            if (document.visibilityState !== 'visible') {
                                e.stopImmediatePropagation();
                            }
                        }, true);
                        window.addEventListener('webkitvisibilitychange', function(e) {
                            if (document.visibilityState !== 'visible') {
                                e.stopImmediatePropagation();
                            }
                        }, true);
                        window.addEventListener('loadstart', function(e) {
                            if (e && e.target && e.target.tagName === 'VIDEO') {
                                sanitizeVideoElement(e.target);
                            }
                        }, true);

                        // Universal Blob/File Store & Magic-Byte Sniffer
                        window.__flowraBlobStore = window.__flowraBlobStore || {};
                        window.__flowraBlobKeys = window.__flowraBlobKeys || [];
                        window.__flowraStagedUrls = window.__flowraStagedUrls || {};

                        function isBlobLike(obj) {
                            return obj && ((typeof Blob !== 'undefined' && obj instanceof Blob) ||
                                (typeof obj.slice === 'function' && typeof obj.size === 'number'));
                        }

                        function readBlobMagicHex(blob, callback) {
                            try {
                                if (!isBlobLike(blob) || blob.size <= 0) {
                                    callback('');
                                    return;
                                }
                                var slice = blob.slice(0, Math.min(32, blob.size));
                                var reader = new FileReader();
                                reader.onloadend = function() {
                                    try {
                                        var buf = reader.result;
                                        if (!buf) { callback(''); return; }
                                        var bytes = new Uint8Array(buf);
                                        var hex = '';
                                        for (var i = 0; i < bytes.length; i++) {
                                            var h = bytes[i].toString(16);
                                            hex += (h.length === 1 ? '0' + h : h);
                                        }
                                        callback(hex);
                                    } catch (eHex) { callback(''); }
                                };
                                reader.onerror = function() { callback(''); };
                                reader.readAsArrayBuffer(slice);
                            } catch (eRead) {
                                callback('');
                            }
                        }

                        function preStageBlobToNativeBridge(blobUrl, suggestedName, knownBlob) {
                            try {
                                if (!blobUrl || !window.StudioDownloadBridge || !window.StudioDownloadBridge.beginPreStagedBlobTransfer) return;
                                var now = Date.now();
                                if (window.__flowraStagedUrls[blobUrl] && (now - window.__flowraStagedUrls[blobUrl]) < 1500) {
                                    if (suggestedName && window.StudioDownloadBridge.registerBlobSuggestedName) {
                                        window.StudioDownloadBridge.registerBlobSuggestedName(blobUrl, suggestedName);
                                    }
                                    return;
                                }
                                window.__flowraStagedUrls[blobUrl] = now;

                                function streamBlobObj(blob) {
                                    if (!isBlobLike(blob)) return;
                                    var transferId = 'pre_' + Date.now() + '_' + Math.floor(Math.random() * 100000);
                                    var bMime = blob.type || '';
                                    var bName = suggestedName || blob.name || '';
                                    readBlobMagicHex(blob, function(magicHex) {
                                        window.StudioDownloadBridge.beginPreStagedBlobTransfer(
                                            transferId,
                                            blobUrl,
                                            bName,
                                            bMime,
                                            blob.size || -1,
                                            magicHex || '',
                                            window.location ? window.location.href : ''
                                        );
                                        var chunkSize = 512 * 1024;
                                        var offset = 0;
                                        function nextChunk() {
                                            if (offset >= blob.size) {
                                                window.StudioDownloadBridge.finishBlobTransfer(transferId, blobUrl);
                                                return;
                                            }
                                            var slice = blob.slice(offset, Math.min(offset + chunkSize, blob.size));
                                            offset += chunkSize;
                                            var r = new FileReader();
                                            r.onloadend = function() {
                                                if (r.result) {
                                                    window.StudioDownloadBridge.appendBlobChunk(transferId, r.result);
                                                    nextChunk();
                                                } else {
                                                    window.StudioDownloadBridge.finishBlobTransfer(transferId, blobUrl);
                                                }
                                            };
                                            r.onerror = function() {
                                                window.StudioDownloadBridge.reportBlobTransferError(transferId, blobUrl, 'Read error');
                                            };
                                            r.readAsDataURL(slice);
                                        }
                                        nextChunk();
                                    });
                                }

                                var cached = knownBlob || (window.__flowraBlobStore && window.__flowraBlobStore[blobUrl]);
                                if (cached) {
                                    streamBlobObj(cached);
                                    return;
                                }

                                try {
                                    var xhr = new XMLHttpRequest();
                                    xhr.open('GET', blobUrl, true);
                                    xhr.responseType = 'blob';
                                    xhr.onload = function() {
                                        if ((xhr.status === 200 || xhr.status === 0) && xhr.response) {
                                            window.__flowraBlobStore[blobUrl] = xhr.response;
                                            streamBlobObj(xhr.response);
                                        }
                                    };
                                    xhr.onerror = function() {
                                        fetch(blobUrl).then(function(res) { return res.blob(); }).then(function(b) {
                                            window.__flowraBlobStore[blobUrl] = b;
                                            streamBlobObj(b);
                                        }).catch(function() {});
                                    };
                                    xhr.send();
                                } catch (eXhr) {
                                    fetch(blobUrl).then(function(res) { return res.blob(); }).then(function(b) {
                                        window.__flowraBlobStore[blobUrl] = b;
                                        streamBlobObj(b);
                                    }).catch(function() {});
                                }
                            } catch (ePre) {}
                        }

                        var isGoogleHost = (host === 'google.com' || host.endsWith('.google.com') || host.endsWith('.gstatic.com') || host.endsWith('.googleapis.com'));
                        if (!isGoogleHost) {
                            var urlTargets = [];
                            if (window.URL && window.URL.createObjectURL) urlTargets.push(window.URL);
                            if (window.webkitURL && window.webkitURL.createObjectURL && window.webkitURL !== window.URL) urlTargets.push(window.webkitURL);

                            urlTargets.forEach(function(urlObj) {
                                var origCreate = urlObj.createObjectURL.bind(urlObj);
                                var origRevoke = urlObj.revokeObjectURL ? urlObj.revokeObjectURL.bind(urlObj) : null;
                                var wrappedCreate = function(obj) {
                                    var generatedUrl = origCreate(obj);
                                    try {
                                        if (isBlobLike(obj)) {
                                            window.__flowraBlobStore[generatedUrl] = obj;
                                            window.__flowraBlobKeys.push(generatedUrl);
                                            if (window.__flowraBlobKeys.length > 60) {
                                                var oldest = window.__flowraBlobKeys.shift();
                                                if (oldest) delete window.__flowraBlobStore[oldest];
                                            }
                                            readBlobMagicHex(obj, function(magicHex) {
                                                try {
                                                    if (window.StudioDownloadBridge && window.StudioDownloadBridge.registerBlobMetadata) {
                                                        window.StudioDownloadBridge.registerBlobMetadata(
                                                            generatedUrl,
                                                            obj.type || '',
                                                            obj.size || -1,
                                                            magicHex || '',
                                                            obj.name || ''
                                                        );
                                                    }
                                                } catch (eReg) {}
                                            });
                                        }
                                    } catch (eBlob) {}
                                    return generatedUrl;
                                };
                                urlObj.createObjectURL = wrappedCreate;

                                if (origRevoke) {
                                    var wrappedRevoke = function(url) {
                                        setTimeout(function() {
                                            try {
                                                delete window.__flowraBlobStore[url];
                                                origRevoke(url);
                                            } catch (eRev) {}
                                        }, 900000);
                                    };
                                    urlObj.revokeObjectURL = wrappedRevoke;
                                }
                            });
                        }

                        function handleAnchorDownloadCandidate(anchorEl) {
                            try {
                                if (!anchorEl) return;
                                var href = anchorEl.href || anchorEl.getAttribute('href') || '';
                                if (!href) return;
                                var dlName = anchorEl.getAttribute('download') || anchorEl.download || '';
                                if (dlName && window.StudioDownloadBridge && window.StudioDownloadBridge.registerBlobSuggestedName) {
                                    window.StudioDownloadBridge.registerBlobSuggestedName(href, dlName);
                                }
                                if (href.indexOf('blob:') === 0 || href.indexOf('data:') === 0) {
                                    preStageBlobToNativeBridge(href, dlName, window.__flowraBlobStore[href]);
                                }
                            } catch (eCand) {}
                        }

                        window.addEventListener('click', function(e) {
                            try {
                                var el = e.target;
                                while (el && el.tagName !== 'A') {
                                    el = el.parentElement;
                                }
                                if (el) {
                                    handleAnchorDownloadCandidate(el);
                                }
                            } catch (eClick) {}
                        }, true);
                    }

                    var existingVideos = document.getElementsByTagName('video');
                    for (var i = 0; i < existingVideos.length; i++) {
                        var v = existingVideos[i];
                        if (window.__studioTabIsActive === false || ((v.autoplay || v.hasAttribute('autoplay')) && !window.__studioUserMediaUnlocked)) {
                            try {
                                v.autoplay = false;
                                v.preload = 'none';
                                if (!v.paused) v.pause();
                            } catch (e4) {}
                        }
                    }
                } catch (e) {}
            })();
        """.trimIndent()

        @Volatile
        private var INSTANCE: WebViewManager? = null

        fun getInstance(context: Context): WebViewManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: WebViewManager(context.applicationContext).also { INSTANCE = it }
            }
        }

        fun getInstanceIfCreated(): WebViewManager? = INSTANCE
    }
}

class BrowserViewModel(val webViewManager: WebViewManager) : ViewModel() {

    private val repo = webViewManager.repository
    private val prefs = webViewManager.preferences

    val settings: StateFlow<BrowserSettings> = prefs.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), BrowserSettings())

    val bookmarks: StateFlow<List<BookmarkEntity>> = repo.allBookmarks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val speedDialBookmarks: StateFlow<List<BookmarkEntity>> = repo.speedDialBookmarks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val history: StateFlow<List<HistoryEntity>> = repo.allHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val downloads: StateFlow<List<DownloadEntity>> = repo.allDownloads
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val installedWebApps: StateFlow<List<InstalledWebAppEntity>> = repo.allWebApps
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val isActiveTabBookmarked: StateFlow<Boolean> = combine(
        webViewManager.tabsState,
        webViewManager.activeTabId,
        bookmarks
    ) { tabs, activeId, allBookmarks ->
        val activeUrl = tabs.find { it.id == activeId }?.url ?: ""
        allBookmarks.any { it.url == activeUrl }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    init {
        // Rescue any stuck 0 B or interrupted downloads on launch and sync active downloads
        viewModelScope.launch(Dispatchers.IO) {
            try {
                DownloadHelper.syncActiveDownloads(
                    context = webViewManager.persistentContainer.context,
                    repository = repo
                )
            } catch (_: Exception) {
            }
            downloads
                .map { list ->
                    list.any {
                        it.status == DownloadStatus.RUNNING ||
                            it.status == DownloadStatus.PENDING ||
                            it.status == DownloadStatus.PAUSED
                    }
                }
                .distinctUntilChanged()
                .collectLatest { hasActiveDownloads ->
                    while (hasActiveDownloads && isActive) {
                        try {
                            DownloadHelper.syncActiveDownloads(
                                context = webViewManager.persistentContainer.context,
                                repository = repo
                            )
                        } catch (_: Exception) {
                        }
                        delay(1500L)
                    }
                }
        }
    }

    fun toggleBookmarkForActiveTab() {
        val activeId = webViewManager.activeTabId.value
        val activeTab = webViewManager.tabsState.value.find { it.id == activeId } ?: return
        if (activeTab.url == WebViewManager.NEW_TAB_URL) return
        viewModelScope.launch(Dispatchers.IO) {
            repo.toggleBookmark(activeTab.pageTitle, activeTab.url)
        }
    }

    fun addBookmark(title: String, url: String, isSpeedDial: Boolean = false) {
        viewModelScope.launch(Dispatchers.IO) {
            repo.addOrUpdateBookmark(
                BookmarkEntity(
                    title = title.ifBlank { url },
                    url = webViewManager.normalizeUrlOrSearchQuery(url),
                    isSpeedDial = isSpeedDial
                )
            )
        }
    }

    fun updateBookmark(id: Long, title: String, url: String, isSpeedDial: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            repo.updateBookmarkFields(
                id = id,
                title = title,
                url = webViewManager.normalizeUrlOrSearchQuery(url),
                isSpeedDial = isSpeedDial
            )
        }
    }

    fun toggleBookmarkSpeedDial(bookmark: BookmarkEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repo.setBookmarkSpeedDial(bookmark.id, !bookmark.isSpeedDial)
        }
    }

    fun deleteBookmark(id: Long) {
        viewModelScope.launch(Dispatchers.IO) { repo.deleteBookmark(id) }
    }

    fun deleteHistoryItem(id: Long) {
        viewModelScope.launch(Dispatchers.IO) { repo.deleteHistoryItem(id) }
    }

    fun clearHistory() {
        viewModelScope.launch(Dispatchers.IO) { repo.clearHistory() }
    }

    fun deleteDownloadRecord(id: Long) {
        val appCtx = webViewManager.persistentContainer.context.applicationContext
        DownloadHelper.cancelActiveDownload(appCtx, repo, id)
    }

    fun clearFinishedDownloads() {
        viewModelScope.launch(Dispatchers.IO) { repo.clearFinishedDownloads() }
    }

    fun extractDownloadedZip(context: Context, download: DownloadEntity) {
        DownloadHelper.extractDownloadedZip(context, repo, download)
    }

    fun retryDownload(context: Context, download: DownloadEntity) {
        DownloadHelper.retryDownload(context, repo, download)
    }

    fun extractExternalZipUri(context: Context, zipUri: Uri) {
        val fakeEntity = DownloadEntity(
            systemDownloadId = -1L,
            fileName = zipUri.lastPathSegment?.substringAfterLast('/')?.ifBlank { "archive.zip" } ?: "archive.zip",
            url = zipUri.toString(),
            mimeType = "application/zip",
            localUri = zipUri.toString(),
            status = DownloadStatus.SUCCESSFUL,
            saveFolderLabel = "/Downloads"
        )
        DownloadHelper.extractDownloadedZip(context, repo, fakeEntity)
    }

    fun createInstalledWebApp(
        context: Context,
        name: String,
        url: String,
        isStandalonePwa: Boolean,
        isolatedProfile: Boolean,
        badgeColorHex: Long,
        badgeTag: String,
        favicon: Bitmap?,
        launchImmediately: Boolean
    ) {
        val pwaId = PwaShortcutHelper.generateUniquePwaId()
        val normalizedUrl = webViewManager.normalizeUrlOrSearchQuery(url)
        val profileName = if (isolatedProfile) "pwa_profile_$pwaId" else "Default"
        val entity = InstalledWebAppEntity(
            pwaId = pwaId,
            name = name.trim().ifBlank { "Web App" },
            url = normalizedUrl,
            isStandalonePwa = isStandalonePwa,
            isolatedProfile = isolatedProfile,
            profileName = profileName,
            badgeColorHex = badgeColorHex,
            badgeTag = badgeTag.trim().take(3)
        )
        viewModelScope.launch(Dispatchers.IO) {
            repo.insertWebApp(entity)
        }
        if (launchImmediately && !entity.isStandalonePwa) {
            webViewManager.focusOrOpenTab(entity.url)
        }
        // Wait 200ms after the Compose Dialog closes so MainActivity regains full top window focus
        // before requesting the Android system Launcher's "Add to Home screen" pin prompt.
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            val targetCtx = webViewManager.currentActivity ?: context
            val pinned = PwaShortcutHelper.pinToHomeScreen(targetCtx, entity, favicon)
            Toast.makeText(
                targetCtx,
                if (pinned) "Adding \"${entity.name}\" to Home Screen" else "Saved \"${entity.name}\" to Installed PWAs",
                Toast.LENGTH_SHORT
            ).show()
            if (launchImmediately && entity.isStandalonePwa && !pinned) {
                PwaShortcutHelper.launchWebApp(targetCtx, entity, requestPinOnStart = false)
            }
        }, 200L)
    }

    fun hibernatePwaSession(context: Context, pwaId: String) {
        PwaWebViewPool.removeAndDestroySession(pwaId, context)
    }

    fun deleteInstalledWebApp(app: InstalledWebAppEntity) {
        PwaWebViewPool.removeAndDestroySession(app.pwaId)
        if (app.isolatedProfile) {
            PwaShortcutHelper.deleteIsolatedProfile(app.profileName)
        }
        viewModelScope.launch(Dispatchers.IO) {
            repo.deleteWebApp(app.pwaId)
        }
    }

    fun updateSearchEngine(engine: SearchEngine) {
        viewModelScope.launch { prefs.setSearchEngine(engine) }
    }

    fun updateThemeMode(mode: ThemeMode) {
        viewModelScope.launch { prefs.setThemeMode(mode) }
    }

    fun updateHomepageMode(mode: HomepageMode) {
        viewModelScope.launch { prefs.setHomepageMode(mode) }
    }

    fun updateFrameRateMode(mode: FrameRateMode) {
        viewModelScope.launch { prefs.setFrameRateMode(mode) }
    }

    fun updateAskBeforeDownload(ask: Boolean) {
        viewModelScope.launch { prefs.setAskBeforeDownload(ask) }
    }

    fun updateDownloadDestination(
        preset: String,
        customTreeUri: String? = null,
        customFolderLabel: String? = null
    ) {
        viewModelScope.launch {
            prefs.setDownloadDestination(preset, customTreeUri, customFolderLabel)
        }
    }

    fun updateKeepPwasAliveInRam(enabled: Boolean) {
        PwaWebViewPool.setKeepAliveEnabled(enabled, webViewManager.persistentContainer.context)
        viewModelScope.launch { prefs.setKeepPwasAliveInRam(enabled) }
    }

    fun updateShowTabStrip(show: Boolean) {
        viewModelScope.launch { prefs.setShowTabStrip(show) }
    }

    fun updateAdBlockEnabled(enabled: Boolean) {
        viewModelScope.launch { prefs.setAdBlockEnabled(enabled) }
    }

    fun updateJavaScriptEnabled(enabled: Boolean) {
        viewModelScope.launch { prefs.setJavaScriptEnabled(enabled) }
    }

    fun updateDarkWebPages(enabled: Boolean) {
        viewModelScope.launch { prefs.setDarkWebPages(enabled) }
    }

    fun updateTextZoomPercent(zoom: Int) {
        viewModelScope.launch { prefs.setTextZoomPercent(zoom) }
    }

    class Factory(private val context: Context) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return BrowserViewModel(WebViewManager.getInstance(context)) as T
        }
    }
}
